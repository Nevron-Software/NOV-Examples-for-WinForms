﻿using AppKit;

using Nevron.Nov;
using Nevron.Nov.Barcode;
using Nevron.Nov.Chart;
using Nevron.Nov.Diagram;
using Nevron.Nov.Grid;
using Nevron.Nov.Mac;
using Nevron.Nov.Schedule;
using Nevron.Nov.Text;

namespace NovXamarinMacProject
{
    static class MainClass
    {
        static void Main(string[] args)
        {
            NSApplication.Init();

            // Install NOV
            NModule[] modules = new NModule[]
            {
                // Add the modules you want to use here
                NBarcodeModule.Instance,
                NChartModule.Instance,
                NDiagramModule.Instance,
                NGridModule.Instance,
                NScheduleModule.Instance,
                NTextModule.Instance
            };

            NNovApplicationInstaller.Install(modules);

            // Set new application delegate
            NSApplication.SharedApplication.Delegate = new AppDelegate();
            NSApplication.SharedApplication.Run();
        }
    }
}

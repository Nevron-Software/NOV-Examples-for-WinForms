﻿using AppKit;
using CoreGraphics;

using Nevron.Nov;
using Nevron.Nov.Graphics;
using Nevron.Nov.Examples;
using Nevron.Nov.Layout;
using Nevron.Nov.Mac;
using Nevron.Nov.UI;

namespace NovXamarinMacProject
{
    public class MainWindow : NSWindow
    {
        #region Constructors

        public MainWindow()
            : base(new CGRect(0, 0, 400, 400), NSWindowStyle.Resizable | NSWindowStyle.Titled | NSWindowStyle.Closable, NSBackingStore.Buffered, false)
        {
			// Maximize the window
            this.IsZoomed = true;

			// Set the window's title
			Title = "NOV Xamarin.Mac - {Title}";

			// Create the NOV example and its controls
			NWidget exampleContent = CreateExampleContent();
			NWidget exampleControls = CreateExampleControls();
			if (exampleControls != null)
			{
				exampleControls.PreferredWidth = 300;
			}

			// Place the example and its controls in a pair box
			NPairBox pairBox = new NPairBox(exampleContent, exampleControls);
			pairBox.FillMode = ENStackFillMode.First;
			pairBox.FitMode = ENStackFitMode.First;
			pairBox.Margins = new NMargins(NDesign.HorizontalSpacing, NDesign.VerticalSpacing);

			// Host the example in the window
			ContentView = new NNovWidgetHost(pairBox);
        }

        #endregion

        #region Example

        private NWidget CreateExampleContent()
		{
			return null;
		}
		private NWidget CreateExampleControls()
		{
			return null;
		}

		#endregion

		#region Implementation
		#endregion

		#region Event Handlers
		#endregion

		#region Fields
		#endregion

		#region Static Methods
		#endregion

		#region Constants
		#endregion

		#region Nested Types
		#endregion
	}
}
﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Threading.Tasks;
using System.Windows;

using Nevron.Nov;
using Nevron.Nov.Barcode;
using Nevron.Nov.Chart;
using Nevron.Nov.Diagram;
using Nevron.Nov.Grid;
using Nevron.Nov.Layout;
using Nevron.Nov.Schedule;
using Nevron.Nov.Text;
using Nevron.Nov.UI;
using Nevron.Nov.Windows;

namespace NovWpfProject
{
	/// <summary>
	/// Interaction logic for App.xaml
	/// </summary>
	public partial class App : Application
	{
		protected override void OnStartup(StartupEventArgs e)
		{
			base.OnStartup(e);

			// TODO: Apply license for redistribution here. You can skip this code when evaluating NOV.
			// NLicenseManager.Instance.SetLicense(new NLicense("LICENSE KEY"));

			// Install Nevron Open Vision for WPF
			NNovApplicationInstaller.Install(
				NBarcodeModule.Instance,
				NTextModule.Instance,
				NChartModule.Instance,
				NDiagramModule.Instance,
				NScheduleModule.Instance,
				NGridModule.Instance);
		}
	}
}
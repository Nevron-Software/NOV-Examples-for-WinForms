﻿using System.Windows;

using Nevron.Nov;
using Nevron.Nov.Examples;
using Nevron.Nov.Graphics;
using Nevron.Nov.Layout;
using Nevron.Nov.UI;
using Nevron.Nov.Windows;

namespace NovWpfProject
{
	/// <summary>
	/// Interaction logic for MainWindow.xaml
	/// </summary>
	public partial class MainWindow : Window
	{
		#region Constructors

		public MainWindow()
		{
			InitializeComponent();

			// Set the window's title
			Title = "NOV WPF - {Title}";

			// Create the NOV example and its controls
			NWidget exampleContent = CreateExampleContent();
			NWidget exampleControls = CreateExampleControls();
			if (exampleControls != null)
			{
				exampleControls.PreferredWidth = 300;
			}

			// Place the example and its controls in a pair box
			NPairBox pairBox = new NPairBox(exampleContent, exampleControls);
			pairBox.FillMode = ENStackFillMode.First;
			pairBox.FitMode = ENStackFitMode.First;
			pairBox.Margins = new NMargins(NDesign.HorizontalSpacing, NDesign.VerticalSpacing);

			// Host the example in the window
			NNovWidgetHost<NWidget> host = new NNovWidgetHost<NWidget>(pairBox);
			Content = host;
		}

		#endregion

		#region Example

		private NWidget CreateExampleContent()
		{
			return null;
		}
		private NWidget CreateExampleControls()
		{
			return null;
		}

		#endregion

		#region Implementation
		#endregion

		#region Event Handlers
		#endregion

		#region Fields
		#endregion

		#region Static Methods
		#endregion

		#region Constants
		#endregion

		#region Nested Types
		#endregion
	}
}
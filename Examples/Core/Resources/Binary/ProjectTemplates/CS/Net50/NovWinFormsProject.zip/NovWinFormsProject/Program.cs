using System;
using System.Windows.Forms;

using Nevron.Nov.Barcode;
using Nevron.Nov.Chart;
using Nevron.Nov.Diagram;
using Nevron.Nov.Grid;
using Nevron.Nov.Schedule;
using Nevron.Nov.Text;
using Nevron.Nov.Windows.Forms;

namespace NovWinFormsProject
{
	static class Program
	{
		/// <summary>
		///  The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main()
		{
			Application.SetHighDpiMode(HighDpiMode.SystemAware);
			Application.EnableVisualStyles();
			Application.SetCompatibleTextRenderingDefault(false);

			// TODO: Apply license for redistribution here. You can skip this code when evaluating NOV.
			// NLicenseManager.Instance.SetLicense("Your License Key");

			// Install Nevron Open Vision for Windows Forms
			NNovApplicationInstaller.Install(
				NTextModule.Instance,
				NChartModule.Instance,
				NDiagramModule.Instance,
				NScheduleModule.Instance,
				NGridModule.Instance,
				NBarcodeModule.Instance);

			// Uncomment the following line if you want to disable GPU hardware acceleration
			// NApplication.EnableGPURendering = false;

			Application.Run(new Form1());
		}
	}
}

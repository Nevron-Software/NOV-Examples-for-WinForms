﻿Imports Nevron.Nov
Imports Nevron.Nov.Barcode
Imports Nevron.Nov.Chart
Imports Nevron.Nov.Diagram
Imports Nevron.Nov.Grid
Imports Nevron.Nov.Schedule
Imports Nevron.Nov.Text
Imports Nevron.Nov.Windows

Class Application
    ' Application-level events, such as Startup, Exit, and DispatcherUnhandledException
    ' can be handled in this file.

    Private Sub Application_Startup(sender As Object, e As StartupEventArgs)
        ' TODO: Apply license for redistribution here. You can skip this code when evaluating NOV.
        ' NLicenseManager.Instance.SetLicense(New NLicense("LICENSE KEY"))

        ' Install Nevron Open Vision for Windows Forms
        NNovApplicationInstaller.Install(
                NBarcodeModule.Instance,
                NTextModule.Instance,
                NChartModule.Instance,
                NDiagramModule.Instance,
                NScheduleModule.Instance,
                NGridModule.Instance)
    End Sub
End Class
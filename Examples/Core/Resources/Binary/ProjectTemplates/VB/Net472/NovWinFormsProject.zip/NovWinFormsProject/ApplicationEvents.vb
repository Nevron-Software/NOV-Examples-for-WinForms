﻿Imports Microsoft.VisualBasic.ApplicationServices
Imports Nevron.Nov
Imports Nevron.Nov.Barcode
Imports Nevron.Nov.Chart
Imports Nevron.Nov.Diagram
Imports Nevron.Nov.Grid
Imports Nevron.Nov.Text
Imports Nevron.Nov.Schedule
Imports Nevron.Nov.Windows.Forms

Namespace My
    ' The following events are available for MyApplication:
    ' Startup: Raised when the application starts, before the startup form is created.
    ' Shutdown: Raised after all application forms are closed.  This event is not raised if the application terminates abnormally.
    ' UnhandledException: Raised if the application encounters an unhandled exception.
    ' StartupNextInstance: Raised when launching a single-instance application and the application is already active. 
    ' NetworkAvailabilityChanged: Raised when the network connection is connected or disconnected.

    ' **NEW** ApplyHighDpiMode: Raised when the application queries the HighDpiMode to set it for the application.

    ' Example:

    ' Private Sub MyApplication_ApplyHighDpiMode(sender As Object, e As ApplyHighDpiModeEventArgs) Handles Me.ApplyHighDpiMode
    '     e.HighDpiMode = HighDpiMode.PerMonitorV2
    ' End Sub

    Partial Friend Class MyApplication
        Private Sub MyApplication_Startup(sender As Object, e As StartupEventArgs) Handles Me.Startup
            ' TODO: Apply license for redistribution here. You can skip this code when evaluating NOV.
            ' NLicenseManager.Instance.SetLicense(New NLicense("LICENSE KEY"))

            ' Install Nevron Open Vision for Windows Forms
            NNovApplicationInstaller.Install(
                NTextModule.Instance,
                NChartModule.Instance,
                NDiagramModule.Instance,
                NScheduleModule.Instance,
                NGridModule.Instance,
                NBarcodeModule.Instance)
        End Sub
    End Class
End Namespace
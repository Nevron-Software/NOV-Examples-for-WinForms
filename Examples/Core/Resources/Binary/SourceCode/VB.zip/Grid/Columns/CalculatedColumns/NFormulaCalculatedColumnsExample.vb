Imports Nevron.Nov.Grid
Imports Nevron.Nov.Editors
Imports Nevron.Nov.Graphics
Imports Nevron.Nov.Dom
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.Grid
    Public Class NFormulaCalculatedColumnsExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' Default constructor.
        ''' </summary>
        Public Sub New()
        End Sub
        ''' <summary>
        ''' Static constructor.
        ''' </summary>
        Shared Sub New()
            NFormulaCalculatedColumnsExampleSchema = NSchema.Create(GetType(NFormulaCalculatedColumnsExample), NExampleBase.NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            m_GridView = New NTableGridView()
            Dim grid = m_GridView.Grid

            ' bind the grid to the data source
            grid.DataSource = NDummyDataSource.CreatePersonsOrdersDataSource()

            ' add a formula column
            m_TotalColumn = New NFormulaCalculatedColumn()
            m_TotalColumn.Title = "Total"
            Dim fx = grid.CreateFormulaFieldName("Price") & "*" & grid.CreateFormulaFieldName("Quantity")
            m_TotalColumn.Formula = fx
            m_TotalColumn.Format.BackgroundFill = New NColorFill(NColor.SeaShell)
            grid.Columns.Add(m_TotalColumn)

            Return m_GridView
        End Function
        Protected Overrides Function CreateExampleControls() As NWidget
            Dim stack As NStackPanel = New NStackPanel()

            Dim editors = NDesigner.GetDesigner(m_TotalColumn).CreatePropertyEditors(m_TotalColumn, NFormulaCalculatedColumn.FormulaProperty)

            For i = 0 To editors.Count - 1
                stack.Add(editors(i))
            Next

            Return stack
        End Function
        Protected Overrides Function GetExampleDescription() As String
            Return "
<p>
    Demonstrates formula calculated columns.
</p>
<p>
    Formula calculated columns are columns whose row values are not obtained from the data source, 
    but are dynamically calculated via a user-specified formula, that can reference data source field values.
    Formula calculated columns are represented by the <b>NFormulaCalculatedColumn</b> class.
</p>
<p>
    In the example the <b>Total</b> column is a formula calculated column that is calculated via the {<b>Price</b>*<b>Quantity</b>} formula.
</p>" End Function

#End Region

#Region "Fields"

        Private m_GridView As NTableGridView
        Private m_TotalColumn As NFormulaCalculatedColumn

#End Region

#Region "Schema"

        ''' <summary>
        ''' Schema associated with NFormulaCalculatedColumnsExample.
        ''' </summary>
        Public Shared ReadOnly NFormulaCalculatedColumnsExampleSchema As NSchema

#End Region
    End Class
End Namespace

Imports Nevron.Nov.Grid
Imports Nevron.Nov.Editors
Imports Nevron.Nov.Dom
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.Grid
    Public Class NColumnsWidthExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' Default constructor.
        ''' </summary>
        Public Sub New()
        End Sub
        ''' <summary>
        ''' Static constructor.
        ''' </summary>
        Shared Sub New()
            NColumnsWidthExampleSchema = NSchema.Create(GetType(NColumnsWidthExample), NExampleBase.NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            m_TableView = New NTableGridView()
            m_TableView.Grid.DataSource = NDummyDataSource.CreatePersonsDataSource()
            Return m_TableView
        End Function
        Protected Overrides Function CreateExampleControls() As NWidget
            Dim stack As NStackPanel = New NStackPanel()

            ' create the columns combo box
            stack.Add(New NLabel("Select Column:"))

            m_ColumnsComboBox = New NComboBox()
            stack.Add(m_ColumnsComboBox)

            For i = 0 To m_TableView.Grid.Columns.Count - 1
                Dim column = m_TableView.Grid.Columns(i)

                Dim item As NComboBoxItem = New NComboBoxItem(column.Title)
                item.Tag = column
                m_ColumnsComboBox.Items.Add(item)
            Next

            Me.m_ColumnsComboBox.SelectedIndexChanged += AddressOf OnColumnsComboBoxSelectedIndexChanged

            ' create the columns 
            m_ColumnPropertiesHolder = New NContentHolder()
            stack.Add(New NGroupBox("Selected Column Properties", m_ColumnPropertiesHolder))

            Return stack
        End Function

        Protected Overrides Function GetExampleDescription() As String
            Return "
<p>
    Demonstrates the column properties that affect the column width.
</p>
<p>
    Select a column from the <b>Select Column</b> combo box and explore the properties that control the selected column width.
</p>
" End Function

#End Region

#Region "Event Handlers"

        Private Sub OnColumnsComboBoxSelectedIndexChanged(ByVal arg As NValueChangeEventArgs)
            Dim item = m_ColumnsComboBox.SelectedItem
            If item Is Nothing Then
                m_ColumnPropertiesHolder.Content = Nothing
            Else
                Dim column As NColumn = item.Tag

                Dim columnPropertiesStack As NStackPanel = New NStackPanel()
                m_ColumnPropertiesHolder.Content = New NUniSizeBoxGroup(columnPropertiesStack)

                Dim designer = NDesigner.GetDesigner(column)
                Dim editors = designer.CreatePropertyEditors(column, NColumn.WidthModeProperty, NColumn.FixedWidthProperty, NColumn.WidthPercentProperty)

                For i = 0 To editors.Count - 1
                    columnPropertiesStack.Add(editors(i))
                Next
            End If
        End Sub

#End Region

#Region "Fields"

        Private m_TableView As NTableGridView
        Private m_ColumnsComboBox As NComboBox
        Private m_ColumnPropertiesHolder As NContentHolder

#End Region

#Region "Schema"

        ''' <summary>
        ''' Schema associated with NColumnsWidthExample.
        ''' </summary>
        Public Shared ReadOnly NColumnsWidthExampleSchema As NSchema

#End Region
    End Class
End Namespace

Imports System
Imports Nevron.Nov.Grid
Imports Nevron.Nov.Graphics
Imports Nevron.Nov.Data
Imports Nevron.Nov.Dom
Imports Nevron.Nov.Layout
Imports Nevron.Nov.UI
Imports Nevron.Nov.Chart

Namespace Nevron.Nov.Examples.Grid
    Public Class NCustomColumnFormatsExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' Default constructor.
        ''' </summary>
        Public Sub New()
        End Sub
        ''' <summary>
        ''' Static constructor.
        ''' </summary>
        Shared Sub New()
            NCustomColumnFormatsExampleSchema = NSchema.Create(GetType(NCustomColumnFormatsExample), NExampleBase.NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            Dim dataTable As NMemoryDataTable = New NMemoryDataTable(New NFieldInfo("Company", GetType(String)), New NFieldInfo("RegionSales", GetType(Double())))
            Dim rnd As Random = New Random()

            For i = 0 To 1000 - 1
                Dim arr = New Double(9) {}

                For j = 0 To 10 - 1
                    arr(j) = rnd.Next(100)
                Next

                dataTable.AddRow(NDummyDataSource.RandomCompanyName(), arr)
            Next

            ' create a view and get its grid
            Dim view As NTableGridView = New NTableGridView()
            Dim grid = view.Grid
            AddHandler grid.AutoCreateColumn, Sub(ByVal arg)
                                                  If Equals(arg.DataColumn.FieldName, "RegionSales") Then
                                                      Dim pieColumnFormat As NCustomColumnFormat = New NCustomColumnFormat()
                                                      pieColumnFormat.FormatDefaultDataCellDelegate = Sub(ByVal theDataCell)
                                                                                                          Dim widget As NWidget = New NWidget()
                                                                                                          widget.PreferredSize = New NSize(400, 300)
                                                                                                      End Sub

                                                      pieColumnFormat.CreateValueDataCellViewDelegate = Function(ByVal theDataCell, ByVal value)
                                                                                                            Dim values = CType(value, Double())
                                                                                                            Dim chartView As NChartView = New NChartView()
                                                                                                            chartView.PreferredSize = New NSize(300, 60)
                                                                                                            Dim cartesianChart As NCartesianChart = New NCartesianChart()
                                                                                                            NDockLayout.SetDockArea(cartesianChart, ENDockArea.Center)
                                                                                                            chartView.Surface.Content = cartesianChart
                                                                                                            cartesianChart.SetPredefinedCartesianAxes(ENPredefinedCartesianAxis.XOrdinalYLinear)
                                                                                                            cartesianChart.Legend = Nothing
                                                                                                            cartesianChart.Axes(ENCartesianAxis.PrimaryX).Visible = False
                                                                                                            Dim yAxis = cartesianChart.Axes(ENCartesianAxis.PrimaryY)
                                                                                                            Dim labelStyle As NValueScaleLabelStyle = New NValueScaleLabelStyle()
                                                                                                            labelStyle.TextStyle.Font = New NFont("Arimo", 8)
                                                                                                            CType(yAxis.Scale, NLinearScale).Labels.Style = labelStyle
                                                                                                            Dim barSeries As NBarSeries = New NBarSeries()
                                                                                                            barSeries.DataLabelStyle = New NDataLabelStyle(False)
                                                                                                            barSeries.InflateMargins = False
                                                                                                            cartesianChart.Series.Add(barSeries)
                                                                                                            Dim count = values.Length

                                                                                                            For i = 0 To count - 1
                                                                                                                barSeries.DataPoints.Add(New NBarDataPoint(values(i)))
                                                                                                            Next

                                                                                                            Return chartView
                                                                                                        End Function

                                                      arg.DataColumn.Format = pieColumnFormat
                                                  End If
                                              End Sub

            grid.DataSource = New NDataSource(dataTable)
            Return view
        End Function

        Protected Overrides Function CreateExampleControls() As NWidget
            Return Nothing
        End Function

        Protected Overrides Function GetExampleDescription() As String
            Return "
<p>
    Demonstrates custom column formatting.
</p>
<p>
    The custom column format is represented by the <b>NCustomColumnFormat</b> class. It exposes a set of delegates that you can hook to create your own widgets that represent the row values.
</p>
<p>
    In this example we are using the <b>NOV Chart for .NET</b> to display <b>Double[]</b> values.
<p>
"
        End Function

#End Region

#Region "Schema"

        ''' <summary>
        ''' Schema associated with NCustomColumnFormatsExample.
        ''' </summary>
        Public Shared ReadOnly NCustomColumnFormatsExampleSchema As NSchema

#End Region
    End Class
End Namespace

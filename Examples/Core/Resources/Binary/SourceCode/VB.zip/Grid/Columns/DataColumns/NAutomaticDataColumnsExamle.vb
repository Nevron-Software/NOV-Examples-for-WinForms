Imports Nevron.Nov.Grid
Imports Nevron.Nov.Graphics
Imports Nevron.Nov.Data
Imports Nevron.Nov.Dom
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.Grid
    Public Class NAutomaticDataColumnsExamle
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' Default constructor.
        ''' </summary>
        Public Sub New()
        End Sub
        ''' <summary>
        ''' Static constructor.
        ''' </summary>
        Shared Sub New()
            NAutomaticDataColumnsExamleSchema = NSchema.Create(GetType(NAutomaticDataColumnsExamle), NExampleBase.NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            m_GridView = New NTableGridView()
            Dim grid = m_GridView.Grid
            Dim items As NItem() = New NItem() {New NItem(NResources.Image_CountryFlags_ad_png, NColor.Navy, New NColorFill(NColor.Moccasin), New NStroke(NColor.AntiqueWhite)), New NItem(NResources.Image_CountryFlags_ae_png, NColor.Olive, New NStockGradientFill(NColor.Violet, NColor.WhiteSmoke), New NStroke(NColor.Bisque)), New NItem(NResources.Image_CountryFlags_af_png, NColor.OldLace, New NHatchFill(ENHatchStyle.DiagonalBrick, NColor.Yellow, NColor.Red), New NStroke(NColor.DarkCyan)), New NItem(NResources.Image_CountryFlags_ag_png, NColor.Plum, New NImageFill(NResources.Image__16x16_Birthday_png), New NStroke(NColor.DimGray)), New NItem(NResources.Image_CountryFlags_ai_png, NColor.Peru, New NStockGradientFill(ENGradientStyle.FromCenter, ENGradientVariant.Variant1, NColor.Wheat, NColor.DarkGoldenrod), New NStroke(NColor.CadetBlue))}

            ' bind the grid to the data source
            grid.DataSource = New NDataSource(New NGenericIListDataTable(Of NItem)(items))
            AddHandler grid.AutoCreateColumn, AddressOf grid_AutoCreateColumn
            Return m_GridView
        End Function

        Private Sub grid_AutoCreateColumn(ByVal arg As NAutoCreateColumnEventArgs)
            ' get the data column which was automatically created
            Dim dataColumn = arg.DataColumn
        End Sub

        Protected Overrides Function CreateExampleControls() As NWidget
            Dim stack As NStackPanel = New NStackPanel()
            Return stack
        End Function

        Protected Overrides Function GetExampleDescription() As String
            Return "
<p>
    Demonstrates automatically created data columns.
</p>
<p>
    Data columns are columns, which obtain and edit data from the data source.
</p>
<p>
    When the grid is bound to a data source, it will automatically create data columns for all data source fields, if the grid <b>AutoCreateColumns</b> property is true.</br>
    During this process it will also raise the <b>AutoCreateColumn</b> column event.
</p>
<p>
</p>"
        End Function

#End Region

#Region "Fields"

        Private m_GridView As NTableGridView

#End Region

#Region "Schema"

        ''' <summary>
        ''' Schema associated with NAutomaticDataColumnsExamle.
        ''' </summary>
        Public Shared ReadOnly NAutomaticDataColumnsExamleSchema As NSchema

#End Region

        Public Enum ENDummyEnum
            EnumValue1
            EnumValue2
            EnumValue3
        End Enum

        Public Class NItem
            Public Sub New(ByVal image As NImage, ByVal color As NColor, ByVal fill As NFill, ByVal stroke As NStroke)
                Me.Image = image
                Me.Color = color
                Me.Fill = fill
                Me.Stroke = stroke
            End Sub

            Public Property BooleanValue As Boolean
            Public Property ByteValue As Byte
            Public Property UInt16Value As UShort
            Public Property UInt32Value As UInteger
            Public Property UInt64Value As ULong
            Public Property Int16Value As Short
            Public Property Int32Value As Integer
            Public Property Int64Value As Long
            Public Property SingleValue As Single
            Public Property DoubleValue As Double
            Public Property DecimalValue As Decimal
            Public Property DateTimeValue As Date
            Public Property StringValue As String
            Public Property EnumValue As ENDummyEnum
            Public Property Image As NImage
            Public Property Color As NColor
            Public Property Fill As NFill
            Public Property Stroke As NStroke
        End Class
    End Class
End Namespace

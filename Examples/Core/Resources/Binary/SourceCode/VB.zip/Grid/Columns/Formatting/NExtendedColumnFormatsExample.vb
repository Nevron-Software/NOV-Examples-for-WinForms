Imports System
Imports Nevron.Nov.Grid
Imports Nevron.Nov.Data
Imports Nevron.Nov.Dom
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.Grid
    Public Class NExtendedColumnFormatsExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' Default constructor.
        ''' </summary>
        Public Sub New()
        End Sub
        ''' <summary>
        ''' Static constructor.
        ''' </summary>
        Shared Sub New()
            NExtendedColumnFormatsExampleSchema = NSchema.Create(GetType(NExtendedColumnFormatsExample), NExampleBase.NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            ' create a view and get its grid
            Dim view As NTableGridView = New NTableGridView()
            Dim grid = view.Grid

            ' create persons order data source
            Dim personOrders As NDataSource = NDummyDataSource.CreatePersonsOrdersDataSource()

            ' get the min and max price. We will use it in the progress bars.
            Dim min, max As Object
            personOrders.TryGetMin("Price", min)
            personOrders.TryGetMax("Price", max)
            AddHandler grid.AutoCreateColumn, Sub(ByVal args)
                                                  If Equals(args.FieldInfo.Name, "Price") Then
                                                      ' create a progress bar column format for the Price field
                                                      Dim progressBarColumnFormat As NProgressBarColumnFormat = New NProgressBarColumnFormat()
                                                      progressBarColumnFormat.Minimum = Convert.ToDouble(min)
                                                      progressBarColumnFormat.Maximum = Convert.ToDouble(max)
                                                      args.DataColumn.Format = progressBarColumnFormat
                                                  End If
                                              End Sub

            grid.DataSource = NDummyDataSource.CreatePersonsOrdersDataSource()
            Return view
        End Function

        Protected Overrides Function CreateExampleControls() As NWidget
            Return Nothing
        End Function

        Protected Overrides Function GetExampleDescription() As String
            Return "
<p>
    Demonstrates the extended column formats.
</p>
<p>
    Extended column formats are such column formats that the grid does not use by default. 
    It is up to the developer to manually assign the extended column format to specific columns, as the grid will not automatically assign them.
</p>
<p>
    In this example the Price column is displayed by the <b>NProgressBarColumnFormat</b>, that is an extended column format.
<p>
"
        End Function

#End Region

#Region "Schema"

        ''' <summary>
        ''' Schema associated with NExtendedColumnFormatsExample.
        ''' </summary>
        Public Shared ReadOnly NExtendedColumnFormatsExampleSchema As NSchema

#End Region
    End Class
End Namespace

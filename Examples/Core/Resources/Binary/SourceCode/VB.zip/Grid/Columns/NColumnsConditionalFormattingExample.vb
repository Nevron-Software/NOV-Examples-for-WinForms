Imports System
Imports Nevron.Nov.Grid
Imports Nevron.Nov.Graphics
Imports Nevron.Nov.Dom
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.Grid
    Public Class NColumnsConditionalFormattingExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' Default constructor.
        ''' </summary>
        Public Sub New()
        End Sub
        ''' <summary>
        ''' Static constructor.
        ''' </summary>
        Shared Sub New()
            NColumnsConditionalFormattingExampleSchema = NSchema.Create(GetType(NColumnsConditionalFormattingExample), NExampleBase.NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            ' create a view and get its grid
            Dim view As NTableGridView = New NTableGridView()
            Dim grid = view.Grid

            ' bind the grid to the PersonsOrders data source
            grid.DataSource = NDummyDataSource.CreatePersonsOrdersDataSource()

            ' Formatting Rule 1 = applied to the Product Name column.
            ' make the Aptax, Joykix, Zun Zimtam,  Dingtincof cell backgrounds LightCoral, with a bold Font
            If True Then
                ' create the formatting rule and add it in the "Product Name" column
                Dim column As NColumn = grid.Columns.GetColumnByFieldName("Product Name")

                Dim formattingRule As NFormattingRule = New NFormattingRule()
                column.FormattingRules.Add(formattingRule)

                ' row condition
                Dim orCondition As NOrGroupRowCondition = New NOrGroupRowCondition()
                orCondition.Add(New NOperatorRowCondition(New NFieldRowValue("Product Name"), ENRowConditionOperator.Equals, "Aptax"))
                orCondition.Add(New NOperatorRowCondition(New NFieldRowValue("Product Name"), ENRowConditionOperator.Equals, "Joykix"))
                orCondition.Add(New NOperatorRowCondition(New NFieldRowValue("Product Name"), ENRowConditionOperator.Equals, "Zun Zimtam"))
                orCondition.Add(New NOperatorRowCondition(New NFieldRowValue("Product Name"), ENRowConditionOperator.Equals, "Dingtincof"))
                formattingRule.RowCondition = orCondition

                ' LightCoral background fill declaration
                Dim backgroundFillDeclaration As NBackgroundFillDeclaration = New NBackgroundFillDeclaration()
                backgroundFillDeclaration.Mode = ENFillDeclarationMode.Uniform
                backgroundFillDeclaration.UniformFill = New NColorFill(NColor.LightCoral)
                formattingRule.Declarations.Add(backgroundFillDeclaration)

                ' Bold font style declaration
                Dim fontStyleDeclaration As NFontStyleDeclaration = New NFontStyleDeclaration()
                fontStyleDeclaration.FontStyle = ENFontStyle.Bold
                formattingRule.Declarations.Add(fontStyleDeclaration)
            End If

            ' Formatting Rule 2 = applied to the Product Name column.
            ' make the Aptax and Joykix cell backgrounds LightCoral, with a bold Font
            If True Then
                ' create the formatting rule and add it in the "Product Name" column
                Dim column As NColumn = grid.Columns.GetColumnByFieldName("Price")
                Dim formattingRule As NFormattingRule = New NFormattingRule()
                column.FormattingRules.Add(formattingRule)

                ' row condition
                formattingRule.RowCondition = New NTrueRowCondition()

                ' get price field min and max
                Dim minPrice, maxPrice As Object
                Dim priceFieldIndex = grid.DataSource.GetFieldIndex("Price")
                grid.DataSource.TryGetMin(priceFieldIndex, minPrice)
                grid.DataSource.TryGetMax(priceFieldIndex, maxPrice)

                ' make a graident fill declaration 
                Dim backgroundFillDeclaration As NBackgroundFillDeclaration = New NBackgroundFillDeclaration()
                backgroundFillDeclaration.Mode = ENFillDeclarationMode.TwoColorGradient
                backgroundFillDeclaration.MinimumValue = Convert.ToDouble(minPrice)
                backgroundFillDeclaration.MaximumValue = Convert.ToDouble(maxPrice)
                backgroundFillDeclaration.BeginColor = NColor.Green
                backgroundFillDeclaration.EndColor = NColor.Red
                formattingRule.Declarations.Add(backgroundFillDeclaration)
            End If

            Return view
        End Function

        Protected Overrides Function CreateExampleControls() As NWidget
            Return Nothing
        End Function
        Protected Overrides Function GetExampleDescription() As String
            Return "
<p>
    Demonstrates the conditional column formatting.
</p>
<p>
    Conditional formatting changes the default formatting of column cells, when a certain condition is met.
    NOV Grid for .NET provides strong support for authoring complex cell conditions.
</p>
<p>
    Besides static fill rules, NOV Grid for .NET also supports gradient background and text fill declarations, 
    that can be defined as a two color or three color gradient. 
</p>
<p>
    In this example <b>Price</b> background uses a two-color gradient background fill.
    The <b>Product Name</b> is has different background fill and font style applied to certain products (<b>Aptax</b>,<b>Joykix</b>,<b>Zun Zimtam</b> and <b>Dingtincof</b>).
</p>
" End Function

#End Region

#Region "Schema"

        ''' <summary>
        ''' Schema associated with NColumnsConditionalFormattingExample.
        ''' </summary>
        Public Shared ReadOnly NColumnsConditionalFormattingExampleSchema As NSchema

#End Region
    End Class
End Namespace

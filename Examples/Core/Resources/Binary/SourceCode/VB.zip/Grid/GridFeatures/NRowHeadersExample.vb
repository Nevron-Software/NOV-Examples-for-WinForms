Imports Nevron.Nov.Grid
Imports Nevron.Nov.Editors
Imports Nevron.Nov.Dom
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.Grid
    Public Class NRowHeadersExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' Default constructor.
        ''' </summary>
        Public Sub New()
        End Sub
        ''' <summary>
        ''' Static constructor.
        ''' </summary>
        Shared Sub New()
            NRowHeadersExampleSchema = NSchema.Create(GetType(NRowHeadersExample), NExampleBase.NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            m_TableView = New NTableGridView()
            m_TableView.Grid.DataSource = NDummyDataSource.CreateCompanySalesDataSource()

            ' show the row headers
            m_TableView.Grid.RowHeaders.Visible = True
            Return m_TableView
        End Function
        Protected Overrides Function CreateExampleControls() As NWidget
            Dim stack As NStackPanel = New NStackPanel()

            ' create the row headers properties
            If True Then
                Dim rowHeadersStack As NStackPanel = New NStackPanel()

                Dim designer = NDesigner.GetDesigner(NRowHeaderCollection.NRowHeaderCollectionSchema)
                Dim editors = designer.CreatePropertyEditors(m_TableView.Grid.RowHeaders, NRowHeaderCollection.VisibleProperty, NRowHeaderCollection.ShowRowNumbersProperty, NRowHeaderCollection.ShowRowSymbolProperty)

                For i = 0 To editors.Count - 1
                    rowHeadersStack.Add(editors(i))
                Next

                Dim rowHeadersGroup As NGroupBox = New NGroupBox("Row Headers Properties", rowHeadersStack)
                stack.Add(New NUniSizeBoxGroup(rowHeadersGroup))
            End If

            ' create the grid properties
            If True Then
                Dim gridStack As NStackPanel = New NStackPanel()

                Dim editors = NDesigner.GetDesigner(m_TableView.Grid).CreatePropertyEditors(m_TableView.Grid, NGrid.FrozenRowsProperty, NGrid.IntegralVScrollProperty)

                For i = 0 To editors.Count - 1
                    gridStack.Add(editors(i))
                Next

                Dim gridGroup As NGroupBox = New NGroupBox("Grid Properties", gridStack)
                stack.Add(New NUniSizeBoxGroup(gridGroup))
            End If

            Return stack
        End Function
        Protected Overrides Function GetExampleDescription() As String
            Return "
<p>
    Demonstrates the row headers.
</p>
<p>
    Row headers are small button-like elements that you can use to select rows. 
    Besides for selection, row headers indicate the row state (e.g. current or editing status) and can be configured to show the row ordinal in the data source.
</p>
" End Function

#End Region

#Region "Fields"

        Private m_TableView As NTableGridView

#End Region

#Region "Schema"

        ''' <summary>
        ''' Schema associated with NRowHeadersExample.
        ''' </summary>
        Public Shared ReadOnly NRowHeadersExampleSchema As NSchema

#End Region
    End Class
End Namespace

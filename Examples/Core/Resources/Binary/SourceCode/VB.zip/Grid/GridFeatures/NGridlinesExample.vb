Imports Nevron.Nov.Grid
Imports Nevron.Nov.Editors
Imports Nevron.Nov.Dom
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.Grid
    Public Class NGridlinesExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' Default constructor.
        ''' </summary>
        Public Sub New()
        End Sub
        ''' <summary>
        ''' Static constructor.
        ''' </summary>
        Shared Sub New()
            NGridlinesExampleSchema = NSchema.Create(GetType(NGridlinesExample), NExampleBase.NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            m_GridView = New NTableGridView()
            m_GridView.Grid.DataSource = NDummyDataSource.CreateCompanySalesDataSource()
            Return m_GridView
        End Function
        Protected Overrides Function CreateExampleControls() As NWidget
            Dim stack As NStackPanel = New NStackPanel()

            ' default gridlines
            If True Then
                Dim pstack As NStackPanel = New NStackPanel()
                pstack.VerticalSpacing = 2

                Dim editors = NDesigner.GetDesigner(m_GridView.Grid).CreatePropertyEditors(m_GridView.Grid, NGrid.HorizontalGridlinesStrokeProperty, NGrid.VerticalGridlinesStrokeProperty)

                For i = 0 To editors.Count - 1
                    pstack.Add(editors(i))
                Next

                stack.Add(New NGroupBox("Grid Gridlines", New NUniSizeBoxGroup(pstack)))
            End If

            ' column gridlines
            If True Then
                Dim pstack As NStackPanel = New NStackPanel()
                pstack.VerticalSpacing = 2

                Dim editors = NDesigner.GetDesigner(NColumnCollection.NColumnCollectionSchema).CreatePropertyEditors(m_GridView.Grid.Columns, NColumnCollection.VisibleProperty, NColumnCollection.TopGridlineStrokeProperty, NColumnCollection.BottomGridlineStrokeProperty, NColumnCollection.VerticalGridlinesStrokeProperty)

                For i = 0 To editors.Count - 1
                    pstack.Add(editors(i))
                Next

                stack.Add(New NGroupBox("Columns Properties", New NUniSizeBoxGroup(pstack)))
            End If

            ' row headers gridlines
            If True Then
                Dim pstack As NStackPanel = New NStackPanel()
                pstack.VerticalSpacing = 2

                Dim editors = NDesigner.GetDesigner(NRowHeaderCollection.NRowHeaderCollectionSchema).CreatePropertyEditors(m_GridView.Grid.RowHeaders, NRowHeaderCollection.VisibleProperty, NRowHeaderCollection.LeftGridlineStrokeProperty, NRowHeaderCollection.RightGridlineStrokeProperty, NRowHeaderCollection.HorizontalGridlinesStrokeProperty)

                For i = 0 To editors.Count - 1
                    pstack.Add(editors(i))
                Next

                stack.Add(New NGroupBox("Row Headers Properties", New NUniSizeBoxGroup(pstack)))
            End If


            Return stack
        End Function
        Protected Overrides Function GetExampleDescription() As String
            Return "
<p>
    Demonstrates gridlines.
</p>
<p>
    NOV Grid for .NET features several types of gridlines that are displayed by the Grid cells, Columns and Row Headers.
</p>
<p>
    Use the controls on the right to change the appearance of the gridlines.
</p>
" End Function

#End Region

#Region "Fields"

        Private m_GridView As NTableGridView

#End Region

#Region "Schema"

        ''' <summary>
        ''' Schema associated with NGridlinesExample.
        ''' </summary>
        Public Shared ReadOnly NGridlinesExampleSchema As NSchema

#End Region
    End Class
End Namespace

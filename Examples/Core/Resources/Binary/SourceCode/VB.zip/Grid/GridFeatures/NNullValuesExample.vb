Imports Nevron.Nov.Data
Imports Nevron.Nov.Dom
Imports Nevron.Nov.Grid
Imports Nevron.Nov.UI
Imports System

Namespace Nevron.Nov.Examples.Grid
    Public Class NNullValuesExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' Default constructor.
        ''' </summary>
        Public Sub New()
        End Sub
        ''' <summary>
        ''' Static constructor.
        ''' </summary>
        Shared Sub New()
            NNullValuesExampleSchema = NSchema.Create(GetType(NNullValuesExample), NExampleBase.NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            ' create a memory data table that supports null values
            Dim table As NMemoryDataTable = New NMemoryDataTable()
            table.AddField(New NFieldInfo("Name", GetType(String), True))
            table.AddField(New NFieldInfo("Birthday", GetType(Date), True))
            table.AddField(New NFieldInfo("Country", GetType(ENCountry), True))
            table.AddField(New NFieldInfo("Email", GetType(String), True))

            Dim rnd As Random = New Random()
            For i As Integer = 0 To NDummyDataSource.PersonInfos.Length - 1
                Dim personInfo As NDummyDataSource.NPersonInfo = NDummyDataSource.PersonInfos(i)

                Dim nullName = rnd.Next(8) = 1
                Dim nullBirthday = rnd.Next(8) = 2
                Dim nullCountry = rnd.Next(8) = 3
                Dim nullEmail = rnd.Next(8) = 4

                table.AddRow(If(nullName, Nothing, personInfo.Name), If(nullBirthday, Nothing, CObj(personInfo.Birthday)), If(nullCountry, Nothing, CObj(personInfo.Country)), If(nullEmail, Nothing, personInfo.Email))                  ' name
                ' birthday
                ' country
                ' email
            Next

            m_TableView = New NTableGridView()
            m_TableView.Grid.DataSource = New NDataSource(table)
            m_TableView.Grid.AllowEdit = True
            Return m_TableView
        End Function
        Protected Overrides Function CreateExampleControls() As NWidget
            Return Nothing
        End Function
        Protected Overrides Function GetExampleDescription() As String
            Return "
<p>
    Demonstrates the grid support for null values. Note that the grid also supports editing of null values. 
</p>
" End Function

#End Region

#Region "Fields"

        Private m_TableView As NTableGridView

#End Region

#Region "Schema"

        ''' <summary>
        ''' Schema associated with NNullValuesExample.
        ''' </summary>
        Public Shared ReadOnly NNullValuesExampleSchema As NSchema

#End Region
    End Class
End Namespace

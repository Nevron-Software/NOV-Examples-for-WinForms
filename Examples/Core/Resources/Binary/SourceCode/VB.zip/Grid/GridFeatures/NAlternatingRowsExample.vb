Imports Nevron.Nov.Dom
Imports Nevron.Nov.Editors
Imports Nevron.Nov.Grid
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.Grid
    Public Class NAlternatingRowsExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' Default constructor.
        ''' </summary>
        Public Sub New()
        End Sub
        ''' <summary>
        ''' Static constructor.
        ''' </summary>
        Shared Sub New()
            NAlternatingRowsExampleSchema = NSchema.Create(GetType(NAlternatingRowsExample), NExampleBase.NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            m_GridView = New NTableGridView()
            m_GridView.Grid.DataSource = NDummyDataSource.CreatePersonsOrdersDataSource()
            m_GridView.Grid.AlternatingRows = True
            Return m_GridView
        End Function
        Protected Overrides Function CreateExampleControls() As NWidget
            Dim stack As NStackPanel = New NStackPanel()

            Dim editors = NDesigner.GetDesigner(m_GridView.Grid).CreatePropertyEditors(m_GridView.Grid, NGrid.AlternatingRowsProperty, NGrid.AlternatingRowsIntervalProperty, NGrid.AlternatingRowsLengthProperty, NGrid.AlternatingRowBackgroundFillProperty)

            For i = 0 To editors.Count - 1
                stack.Add(editors(i))
            Next

            Return stack
        End Function
        Protected Overrides Function GetExampleDescription() As String
            Return "
<p>
    Demonstrates <b>Alternating Rows</b>.
</p>
<p>
    Use the controls on the right side to alter the properties that affect the <b>Alternating Rows</b> feature.
</p>
" End Function

#End Region

#Region "Fields"

        Private m_GridView As NTableGridView

#End Region

#Region "Schema"

        ''' <summary>
        ''' Schema associated with NAlternatingRowsExample.
        ''' </summary>
        Public Shared ReadOnly NAlternatingRowsExampleSchema As NSchema

#End Region
    End Class
End Namespace

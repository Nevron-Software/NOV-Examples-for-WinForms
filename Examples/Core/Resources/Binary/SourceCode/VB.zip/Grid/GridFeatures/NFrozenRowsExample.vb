Imports Nevron.Nov.Grid
Imports Nevron.Nov.Editors
Imports Nevron.Nov.Dom
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.Grid
    Public Class NFrozenRowsExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' Default constructor.
        ''' </summary>
        Public Sub New()
        End Sub
        ''' <summary>
        ''' Static constructor.
        ''' </summary>
        Shared Sub New()
            NFrozenRowsExampleSchema = NSchema.Create(GetType(NFrozenRowsExample), NExampleBase.NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            m_GridView = New NTableGridView()
            m_GridView.Grid.DataSource = NDummyDataSource.CreatePersonsOrdersDataSource()
            m_GridView.Grid.FrozenRows = 3
            Return m_GridView
        End Function

        Protected Overrides Function CreateExampleControls() As NWidget
            Dim pstack As NStackPanel = New NStackPanel()
            pstack.VerticalSpacing = 2
            Dim editors = NDesigner.GetDesigner(m_GridView.Grid).CreatePropertyEditors(m_GridView.Grid, NGrid.FrozenRowsProperty)

            For i = 0 To editors.Count - 1
                pstack.Add(editors(i))
            Next

            Return pstack
        End Function

        Protected Overrides Function GetExampleDescription() As String
            Return "
<p>
    Demonstrates <b>Frozen Rows</b>.
</p>
<p>
    Frozen rows are controlled by the <b>FrozenRows</b> grid property. 
    It specifies the count of rows from the top of the grid, that are non-scrollable. 
    Frozen rows are thus appearing pinned to the column headers.
</p>
"
        End Function

#End Region

#Region "Fields"

        Private m_GridView As NTableGridView

#End Region

#Region "Schema"

        ''' <summary>
        ''' Schema associated with NFrozenRowsExample.
        ''' </summary>
        Public Shared ReadOnly NFrozenRowsExampleSchema As NSchema

#End Region
    End Class
End Namespace

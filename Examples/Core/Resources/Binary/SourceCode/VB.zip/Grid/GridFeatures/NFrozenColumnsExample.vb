Imports System
Imports Nevron.Nov.Grid
Imports Nevron.Nov.Graphics
Imports Nevron.Nov.Dom
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.Grid
    Public Class NFrozenColumnsExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' Default constructor.
        ''' </summary>
        Public Sub New()
        End Sub
        ''' <summary>
        ''' Static constructor.
        ''' </summary>
        Shared Sub New()
            NFrozenColumnsExampleSchema = NSchema.Create(GetType(NFrozenColumnsExample), NExampleBase.NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            m_GridView = New NTableGridView()
            m_GridView.Grid.DataSource = NDummyDataSource.CreatePersonsOrdersDataSource()

            ' create a total column that is pinned to the right
            ' add an event calculated column of type Double
            Dim totalColumn As NCustomCalculatedColumn(Of Double) = New NCustomCalculatedColumn(Of Double)()
            totalColumn.Title = "Total"
            totalColumn.FreezeMode = ENColumnFreezeMode.Right
            totalColumn.GetRowValueDelegate += Function(ByVal arg As NCustomCalculatedColumnGetRowValueArgs(Of Double))
                                                   ' calculate a RowValue for the RowIndex
                                                   Dim price = Convert.ToDouble(arg.DataSource.GetValue(arg.RowIndex, "Price"))
                                                   Dim quantity = Convert.ToDouble(arg.DataSource.GetValue(arg.RowIndex, "Quantity"))
                                                   Return price * quantity
                                               End Function

            totalColumn.Format.BackgroundFill = New NColorFill(NColor.SeaShell)
            m_GridView.Grid.Columns.Add(totalColumn)

            ' freeze the pruduct name to the left
            Dim productNameColumn As NColumn = m_GridView.Grid.Columns.GetColumnByFieldName("Product Name")
            productNameColumn.Format.BackgroundFill = New NColorFill(NColor.SeaShell)
            productNameColumn.FreezeMode = ENColumnFreezeMode.Left
            Return m_GridView
        End Function

        Protected Overrides Function CreateExampleControls() As NWidget
            Dim pstack As NStackPanel = New NStackPanel()
            Return pstack
        End Function

        Protected Overrides Function GetExampleDescription() As String
            Return "
<p>
    Demonstrates <b>Frozen Columns</b>.
</p>
<p>
    Columns can be frozen to the left or right side of the grid window area.
    In this example the <b>Total</b> column is frozen to the right side, while the <b>Product Name</b> column is frozen to the left side.
</p>
"
        End Function

#End Region

#Region "Fields"

        Private m_GridView As NTableGridView

#End Region

#Region "Schema"

        ''' <summary>
        ''' Schema associated with NFrozenColumnsExample.
        ''' </summary>
        Public Shared ReadOnly NFrozenColumnsExampleSchema As NSchema

#End Region
    End Class
End Namespace

Imports Nevron.Nov.Grid
Imports Nevron.Nov.Editors
Imports Nevron.Nov.Data
Imports Nevron.Nov.Dom
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.Grid
    Public Class NScrollingExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' Default constructor.
        ''' </summary>
        Public Sub New()
        End Sub
        ''' <summary>
        ''' Static constructor.
        ''' </summary>
        Shared Sub New()
            NScrollingExampleSchema = NSchema.Create(GetType(NScrollingExample), NExampleBase.NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            m_TableView = New NTableGridView()

            ' create a dummy data source with many columns to demonstrate horizontal scrolling
            ' person info
            ' address info
            ' product info
            Dim dataTable As NMemoryDataTable = New NMemoryDataTable(New NFieldInfo() {New NFieldInfo("Name-0", GetType(String)), New NFieldInfo("Gender-1", GetType(ENGender)), New NFieldInfo("Birthday-2", GetType(Date)), New NFieldInfo("Phone-3", GetType(String)), New NFieldInfo("Email-4", GetType(String)), New NFieldInfo("Country-5", GetType(ENCountry)), New NFieldInfo("City-6", GetType(String)), New NFieldInfo("Address-7", GetType(String)), New NFieldInfo("Product Name-8", GetType(String)), New NFieldInfo("Product Price-9", GetType(Double)), New NFieldInfo("Product Quantity-10", GetType(Integer))})

            For i = 0 To 999
                Dim personInfo As NDummyDataSource.NPersonInfo = NDummyDataSource.RandomPersonInfo()
                Dim addressInfo As NDummyDataSource.NAddressInfo = NDummyDataSource.RandomAddressInfo()
                Dim productInfo As NDummyDataSource.NProductInfo = NDummyDataSource.RandomProductInfo()

                ' person info
                ' address
                ' product
                dataTable.AddRow(personInfo.Name, personInfo.Gender, personInfo.Birthday, personInfo.Phone, personInfo.Email, addressInfo.Country, addressInfo.City, addressInfo.Address, productInfo.Name, productInfo.Price, NDummyDataSource.RandomInt32(1, 100))
            Next

            m_TableView.Grid.DataSource = New NDataSource(dataTable)
            Return m_TableView
        End Function
        Protected Overrides Function CreateExampleControls() As NWidget
            Dim stack As NStackPanel = New NStackPanel()

            ' create the horizontal scrolling properties
            If True Then
                Dim hstack As NStackPanel = New NStackPanel()

                Dim designer = NDesigner.GetDesigner(NTableGrid.NTableGridSchema)
                Dim editors = designer.CreatePropertyEditors(m_TableView.Grid, NGrid.HScrollModeProperty, NGrid.IntegralHScrollProperty, NGrid.SmallHScrollChangeProperty)

                For i = 0 To editors.Count - 1
                    hstack.Add(editors(i))
                Next

                Dim hgroup As NGroupBox = New NGroupBox("Horizontal Scrolling", hstack)
                stack.Add(New NUniSizeBoxGroup(hgroup))
            End If

            ' create the vertical scrolling properties
            If True Then
                Dim vstack As NStackPanel = New NStackPanel()

                Dim designer = NDesigner.GetDesigner(NTableGrid.NTableGridSchema)
                Dim editors = designer.CreatePropertyEditors(m_TableView.Grid, NGrid.VScrollModeProperty, NGrid.IntegralVScrollProperty, NGrid.SmallVScrollChangeProperty)

                For i = 0 To editors.Count - 1
                    vstack.Add(editors(i))
                Next

                Dim vgroup As NGroupBox = New NGroupBox("Vertical Scrolling", vstack)
                stack.Add(New NUniSizeBoxGroup(vgroup))
            End If

            Return stack
        End Function
        Protected Overrides Function GetExampleDescription() As String
            Return "
<p>
    Demonstrates the properties that control the grid horizontal and vertical scrolling behavior.
</p>
<p>
    Note that the grid supports integral and pixel-wise scrolling in both the horizontal and vertical dimensions.
</p>
" End Function

#End Region

#Region "Fields"

        Private m_TableView As NTableGridView

#End Region

#Region "Schema"

        ''' <summary>
        ''' Schema associated with NScrollingExample.
        ''' </summary>
        Public Shared ReadOnly NScrollingExampleSchema As NSchema

#End Region
    End Class
End Namespace

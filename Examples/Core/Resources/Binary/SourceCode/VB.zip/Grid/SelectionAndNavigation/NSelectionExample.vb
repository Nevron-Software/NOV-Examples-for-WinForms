Imports Nevron.Nov.Dom
Imports Nevron.Nov.Editors
Imports Nevron.Nov.Grid
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.Grid
    Public Class NSelectionExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' Default constructor.
        ''' </summary>
        Public Sub New()
        End Sub
        ''' <summary>
        ''' Static constructor.
        ''' </summary>
        Shared Sub New()
            NSelectionExampleSchema = NSchema.Create(GetType(NSelectionExample), NExampleBase.NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            m_TableView = New NTableGridView()
            m_TableView.Grid.DataSource = NDummyDataSource.CreateCompanySalesDataSource()
            m_TableView.Grid.AllowEdit = True
            Return m_TableView
        End Function

        Protected Overrides Function CreateExampleControls() As NWidget
            Dim stack As NStackPanel = New NStackPanel()

            ' create the row headers properties
            If True Then
                Dim selectionStack As NStackPanel = New NStackPanel()
                Dim designer = NDesigner.GetDesigner(NGridSelection.NGridSelectionSchema)
                Dim editors = designer.CreatePropertyEditors(m_TableView.Grid.Selection, NGridSelection.ModeProperty, NGridSelection.AllowCurrentCellProperty, NGridSelection.BeginEditCellOnClickProperty, NGridSelection.BeginEditCellOnDoubleClickProperty, NGridSelection.BeginEditCellOnBecomeCurrentProperty)

                For i = 0 To editors.Count - 1
                    selectionStack.Add(editors(i))
                Next

                Dim selectionGroup As NGroupBox = New NGroupBox("Selection Properties", selectionStack)
                stack.Add(New NUniSizeBoxGroup(selectionGroup))
            End If

            Return stack
        End Function

        Protected Overrides Function GetExampleDescription() As String
            Return "
<p>
    Demonstrates the grid selection modes and various properties that affect the current cell and its editing behavior.
</p>
"
        End Function

#End Region

#Region "Fields"

        Private m_TableView As NTableGridView

#End Region

#Region "Schema"

        ''' <summary>
        ''' Schema associated with NSelectionExample.
        ''' </summary>
        Public Shared ReadOnly NSelectionExampleSchema As NSchema

#End Region
    End Class
End Namespace

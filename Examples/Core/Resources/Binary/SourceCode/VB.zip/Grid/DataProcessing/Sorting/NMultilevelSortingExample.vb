Imports Nevron.Nov.Dom
Imports Nevron.Nov.Grid
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.Grid
    Public Class NMultilevelSortingExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' Default constructor.
        ''' </summary>
        Public Sub New()
        End Sub
        ''' <summary>
        ''' Static constructor.
        ''' </summary>
        Shared Sub New()
            NMultilevelSortingExampleSchema = NSchema.Create(GetType(NMultilevelSortingExample), NExampleBase.NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            ' create a view and get its grid
            Dim view As NTableGridView = New NTableGridView()
            Dim grid = view.Grid

            ' bind the grid to the data source
            grid.DataSource = NDummyDataSource.CreateCompanySalesDataSource()

            ' create a sorting rule that sorts by the company column first
            Dim companyColumn As NColumn = grid.Columns.GetColumnByFieldName("Company")
            grid.SortingRules.Add(New NSortingRule(companyColumn, ENSortingDirection.Ascending))

            ' create a sorting rule that sorts by the sales column next
            Dim salesColumn As NColumn = grid.Columns.GetColumnByFieldName("Sales")
            grid.SortingRules.Add(New NSortingRule(salesColumn, ENSortingDirection.Ascending))

            Return view
        End Function
        Protected Overrides Function CreateExampleControls() As NWidget
            Return Nothing
        End Function
        Protected Overrides Function GetExampleDescription() As String
            Return "
<p>
    Demonstrates multilevel grid sorting by columns.
</p>
<p>
    In this example we have sorted in <b>Ascending</b> order first by the <b>Company</b> field and then by the <b>Sales</b> field.
</p>
" End Function

#End Region

#Region "Schema"

        ''' <summary>
        ''' Schema associated with NColumnSortingExample.
        ''' </summary>
        Public Shared ReadOnly NMultilevelSortingExampleSchema As NSchema

#End Region
    End Class
End Namespace

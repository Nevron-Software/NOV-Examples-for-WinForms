Imports System
Imports Nevron.Nov.Data
Imports Nevron.Nov.Dom
Imports Nevron.Nov.Grid
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.Grid
    Public Class NCustomGroupingExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' Default constructor.
        ''' </summary>
        Public Sub New()
        End Sub
        ''' <summary>
        ''' Static constructor.
        ''' </summary>
        Shared Sub New()
            NCustomGroupingExampleSchema = NSchema.Create(GetType(NCustomGroupingExample), NExampleBase.NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            ' store current date time
            m_Now = Date.Now

            ' create a view and get its grid
            Dim view As NTableGridView = New NTableGridView()
            Dim grid = view.Grid

            ' bind the grid to the data source
            grid.DataSource = CreateMailDataSource()

            ' create a grouping rule with a custom row value.
            ' NOTE: The RowValue associated with each grouping rule, returns an object for each row of the data source.
            ' the rows in the data source are grouped according to that object.
            ' The NCustomRowValue provides a delegate that help you return a custom object object for each data source row.
            ' In our example the NCustomRowValue returns a member of the ENMailGroup enumeraiton for each record, depending on its Received row value.
            Dim customRowValue As NCustomRowValue(Of ENMailGroup) = New NCustomRowValue(Of ENMailGroup)()
            customRowValue.Description = "Received"
            customRowValue.GetRowValueDelegate = AddressOf GetRowValueDelegate

            ' NOTE: The NGroupingRule provides the following events:
            ' CreateGroupRowCells - raised when the grid needs to create the cells of the group row.
            ' CreateGroupingHeaderContent - raised when the grid needs to create a grouping header content for the grouping in the groupings panel.
            Dim groupingRule As NGroupingRule = New NGroupingRule()
            groupingRule.RowValue = customRowValue
            groupingRule.CreateGroupRowCellsDelegate = Function(ByVal arg)
                                                           Dim groupValue = Convert.ToInt32(arg.GroupRow.GroupValue)
                                                           Dim text As String = NStringHelpers.InsertSpacesBeforeUppersAndDigits(CType(groupValue, ENMailGroup).ToString())
                                                           Return New NGroupRowCell() {New NGroupRowCell(text)}
                                                       End Function

            groupingRule.CreateGroupingHeaderContentDelegate = Function(ByVal theGroupingRule) New NLabel("Received")
            grid.GroupingRules.Add(groupingRule)
            Return view
        End Function

        Protected Overrides Function CreateExampleControls() As NWidget
            Return Nothing
        End Function

        Protected Overrides Function GetExampleDescription() As String
            Return "
<p>
    Demonstrates custom grouping, custom group header content and custom group row cells.
</p>
<p>
    In this example we are grouping fictional emails by the <b>Received</b> field. 
    However, since the condition for grouping is complex, we are using the <b>NCustomRowValue</b> to provide a custom row grouping condition.
</p>
<p>
    The example also demonstrates how to create custom GroupRow cells. Since the email group values are instances of the ENMailGroup enumeration, 
    the <b>CreateGroupRowCellsDelegate</b> is handled to provide a string representation for them.
</p>
<p>
    The example also demonstrates how to override the <b>CreateGroupingHeaderContentDelegate</b> to provide a custom grouping rule header content. 
    In example we have created, Received label serves as header content for the custom grouping rule.
</p>
"
        End Function

#End Region

#Region "Custom Row Value Provider Delegates"

        ''' <summary>
        ''' Delegate for getting a row value.
        ''' </summary>
        ''' <paramname="grid"></param>
        ''' <paramname="row"></param>
        ''' <returns></returns>
        Private Function GetRowValueDelegate(ByVal args As NCustomRowValueGetRowValueArgs(Of ENMailGroup)) As NNullable(Of ENMailGroup)
            Dim received As Date = args.DataSource.GetValue(args.Row, "Received")
            Dim dayOfWeek = m_Now.DayOfWeek
            Dim todayStart As Date = New DateTime(m_Now.Year, m_Now.Month, m_Now.Day, 0, 0, 0)
            Dim yesterdayStart As Date = todayStart - New TimeSpan(1, 0, 0, 0)

            ' today
            If received >= todayStart Then Return ENMailGroup.Today

            ' yesterday
            If received >= yesterdayStart AndAlso received < todayStart Then Return ENMailGroup.Yesterday

            ' check weeks
            If True Then
                Dim lastWeekEnd As Date = todayStart - New TimeSpan(dayOfWeek - 1, 0, 0, 0)

                If received < lastWeekEnd Then
                    Dim lastWeekStart As Date = lastWeekEnd - New TimeSpan(7, 0, 0, 0)
                    If received >= lastWeekStart AndAlso received < lastWeekEnd Then Return ENMailGroup.LastWeek
                    Dim twoWeekAgoStart As Date = lastWeekStart - New TimeSpan(7, 0, 0, 0)
                    If received >= twoWeekAgoStart AndAlso received < lastWeekStart Then Return ENMailGroup.TwoWeeksAgo
                    Dim threeWeeksAgoStart As Date = twoWeekAgoStart - New TimeSpan(7, 0, 0, 0)
                    If received >= threeWeeksAgoStart AndAlso received < twoWeekAgoStart Then Return ENMailGroup.ThreeWeeksAgo
                End If
            End If

            ' check days of week
            If True Then
                Dim dayOfWeekStart = todayStart
                Dim dayOfWeekEnd As Date = todayStart + New TimeSpan(24, 0, 0)

                While True

                    If received >= dayOfWeekStart AndAlso received < dayOfWeekEnd Then
                        Select Case dayOfWeek
                            Case DayOfWeek.Friday
                                Return ENMailGroup.Friday
                            Case DayOfWeek.Monday
                                Return ENMailGroup.Monday
                            Case DayOfWeek.Saturday
                                Return ENMailGroup.Saturday
                            Case DayOfWeek.Sunday
                                Return ENMailGroup.Sunday
                            Case DayOfWeek.Thursday
                                Return ENMailGroup.Thursday
                            Case DayOfWeek.Tuesday
                                Return ENMailGroup.Tuesday
                            Case DayOfWeek.Wednesday
                                Return ENMailGroup.Wednesday
                            Case Else
                                Throw New Exception("New DayOfWeek?")
                        End Select
                    End If

                    dayOfWeek = dayOfWeek - 1
                    dayOfWeekStart = dayOfWeekStart - New TimeSpan(24, 0, 0)
                    dayOfWeekEnd = dayOfWeekEnd - New TimeSpan(24, 0, 0)
                    If dayOfWeek = DayOfWeek.Sunday Then Exit While
                End While
            End If

            ' check months
            Dim lastMonthEnd As Date = New DateTime(m_Now.Year, m_Now.Month, 1, 0, 0, 0)
            Dim lastMonthStart = lastMonthEnd.AddMonths(-1)
            If received >= lastMonthStart AndAlso received < lastMonthEnd Then Return ENMailGroup.LastMonth
            Dim twoMonthsAgoStart As Date = lastMonthStart - New TimeSpan(7, 0, 0, 0)
            If received >= twoMonthsAgoStart AndAlso received < lastMonthStart Then Return ENMailGroup.TwoMonthsAgo
            Dim threeMonthsAgoStart As Date = twoMonthsAgoStart - New TimeSpan(7, 0, 0, 0)
            If received >= threeMonthsAgoStart AndAlso received < twoMonthsAgoStart Then Return ENMailGroup.ThreeMonthsAgo
            Return ENMailGroup.Older
        End Function

#End Region

#Region "Mail Data Source"

        ''' <summary>
        ''' Creates a fictional data source that represents received e-mails.
        ''' </summary>
        ''' <returns></returns>
        Private Function CreateMailDataSource() As NDataSource
            ' create a a dummy data table that represents a simple organization.
            Dim dataTable As NMemoryDataTable = New NMemoryDataTable(New NFieldInfo() {New NFieldInfo("From", GetType(String)), New NFieldInfo("Subject", GetType(String)), New NFieldInfo("Received", GetType(Date)), New NFieldInfo("Size", GetType(String))})
            Dim subjects = New String() {"VIVACOM BILL", "SharePoint Users", "USB Sticks", "Garden Conference", ".NET Core and .NET Native", "Hackers Attack", "Week in Review", "Big Data Analytics", "Encryption Compromise", "Grid Issues", "DSC SOT BILL", "Data Security Bulletin", "How Cybercriminals use Facebook", "Empowering Users Success", "Boost your Income", "The AMISH way to motivate", "Daily news"}
            Dim rnd As Random = New Random()

            For i = 0 To 600 - 1
                Dim name As String = NDummyDataSource.RandomPersonInfo().Name
                Dim subject = subjects(rnd.Next(subjects.Length))
                Dim received As Date = m_Now - New TimeSpan(rnd.Next(60), rnd.Next(24), rnd.Next(60), 0)
                Dim size As String = (10 + rnd.Next(100)).ToString() & " KB"
                dataTable.AddRow(name, subject, received, size)
            Next

            Return New NDataSource(dataTable)
        End Function

#End Region

#Region "Fields"

        Private m_Now As Date

#End Region

#Region "Schema"

        ''' <summary>
        ''' Schema associated with NCustomGroupingExample.
        ''' </summary>
        Public Shared ReadOnly NCustomGroupingExampleSchema As NSchema

#End Region

#Region "MailGroup"

        Public Enum ENMailGroup
            Today
            Yesterday
            Sunday
            Saturday
            Friday
            Thursday
            Wednesday
            Tuesday
            Monday
            LastWeek
            TwoWeeksAgo
            ThreeWeeksAgo
            LastMonth
            TwoMonthsAgo
            ThreeMonthsAgo
            Older
        End Enum


#End Region
    End Class
End Namespace

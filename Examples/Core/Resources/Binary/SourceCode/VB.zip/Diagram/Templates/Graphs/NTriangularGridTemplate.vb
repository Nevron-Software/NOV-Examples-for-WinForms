Imports System

Imports Nevron.Nov.DataStructures
Imports Nevron.Nov.Diagram
Imports Nevron.Nov.Diagram.Shapes
Imports Nevron.Nov.Graphics

Namespace Nevron.Nov.Examples.Diagram
    ''' <summary>
    ''' The NTriangularGridTemplate class represents a triangular grid template
    ''' </summary>
    Public Class NTriangularGridTemplate
        Inherits NGraphTemplate
#Region "Constructors"

        ''' <summary>
        ''' Default constructor
        ''' </summary>
        Public Sub New()
            MyBase.New("Triangular Grid")
            m_nLevels = 3
            m_bConnectGrid = True
        End Sub

#End Region

#Region "Properties"

        ''' <summary>
        ''' Gets or sets the levels count of the triangluar grid
        ''' </summary>
        ''' <remarks>
        ''' By default set to 3
        ''' </remarks>
        Public Property Levels As Integer
            Get
                Return m_nLevels
            End Get
            Set(ByVal value As Integer)
                If value = m_nLevels Then Return

                If value < 1 Then Throw New ArgumentOutOfRangeException("The value must be > 0.")

                m_nLevels = value
                OnTemplateChanged()
            End Set
        End Property

        ''' <summary>
        ''' Specifies whether the grid vertices are connected
        ''' </summary>
        ''' <remarks>
        ''' By default set to true
        ''' </remarks>
        Public Property ConnectGrid As Boolean
            Get
                Return m_bConnectGrid
            End Get
            Set(ByVal value As Boolean)
                If value = m_bConnectGrid Then Return

                m_bConnectGrid = value
                OnTemplateChanged()
            End Set
        End Property


#End Region

#Region "Overrides"

        ''' <summary>
        ''' Overriden to return the triangular grid description
        ''' </summary>
        Public Overrides Function GetDescription() As String
            Dim description = String.Format("##Triangular grid graph with {0} levels.", m_nLevels)

            If m_bConnectGrid Then description += " " & "##Each cell has two child cells and is connected with them as well as with the adjacent cells from the same level."

            Return description
        End Function

#End Region

#Region "Protected overrides"

        ''' <summary>
        ''' Overriden to create the triangular grid template in the specified document
        ''' </summary>
        ''' <paramname="document">document in which to create the template</param>
        Protected Overrides Sub CreateTemplate(ByVal document As NDrawingDocument)
            Dim page = document.Content.ActivePage
            Dim templateBounds As NRectangle = New NRectangle(m_Origin.X, m_Origin.Y, m_nLevels * m_VertexSize.Width + (m_nLevels - 1) * m_fHorizontalSpacing, m_nLevels * m_VertexSize.Height + (m_nLevels - 1) * m_fVerticalSpacing)
            Dim location As NPoint
            Dim cur As NShape = Nothing, prev As NShape = Nothing
            Dim edge As NShape = Nothing

            Dim curRowNodes As NList(Of NShape) = Nothing
            Dim prevRowNodes As NList(Of NShape) = Nothing

            For level = 1 To m_nLevels
                ' determine the location of the first node in the level
                location = New NPoint(templateBounds.X + (templateBounds.Width - level * m_VertexSize.Width - (level - 1) * m_fHorizontalSpacing) / 2, templateBounds.Y + (level - 1) * (m_VertexSize.Height + m_fVerticalSpacing))

                curRowNodes = New NList(Of NShape)()
                For i = 0 To level - 1
                    cur = CreateVertex(m_VertexShape)
                    cur.SetBounds(New NRectangle(location, m_VertexSize))
                    page.Items.AddChild(cur)

                    location.X += m_VertexSize.Width + m_fHorizontalSpacing

                    ' connect the current node with its ancestors and prev node
                    If m_bConnectGrid = False Then Continue For

                    ' connect with prev
                    If i > 0 Then
                        edge = CreateEdge(ENConnectorShape.Line)
                        page.Items.AddChild(edge)

                        edge.GlueBeginToGeometryIntersection(prev)
                        edge.GlueEndToShape(cur)
                    End If

                    ' connect with ancestors
                    If level > 1 Then
                        If i < prevRowNodes.Count Then
                            edge = CreateEdge(ENConnectorShape.Line)
                            page.Items.AddChild(edge)

                            edge.GlueBeginToGeometryIntersection(prevRowNodes(i))
                            edge.GlueEndToShape(cur)
                        End If

                        If i > 0 Then
                            edge = CreateEdge(ENConnectorShape.Line)
                            page.Items.AddChild(edge)

                            edge.GlueBeginToGeometryIntersection(prevRowNodes(i - 1))
                            edge.GlueEndToShape(cur)
                        End If
                    End If

                    curRowNodes.Add(cur)
                    prev = cur
                Next

                prevRowNodes = curRowNodes
            Next
        End Sub


#End Region

#Region "Fields"

        Friend m_nLevels As Integer
        Friend m_bConnectGrid As Boolean

#End Region
    End Class
End Namespace

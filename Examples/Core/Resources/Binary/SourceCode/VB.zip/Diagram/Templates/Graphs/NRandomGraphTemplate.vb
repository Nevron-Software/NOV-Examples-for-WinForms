Imports System
Imports Nevron.Nov.Graphics
Imports Nevron.Nov.Layout
Imports Nevron.Nov.Diagram
Imports Nevron.Nov.Diagram.Layout
Imports Nevron.Nov.Diagram.Shapes
Imports Nevron.Nov.DataStructures

Namespace Nevron.Nov.Examples.Diagram
    ''' <summary>
    ''' Generates a connnected random graph.
    ''' </summary>
    Public Class NRandomGraphTemplate
        Inherits NGraphTemplate
#Region "Constructors"

        ''' <summary>
        ''' Default constructor.
        ''' </summary>
        Public Sub New()
            MyBase.New("Random Graph")
            m_nVertexCount = 10
            m_nEdgeCount = 15
            m_MinVerticesSize = m_VerticesSize
            m_MaxVerticesSize = m_VerticesSize
        End Sub

#End Region

#Region "Properties"

        ''' <summary>
        ''' The number of edges to generate.
        ''' </summary>
        Public Property EdgeCount As Integer
            Get
                Return m_nEdgeCount
            End Get
            Set(ByVal value As Integer)

                If m_nEdgeCount <> value Then
                    m_nEdgeCount = value
                    OnTemplateChanged()
                End If
            End Set
        End Property

        ''' <summary>
        ''' The number of vertices to generate.
        ''' </summary>
        Public Property VertexCount As Integer
            Get
                Return m_nVertexCount
            End Get
            Set(ByVal value As Integer)

                If m_nVertexCount <> value Then
                    m_nVertexCount = value
                    OnTemplateChanged()
                End If
            End Set
        End Property

        ''' <summary>
        ''' The minimal size of a vertex in the graph.
        ''' </summary>
        Public Property MinVerticesSize As NSize
            Get
                Return m_MinVerticesSize
            End Get
            Set(ByVal value As NSize)

                If m_MinVerticesSize <> value Then
                    If value.Width > m_MaxVerticesSize.Width OrElse value.Height > m_MaxVerticesSize.Height Then
                        Throw New ArgumentException("MinVerticesSize must be smaller than or equal to MaxVertexSize")
                    End If

                    m_MinVerticesSize = value
                    OnTemplateChanged()
                End If
            End Set
        End Property

        ''' <summary>
        ''' The maximal size of a vertex in the graph.
        ''' </summary>
        Public Property MaxVerticesSize As NSize
            Get
                Return m_MaxVerticesSize
            End Get
            Set(ByVal value As NSize)

                If m_MaxVerticesSize <> value Then
                    If value.Width < m_MinVerticesSize.Width OrElse value.Height < m_MinVerticesSize.Height Then
                        Throw New ArgumentException("MexVerticesSize must be greater than or equal to MinVerticesSize")
                    End If

                    m_MaxVerticesSize = value
                    OnTemplateChanged()
                End If
            End Set
        End Property

#End Region

#Region "Overrides"

        ''' <summary>
        ''' Overriden to provide a description of the template.
        ''' </summary>
        ''' <returns></returns>
        Public Overrides Function GetDescription() As String
            Return String.Format("##Generates a random graph with {0} vertices and {1} edges.", m_nVertexCount, m_nEdgeCount)
        End Function
        ''' <summary>
        ''' Overriden to create a random graph template in the specified document.
        ''' </summary>
        ''' <paramname="document">The document to create a graph in.</param>
        Protected Overrides Sub CreateTemplate(ByVal document As NDrawingDocument)
            If m_nEdgeCount < m_nVertexCount - 1 Then Throw New Exception("##The number of edges must be greater than or equal to the (number of vertices - 1) in order to generate a connected graph")
            If m_nEdgeCount > MaxEdgeCount(m_nVertexCount) Then Throw New Exception("##Too many edges wanted for the graph")
            Dim i As Integer
            Dim random As Random = New Random()
            Dim activePage = document.Content.ActivePage
            Dim vertices = New NShape(m_nVertexCount - 1) {}
            Dim edges = GetRandomMST(m_nVertexCount)
            Dim edgeInfo As NPointI
            Dim minSize As NSizeI = m_MinVerticesSize.Round()
            Dim maxSize As NSizeI = m_MaxVerticesSize.Round()
            maxSize.Width += 1
            maxSize.Height += 1

            ' Create the vertices
            For i = 0 To m_nVertexCount - 1
                vertices(i) = CreateVertex(m_VerticesShape)
                Dim width As Double = random.Next(minSize.Width, maxSize.Width)
                Dim height As Double = random.Next(minSize.Height, maxSize.Height)
                vertices(i).SetBounds(New NRectangle(0, 0, width, height))
                activePage.Items.AddChild(vertices(i))
            Next

            ' Generate the edges
            For i = m_nVertexCount - 1 To m_nEdgeCount - 1

                Do   ' Generate a new edge
                    edgeInfo = New NPointI(random.Next(m_nVertexCount), random.Next(m_nVertexCount))
                Loop While edgeInfo.X = edgeInfo.Y OrElse edges.Contains(edgeInfo) OrElse edges.Contains(New NPointI(edgeInfo.Y, edgeInfo.X))

                edges.Add(edgeInfo)
            Next

            ' Create the edges
            For i = 0 To m_nEdgeCount - 1
                edgeInfo = edges(i)
                Dim edge As NShape = CreateEdge(ENConnectorShape.RoutableConnector)
                activePage.Items.AddChild(edge)
                edge.GlueBeginToGeometryIntersection(vertices(edgeInfo.X))
                edge.GlueEndToShape(vertices(edgeInfo.Y))
            Next

            ' Apply a table layout to the generated graph
            Dim tableLayout As NTableFlowLayout = New NTableFlowLayout()
            tableLayout.MaxOrdinal = CInt(Math.Sqrt(m_nVertexCount)) + 1
            tableLayout.HorizontalSpacing = m_VerticesSize.Width / 5
            tableLayout.VerticalSpacing = m_VerticesSize.Width / 5
            Dim context As NDrawingLayoutContext = New NDrawingLayoutContext(document, activePage)
            tableLayout.Arrange(New NList(Of Object)(NArrayHelpers(Of NShape).CastAll(Of Object)(vertices)), context)
        End Sub

#End Region

#Region "Fields"

        Private m_nEdgeCount As Integer
        Private m_nVertexCount As Integer
        Private m_MinVerticesSize As NSize
        Private m_MaxVerticesSize As NSize

#End Region

#Region "Static"

        ''' <summary>
        ''' Returns the maximum number of edges for the specified number of vertices.
        ''' </summary>
        ''' <paramname="vertexCount"></param>
        ''' <returns></returns>
        Private Shared Function MaxEdgeCount(ByVal vertexCount As Integer) As Integer
            Return vertexCount * (vertexCount - 1) / 2
        End Function
        ''' <summary>
        ''' Creates a random minimum spannig tree (this ensures that the graph will be connected).
        ''' </summary>
        ''' <returns></returns>
        Private Shared Function GetRandomMST(ByVal vertexCount As Integer) As NList(Of NPointI)
            Dim i, v1, v2 As Integer
            Dim random As Random = New Random()
            Dim edges As NList(Of NPointI) = New NList(Of NPointI)()
            Dim usedVertices As NList(Of Integer) = New NList(Of Integer)()
            Dim unusedVertices As NList(Of Integer) = New NList(Of Integer)(vertexCount)

            For i = 0 To vertexCount - 1
                unusedVertices.Add(i)
            Next

            ' Determine the root
            v1 = random.Next(vertexCount)
            usedVertices.Add(v1)
            unusedVertices.RemoveAt(v1)

            For i = 1 To vertexCount - 1
                v1 = random.Next(usedVertices.Count)
                v2 = random.Next(unusedVertices.Count)
                edges.Add(New NPointI(usedVertices(v1), unusedVertices(v2)))
                usedVertices.Add(unusedVertices(v2))
                unusedVertices.RemoveAt(v2)
            Next

            Return edges
        End Function

#End Region
    End Class
End Namespace

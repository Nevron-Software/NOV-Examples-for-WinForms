Imports System

Imports Nevron.Nov.Diagram
Imports Nevron.Nov.Diagram.Shapes
Imports Nevron.Nov.Graphics

Namespace Nevron.Nov.Examples.Diagram
    ''' <summary>
    ''' The NFamilyTreeTemplate class represents a family tree template
    ''' </summary>
    Public Class NFamilyTreeTemplate
        Inherits NGraphTemplate
#Region "Constructors"

        ''' <summary>
        ''' Default constructor
        ''' </summary>
        Public Sub New()
            MyBase.New("Family Tree")
            m_nChildrenCount = 2
        End Sub


#End Region

#Region "Properties"

        ''' <summary>
        ''' Gets or sets the children count
        ''' </summary>
        ''' <remarks>
        ''' By default set to 2
        ''' </remarks>
        Public Property ChildrenCount As Integer
            Get
                Return m_nChildrenCount
            End Get
            Set(ByVal value As Integer)
                If value < 0 Then Throw New ArgumentOutOfRangeException("The value must be >= 0")

                m_nChildrenCount = value
                OnTemplateChanged()
            End Set
        End Property


#End Region

#Region "Overrides"

        ''' <summary>
        ''' Overriden to return the family tree description
        ''' </summary>
        Public Overrides Function GetDescription() As String
            Dim description As String = "##Family tree with two parents and " & m_nChildrenCount.ToString() & " " & If(m_nChildrenCount = 1, " child", " children") & "."
            Return description
        End Function

#End Region

#Region "Protected overrides"

        ''' <summary>
        ''' Overriden to create the family tree template
        ''' </summary>
        ''' <paramname="document">document in which to create the template</param>
        Protected Overrides Sub CreateTemplate(ByVal document As NDrawingDocument)
            Dim pt As NPoint
            Dim node As NShape
            Dim edge As NShape = Nothing
            Dim page = document.Content.ActivePage

            ' determine the elements dimensions
            Dim childrenWidth As Double = m_nChildrenCount * m_VertexSize.Width + (m_nChildrenCount - 1) * m_fHorizontalSpacing
            Dim parentsWidth As Double = m_VertexSize.Width * 2 + m_fHorizontalSpacing

            ' determine the template dimensions
            Dim templateWidth = Math.Max(childrenWidth, parentsWidth)
            Dim templateBounds As NRectangle = New NRectangle(m_Origin.X, m_Origin.Y, templateWidth, m_VertexSize.Height * 2 + m_fVerticalSpacing)
            Dim center As NPoint = templateBounds.Center

            ' create the parent nodes
            Dim father As NShape = CreateVertex(m_VertexShape)
            pt = New NPoint(center.X - (m_VertexSize.Width + m_fHorizontalSpacing / 2), templateBounds.Y)
            father.SetBounds(New NRectangle(pt, m_VertexSize))
            page.Items.AddChild(father)

            Dim mother As NShape = CreateVertex(m_VertexShape)
            pt = New NPoint(center.X + m_fHorizontalSpacing / 2, templateBounds.Y)
            mother.SetBounds(New NRectangle(pt, m_VertexSize))
            page.Items.AddChild(mother)

            ' create the children
            If m_nChildrenCount > 0 Then
                Dim childrenY As Double = templateBounds.Y + m_VertexSize.Height + m_fVerticalSpacing
                For i = 0 To m_nChildrenCount - 1
                    ' create the child
                    node = CreateVertex(m_VertexShape)
                    pt = New NPoint(i * (m_VertexSize.Width + m_fHorizontalSpacing), childrenY)
                    node.SetBounds(New NRectangle(pt, m_VertexSize))
                    page.Items.AddChild(node)

                    ' attach it to the parents
                    edge = CreateEdge(ENConnectorShape.BottomToTop1)
                    page.Items.AddChild(edge)

                    edge.GlueBeginToGeometryIntersection(father)
                    edge.GlueEndToShape(node)

                    edge = CreateEdge(ENConnectorShape.BottomToTop1)
                    page.Items.AddChild(edge)

                    edge.GlueBeginToGeometryIntersection(mother)
                    edge.GlueEndToShape(node)
                Next
            End If
        End Sub


#End Region

#Region "Fields"

        Friend m_nChildrenCount As Integer

#End Region
    End Class
End Namespace

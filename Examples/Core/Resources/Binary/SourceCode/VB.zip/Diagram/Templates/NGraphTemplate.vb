Imports System
Imports System.Globalization

Imports Nevron.Nov.Diagram
Imports Nevron.Nov.Diagram.Shapes
Imports Nevron.Nov.Graphics

Namespace Nevron.Nov.Examples.Diagram
    ''' <summary>
    ''' The NGraphTemplate class is a template, which serves as base class for all templates which create graph
    ''' </summary>
    ''' <remarks>
    ''' It enhances its base with the following features:
    ''' <listtype="bullet">
    ''' <item>
    ''' 		<term>Vertex style and Edge style attributes</term>
    ''' 		<description>Exposed by the VerticesUserClass and EdgesUserClass properties
    ''' 		</description>
    ''' 	</item>
    ''' <item>
    ''' 		<term>Control over the vertices shape and size</term>
    ''' 		<description>Exposed by the VerticesSize and VerticesShape properties
    ''' 		</description>
    ''' 	</item>
    ''' <item>
    ''' 		<term>Generic spacing control</term>
    ''' 		<description>Exposed by the HorizontalSpacing and VerticalSpacing properties
    ''' 		</description>
    ''' 	</item>
    ''' <item>
    ''' 		<term>Ability to create new vertices and edges which conform to the template settings</term>
    ''' 		<description>
    ''' 		Achieved with the help of the CreateLineGraphEdge and CreateGraphVertex methods.
    ''' 		</description>
    ''' 	</item>
    ''' 	</list>
    ''' </remarks>
    Public MustInherit Class NGraphTemplate
        Inherits NTemplate
#Region "Constructors"

        ''' <summary>
        ''' Default constructor.
        ''' </summary>
        Public Sub New()
            Initialize()
        End Sub
        ''' <summary>
        ''' Initializing constructor.
        ''' </summary>
        ''' <paramname="name">Template name.</param>
        Public Sub New(ByVal name As String)
            MyBase.New(name)
            Initialize()
        End Sub

        ''' <summary>
        ''' Static constructor.
        ''' </summary>
        Shared Sub New()
            CurrentEdgeIndex = 1
            CurrentVertexIndex = 1
        End Sub

#End Region

#Region "Properties"

        ''' <summary>
        ''' Gets or sets the size of the vertices constructed by this template.
        ''' </summary>
        Public Property VertexSize As NSize
            Get
                Return m_VertexSize
            End Get
            Set(ByVal value As NSize)
                If value Is m_VertexSize Then Return

                If value.Width <= 0 OrElse value.Height <= 0 Then Throw New ArgumentOutOfRangeException()

                m_VertexSize = value
                OnTemplateChanged()
            End Set
        End Property
        ''' <summary>
        ''' Gets or sets the shape of the vertices constructed by this template. By default set to
		''' <seecref="ENBasicShape.Rectangle"/>.
        ''' </summary>
        Public Property VertexShape As ENBasicShape
            Get
                Return m_VertexShape
            End Get
            Set(ByVal value As ENBasicShape)
                If m_VertexShape Is value Then Return

                m_VertexShape = value
                OnTemplateChanged()
            End Set
        End Property
        ''' <summary>
        ''' Gets or sets the horizontal spacing between vertices.
        ''' </summary>
        Public Property HorizontalSpacing As Double
            Get
                Return m_fHorizontalSpacing
            End Get
            Set(ByVal value As Double)
                If value = m_fHorizontalSpacing Then Return

                If value < 0 Then Throw New ArgumentOutOfRangeException()

                m_fHorizontalSpacing = value
                OnTemplateChanged()
            End Set
        End Property
        ''' <summary>
        ''' Gets or sets the vertical spacing between vertices.
        ''' </summary>
        Public Property VerticalSpacing As Double
            Get
                Return m_fVerticalSpacing
            End Get
            Set(ByVal value As Double)
                If value = m_fVerticalSpacing Then Return

                If value < 0 Then Throw New ArgumentOutOfRangeException()

                m_fVerticalSpacing = value
                OnTemplateChanged()
            End Set
        End Property
        ''' <summary>
        ''' Specifies the user class for vertices.
        ''' </summary>
        Public Property VerticesUserClass As String
            Get
                Return m_VertexUserClass
            End Get
            Set(ByVal value As String)
                If Equals(m_VertexUserClass, Nothing) Then Throw New ArgumentNullException()

                m_VertexUserClass = value
                OnTemplateChanged()
            End Set
        End Property
        ''' <summary>
        ''' Specifies the user class for edges.
        ''' </summary>
        Public Property EdgeUserClass As String
            Get
                Return m_EdgeUserClass
            End Get
            Set(ByVal value As String)
                If Equals(m_EdgeUserClass, Nothing) Then Throw New ArgumentNullException()

                m_EdgeUserClass = value
                OnTemplateChanged()
            End Set
        End Property

#End Region

#Region "Protected Overridable"

        ''' <summary>
        ''' Creates a new edge shape of the specified type.
        ''' </summary>
        ''' <paramname="type"></param>
        ''' <returns>A new edge shape.</returns> 
        Protected Overridable Function CreateEdge(ByVal type As ENConnectorShape) As NShape
            Dim connector = m_ConnectorShapes.CreateShape(type)
            connector.Name = m_sName & " Edge " & CurrentEdgeIndex.ToString(CultureInfo.InvariantCulture)
            connector.UserClass = m_EdgeUserClass
            CurrentEdgeIndex += 1

            Return connector
        End Function
        ''' <summary>
        ''' Creates a new vertex shape of the specified type.
        ''' </summary>
        ''' <paramname="shape">A predefined basic shape.</param>
        ''' <returns>A new vertex shape.</returns>
        Protected Overridable Function CreateVertex(ByVal shape As ENBasicShape) As NShape
            Dim vertex = m_BasicShapes.CreateShape(shape)
            vertex.Name = m_sName & " Vertex " & CurrentVertexIndex.ToString(CultureInfo.InvariantCulture)
            vertex.UserClass = m_VertexUserClass
            CurrentVertexIndex += 1

            Return vertex
        End Function

#End Region

#Region "Implementation"

        Private Sub Initialize()
            m_fHorizontalSpacing = 30
            m_fVerticalSpacing = 30

            m_VertexSize = New NSize(40, 40)
            m_VertexShape = ENBasicShape.Rectangle

            m_VertexUserClass = String.Empty
            m_EdgeUserClass = String.Empty

            m_BasicShapes = New NBasicShapeFactory()
            m_ConnectorShapes = New NConnectorShapeFactory()
        End Sub

#End Region

#Region "Fields"

        Friend m_fHorizontalSpacing As Double
        Friend m_fVerticalSpacing As Double

        Friend m_VertexSize As NSize
        Friend m_VertexShape As ENBasicShape

        Friend m_VertexUserClass As String
        Friend m_EdgeUserClass As String

        Private m_BasicShapes As NBasicShapeFactory
        Private m_ConnectorShapes As NConnectorShapeFactory

#End Region

#Region "Static Fields"

        Public Shared CurrentEdgeIndex As Long
        Public Shared CurrentVertexIndex As Long

#End Region
    End Class
End Namespace

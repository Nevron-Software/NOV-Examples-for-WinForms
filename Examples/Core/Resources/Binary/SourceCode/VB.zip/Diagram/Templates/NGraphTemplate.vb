Imports System
Imports System.Globalization
Imports Nevron.Nov.Graphics
Imports Nevron.Nov.Diagram
Imports Nevron.Nov.Diagram.Shapes

Namespace Nevron.Nov.Examples.Diagram
    ''' <summary>
    ''' The NGraphTemplate class is a template, which serves as base class for all templates which create graph
    ''' </summary>
    ''' <remarks>
    ''' It enhances its base with the following features:
    ''' <listtype="bullet">
    ''' <item>
    ''' 		<term>Vertex style and Edge style attributes</term>
    ''' 		<description>Exposed by the VerticesUserClass and EdgesUserClass properties
    ''' 		</description>
    ''' 	</item>
    ''' <item>
    ''' 		<term>Control over the vertices shape and size</term>
    ''' 		<description>Exposed by the VerticesSize and VerticesShape properties
    ''' 		</description>
    ''' 	</item>
    ''' <item>
    ''' 		<term>Generic spacing control</term>
    ''' 		<description>Exposed by the HorizontalSpacing and VerticalSpacing properties
    ''' 		</description>
    ''' 	</item>
    ''' <item>
    ''' 		<term>Ability to create new vertices and edges which conform to the template settings</term>
    ''' 		<description>
    ''' 		Achieved with the help of the CreateLineGraphEdge and CreateGraphVertex methods.
    ''' 		</description>
    ''' 	</item>
    ''' 	</list>
    ''' </remarks>
    Public MustInherit Class NGraphTemplate
        Inherits NTemplate
#Region "Constructors"

        ''' <summary>
        ''' Default constructor
        ''' </summary>
        Public Sub New()
            Initialize()
        End Sub
        ''' <summary>
        ''' Initializer constructor
        ''' </summary>
        ''' <paramname="name">template name</param>
        Public Sub New(ByVal name As String)
            MyBase.New(name)
            Initialize()
        End Sub
        ''' <summary>
        ''' Static constructor.
        ''' </summary>
        Shared Sub New()
            CurrentEdgeIndex = 1
            CurrentVertexIndex = 1
        End Sub

#End Region

#Region "Properties"

        ''' <summary>
        ''' Gets or sets the size of the vertices constructed by this template
        ''' </summary>
        Public Property VerticesSize As NSize
            Get
                Return m_VerticesSize
            End Get
            Set(ByVal value As NSize)
                If value = m_VerticesSize Then Return
                If value.Width <= 0 OrElse value.Height <= 0 Then Throw New ArgumentOutOfRangeException()
                m_VerticesSize = value
                OnTemplateChanged()
            End Set
        End Property

        ''' <summary>
        ''' Gets or sets the shape of the vertices constructed by this template
        ''' </summary>
        ''' <remarks>
        ''' By default set to Rectangle
        ''' </remarks>
        Public Property VerticesShape As ENBasicShape
            Get
                Return m_VerticesShape
            End Get
            Set(ByVal value As ENBasicShape)
                If m_VerticesShape = value Then Return
                m_VerticesShape = value
                OnTemplateChanged()
            End Set
        End Property
        ''' <summary>
        ''' Gets or sets the horizontal spacing between vertices
        ''' </summary>
        Public Property HorizontalSpacing As Double
            Get
                Return m_fHorizontalSpacing
            End Get
            Set(ByVal value As Double)
                If value = m_fHorizontalSpacing Then Return
                If value < 0 Then Throw New ArgumentOutOfRangeException()
                m_fHorizontalSpacing = value
                OnTemplateChanged()
            End Set
        End Property

        ''' <summary>
        ''' Gets or sets the vertical spacing between vertices
        ''' </summary>
        Public Property VerticalSpacing As Double
            Get
                Return m_fVerticalSpacing
            End Get
            Set(ByVal value As Double)
                If value = m_fVerticalSpacing Then Return
                If value < 0 Then Throw New ArgumentOutOfRangeException()
                m_fVerticalSpacing = value
                OnTemplateChanged()
            End Set
        End Property
        ''' <summary>
        ''' Specifies the default style applied to vertices
        ''' </summary>
        Public Property VerticesUserClass As String
            Get
                Return m_VerticesUserClass
            End Get
            Set(ByVal value As String)
                If Equals(m_VerticesUserClass, Nothing) Then Throw New ArgumentNullException()
                m_VerticesUserClass = value
                OnTemplateChanged()
            End Set
        End Property

        ''' <summary>
        ''' Specifies the default style applied to edges
        ''' </summary>
        Public Property EdgesUserClass As String
            Get
                Return m_EdgesUserClass
            End Get
            Set(ByVal value As String)
                If Equals(m_EdgesUserClass, Nothing) Then Throw New ArgumentNullException()
                m_EdgesUserClass = value
                OnTemplateChanged()
            End Set
        End Property

#End Region

#Region "Protected Overridable"

        ''' <summary>
        ''' Creates a new connector from the specified type
        ''' </summary>
        ''' <remarks>
        ''' The new connector style uses a copy of EdgesUserClass style
        ''' </remarks>
        ''' <paramname="type"></param>
        ''' <returns>new connector</returns> 
        Protected Overridable Function CreateEdge(ByVal type As ENConnectorShape) As NShape
            Dim factory As NConnectorShapeFactory = New NConnectorShapeFactory()
            Dim connector = factory.CreateShape(type)
            connector.Name = m_sName & " Edge " & CurrentEdgeIndex.ToString(CultureInfo.InvariantCulture)
            connector.UserClass = m_EdgesUserClass
            CurrentEdgeIndex += 1
            Return connector
        End Function
        ''' <summary>
        ''' Creates a new graph vertex with the specified predefined shape
        ''' </summary>
        ''' <remarks>
        ''' The new graph vertex style is a copy of the VerticesUserClass style
        ''' </remarks>
        ''' <paramname="shape">predefined shape</param>
        ''' <returns>new graph vertex</returns>
        Protected Overridable Function CreateVertex(ByVal shape As ENBasicShape) As NShape
            Dim vertex = m_ShapeFactory.CreateShape(shape)
            vertex.Name = m_sName & " Vertex " & CurrentVertexIndex.ToString(CultureInfo.InvariantCulture)
            vertex.UserClass = m_VerticesUserClass
            CurrentVertexIndex += 1
            Return vertex
        End Function

#End Region

#Region "Implementation"

        Private Sub Initialize()
            m_fHorizontalSpacing = 30
            m_fVerticalSpacing = 30
            m_VerticesSize = New NSize(40, 40)
            m_VerticesShape = ENBasicShape.Rectangle
            m_VerticesUserClass = ""
            m_EdgesUserClass = ""
            m_ShapeFactory = New NBasicShapeFactory()
        End Sub

#End Region

#Region "Fields"

        Friend m_fHorizontalSpacing As Double
        Friend m_fVerticalSpacing As Double
        Friend m_VerticesSize As NSize
        Friend m_VerticesShape As ENBasicShape
        Friend m_VerticesUserClass As String
        Friend m_EdgesUserClass As String
        Private m_ShapeFactory As NBasicShapeFactory

#End Region

#Region "Static Fields"

        Public Shared CurrentEdgeIndex As Long
        Public Shared CurrentVertexIndex As Long

#End Region
    End Class
End Namespace

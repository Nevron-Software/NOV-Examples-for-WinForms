Imports Nevron.Nov.Diagram
Imports Nevron.Nov.Diagram.Layout
Imports Nevron.Nov.Dom
Imports Nevron.Nov.Graphics
Imports Nevron.Nov.IO
Imports Nevron.Nov.Layout
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.Diagram
    Public Class NDecorativeShapesExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' Default constructor.
        ''' </summary>
        Public Sub New()

        End Sub

        ''' <summary>
        ''' Static constructor
        ''' </summary>
        Shared Sub New()
            NDecorativeShapesExampleSchema = NSchema.Create(GetType(NDecorativeShapesExample), NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            ' Create a simple drawing
            Dim drawingViewWithRibbon As NDrawingViewWithRibbon = New NDrawingViewWithRibbon()
            m_DrawingView = drawingViewWithRibbon.View

            m_DrawingView.Document.HistoryService.Pause()
            Try
                InitDiagram(m_DrawingView.Document)
            Finally
                m_DrawingView.Document.HistoryService.Resume()
            End Try

            Return drawingViewWithRibbon
        End Function
        Protected Overrides Function CreateExampleControls() As NWidget
            Return Nothing
        End Function
        Protected Overrides Function GetExampleDescription() As String
            Return "<p>This example shows the decorative shapes located in the ""General\Decorative Shapes.nlb"" shape library.</p>"
        End Function

        Private Sub InitDiagram(ByVal drawingDocument As NDrawingDocument)
            Const ShapeWidth As Double = 80
            Const ShapeHeight As Double = 60
            Dim drawing = drawingDocument.Content
            Dim activePage = drawing.ActivePage

            ' Hide grid and ports
            drawing.ScreenVisibility.ShowGrid = False
            drawing.ScreenVisibility.ShowPorts = False

            ' Load the library and create all shapes from it
            Dim libraryFile = NApplication.ResourcesFolder.GetFile(NPath.Current.Combine("ShapeLibraries", "General", "Decorative Shapes.nlb"))
            Call NLibraryDocument.FromFileAsync(libraryFile).[Then](Sub(libraryDocument)
                                                                        Dim library As NLibrary = libraryDocument.Content
                                                                        For i = 0 To library.Items.Count - 1
                                                                            Dim shape = library.CreateShape(i, ShapeWidth, ShapeHeight)
                                                                            shape.HorizontalPlacement = ENHorizontalPlacement.Center
                                                                            shape.VerticalPlacement = ENVerticalPlacement.Center
                                                                            shape.Text = shape.Name
                                                                            shape.MoveTextBlockBelowShape()
                                                                            activePage.Items.Add(shape)
                                                                        Next

                                                                        ' arrange them
                                                                        Dim shapes = activePage.GetShapes(False)
                                                                        Dim layoutContext As NLayoutContext = New NLayoutContext()
                                                                        layoutContext.BodyAdapter = New NShapeBodyAdapter(drawingDocument)
                                                                        layoutContext.GraphAdapter = New NShapeGraphAdapter()
                                                                        layoutContext.LayoutArea = activePage.Bounds

                                                                        Dim flowLayout As NTableFlowLayout = New NTableFlowLayout()
                                                                        flowLayout.HorizontalSpacing = 30
                                                                        flowLayout.VerticalSpacing = 50
                                                                        flowLayout.Direction = ENHVDirection.LeftToRight
                                                                        flowLayout.MaxOrdinal = 5
                                                                        flowLayout.Arrange(shapes.CastAll(Of Object)(), layoutContext)

                                                                        ' size page to content
                                                                        activePage.Layout.ContentPadding = New NMargins(40)
                                                                        activePage.SizeToContent()
                                                                    End Sub)
        End Sub

#End Region

#Region "Fields"

        Private m_DrawingView As NDrawingView

#End Region

#Region "Schema"

        ''' <summary>
        ''' Schema associated with NDecorativeShapesExample
        ''' </summary>
        Public Shared ReadOnly NDecorativeShapesExampleSchema As NSchema

#End Region
    End Class
End Namespace

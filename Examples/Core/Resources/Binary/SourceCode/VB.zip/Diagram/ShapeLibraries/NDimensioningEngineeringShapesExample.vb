Imports Nevron.Nov.Diagram
Imports Nevron.Nov.Dom
Imports Nevron.Nov.Graphics
Imports Nevron.Nov.IO
Imports Nevron.Nov.Layout
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.Diagram
    Public Class NDimensioningEngineeringShapesExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' Default constructor.
        ''' </summary>
        Public Sub New()
        End Sub

        ''' <summary>
        ''' Static constructor.
        ''' </summary>
        Shared Sub New()
            NDimensioningEngineeringShapesExampleSchema = NSchema.Create(GetType(NDimensioningEngineeringShapesExample), NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            ' Create a simple drawing
            Dim drawingViewWithRibbon As NDrawingViewWithRibbon = New NDrawingViewWithRibbon()
            m_DrawingView = drawingViewWithRibbon.View

            m_DrawingView.Document.HistoryService.Pause()
            Try
                InitDiagram(m_DrawingView.Document)
            Finally
                m_DrawingView.Document.HistoryService.Resume()
            End Try

            Return drawingViewWithRibbon
        End Function
        Protected Overrides Function CreateExampleControls() As NWidget
            Return Nothing
        End Function
        Protected Overrides Function GetExampleDescription() As String
            Return "<p>This example shows the dimensioning engineering shapes located in the ""General\Dimension - Engineering Shapes.nlb"" shape library.</p>"
        End Function

        Private Sub InitDiagram(ByVal drawingDocument As NDrawingDocument)
            Const ShapeWidth As Double = 90
            Const ShapeHeight As Double = 90
            Const XStep As Double = 150
            Const YStep As Double = 200

            Dim drawing = drawingDocument.Content
            Dim activePage = drawing.ActivePage

            ' Hide grid and ports
            drawing.ScreenVisibility.ShowGrid = False
            drawing.ScreenVisibility.ShowPorts = False

            ' Load the library and create all shapes from it
            Dim libraryFile = NApplication.ResourcesFolder.GetFile(NPath.Current.Combine("ShapeLibraries", "General", "Dimension - Engineering Shapes.nlb"))
            Call NLibraryDocument.FromFileAsync(libraryFile).[Then](Sub(libraryDocument)
                                                                        Dim library As NLibrary = libraryDocument.Content
                                                                        Dim x As Double = 0
                                                                        Dim y As Double = 0

                                                                        For i = 0 To library.Items.Count - 1
                                                                            Dim shape = library.CreateShape(i, ShapeWidth, ShapeHeight)
                                                                            shape.HorizontalPlacement = ENHorizontalPlacement.Center
                                                                            shape.VerticalPlacement = ENVerticalPlacement.Center
                                                                            shape.Tooltip = New NTooltip(shape.Name)
                                                                            activePage.Items.Add(shape)

                                                                            If shape.ShapeType Is ENShapeType.Shape1D Then
                                                                                Dim shapeType = CType(i, ENDimensioningEngineeringShapes)
                                                                                Select Case shapeType
                                                                                    Case ENDimensioningEngineeringShapes.VerticalBaseline, ENDimensioningEngineeringShapes.Vertical, ENDimensioningEngineeringShapes.VerticalOutside, ENDimensioningEngineeringShapes.OrdinateVertical, ENDimensioningEngineeringShapes.OrdinateVerticalMultiple
                                                                                        shape.SetBeginPoint(New NPoint(x + shape.Width, y + shape.Height))
                                                                                        shape.SetEndPoint(New NPoint(x + shape.Width, y))
                                                                                    Case ENDimensioningEngineeringShapes.OrdinateHorizontalMultiple, ENDimensioningEngineeringShapes.OrdinateHorizontal
                                                                                        shape.SetBeginPoint(New NPoint(x, y))
                                                                                        shape.SetEndPoint(New NPoint(x + shape.Width, y))
                                                                                    Case ENDimensioningEngineeringShapes.Radius, ENDimensioningEngineeringShapes.RadiusOutside, ENDimensioningEngineeringShapes.ArcRadius, ENDimensioningEngineeringShapes.Diameter, ENDimensioningEngineeringShapes.DiameterOutside
                                                                                        shape.SetBeginPoint(New NPoint(x, y + shape.Height / 2))
                                                                                        shape.SetEndPoint(New NPoint(x + shape.Width, y - shape.Height / 2))
                                                                                    Case ENDimensioningEngineeringShapes.AngleCenter, ENDimensioningEngineeringShapes.AngleEven, ENDimensioningEngineeringShapes.AngleOutside, ENDimensioningEngineeringShapes.AngleUneven
                                                                                        shape.SetBeginPoint(New NPoint(x, y + shape.Width / 2))
                                                                                        shape.SetEndPoint(New NPoint(x + shape.Width, y + shape.Width / 2))
                                                                                    Case Else
                                                                                        shape.SetBeginPoint(New NPoint(x, y))
                                                                                        shape.SetEndPoint(New NPoint(x + shape.Width, y + shape.Height))
                                                                                End Select
                                                                            Else
                                                                                shape.SetBounds(x, y, shape.Width, shape.Height)
                                                                                shape.LocPinY = 1
                                                                            End If

                                                                            x += XStep
                                                                            If x > activePage.Width Then
                                                                                x = 0
                                                                                y += YStep
                                                                            End If
                                                                        Next

                                                                        ' Size page to content
                                                                        activePage.Layout.ContentPadding = New NMargins(50)
                                                                        activePage.SizeToContent()
                                                                    End Sub)
        End Sub

#End Region

#Region "Fields"

        Private m_DrawingView As NDrawingView

#End Region

#Region "Schema"

        ''' <summary>
        ''' Schema associated with NDimensioningEngineeringShapesExample.
        ''' </summary>
        Public Shared ReadOnly NDimensioningEngineeringShapesExampleSchema As NSchema

#End Region

#Region "Nested Types"

        ''' <summary>
        ''' Enumerates the dimensioning engineering shapes.
        ''' </summary>
        Public Enum ENDimensioningEngineeringShapes
            ''' <summary>
            ''' Horizontal baseline
            ''' </summary>
            HorizontalBaseline
            ''' <summary>
            ''' Vertical baseline
            ''' </summary>
            VerticalBaseline
            ''' <summary>
            ''' Horizontal outside
            ''' </summary>
            HorizontalOutside
            ''' <summary>
            ''' Horizontal
            ''' </summary>
            Horizontal
            ''' <summary>
            ''' Vertical outside
            ''' </summary>
            VerticalOutside
            ''' <summary>
            ''' Vertical
            ''' </summary>
            Vertical
            ''' <summary>
            ''' Aligned out even
            ''' </summary>
            AlignedOutEven
            ''' <summary>
            ''' Aligned out uneven
            ''' </summary>
            AlignedOutUneven
            ''' <summary>
            ''' Aligned even
            ''' </summary>
            AlignedEven
            ''' <summary>
            ''' Aligned uneven
            ''' </summary>
            AlignedUneven
            ''' <summary>
            ''' Arc radius
            ''' </summary>
            ArcRadius
            ''' <summary>
            ''' Radius outside
            ''' </summary>
            RadiusOutside
            ''' <summary>
            ''' Radius
            ''' </summary>
            Radius
            ''' <summary>
            ''' Diameter
            ''' </summary>
            Diameter
            ''' <summary>
            ''' Diameter outside
            ''' </summary>
            DiameterOutside
            ''' <summary>
            ''' Angle center
            ''' </summary>
            AngleCenter
            ''' <summary>
            ''' Angle uneven
            ''' </summary>
            AngleUneven
            ''' <summary>
            ''' Angle even
            ''' </summary>
            AngleEven
            ''' <summary>
            ''' Angle outside
            ''' </summary>
            AngleOutside
            ''' <summary>
            ''' Ordinate horizontal
            ''' </summary>
            OrdinateHorizontal
            ''' <summary>
            ''' Ordinate vertical
            ''' </summary>
            OrdinateVertical
            ''' <summary>
            ''' Ordinate horizontal multiple
            ''' </summary>
            OrdinateHorizontalMultiple
            ''' <summary>
            ''' Ordinate vertical multiple
            ''' </summary>
            OrdinateVerticalMultiple
            ''' <summary>
            ''' Centerline
            ''' </summary>
            Centerline
            ''' <summary>
            ''' Room measure
            ''' </summary>
            RoomMeasure
        End Enum

#End Region
    End Class
End Namespace

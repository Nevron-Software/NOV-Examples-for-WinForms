Imports Nevron.Nov.Diagram
Imports Nevron.Nov.Diagram.Expressions
Imports Nevron.Nov.Dom
Imports Nevron.Nov.Graphics
Imports Nevron.Nov.IO
Imports Nevron.Nov.Layout
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.Diagram
    Public Class NAnnotationShapesExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' Default constructor.
        ''' </summary>
        Public Sub New()

        End Sub

        ''' <summary>
        ''' Static constructor.
        ''' </summary>
        Shared Sub New()
            NAnnotationShapesExampleSchema = NSchema.Create(GetType(NAnnotationShapesExample), NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            ' Create a simple drawing
            Dim drawingViewWithRibbon As NDrawingViewWithRibbon = New NDrawingViewWithRibbon()
            m_DrawingView = drawingViewWithRibbon.View

            m_DrawingView.Document.HistoryService.Pause()
            Try
                InitDiagram(m_DrawingView.Document)
            Finally
                m_DrawingView.Document.HistoryService.Resume()
            End Try

            Return drawingViewWithRibbon
        End Function
        Protected Overrides Function CreateExampleControls() As NWidget
            Return Nothing
        End Function
        Protected Overrides Function GetExampleDescription() As String
            Return "<p>This example shows the annotation shapes located in the ""General\Annotations.nlb"" shape library.</p>"
        End Function

        Private Sub InitDiagram(ByVal drawingDocument As NDrawingDocument)
            Const ShapeWidth As Double = 60
            Const ShapeHeight As Double = 60

            Dim drawing = drawingDocument.Content
            Dim activePage = drawing.ActivePage

            ' Hide grid and ports
            drawing.ScreenVisibility.ShowGrid = False
            drawing.ScreenVisibility.ShowPorts = False

            ' Load the library and create all shapes from it
            Dim libraryFile = NApplication.ResourcesFolder.GetFile(NPath.Current.Combine("ShapeLibraries", "General", "Annotations.nlb"))
            Call NLibraryDocument.FromFileAsync(libraryFile).[Then](Sub(libraryDocument)
                                                                        Dim library As NLibrary = libraryDocument.Content
                                                                        Dim row = 0, col = 0
                                                                        Dim cellWidth As Double = 0 ' 180;
                                                                        Dim cellHeight As Double = 150
                                                                        Dim is1D = False

                                                                        Dim i = 0

                                                                        While i < library.Items.Count
                                                                            Dim shape = library.CreateShape(i, ShapeWidth, ShapeHeight)

                                                                            Dim tempShape As NShape
                                                                            shape.HorizontalPlacement = ENHorizontalPlacement.Center
                                                                            shape.VerticalPlacement = ENVerticalPlacement.Center


                                                                            If i = CInt(ENAnnotationShape.Text) OrElse i = CInt(ENAnnotationShape.FiveRuledColumn) OrElse i = CInt(ENAnnotationShape.InfoLine) OrElse i = CInt(ENAnnotationShape.NorthArrow5) OrElse i = CInt(ENAnnotationShape.NoteSymbol) OrElse i = CInt(ENAnnotationShape.ReferenceTriangle) OrElse i = CInt(ENAnnotationShape.ReferenceRectangle) OrElse i = CInt(ENAnnotationShape.ReferenceHexagon) OrElse i = CInt(ENAnnotationShape.ReferenceCircle) OrElse i = CInt(ENAnnotationShape.ReferenceOval) Then
                                                                                Dim group As NGroup = New NGroup()

                                                                                group.Width = shape.Width
                                                                                group.Height = shape.Height
                                                                                If i = CInt(ENAnnotationShape.Text) Then
                                                                                    shape.PinX = 0
                                                                                    shape.SetFx(NShape.PinYProperty, "Height")
                                                                                Else
                                                                                    shape.SetFx(NShape.PinXProperty, "Width / 2")
                                                                                    shape.SetFx(NShape.PinYProperty, "Height / 2")
                                                                                End If

                                                                                group.TextBlock = New NTextBlock(shape.Name)

                                                                                shape.SetFx(NShape.WidthProperty, "$ParentSheet.Width")
                                                                                shape.SetFx(NShape.HeightProperty, "$ParentSheet.Height")
                                                                                MoveTextBelowShape(group)

                                                                                group.Shapes.Add(shape)
                                                                                activePage.Items.Add(group)
                                                                                tempShape = group
                                                                            Else
                                                                                If i <> CInt(ENAnnotationShape.Benchmark) Then
                                                                                    shape.Text = shape.Name
                                                                                    MoveTextBelowShape(shape)
                                                                                    If i = CInt(ENAnnotationShape.ReferenceCallout1) Then
                                                                                        shape.TextBlock.PinX = 40
                                                                                        shape.TextBlock.PinY = 10
                                                                                    End If
                                                                                    If i = CInt(ENAnnotationShape.ReferenceCallout2) Then
                                                                                        shape.TextBlock.Angle = New NAngle(0)
                                                                                        shape.TextBlock.PinY = 100
                                                                                    End If
                                                                                End If

                                                                                activePage.Items.Add(shape)
                                                                                tempShape = shape
                                                                            End If

                                                                            If col >= 5 Then
                                                                                row += 1
                                                                                col = 0
                                                                                cellWidth = 0
                                                                                is1D = False
                                                                            End If

                                                                            Dim widthGap = If(is1D, 150, 100)
                                                                            is1D = shape.ShapeType Is ENShapeType.Shape1D
                                                                            Dim beginPoint As NPoint = New NPoint(widthGap + cellWidth, 50 + row * cellHeight)
                                                                            If is1D Then
                                                                                Dim endPoint As NPoint = beginPoint + New NPoint(0, cellHeight - 60)
                                                                                If i = CInt(ENAnnotationShape.ReferenceCallout1) OrElse i = CInt(ENAnnotationShape.ReferenceCallout2) Then
                                                                                    tempShape.SetBeginPoint(beginPoint)
                                                                                    tempShape.SetEndPoint(endPoint)
                                                                                Else
                                                                                    tempShape.SetBeginPoint(endPoint)
                                                                                    tempShape.SetEndPoint(beginPoint)
                                                                                End If
                                                                            Else
                                                                                tempShape.SetBounds(beginPoint.X, beginPoint.Y, shape.Width, shape.Height)
                                                                            End If

                                                                            cellWidth += widthGap + tempShape.Width
                                                                            i += 1
                                                                            col += 1
                                                                        End While

                                                                        ' size page to content
                                                                        activePage.Layout.ContentPadding = New NMargins(40)
                                                                        activePage.SizeToContent()
                                                                    End Sub)
        End Sub
        Private Sub MoveTextBelowShape(ByVal shape As NShape)
            If shape.ShapeType Is ENShapeType.Shape2D Then
                shape.MoveTextBlockBelowShape()
                Return
            End If

            ' if the shape is 1D put the text block on the left part of the shape and rotate it on 90 degrees.
            Dim textBlock As NTextBlock = shape.GetTextBlock()
            textBlock.Padding = New NMargins(5, 0, 0, 0)
            textBlock.ResizeMode = ENTextBlockResizeMode.TextSize
            textBlock.PinX = shape.BeginX
            textBlock.SetFx(NShapeBlock.PinYProperty, New NShapeHeightFactorFx(0))
            textBlock.LocPinY = 0
            textBlock.Angle = New NAngle(90)
        End Sub

#End Region

#Region "Fields"

        Private m_DrawingView As NDrawingView

#End Region

#Region "Schema"

        ''' <summary>
        ''' Schema associated with NAnnotationShapesExample.
        ''' </summary>
        Public Shared ReadOnly NAnnotationShapesExampleSchema As NSchema

#End Region

#Region "Nested Types"

        ''' <summary>
        ''' Enumerates the annotation shapes.
        ''' </summary>
        Public Enum ENAnnotationShape
            ''' <summary>
            ''' Text
            ''' </summary>
            Text
            ''' <summary>
            ''' 5 ruled column
            ''' </summary>
            FiveRuledColumn
            ''' <summary>
            ''' Info line
            ''' </summary>
            InfoLine
            ''' <summary>
            ''' Break line
            ''' </summary>
            BreakLine
            ''' <summary>
            ''' Section 1
            ''' </summary>
            Section1
            ''' <summary>
            ''' Section 2
            ''' </summary>
            Section2
            ''' <summary>
            ''' Section 3
            ''' </summary>
            Section3
            ''' <summary>
            ''' Reference plane (site)
            ''' </summary>
            ReferencePlaneSite
            ''' <summary>
            ''' Reference plane 1
            ''' </summary>
            ReferencePlane1
            ''' <summary>
            ''' Reference plane 2
            ''' </summary>
            ReferencePlane2
            ''' <summary>
            ''' Benchmark
            ''' </summary>
            Benchmark
            ''' <summary>
            ''' Level
            ''' </summary>
            Level
            ''' <summary>
            ''' Datum
            ''' </summary>
            Datum
            ''' <summary>
            ''' Ceiling
            ''' </summary>
            Ceiling
            ''' <summary>
            ''' North arrow 1
            ''' </summary>
            NorthArrow1
            ''' <summary>
            ''' North arrow 2
            ''' </summary>
            NorthArrow2
            ''' <summary>
            ''' North arrow 3
            ''' </summary>
            NorthArrow3
            ''' <summary>
            ''' North arrow 4
            ''' </summary>
            NorthArrow4
            ''' <summary>
            ''' North arrow 5
            ''' </summary>
            NorthArrow5
            ''' <summary>
            ''' Revision cloud
            ''' </summary>
            RevisionCloud
            ''' <summary>
            ''' Scale symbol
            ''' </summary>
            ScaleSymbol
            ''' <summary>
            ''' Note symbol
            ''' </summary>
            NoteSymbol
            ''' <summary>
            ''' Reference triangle
            ''' </summary>
            ReferenceTriangle
            ''' <summary>
            ''' Reference rectangle
            ''' </summary>
            ReferenceRectangle
            ''' <summary>
            ''' Reference hexagon
            ''' </summary>
            ReferenceHexagon
            ''' <summary>
            ''' Reference oval
            ''' </summary>
            ReferenceOval
            ''' <summary>
            ''' Reference circle
            ''' </summary>
            ReferenceCircle
            ''' <summary>
            ''' Reference callout 1
            ''' </summary>
            ReferenceCallout1
            ''' <summary>
            ''' Reference callout 2
            ''' </summary>
            ReferenceCallout2
        End Enum

#End Region
    End Class
End Namespace

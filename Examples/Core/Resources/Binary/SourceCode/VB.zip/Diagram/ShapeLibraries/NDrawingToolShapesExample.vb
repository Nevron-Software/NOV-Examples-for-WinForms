Imports Nevron.Nov.Diagram
Imports Nevron.Nov.Diagram.Expressions
Imports Nevron.Nov.Dom
Imports Nevron.Nov.Graphics
Imports Nevron.Nov.IO
Imports Nevron.Nov.Layout
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.Diagram
    Public Class NDrawingToolShapesExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' Default constructor.
        ''' </summary>
        Public Sub New()

        End Sub

        ''' <summary>
        ''' Static constructor.
        ''' </summary>
        Shared Sub New()
            NDrawingToolShapesExampleSchema = NSchema.Create(GetType(NDrawingToolShapesExample), NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            ' Create a simple drawing
            Dim drawingViewWithRibbon As NDrawingViewWithRibbon = New NDrawingViewWithRibbon()
            m_DrawingView = drawingViewWithRibbon.View

            m_DrawingView.Document.HistoryService.Pause()
            Try
                InitDiagram(m_DrawingView.Document)
            Finally
                m_DrawingView.Document.HistoryService.Resume()
            End Try

            Return drawingViewWithRibbon
        End Function
        Protected Overrides Function CreateExampleControls() As NWidget
            Return Nothing
        End Function
        Protected Overrides Function GetExampleDescription() As String
            Return "<p>This example shows the drawing tool shapes located in the ""General\Drawing Tools.nlb"" shape library.</p>"
        End Function

        Private Sub InitDiagram(ByVal drawingDocument As NDrawingDocument)
            Const ShapeWidth As Double = 90
            Const ShapeHeight As Double = 90
            Const XStep As Double = 150
            Const YStep As Double = 200

            Dim drawing = drawingDocument.Content
            Dim activePage = drawing.ActivePage

            ' Hide grid and ports
            drawing.ScreenVisibility.ShowGrid = False
            drawing.ScreenVisibility.ShowPorts = False

            ' Load the library and create all shapes from it
            Dim libraryFile = NApplication.ResourcesFolder.GetFile(NPath.Current.Combine("ShapeLibraries", "General", "Drawing Tools.nlb"))
            Call NLibraryDocument.FromFileAsync(libraryFile).[Then](Sub(libraryDocument)
                                                                        Dim library As NLibrary = libraryDocument.Content
                                                                        Dim x As Double = 0
                                                                        Dim y As Double = 0

                                                                        For i = 0 To library.Items.Count - 1
                                                                            Dim shape = library.CreateShape(i, ShapeWidth, ShapeHeight)
                                                                            shape.HorizontalPlacement = ENHorizontalPlacement.Center
                                                                            shape.VerticalPlacement = ENVerticalPlacement.Center
                                                                            shape.Tooltip = New NTooltip(shape.Name)

                                                                            If i <> CInt(ENDrawingToolShapes.SectorNumeric) AndAlso i <> CInt(ENDrawingToolShapes.ArcNumeric) AndAlso i <> CInt(ENDrawingToolShapes.RightTriangle) Then
                                                                                shape.Text = shape.Name
                                                                                MoveTextBelowShape(shape)
                                                                            End If
                                                                            activePage.Items.Add(shape)

                                                                            If shape.ShapeType Is ENShapeType.Shape1D Then
                                                                                If i = CInt(ENDrawingToolShapes.CircleRadius) Then
                                                                                    shape.SetBeginPoint(New NPoint(x + shape.Width / 2, y))
                                                                                Else
                                                                                    shape.SetBeginPoint(New NPoint(x, y))
                                                                                End If

                                                                                Dim width = shape.Width

                                                                                If i = CInt(ENDrawingToolShapes.MultigonEdge) Then
                                                                                    width = 90
                                                                                ElseIf i = CInt(ENDrawingToolShapes.MultigonCenter) Then
                                                                                    width = 30
                                                                                End If

                                                                                shape.SetEndPoint(New NPoint(x + width, y + shape.Height))
                                                                            Else
                                                                                shape.SetBounds(x, y, shape.Width, shape.Height)
                                                                                shape.LocPinY = 1
                                                                            End If

                                                                            x += XStep
                                                                            If x > activePage.Width Then
                                                                                x = 0
                                                                                y += YStep
                                                                            End If
                                                                        Next

                                                                        ' size page to content
                                                                        activePage.Layout.ContentPadding = New NMargins(50)
                                                                        activePage.SizeToContent()
                                                                    End Sub)
        End Sub
        Private Sub MoveTextBelowShape(ByVal shape As NShape)
            If shape.ShapeType Is ENShapeType.Shape1D Then
                Dim textBlock = CType(shape.TextBlock, NTextBlock)
                textBlock.Padding = New NMargins(0, 5, 0, 0)
                textBlock.ResizeMode = ENTextBlockResizeMode.TextSize
                textBlock.SetFx(NShapeBlock.PinYProperty, New NShapeHeightFactorFx(1.0))
                textBlock.LocPinY = -2
            Else
                shape.MoveTextBlockBelowShape()
            End If
        End Sub

#End Region

#Region "Fields"

        Private m_DrawingView As NDrawingView

#End Region

#Region "Schema"

        ''' <summary>
        ''' Schema associated with NBasicShapesExample.
        ''' </summary>
        Public Shared ReadOnly NDrawingToolShapesExampleSchema As NSchema

#End Region

#Region "Nested Types"

        ''' <summary>
        ''' Drawing tool shapes.
        ''' </summary>
        Public Enum ENDrawingToolShapes
            ''' <summary>
            ''' Circle
            ''' </summary>
            Circle
            ''' <summary>
            ''' Circle diameter
            ''' </summary>
            CircleDiameter
            ''' <summary>
            ''' Circle radius
            ''' </summary>
            CircleRadius
            ''' <summary>
            ''' Circle 3 points
            ''' </summary>
            Circle3Points
            ''' <summary>
            ''' Arc 3 points
            ''' </summary>
            Arc3Points
            ''' <summary>
            ''' Circles
            ''' </summary>
            Circles
            ''' <summary>
            ''' Sector-graphical
            ''' </summary>
            SectorGraphical
            ''' <summary>
            ''' Arc-graphical
            ''' </summary>
            ArcGraphical
            ''' <summary>
            ''' Circle tangents
            ''' </summary>
            CircleTangents
            ''' <summary>
            ''' Sector numeric
            ''' </summary>
            SectorNumeric
            ''' <summary>
            ''' Arc numeric
            ''' </summary>
            ArcNumeric
            ''' <summary>
            ''' Arc tangents
            ''' </summary>
            ArcTangents
            ''' <summary>
            ''' Line with extensions
            ''' </summary>
            LineWithExtensions
            ''' <summary>
            ''' Circle tangent
            ''' </summary>
            CircleTangent
            ''' <summary>
            ''' Opposite tangent.
            ''' </summary>
            OppositeTangent
            ''' <summary>
            ''' Perpendicular angle
            ''' </summary>
            PerpendicularAngle
            ''' <summary>
            ''' Perpendicular lines
            ''' </summary>
            PerpendicularLines
            ''' <summary>
            ''' Triangle free
            ''' </summary>
            TriangleFree
            ''' <summary>
            ''' Right triangle
            ''' </summary>
            RightTriangle
            ''' <summary>
            ''' Right triangle 2
            ''' </summary>
            RightTriangle2
            ''' <summary>
            ''' Triangle base
            ''' </summary>
            TriangleBase
            ''' <summary>
            ''' Diagonal rectangle
            ''' </summary>
            DiagonalRectangle
            ''' <summary>
            ''' Rounded rectangle
            ''' </summary>
            RoundedRectangle
            ''' <summary>
            ''' Rectangle
            ''' </summary>
            Rectangle
            ''' <summary>
            ''' Chamfered rectangle
            ''' </summary>
            ChamferedRectangle
            ''' <summary>
            ''' Chamfered corner
            ''' </summary>
            ChamferedCorner
            ''' <summary>
            ''' Multigon edge
            ''' </summary>
            MultigonEdge
            ''' <summary>
            ''' Multigon center
            ''' </summary>
            MultigonCenter
        End Enum

#End Region
    End Class
End Namespace

Imports Nevron.Nov.Diagram
Imports Nevron.Nov.Dom
Imports Nevron.Nov.Graphics
Imports Nevron.Nov.IO
Imports Nevron.Nov.Layout
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.Diagram
    Public Class NSDLShapesExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' Default constructor.
        ''' </summary>
        Public Sub New()
        End Sub

        ''' <summary>
        ''' Static constructor.
        ''' </summary>
        Shared Sub New()
            NSDLShapesExampleSchema = NSchema.Create(GetType(NSDLShapesExample), NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            ' Create a simple drawing
            Dim drawingViewWithRibbon As NDrawingViewWithRibbon = New NDrawingViewWithRibbon()
            m_DrawingView = drawingViewWithRibbon.View

            m_DrawingView.Document.HistoryService.Pause()
            Try
                InitDiagram(m_DrawingView.Document)
            Finally
                m_DrawingView.Document.HistoryService.Resume()
            End Try

            Return drawingViewWithRibbon
        End Function
        Protected Overrides Function CreateExampleControls() As NWidget
            Return Nothing
        End Function
        Protected Overrides Function GetExampleDescription() As String
            Return "<p>This example shows the SDL shapes located in the ""Flowchart\SDL Diagram Shapes.nlb"" shape library.</p>"
        End Function

        Private Sub InitDiagram(ByVal drawingDocument As NDrawingDocument)
            Const ShapeWidth As Double = 80
            Const ShapeHeight As Double = 60
            Dim drawing = drawingDocument.Content
            Dim activePage = drawing.ActivePage

            ' Hide grid and ports
            drawing.ScreenVisibility.ShowGrid = False
            drawing.ScreenVisibility.ShowPorts = False

            ' Load the library and create all shapes from it
            Dim libraryFile = NApplication.ResourcesFolder.GetFile(NPath.Current.Combine("ShapeLibraries", "Flowchart", "SDL Diagram Shapes.nlb"))
            Call NLibraryDocument.FromFileAsync(libraryFile).[Then](Sub(libraryDocument)
                                                                        Dim library As NLibrary = libraryDocument.Content
                                                                        Dim row = 0, col = 0
                                                                        Dim cellWidth As Double = 180
                                                                        Dim cellHeight As Double = 120

                                                                        Dim i = 0

                                                                        While i < library.Items.Count
                                                                            Dim shape = library.CreateShape(i, ShapeWidth, ShapeHeight)
                                                                            shape.HorizontalPlacement = ENHorizontalPlacement.Center
                                                                            shape.VerticalPlacement = ENVerticalPlacement.Center
                                                                            shape.Text = shape.Name
                                                                            shape.MoveTextBlockBelowShape()
                                                                            activePage.Items.Add(shape)

                                                                            If col >= 5 Then
                                                                                row += 1
                                                                                col = 0
                                                                            End If

                                                                            Dim beginPoint As NPoint = New NPoint(50 + col * cellWidth, 50 + row * cellHeight)
                                                                            If shape.ShapeType Is ENShapeType.Shape1D Then
                                                                                Dim endPoint As NPoint = beginPoint + New NPoint(cellWidth - 100, cellHeight - 100)
                                                                                shape.SetBeginPoint(beginPoint)
                                                                                shape.SetEndPoint(endPoint)
                                                                            Else
                                                                                shape.SetBounds(beginPoint.X, beginPoint.Y, shape.Width, shape.Height)
                                                                            End If

                                                                            i += 1
                                                                            col += 1
                                                                        End While

                                                                        ' size page to content
                                                                        activePage.Layout.ContentPadding = New NMargins(40)
                                                                        activePage.SizeToContent()
                                                                    End Sub)
        End Sub

#End Region

#Region "Fields"

        Private m_DrawingView As NDrawingView

#End Region

#Region "Schema"

        ''' <summary>
        ''' Schema associated with NSDLShapesExample.
        ''' </summary>
        Public Shared ReadOnly NSDLShapesExampleSchema As NSchema

#End Region
    End Class
End Namespace

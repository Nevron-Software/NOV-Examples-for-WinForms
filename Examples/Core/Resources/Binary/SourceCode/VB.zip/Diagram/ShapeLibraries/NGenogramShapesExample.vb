Imports Nevron.Nov.Diagram
Imports Nevron.Nov.Dom
Imports Nevron.Nov.Graphics
Imports Nevron.Nov.IO
Imports Nevron.Nov.Layout
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.Diagram
    Public Class NGenogramShapesExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' Default constructor.
        ''' </summary>
        Public Sub New()

        End Sub

        ''' <summary>
        ''' Static constructor
        ''' </summary>
        Shared Sub New()
            NGenogramShapesExampleSchema = NSchema.Create(GetType(NGenogramShapesExample), NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            ' Create a simple drawing
            Dim drawingViewWithRibbon As NDrawingViewWithRibbon = New NDrawingViewWithRibbon()
            m_DrawingView = drawingViewWithRibbon.View

            m_DrawingView.Document.HistoryService.Pause()
            Try
                InitDiagram(m_DrawingView.Document)
            Finally
                m_DrawingView.Document.HistoryService.Resume()
            End Try

            Return drawingViewWithRibbon
        End Function
        Protected Overrides Function CreateExampleControls() As NWidget
            Return Nothing
        End Function
        Protected Overrides Function GetExampleDescription() As String
            Return "<p>This example shows the genogram shapes located in the ""Family Tree\Genogram Shapes.nlb"" shape library.</p>"
        End Function

        Private Sub InitDiagram(ByVal drawingDocument As NDrawingDocument)
            Dim drawing = drawingDocument.Content
            Dim activePage = drawing.ActivePage

            ' Hide grid and ports
            drawing.ScreenVisibility.ShowGrid = False
            drawing.ScreenVisibility.ShowPorts = False

            ' Load the library and create all shapes from it
            Dim libraryFile = NApplication.ResourcesFolder.GetFile(NPath.Current.Combine("ShapeLibraries", "Family Tree", "Genogram Shapes.nlb"))
            Call NLibraryDocument.FromFileAsync(libraryFile).[Then](Sub(libraryDocument)
                                                                        Dim library As NLibrary = libraryDocument.Content
                                                                        Dim row = 0, col = 0
                                                                        Dim cellWidth As Double = 240
                                                                        Dim cellHeight As Double = 150

                                                                        Dim i = 0

                                                                        While i < library.Items.Count
                                                                            Dim shape = library.CreateShape(i)
                                                                            shape.HorizontalPlacement = ENHorizontalPlacement.Center
                                                                            shape.VerticalPlacement = ENVerticalPlacement.Center

                                                                            Dim textBlock As NTextBlock = shape.GetFirstDescendant(Of NTextBlock)()

                                                                            If textBlock Is Nothing OrElse i = CInt(ENGenogramShape.Male) OrElse i = CInt(ENGenogramShape.Female) OrElse i = CInt(ENGenogramShape.Pet) OrElse i = CInt(ENGenogramShape.UnknownGender) Then
                                                                                textBlock = CType(shape.TextBlock, NTextBlock)
                                                                            End If

                                                                            textBlock.Text = shape.Name

                                                                            activePage.Items.Add(shape)

                                                                            If col >= 4 Then
                                                                                row += 1
                                                                                col = 0
                                                                            End If

                                                                            Dim beginPoint As NPoint = New NPoint(50 + col * cellWidth, 50 + row * cellHeight)
                                                                            If shape.ShapeType Is ENShapeType.Shape1D Then
                                                                                Dim endPoint As NPoint = beginPoint + New NPoint(cellWidth - 50, cellHeight - 50)

                                                                                shape.SetBeginPoint(beginPoint)
                                                                                shape.SetEndPoint(endPoint)
                                                                            Else
                                                                                textBlock.SetFx(NShapeBlock.PinYProperty, "$Parent.Height + Height + 10")
                                                                                textBlock.ResizeMode = ENTextBlockResizeMode.TextSize
                                                                                shape.SetBounds(beginPoint.X, beginPoint.Y, shape.Width, shape.Height)
                                                                            End If

                                                                            i += 1
                                                                            col += 1
                                                                        End While

                                                                        ' size page to content
                                                                        activePage.Layout.ContentPadding = New NMargins(50)
                                                                        activePage.SizeToContent()
                                                                    End Sub)
        End Sub

#End Region

#Region "Fields"

        Private m_DrawingView As NDrawingView

#End Region

#Region "Schema"

        ''' <summary>
        ''' Schema associated with NGenogramShapesExample.
        ''' </summary>
        Public Shared ReadOnly NGenogramShapesExampleSchema As NSchema

#End Region

#Region "Nested Types"

        ''' <summary>
        ''' Enumerates the genogram shapes.
        ''' </summary>
        Public Enum ENGenogramShape
            ''' <summary>
            ''' Male.
            ''' </summary>
            Male
            ''' <summary>
            ''' Female.
            ''' </summary>
            Female
            ''' <summary>
            ''' Unknown.
            ''' </summary>
            UnknownGender
            ''' <summary>
            ''' Pet.
            ''' </summary>
            Pet
            ''' <summary>
            ''' Pregnancy
            ''' </summary>
            Pregnancy
            ''' <summary>
            ''' Marriage
            ''' </summary>
            Marriage
            ''' <summary>
            ''' Engagement
            ''' </summary>
            Engagement
            ''' <summary>
            ''' Engagement and separation
            ''' </summary>
            EngagementAndSeparation
            ''' <summary>
            ''' Engagement and cohabitation
            ''' </summary>
            EngagementAndCohabitation
            ''' <summary>
            ''' Commited
            ''' </summary>
            Commited
            ''' <summary>
            ''' Casual relationship
            ''' </summary>
            CasualRelationship
            ''' <summary>
            ''' Casual relationship and separation
            ''' </summary>
            CasualRelationshipAndSeparation
            ''' <summary>
            ''' Temporary relationship
            ''' </summary>
            TemporaryRelationship
            ''' <summary>
            ''' Love affair
            ''' </summary>
            LoveAffair
            ''' <summary>
            ''' Separation in fact.
            ''' </summary>
            SeparationInFact
            ''' <summary>
            ''' Legal separation
            ''' </summary>
            LegalSeparation
            ''' <summary>
            ''' Legal cohabitaion
            ''' </summary>
            LegalCohabitaion
            ''' <summary>
            ''' Legal cohabitaion and separation
            ''' </summary>
            LegalCohabitaionAndSeparation
            ''' <summary>
            ''' Cohabitaion
            ''' </summary>
            Cohabitaion
            ''' <summary>
            ''' Non-sentimental cohabitaion
            ''' </summary>
            NonSentimentalCohabitaion
            ''' <summary>
            ''' Non-sentimental cohabitaion and separation
            ''' </summary>
            NonSentimentalCohabitaionAndSeparation
            ''' <summary>
            ''' Cohabitaion and separation
            ''' </summary>
            CohabitaionAndSeparation
            ''' <summary>
            ''' Cohabitaion and legal separation
            ''' </summary>
            CohabitaionAndLegalSeparation
            ''' <summary>
            ''' Divorce
            ''' </summary>
            Divorce
            ''' <summary>
            ''' Nullity
            ''' </summary>
            Nullity
            ''' <summary>
            ''' Indifferent
            ''' </summary>
            Indifferent
            ''' <summary>
            ''' Distant
            ''' </summary>
            Distant
            ''' <summary>
            ''' Harmony
            ''' </summary>
            Harmony
            ''' <summary>
            ''' Friendship
            ''' </summary>
            Friendship
            ''' <summary>
            ''' Discord
            ''' </summary>
            Discord
            ''' <summary>
            ''' Hate
            ''' </summary>
            Hate
            ''' <summary>
            ''' Fused
            ''' </summary>
            Fused
            ''' <summary>
            ''' Cutoff
            ''' </summary>
            Cutoff
            ''' <summary>
            ''' Love
            ''' </summary>
            Love
            ''' <summary>
            ''' In Love
            ''' </summary>
            InLove
            ''' <summary>
            ''' Focused On
            ''' </summary>
            FocusedOn
            ''' <summary>
            ''' Fan
            ''' </summary>
            Fan
            ''' <summary>
            ''' Limerence
            ''' </summary>
            Limerence
            ''' <summary>
            ''' Neglect
            ''' </summary>
            Neglect
            ''' <summary>
            ''' Manipulative
            ''' </summary>
            Manipulative
            ''' <summary>
            ''' Controlling
            ''' </summary>
            Controlling
            ''' <summary>
            ''' Hostile
            ''' </summary>
            Hostile
            ''' <summary>
            ''' Distant - Hostile
            ''' </summary>
            DistantHostile
            ''' <summary>
            ''' Violence
            ''' </summary>
            Violence
            ''' <summary>
            ''' Distant - Violence
            ''' </summary>
            DistantViolence
            ''' <summary>
            ''' Abuse
            ''' </summary>
            Abuse
            ''' <summary>
            ''' Phisical abuse
            ''' </summary>
            PhisicalAbuse
            ''' <summary>
            ''' Emotional abuse
            ''' </summary>
            EmotionalAbuse
            ''' <summary>
            ''' Close - Hosile
            ''' </summary>
            CloseHostile
            ''' <summary>
            ''' Fused - Hostile
            ''' </summary>
            FusedHostile
            ''' <summary>
            ''' Close - Violence
            ''' </summary>
            CloseViolence
            ''' <summary>
            ''' Fused - Violence
            ''' </summary>
            FusedViolence
            ''' <summary>
            ''' Sexual Abuse
            ''' </summary>
            SexualAbuse
            ''' <summary>
            ''' BestFriends
            ''' </summary>
            BestFriends
            ''' <summary>
            ''' Distrust
            ''' </summary>
            Distrust
        End Enum

#End Region
    End Class
End Namespace

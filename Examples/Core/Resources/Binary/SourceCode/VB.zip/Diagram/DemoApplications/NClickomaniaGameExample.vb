Imports System

Imports Nevron.Nov.DataStructures
Imports Nevron.Nov.Diagram
Imports Nevron.Nov.Diagram.Themes
Imports Nevron.Nov.Dom
Imports Nevron.Nov.Graphics
Imports Nevron.Nov.Text
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.Diagram
    Public Class NClickomaniaGameExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' Default constructor.
        ''' </summary>
        Public Sub New()
        End Sub

        ''' <summary>
        ''' Static constructor.
        ''' </summary>
        Shared Sub New()
            NClickomaniaGameExampleSchema = NSchema.Create(GetType(NClickomaniaGameExample), NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            m_DrawingView = New NDrawingView()
            m_DrawingView.Document.HistoryService.Pause()

            ' hide grid and ports
            m_DrawingView.Content.ScreenVisibility.ShowGrid = False
            m_DrawingView.Content.ScreenVisibility.ShowPorts = False

            Dim styleSheet As NStyleSheet = CreateStyles()
            m_DrawingView.Document.StyleSheets.Add(styleSheet)

            Dim page = m_DrawingView.ActivePage

            page.Items.Add(CreateTitleShape("Clickomania"))
            page.Items.Add(CreateInfoShape())
            page.Items.Add(CreateBoardShape())

            page.SizeToContent()

            m_CellsToClear = New NList(Of NPointI)()
            m_Score = 0
            UpdateInfo()

            m_Timer = New NTimer(ClearCellsDelay)
            Me.m_Timer.Tick += AddressOf OnTimerTick

            Return m_DrawingView
        End Function
        Protected Overrides Function CreateExampleControls() As NWidget
            Return Nothing
        End Function
        Protected Overrides Function GetExampleDescription() As String
            Return "
<p>
	The example demonstrates how to use table blocks and how to handle events in NOV Diagram.
	We've implemented the popular Clickomania game using a table block and table cell
	mouse down events.
</p>
<p>
    Clickomania is a one-player game (puzzle) with the following rules. The board is a
    rectangular grid (this is where the table block support comes in handy). Initially the board
    is full of square blocks each colored one of k colors. A group is a collection of
    squares connected along edges that all have the same color. At any step, the player
    can click any group of size at least two. This move causes those blocks to disappear,
    and any blocks stacked above them fall straight down as far as they can. This falling
    is similar to Tetris, but each column falls independently. In particular, we never leave
    an internal hole. One final twist on the rules is that, if an entire column becomes empty
    of blocks, then the left and right components are slid together to remove the vertical hole. 
</p>" End Function

#End Region

#Region "Implementation - Shapes"

        ''' <summary>
        ''' Creates the cell styles.
        ''' </summary>
        ''' <returns></returns>
        Private Function CreateStyles() As NStyleSheet
            Dim styleSheet As NStyleSheet = New NStyleSheet()

            ' Create the default cell style
            If True Then
                Dim rule = styleSheet.CreateRule(Sub(sb) sb.Type(NTableCell.NTableCellSchema))

                rule.AddValueDeclaration(NTextElement.BackgroundFillProperty, New NColorFill(NColor.White))
                rule.AddValueDeclaration(NBlock.VerticalAlignmentProperty, ENVAlign.Center)
            End If

            ' Create the cell classes
            For i = 0 To CellClasses.Length - 1
                Dim className = CellClasses(i)
                Dim rule = styleSheet.CreateRule(Sub(sb)
                                                     sb.Type(NTableCell.NTableCellSchema)
                                                     sb.UserClass(className)
                                                 End Sub)

                Dim color = NColor.Parse(className)
                Dim gradient As NRadialGradientFill = New NRadialGradientFill()
                gradient.GradientStops.Add(New NGradientStop(0, color))
                gradient.GradientStops.Add(New NGradientStop(0.8, color.Darken()))
                gradient.GradientStops.Add(New NGradientStop(1, NColor.White))
                rule.AddValueDeclaration(NTextElement.BackgroundFillProperty, gradient)
            Next

            ' Add the highlighted cell classes
            If True Then
                Dim rule = styleSheet.CreateRule(Sub(sb)
                                                     sb.Type(NTableCell.NTableCellSchema)
                                                     sb.UserClass(HighlightedClassName)
                                                 End Sub)

                rule.AddValueDeclaration(NTextElement.BackgroundFillProperty, New NHatchFill(ENHatchStyle.DiagonalCross, NColor.DarkRed, NColor.White))
            End If

            Return styleSheet
        End Function

        ''' <summary>
        ''' Creates the Title shape.
        ''' </summary>
        ''' <paramname="title"></param>
        ''' <returns></returns>
        Private Function CreateTitleShape(ByVal title As String) As NShape
            Dim theme = NDrawingTheme.MyDrawNature

            Dim titleShape As NShape = New NShape()
            titleShape.SetBounds(0, 0, 500, 50)
            titleShape.Text = title
            titleShape.SetProtectionMask(ENDiagramItemOperationMask.All)

            Dim titleTextBlock = CType(titleShape.TextBlock, NTextBlock)
            titleTextBlock.ResizeMode = ENTextBlockResizeMode.ShapeSize
            titleTextBlock.FontSize = 28
            titleTextBlock.FontStyleBold = True

            ' Set theme-based colors to the title text, so that it changes when the user changes the theme
            Dim strokeColor = theme.ColorPalette.Variants(0)(0)
            strokeColor.Tag = New NThemeVariantColorInfo(0)
            titleTextBlock.Stroke = New NStroke(strokeColor)

            Dim fillColor = theme.ColorPalette.Variants(0)(4)
            fillColor.Tag = New NThemeVariantColorInfo(4)
            titleTextBlock.Fill = New NColorFill(fillColor)

            ' Alternatively, you can also use fixed colors (uncomment the 2 lines below)
            'titleTextBlock.Stroke = new NStroke(NColor.DarkBlue);
            'titleTextBlock.Fill = new NColorFill(NColor.LightBlue);

            ' Set an expression to center the title horizontally in the page
            titleShape.SetFx(NShape.PinXProperty, New NFormulaFx("$ParentSheet.X + $ParentSheet.Width / 2", True))

            Return titleShape
        End Function
        ''' <summary>
        ''' Creates the Board shape.
        ''' </summary>
        ''' <returns></returns>
        Private Function CreateBoardShape() As NShape
            Dim boardShape As NShape = New NShape()
            boardShape.SetBounds(200, 100, 600, 600)
            boardShape.SetProtectionMask(ENDiagramItemOperationMask.All)

            Dim tableBlock As NTableBlock = New NTableBlock()
            tableBlock.ResizeMode = ENTableBlockResizeMode.FitToShape
            tableBlock.PortsDistributionMode = ENPortsDistributionMode.None
            boardShape.TextBlock = tableBlock

            m_Table = New NTableBlockContent(BoardSize.Height, BoardSize.Width, NBorder.CreateFilledBorder(TableBorderColor), TableBorderThickness)
            m_Table.AllowSpacingBetweenCells = False
            tableBlock.Content = m_Table

            ' Create the cells
            Dim random As Random = New Random()
            For i = 0 To m_Table.Rows.Count - 1
                Dim row = m_Table.Rows(i)
                For j = 0 To m_Table.Columns.Count - 1
                    Dim cell = row.Cells(j)
                    cell.UserClass = CellClasses(random.Next(CellClasses.Length))
                    cell.MouseDown += AddressOf OnCellMouseDown
                Next
            Next

            Return boardShape
        End Function
        ''' <summary>
        ''' Creates the info shape.
        ''' </summary>
        ''' <returns></returns>
        Private Function CreateInfoShape() As NShape
            Dim infoShape As NShape = New NShape()
            infoShape.SetBounds(0, 240, 120, 240)
            infoShape.SetProtectionMask(ENDiagramItemOperationMask.All)

            Dim tableBlock As NTableBlock = New NTableBlock()
            tableBlock.ResizeMode = ENTableBlockResizeMode.FitToShape
            tableBlock.PortsDistributionMode = ENPortsDistributionMode.None
            infoShape.TextBlock = tableBlock

            m_InfoTable = New NTableBlockContent(CellClasses.Length + 2, 2, NBorder.CreateFilledBorder(TableBorderColor), TableBorderThickness)
            m_InfoTable.AllowSpacingBetweenCells = False
            m_InfoTable.FontSize = 16
            tableBlock.Content = m_InfoTable

            m_InfoTable.Columns(0).PreferredWidth = NMultiLength.NewFixed(40)

            m_InfoTable.Rows(0).Cells(0).Blocks(0) = New NParagraph("Cells:")
            m_InfoTable.Rows(0).Cells(0).ColSpan = 2

            For i = 0 To CellClasses.Length - 1
                m_InfoTable.Rows(i + 1).Cells(0).UserClass = CellClasses(i)
            Next

            m_InfoTable.Rows(CellClasses.Length + 1).Cells(0).Blocks(0) = New NParagraph("Score: 0")
            m_InfoTable.Rows(CellClasses.Length + 1).Cells(0).ColSpan = 2

            Return infoShape
        End Function

#End Region

#Region "Implementation - Game"

        ''' <summary>
        ''' Gets the UserClass of the cell at the given address.
        ''' </summary>
        ''' <paramname="x"></param>
        ''' <paramname="y"></param>
        ''' <returns></returns>
        Private Function GetCellClass(ByVal x As Integer, ByVal y As Integer) As String
            Return m_Table.Rows(y).Cells(x).UserClass
        End Function

        ''' <summary>
        ''' Checks if a column is empty from the given row index to the top.
        ''' </summary>
        ''' <paramname="x"></param>
        ''' <paramname="y"></param>
        ''' <returns></returns>
        Private Function IsEmptyToTop(ByVal x As Integer, ByVal y As Integer) As Boolean
            For i = y To 0 Step -1
                If Not String.IsNullOrEmpty(GetCellClass(x, i)) Then Return False
            Next

            Return True
        End Function
        ''' <summary>
        ''' Applies top to bottom and right to left gravity forces to the table.
        ''' </summary>
        Private Sub ApplyGravity()
            Dim i, j, z As Integer
            Dim rowCount = m_Table.Rows.Count
            Dim columnCount = m_Table.Columns.Count

            ' Top to bottom gravity force
            For j = 0 To columnCount - 1
                For i = rowCount - 1 To 1 Step -1
                    If String.IsNullOrEmpty(GetCellClass(j, i)) Then
                        ' Shift the column down by 1 cell
                        If IsEmptyToTop(j, i - 1) Then Exit For

                        For z = i To 1 Step -1
                            m_Table.Rows(z).Cells(j).UserClass = m_Table.Rows(z - 1).Cells(j).UserClass
                        Next

                        m_Table.Rows(0).Cells(j).ClearLocalValue(UserClassProperty)
                        i += 1
                    End If
                Next
            Next

            ' Right to left gravity force
            For j = columnCount - 2 To 0 Step -1
                If IsEmptyToTop(j, rowCount - 1) Then
                    ' Shift columns to the left
                    For i = 0 To rowCount - 1
                        For z = j To columnCount - 1 - 1
                            m_Table.Rows(i).Cells(z).UserClass = m_Table.Rows(i).Cells(z + 1).UserClass
                        Next

                        m_Table.Rows(i).Cells(z).ClearLocalValue(UserClassProperty)
                    Next
                End If
            Next
        End Sub
        ''' <summary>
        ''' Returns true if all cells are cleared.
        ''' </summary>
        ''' <returns></returns>
        Private Function AllClear() As Boolean
            Dim rowCount = m_Table.Rows.Count
            Dim columnCount = m_Table.Columns.Count

            For i = rowCount - 1 To 0 Step -1
                For j = 0 To columnCount - 1
                    If Not String.IsNullOrEmpty(GetCellClass(j, i)) Then Return False
                Next
            Next

            Return True
        End Function
        ''' <summary>
        ''' Returns true if there are no more regions to remove.
        ''' </summary>
        ''' <returns></returns>
        Private Function GameOver() As Boolean
            Dim rowCount = m_Table.Rows.Count
            Dim columnCount = m_Table.Columns.Count
            Dim cell As NTableCell

            For i = rowCount - 1 To 0 Step -1
                For j = 0 To columnCount - 1
                    cell = m_Table.Rows(i).Cells(j)
                    If Not String.IsNullOrEmpty(cell.UserClass) Then
                        If Test(j, i, cell.UserClass) Then Return False
                    End If
                Next
            Next

            Return True
        End Function

        ''' <summary>
        ''' Tests if a region of at least 2 cells with the same color is clicked.
        ''' </summary>
        ''' <paramname="x"></param>
        ''' <paramname="y"></param>
        ''' <paramname="color"></param>
        ''' <returns></returns>
        Private Function Test(ByVal x As Integer, ByVal y As Integer, ByVal color As String) As Boolean
            If x > 0 AndAlso Equals(GetCellClass(x - 1, y), color) Then Return True

            If x < m_Table.Columns.Count - 1 AndAlso Equals(GetCellClass(x + 1, y), color) Then Return True

            If y > 0 AndAlso Equals(GetCellClass(x, y - 1), color) Then Return True

            If y < m_Table.Rows.Count - 1 AndAlso Equals(GetCellClass(x, y + 1), color) Then Return True

            Return False
        End Function
        ''' <summary>
        ''' Accumulates all cells of the same color adjacent to the given cell.
        ''' </summary>
        ''' <paramname="x"></param>
        ''' <paramname="y"></param>
        ''' <paramname="color"></param>
        ''' <paramname="cellAddresses"></param>
        Private Sub HighlightCellsOfSameColor(ByVal x As Integer, ByVal y As Integer, ByVal color As String, ByVal cellAddresses As NList(Of NPointI))
            Dim address As NPointI = New NPointI(x, y)
            cellAddresses.AddNoDuplicates(address)
            m_Table.Rows(y).Cells(x).UserClass = HighlightedClassName

            If x > 0 AndAlso Equals(GetCellClass(x - 1, y), color) Then HighlightCellsOfSameColor(x - 1, y, color, cellAddresses)

            If x < m_Table.Columns.Count - 1 AndAlso Equals(GetCellClass(x + 1, y), color) Then HighlightCellsOfSameColor(x + 1, y, color, cellAddresses)

            If y > 0 AndAlso Equals(GetCellClass(x, y - 1), color) Then HighlightCellsOfSameColor(x, y - 1, color, cellAddresses)

            If y < m_Table.Rows.Count - 1 AndAlso Equals(GetCellClass(x, y + 1), color) Then HighlightCellsOfSameColor(x, y + 1, color, cellAddresses)
        End Sub

        ''' <summary>
        ''' Clears the given cells.
        ''' </summary>
        ''' <paramname="cellAddresses"></param>
        Private Sub ClearCells(ByVal cellAddresses As NList(Of NPointI))
            ' Clear the adjacent cells of the same color
            For i = 0 To cellAddresses.Count - 1
                m_Table.Rows(cellAddresses(i).Y).Cells(cellAddresses(i).X).ClearLocalValue(UserClassProperty)
            Next

            Dim n = cellAddresses.Count - 1
            m_Score += n * n

            ApplyGravity()

            Dim gameOver = False
            If AllClear() Then
                ' All cells were cleared
                m_Score *= 2
                gameOver = True
            ElseIf Me.GameOver() Then
                ' No more cells can be cleared
                gameOver = True
            End If

            UpdateInfo(gameOver)
        End Sub

        ''' <summary>
        ''' Updates the cells of the info table.
        ''' </summary>
        ''' <paramname="gameOver"></param>
        Private Sub UpdateInfo(ByVal Optional gameOver As Boolean = False)
            Dim rowCount = m_Table.Rows.Count
            Dim columnCount = m_Table.Columns.Count

            ' Update the cell count
            Dim cellCount = New Integer(CellClasses.Length - 1) {}
            For i = rowCount - 1 To 0 Step -1
                For j = 0 To columnCount - 1
                    Dim color = GetCellClass(j, i)
                    Dim index = Array.IndexOf(CellClasses, color)
                    If index <> -1 Then
                        cellCount(index) += 1
                    End If
                Next
            Next

            For i = 0 To cellCount.Length - 1
                m_InfoTable.Rows(i + 1).Cells(1).Blocks(0) = New NParagraph(cellCount(i).ToString())
            Next

            ' Update the score
            m_InfoTable.Rows(CellClasses.Length + 1).Cells(0).Blocks(0) = New NParagraph($"Score: {m_Score}")

            If gameOver Then
                Dim boardShape As NShape = m_Table.GetFirstAncestor(Of NShape)()

                Dim gameOverShape = CreateTitleShape("Game Over")
                gameOverShape.Geometry.AddRelative(New NDrawRectangle(0, 0, 1, 1))
                gameOverShape.Geometry.Fill = New NColorFill(New NColor(&HA0FFFFFFUI))
                gameOverShape.SetProtectionMask(ENDiagramItemOperationMask.All)

                boardShape.OwnerPage.Items.Add(gameOverShape)
                gameOverShape.PinX = boardShape.PinX
                gameOverShape.PinY = boardShape.PinY
            End If
        End Sub

#End Region

#Region "Event Handlers"

        Private Sub OnCellMouseDown(ByVal arg As NMouseButtonEventArgs)
            If m_CellsToClear.Count > 0 Then Return

            If arg.Cancel OrElse arg.Button IsNot ENMouseButtons.Left Then Return

            ' Get the clicked cell and mark the event as handled
            Dim cell = CType(arg.CurrentTargetNode, NTableCell)
            arg.Cancel = True

            If String.IsNullOrEmpty(cell.UserClass) Then Return

            Dim x As Integer = cell.Column.GetAggregationInfo().Index
            Dim y As Integer = cell.Row.GetAggregationInfo().Index
            If Not Test(x, y, cell.UserClass) Then Return

            ' Highlight the adjacent cells of same color
            HighlightCellsOfSameColor(x, y, cell.UserClass, m_CellsToClear)
            m_Timer.Start()
        End Sub

        Private Sub OnTimerTick()
            m_Timer.Stop()

            ClearCells(m_CellsToClear)

            m_CellsToClear.Clear()
        End Sub

#End Region

#Region "Fields"

        Private m_DrawingView As NDrawingView
        Private m_Table As NTableBlockContent
        Private m_InfoTable As NTableBlockContent
        Private m_CellsToClear As NList(Of NPointI)
        Private m_Score As Integer
        Private m_Timer As NTimer

#End Region

#Region "Schema"

        ''' <summary>
        ''' Schema associated with NClickomaniaGameExample.
        ''' </summary>
        Public Shared ReadOnly NClickomaniaGameExampleSchema As NSchema

#End Region

#Region "Constants"

        Private Shared ReadOnly BoardSize As NSizeI = New NSizeI(15, 15)
        Private Shared ReadOnly TableBorderColor As NColor = NColor.DimGray
        Private Shared ReadOnly TableBorderThickness As NMargins = New NMargins(1)

        Private Const ClearCellsDelay As Integer = 1000
        Private Const HighlightedClassName As String = "Highlighted"

        Private Shared ReadOnly CellClasses As String() = New String() {"Red", "Blue", "Green", "Gold"}

#End Region
    End Class
End Namespace

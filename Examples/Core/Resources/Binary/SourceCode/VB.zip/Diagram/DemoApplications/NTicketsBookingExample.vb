Imports System

Imports Nevron.Nov.Diagram
Imports Nevron.Nov.Diagram.Themes
Imports Nevron.Nov.Dom
Imports Nevron.Nov.Graphics
Imports Nevron.Nov.Text
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.Diagram
    Public Class NTicketsBookingExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' Default constructor.
        ''' </summary>
        Public Sub New()
        End Sub

        ''' <summary>
        ''' Static constructor.
        ''' </summary>
        Shared Sub New()
            NTicketsBookingExampleSchema = NSchema.Create(GetType(NTicketsBookingExample), NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            m_DrawingView = New NDrawingView()

            ' hide grid and ports
            m_DrawingView.Content.ScreenVisibility.ShowGrid = False
            m_DrawingView.Content.ScreenVisibility.ShowPorts = False

            ' no history for this example
            m_DrawingView.Document.HistoryService.Stop()

            ' create styling
            Dim styleSheet As NStyleSheet = CreateStyles()
            m_DrawingView.Document.StyleSheets.Add(styleSheet)

            Dim page = m_DrawingView.ActivePage

            m_FreeSeats = 0
            m_BookedSeats = 0

            page.Items.Add(CreateTitleShape("Tickets Booking"))
            page.Items.Add(CreateAirplaneShape())

            Dim infoShape As NGroup = CreateInfoShape()
            page.Items.Add(infoShape)
            UpdateTexts()
            infoShape.UpdateBounds()

            page.SizeToContent()

            Return m_DrawingView
        End Function
        Protected Overrides Function CreateExampleControls() As NWidget
            Return Nothing
        End Function
        Protected Overrides Function GetExampleDescription() As String
            Return "
<p>
	This example demonstrates how to create a tickets booking application using NOV Diagram for .NET. When the user clicks on a shape (seat)
    its user class is changed in order to mark it as booked. The example also demonstrates the usage of protections, which helps us
    prevent the user from moving, resizing and deleting of shapes thus leaving him the only possible interaction he should be allowed to do -
    to click on shapes.
</p>" End Function

#End Region

#Region "Implementation"

        ''' <summary>
        ''' 
        ''' </summary>
        ''' <returns></returns>
        Private Function CreateStyles() As NStyleSheet
            Dim styleSheet As NStyleSheet = New NStyleSheet()

            ' Create the free seats style
            If True Then
                ' Shape appearance
                Dim rule As NRule = styleSheet.CreateRule(Sub(sb)
                                                              sb.Type(NGeometry.NGeometrySchema)
                                                              sb.ChildOf()
                                                              sb.Type(NShape.NShapeSchema)
                                                              sb.UserClass(UserClassFree)
                                                          End Sub)

                rule.AddValueDeclaration(NGeometry.FillProperty, New NColorFill(NColor.LemonChiffon))

                ' Shape cursor
                rule = styleSheet.CreateRule(Sub(sb)
                                                 sb.Type(NShape.NShapeSchema)
                                                 sb.UserClass(UserClassFree)
                                             End Sub)

                rule.AddValueDeclaration(NInputElement.CursorProperty, New NCursor(ENPredefinedCursor.Hand))
            End If

            ' Create the booked seats style
            If True Then
                Dim rule As NRule = styleSheet.CreateRule(Sub(sb)
                                                              sb.Type(NGeometry.NGeometrySchema)
                                                              sb.ChildOf()
                                                              sb.Type(NShape.NShapeSchema)
                                                              sb.UserClass(UserClassBooked)
                                                          End Sub)

                rule.AddValueDeclaration(NGeometry.FillProperty, New NHatchFill(ENHatchStyle.LightUpwardDiagonal, NColor.DarkRed, NColor.LemonChiffon))
            End If

            Return styleSheet
        End Function
        ''' <summary>
        ''' Creates the Title shape.
        ''' </summary>
        ''' <paramname="title"></param>
        ''' <returns></returns>
        Private Function CreateTitleShape(ByVal title As String) As NShape
            Dim theme = NDrawingTheme.MyDrawNature

            Dim titleShape As NShape = New NShape()
            titleShape.SetBounds(0, 0, 500, 50)
            titleShape.Text = title
            titleShape.SetProtectionMask(ENDiagramItemOperationMask.All)

            Dim titleTextBlock = CType(titleShape.TextBlock, NTextBlock)
            titleTextBlock.ResizeMode = ENTextBlockResizeMode.ShapeSize
            titleTextBlock.FontSize = 28
            titleTextBlock.FontStyleBold = True

            ' Set theme-based colors to the title text, so that it changes when the user changes the theme
            Dim strokeColor = theme.ColorPalette.Variants(0)(0)
            strokeColor.Tag = New NThemeVariantColorInfo(0)
            titleTextBlock.Stroke = New NStroke(strokeColor)

            Dim fillColor = theme.ColorPalette.Variants(0)(4)
            fillColor.Tag = New NThemeVariantColorInfo(4)
            titleTextBlock.Fill = New NColorFill(fillColor)

            ' Alternatively, you can also use fixed colors (uncomment the 2 lines below)
            'titleTextBlock.Stroke = new NStroke(NColor.DarkBlue);
            'titleTextBlock.Fill = new NColorFill(NColor.LightBlue);

            ' Set an expression to center the title horizontally in the page
            titleShape.SetFx(NShape.PinXProperty, New NFormulaFx("$ParentSheet.X + $ParentSheet.Width / 2", True))

            Return titleShape
        End Function
        ''' <summary>
        ''' Creates the Airplane shape.
        ''' </summary>
        ''' <returns></returns>
        Private Function CreateAirplaneShape() As NGroup
            ' Constants
            Const SeatsDistance = 5.1
            Dim Line1Left As NPoint = New NPoint(300, 182)
            Dim Line1Right As NPoint = New NPoint(588, 182)
            Dim Line2Left As NPoint = New NPoint(292, 257)

            ' Get the airplane seats image from the resources
            Dim image As NImage = NResources.Image_Artistic_AirplaneSeats_png

            ' Create a group
            Dim group As NGroup = New NGroup()
            group.SetProtectionMask(ENDiagramItemOperationMask.All)
            group.SelectionMode = ENGroupSelectionMode.GroupOnly
            group.Geometry.AddRelative(New NDrawRectangle(0, 0, 1, 1))
            group.Geometry.Fill = New NImageFill(image)
            group.SetBounds(0, 100, image.Width, image.Height)

            ' Create the seat shapes
            Dim distance = SeatsDistance
            Dim startPoint = Line1Left

            Dim y = Line1Left.Y

            While y < 309
                If y > 223 AndAlso y < Line2Left.Y Then
                    y = Line2Left.Y
                    startPoint = Line2Left
                End If

                If y >= Line2Left.Y Then distance = 6.1

                Dim x = startPoint.X

                While x < 970
                    If x > 460 AndAlso x < Line1Right.X Then
                        x = Line1Right.X
                        distance = SeatsDistance
                    End If

                    m_FreeSeats += 1

                    Dim seatShape = CreateSeatShape(x, y)
                    seatShape.UserClass = UserClassFree
                    seatShape.MouseDown += AddressOf OnSeatShapeMouseDown
                    group.Shapes.Add(seatShape)
                    x += SeatWidth + distance
                End While

                y += SeatHeight
            End While

            Return group
        End Function
        Private Function CreateSeatShape(ByVal x As Double, ByVal y As Double) As NShape
            Dim seatShape As NShape = New NShape()
            seatShape.Geometry.AddRelative(New NDrawRectangle(0, 0, 1, 1))
            seatShape.SetBounds(x, y, SeatWidth, SeatHeight)

            Return seatShape
        End Function
        ''' <summary>
        ''' Creates the Info shape.
        ''' </summary>
        ''' <returns></returns>
        Private Function CreateInfoShape() As NGroup
            Dim infoGroup As NGroup = New NGroup()
            infoGroup.SetProtectionMask(ENDiagramItemOperationMask.All)
            infoGroup.SelectionMode = ENGroupSelectionMode.GroupOnly

            Dim freeSeatShape = CreateSeatShape(2, 2)
            freeSeatShape.UserClass = UserClassFree
            infoGroup.Shapes.Add(freeSeatShape)

            Dim bookedSeatShape = CreateSeatShape(2, 25)
            bookedSeatShape.UserClass = UserClassBooked
            infoGroup.Shapes.Add(bookedSeatShape)

            m_FreeSeatsShape = New NShape()
            m_FreeSeatsShape.SetBounds(30, 2, 150, 20)
            m_FreeSeatsShape.TextBlock.HorizontalAlignment = ENAlign.Left
            infoGroup.Shapes.Add(m_FreeSeatsShape)

            m_BookedSeatsShape = New NShape()
            m_BookedSeatsShape.SetBounds(30, 25, 150, 20)
            m_BookedSeatsShape.TextBlock.HorizontalAlignment = ENAlign.Left
            infoGroup.Shapes.Add(m_BookedSeatsShape)

            m_RevenueShape = New NShape()
            m_RevenueShape.SetBounds(30, 48, 200, 20)
            m_RevenueShape.TextBlock.HorizontalAlignment = ENAlign.Left
            m_RevenueShape.TextBlock.FontStyleBold = True
            m_RevenueShape.TextBlock.Fill = New NColorFill(NColor.MediumBlue)
            infoGroup.Shapes.Add(m_RevenueShape)

            Return infoGroup
        End Function
        ''' <summary>
        ''' 
        ''' </summary>
        Private Sub UpdateTexts()
            m_FreeSeatsShape.Text = String.Format(FormatStringFree, m_FreeSeats)
            m_BookedSeatsShape.Text = String.Format(FormatStringBooked, m_BookedSeats)
            m_RevenueShape.Text = String.Format(FormatStringRevenue, m_BookedSeats * SeatPrice)
        End Sub

#End Region

#Region "Event Handlers"

        Private Sub OnSeatShapeMouseDown(ByVal arg As NMouseButtonEventArgs)
            If arg.Cancel OrElse arg.Button IsNot ENMouseButtons.Left Then Return

            Dim shape = CType(arg.CurrentTargetNode, NShape)
            If Equals(shape.UserClass, UserClassFree) Then
                m_FreeSeats -= 1
                m_BookedSeats += 1
                shape.UserClass = UserClassBooked
            Else
                m_FreeSeats += 1
                m_BookedSeats -= 1
                shape.UserClass = UserClassFree
            End If

            UpdateTexts()
        End Sub

#End Region

#Region "Fields"

        Private m_DrawingView As NDrawingView
        Private m_FreeSeats As Integer
        Private m_BookedSeats As Integer

        Private m_FreeSeatsShape As NShape
        Private m_BookedSeatsShape As NShape
        Private m_RevenueShape As NShape

#End Region

#Region "Schema"

        ''' <summary>
        ''' Schema associated with NTicketsBookingExample.
        ''' </summary>
        Public Shared ReadOnly NTicketsBookingExampleSchema As NSchema

#End Region

#Region "Constants"

        Private Const SeatWidth As Double = 20
        Private Const SeatHeight As Double = 19
        Private Const SeatPrice As Double = 50

        Private Const UserClassFree As String = "FreeSeat"
        Private Const UserClassBooked As String = "BookedSeat"

        Private Const FormatStringFree As String = "Free seats: {0}"
        Private Const FormatStringBooked As String = "Booked seats: {0}"
        Private Const FormatStringRevenue As String = "Total revenue: {0:C0}"

#End Region
    End Class
End Namespace

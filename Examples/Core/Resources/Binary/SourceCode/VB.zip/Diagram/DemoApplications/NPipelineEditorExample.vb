Imports System

Imports Nevron.Nov.Diagram
Imports Nevron.Nov.Diagram.Themes
Imports Nevron.Nov.Dom
Imports Nevron.Nov.Graphics
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.Diagram
    Public Class NPipelineEditorExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' Default constructor.
        ''' </summary>
        Public Sub New()
        End Sub

        ''' <summary>
        ''' Static constructor.
        ''' </summary>
        Shared Sub New()
            NPipelineEditorExampleSchema = NSchema.Create(GetType(NPipelineEditorExample), NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            m_DrawingView = New NDrawingView()

            Dim page = m_DrawingView.ActivePage
            page.Items.Add(CreateTitleShape("Pipeline Editor"))

            Return m_DrawingView
        End Function
        Protected Overrides Function CreateExampleControls() As NWidget
            Dim libraryView As NLibraryView = New NLibraryView()
            libraryView.Content = CreateLibrary()
            Return libraryView
        End Function
        Protected Overrides Function GetExampleDescription() As String
            Return "
<p>
	This example demonstrates how to take advantage of inward/outward ports in order to build a pipeline editor application.
	Drag and drop pipes from the pipes panel into the drawing area. When a pipe is near other pipe it sticks to its end if possible
	or automatically rotates if needed and then sticks to the other pipe. Use the end pipe symbols (triangles) to mark pipe ends.
</p>" End Function

#End Region

#Region "Implementation"

        ''' <summary>
        ''' Creates the Title shape.
        ''' </summary>
        ''' <paramname="title"></param>
        ''' <returns></returns>
        Private Function CreateTitleShape(ByVal title As String) As NShape
            Dim theme = NDrawingTheme.MyDrawNature

            Dim titleShape As NShape = New NShape()
            titleShape.SetBounds(0, 0, 500, 50)
            titleShape.Text = title
            titleShape.SetProtectionMask(ENDiagramItemOperationMask.All)

            Dim titleTextBlock = CType(titleShape.TextBlock, NTextBlock)
            titleTextBlock.ResizeMode = ENTextBlockResizeMode.ShapeSize
            titleTextBlock.FontSize = 28
            titleTextBlock.FontStyleBold = True

            ' Set theme-based colors to the title text, so that it changes when the user changes the theme
            Dim strokeColor = theme.ColorPalette.Variants(0)(0)
            strokeColor.Tag = New NThemeVariantColorInfo(0)
            titleTextBlock.Stroke = New NStroke(strokeColor)

            Dim fillColor = theme.ColorPalette.Variants(0)(4)
            fillColor.Tag = New NThemeVariantColorInfo(4)
            titleTextBlock.Fill = New NColorFill(fillColor)

            ' Alternatively, you can also use fixed colors (uncomment the 2 lines below)
            'titleTextBlock.Stroke = new NStroke(NColor.DarkBlue);
            'titleTextBlock.Fill = new NColorFill(NColor.LightBlue);

            ' Set an expression to center the title horizontally in the page
            titleShape.SetFx(NShape.PinXProperty, New NFormulaFx("$ParentSheet.X + $ParentSheet.Width / 2", True))

            Return titleShape
        End Function

        Private Function CreateLibrary() As NLibrary
            Dim library As NLibrary = New NLibrary()

            library.Items.Add(New NLibraryItem(CreateHorizontalPipe(), "Horizontal Pipe", "Drag me on the drawing"))
            library.Items.Add(New NLibraryItem(CreateVerticalPipe(), "Vertical Pipe", "Drag me on the drawing"))
            library.Items.Add(New NLibraryItem(CreateCrossPipe(), "Cross Pipe", "Drag me on the drawing"))

            library.Items.Add(New NLibraryItem(CreateElbowPipe("NW"), "North-West Pipe", "Drag me on the drawing"))
            library.Items.Add(New NLibraryItem(CreateElbowPipe("NE"), "North-East Pipe", "Drag me on the drawing"))
            library.Items.Add(New NLibraryItem(CreateElbowPipe("SW"), "South-West Pipe", "Drag me on the drawing"))
            library.Items.Add(New NLibraryItem(CreateElbowPipe("SE"), "South-East Pipe", "Drag me on the drawing"))

            library.Items.Add(New NLibraryItem(CreateTPipe("NEW"), "North-East-West Pipe", "Drag me on the drawing"))
            library.Items.Add(New NLibraryItem(CreateTPipe("NES"), "North-East-South Pipe", "Drag me on the drawing"))
            library.Items.Add(New NLibraryItem(CreateTPipe("NWS"), "North-West-South Pipe", "Drag me on the drawing"))
            library.Items.Add(New NLibraryItem(CreateTPipe("SEW"), "South-East-West Pipe", "Drag me on the drawing"))

            library.Items.Add(New NLibraryItem(CreateEndPipe("W"), "West-End Pipe", "Drag me on the drawing"))
            library.Items.Add(New NLibraryItem(CreateEndPipe("N"), "North-End Pipe", "Drag me on the drawing"))
            library.Items.Add(New NLibraryItem(CreateEndPipe("E"), "East-End Pipe", "Drag me on the drawing"))
            library.Items.Add(New NLibraryItem(CreateEndPipe("S"), "South-End Pipe", "Drag me on the drawing"))

            Return library
        End Function

        Private Function CreateHorizontalPipe() As NShape
            Dim shape As NShape = New NShape()
            shape.SetBounds(0, BoxSize, 3 * BoxSize, BoxSize)

            Dim drawRectangle As NDrawRectangle = New NDrawRectangle(0, 0, 1, 1)
            drawRectangle.ShowStroke = False
            shape.Geometry.AddRelative(drawRectangle)

            shape.Geometry.AddRelative(New NMoveTo(0, 0))
            shape.Geometry.AddRelative(New NLineTo(1, 0))
            shape.Geometry.AddRelative(New NMoveTo(0, 1))
            shape.Geometry.AddRelative(New NLineTo(1, 1))

            shape.Ports.Add(CreatePort(Side.Left))
            shape.Ports.Add(CreatePort(Side.Right))

            SetProtections(shape)
            Return shape
        End Function
        Private Function CreateVerticalPipe() As NShape
            Dim shape As NShape = New NShape()
            shape.SetBounds(BoxSize, 0, BoxSize, 3 * BoxSize)

            Dim drawRectangle As NDrawRectangle = New NDrawRectangle(0, 0, 1, 1)
            drawRectangle.ShowStroke = False
            shape.Geometry.AddRelative(drawRectangle)

            shape.Geometry.AddRelative(New NMoveTo(0, 0))
            shape.Geometry.AddRelative(New NLineTo(0, 1))
            shape.Geometry.AddRelative(New NMoveTo(1, 0))
            shape.Geometry.AddRelative(New NLineTo(1, 1))

            shape.Ports.Add(CreatePort(Side.Top))
            shape.Ports.Add(CreatePort(Side.Bottom))

            SetProtections(shape)
            Return shape
        End Function
        Private Function CreateCrossPipe() As NShape
            Dim shape As NShape = New NShape()
            shape.SetBounds(0, 0, 3 * BoxSize, 3 * BoxSize)

            Dim drawPolygon As NDrawPolygon = New NDrawPolygon(0, 0, 1, 1, New NPoint() {New NPoint(0, OneThird), New NPoint(OneThird, OneThird), New NPoint(OneThird, 0), New NPoint(TwoThirds, 0), New NPoint(TwoThirds, OneThird), New NPoint(1, OneThird), New NPoint(1, TwoThirds), New NPoint(TwoThirds, TwoThirds), New NPoint(TwoThirds, 1), New NPoint(OneThird, 1), New NPoint(OneThird, TwoThirds), New NPoint(0, TwoThirds)})

            drawPolygon.ShowStroke = False
            shape.Geometry.AddRelative(drawPolygon)

            shape.Geometry.AddRelative(New NMoveTo(0, OneThird))
            shape.Geometry.AddRelative(New NLineTo(OneThird, OneThird))
            shape.Geometry.AddRelative(New NMoveTo(OneThird, OneThird))
            shape.Geometry.AddRelative(New NLineTo(OneThird, 0))

            shape.Geometry.AddRelative(New NMoveTo(TwoThirds, 0))
            shape.Geometry.AddRelative(New NLineTo(TwoThirds, OneThird))
            shape.Geometry.AddRelative(New NMoveTo(TwoThirds, OneThird))
            shape.Geometry.AddRelative(New NLineTo(1, OneThird))

            shape.Geometry.AddRelative(New NMoveTo(1, TwoThirds))
            shape.Geometry.AddRelative(New NLineTo(TwoThirds, TwoThirds))
            shape.Geometry.AddRelative(New NMoveTo(TwoThirds, TwoThirds))
            shape.Geometry.AddRelative(New NLineTo(TwoThirds, 1))

            shape.Geometry.AddRelative(New NMoveTo(OneThird, 1))
            shape.Geometry.AddRelative(New NLineTo(OneThird, TwoThirds))
            shape.Geometry.AddRelative(New NMoveTo(OneThird, TwoThirds))
            shape.Geometry.AddRelative(New NLineTo(0, TwoThirds))

            shape.Ports.Add(CreatePort(Side.Left))
            shape.Ports.Add(CreatePort(Side.Top))
            shape.Ports.Add(CreatePort(Side.Right))
            shape.Ports.Add(CreatePort(Side.Bottom))

            SetProtections(shape)
            Return shape
        End Function
        Private Function CreateElbowPipe(ByVal type As String) As NShape
            Dim drawPolygon As NDrawPolygon
            Dim ca1, ca2 As Side

            Select Case type
                Case "NW"
                    drawPolygon = New NDrawPolygon(0, 0, 1, 1, New NPoint() {New NPoint(0, OneThird), New NPoint(OneThird, OneThird), New NPoint(OneThird, 0), New NPoint(TwoThirds, 0), New NPoint(TwoThirds, TwoThirds), New NPoint(0, TwoThirds)})

                    ca1 = Side.Top
                    ca2 = Side.Left

                Case "NE"
                    drawPolygon = New NDrawPolygon(0, 0, 1, 1, New NPoint() {New NPoint(1, OneThird), New NPoint(TwoThirds, OneThird), New NPoint(TwoThirds, 0), New NPoint(OneThird, 0), New NPoint(OneThird, TwoThirds), New NPoint(1, TwoThirds)})

                    ca1 = Side.Top
                    ca2 = Side.Right

                Case "SW"
                    drawPolygon = New NDrawPolygon(0, 0, 1, 1, New NPoint() {New NPoint(0, TwoThirds), New NPoint(OneThird, TwoThirds), New NPoint(OneThird, 1), New NPoint(TwoThirds, 1), New NPoint(TwoThirds, OneThird), New NPoint(0, OneThird)})

                    ca1 = Side.Bottom
                    ca2 = Side.Left

                Case "SE"
                    drawPolygon = New NDrawPolygon(0, 0, 1, 1, New NPoint() {New NPoint(1, TwoThirds), New NPoint(TwoThirds, TwoThirds), New NPoint(TwoThirds, 1), New NPoint(OneThird, 1), New NPoint(OneThird, OneThird), New NPoint(1, OneThird)})

                    ca1 = Side.Bottom
                    ca2 = Side.Right
                Case Else
                    Throw New ArgumentException("Unsupported elbow pipe type")
            End Select

            Dim shape As NShape = New NShape()
            shape.SetBounds(0, 0, 3 * BoxSize, 3 * BoxSize)

            drawPolygon.ShowStroke = False
            shape.Geometry.AddRelative(drawPolygon)

            shape.Geometry.AddRelative(New NMoveTo(drawPolygon.Points(0)))
            shape.Geometry.AddRelative(New NLineTo(drawPolygon.Points(1)))

            shape.Geometry.AddRelative(New NMoveTo(drawPolygon.Points(1)))
            shape.Geometry.AddRelative(New NLineTo(drawPolygon.Points(2)))

            shape.Geometry.AddRelative(New NMoveTo(drawPolygon.Points(3)))
            shape.Geometry.AddRelative(New NLineTo(drawPolygon.Points(4)))

            shape.Geometry.AddRelative(New NMoveTo(drawPolygon.Points(4)))
            shape.Geometry.AddRelative(New NLineTo(drawPolygon.Points(5)))

            shape.Ports.Add(CreatePort(ca1))
            shape.Ports.Add(CreatePort(ca2))

            SetProtections(shape)
            Return shape
        End Function
        Private Function CreateTPipe(ByVal type As String) As NShape
            Dim drawPolygon As NDrawPolygon
            Dim ca1, ca2, ca3 As Side

            Select Case type
                Case "NEW"
                    drawPolygon = New NDrawPolygon(0, 0, 1, 1, New NPoint() {New NPoint(0, OneThird), New NPoint(OneThird, OneThird), New NPoint(OneThird, 0), New NPoint(TwoThirds, 0), New NPoint(TwoThirds, OneThird), New NPoint(1, OneThird), New NPoint(1, TwoThirds), New NPoint(0, TwoThirds)})

                    ca1 = Side.Top
                    ca2 = Side.Left
                    ca3 = Side.Right

                Case "NES"
                    drawPolygon = New NDrawPolygon(0, 0, 1, 1, New NPoint() {New NPoint(1, OneThird), New NPoint(TwoThirds, OneThird), New NPoint(TwoThirds, 0), New NPoint(OneThird, 0), New NPoint(OneThird, 1), New NPoint(TwoThirds, 1), New NPoint(TwoThirds, TwoThirds), New NPoint(1, TwoThirds)})

                    ca1 = Side.Top
                    ca2 = Side.Right
                    ca3 = Side.Bottom

                Case "NWS"
                    drawPolygon = New NDrawPolygon(0, 0, 1, 1, New NPoint() {New NPoint(0, OneThird), New NPoint(OneThird, OneThird), New NPoint(OneThird, 0), New NPoint(TwoThirds, 0), New NPoint(TwoThirds, 1), New NPoint(OneThird, 1), New NPoint(OneThird, TwoThirds), New NPoint(0, TwoThirds)})

                    ca1 = Side.Top
                    ca2 = Side.Left
                    ca3 = Side.Bottom

                Case "SEW"
                    drawPolygon = New NDrawPolygon(0, 0, 1, 1, New NPoint() {New NPoint(1, TwoThirds), New NPoint(TwoThirds, TwoThirds), New NPoint(TwoThirds, 1), New NPoint(OneThird, 1), New NPoint(OneThird, TwoThirds), New NPoint(0, TwoThirds), New NPoint(0, OneThird), New NPoint(1, OneThird)})

                    ca1 = Side.Bottom
                    ca2 = Side.Right
                    ca3 = Side.Left
                Case Else
                    Throw New ArgumentException("Unsupported elbow pipe type")
            End Select

            Dim shape As NShape = New NShape()
            shape.SetBounds(0, 0, 3 * BoxSize, 3 * BoxSize)

            drawPolygon.ShowStroke = False
            shape.Geometry.AddRelative(drawPolygon)

            shape.Geometry.AddRelative(New NMoveTo(drawPolygon.Points(0)))
            shape.Geometry.AddRelative(New NLineTo(drawPolygon.Points(1)))

            shape.Geometry.AddRelative(New NMoveTo(drawPolygon.Points(1)))
            shape.Geometry.AddRelative(New NLineTo(drawPolygon.Points(2)))

            shape.Geometry.AddRelative(New NMoveTo(drawPolygon.Points(3)))
            shape.Geometry.AddRelative(New NLineTo(drawPolygon.Points(4)))

            If type.Contains("S") AndAlso type.Contains("N") Then
                shape.Geometry.AddRelative(New NMoveTo(drawPolygon.Points(5)))
                shape.Geometry.AddRelative(New NLineTo(drawPolygon.Points(6)))
            Else
                shape.Geometry.AddRelative(New NMoveTo(drawPolygon.Points(4)))
                shape.Geometry.AddRelative(New NLineTo(drawPolygon.Points(5)))
            End If

            shape.Geometry.AddRelative(New NMoveTo(drawPolygon.Points(6)))
            shape.Geometry.AddRelative(New NLineTo(drawPolygon.Points(7)))

            shape.Ports.Add(CreatePort(ca1))
            shape.Ports.Add(CreatePort(ca2))
            shape.Ports.Add(CreatePort(ca3))

            SetProtections(shape)
            Return shape
        End Function
        Private Function CreateEndPipe(ByVal type As String) As NShape
            Dim drawPolygon As NDrawPolygon
            Dim ca As Side

            Select Case type
                Case "W"
                    drawPolygon = New NDrawPolygon(0, 0, 1, 1, New NPoint() {New NPoint(1, OneThird), New NPoint(TwoThirds, Half), New NPoint(1, TwoThirds)})

                    ca = Side.Right

                Case "N"
                    drawPolygon = New NDrawPolygon(0, 0, 1, 1, New NPoint() {New NPoint(OneThird, 1), New NPoint(Half, TwoThirds), New NPoint(TwoThirds, 1)})

                    ca = Side.Bottom

                Case "E"
                    drawPolygon = New NDrawPolygon(0, 0, 1, 1, New NPoint() {New NPoint(0, OneThird), New NPoint(OneThird, Half), New NPoint(0, TwoThirds)})

                    ca = Side.Left

                Case "S"
                    drawPolygon = New NDrawPolygon(0, 0, 1, 1, New NPoint() {New NPoint(OneThird, 0), New NPoint(Half, OneThird), New NPoint(TwoThirds, 0)})

                    ca = Side.Top
                Case Else
                    Throw New ArgumentException("Unsupported elbow pipe type")
            End Select

            Dim shape As NShape = New NShape()
            shape.SetBounds(0, 0, 3 * BoxSize, 3 * BoxSize)

            drawPolygon.ShowStroke = False
            shape.Geometry.AddRelative(drawPolygon)

            shape.Geometry.AddRelative(New NMoveTo(drawPolygon.Points(0)))
            shape.Geometry.AddRelative(New NLineTo(drawPolygon.Points(1)))

            shape.Geometry.AddRelative(New NMoveTo(drawPolygon.Points(1)))
            shape.Geometry.AddRelative(New NLineTo(drawPolygon.Points(2)))

            shape.Ports.Add(CreatePort(ca))

            SetProtections(shape)
            Return shape
        End Function

#End Region

#Region "Fields"

        Private m_DrawingView As NDrawingView

#End Region

#Region "Schema"

        ''' <summary>
        ''' Schema associated with NPipelineEditorExample.
        ''' </summary>
        Public Shared ReadOnly NPipelineEditorExampleSchema As NSchema

#End Region

#Region "Static Methods"

        Private Shared Sub SetProtections(ByVal shape As NShape)
            shape.AllowResizeX = False
            shape.AllowResizeY = False
            shape.AllowRotate = False
            shape.AllowInplaceEdit = False
        End Sub

        Private Shared Function CreatePort(ByVal side As Side) As NPort
            Dim port As NPort
            Select Case side
                Case Side.Left
                    port = New NPort(0, 0.5, True)
                    port.SetDirection(ENBoxDirection.Left)
                Case Side.Top
                    port = New NPort(0.5, 0, True)
                    port.SetDirection(ENBoxDirection.Up)
                Case Side.Right
                    port = New NPort(1, 0.5, True)
                    port.SetDirection(ENBoxDirection.Right)
                Case Side.Bottom
                    port = New NPort(0.5, 1, True)
                    port.SetDirection(ENBoxDirection.Down)
                Case Else
                    Return Nothing
            End Select

            port.GlueMode = ENPortGlueMode.InwardAndOutward
            Return port
        End Function

#End Region

#Region "Constants"

        Private Const BoxSize As Integer = 25

        Private Const OneThird As Double = 1.0 / 3.0
        Private Const TwoThirds As Double = 2.0 / 3.0
        Private Const Half As Double = 0.5

#End Region

#Region "Nested Types"

        Private Enum Side
            Left
            Top
            Right
            Bottom
        End Enum

#End Region
    End Class
End Namespace

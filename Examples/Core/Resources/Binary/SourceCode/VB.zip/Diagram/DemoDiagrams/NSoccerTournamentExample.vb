Imports Nevron.Nov.Diagram
Imports Nevron.Nov.Diagram.Layout
Imports Nevron.Nov.Diagram.Themes
Imports Nevron.Nov.Dom
Imports Nevron.Nov.Graphics
Imports Nevron.Nov.Layout
Imports Nevron.Nov.Text
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.Diagram
    Public Class NSoccerTournamentExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' Default constructor.
        ''' </summary>
        Public Sub New()
        End Sub

        ''' <summary>
        ''' Static constructor.
        ''' </summary>
        Shared Sub New()
            NSoccerTournamentExampleSchema = NSchema.Create(GetType(NSoccerTournamentExample), NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            ' Create a simple drawing
            Dim drawingViewWithRibbon As NDrawingViewWithRibbon = New NDrawingViewWithRibbon()
            m_DrawingView = drawingViewWithRibbon.View

            ' hide grid and ports
            m_DrawingView.Content.ScreenVisibility.ShowGrid = False
            m_DrawingView.Content.ScreenVisibility.ShowPorts = False

            m_DrawingView.Document.HistoryService.Pause()
            Try
                InitDiagram(m_DrawingView.Document)
            Finally
                m_DrawingView.Document.HistoryService.Resume()
            End Try

            Return drawingViewWithRibbon
        End Function
        Protected Overrides Function CreateExampleControls() As NWidget
            Return Nothing
        End Function
        Protected Overrides Function GetExampleDescription() As String
            Return "<p>Demonstrates how to create a soccer tournament scoreboard using the following NOV Diagram features:</p>
<ul>
	<li>Theme-based colors for the title - change the page theme from the ""Design"" tab to see how the style of the title will change, too.</li>
	<li>Table blocks - used for the match shapes.</li>
	<li>Layered Graph Layout - used to arrange the shapes.</li>
</ul>
" End Function

        Private Sub InitDiagram(ByVal drawingDocument As NDrawingDocument)
            Dim page = drawingDocument.Content.ActivePage

            ' Create a title shape
            Dim titleShape = CreateTitleShape("FIFA World Cup 2022")
            page.Items.Add(titleShape)

            ' Create the match shapes
            Dim roundOf16Shapes = CreateMatchShapes(page, RoundOf16)
            Dim quarterFinalsShapes = CreateMatchShapes(page, QuarterFinals)
            Dim semiFinalsShapes = CreateMatchShapes(page, SemiFinals)

            Dim finalShape = CreateMatchShape(Final)
            page.Items.Add(finalShape)

            ' Connect the shapes
            For i = 0 To quarterFinalsShapes.Length - 1
                ConnectShapes(roundOf16Shapes(i * 2), roundOf16Shapes(i * 2 + 1), quarterFinalsShapes(i))
            Next

            ConnectShapes(quarterFinalsShapes(0), quarterFinalsShapes(1), semiFinalsShapes(0))
            ConnectShapes(quarterFinalsShapes(2), quarterFinalsShapes(3), semiFinalsShapes(1))

            ConnectShapes(semiFinalsShapes(0), semiFinalsShapes(1), finalShape)

            ' Arrange the shapes using a Layered Graph Layout
            Dim layout As NLayeredGraphLayout = New NLayeredGraphLayout()
            layout.Direction = ENHVDirection.LeftToRight
            layout.UseSingleBus = True
            layout.PlugSpacing.Mode = ENPlugSpacingMode.None
            layout.RegionLayout.VerticalSpacing = 25 ' Controls the spacing between the title and the diagram

            Dim shapes = page.GetShapes(False, NDiagramFilters.ShapeType2D)
            layout.Arrange(shapes.CastAll(Of Object)(), New NDrawingLayoutContext(page))

            page.SizeToContent()
        End Sub

#End Region

#Region "Implementation"

        Private Function CreateTitleShape(ByVal title As String) As NShape
            Dim theme = NDrawingTheme.MyDrawNature

            Dim titleShape As NShape = New NShape()
            titleShape.SetBounds(0, 0, 500, 50)
            titleShape.Text = title
            titleShape.SetProtectionMask(ENDiagramItemOperationMask.All)

            Dim titleTextBlock = CType(titleShape.TextBlock, NTextBlock)
            titleTextBlock.ResizeMode = ENTextBlockResizeMode.ShapeSize
            titleTextBlock.FontSize = 28
            titleTextBlock.FontStyleBold = True

            ' Set theme-based colors to the title text, so that it changes when the user changes the theme
            Dim strokeColor = theme.ColorPalette.Variants(0)(0)
            strokeColor.Tag = New NThemeVariantColorInfo(0)
            titleTextBlock.Stroke = New NStroke(strokeColor)

            Dim fillColor = theme.ColorPalette.Variants(0)(4)
            fillColor.Tag = New NThemeVariantColorInfo(4)
            titleTextBlock.Fill = New NColorFill(fillColor)

            ' Alternatively, you can also use fixed colors (uncomment the 2 lines below)
            'titleTextBlock.Stroke = new NStroke(NColor.DarkBlue);
            'titleTextBlock.Fill = new NColorFill(NColor.LightBlue);

            ' Set an expression to center the title horizontally in the page
            titleShape.SetFx(NShape.PinXProperty, New NFormulaFx("$ParentSheet.X + $ParentSheet.Width / 2", True))

            Return titleShape
        End Function

        Private Function CreateMatchShapes(ByVal page As NPage, ByVal matches As Match()) As NShape()
            Dim matchShapes = New NShape(matches.Length - 1) {}
            For i = 0 To matches.Length - 1
                Dim matchShape = CreateMatchShape(matches(i))
                page.Items.Add(matchShape)
                matchShapes(i) = matchShape
            Next

            Return matchShapes
        End Function
        Private Function CreateMatchShape(ByVal match As Match) As NShape
            Dim shape As NShape = New NShape()
            shape.SetBounds(0, 0, MatchShapeSize.Width, MatchShapeSize.Height)

            ' Create a table block
            Dim tableBlock As NTableBlock = New NTableBlock(2, 2, NBorder.CreateFilledBorder(MatchBorderColor), MatchBorderThickness)
            tableBlock.PortsDistributionMode = ENPortsDistributionMode.None
            tableBlock.ResizeMode = ENTableBlockResizeMode.FitToShape
            shape.TextBlock = tableBlock

            ' Configure the table block content
            Dim table = tableBlock.Content
            table.AllowSpacingBetweenCells = False
            table.Columns(1).PreferredWidth = NMultiLength.NewFixed(MatchShapeSize.Width / 4)

            ' Add the match info to the table
            table.Rows(0).Cells(0).Blocks(0) = New NParagraph(match.Team1)
            table.Rows(0).Cells(1).Blocks(0) = New NParagraph(match.Score1String)
            table.Rows(1).Cells(0).Blocks(0) = New NParagraph(match.Team2)
            table.Rows(1).Cells(1).Blocks(0) = New NParagraph(match.Score2String)

            ' Apply center vertical alignment to all cells
            For i = 0 To table.Rows.Count - 1
                For j = 0 To table.Columns.Count - 1
                    table.Rows(i).Cells(j).VerticalAlignment = ENVAlign.Center
                Next
            Next

            ' Make the winner's row bold
            table.Rows(match.WinnerTeamIndex - 1).FontStyleBold = True

            Return shape
        End Function

        Private Sub ConnectShapes(ByVal matchShape1 As NShape, ByVal matchShape2 As NShape, ByVal nextMatchShape As NShape)
            Dim page = matchShape1.OwnerPage

            Dim con1 As NRoutableConnector = New NRoutableConnector()
            page.Items.Add(con1)
            con1.GlueBeginToShape(matchShape1)
            con1.GlueEndToShape(nextMatchShape)

            Dim con2 As NRoutableConnector = New NRoutableConnector()
            page.Items.Add(con2)
            con2.GlueBeginToShape(matchShape2)
            con2.GlueEndToShape(nextMatchShape)
        End Sub

#End Region

#Region "Fields"

        Private m_DrawingView As NDrawingView

#End Region

#Region "Schema"

        ''' <summary>
        ''' Schema associated with NSoccerTournamentExample.
        ''' </summary>
        Public Shared ReadOnly NSoccerTournamentExampleSchema As NSchema

#End Region

#Region "Constants - Data"

        Private RoundOf16 As Match() = New Match() {New Match("Netherlands", 3, "United States", 1), New Match("Argentina", 2, "Australia", 1), New Match("Japan", 1, 1, "Croatia", 1, 3), New Match("Brazil", 4, "South Korea", 1), New Match("England", 3, "Senegal", 0), New Match("France", 3, "Poland", 1), New Match("Morocco", 0, 3, "Spain", 0, 0), New Match("Portugal", 6, "Switzerland", 1)}

        Private QuarterFinals As Match() = New Match() {New Match("Netherlands", 2, 3, "Argentina", 2, 4), New Match("Croatia", 1, 4, "Brazil", 1, 2), New Match("England", 1, "France", 2), New Match("Morocco", 1, "Portugal", 0)}

        Private SemiFinals As Match() = New Match() {New Match("Argentina", 3, "Croatia", 0), New Match("France", 2, "Morocco", 0)}

        Private ThirdPlace As Match = New Match("Croatia", 2, "Morocco", 1)

        Private Final As Match = New Match("Argentina", 3, 4, "France", 3, 2)

#End Region

#Region "Constants - Appearance"

        Private Shared ReadOnly MatchShapeSize As NSize = New NSize(160, 60)
        Private Shared ReadOnly MatchBorderColor As NColor = NColor.DimGray
        Private Shared ReadOnly MatchBorderThickness As NMargins = New NMargins(1)

#End Region

#Region "Nested Types"

        Private Class Match
            Public Sub New(ByVal team1 As String, ByVal goals1 As Integer, ByVal team2 As String, ByVal goals2 As Integer)
                Me.New(team1, goals1, -1, team2, goals2, -1)
            End Sub
            Public Sub New(ByVal team1 As String, ByVal goals1 As Integer, ByVal penalty1 As Integer, ByVal team2 As String, ByVal goals2 As Integer, ByVal penalty2 As Integer)
                Me.Team1 = team1
                m_Goals1 = goals1
                m_Penalty1 = penalty1

                Me.Team2 = team2
                m_Goals2 = goals2
                m_Penalty2 = penalty2
            End Sub

            ''' <summary>
            ''' Returns the index of the winner team - 1 or 2.
            ''' </summary>
            Public ReadOnly Property WinnerTeamIndex As Integer
                Get
                    If m_Goals1 > m_Goals2 Then
                        Return 1
                    ElseIf m_Goals1 < m_Goals2 Then
                        Return 2
                    Else
                        Return If(m_Penalty1 > m_Penalty2, 1, 2)
                    End If
                End Get
            End Property
            Public ReadOnly Property Score1String As String
                Get
                    Dim score As String = m_Goals1.ToString()
                    If m_Penalty1 <> -1 Then
                        score += $" ({m_Penalty1})"
                    End If

                    Return score
                End Get
            End Property
            Public ReadOnly Property Score2String As String
                Get
                    Dim score As String = m_Goals2.ToString()
                    If m_Penalty2 <> -1 Then
                        score += $" ({m_Penalty2})"
                    End If

                    Return score
                End Get
            End Property

            Public Team1 As String
            Public Team2 As String

            Private m_Goals1 As Integer
            Private m_Goals2 As Integer
            Private m_Penalty1 As Integer
            Private m_Penalty2 As Integer
        End Class

#End Region
    End Class
End Namespace

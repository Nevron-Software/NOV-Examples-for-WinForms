Imports Nevron.Nov.Diagram
Imports Nevron.Nov.Diagram.Layout
Imports Nevron.Nov.Diagram.Shapes
Imports Nevron.Nov.Diagram.Themes
Imports Nevron.Nov.Dom
Imports Nevron.Nov.Graphics
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.Diagram
    Public Class NOrgChartBusinessCompanyExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' Default constructor.
        ''' </summary>
        Public Sub New()
        End Sub

        ''' <summary>
        ''' Static constructor.
        ''' </summary>
        Shared Sub New()
            NOrgChartBusinessCompanyExampleSchema = NSchema.Create(GetType(NOrgChartBusinessCompanyExample), NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            ' Create a simple drawing
            Dim drawingViewWithRibbon As NDrawingViewWithRibbon = New NDrawingViewWithRibbon()
            m_DrawingView = drawingViewWithRibbon.View

            ' hide grid and ports
            m_DrawingView.Content.ScreenVisibility.ShowGrid = False
            m_DrawingView.Content.ScreenVisibility.ShowPorts = False

            m_DrawingView.Document.HistoryService.Pause()
            Try
                InitDiagram(m_DrawingView.Document)
            Finally
                m_DrawingView.Document.HistoryService.Resume()
            End Try

            Return drawingViewWithRibbon
        End Function
        Protected Overrides Function CreateExampleControls() As NWidget
            Return Nothing
        End Function
        Protected Overrides Function GetExampleDescription() As String
            Return "<p>Demonstrates how to create an organizational chart diagram (org chart) of a business company using the following NOV Diagram features:</p>
<ul>
	<li>Theme-based colors for the title - change the page theme from the ""Design"" tab to see how the style of the title will change, too.</li>
	<li>Organizational shapes - used to represent the employees of the business company.</li>
	<li>Tip Over Tree Layout - used to arrange the org chart shapes in a compact way, placing leaf shapes in a column instead of in a row.</li>
</ul>
" End Function

        Private Sub InitDiagram(ByVal drawingDocument As NDrawingDocument)
            Dim page = drawingDocument.Content.ActivePage

            ' Create a title shape
            Dim titleShape = CreateTitleShape("Business Company")
            page.Items.Add(titleShape)

            ' Recursively create the org chart shapes
            CreateOrgShape(page, ExecutiveEmployee)

            ' Arrange the shapes using a Layered Graph Layout
            Dim layout As NTipOverTreeLayout = New NTipOverTreeLayout()
            layout.LeafsPlacement = ENTipOverChildrenPlacement.ColRight
            layout.RegionLayout.VerticalSpacing = 25 ' Controls the spacing between the title and the diagram

            Dim shapes = page.GetShapes(False, NDiagramFilters.ShapeType2D)
            layout.Arrange(shapes.CastAll(Of Object)(), New NDrawingLayoutContext(page))

            page.SizeToContent()
        End Sub

#End Region

#Region "Implementation"

        Private Function CreateTitleShape(ByVal title As String) As NShape
            Dim theme = NDrawingTheme.MyDrawNature

            Dim titleShape As NShape = New NShape()
            titleShape.SetBounds(0, 0, 500, 50)
            titleShape.Text = title

            Dim titleTextBlock = CType(titleShape.TextBlock, NTextBlock)
            titleTextBlock.ResizeMode = ENTextBlockResizeMode.ShapeSize
            titleTextBlock.FontSize = 28
            titleTextBlock.FontStyleBold = True

            ' Set theme-based colors to the title text, so that it changes when the user changes the theme
            Dim strokeColor = theme.ColorPalette.Variants(0)(0)
            strokeColor.Tag = New NThemeVariantColorInfo(0)
            titleTextBlock.Stroke = New NStroke(strokeColor)

            Dim fillColor = theme.ColorPalette.Variants(0)(4)
            fillColor.Tag = New NThemeVariantColorInfo(4)
            titleTextBlock.Fill = New NColorFill(fillColor)

            ' Alternatively, you can also use fixed colors (uncomment the 2 lines below)
            'titleTextBlock.Stroke = new NStroke(NColor.DarkBlue);
            'titleTextBlock.Fill = new NColorFill(NColor.LightBlue);

            ' Set an expression to center the title horizontally in the page
            titleShape.SetFx(NShape.PinXProperty, New NFormulaFx("$ParentSheet.X + $ParentSheet.Width / 2", True))

            Return titleShape
        End Function
        Private Function CreateOrgShape(ByVal page As NPage, ByVal employee As Employee) As NShape
            Dim shape = NLibrary.OrganizationalChartShapes.CreateShape(employee.Position, OrgChartShapeSize.Width, OrgChartShapeSize.Height)
            shape.Text = employee.Name
            shape.ImageBlock.Image = If(employee.Gender Is ENGender.Male, NResources.Image_SVG_Male_svg, NResources.Image_SVG_Female_svg)
            page.Items.Add(shape)

            If employee.SubordinateEmployees IsNot Nothing Then
                For i = 0 To employee.SubordinateEmployees.Length - 1
                    Dim childShape = CreateOrgShape(page, employee.SubordinateEmployees(i))
                    ConnectShapes(shape, childShape)
                Next
            End If

            Return shape
        End Function
        Private Sub ConnectShapes(ByVal shape1 As NShape, ByVal shape2 As NShape)
            Dim connector As NRoutableConnector = New NRoutableConnector()
            shape1.OwnerPage.Items.Add(connector)
            connector.GlueBeginToShape(shape1)
            connector.GlueEndToShape(shape2)
        End Sub

#End Region

#Region "Fields"

        Private m_DrawingView As NDrawingView

#End Region

#Region "Schema"

        ''' <summary>
        ''' Schema associated with NOrgChartBusinessCompanyExample.
        ''' </summary>
        Public Shared ReadOnly NOrgChartBusinessCompanyExampleSchema As NSchema

#End Region

#Region "Constants - Data"

        Private ExecutiveEmployee As Employee = New Employee(ENGender.Male, ENOrganizationalShape.Executive, "William Smith", New Employee(ENGender.Male, ENOrganizationalShape.Manager, "Charlie Good", New Employee(ENGender.Male, ENOrganizationalShape.Assistant, "Peter Marshall"), New Employee(ENGender.Female, ENOrganizationalShape.Assistant, "Tracy Chapmann")), New Employee(ENGender.Male, ENOrganizationalShape.Manager, "Kevin Tylor", New Employee(ENGender.Female, ENOrganizationalShape.Assistant, "Jane Buckley"), New Employee(ENGender.Male, ENOrganizationalShape.Assistant, "Dave Zak")), New Employee(ENGender.Female, ENOrganizationalShape.Manager, "Patricia Holgate", New Employee(ENGender.Male, ENOrganizationalShape.Assistant, "Stephen Maule"), New Employee(ENGender.Male, ENOrganizationalShape.Assistant, "Steve Tucker")))

#End Region

#Region "Constants"

        Private Shared ReadOnly OrgChartShapeSize As NSize = New NSize(120, 70)

#End Region

#Region "Nested Types"

        Private Class Employee
            Public Sub New(ByVal gender As ENGender, ByVal position As ENOrganizationalShape, ByVal name As String, ParamArray subordinateEmployees As Employee())
                Me.Gender = gender
                Me.Position = position
                Me.Name = name
                Me.SubordinateEmployees = subordinateEmployees
            End Sub

            Public Gender As ENGender
            Public Position As ENOrganizationalShape
            Public Name As String
            Public SubordinateEmployees As Employee()
        End Class

#End Region
    End Class
End Namespace

Imports Nevron.Nov.Diagram
Imports Nevron.Nov.Diagram.DataVisualizer
Imports Nevron.Nov.Diagram.Themes
Imports Nevron.Nov.Dom
Imports Nevron.Nov.Graphics
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.Diagram
    Public Class NOrgChartImportExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' Default constructor.
        ''' </summary>
        Public Sub New()
        End Sub

        ''' <summary>
        ''' Static constructor.
        ''' </summary>
        Shared Sub New()
            NOrgChartImportExampleSchema = NSchema.Create(GetType(NOrgChartImportExample), NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            ' Create a simple drawing
            Dim drawingViewWithRibbon As NDrawingViewWithRibbon = New NDrawingViewWithRibbon()
            m_DrawingView = drawingViewWithRibbon.View

            ' hide grid and ports
            m_DrawingView.Content.ScreenVisibility.ShowGrid = False
            m_DrawingView.Content.ScreenVisibility.ShowPorts = False

            m_DrawingView.Document.HistoryService.Pause()
            Try
                InitDiagram(m_DrawingView.Document)
            Finally
                m_DrawingView.Document.HistoryService.Resume()
            End Try

            Return drawingViewWithRibbon
        End Function
        Protected Overrides Function CreateExampleControls() As NWidget
            Return Nothing
        End Function
        Protected Overrides Function GetExampleDescription() As String
            Return "<p>Demonstrates how to create an organizational chart diagram (org chart) from an Excel spreadsheet.</p>"
        End Function

        Private Sub InitDiagram(ByVal drawingDocument As NDrawingDocument)
            Dim page = drawingDocument.Content.ActivePage

            ' Create an org chart from an Excel spreadsheet
            Dim importer As NOrganizationChartVisualizer = New NOrganizationChartVisualizer()
            importer.Columns.Add("Id", "ID")
            importer.Columns.Add("Name", "Employee Name")
            importer.Columns.Add("ReportsTo", "Reports to")
            importer.Columns.Add("Position", "Position")
            importer.BuildDiagramFromStream(m_DrawingView, NResources.RBIN_XLSX_Organization_xlsx.Stream)

            ' Add a title shape
            Dim titleShape = CreateTitleShape("Org Chart Import")
            page.Items.Add(titleShape)

            page.SizeToContent()
        End Sub

#End Region

#Region "Implementation"

        Private Function CreateTitleShape(ByVal title As String) As NShape
            Dim theme = NDrawingTheme.MyDrawNature

            Dim titleShape As NShape = New NShape()
            titleShape.SetBounds(0, -75, 350, 50)
            titleShape.Text = title

            Dim titleTextBlock = CType(titleShape.TextBlock, NTextBlock)
            titleTextBlock.ResizeMode = ENTextBlockResizeMode.ShapeSize
            titleTextBlock.FontSize = 28
            titleTextBlock.FontStyleBold = True

            ' Set theme-based colors to the title text, so that it changes when the user changes the theme
            Dim strokeColor = theme.ColorPalette.Variants(0)(0)
            strokeColor.Tag = New NThemeVariantColorInfo(0)
            titleTextBlock.Stroke = New NStroke(strokeColor)

            Dim fillColor = theme.ColorPalette.Variants(0)(4)
            fillColor.Tag = New NThemeVariantColorInfo(4)
            titleTextBlock.Fill = New NColorFill(fillColor)

            ' Alternatively, you can also use fixed colors (uncomment the 2 lines below)
            'titleTextBlock.Stroke = new NStroke(NColor.DarkBlue);
            'titleTextBlock.Fill = new NColorFill(NColor.LightBlue);

            ' Set an expression to center the title horizontally in the page
            titleShape.SetFx(NShape.PinXProperty, New NFormulaFx("$ParentSheet.X + $ParentSheet.Width / 2", True))

            Return titleShape
        End Function

#End Region

#Region "Fields"

        Private m_DrawingView As NDrawingView

#End Region

#Region "Schema"

        ''' <summary>
        ''' Schema associated with NOrgChartImportExample.
        ''' </summary>
        Public Shared ReadOnly NOrgChartImportExampleSchema As NSchema

#End Region
    End Class
End Namespace

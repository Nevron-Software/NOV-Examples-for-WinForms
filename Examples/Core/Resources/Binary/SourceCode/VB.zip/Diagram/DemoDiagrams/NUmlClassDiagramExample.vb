Imports System
Imports Nevron.Nov.DataStructures
Imports Nevron.Nov.Diagram
Imports Nevron.Nov.Diagram.Layout
Imports Nevron.Nov.Dom
Imports Nevron.Nov.Graphics
Imports Nevron.Nov.Layout
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.Diagram
    Public Class NUmlClassDiagramExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' Default constructor.
        ''' </summary>
        Public Sub New()
        End Sub

        ''' <summary>
        ''' Static constructor.
        ''' </summary>
        Shared Sub New()
            NUmlClassDiagramExampleSchema = NSchema.Create(GetType(NUmlClassDiagramExample), NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            ' Create a simple drawing
            Dim drawingViewWithRibbon As NDrawingViewWithRibbon = New NDrawingViewWithRibbon()
            m_DrawingView = drawingViewWithRibbon.View
            m_DrawingView.Document.HistoryService.Pause()

            Try
                InitDiagram(m_DrawingView.Document)
            Finally
                m_DrawingView.Document.HistoryService.Resume()
            End Try

            Return drawingViewWithRibbon
        End Function

        Protected Overrides Function CreateExampleControls() As NWidget
            Return Nothing
        End Function

        Protected Overrides Function GetExampleDescription() As String
            Return "<p>This example demonstrates how to create an UML class diagrams.</p>"
        End Function

        Private Sub InitDiagram(ByVal drawingDocument As NDrawingDocument)
            ' Get drawing and active page
            Dim drawing = drawingDocument.Content
            Dim activePage = drawing.ActivePage

            ' Hide ports and grid
            drawing.ScreenVisibility.ShowGrid = False

            ' Create styles
            Dim rule As NRule = CreateConnectorOneToManyRule()
            Dim styleSheet As NStyleSheet = New NStyleSheet()
            styleSheet.Add(rule)
            drawingDocument.StyleSheets.Add(styleSheet)

            ' Create some UML shapes
            Dim shapeDevice As NShape = CreateUmlShape("Device", New NMemberInfo() {New NMemberInfo(ENMemberVisibility.Public, "DeviceID", "integer(10)"), New NMemberInfo(ENMemberVisibility.Protected, "DeviceCategory", "integer(10)"), New NMemberInfo(ENMemberVisibility.Private, "name", "varchar(50)"), New NMemberInfo(ENMemberVisibility.Private, "description", "blob"), New NMemberInfo(ENMemberVisibility.Private, "detail", "blob")})
            activePage.Items.Add(shapeDevice)
            Dim shapeDeviceCategory As NShape = CreateUmlShape("DeviceCategory", New NMemberInfo() {New NMemberInfo(ENMemberVisibility.Public, "CategoryID", "integer(10)"), New NMemberInfo(ENMemberVisibility.Private, "description", "blob")})
            activePage.Items.Add(shapeDeviceCategory)
            Dim shapeSupportRequest As NShape = CreateUmlShape("SupportRequest", New NMemberInfo() {New NMemberInfo(ENMemberVisibility.Protected, "Device", "integer(10)"), New NMemberInfo(ENMemberVisibility.Public, "RequestID", "integer(10)"), New NMemberInfo(ENMemberVisibility.Protected, "User", "integer(10)"), New NMemberInfo(ENMemberVisibility.Private, "reportDate", "date"), New NMemberInfo(ENMemberVisibility.Private, "description", "blob")})
            activePage.Items.Add(shapeSupportRequest)
            Dim shapeUser As NShape = CreateUmlShape("User", New NMemberInfo() {New NMemberInfo(ENMemberVisibility.Public, "ID", "integer(10)"), New NMemberInfo(ENMemberVisibility.Public, "firstName", "varchar(50)"), New NMemberInfo(ENMemberVisibility.Protected, "lastName", "varchar(50)"), New NMemberInfo(ENMemberVisibility.Private, "phone", "varchar(12)"), New NMemberInfo(ENMemberVisibility.Private, "email", "varchar(50)"), New NMemberInfo(ENMemberVisibility.Private, "address", "blob"), New NMemberInfo(ENMemberVisibility.Private, "remarks", "blob")})
            activePage.Items.Add(shapeUser)

            ' Connect the shapes
            Connect(GetShapeByName("DeviceCategory"), "CategoryID", GetShapeByName("Device"), "DeviceCategory")
            Connect(GetShapeByName("Device"), "DeviceID", GetShapeByName("SupportRequest"), "Device")
            Connect(GetShapeByName("User"), "ID", GetShapeByName("SupportRequest"), "User")

            ' Subscribe to the drawing view's Registered event to layout the shapes
            ' when the drawing view is registered in its owner document
            AddHandler m_DrawingView.Registered, AddressOf OnDrawingViewRegistered
        End Sub

#End Region

#Region "Implementation"

        ''' <summary>
        ''' Creates the rule for one to many connectors.
        ''' </summary>
        ''' <returns></returns>
        Private Function CreateConnectorOneToManyRule() As NRule
            Dim rule As NRule = New NRule()
            Dim sb As NSelectorBuilder = rule.GetSelectorBuilder()
            sb.Start()
            sb.Type(NGeometry.NGeometrySchema)
            sb.ChildOf()
            sb.UserClass(ConnectorOneToManyClassName)
            sb.End()
            rule.Declarations.Add(New NValueDeclaration(Of NStroke)(NGeometry.StrokeProperty, New NStroke(1, NColor.Black, ENDashStyle.Dash)))
            rule.Declarations.Add(New NValueDeclaration(Of NArrowhead)(NGeometry.BeginArrowheadProperty, New NArrowhead(ENArrowheadShape.VerticalLine, 8, 8, Nothing, New NStroke(1, NColor.Black))))
            rule.Declarations.Add(New NValueDeclaration(Of NArrowhead)(NGeometry.EndArrowheadProperty, New NArrowhead(ENArrowheadShape.InvertedLineArrowWithCircleNoFill, 8, 8, Nothing, New NStroke(1, NColor.Black))))
            Return rule
        End Function
        ''' <summary>
        ''' Creates a one to many connector from the member1 of shape1 to
        ''' member2 of shape2.
        ''' </summary>
        ''' <paramname="shape1"></param>
        ''' <paramname="member1"></param>
        ''' <paramname="shape2"></param>
        ''' <paramname="member2"></param>
        Private Sub Connect(ByVal shape1 As NShape, ByVal member1 As String, ByVal shape2 As NShape, ByVal member2 As String)
            Dim connector As NRoutableConnector = New NRoutableConnector()
            connector.UserClass = ConnectorOneToManyClassName
            m_DrawingView.ActivePage.Items.Add(connector)

            ' Get or create the ports
            Dim port1 = GetOrCreatePort(shape1, member1)
            Dim port2 = GetOrCreatePort(shape2, member2)
            If port1 Is Nothing Then Throw New ArgumentException("A member with name '" & member1 & "' not found in shape '" & shape1.Name & "'", "member")
            If port1 Is Nothing Then Throw New ArgumentException("A member with name '" & member2 & "' not found in shape '" & shape2.Name & "'", "member")

            ' Connect the ports
            connector.GlueBeginToPort(port1)
            connector.GlueEndToPort(port2)
        End Sub
        ''' <summary>
        ''' Gets the port with the given name or creates one if a port with the given name
        ''' does not exist in the specified shape.
        ''' </summary>
        ''' <paramname="shape"></param>
        ''' <paramname="member"></param>
        ''' <returns></returns>
        Private Function GetOrCreatePort(ByVal shape As NShape, ByVal member As String) As NPort
            Dim port = shape.GetPortByName(member)
            If port IsNot Nothing Then Return port

            ' The port does not exist, so create it
            Dim label As NLabel = CType(shape.Widget.GetFirstDescendant(New NLabelByTextFilter(member)), NLabel)
            If label Is Nothing Then Return Nothing
            Dim pairBox = CType(label.GetFirstAncestor(NPairBox.NPairBoxSchema), NPairBox)
            Dim stack = CType(pairBox.ParentNode, NStackPanel)
            Dim yRelative As Double = (pairBox.GetAggregationInfo().Index + 0.5) / stack.Count
            port = New NPort(0.5, yRelative, True)
            port.SetDirection(ENBoxDirection.Right)
            shape.Ports.Add(port)
            Return port
        End Function

        ''' <summary>
        ''' Creates an UML class diagram shape.
        ''' </summary>
        ''' <paramname="name"></param>
        ''' <paramname="memberInfos"></param>
        ''' <returns></returns>
        Private Function CreateUmlShape(ByVal name As String, ByVal memberInfos As NMemberInfo()) As NShape
            ' Create the shape
            Dim shape As NShape = New NShape()
            shape.Name = name

            ' Set a rounded rectangle geometry
            Dim drawRectangle As NDrawRectangle = New NDrawRectangle(0, 0, 1, 1)
            drawRectangle.Relative = True
            shape.Geometry.Add(drawRectangle)
            shape.Geometry.CornerRounding = 15

            ' Create a stack panel
            Dim stack As NStackPanel = New NStackPanel()
            stack.Margins = New NMargins(5)
            stack.Direction = ENHVDirection.TopToBottom

            ' Create the title label
            Dim titleLabel As NLabel = New NLabel(name)
            titleLabel.TextAlignment = ENContentAlignment.MiddleCenter
            titleLabel.Border = NBorder.CreateFilledBorder(NColor.Black)
            titleLabel.BorderThickness = New NMargins(0, 0, 0, 1)
            stack.Add(titleLabel)

            ' Create the member info pair boxes
            For i = 0 To memberInfos.Length - 1
                stack.Add(CreatePairBox(memberInfos(i)))
            Next

            shape.Widget = New NUniSizeBoxGroup(stack)
            BindSizeToDesiredSize(shape)
            Return shape
        End Function
        ''' <summary>
        ''' Creates a pair box from the given member information.
        ''' </summary>
        ''' <paramname="memberInfo"></param>
        ''' <returns></returns>
        Private Function CreatePairBox(ByVal memberInfo As NMemberInfo) As NPairBox
            Dim pairBox As NPairBox = New NPairBox(CChar(memberInfo.Visibility) & memberInfo.Name, memberInfo.Type, True)
            pairBox.Spacing = NDesign.HorizontalSpacing * 2
            pairBox.FillMode = ENStackFillMode.Equal
            pairBox.FitMode = ENStackFitMode.Last

            Select Case memberInfo.Visibility
                Case ENMemberVisibility.Public
                    ' Set bold font style
                    pairBox.Font = New NFont(NFontDescriptor.DefaultSansFamilyName, 9, ENFontStyle.Bold)
                Case ENMemberVisibility.Protected
                    ' Set italic font style
                    pairBox.Font = New NFont(NFontDescriptor.DefaultSansFamilyName, 9, ENFontStyle.Italic)
                    ' Do not change the font style
                Case ENMemberVisibility.Private
            End Select

            Return pairBox
        End Function
        ''' <summary>
        ''' Binds the size of the shape to the embedded widget desired size.
        ''' </summary>
        ''' <paramname="shape"></param>
        Private Sub BindSizeToDesiredSize(ByVal shape As NShape)
            Dim widget = shape.Widget

            ' bind shape width to button desired width
            Dim bx As NBindingFx = New NBindingFx(widget, NBoxElement.DesiredWidthProperty)
            bx.Guard = True
            shape.SetFx(NShape.WidthProperty, bx)

            ' bind shape height to button desired height
            Dim by As NBindingFx = New NBindingFx(widget, NBoxElement.DesiredHeightProperty)
            by.Guard = True
            shape.SetFx(NShape.HeightProperty, by)
            shape.AllowResizeX = False
            shape.AllowRotate = False
            shape.AllowResizeY = False
        End Sub
        ''' <summary>
        ''' Gets the first shape with the given name in the drawing document's active page.
        ''' </summary>
        ''' <paramname="name"></param>
        ''' <returns></returns>
        Private Function GetShapeByName(ByVal name As String) As NShape
            Dim activePage = m_DrawingView.ActivePage
            Return CType(activePage.GetFirstDescendant(New NShapeByNameFilter(name)), NShape)
        End Function

        ''' <summary>
        ''' Arranges the shapes in the active page.
        ''' </summary>
        Private Sub ArrangeDiagram()
            ' Create and configure a layout
            Dim layout As NLayeredGraphLayout = New NLayeredGraphLayout()

            ' Get all top-level shapes that reside in the active page
            Dim activePage = m_DrawingView.ActivePage
            Dim shapes = activePage.GetShapes(False)

            ' Create a layout context and use it to arrange the shapes using the current layout
            Dim layoutContext As NDrawingLayoutContext = New NDrawingLayoutContext(m_DrawingView.Document, activePage)
            layout.Arrange(shapes.CastAll(Of Object)(), layoutContext)

            ' Size the page to the content size
            activePage.SizeToContent()
        End Sub

#End Region

#Region "Event Handlers"

        ''' <summary>
        ''' Called when the drawing view is registered to its owner document.
        ''' </summary>
        ''' <paramname="arg"></param>
        Private Sub OnDrawingViewRegistered(ByVal arg As NEventArgs)
            ' Evaluate the drawing document
            m_DrawingView.Document.Evaluate()

            ' Layout the shapes
            ArrangeDiagram()
        End Sub

#End Region

#Region "Schema"

        ''' <summary>
        ''' Schema associated with NUmlClassDiagramExample.
        ''' </summary>
        Public Shared ReadOnly NUmlClassDiagramExampleSchema As NSchema

#End Region

#Region "Fields"

        Private m_DrawingView As NDrawingView

#End Region

#Region "Constants"

        Private Const ConnectorOneToManyClassName As String = "ConnectorOneToMany"

#End Region

#Region "Nested Types"

        Private Enum ENMemberVisibility
            [Public] = Microsoft.VisualBasic.AscW("+"c)
            [Protected] = Microsoft.VisualBasic.AscW("#"c)
            [Private] = Microsoft.VisualBasic.AscW("-"c)
        End Enum

        Private Structure NMemberInfo
            Public Sub New(ByVal visibility As ENMemberVisibility, ByVal name As String, ByVal type As String)
                Me.Visibility = visibility
                Me.Name = name
                Me.Type = type
            End Sub

            Public Visibility As ENMemberVisibility
            Public Name As String
            Public Type As String
        End Structure

        Private Class NShapeByNameFilter
            Implements INFilter(Of NNode)

            Public Sub New(ByVal name As String)
                Me.Name = name
            End Sub

            Public Function Filter(ByVal item As NNode) As Boolean Implements INFilter(Of NNode).Filter
                Dim shape As NShape = TryCast(item, NShape)
                Return shape IsNot Nothing AndAlso Equals(shape.Name, Name)
            End Function

            Public Name As String
        End Class

        Private Class NLabelByTextFilter
            Implements INFilter(Of NNode)

            Public Sub New(ByVal text As String)
                Me.Text = text
            End Sub

            Public Function Filter(ByVal item As NNode) As Boolean Implements INFilter(Of NNode).Filter
                Dim label As NLabel = TryCast(item, NLabel)
                Return label IsNot Nothing AndAlso Equals(label.Text.Substring(1), Text)
            End Function

            Public Text As String
        End Class

#End Region
    End Class
End Namespace

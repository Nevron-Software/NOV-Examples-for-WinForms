Imports Nevron.Nov.Diagram
Imports Nevron.Nov.Diagram.Layout
Imports Nevron.Nov.Diagram.Shapes
Imports Nevron.Nov.Dom
Imports Nevron.Nov.Editors
Imports Nevron.Nov.Graphics
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.Diagram
    Public Class NBalloonTreeLayoutExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' Default constructor.
        ''' </summary>
        Public Sub New()
        End Sub

        ''' <summary>
        ''' Static constructor.
        ''' </summary>
        Shared Sub New()
            NBalloonTreeLayoutExampleSchema = NSchema.Create(GetType(NBalloonTreeLayoutExample), NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            ' Create a simple drawing
            Dim drawingViewWithRibbon As NDrawingViewWithRibbon = New NDrawingViewWithRibbon()
            m_DrawingView = drawingViewWithRibbon.View
            m_DrawingView.Document.HistoryService.Pause()

            Try
                InitDiagram(m_DrawingView.Document)
            Finally
                m_DrawingView.Document.HistoryService.Resume()
            End Try

            Return drawingViewWithRibbon
        End Function

        Protected Overrides Function CreateExampleControls() As NWidget
            AddHandler m_Layout.Changed, AddressOf OnLayoutChanged
            Dim stack As NStackPanel = New NStackPanel()

            ' property editor
            Dim editor As NEditor = NDesigner.GetDesigner(m_Layout).CreateInstanceEditor(m_Layout)
            stack.Add(New NGroupBox("Properties", editor))
            Dim arrangeButton As NButton = New NButton("Arrange Diagram")
            AddHandler arrangeButton.Click, AddressOf OnArrangeButtonClick
            stack.Add(arrangeButton)

            ' items stack
            Dim itemsStack As NStackPanel = New NStackPanel()

            ' NOTE: For Tree layouts we provide the user with the ability to generate random tree diagrams so that he/she can test the layouts
            Dim randomTree1Button As NButton = New NButton("Random Tree (max 6 levels, max 3 branch nodes)")
            AddHandler randomTree1Button.Click, AddressOf OnRandomTree1ButtonClick
            itemsStack.Add(randomTree1Button)
            Dim randomTree2Button As NButton = New NButton("Random Tree (max 8 levels, max 2 branch nodes)")
            AddHandler randomTree2Button.Click, AddressOf OnRandomTree2ButtonClick
            itemsStack.Add(randomTree2Button)
            stack.Add(New NGroupBox("Items", itemsStack))
            Return stack
        End Function

        Protected Overrides Function GetExampleDescription() As String
            Return "
<p>
    The balloon tree layout tries to compact the drawing area of the tree 
    by placing the vertices in balloons around the tree root.
    It produces straight line tree drawings. 
</p>
<p>        
    Following is a brief description of its properties:
</p>
<ul>
	<li>
		<b>ParentChildSpacing</b> - the preferred spacing between a parent and a child
		vertex in the layout direction. The real spacing may be different for some nodes,
		because the layout does not allow overlapping.
	</li>
	<li>
		<b>VertexSpacing</b> - the minimal spacing between 2 nodes in the layout.
		If set to 0, the nodes may touch each other.
	</li>
	<li>
		<b>ChildWedge</b> - the sector angle (measured in degrees) for the children
		of each vertex.
	</li>
	<li>
		<b>RootWedge</b> - the sector angle (measured in degrees) for the children
		of the root vertex.
	</li>
	<li>
		<b>StartAngle</b> - the start angle for the children of the root vertex, measured in
		degrees anticlockwise from the x-axis.
	</li>
</ul>
<p>
	To experiment with the layout just change its properties from the property grid and click the <b>Layout</b> button.
</p>            
            "
        End Function

        Private Sub InitDiagram(ByVal drawingDocument As NDrawingDocument)
            ' Hide ports
            drawingDocument.Content.ScreenVisibility.ShowPorts = False

            ' Create a template graph
            Dim tree As NGenericTreeTemplate = New NGenericTreeTemplate()
            tree.EdgesUserClass = "Connector"
            tree.Levels = 4
            tree.BranchNodes = 4
            tree.HorizontalSpacing = 10
            tree.VerticalSpacing = 10
            tree.ConnectorType = ENConnectorShape.RoutableConnector
            tree.VerticesShape = VertexShape
            tree.VerticesSize = VertexSize
            tree.Create(drawingDocument)

            ' Arrange diagram
            ArrangeDiagram(drawingDocument)

            ' Fit active page
            drawingDocument.Content.ActivePage.ZoomMode = ENZoomMode.Fit
        End Sub

#End Region

#Region "Implementation"

        ''' <summary>
        ''' Arranges the shapes in the active page.
        ''' </summary>
        ''' <paramname="drawingDocument"></param>
        Private Sub ArrangeDiagram(ByVal drawingDocument As NDrawingDocument)
            ' get all top-level shapes that reside in the active page
            Dim activePage = drawingDocument.Content.ActivePage
            Dim shapes = activePage.GetShapes(False)

            ' create a layout context and use it to arrange the shapes using the current layout
            Dim layoutContext As NDrawingLayoutContext = New NDrawingLayoutContext(drawingDocument, activePage)
            m_Layout.Arrange(shapes.CastAll(Of Object)(), layoutContext)

            ' size the page to the content size
            activePage.SizeToContent()
        End Sub

#End Region

#Region "Event Handlers"

        Private Sub OnRandomTree1ButtonClick(ByVal arg As NEventArgs)
            Dim drawingDocument = m_DrawingView.Document
            drawingDocument.StartHistoryTransaction("Create Random Tree 1")

            Try
                drawingDocument.Content.ActivePage.Items.Clear()

                ' create a random tree
                Dim tree As NGenericTreeTemplate = New NGenericTreeTemplate()
                tree.EdgesUserClass = "Connector"
                tree.Levels = 6
                tree.BranchNodes = 3
                tree.HorizontalSpacing = 10
                tree.VerticalSpacing = 10
                tree.VerticesShape = VertexShape
                tree.VerticesSize = VertexSize
                tree.Balanced = True
                tree.VertexSizeDeviation = 0
                tree.Create(drawingDocument)

                ' layout the tree
                ArrangeDiagram(drawingDocument)
            Finally
                drawingDocument.CommitHistoryTransaction()
            End Try
        End Sub

        Private Sub OnRandomTree2ButtonClick(ByVal arg As NEventArgs)
            Dim drawingDocument = m_DrawingView.Document
            drawingDocument.StartHistoryTransaction("Create Random Tree 2")

            Try
                drawingDocument.Content.ActivePage.Items.Clear()

                ' create a random tree
                Dim tree As NGenericTreeTemplate = New NGenericTreeTemplate()
                tree.EdgesUserClass = "Connector"
                tree.Levels = 8
                tree.BranchNodes = 2
                tree.HorizontalSpacing = 10
                tree.VerticalSpacing = 10
                tree.VerticesShape = VertexShape
                tree.VerticesSize = VertexSize
                tree.Balanced = True
                tree.VertexSizeDeviation = 0
                tree.Create(drawingDocument)

                ' layout the tree
                ArrangeDiagram(drawingDocument)
            Finally
                drawingDocument.CommitHistoryTransaction()
            End Try
        End Sub

        Private Sub OnLayoutChanged(ByVal arg As NEventArgs)
            ArrangeDiagram(m_DrawingView.Document)
        End Sub

        Private Sub OnArrangeButtonClick(ByVal arg As NEventArgs)
            ArrangeDiagram(m_DrawingView.Document)
        End Sub

#End Region

#Region "Fields"

        Private m_DrawingView As NDrawingView
        Private m_Layout As NBalloonTreeLayout = New NBalloonTreeLayout()

#End Region

#Region "Schema"

        ''' <summary>
        ''' Schema associated with NBalloonTreeLayoutExample.
        ''' </summary>
        Public Shared ReadOnly NBalloonTreeLayoutExampleSchema As NSchema

#End Region

#Region "Constants"

        Private Const VertexShape As ENBasicShape = ENBasicShape.Circle
        Private Shared ReadOnly VertexSize As NSize = New NSize(60, 60)

#End Region
    End Class
End Namespace

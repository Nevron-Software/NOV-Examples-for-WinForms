Imports System
Imports Nevron.Nov.Diagram
Imports Nevron.Nov.Diagram.Layout
Imports Nevron.Nov.Diagram.Shapes
Imports Nevron.Nov.Dom
Imports Nevron.Nov.Editors
Imports Nevron.Nov.Layout
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.Diagram
    Public Class NStackLayoutExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' Default constructor.
        ''' </summary>
        Public Sub New()
        End Sub

        ''' <summary>
        ''' Static constructor.
        ''' </summary>
        Shared Sub New()
            NStackLayoutExampleSchema = NSchema.Create(GetType(NStackLayoutExample), NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            ' Create a simple drawing
            Dim drawingViewWithRibbon As NDrawingViewWithRibbon = New NDrawingViewWithRibbon()
            m_DrawingView = drawingViewWithRibbon.View
            m_DrawingView.Document.HistoryService.Pause()

            Try
                InitDiagram(m_DrawingView.Document)
            Finally
                m_DrawingView.Document.HistoryService.Resume()
            End Try

            Return drawingViewWithRibbon
        End Function

        Protected Overrides Function CreateExampleControls() As NWidget
            AddHandler m_Layout.Changed, AddressOf OnLayoutChanged
            Dim stack As NStackPanel = New NStackPanel()

            ' property editor
            Dim editor As NEditor = NDesigner.GetDesigner(m_Layout).CreateInstanceEditor(m_Layout)
            stack.Add(New NGroupBox("Properties", editor))
            Dim arrangeButton As NButton = New NButton("Arrange Diagram")
            AddHandler arrangeButton.Click, AddressOf OnArrangeButtonClick
            stack.Add(arrangeButton)

            ' items stack
            Dim itemsStack As NStackPanel = New NStackPanel()

            ' NOTE: For Cells layout we provide the user with the ability to add shapes with different sizes so that he/she can test the layouts
            Dim addSmallItemButton As NButton = New NButton("Add Small Shape")
            AddHandler addSmallItemButton.Click, New [Function](Of NEventArgs)(AddressOf OnAddSmallItemButtonClick)
            itemsStack.Add(addSmallItemButton)
            Dim addLargeItemButton As NButton = New NButton("Add Large Shape")
            AddHandler addLargeItemButton.Click, New [Function](Of NEventArgs)(AddressOf OnAddLargeItemButtonClick)
            itemsStack.Add(addLargeItemButton)
            Dim addRandomItemButton As NButton = New NButton("Add Random Shape")
            AddHandler addRandomItemButton.Click, New [Function](Of NEventArgs)(AddressOf OnAddRandomItemButtonClick)
            itemsStack.Add(addRandomItemButton)
            Dim removeAllItemsButton As NButton = New NButton("Remove All Shapes")
            AddHandler removeAllItemsButton.Click, New [Function](Of NEventArgs)(AddressOf OnRemoveAllItemsButtonClick)
            itemsStack.Add(removeAllItemsButton)
            stack.Add(New NGroupBox("Items", itemsStack))
            Return stack
        End Function

        Protected Overrides Function GetExampleDescription() As String
            Return "
<p>
    The stack layout is a directed constrained cells layout, which stacks the cells in horizontal or vertical order.
    Depending on the layout direction the layout is constrained by either width or height.
</p>
<p>
	The most important properties of this layout are:
	<ul>
		<li>
			<b>Direction</b> - determines the direction in which the layout arranges adjacent cells.
		</li>
		<li>
		    <b>HorizontalContentPlacement and VerticalContentPlacement</b> - determine the default placement
		        of the cell content in regards to the X or the Y dimension of the cell bounds.
		</li>
		<li>
		    <b>HorizontalSpacing and VerticalSpacing</b> - determine the minimal spacing between 2 cells in
		        horizontal and vertical direction respectively.
		</li>
		<li>
			<b>FillMode</b> - when the size of the content is smaller than the container size 
			the FillMode property is taken into account. Possible values are:
			<ul>
			    <li>None - no filling is performed</li>
			    <li>Equal - all shapes are equally inflated</li>
			    <li>Proportional - shapes are inflated proportionally to their size</li>
			    <li>First - shapes are inflated in forward order until content fills the area</li>
			    <li>Last - shapes are inflated in reverse order until content fills the area</li>
			</ul>
			In all cases the maximal size constraints of each shape are not broken.
		</li>
		<li>
			<b>FitMode</b> - when the size of the content is larger than the container size 
			the FitMode property is taken into account. Possible values are:
			<ul>
			    <li>None - no fitting is performed</li>
			    <li>Equal - all shapes are equally deflated</li>
			    <li>Proportional - shapes are deflated proportionally to their size</li>
			    <li>First - shapes are deflated in forward order until content fits the area</li>
			    <li>Last - shapes are deflated in reverse order until content fits the area</li>
			</ul>
			In all cases the minimal size constraints of each shape are not broken.
		</li>
	</ul>
</p>
<p>
	To experiment with their behavior just change the properties of the layout in the property
	grid and click the button <b>Layout</b> button. 
</p>		
<p>	
	Change the drawing width and height to see how the layout behaves with a different layout area.
</p>
            "
        End Function

        Private Sub InitDiagram(ByVal drawingDocument As NDrawingDocument)
            ' Hide ports
            drawingDocument.Content.ScreenVisibility.ShowPorts = False

            ' Create some shapes
            Dim activePage = drawingDocument.Content.ActivePage
            Dim basicShapes As NBasicShapeFactory = New NBasicShapeFactory()

            For i = 0 To 20 - 1
                Dim shape = basicShapes.CreateShape(ENBasicShape.Rectangle)
                activePage.Items.Add(shape)
            Next

            ' Arrange diagram
            ArrangeDiagram(drawingDocument)

            ' Fit page
            drawingDocument.Content.ActivePage.ZoomMode = ENZoomMode.Fit
        End Sub

#End Region

#Region "Implementation"

        ''' <summary>
        ''' Arranges the shapes in the active page.
        ''' </summary>
        ''' <paramname="drawingDocument"></param>
        Private Sub ArrangeDiagram(ByVal drawingDocument As NDrawingDocument)
            ' get all top-level shapes that reside in the active page
            Dim activePage = drawingDocument.Content.ActivePage
            Dim shapes = activePage.GetShapes(False)

            ' create a layout context and use it to arrange the shapes using the current layout
            Dim layoutContext As NDrawingLayoutContext = New NDrawingLayoutContext(drawingDocument, activePage)
            m_Layout.Arrange(shapes.CastAll(Of Object)(), layoutContext)

            ' size the page to the content size
            activePage.SizeToContent()
        End Sub

        Private Function CreateShape() As NShape
            Dim factory As NBasicShapeFactory = New NBasicShapeFactory()
            Return factory.CreateShape(ENBasicShape.Rectangle)
        End Function

        Private Sub OnAddSmallItemButtonClick(ByVal args As NEventArgs)
            Dim shape As NShape = CreateShape()
            shape.Width = 25
            shape.Height = 25
            m_DrawingView.ActivePage.Items.Add(shape)
            ArrangeDiagram(m_DrawingView.Document)
        End Sub

        Private Sub OnAddLargeItemButtonClick(ByVal args As NEventArgs)
            Dim shape As NShape = CreateShape()
            shape.Width = 60
            shape.Height = 60
            m_DrawingView.ActivePage.Items.Add(shape)
            ArrangeDiagram(m_DrawingView.Document)
        End Sub

        Private Sub OnAddRandomItemButtonClick(ByVal args As NEventArgs)
            Dim range = 30
            Dim rnd As Random = New Random()
            Dim shape As NShape = CreateShape()
            shape.Width = rnd.Next(range) + range
            shape.Height = rnd.Next(range) + range
            m_DrawingView.ActivePage.Items.Add(shape)
            ArrangeDiagram(m_DrawingView.Document)
        End Sub

        Private Sub OnRemoveAllItemsButtonClick(ByVal args As NEventArgs)
            m_DrawingView.Document.StartHistoryTransaction("Remove All Items")

            Try
                m_DrawingView.Document.Content.ActivePage.Items.Clear()
            Finally
                m_DrawingView.Document.CommitHistoryTransaction()
            End Try
        End Sub

#End Region

#Region "Event Handlers"

        Private Sub OnLayoutChanged(ByVal arg As NEventArgs)
            ArrangeDiagram(m_DrawingView.Document)
        End Sub

        Protected Overridable Sub OnArrangeButtonClick(ByVal arg As NEventArgs)
            ArrangeDiagram(m_DrawingView.Document)
        End Sub

#End Region

#Region "Fields"

        Private m_DrawingView As NDrawingView
        Private m_Layout As NStackLayout = New NStackLayout()

#End Region

#Region "Schema"

        ''' <summary>
        ''' Schema associated with NStackLayoutExample.
        ''' </summary>
        Public Shared ReadOnly NStackLayoutExampleSchema As NSchema

#End Region
    End Class
End Namespace

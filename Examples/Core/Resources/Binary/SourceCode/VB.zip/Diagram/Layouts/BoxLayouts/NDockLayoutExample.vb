Imports System
Imports Nevron.Nov.Diagram
Imports Nevron.Nov.Diagram.Layout
Imports Nevron.Nov.Diagram.Shapes
Imports Nevron.Nov.Dom
Imports Nevron.Nov.Editors
Imports Nevron.Nov.Graphics
Imports Nevron.Nov.Layout
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.Diagram
    Public Class NDockLayoutExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' Default constructor.
        ''' </summary>
        Public Sub New()
        End Sub
        ''' <summary>
        ''' Static constructor.
        ''' </summary>
        Shared Sub New()
            NDockLayoutExampleSchema = NSchema.Create(GetType(NDockLayoutExample), NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            ' Create a simple drawing
            Dim drawingViewWithRibbon As NDrawingViewWithRibbon = New NDrawingViewWithRibbon()
            m_DrawingView = drawingViewWithRibbon.View
            m_DrawingView.Document.HistoryService.Pause()

            Try
                InitDiagram(m_DrawingView.Document)
            Finally
                m_DrawingView.Document.HistoryService.Resume()
            End Try

            Return drawingViewWithRibbon
        End Function

        Protected Overrides Function CreateExampleControls() As NWidget
            AddHandler m_Layout.Changed, AddressOf OnLayoutChanged
            Dim stack As NStackPanel = New NStackPanel()

            ' property editor
            Dim editor As NEditor = NDesigner.GetDesigner(m_Layout).CreateInstanceEditor(m_Layout)
            stack.Add(New NGroupBox("Properties", editor))
            Dim arrangeButton As NButton = New NButton("Arrange Diagram")
            AddHandler arrangeButton.Click, AddressOf OnArrangeButtonClick
            stack.Add(arrangeButton)

            ' items stack
            Dim itemsStack As NStackPanel = New NStackPanel()

            ' NOTE: For Cells layout we provide the user with the ability to add shapes with different sizes so that he/she can test the layouts
            Dim addSmallItemButton As NButton = New NButton("Add Small Shape")
            AddHandler addSmallItemButton.Click, New [Function](Of NEventArgs)(AddressOf OnAddSmallItemButtonClick)
            itemsStack.Add(addSmallItemButton)
            Dim addLargeItemButton As NButton = New NButton("Add Large Shape")
            AddHandler addLargeItemButton.Click, New [Function](Of NEventArgs)(AddressOf OnAddLargeItemButtonClick)
            itemsStack.Add(addLargeItemButton)
            Dim addRandomItemButton As NButton = New NButton("Add Random Shape")
            AddHandler addRandomItemButton.Click, New [Function](Of NEventArgs)(AddressOf OnAddRandomItemButtonClick)
            itemsStack.Add(addRandomItemButton)
            Dim removeAllItemsButton As NButton = New NButton("Remove All Shapes")
            AddHandler removeAllItemsButton.Click, New [Function](Of NEventArgs)(AddressOf OnRemoveAllItemsButtonClick)
            itemsStack.Add(removeAllItemsButton)
            stack.Add(New NGroupBox("Items", itemsStack))
            Return stack
        End Function

        Protected Overrides Function GetExampleDescription() As String
            Return "
<p>     
    The dock layout is a space eating cells layout, which places vertices at per-vertex specified docking areas of the currently available layout area.
</p>
<p>
	The most important properties of this layout are:
	<ul>
		<li>
		    <b>HorizontalContentPlacement and VerticalContentPlacement</b> - determine the default placement
		        of the cell content in regards to the X or the Y dimension of the cell bounds.
		</li>
		<li>
		    <b>HorizontalSpacing and VerticalSpacing</b> - determine the minimal spacing between 2 cells in
		        horizontal and vertical direction respectively.
		</li>
		<li>
			<b>FillMode and FitMode</b> - when the size of the content is smaller than the container size 
			the FillMode property is taken into account. If the content size is greater than the container,
			then the layout takes the value of the FitMode into account. Possible values are:
			<ul>
			    <li>None - the dock layout does not attempt to resolve the available/insufficient area problem</li>
			    <li>Equal - the dock inflates/deflates the size of each object with equal amount of space in order
			        to resolve the available/insufficient area problem</li>
			    <li>CenterFirst - the dock inflates/deflates the size of the center object in the dock, then the size of the
			        pair formed by the previous and the next one and so on until the available/insufficient area
			        problem is resolved</li>
			    <li>SidesFirst - the dock inflates/deflates the size of the pair formed by the first and the last
			        object in the dock, then the size of the pair formed by the next and the previous one and so
			        on until the available/insufficient area problem is resolved</li>
			    <li>ForwardOrder - the bodies are resized in the order they were added</li>
			    <li>ReverseOrder - the bodies are resized in reverse order to the order they were added</li>
			</ul>
			In all cases the minimal and maximal size constraints of each shape are not broken, so it is possible
			the dock cannot resolve the available/insufficient area problem completely.
		</li>
	</ul>
</p>
<p>
	To experiment with the layout just change the properties of the layout in the property grid and click the <b>Layout</b> button.
</p>
            "
        End Function

        Private Sub InitDiagram(ByVal drawingDocument As NDrawingDocument)
            ' Hide ports
            drawingDocument.Content.ScreenVisibility.ShowPorts = False
            Dim activePage = drawingDocument.Content.ActivePage
            Dim basicShapes As NBasicShapeFactory = New NBasicShapeFactory()
            Dim min = 100
            Dim max = 200
            Dim shape As NShape
            Dim random As Random = New Random()

            For i = 0 To 5 - 1
                shape = basicShapes.CreateShape(ENBasicShape.Rectangle)
                Dim shapeLightColors As NColor() = New NColor() {New NColor(236, 97, 49), New NColor(247, 150, 56), New NColor(68, 90, 108), New NColor(129, 133, 133), New NColor(255, 165, 109)}
                Dim shapeDarkColors As NColor() = New NColor() {New NColor(246, 176, 152), New NColor(251, 203, 156), New NColor(162, 173, 182), New NColor(192, 194, 194), New NColor(255, 210, 182)}
                shape.Geometry.Fill = New NStockGradientFill(ENGradientStyle.Horizontal, ENGradientVariant.Variant3, shapeLightColors(i), shapeDarkColors(i))
                shape.Geometry.Stroke = New NStroke(1, New NColor(68, 90, 108))


                ' Generate random width and height
                Dim width As Single = random.Next(min, max)
                Dim height As Single = random.Next(min, max)

                Select Case i
                    Case 0
                        shape.LayoutData.DockArea = ENDockArea.Top
                        shape.Text = "Top (" & i.ToString() & ")"
                    Case 1
                        shape.LayoutData.DockArea = ENDockArea.Bottom
                        shape.Text = "Bottom (" & i.ToString() & ")"
                    Case 2
                        shape.LayoutData.DockArea = ENDockArea.Left
                        shape.Text = "Left (" & i.ToString() & ")"
                    Case 3
                        shape.LayoutData.DockArea = ENDockArea.Right
                        shape.Text = "Right (" & i.ToString() & ")"
                    Case 4
                        shape.LayoutData.DockArea = ENDockArea.Center
                        shape.Text = "Center (" & i.ToString() & ")"
                End Select

                shape.SetBounds(New NRectangle(0, 0, width, height))
                activePage.Items.Add(shape)
            Next

            ' Arrange diagram
            ArrangeDiagram(drawingDocument)

            ' Fit page
            drawingDocument.Content.ActivePage.ZoomMode = ENZoomMode.Fit
        End Sub

#End Region

#Region "Implementation"

        ''' <summary>
        ''' Arranges the shapes in the active page.
        ''' </summary>
        ''' <paramname="drawingDocument"></param>
        Private Sub ArrangeDiagram(ByVal drawingDocument As NDrawingDocument)
            ' get all top-level shapes that reside in the active page
            Dim activePage = drawingDocument.Content.ActivePage
            Dim shapes = activePage.GetShapes(False)

            ' create a layout context and use it to arrange the shapes using the current layout
            Dim layoutContext As NDrawingLayoutContext = New NDrawingLayoutContext(drawingDocument, activePage)
            m_Layout.Arrange(shapes.CastAll(Of Object)(), layoutContext)

            ' size the page to the content size
            activePage.SizeToContent()
        End Sub

        Private Function CreateShape() As NShape
            Dim factory As NBasicShapeFactory = New NBasicShapeFactory()
            Return factory.CreateShape(ENBasicShape.Rectangle)
        End Function

        Private Sub OnAddSmallItemButtonClick(ByVal args As NEventArgs)
            Dim shape As NShape = CreateShape()
            shape.Width = 25
            shape.Height = 25
            m_DrawingView.ActivePage.Items.Add(shape)
            ArrangeDiagram(m_DrawingView.Document)
        End Sub

        Private Sub OnAddLargeItemButtonClick(ByVal args As NEventArgs)
            Dim shape As NShape = CreateShape()
            shape.Width = 60
            shape.Height = 60
            m_DrawingView.ActivePage.Items.Add(shape)
            ArrangeDiagram(m_DrawingView.Document)
        End Sub

        Private Sub OnAddRandomItemButtonClick(ByVal args As NEventArgs)
            Dim range = 30
            Dim rnd As Random = New Random()
            Dim shape As NShape = CreateShape()
            shape.Width = rnd.Next(range) + range
            shape.Height = rnd.Next(range) + range
            m_DrawingView.ActivePage.Items.Add(shape)
            ArrangeDiagram(m_DrawingView.Document)
        End Sub

        Private Sub OnRemoveAllItemsButtonClick(ByVal args As NEventArgs)
            m_DrawingView.Document.StartHistoryTransaction("Remove All Items")

            Try
                m_DrawingView.Document.Content.ActivePage.Items.Clear()
            Finally
                m_DrawingView.Document.CommitHistoryTransaction()
            End Try
        End Sub

#End Region

#Region "Event Handlers"

        Private Sub OnLayoutChanged(ByVal arg As NEventArgs)
            ArrangeDiagram(m_DrawingView.Document)
        End Sub

        Protected Overridable Sub OnArrangeButtonClick(ByVal arg As NEventArgs)
            ArrangeDiagram(m_DrawingView.Document)
        End Sub

#End Region

#Region "Fields"

        Private m_DrawingView As NDrawingView
        Private m_Layout As NDockLayout = New NDockLayout()

#End Region

#Region "Schema"

        ''' <summary>
        ''' Schema associated with NDockLayoutExample.
        ''' </summary>
        Public Shared ReadOnly NDockLayoutExampleSchema As NSchema

#End Region
    End Class
End Namespace

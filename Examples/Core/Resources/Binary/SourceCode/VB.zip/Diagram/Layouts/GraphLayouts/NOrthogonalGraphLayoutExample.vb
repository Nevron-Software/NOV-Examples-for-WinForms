Imports Nevron.Nov.Diagram
Imports Nevron.Nov.Diagram.Layout
Imports Nevron.Nov.Diagram.Shapes
Imports Nevron.Nov.Dom
Imports Nevron.Nov.Editors
Imports Nevron.Nov.Graphics
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.Diagram
    Public Class NOrthogonalGraphLayoutExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' Default constructor.
        ''' </summary>
        Public Sub New()
        End Sub

        ''' <summary>
        ''' Static constructor.
        ''' </summary>
        Shared Sub New()
            NOrthogonalGraphLayoutExampleSchema = NSchema.Create(GetType(NOrthogonalGraphLayoutExample), NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            ' Create a simple drawing
            Dim drawingViewWithRibbon As NDrawingViewWithRibbon = New NDrawingViewWithRibbon()
            m_DrawingView = drawingViewWithRibbon.View
            m_DrawingView.Document.HistoryService.Pause()

            Try
                InitDiagram(m_DrawingView.Document)
            Finally
                m_DrawingView.Document.HistoryService.Resume()
            End Try

            Return drawingViewWithRibbon
        End Function

        Protected Overrides Function CreateExampleControls() As NWidget
            AddHandler m_Layout.Changed, AddressOf OnLayoutChanged
            Dim stack As NStackPanel = New NStackPanel()

            ' property editor
            Dim editor As NEditor = NDesigner.GetDesigner(m_Layout).CreateInstanceEditor(m_Layout)
            stack.Add(New NGroupBox("Properties", editor))
            Dim arrangeButton As NButton = New NButton("Arrange Diagram")
            AddHandler arrangeButton.Click, AddressOf OnArrangeButtonClick
            stack.Add(arrangeButton)

            ' items stack
            Dim itemsStack As NStackPanel = New NStackPanel()

            ' NOTE: For Graph layouts we provide the user with the ability to generate random graph diagrams so that he/she can test the layouts
            Dim randomGraph1Button As NButton = New NButton("Random Graph (10 vertices, 15 edges)")
            AddHandler randomGraph1Button.Click, AddressOf OnRandomGraph1ButtonClick
            itemsStack.Add(randomGraph1Button)
            Dim randomGraph2Button As NButton = New NButton("Random Graph (20 vertices, 30 edges)")
            AddHandler randomGraph2Button.Click, AddressOf OnRandomGraph2ButtonClick
            itemsStack.Add(randomGraph2Button)
            stack.Add(New NGroupBox("Items", itemsStack))
            Return stack
        End Function

        Protected Overrides Function GetExampleDescription() As String
            Return "
<p>
    The orthogonal graph layout produces orthogonal graph drawings of all types of graphs
    (including those with self-loops and duplicate edges). It tries to compact the graph
    drawing area and also to minimize the number of edge crossings and bends.
</p>
<p>
	The most important properties are:
	<ul>
		<li>
			<b>CellSpacing</b> - determines the distance between 2 grid cells. For example if a grid
			cell is calculated to have a size of 100 x 100 and the CellSpacing property is set to
			10, then the cell size will be 120 x 120. Note that the node is always placed in the
			middle of the cell.
		</li>
		<li>
			<b>GridCellSizeMode</b> - this property is an enum with 2 possible values: GridCellSizeMode.
			GridBased and GridCellSizeMode.CellBased. If set to the first the maximal size of a
			node in the graph is determined and all cells are scaled to that size. More area
			efficient is the second value - it causes the dimensions of each column and row
			dimensions to be determined according to the size of the cells they contain.
		</li>
		<li>
			<b>Compact</b> - if set to true, a compaction algorithm will be applied to the embedded
			graph. This will decrease the total area of the drawing with 20 to 50 % (in the average
			case) at the cost of some additional time needed for the calculations.
		</li>
		<li>
			<b>PlugSpacing</b> - determines the spacing between the plugs of a node.
			You can set a fixed amount of spacing or a proportional spacing, which means that the plugs
			are distributed along the whole side of the node.
		</li>
	</ul>
</p>
<p>
	To experiment with the layout just change its properties from the property grid and click the <b>Layout</b> button. 
    To see the layout in action on a different graph, just click the <b>Random Graph</b> button. 
</p>
            "
        End Function

        Private Sub InitDiagram(ByVal drawingDocument As NDrawingDocument)
            Const width As Double = 40
            Const height As Double = 40
            Const distance As Double = 80

            ' Hide ports
            drawingDocument.Content.ScreenVisibility.ShowPorts = False
            Dim basicShapes As NBasicShapeFactory = New NBasicShapeFactory()
            Dim activePage = drawingDocument.Content.ActivePage
            Dim from = New Integer() {1, 1, 1, 2, 2, 2, 3, 3, 4, 4, 4, 5, 5, 6}
            Dim [to] = New Integer() {2, 3, 4, 4, 5, 8, 6, 7, 5, 8, 10, 8, 9, 10}
            Dim shapes = New NShape(9) {}
            Dim vertexCount = shapes.Length
            Dim edgeCount = from.Length
            Dim count = vertexCount + edgeCount

            For i = 0 To count - 1

                If i < vertexCount Then
                    Dim j = If(vertexCount Mod 2 = 0, i, i + 1)
                    shapes(i) = basicShapes.CreateShape(ENBasicShape.Rectangle)

                    If vertexCount Mod 2 <> 0 AndAlso i = 0 Then
                        shapes(i).SetBounds(New NRectangle((width + distance * 1.5) / 2, distance + j / 2 * (distance * 1.5), width, height))
                    Else
                        shapes(i).SetBounds(New NRectangle(width / 2 + (j Mod 2) * (distance * 1.5), height + j / 2 * (distance * 1.5), width, height))
                    End If

                    activePage.Items.Add(shapes(i))
                Else
                    Dim edge As NRoutableConnector = New NRoutableConnector()
                    edge.UserClass = "Connector"
                    activePage.Items.Add(edge)
                    edge.GlueBeginToShape(shapes(from(i - vertexCount) - 1))
                    edge.GlueEndToShape(shapes([to](i - vertexCount) - 1))
                End If
            Next

            ' arrange diagram
            ArrangeDiagram(drawingDocument)

            ' fit active page
            drawingDocument.Content.ActivePage.ZoomMode = ENZoomMode.Fit
        End Sub

#End Region

#Region "Implementation"

        ''' <summary>
        ''' Arranges the shapes in the active page.
        ''' </summary>
        ''' <paramname="drawingDocument"></param>
        Private Sub ArrangeDiagram(ByVal drawingDocument As NDrawingDocument)
            ' get all top-level shapes that reside in the active page
            Dim activePage = drawingDocument.Content.ActivePage
            Dim shapes = activePage.GetShapes(False)

            ' create a layout context and use it to arrange the shapes using the current layout
            Dim layoutContext As NDrawingLayoutContext = New NDrawingLayoutContext(drawingDocument, activePage)
            m_Layout.Arrange(shapes.CastAll(Of Object)(), layoutContext)

            ' size the page to the content size
            activePage.SizeToContent()
        End Sub

#End Region

#Region "Event Handlers"

        Private Sub OnRandomGraph1ButtonClick(ByVal arg As NEventArgs)
            Dim drawingDocument = m_DrawingView.Document
            drawingDocument.StartHistoryTransaction("Create Random Graph 1")

            Try
                m_DrawingView.ActivePage.Items.Clear()

                ' create a test tree
                Dim graph As NRandomGraphTemplate = New NRandomGraphTemplate()
                graph.EdgesUserClass = "Connector"
                graph.VertexCount = 10
                graph.EdgeCount = 15
                graph.VerticesShape = VertexShape
                graph.VerticesSize = VertexSize
                graph.Create(drawingDocument)

                ' layout the tree
                ArrangeDiagram(drawingDocument)
            Finally
                drawingDocument.CommitHistoryTransaction()
            End Try
        End Sub

        Private Sub OnRandomGraph2ButtonClick(ByVal arg As NEventArgs)
            Dim drawingDocument = m_DrawingView.Document
            drawingDocument.StartHistoryTransaction("Create Random Graph 2")

            Try
                m_DrawingView.ActivePage.Items.Clear()

                ' create a test tree
                Dim graph As NRandomGraphTemplate = New NRandomGraphTemplate()
                graph.EdgesUserClass = "Connector"
                graph.VertexCount = 20
                graph.EdgeCount = 30
                graph.VerticesShape = VertexShape
                graph.VerticesSize = VertexSize
                graph.Create(drawingDocument)

                ' layout the tree
                ArrangeDiagram(drawingDocument)
            Finally
                drawingDocument.CommitHistoryTransaction()
            End Try
        End Sub

        Private Sub OnLayoutChanged(ByVal arg As NEventArgs)
            ArrangeDiagram(m_DrawingView.Document)
        End Sub

        Protected Overridable Sub OnArrangeButtonClick(ByVal arg As NEventArgs)
            ArrangeDiagram(m_DrawingView.Document)
        End Sub

#End Region

#Region "Fields"

        Private m_DrawingView As NDrawingView
        Private m_Layout As NOrthogonalGraphLayout = New NOrthogonalGraphLayout()

#End Region

#Region "Schema"

        ''' <summary>
        ''' Schema associated with NOrthogonalGraphLayoutExample.
        ''' </summary>
        Public Shared ReadOnly NOrthogonalGraphLayoutExampleSchema As NSchema

#End Region

#Region "Constants"

        Private Const VertexShape As ENBasicShape = ENBasicShape.Rectangle
        Private Shared ReadOnly VertexSize As NSize = New NSize(50, 50)

#End Region
    End Class
End Namespace

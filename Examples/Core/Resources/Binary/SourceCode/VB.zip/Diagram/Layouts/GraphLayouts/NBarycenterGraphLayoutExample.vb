Imports System

Imports Nevron.Nov.DataStructures
Imports Nevron.Nov.Diagram
Imports Nevron.Nov.Diagram.Batches
Imports Nevron.Nov.Diagram.Layout
Imports Nevron.Nov.Diagram.Shapes
Imports Nevron.Nov.Dom
Imports Nevron.Nov.Editors
Imports Nevron.Nov.Graphics
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.Diagram
    Public Class NBarycenterGraphLayoutExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' Default constructor.
        ''' </summary>
        Public Sub New()
            m_Layout.FixedVertexPlacement.Mode = ENFixedVertexPlacementMode.AutomaticEllipseRim
            m_Layout.FixedVertexPlacement.PredefinedEllipse = New NRectangle(0, 0, 500, 500)
        End Sub

        ''' <summary>
        ''' Static constructor.
        ''' </summary>
        Shared Sub New()
            NBarycenterGraphLayoutExampleSchema = NSchema.Create(GetType(NBarycenterGraphLayoutExample), NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function GetExampleDescription() As String
            Return "
<p>     
    The barycenter layout method splits the input graph into a set of fixed and free vertices. 
    Fixed vertices are nailed to the corners of a strictly convex polygon,           
    while free vertices are placed in the barycenter of their neighbors. 
    The barycenter force accessible from the <b>BarycenterForce</b> property of the layout is 
    responsible for attracting the vertices to their barycenter.
</p>
<p>
	In case there are no fixed vertices this will place all vertices at a single point, 
	which is obviously not a good graph drawing. That is why the barycenter layout needs 
	at least three fixed vertices.
</p>
<p>
	The minimal amount of fixed vertices is specified by the <b>MinFixedVerticesCount</b> property. 
	If the input graph does not have that many fixed vertices, the layout will automatically 
	fulfill this requirement. This is done by fixing the vertices with the smallest degree.
</p>
<p>
	In this example the fixed vertices are highlighted in orange.
</p>
" End Function
        Protected Overrides Function CreateExampleContent() As NWidget
            ' Create a simple drawing
            Dim drawingViewWithRibbon As NDrawingViewWithRibbon = New NDrawingViewWithRibbon()
            m_DrawingView = drawingViewWithRibbon.View

            m_DrawingView.Document.HistoryService.Pause()
            Try
                InitDiagram(m_DrawingView.Document)
            Finally
                m_DrawingView.Document.HistoryService.Resume()
            End Try

            Return drawingViewWithRibbon
        End Function
        Protected Overrides Function CreateExampleControls() As NWidget
            Me.m_Layout.Changed += AddressOf OnLayoutChanged

            Dim stack As NStackPanel = New NStackPanel()

            ' property editor
            Dim editor As NEditor = NDesigner.GetDesigner(m_Layout).CreateInstanceEditor(m_Layout)
            stack.Add(New NGroupBox("Properties", editor))

            Dim arrangeButton As NButton = New NButton("Arrange Diagram")
            arrangeButton.Click += AddressOf OnArrangeButtonClick
            stack.Add(arrangeButton)

            ' items stack
            Dim itemsStack As NStackPanel = New NStackPanel()
            Dim triangularGrid6 As NButton = New NButton("Create Triangular Grid (levels 6)")
            triangularGrid6.Click += Sub(ByVal args As NEventArgs) CreateTriangularGridDiagram(6)
            stack.AddChild(triangularGrid6)

            Dim triangularGrid8 As NButton = New NButton("Create Triangular Grid (levels 8)")
            triangularGrid8.Click += Sub(ByVal args As NEventArgs) CreateTriangularGridDiagram(8)
            stack.AddChild(triangularGrid8)

            Dim random10 As NButton = New NButton("Random (fixed 10, free 10)")
            random10.Click += Sub(ByVal args As NEventArgs) CreateRandomBarycenterDiagram(10, 10)
            stack.AddChild(random10)

            Dim random15 As NButton = New NButton("Random (fixed 15, free 15)")
            random15.Click += Sub(ByVal args As NEventArgs) CreateRandomBarycenterDiagram(15, 15)
            stack.AddChild(random15)

            stack.Add(New NGroupBox("Items", itemsStack))

            Return stack
        End Function

        Private Sub InitDiagram(ByVal drawingDocument As NDrawingDocument)
            ' Hide ports
            drawingDocument.Content.ScreenVisibility.ShowPorts = False

            ' Create a random diagram 
            CreateRandomBarycenterDiagram(8, 10)

            ' Arrange the diagram
            ArrangeDiagram(drawingDocument)

            ' Fit active page
            drawingDocument.Content.ActivePage.ZoomMode = ENZoomMode.Fit
        End Sub

#End Region

#Region "Implementation"

        ''' <summary>
        ''' Creates a random barycenter diagram with the specified settings
        ''' </summary>
        ''' <paramname="fixedCount">number of fixed vertices (must be larger than 3)</param>
        ''' <paramname="freeCount">number of free vertices</param>
        Private Sub CreateRandomBarycenterDiagram(ByVal fixedCount As Integer, ByVal freeCount As Integer)
            If fixedCount < 3 Then Throw New ArgumentException("Needs at least three fixed vertices")

            ' clean up the active page
            Dim activePage = m_DrawingView.ActivePage
            activePage.Items.Clear()

            ' we will be using basic circle shapes with default size of (30, 30)
            Dim basicShapes As NBasicShapeFactory = New NBasicShapeFactory()
            basicShapes.DefaultSize = New NSize(30, 30)

            ' create the fixed vertices
            Dim fixedShapes = New NShape(fixedCount - 1) {}

            For i = 0 To fixedCount - 1
                fixedShapes(i) = basicShapes.CreateShape(ENBasicShape.Circle)

                '((NDynamicPort)fixedShapes[i].Ports.GetChildByName("Center", -1)).GlueMode = DynamicPortGlueMode.GlueToLocation;
                fixedShapes(i).Geometry.Fill = New NStockGradientFill(ENGradientStyle.Horizontal, ENGradientVariant.Variant3, New NColor(251, 203, 156), New NColor(247, 150, 56))
                fixedShapes(i).Geometry.Stroke = New NStroke(1, New NColor(68, 90, 108))

                ' setting the ForceXMoveable and ForceYMoveable properties to false
                ' specifies that the layout cannot move the shape in both X and Y directions
                NForceDirectedGraphLayout.SetXMoveable(fixedShapes(i), False)
                NForceDirectedGraphLayout.SetYMoveable(fixedShapes(i), False)

                activePage.Items.AddChild(fixedShapes(i))
            Next

            ' create the free vertices
            Dim freeShapes = New NShape(freeCount - 1) {}
            For i = 0 To freeCount - 1
                freeShapes(i) = basicShapes.CreateShape(ENBasicShape.Circle)
                freeShapes(i).Geometry.Fill = New NStockGradientFill(ENGradientStyle.Horizontal, ENGradientVariant.Variant3, New NColor(192, 194, 194), New NColor(129, 133, 133))
                freeShapes(i).Geometry.Stroke = New NStroke(1, New NColor(68, 90, 108))
                activePage.Items.AddChild(freeShapes(i))
            Next

            ' link the fixed shapes in a circle
            For i = 0 To fixedCount - 1
                Dim connector As NRoutableConnector = New NRoutableConnector()
                connector.MakeLine()
                activePage.Items.AddChild(connector)

                If i = 0 Then
                    connector.GlueBeginToShape(fixedShapes(fixedCount - 1))
                    connector.GlueEndToShape(fixedShapes(0))
                Else
                    connector.GlueBeginToShape(fixedShapes(i - 1))
                    connector.GlueEndToShape(fixedShapes(i))
                End If
            Next

            ' link each free shape with two different random fixed shapes
            Dim rnd As Random = New Random()
            For i = 0 To freeCount - 1
                Dim firstFixed = rnd.Next(fixedCount)
                Dim secondFixed = (firstFixed + rnd.Next(fixedCount / 3) + 1) Mod fixedCount

                ' link with first fixed
                Dim lineShape As NRoutableConnector = New NRoutableConnector()
                lineShape.MakeLine()
                activePage.Items.AddChild(lineShape)

                lineShape.GlueBeginToShape(freeShapes(i))
                lineShape.GlueEndToShape(fixedShapes(firstFixed))

                ' link with second fixed
                lineShape = New NRoutableConnector()
                lineShape.MakeLine()
                activePage.Items.AddChild(lineShape)

                lineShape.GlueBeginToShape(freeShapes(i))
                lineShape.GlueEndToShape(fixedShapes(secondFixed))
            Next

            ' link each free shape with another free shape
            For i = 1 To freeCount - 1
                Dim connector As NRoutableConnector = New NRoutableConnector()
                connector.MakeLine()
                activePage.Items.AddChild(connector)

                connector.GlueBeginToShape(freeShapes(i - 1))
                connector.GlueEndToShape(freeShapes(i))
            Next

            ' send all edges to back
            Dim batchReorder As NBatchReorder(Of NPageItem) = New NBatchReorder(Of NPageItem)(m_DrawingView.Document)
            batchReorder.Build(activePage.GetShapes(False, NDiagramFilters.ShapeType1D).CastAll(Of NPageItem)())
            batchReorder.SendToBack(activePage)

            ' arrange the elements
            ArrangeDiagram(m_DrawingView.Document)
        End Sub
        ''' <summary>
        ''' Creates a triangular grid diagram with the specified count of levels
        ''' </summary>
        ''' <paramname="levels"></param>
        Private Sub CreateTriangularGridDiagram(ByVal levels As Integer)
            ' clean up the active page
            Dim activePage = m_DrawingView.ActivePage
            activePage.Items.Clear()

            ' we will be using basic circle shapes with default size of (30, 30)
            Dim basicShapes As NBasicShapeFactory = New NBasicShapeFactory()
            basicShapes.DefaultSize = New NSize(30, 30)

            Dim prev As NShape = Nothing
            Dim prevRowShapes As NList(Of NShape) = Nothing

            For level = 1 To levels - 1
                Dim curRowShapes As NList(Of NShape) = New NList(Of NShape)()

                For i = 0 To level - 1
                    Dim cur = basicShapes.CreateShape(ENBasicShape.Circle)
                    cur.Geometry.Fill = New NStockGradientFill(ENGradientStyle.Horizontal, ENGradientVariant.Variant3, New NColor(192, 194, 194), New NColor(129, 133, 133))
                    cur.Geometry.Stroke = New NStroke(1, New NColor(68, 90, 108))
                    activePage.Items.Add(cur)

                    Dim edge As NRoutableConnector
                    ' connect with prev
                    If i > 0 Then
                        edge = New NRoutableConnector()
                        edge.MakeLine()
                        activePage.Items.Add(edge)

                        edge.GlueBeginToShape(prev)
                        edge.GlueEndToShape(cur)
                    End If

                    ' connect with ancestors
                    If level > 1 Then
                        If i < prevRowShapes.Count Then
                            edge = New NRoutableConnector()
                            edge.MakeLine()
                            activePage.Items.Add(edge)

                            edge.GlueBeginToShape(prevRowShapes(i))
                            edge.GlueEndToShape(cur)
                        End If

                        If i > 0 Then
                            edge = New NRoutableConnector()
                            edge.MakeLine()
                            activePage.Items.Add(edge)

                            edge.GlueBeginToShape(prevRowShapes(i - 1))
                            edge.GlueEndToShape(cur)
                        End If
                    End If

                    ' fix the three corner vertices
                    If level = 1 OrElse level = levels - 1 AndAlso (i = 0 OrElse i = level - 1) Then
                        NForceDirectedGraphLayout.SetXMoveable(cur, False)
                        NForceDirectedGraphLayout.SetYMoveable(cur, False)

                        cur.Geometry.Fill = New NStockGradientFill(ENGradientStyle.Horizontal, ENGradientVariant.Variant3, New NColor(251, 203, 156), New NColor(247, 150, 56))
                        cur.Geometry.Stroke = New NStroke(1, New NColor(68, 90, 108))
                    End If

                    curRowShapes.Add(cur)
                    prev = cur
                Next

                prevRowShapes = curRowShapes
            Next

            ' send all edges to back
            Dim batchReorder As NBatchReorder(Of NPageItem) = New NBatchReorder(Of NPageItem)(m_DrawingView.Document)
            batchReorder.Build(activePage.GetShapes(False, NDiagramFilters.ShapeType1D).CastAll(Of NPageItem)())
            batchReorder.SendToBack(activePage)

            ' arrange the elements
            ArrangeDiagram(m_DrawingView.Document)
        End Sub
        ''' <summary>
        ''' Arranges the shapes in the active page.
        ''' </summary>
        ''' <paramname="drawingDocument"></param>
        Private Sub ArrangeDiagram(ByVal drawingDocument As NDrawingDocument)
            ' get all top-level shapes that reside in the active page
            Dim activePage = drawingDocument.Content.ActivePage
            Dim shapes = activePage.GetShapes(False)

            ' create a layout context and use it to arrange the shapes using the current layout
            Dim layoutContext As NDrawingLayoutContext = New NDrawingLayoutContext(drawingDocument, activePage)
            m_Layout.Arrange(shapes.CastAll(Of Object)(), layoutContext)

            ' size the page to the content size
            activePage.SizeToContent()
        End Sub

#End Region

#Region "Event Handlers"

        Private Sub OnLayoutChanged(ByVal arg As NEventArgs)
            ArrangeDiagram(m_DrawingView.Document)
        End Sub
        Protected Overridable Sub OnArrangeButtonClick(ByVal arg As NEventArgs)
            ArrangeDiagram(m_DrawingView.Document)
        End Sub

#End Region

#Region "Fields"

        Private m_DrawingView As NDrawingView
        Private m_Layout As NBarycenterGraphLayout = New NBarycenterGraphLayout()

#End Region

#Region "Schema"

        ''' <summary>
        ''' Schema associated with NBarycenterGraphLayoutExample.
        ''' </summary>
        Public Shared ReadOnly NBarycenterGraphLayoutExampleSchema As NSchema

#End Region
    End Class
End Namespace

Imports Nevron.Nov.Diagram
Imports Nevron.Nov.Diagram.Layout
Imports Nevron.Nov.Diagram.Shapes
Imports Nevron.Nov.Dom
Imports Nevron.Nov.Editors
Imports Nevron.Nov.Graphics
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.Diagram
    Public Class NLayeredTreeLayoutExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' Default constructor.
        ''' </summary>
        Public Sub New()
        End Sub

        ''' <summary>
        ''' Static constructor.
        ''' </summary>
        Shared Sub New()
            NLayeredTreeLayoutExampleSchema = NSchema.Create(GetType(NLayeredTreeLayoutExample), NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            ' Create a simple drawing
            Dim drawingViewWithRibbon As NDrawingViewWithRibbon = New NDrawingViewWithRibbon()
            m_DrawingView = drawingViewWithRibbon.View

            m_DrawingView.Document.HistoryService.Pause()
            Try
                InitDiagram(m_DrawingView.Document)
            Finally
                m_DrawingView.Document.HistoryService.Resume()
            End Try

            Return drawingViewWithRibbon
        End Function
        Protected Overrides Function CreateExampleControls() As NWidget
            Me.m_Layout.Changed += AddressOf OnLayoutChanged

            Dim stack As NStackPanel = New NStackPanel()

            ' property editor
            Dim editor As NEditor = NDesigner.GetDesigner(m_Layout).CreateInstanceEditor(m_Layout)
            stack.Add(New NGroupBox("Properties", editor))

            Dim arrangeButton As NButton = New NButton("Arrange Diagram")
            arrangeButton.Click += AddressOf OnArrangeButtonClick
            stack.Add(arrangeButton)

            ' items stack
            Dim itemsStack As NStackPanel = New NStackPanel()

            ' NOTE: For Tree layouts we provide the user with the ability to generate random tree diagrams so that he/she can test the layouts
            Dim randomTree1Button As NButton = New NButton("Random Tree (max 6 levels, max 3 branch nodes)")
            randomTree1Button.Click += AddressOf OnRandomTree1ButtonClick
            itemsStack.Add(randomTree1Button)

            Dim randomTree2Button As NButton = New NButton("Random Tree (max 8 levels, max 2 branch nodes)")
            randomTree2Button.Click += AddressOf OnRandomTree2ButtonClick
            itemsStack.Add(randomTree2Button)

            stack.Add(New NGroupBox("Items", itemsStack))

            Return stack
        End Function
        Protected Overrides Function GetExampleDescription() As String
            Return "
	<p>
        The layered tree layout represents a classical directed tree layout 
        (e.g. with uniform parent placement), which places vertices from the same level in layers.
        It produces both straight line and orthogonal tree drawings, which is controlled by the <b>OrthogonalEdgeRouting</b> property.
		The <b>PlugSpacing</b> property controls the spacing between the plugs of a node.
		You can set a fixed amount of spacing or a proportional spacing, which means that the plugs
		are distributed along the whole side of the node.
        The layout satisfies the following aesthetic criteria:
        <ul>
            <li>No edge crossings - edges do not cross each other.</li>
            <li>No vertex-vertex overlaps - vertices do not overlap each other.</li>
            <li>No vertex-edge overlaps - in case of orthogonal edge routing, this criteria is met when the <b>BusBetweenLayers</b> property is set to true. </li>
            <li>Straight line routing - in case the <b>OrthogonalEdgeRouting</b> property is set to false you can consider modifying the
			    <b>PortStyle</b> property, which controls the anchoring of the lines to the vertex boxes.</li>
            <li>Compactness - you can optimize the compactness of the drawing in the tree breadth dimension 
            by setting the <b>CompactBreadth</b> property to true.</li>
        </ul>
    </p>    
    <p>
		To experiment with the layout just change its properties from the property grid 
		and click the <b>Layout</b> button.
	</p>
	<p>
		To see the layout in action on a different trees, just click the <b>Random Tree</b> buttons.
	</p>
" End Function

        Private Sub InitDiagram(ByVal drawingDocument As NDrawingDocument)
            ' Hide ports
            drawingDocument.Content.ScreenVisibility.ShowPorts = False

            ' Create random diagram
            Dim template As NGenericTreeTemplate = New NGenericTreeTemplate()
            template.EdgeUserClass = NDR.StyleSheetNameConnectors
            template.Balanced = False
            template.Levels = 6
            template.BranchNodes = 3
            template.HorizontalSpacing = 10
            template.VerticalSpacing = 10
            template.VertexSize = New NSize(50, 50)
            template.VertexSizeDeviation = 1
            template.Create(drawingDocument)

            ' Arrange diagram
            ArrangeDiagram(drawingDocument)

            ' Fit active page
            drawingDocument.Content.ActivePage.ZoomMode = ENZoomMode.Fit
        End Sub

#End Region

#Region "Implementation"

        ''' <summary>
        ''' Arranges the shapes in the active page.
        ''' </summary>
        ''' <paramname="drawingDocument"></param>
        Private Sub ArrangeDiagram(ByVal drawingDocument As NDrawingDocument)
            ' get all top-level shapes that reside in the active page
            Dim activePage = drawingDocument.Content.ActivePage
            Dim shapes = activePage.GetShapes(False)

            ' create a layout context and use it to arrange the shapes using the current layout
            Dim layoutContext As NDrawingLayoutContext = New NDrawingLayoutContext(drawingDocument, activePage)
            m_Layout.Arrange(shapes.CastAll(Of Object)(), layoutContext)

            ' size the page to the content size
            activePage.SizeToContent()
        End Sub

#End Region

#Region "Event Handlers"

        Private Sub OnRandomTree1ButtonClick(ByVal arg As NEventArgs)
            Dim drawingDocument = m_DrawingView.Document

            drawingDocument.StartHistoryTransaction("Create Random Tree 1")
            Try
                drawingDocument.Content.ActivePage.Items.Clear()

                ' create a random tree
                Dim tree As NGenericTreeTemplate = New NGenericTreeTemplate()
                tree.EdgeUserClass = NDR.StyleSheetNameConnectors
                tree.Levels = 6
                tree.BranchNodes = 3
                tree.HorizontalSpacing = 10
                tree.VerticalSpacing = 10
                tree.VertexShape = VertexShape
                tree.VertexSize = VertexSize
                tree.Balanced = False
                tree.VertexSizeDeviation = 1

                tree.Create(drawingDocument)

                ' layout the tree
                ArrangeDiagram(drawingDocument)
            Finally
                drawingDocument.CommitHistoryTransaction()
            End Try
        End Sub
        Private Sub OnRandomTree2ButtonClick(ByVal arg As NEventArgs)
            Dim drawingDocument = m_DrawingView.Document

            drawingDocument.StartHistoryTransaction("Create Random Tree 2")
            Try
                drawingDocument.Content.ActivePage.Items.Clear()

                ' create a random tree
                Dim tree As NGenericTreeTemplate = New NGenericTreeTemplate()
                tree.EdgeUserClass = NDR.StyleSheetNameConnectors
                tree.Levels = 8
                tree.BranchNodes = 2
                tree.HorizontalSpacing = 10
                tree.VerticalSpacing = 10
                tree.VertexShape = VertexShape
                tree.VertexSize = VertexSize
                tree.Balanced = False
                tree.VertexSizeDeviation = 1

                tree.Create(drawingDocument)

                ' layout the tree
                ArrangeDiagram(drawingDocument)
            Finally
                drawingDocument.CommitHistoryTransaction()
            End Try
        End Sub
        Private Sub OnLayoutChanged(ByVal arg As NEventArgs)
            ArrangeDiagram(m_DrawingView.Document)
        End Sub
        Private Sub OnArrangeButtonClick(ByVal arg As NEventArgs)
            ArrangeDiagram(m_DrawingView.Document)
        End Sub

#End Region

#Region "Fields"

        Private m_DrawingView As NDrawingView
        Private m_Layout As NLayeredTreeLayout = New NLayeredTreeLayout()

#End Region

#Region "Schema"

        ''' <summary>
        ''' Schema associated with NLayeredTreeLayoutExample.
        ''' </summary>
        Public Shared ReadOnly NLayeredTreeLayoutExampleSchema As NSchema

#End Region

#Region "Constants"

        Private Const VertexShape As ENBasicShape = ENBasicShape.Rectangle
        Private Shared ReadOnly VertexSize As NSize = New NSize(60, 60)

#End Region
    End Class
End Namespace

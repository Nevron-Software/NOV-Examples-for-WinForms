Imports Nevron.Nov.Diagram
Imports Nevron.Nov.Diagram.Layout
Imports Nevron.Nov.Diagram.Shapes
Imports Nevron.Nov.Dom
Imports Nevron.Nov.Editors
Imports Nevron.Nov.Graphics
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.Diagram
    Public Class NRadialGraphLayoutExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' Default constructor.
        ''' </summary>
        Public Sub New()
        End Sub

        ''' <summary>
        ''' Static constructor.
        ''' </summary>
        Shared Sub New()
            NRadialGraphLayoutExampleSchema = NSchema.Create(GetType(NRadialGraphLayoutExample), NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            ' Create a simple drawing
            Dim drawingViewWithRibbon As NDrawingViewWithRibbon = New NDrawingViewWithRibbon()
            m_DrawingView = drawingViewWithRibbon.View
            m_DrawingView.Document.HistoryService.Pause()

            Try
                InitDiagram(m_DrawingView.Document)
            Finally
                m_DrawingView.Document.HistoryService.Resume()
            End Try

            Return drawingViewWithRibbon
        End Function

        Protected Overrides Function CreateExampleControls() As NWidget
            AddHandler m_Layout.Changed, AddressOf OnLayoutChanged
            Dim stack As NStackPanel = New NStackPanel()

            ' property editor
            Dim editor As NEditor = NDesigner.GetDesigner(m_Layout).CreateInstanceEditor(m_Layout)
            stack.Add(New NGroupBox("Properties", editor))
            Dim arrangeButton As NButton = New NButton("Arrange Diagram")
            AddHandler arrangeButton.Click, AddressOf OnArrangeButtonClick
            stack.Add(arrangeButton)

            ' items stack
            Dim itemsStack As NStackPanel = New NStackPanel()

            ' NOTE: For Graph layouts we provide the user with the ability to generate random graph diagrams so that he/she can test the layouts
            Dim randomGraph1Button As NButton = New NButton("Random Graph (10 vertices, 15 edges)")
            AddHandler randomGraph1Button.Click, AddressOf OnRandomGraph1ButtonClick
            itemsStack.Add(randomGraph1Button)
            Dim randomGraph2Button As NButton = New NButton("Random Graph (20 vertices, 30 edges)")
            AddHandler randomGraph2Button.Click, AddressOf OnRandomGraph2ButtonClick
            itemsStack.Add(randomGraph2Button)
            stack.Add(New NGroupBox("Items", itemsStack))
            Return stack
        End Function

        Protected Overrides Function GetExampleDescription() As String
            Return "
<p>
    The radial graph layout layouts the graphs in concentric circles. The vertices with no
    predecessors are placed in the center and their descendants are placed on the next circle
    and so on. It produces a straight line graph drawing. The most important properties are:
</p>
<ul>
	<li>
		<b>Aspect Ratio</b> - determines the aspect (width/height) ratio of the layout.
		By default set to 1 which layouts the nodes in a circle. A value different from 1
		will make the layout order the nodes in an ellipse.
	</li>
	<li>
		<b>AutoSizeRings</b> - if set to true the RingRadius property is automatically
		calculated to have such value that the total area of the drawing is minimized and there
		is no node overlapping.
	</li>
	<li>
		<b>RingRadius</b> - determines the size of the radius of the first imaginary circle where
		nodes are placed. The radius of each other circle is a sum of the RingRadius value and
		the radius of the previous circle. This value is automatically determined if the 
		AutoSizeRings property is set to true.
	</li>
</ul>
<p>
	To experiment with their behavior just change the properties of the layout in the property
	grid and click the <b>Layout</b> button.
</p>
            "
        End Function

        Private Sub InitDiagram(ByVal drawingDocument As NDrawingDocument)
            ' Hide ports
            drawingDocument.Content.ScreenVisibility.ShowPorts = False

            ' Create a random tree
            Dim tree As NGenericTreeTemplate = New NGenericTreeTemplate()
            tree.Levels = 4
            tree.BranchNodes = 4
            tree.HorizontalSpacing = 10
            tree.VerticalSpacing = 10
            tree.ConnectorType = ENConnectorShape.RoutableConnector
            tree.VerticesShape = ENBasicShape.Circle
            tree.VerticesSize = New NSize(40, 40)
            tree.Create(drawingDocument)

            ' Arrange diagram
            ArrangeDiagram(drawingDocument)

            ' Fit active page
            drawingDocument.Content.ActivePage.ZoomMode = ENZoomMode.Fit
        End Sub

#End Region

#Region "Implementation"

        ''' <summary>
        ''' Arranges the shapes in the active page.
        ''' </summary>
        ''' <paramname="drawingDocument"></param>
        Private Sub ArrangeDiagram(ByVal drawingDocument As NDrawingDocument)
            ' get all top-level shapes that reside in the active page
            Dim activePage = drawingDocument.Content.ActivePage
            Dim shapes = activePage.GetShapes(False)

            ' create a layout context and use it to arrange the shapes using the current layout
            Dim layoutContext As NDrawingLayoutContext = New NDrawingLayoutContext(drawingDocument, activePage)
            m_Layout.Arrange(shapes.CastAll(Of Object)(), layoutContext)

            ' size the page to the content size
            activePage.SizeToContent()
        End Sub

#End Region

#Region "Event Handlers"

        Private Sub OnRandomGraph1ButtonClick(ByVal arg As NEventArgs)
            Dim drawingDocument = m_DrawingView.Document
            drawingDocument.StartHistoryTransaction("Create Random Graph 1")

            Try
                m_DrawingView.ActivePage.Items.Clear()

                ' create a test tree
                Dim graph As NRandomGraphTemplate = New NRandomGraphTemplate()
                graph.EdgesUserClass = "Connector"
                graph.VertexCount = 10
                graph.EdgeCount = 15
                graph.VerticesShape = VertexShape
                graph.VerticesSize = VertexSize
                graph.Create(drawingDocument)

                ' layout the tree
                ArrangeDiagram(drawingDocument)
            Finally
                drawingDocument.CommitHistoryTransaction()
            End Try
        End Sub

        Private Sub OnRandomGraph2ButtonClick(ByVal arg As NEventArgs)
            Dim drawingDocument = m_DrawingView.Document
            drawingDocument.StartHistoryTransaction("Create Random Graph 2")

            Try
                m_DrawingView.ActivePage.Items.Clear()

                ' create a test tree
                Dim graph As NRandomGraphTemplate = New NRandomGraphTemplate()
                graph.EdgesUserClass = "Connector"
                graph.VertexCount = 20
                graph.EdgeCount = 30
                graph.VerticesShape = VertexShape
                graph.VerticesSize = VertexSize
                graph.Create(drawingDocument)

                ' layout the tree
                ArrangeDiagram(drawingDocument)
            Finally
                drawingDocument.CommitHistoryTransaction()
            End Try
        End Sub

        Private Sub OnLayoutChanged(ByVal arg As NEventArgs)
            ArrangeDiagram(m_DrawingView.Document)
        End Sub

        Protected Overridable Sub OnArrangeButtonClick(ByVal arg As NEventArgs)
            ArrangeDiagram(m_DrawingView.Document)
        End Sub

#End Region

#Region "Fields"

        Private m_DrawingView As NDrawingView
        Private m_Layout As NRadialGraphLayout = New NRadialGraphLayout()

#End Region

#Region "Schema"

        ''' <summary>
        ''' Schema associated with NRadialGraphLayoutExample.
        ''' </summary>
        Public Shared ReadOnly NRadialGraphLayoutExampleSchema As NSchema

#End Region

#Region "Constants"

        Private Const VertexShape As ENBasicShape = ENBasicShape.Circle
        Private Shared ReadOnly VertexSize As NSize = New NSize(50, 50)

#End Region
    End Class
End Namespace

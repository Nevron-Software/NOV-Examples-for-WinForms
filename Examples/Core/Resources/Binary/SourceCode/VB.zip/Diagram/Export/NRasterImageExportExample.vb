Imports Nevron.Nov.Diagram
Imports Nevron.Nov.Diagram.Export
Imports Nevron.Nov.Diagram.Shapes
Imports Nevron.Nov.Dom
Imports Nevron.Nov.Graphics
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.Diagram
    Public Class NRasterImageExportExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' Default constructor.
        ''' </summary>
        Public Sub New()
        End Sub

        ''' <summary>
        ''' Static constructor.
        ''' </summary>
        Shared Sub New()
            NRasterImageExportExampleSchema = NSchema.Create(GetType(NRasterImageExportExample), NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            ' Create a simple drawing
            Dim drawingViewWithRibbon As NDrawingViewWithRibbon = New NDrawingViewWithRibbon()
            m_DrawingView = drawingViewWithRibbon.View

            m_DrawingView.Document.HistoryService.Pause()
            Try
                InitDiagram(m_DrawingView.Document)
            Finally
                m_DrawingView.Document.HistoryService.Resume()
            End Try

            Return drawingViewWithRibbon
        End Function
        Protected Overrides Function CreateExampleControls() As NWidget
            Dim stackPanel As NStackPanel = New NStackPanel()

            Dim showImageExportButton As NButton = New NButton("Show Raster Image Export Dialog...")
            showImageExportButton.Click += AddressOf OnShowImageExportButtonClick
            stackPanel.Add(showImageExportButton)

            Dim copyImageToClipboardButton As NButton = New NButton("Copy Raster Image to Clipboard")
            copyImageToClipboardButton.Click += AddressOf OnCopyImageToClipboardButtonClick
            stackPanel.Add(copyImageToClipboardButton)

            Dim saveAsRasterImageFileButton As NButton = New NButton("Save as Raster Image File...")
            saveAsRasterImageFileButton.Click += AddressOf OnSaveAsRasterImageFileButtonClick
            stackPanel.Add(saveAsRasterImageFileButton)

            Return stackPanel
        End Function

        Protected Overrides Function GetExampleDescription() As String
            Return "
<p>
    Demonstrates the raster image exporter, with the help of which you can export the active page or any portion of it
	to a raster image (PNG, JPEG, BMP).
</p>
            " End Function

        Private Sub InitDiagram(ByVal drawingDocument As NDrawingDocument)
            Dim drawing = drawingDocument.Content
            Dim activePage = drawing.ActivePage

            drawing.ScreenVisibility.ShowGrid = False
            drawing.ScreenVisibility.ShowPorts = False

            Dim basicShapes As NBasicShapeFactory = New NBasicShapeFactory()
            Dim flowchartShapes = NLibrary.FlowchartShapes
            Dim connectorShapes As NConnectorShapeFactory = New NConnectorShapeFactory()

            Dim nonPrintableShape = basicShapes.CreateShape(ENBasicShape.Rectangle)
            nonPrintableShape.Text = "Non printable shape"
            nonPrintableShape.AllowPrint = False
            nonPrintableShape.Geometry.Fill = New NColorFill(NColor.Tomato)
            nonPrintableShape.SetBounds(50, 50, 150, 50)
            activePage.Items.Add(nonPrintableShape)

            Dim isLifeGood = flowchartShapes.CreateShape(ENFlowchartingShape.Decision)
            isLifeGood.Text = "Is Life Good?"
            isLifeGood.SetBounds(300, 50, 150, 100)
            isLifeGood.Geometry.Fill = New NColorFill(NColor.LightSkyBlue)
            activePage.Items.Add(isLifeGood)

            Dim goodShape = flowchartShapes.CreateShape(ENFlowchartingShape.Termination)
            goodShape.Text = "Good"
            goodShape.SetBounds(200, 200, 100, 100)
            goodShape.Geometry.Fill = New NColorFill(NColor.Gold)
            activePage.Items.Add(goodShape)

            Dim changeSomething = flowchartShapes.CreateShape(ENFlowchartingShape.Process)
            changeSomething.Text = "Change Something"
            changeSomething.Geometry.Fill = New NColorFill(NColor.Thistle)
            changeSomething.SetBounds(450, 200, 100, 100)
            activePage.Items.Add(changeSomething)

            Dim yesConnector = connectorShapes.CreateShape(ENConnectorShape.RoutableConnector)
            yesConnector.Text = "Yes"
            yesConnector.GlueBeginToPort(isLifeGood.GetPortByName("Left"))
            yesConnector.GlueEndToPort(goodShape.GetPortByName("Top"))
            activePage.Items.Add(yesConnector)

            Dim noConnector = connectorShapes.CreateShape(ENConnectorShape.RoutableConnector)
            noConnector.Text = "No"
            noConnector.GlueBeginToPort(isLifeGood.GetPortByName("Right"))
            noConnector.GlueEndToPort(changeSomething.GetPortByName("Top"))
            activePage.Items.Add(noConnector)

            Dim gobackConnector = connectorShapes.CreateShape(ENConnectorShape.RoutableConnector)
            gobackConnector.GlueBeginToPort(changeSomething.GetPortByName("Right"))
            gobackConnector.GlueEndToPort(isLifeGood.GetPortByName("Top"))
            activePage.Items.Add(gobackConnector)
        End Sub

#End Region

#Region "Event Handlers"

        Private Sub OnShowImageExportButtonClick(ByVal arg As NEventArgs)
            Dim imageExporter As NDrawingRasterImageExporter = New NDrawingRasterImageExporter(m_DrawingView.Content)
            imageExporter.ShowDialog(DisplayWindow, True)
        End Sub
        Private Sub OnCopyImageToClipboardButtonClick(ByVal arg As NEventArgs)
            Dim imageExporter As NDrawingRasterImageExporter = New NDrawingRasterImageExporter(m_DrawingView.Content)
            imageExporter.CopyToClipboard()
        End Sub
        Private Sub OnSaveAsRasterImageFileButtonClick(ByVal arg As NEventArgs)
            Dim imageExporter As NDrawingRasterImageExporter = New NDrawingRasterImageExporter(m_DrawingView.Content)
            imageExporter.SaveAsImage()

            ' Pass a raster image format, if you want it to be selected by default in the Save File dialog.
            ' For example, to make the PNG image format selected by default, use the following line of code:
            ' imageExporter.SaveAsImage(NImageFormat.Png);
        End Sub

#End Region

#Region "Fields"

        Private m_DrawingView As NDrawingView

#End Region

#Region "Schema"

        ''' <summary>
        ''' Schema associated with NRasterImageExportExample.
        ''' </summary>
        Public Shared ReadOnly NRasterImageExportExampleSchema As NSchema

#End Region
    End Class
End Namespace

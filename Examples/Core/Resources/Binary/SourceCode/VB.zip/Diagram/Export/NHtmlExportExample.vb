Imports System

Imports Nevron.Nov.Diagram
Imports Nevron.Nov.Diagram.Shapes
Imports Nevron.Nov.Dom
Imports Nevron.Nov.Graphics
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.Diagram
    Public Class NHtmlExportExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' Default constructor.
        ''' </summary>
        Public Sub New()
        End Sub

        ''' <summary>
        ''' Static constructor.
        ''' </summary>
        Shared Sub New()
            NHtmlExportExampleSchema = NSchema.Create(GetType(NHtmlExportExample), NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            ' Create a simple drawing
            Dim drawingViewWithRibbon As NDrawingViewWithRibbon = New NDrawingViewWithRibbon()
            m_DrawingView = drawingViewWithRibbon.View

            m_DrawingView.Document.HistoryService.Pause()
            Try
                InitDiagram(m_DrawingView.Document)
            Finally
                m_DrawingView.Document.HistoryService.Resume()
            End Try

            Return drawingViewWithRibbon
        End Function
        Protected Overrides Function CreateExampleControls() As NWidget
            Dim stackPanel As NStackPanel = New NStackPanel()

            Dim saveAsButton As NButton = New NButton("Save as Web Page...")
            saveAsButton.Click += AddressOf OnSaveAsButtonClick
            stackPanel.Add(saveAsButton)

            Return stackPanel
        End Function
        Protected Overrides Function GetExampleDescription() As String
            Return "
<p>
    Demonstrates how to export a NOV Diagram drawing to a web page (HTML). The drawing is exported
	to SVG that gets inserted into an HTML web page. If the drawing has multiple pages, then some
	CSS and JavaScript are inserted in the HTML web page in order to create a tab navigation interface.
	Each drawing page is inserted into a tab page.
</p>
" End Function

        Private Sub InitDiagram(ByVal drawingDocument As NDrawingDocument)
            Dim drawing = drawingDocument.Content
            Dim activePage = drawing.ActivePage

            drawing.ScreenVisibility.ShowGrid = False
            drawing.ScreenVisibility.ShowPorts = False

            CreateDiagram(activePage)

            Dim page As NPage = New NPage("Page-2")
            drawing.Pages.Add(page)
            CreateDiagram(page)
        End Sub

#End Region

#Region "Implementation"

        Private Sub CreateDiagram(ByVal page As NPage)
            Dim basicShapes As NBasicShapeFactory = New NBasicShapeFactory()
            Dim connectorShapes As NConnectorShapeFactory = New NConnectorShapeFactory()
            Dim flowchartShapes = NLibrary.FlowchartShapes

            Dim titleShape = basicShapes.CreateShape(ENBasicShape.Rectangle)
            titleShape.Geometry.Fill = New NColorFill(NColor.LightGray)
            titleShape.Text = page.Title
            titleShape.SetBounds(10, 10, page.Width - 20, 50)
            page.Items.Add(titleShape)

            Dim nonPrintableShape = basicShapes.CreateShape(ENBasicShape.Rectangle)
            nonPrintableShape.Text = "Non printable shape"
            nonPrintableShape.AllowPrint = False
            nonPrintableShape.Geometry.Fill = New NColorFill(NColor.Tomato)
            nonPrintableShape.SetBounds(50, 150, 150, 50)
            page.Items.Add(nonPrintableShape)

            Dim isLifeGood = flowchartShapes.CreateShape(ENFlowchartingShape.Decision)
            isLifeGood.Text = "Is Life Good?"
            isLifeGood.SetBounds(300, 150, 150, 100)
            isLifeGood.Geometry.Fill = New NColorFill(NColor.LightSkyBlue)
            page.Items.Add(isLifeGood)

            Dim goodShape = flowchartShapes.CreateShape(ENFlowchartingShape.Termination)
            goodShape.Text = "Good"
            goodShape.SetBounds(200, 300, 100, 100)
            goodShape.Geometry.Fill = New NColorFill(NColor.Gold)
            page.Items.Add(goodShape)

            Dim changeSomething = flowchartShapes.CreateShape(ENFlowchartingShape.Process)
            changeSomething.Text = "Change Something"
            changeSomething.Geometry.Fill = New NColorFill(NColor.Thistle)
            changeSomething.SetBounds(450, 300, 100, 100)
            page.Items.Add(changeSomething)

            Dim yesConnector = connectorShapes.CreateShape(ENConnectorShape.RoutableConnector)
            yesConnector.Text = "Yes"
            yesConnector.GlueBeginToPort(isLifeGood.GetPortByName("Left"))
            yesConnector.GlueEndToPort(goodShape.GetPortByName("Top"))
            page.Items.Add(yesConnector)

            Dim noConnector = connectorShapes.CreateShape(ENConnectorShape.RoutableConnector)
            noConnector.Text = "No"
            noConnector.GlueBeginToPort(isLifeGood.GetPortByName("Right"))
            noConnector.GlueEndToPort(changeSomething.GetPortByName("Top"))
            page.Items.Add(noConnector)

            Dim gobackConnector = connectorShapes.CreateShape(ENConnectorShape.RoutableConnector)
            gobackConnector.GlueBeginToPort(changeSomething.GetPortByName("Right"))
            gobackConnector.GlueEndToPort(isLifeGood.GetPortByName("Top"))
            page.Items.Add(gobackConnector)
        End Sub

#End Region

#Region "Event Handlers"

        Private Sub OnSaveAsButtonClick(ByVal arg As NEventArgs)
            Dim fileName = m_DrawingView.Content.Information.FileName
            If String.IsNullOrEmpty(fileName) OrElse Not fileName.EndsWith("vsdx", StringComparison.OrdinalIgnoreCase) Then
                ' The document has not been saved, yet, so set a file name with HTML extension
                ' to make the default Save As dialog show Web Page as file save as type
                m_DrawingView.Content.Information.FileName = "Document1.html"
            End If

            m_DrawingView.SaveAsAsync()
        End Sub

#End Region

#Region "Fields"

        Private m_DrawingView As NDrawingView

#End Region

#Region "Schema"

        ''' <summary>
        ''' Schema associated with NHtmlExportExample.
        ''' </summary>
        Public Shared ReadOnly NHtmlExportExampleSchema As NSchema

#End Region
    End Class
End Namespace

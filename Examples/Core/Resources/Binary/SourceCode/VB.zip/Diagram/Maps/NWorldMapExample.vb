Imports Nevron.Nov.Diagram
Imports Nevron.Nov.Diagram.Import.Map
Imports Nevron.Nov.Dom
Imports Nevron.Nov.Graphics
Imports Nevron.Nov.UI

#Region "InternalCode"

' Map data from: http://www.naturalearthdata.com/features/

#End Region

Namespace Nevron.Nov.Examples.Diagram
    Public Class NWorldMapExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' Default constructor.
        ''' </summary>
        Public Sub New()
        End Sub

        ''' <summary>
        ''' Static constructor.
        ''' </summary>
        Shared Sub New()
            NWorldMapExampleSchema = NSchema.Create(GetType(NWorldMapExample), NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            ' Create a simple drawing
            Dim drawingViewWithRibbon As NDrawingViewWithRibbon = New NDrawingViewWithRibbon()
            m_DrawingView = drawingViewWithRibbon.View

            m_DrawingView.Document.HistoryService.Pause()
            Try
                InitDiagram(m_DrawingView.Document)
            Finally
                m_DrawingView.Document.HistoryService.Resume()
            End Try

            Return drawingViewWithRibbon
        End Function
        Protected Overrides Function CreateExampleControls() As NWidget
            Return Nothing
        End Function
        Protected Overrides Function GetExampleDescription() As String
            Return "
<p>
    <b>NOV Diagram</b> makes it easy to import geographical data from ESRI shapefiles. You
    can control the way the shapes are rendered by applying various fill rules to them. You can
	also specify a zoom range in which the shapes and/or texts of a shapefile should be visible.
	For example when you zoom this map to 50% you will notice that labels appear for the countries.
</p>
<p>
	Upon import of a shape additional information from the DBF file that accompanies the shapefile
	is provided (e.g. Country Name, Population, Currency, GDP, etc.). You can use these values to
	customize the name, the text and the fill of the shape. You can also provide an INShapeCreatedListener
	implementation to the shape importer of the map in order to get notified when a shape is imported
	and use the values from the DBF file for this shape to customize it even further.
</p>" End Function

        Private Sub InitDiagram(ByVal drawingDocument As NDrawingDocument)
            ' Configure the document
            Dim drawing = drawingDocument.Content
            drawing.ScreenVisibility.ShowGrid = False

            ' Add styles
            AddStyles(drawingDocument)

            ' Configure the active page
            Dim page = drawing.ActivePage
            page.Bounds = New NRectangle(0, 0, 10000, 10000)
            page.ZoomMode = ENZoomMode.Fit
            page.BackgroundFill = New NColorFill(NColor.LightBlue)

            ' Create a map importer
            Dim mapImporter As NEsriMapImporter = New NEsriMapImporter()
            mapImporter.MapBounds = NMapBounds.World

            ' Add an ESRI shapefile
            Dim countries As NEsriShapefile = New NEsriShapefile(NResources.RBIN_Countries_zip)
            countries.NameColumn = "name_long"
            countries.TextColumn = "name_long"
            countries.MinTextZoomPercent = 50
            countries.FillRule = New NMapFillRuleValue("mapcolor8", Colors)
            mapImporter.AddShapefile(countries)

            ' Read the map data
            mapImporter.Read()

            ' Import the map to the drawing document
            mapImporter.Import(drawingDocument, page.Bounds)

            ' Size page to content
            page.SizeToContent()
        End Sub

#End Region

#Region "Implementation"

        Private Sub AddStyles(ByVal document As NDrawingDocument)
            ' Create a style sheet
            Dim styleSheet As NStyleSheet = New NStyleSheet()
            document.StyleSheets.Add(styleSheet)

            ' Add some styling for the shapes
            Dim rule As NRule = New NRule()
            Dim sb As NSelectorBuilder = rule.GetSelectorBuilder()
            sb.Start()
            sb.Type(NGeometry.NGeometrySchema)
            sb.ChildOf()
            sb.Type(NShape.NShapeSchema)
            sb.End()

            rule.Declarations.Add(New NValueDeclaration(Of NStroke)(NGeometry.StrokeProperty, New NStroke(New NColor(68, 90, 108))))
            styleSheet.Add(rule)
        End Sub

#End Region

#Region "Fields"

        Private m_DrawingView As NDrawingView

#End Region

#Region "Schema"

        ''' <summary>
        ''' Schema associated with NWorldMapExample.
        ''' </summary>
        Public Shared ReadOnly NWorldMapExampleSchema As NSchema

#End Region

#Region "Constants"

        ''' <summary>
        ''' The colors used to fill the countries.
        ''' </summary>
        Private Shared ReadOnly Colors As NColor() = New NColor() {NColor.OldLace, NColor.PaleGreen, NColor.Gold, NColor.Khaki, NColor.Tan, NColor.Orange, NColor.Salmon, NColor.PaleGoldenrod}

#End Region
    End Class
End Namespace

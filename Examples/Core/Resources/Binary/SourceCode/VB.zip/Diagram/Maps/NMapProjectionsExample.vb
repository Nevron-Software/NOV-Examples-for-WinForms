Imports Nevron.Nov.Diagram
Imports Nevron.Nov.Diagram.Import.Map
Imports Nevron.Nov.Dom
Imports Nevron.Nov.Graphics
Imports Nevron.Nov.Layout
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.Diagram
    Public Class NMapProjectionsExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' Default constructor.
        ''' </summary>
        Public Sub New()
            m_Projections = New NMapProjection() {New NAitoffProjection(), New NBonneProjection(), New NCylindricalEqualAreaProjection(ENCylindricalEqualAreaProjectionType.Lambert), New NCylindricalEqualAreaProjection(ENCylindricalEqualAreaProjectionType.Behrmann), New NCylindricalEqualAreaProjection(ENCylindricalEqualAreaProjectionType.TristanEdwards), New NCylindricalEqualAreaProjection(ENCylindricalEqualAreaProjectionType.Peters), New NCylindricalEqualAreaProjection(ENCylindricalEqualAreaProjectionType.Gall), New NCylindricalEqualAreaProjection(ENCylindricalEqualAreaProjectionType.Balthasart), New NEckertIVProjection(), New NEckertVIProjection(), New NEquirectangularProjection(), New NHammerProjection(), New NKavrayskiyVIIProjection(), New NMercatorProjection(), New NMillerCylindricalProjection(), New NMollweideProjection(), New NOrthographicProjection(), New NRobinsonProjection(), New NStereographicProjection(), New NVanDerGrintenProjection(), New NWagnerVIProjection(), New NWinkelTripelProjection()}
        End Sub

        ''' <summary>
        ''' Static constructor.
        ''' </summary>
        Shared Sub New()
            NMapProjectionsExampleSchema = NSchema.Create(GetType(NMapProjectionsExample), NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            ' Create a simple drawing
            Dim drawingViewWithRibbon As NDrawingViewWithRibbon = New NDrawingViewWithRibbon()
            m_DrawingView = drawingViewWithRibbon.View
            m_DrawingView.Document.HistoryService.Pause()

            Try
                InitDiagram(m_DrawingView.Document)
            Finally
                m_DrawingView.Document.HistoryService.Resume()
            End Try

            Return drawingViewWithRibbon
        End Function

        Protected Overrides Function CreateExampleControls() As NWidget
            Dim stack As NStackPanel = New NStackPanel()

            ' Create the projection combo box
            m_ProjectionComboBox = New NComboBox()
            m_ProjectionComboBox.FillFromArray(m_Projections)
            m_ProjectionComboBox.SelectedIndex = DefaultProjectionIndex
            AddHandler m_ProjectionComboBox.SelectedIndexChanged, AddressOf OnProjectionComboSelectedIndexChanged
            Dim pairBox = NPairBox.Create("Projection:", m_ProjectionComboBox)
            stack.Add(pairBox)

            ' Create the label arcs check box
            Dim labelArcsCheckBox As NCheckBox = New NCheckBox()
            AddHandler labelArcsCheckBox.CheckedChanged, AddressOf OnLabelArcsCheckBoxCheckedChanged
            labelArcsCheckBox.HorizontalPlacement = ENHorizontalPlacement.Left
            labelArcsCheckBox.Padding = NMargins.Zero
            pairBox = NPairBox.Create("Label arcs:", labelArcsCheckBox)
            stack.Add(pairBox)

            ' Create the center parallel numeric up down
            m_CenterParalelNumericUpDown = New NNumericUpDown()
            m_CenterParalelNumericUpDown.Minimum = -90
            m_CenterParalelNumericUpDown.Maximum = 90
            m_CenterParalelNumericUpDown.Step = 15
            AddHandler m_CenterParalelNumericUpDown.ValueChanged, AddressOf OnCenterParallelNumericUpDownValueChanged
            stack.Add(NPairBox.Create("Central parallel:", m_CenterParalelNumericUpDown))

            ' Create the center meridian numeric up down
            m_CenterMeridianNumericUpDown = New NNumericUpDown()
            m_CenterMeridianNumericUpDown.Minimum = -180
            m_CenterMeridianNumericUpDown.Maximum = 180
            m_CenterMeridianNumericUpDown.Step = 15
            AddHandler m_CenterMeridianNumericUpDown.ValueChanged, AddressOf OnCenterMeridianNumericUpDownValueChanged
            stack.Add(NPairBox.Create("Central meridian:", m_CenterMeridianNumericUpDown))
            Dim settingsGroupBox As NGroupBox = New NGroupBox("Settings", New NUniSizeBoxGroup(stack))
            Return settingsGroupBox
        End Function

        Protected Overrides Function GetExampleDescription() As String
            Return "
<p>
    <b>NOV Diagram</b> makes it easy to import geographical data from ESRI shapefiles. You
    can control the way the shapes are rendered by applying various fill rules to them. You can
	also specify a map projection to be used for transforming the 3D geographical data to 2D
	screen coordinates as this example demonstrates. Using the controls on the right you can
	change the map projection and turn on or off the arc labelling. Note that some projections
	also lets you specify a central parallel and/or meridian.
</p>
<p>
	Upon import of a shape additional information from the DBF file that accompanies the shapefile
	is provided (e.g. Country Name, Population, Currency, GDP, etc.). You can use these values to
	customize the name, the text and the fill of the shape. You can also provide an INShapeCreatedListener
	implementation to the shape importer of the map in order to get notified when a shape is imported
	and use the values from the DBF file for this shape to customize it even further.
</p>"
        End Function

        Private Sub InitDiagram(ByVal drawingDocument As NDrawingDocument)
            ' Configure the document
            Dim drawing = drawingDocument.Content
            drawing.ScreenVisibility.ShowGrid = False

            ' Add styles
            AddStyles(drawingDocument)

            ' Configure the active page
            Dim page = drawing.ActivePage
            page.BackgroundFill = New NColorFill(NColor.LightBlue)
            page.Bounds = New NRectangle(0, 0, 10000, 10000)
            page.ZoomMode = ENZoomMode.Fit

            ' Create a map importer
            m_MapImporter = New NEsriMapImporter()
            m_MapImporter.MapBounds = NMapBounds.World
            m_MapImporter.MeridianSettings.RenderMode = ENArcRenderMode.BelowObjects
            m_MapImporter.ParallelSettings.RenderMode = ENArcRenderMode.BelowObjects
            m_MapImporter.Projection = m_Projections(DefaultProjectionIndex)

            ' Add an ESRI shapefile
            Dim countries As NEsriShapefile = New NEsriShapefile(NResources.RBIN_countries_zip)
            countries.NameColumn = "name_long"
            countries.FillRule = New NMapFillRuleValue("mapcolor8", Colors)
            m_MapImporter.AddShapefile(countries)

            ' Read the map data
            m_MapImporter.Read()
            ImportMap()
        End Sub

#End Region

#Region "Implementation"

        Private Sub AddStyles(ByVal document As NDrawingDocument)
            ' Create a style sheet
            Dim styleSheet As NStyleSheet = New NStyleSheet()
            document.StyleSheets.Add(styleSheet)

            ' Add some styling for the shapes
            Dim rule As NRule = New NRule()
            Dim sb As NSelectorBuilder = rule.GetSelectorBuilder()
            sb.Start()
            sb.Type(NGeometry.NGeometrySchema)
            sb.ChildOf()
            sb.Type(NShape.NShapeSchema)
            sb.End()
            rule.Declarations.Add(New NValueDeclaration(Of NStroke)(NGeometry.StrokeProperty, New NStroke(New NColor(68, 90, 108))))
            styleSheet.Add(rule)
        End Sub

        Private Sub ImportMap()
            Dim page = m_DrawingView.ActivePage
            page.Items.Clear()

            ' Import the map to the drawing document
            m_MapImporter.Import(m_DrawingView.Document, page.Bounds)
        End Sub

#End Region

#Region "Event Handlers"

        Private Sub OnProjectionComboSelectedIndexChanged(ByVal arg As NValueChangeEventArgs)
            Dim projectionCombo = CType(arg.TargetNode, NComboBox)
            Dim projection = CType(projectionCombo.SelectedItem.Tag, NMapProjection)
            m_MapImporter.Projection = projection

            ' Reimport the map applying the newly selected projection
            If TypeOf m_MapImporter.Projection Is NOrthographicProjection Then
                GetOwnerPairBox(m_CenterParalelNumericUpDown).Visibility = ENVisibility.Visible
                GetOwnerPairBox(m_CenterMeridianNumericUpDown).Visibility = ENVisibility.Visible
                Dim ortographicProjection = CType(m_MapImporter.Projection, NOrthographicProjection)
                ortographicProjection.CenterPoint = New NPoint(m_CenterMeridianNumericUpDown.Value, m_CenterParalelNumericUpDown.Value)
            ElseIf TypeOf m_MapImporter.Projection Is NBonneProjection Then
                GetOwnerPairBox(m_CenterParalelNumericUpDown).Visibility = ENVisibility.Visible
                GetOwnerPairBox(m_CenterMeridianNumericUpDown).Visibility = ENVisibility.Hidden
                CType(m_MapImporter.Projection, NBonneProjection).StandardParallel = m_CenterParalelNumericUpDown.Value
            Else
                GetOwnerPairBox(m_CenterParalelNumericUpDown).Visibility = ENVisibility.Hidden
                GetOwnerPairBox(m_CenterMeridianNumericUpDown).Visibility = ENVisibility.Hidden
            End If

            ImportMap()
        End Sub

        Private Sub OnLabelArcsCheckBoxCheckedChanged(ByVal arg As NValueChangeEventArgs)
            Dim showLabels As Boolean = arg.NewValue
            m_MapImporter.ParallelSettings.ShowLabels = showLabels
            m_MapImporter.MeridianSettings.ShowLabels = showLabels
            ImportMap()
        End Sub

        Private Sub OnCenterParallelNumericUpDownValueChanged(ByVal arg As NValueChangeEventArgs)
            Dim value As Double = arg.NewValue

            If TypeOf m_MapImporter.Projection Is NBonneProjection Then
                CType(m_MapImporter.Projection, NBonneProjection).StandardParallel = value
                ImportMap()
            ElseIf TypeOf m_MapImporter.Projection Is NOrthographicProjection Then
                Dim ortographicProjection = CType(m_MapImporter.Projection, NOrthographicProjection)
                ortographicProjection.CenterPoint = New NPoint(ortographicProjection.CenterPoint.X, value)
                ImportMap()
            End If
        End Sub

        Private Sub OnCenterMeridianNumericUpDownValueChanged(ByVal arg As NValueChangeEventArgs)
            Dim value As Double = arg.NewValue

            If TypeOf m_MapImporter.Projection Is NOrthographicProjection Then
                Dim ortographicProjection = CType(m_MapImporter.Projection, NOrthographicProjection)
                ortographicProjection.CenterPoint = New NPoint(value, ortographicProjection.CenterPoint.Y)
                ImportMap()
            End If
        End Sub

#End Region

#Region "Fields"

        Private m_DrawingView As NDrawingView
        Private m_Projections As NMapProjection()
        Private m_MapImporter As NEsriMapImporter
        Private m_ProjectionComboBox As NComboBox
        Private m_CenterParalelNumericUpDown As NNumericUpDown
        Private m_CenterMeridianNumericUpDown As NNumericUpDown

#End Region

#Region "Schema"

        ''' <summary>
        ''' Schema associated with NMapProjectionsExample.
        ''' </summary>
        Public Shared ReadOnly NMapProjectionsExampleSchema As NSchema

#End Region

#Region "Static Methods"

        Private Shared Function GetOwnerPairBox(ByVal widget As NWidget) As NPairBox
            Return CType(widget.GetFirstAncestor(NPairBox.NPairBoxSchema), NPairBox)
        End Function

#End Region

#Region "Constants"

        Private Const DefaultProjectionIndex As Integer = 16

        ''' <summary>
        ''' The colors used to fill the countries.
        ''' </summary>
        Private Shared ReadOnly Colors As NColor() = New NColor() {NColor.OldLace, NColor.PaleGreen, NColor.Gold, NColor.Khaki, NColor.Tan, NColor.Orange, NColor.Salmon, NColor.PaleGoldenrod}

#End Region
    End Class
End Namespace

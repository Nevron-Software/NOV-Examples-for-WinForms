Imports Nevron.Nov.DataStructures
Imports Nevron.Nov.Diagram
Imports Nevron.Nov.Diagram.Shapes
Imports Nevron.Nov.Dom
Imports Nevron.Nov.Editors
Imports Nevron.Nov.Graphics
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.Diagram
    Public Class NTranslationSlavesExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' Default constructor.
        ''' </summary>
        Public Sub New()
        End Sub

        ''' <summary>
        ''' Static constructor.
        ''' </summary>
        Shared Sub New()
            NTranslationSlavesExampleSchema = NSchema.Create(GetType(NTranslationSlavesExample), NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            ' Create a simple drawing
            Dim drawingViewWithRibbon As NDrawingViewWithRibbon = New NDrawingViewWithRibbon()
            m_DrawingView = drawingViewWithRibbon.View

            m_DrawingView.Document.HistoryService.Pause()
            Try
                InitDiagram(m_DrawingView.Document)
            Finally
                m_DrawingView.Document.HistoryService.Resume()
            End Try

            Return drawingViewWithRibbon
        End Function
        Protected Overrides Function CreateExampleControls() As NWidget
            m_PropertyEditorHolder = New NContentHolder()
            Return m_PropertyEditorHolder
        End Function
        Protected Overrides Function GetExampleDescription() As String
            Return "
<p>
This example demonstrates the shape move slaves. 
</p>
<p>
It is in many cases necessary to implement rigid connected shapes structures. In NOV Diagram this is achieved with the help of shape move slaves. 
</p>
<p>
The move slaves of a shape are such shapes, which are moved together with the shape. The accumulation of the shape move slaves is recursive. For example: if a shape has to be moved, because it is a move slave, then its move slaves will also be moved. 
</p>
<p>
To explore move slaves behavior just select a shape in the diagram and check the shapes, which must be moved when it is move. Then move the shape. 
</p>
<p>
Note that the example will automatically highlight the move slaves of the currently selected shape. 
</p>
            " End Function

        Private Sub InitDiagram(ByVal drawingDocument As NDrawingDocument)
            Dim template As NGraphTemplate

            ' create rectangular grid template
            template = New NRectangularGridTemplate()
            template.Origin = New NPoint(10, 23)
            template.VertexShape = ENBasicShape.Rectangle
            template.EdgeUserClass = NDR.StyleSheetNameConnectors
            template.Create(drawingDocument)

            ' create tree template
            template = New NGenericTreeTemplate()
            template.Origin = New NPoint(250, 23)
            template.VertexShape = ENBasicShape.Triangle
            template.EdgeUserClass = NDR.StyleSheetNameConnectors
            template.Create(drawingDocument)

            ' create elliptical grid template
            template = New NEllipticalGridTemplate()
            template.Origin = New NPoint(10, 250)
            template.VertexShape = ENBasicShape.Ellipse
            template.EdgeUserClass = NDR.StyleSheetNameConnectors
            template.Create(drawingDocument)

            ' hook selection events
            Dim selection = drawingDocument.Content.ActivePage.Selection
            selection.Mode = ENSelectionMode.[Single]
            selection.Selected += AddressOf OnSelectionSelected
            selection.Deselected += AddressOf OnSelectionDeselected
        End Sub


#End Region

#Region "Implementation"

        ''' <summary>
        ''' Called when a diagram item has been selected.
        ''' </summary>
        ''' <paramname="arg"></param>
        Private Sub OnSelectionSelected(ByVal arg As NSelectEventArgs(Of NPageItem))
            Dim shape As NShape = TryCast(arg.Item, NShape)
            If shape Is Nothing Then Return

            ' create the shape move slaves property editor
            m_PropertyEditorHolder.Content = NDesigner.GetDesigner(shape).CreatePropertyEditor(shape, NShape.MoveSlavesProperty)

            ' subscribe for move slaves property changes.
            shape.AddEventHandler(NShape.MoveSlavesProperty.ValueChangedEvent, New NEventHandler(Of NValueChangeEventArgs)(AddressOf OnMoveSlavesPropertyChanged))

            ' highlight the shape current slaves
            HighlightSlaves(shape)
        End Sub
        ''' <summary>
        ''' Called when a diagram item has been deselected.
        ''' </summary>
        ''' <paramname="arg"></param>
        Private Sub OnSelectionDeselected(ByVal arg As NSelectEventArgs(Of NPageItem))
            Dim shape As NShape = TryCast(arg.Item, NShape)
            If shape Is Nothing Then Return

            ' unhook move slaves property changed event
            shape.RemoveEventHandler(NShape.MoveSlavesProperty.ValueChangedEvent, New NEventHandler(Of NValueChangeEventArgs)(AddressOf OnMoveSlavesPropertyChanged))

            ' clear hightlights
            ClearHighlights()

            ' destroy property editor
            m_PropertyEditorHolder.Content = Nothing
        End Sub
        ''' <summary>
        ''' Called when the MoveSlaves property of the currently selected shape has changed.
        ''' </summary>
        ''' <paramname="arg"></param>
        Private Sub OnMoveSlavesPropertyChanged(ByVal arg As NValueChangeEventArgs)
            Dim shape As NShape = TryCast(arg.TargetNode, NShape)
            If shape Is Nothing Then Return

            ' highligh the shape move slaves
            HighlightSlaves(shape)
        End Sub
        ''' <summary>
        ''' Clears the highlighting on all shapes in the active page.
        ''' </summary>
        Private Sub ClearHighlights()
            Dim shapes = m_DrawingView.ActivePage.GetShapes(True)
            For i = 0 To shapes.Count - 1
                Dim shape = shapes(i)
                shape.Geometry.ClearValue(NGeometry.FillProperty)
                shape.Geometry.ClearValue(NGeometry.StrokeProperty)
            Next
        End Sub
        ''' <summary>
        ''' Highlights the move slaves of the specified shape
        ''' </summary>
        ''' <paramname="shape"></param>
        Private Sub HighlightSlaves(ByVal shape As NShape)
            ClearHighlights()

            Dim shapes As NList(Of NShape) = shape.GetMoveSlaves()
            For i = 0 To shapes.Count - 1
                Dim cur = shapes(i)
                cur.Geometry.Fill = New NColorFill(NColor.LightCoral)
                cur.Geometry.Stroke = New NStroke(2, NColor.DarkRed)
            Next
        End Sub

#End Region

#Region "Fields"

        Private m_DrawingView As NDrawingView
        Private m_PropertyEditorHolder As NContentHolder

#End Region

#Region "Schema"

        ''' <summary>
        ''' Schema associated with NTranslationSlavesExample.
        ''' </summary>
        Public Shared ReadOnly NTranslationSlavesExampleSchema As NSchema

#End Region
    End Class
End Namespace

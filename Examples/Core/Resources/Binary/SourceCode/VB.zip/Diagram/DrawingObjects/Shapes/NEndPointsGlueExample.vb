Imports System
Imports Nevron.Nov.Diagram
Imports Nevron.Nov.Diagram.Shapes
Imports Nevron.Nov.Dom
Imports Nevron.Nov.Editors
Imports Nevron.Nov.Graphics
Imports Nevron.Nov.Layout
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.Diagram
    Public Class NEndPointsGlueExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' Default constructor.
        ''' </summary>
        Public Sub New()
            AddHandler m_Timer.Tick, AddressOf OnTimerTick
        End Sub
        ''' <summary>
        ''' Static constructor.
        ''' </summary>
        Shared Sub New()
            NEndPointsGlueExampleSchema = NSchema.Create(GetType(NEndPointsGlueExample), NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            ' Create a simple drawing
            Dim drawingViewWithRibbon As NDrawingViewWithRibbon = New NDrawingViewWithRibbon()
            m_DrawingView = drawingViewWithRibbon.View
            m_DrawingView.Document.HistoryService.Pause()

            Try
                InitDiagram(m_DrawingView.Document)
            Finally
                m_DrawingView.Document.HistoryService.Resume()
            End Try

            AddHandler m_DrawingView.Registered, AddressOf OnDrawingViewRegistered
            AddHandler m_DrawingView.Unregistered, AddressOf OnDrawingViewUnregistered
            Return drawingViewWithRibbon
        End Function

        Protected Overrides Function CreateExampleControls() As NWidget
            Dim stack As NStackPanel = New NStackPanel()
            stack.FillMode = ENStackFillMode.Last

            ' selection mode
            If True Then
                m_RadioGroup = New NRadioButtonGroup()
                Dim radioStack As NStackPanel = New NStackPanel()
                m_RadioGroup.Content = radioStack
                radioStack.Add(New NRadioButton("Glue To Nearest Port"))
                radioStack.Add(New NRadioButton("Glue To Shape Box Intersection"))
                radioStack.Add(New NRadioButton("Glue To Geometry Intersection"))
                radioStack.Add(New NRadioButton("Glue To Shape Box"))
                radioStack.Add(New NRadioButton("Glue To Geometry Contour"))
                radioStack.Add(New NRadioButton("Glue To Port"))
                stack.Add(New NGroupBox("Select Glue Mode", m_RadioGroup))
            End If

            ' glue properties
            If True Then
                Dim holdersStack As NStackPanel = New NStackPanel()
                stack.Add(holdersStack)
                m_BeginGlueHolder = New NGroupBox("Begin Glue Properties")
                holdersStack.Add(m_BeginGlueHolder)
                m_EndGlueHolder = New NGroupBox("End Glue Properties")
                holdersStack.Add(m_EndGlueHolder)
            End If

            ' timer
            If True Then
                Dim timerStack As NStackPanel = New NStackPanel()
                Dim startRotationButton As NButton = New NButton("Start Rotation")
                AddHandler startRotationButton.Click, Sub(ByVal args) m_Timer.Start()
                timerStack.Add(startRotationButton)
                Dim stopRotationButton As NButton = New NButton("Stop Rotation")
                AddHandler stopRotationButton.Click, Sub(ByVal args) m_Timer.Stop()
                timerStack.Add(stopRotationButton)
                stack.Add(timerStack)
            End If

            ' select the first glue mode
            AddHandler m_RadioGroup.SelectedIndexChanged, AddressOf OnRadioGroupSelectedIndexChanged
            m_RadioGroup.SelectedIndex = 0
            Return stack
        End Function

        Protected Overrides Function GetExampleDescription() As String
            Return "
<p>
    Demonstrates the End-Points glue and the API you can use to glue the begin and end points.
</p>
<p>
    The begin or end point of a 1D shape can be glued in the following ways:
    <ul>
        <li>
            <b>Glue To Nearest Port</b> The begin or end point is glued to the nearest port in respect to the other end-point.
        </li>
        <li>
            <b>Glue To Shape Box Intersection</b> The begin or end point is glued to the intersection of the shape box and the line formed by the shape center and the other end-point.
        </li>
        <li>
            <b>Glue To Geometry Intersection</b> The begin or end point is glued to the intersection of the shape geometry and the line formed by the shape center and the other end-point.
        </li>
        <li>
            <b>Glue To Shape Box</b> The begin or end point is glued to a point in the shape Width-Height box. The point is defined in relative coordinates.
        </li>
        <li>
            <b>Glue To Geometry Contour</b> The begin or end point is glued to a point along the shape geometry contour (outline). The point is defined a factor - 0 is the contour begin, 1 is the contour end.
        </li>
        <li>
            <b>Glue To Port</b> The begin or end point is glued to a port of the target shape. The port is defined by its index.
        </li>
    </ul>
</p>
            "
        End Function

        Private Sub InitDiagram(ByVal drawingDocument As NDrawingDocument)
            Dim drawing = drawingDocument.Content

            ' Hide the grid
            drawing.ScreenVisibility.ShowGrid = False

            ' Create two shapes and a line connector between them
            Dim basicShapes As NBasicShapeFactory = New NBasicShapeFactory()
            Dim connectorShapes As NConnectorShapeFactory = New NConnectorShapeFactory()
            m_BeginShape = basicShapes.CreateShape(ENBasicShape.Ellipse)
            m_BeginShape.Size = New NSize(150, 100)
            drawing.ActivePage.Items.Add(m_BeginShape)
            m_EndShape = basicShapes.CreateShape(ENBasicShape.Pentagram)
            m_EndShape.Size = New NSize(100, 100)
            drawing.ActivePage.Items.Add(m_EndShape)
            m_Connector = connectorShapes.CreateShape(ENConnectorShape.Line)
            m_Connector.GlueBeginToNearestPort(m_BeginShape)
            m_Connector.GlueEndToNearestPort(m_EndShape)
            drawing.ActivePage.Items.Add(m_Connector)

            ' Perform inital layout of shapes
            OnTimerTick()
        End Sub

#End Region

#Region "Event Handlers"

        Private Sub OnDrawingViewRegistered(ByVal arg As NEventArgs)
            m_Timer.Start()
        End Sub

        Private Sub OnDrawingViewUnregistered(ByVal arg As NEventArgs)
            m_Timer.Stop()
        End Sub

        Private Sub OnTimerTick()
            Dim centerOfRotation As NPoint = New NPoint(m_DrawingView.ActivePage.Bounds.CenterX, 300)
            Const radius As Double = 150
            Dim beginCenter As NPoint = centerOfRotation + New NPoint(Math.Cos(m_dAngle) * radius, Math.Sin(m_dAngle) * radius)
            m_BeginShape.SetBounds(NRectangle.FromCenterAndSize(beginCenter, m_BeginShape.Width, m_BeginShape.Height))
            Dim endCenter As NPoint = centerOfRotation + New NPoint(Math.Cos(m_dAngle + NMath.PI) * radius, Math.Sin(m_dAngle + NMath.PI) * radius)
            m_EndShape.SetBounds(NRectangle.FromCenterAndSize(endCenter, m_EndShape.Width, m_EndShape.Height))
            m_dAngle += NMath.PI / 180
        End Sub

        Private Sub OnRadioGroupSelectedIndexChanged(ByVal arg As NValueChangeEventArgs)
            Select Case m_RadioGroup.SelectedIndex
                Case 0 ' glue to nearest port
                    m_Connector.GlueBeginToNearestPort(m_BeginShape)
                    m_Connector.GlueEndToNearestPort(m_EndShape)
                Case 1 ' glue to box intersection
                    m_Connector.GlueBeginToShapeBoxIntersection(m_BeginShape)
                    m_Connector.GlueEndToShapeBoxIntersection(m_EndShape)
                Case 2 ' glue to box intersection
                    m_Connector.GlueBeginToGeometryIntersection(m_BeginShape)
                    m_Connector.GlueEndToGeometryIntersection(m_EndShape)
                Case 3 ' glue to box location
                    m_Connector.GlueBeginToShapeBox(m_BeginShape, 0.3R, 0.3R)
                    m_Connector.GlueEndToShapeBox(m_EndShape, 0.3R, 0.3R)
                Case 4 ' glue to geometry contour
                    m_Connector.GlueBeginToGeometryContour(m_BeginShape, 0.5R)
                    m_Connector.GlueEndToGeometryContour(m_EndShape, 0.5R)
                Case 5 ' glue to port
                    m_Connector.GlueBeginToPort(m_BeginShape.Ports(0))
                    m_Connector.GlueEndToPort(m_EndShape.Ports(0))
            End Select

            ' update the begin point glue properties
            If m_Connector.BeginPointGlue Is Nothing Then
                m_BeginGlueHolder.Content = Nothing
                m_BeginGlueHolder.Visibility = ENVisibility.Collapsed
            Else
                m_BeginGlueHolder.Visibility = ENVisibility.Visible
                m_BeginGlueHolder.Content = NDesigner.GetDesigner(m_Connector.BeginPointGlue).CreateInstanceEditor(m_Connector.BeginPointGlue)
            End If

            ' update the end point glue properties
            If m_Connector.EndPointGlue Is Nothing Then
                m_EndGlueHolder.Content = Nothing
                m_EndGlueHolder.Visibility = ENVisibility.Collapsed
            Else
                m_EndGlueHolder.Visibility = ENVisibility.Visible
                m_EndGlueHolder.Content = NDesigner.GetDesigner(m_Connector.EndPointGlue).CreateInstanceEditor(m_Connector.EndPointGlue)
            End If
        End Sub

#End Region

#Region "Fields"

        Private m_DrawingView As NDrawingView
        Private m_BeginShape As NShape
        Private m_EndShape As NShape
        Private m_Connector As NShape
        Private m_Timer As NTimer = New NTimer(50)
        Private m_RadioGroup As NRadioButtonGroup
        Private m_BeginGlueHolder As NGroupBox
        Private m_EndGlueHolder As NGroupBox
        Private m_dAngle As Double = 0

#End Region

#Region "Schema"

        ''' <summary>
        ''' Schema associated with NEndPointsGlueExample.
        ''' </summary>
        Public Shared ReadOnly NEndPointsGlueExampleSchema As NSchema

#End Region
    End Class
End Namespace

Imports Nevron.Nov.Diagram
Imports Nevron.Nov.Diagram.Shapes
Imports Nevron.Nov.Dom
Imports Nevron.Nov.Graphics
Imports Nevron.Nov.Text
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.Diagram
    Public Class NImageBlockExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' Default constructor.
        ''' </summary>
        Public Sub New()
        End Sub

        ''' <summary>
        ''' Static constructor.
        ''' </summary>
        Shared Sub New()
            NImageBlockExampleSchema = NSchema.Create(GetType(NImageBlockExample), NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            ' Create a simple drawing
            Dim drawingViewWithRibbon As NDrawingViewWithRibbon = New NDrawingViewWithRibbon()
            m_DrawingView = drawingViewWithRibbon.View
            m_DrawingView.Document.HistoryService.Pause()

            Try
                InitDiagram(m_DrawingView.Document)
            Finally
                m_DrawingView.Document.HistoryService.Resume()
            End Try

            Return drawingViewWithRibbon
        End Function

        Protected Overrides Function CreateExampleControls() As NWidget
            Return Nothing
        End Function

        Protected Overrides Function GetExampleDescription() As String
            Return "<p>Demonstrates image blocks.</p>"
        End Function

        Private Sub InitDiagram(ByVal drawingDocument As NDrawingDocument)
            Dim drawing = drawingDocument.Content

            ' hide the grid
            drawing.ScreenVisibility.ShowGrid = False
            Dim basicShapesFactory As NBasicShapeFactory = New NBasicShapeFactory()
            Dim shape1 = basicShapesFactory.CreateShape(ENBasicShape.Rectangle)
            shape1.SetBounds(10, 10, 600, 1000)
            Dim imageBlock = shape1.ImageBlock
            imageBlock.Image = NResources.Image_FishBowl_wmf
            imageBlock.Padding = New NMargins(20)
            drawing.ActivePage.Items.Add(shape1)
        End Sub

#End Region

#Region "Implementation "

        ''' <summary>
        ''' Adds rich formatted text to the specified text block content
        ''' </summary>
        ''' <paramname="content"></param>
        Private Sub AddFormattedTextToContent(ByVal content As NTextBlockContent)
            content.Blocks.Add(GetTitleParagraph("Bullet lists allow you to apply automatic numbering on paragraphs or groups of blocks.", 1))

            ' setting bullet list template type
            If True Then
                content.Blocks.Add(GetTitleParagraph("Following are bullet lists with different formatting", 2))
                Dim values As ENBulletListTemplateType() = NEnum.GetValues(Of ENBulletListTemplateType)()
                Dim names As String() = NEnum.GetNames(Of ENBulletListTemplateType)()
                Dim itemText = "Bullet List Item"

                For i = 0 To values.Length - 1 - 1
                    Dim group As NGroupBlock = New NGroupBlock()
                    content.Blocks.Add(group)
                    group.MarginTop = 10
                    group.MarginBottom = 10
                    Dim bulletList As NBulletList = New NBulletList(values(i))
                    content.BulletLists.Add(bulletList)

                    For j = 0 To 3 - 1
                        Dim paragraph As NParagraph = New NParagraph(itemText & j.ToString())
                        Dim bullet As NBulletInline = New NBulletInline()
                        bullet.List = bulletList
                        paragraph.Bullet = bullet
                        group.Blocks.Add(paragraph)
                    Next
                Next
            End If

            ' nested bullet lists
            If True Then
                content.Blocks.Add(GetTitleParagraph("Following is an example of bullets with different bullet level", 2))
                Dim bulletList As NBulletList = New NBulletList(ENBulletListTemplateType.Decimal)
                content.BulletLists.Add(bulletList)
                Dim group As NGroupBlock = New NGroupBlock()
                content.Blocks.Add(group)

                For i = 0 To 3 - 1
                    Dim par As NParagraph = New NParagraph("Bullet List Item" & i.ToString(), bulletList, 0)
                    group.Blocks.Add(par)

                    For j = 0 To 2 - 1
                        Dim nestedPar As NParagraph = New NParagraph("Nested Bullet List Item" & i.ToString(), bulletList, 1)
                        nestedPar.MarginLeft = 10
                        group.Blocks.Add(nestedPar)
                    Next
                Next
            End If
        End Sub
        ''' <summary>
        ''' 
        ''' </summary>
        ''' <paramname="text"></param>
        ''' <paramname="level"></param>
        ''' <returns></returns>
        Friend Shared Function GetTitleParagraphNoBorder(ByVal text As String, ByVal level As Integer) As NParagraph
            Dim fontSize As Double = 10
            Dim fontStyle = ENFontStyle.Regular

            Select Case level
                Case 1
                    fontSize = 16
                    fontStyle = ENFontStyle.Bold
                Case 2
                    fontSize = 10
                    fontStyle = ENFontStyle.Bold
            End Select

            Dim paragraph As NParagraph = New NParagraph()
            paragraph.HorizontalAlignment = ENAlign.Left
            paragraph.FontSize = fontSize
            paragraph.FontStyle = fontStyle
            Dim textInline As NTextInline = New NTextInline(text)
            textInline.FontStyle = fontStyle
            textInline.FontSize = fontSize
            paragraph.Inlines.Add(textInline)
            Return paragraph
        End Function
        ''' <summary>
        ''' Gets a paragraph with title formatting
        ''' </summary>
        ''' <paramname="text"></param>
        ''' <returns></returns>
        Friend Shared Function GetTitleParagraph(ByVal text As String, ByVal level As Integer) As NParagraph
            Dim color = NColor.Black
            Dim paragraph = GetTitleParagraphNoBorder(text, level)
            paragraph.HorizontalAlignment = ENAlign.Left
            paragraph.Border = CreateLeftTagBorder(color)
            paragraph.BorderThickness = New NMargins(5.0, 0.0, 0.0, 0.0)
            Return paragraph
        End Function
        ''' <summary>
        ''' Creates a left tag border with the specified border
        ''' </summary>
        ''' <paramname="color"></param>
        ''' <returns></returns>
        Private Shared Function CreateLeftTagBorder(ByVal color As NColor) As NBorder
            Dim border As NBorder = New NBorder()
            border.LeftSide = New NBorderSide()
            border.LeftSide.Fill = New NColorFill(color)
            Return border
        End Function

#End Region

#Region "Fields"

        Private m_DrawingView As NDrawingView

#End Region

#Region "Schema"

        ''' <summary>
        ''' Schema associated with NImageBlockExample.
        ''' </summary>
        Public Shared ReadOnly NImageBlockExampleSchema As NSchema

#End Region
    End Class
End Namespace

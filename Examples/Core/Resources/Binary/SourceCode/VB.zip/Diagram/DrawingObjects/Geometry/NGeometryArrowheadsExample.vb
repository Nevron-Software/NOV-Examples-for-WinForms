Imports Nevron.Nov.Diagram
Imports Nevron.Nov.Diagram.Shapes
Imports Nevron.Nov.Dom
Imports Nevron.Nov.Graphics
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.Diagram
    Public Class NGeometryArrowheadsExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' Default constructor.
        ''' </summary>
        Public Sub New()
        End Sub

        ''' <summary>
        ''' Static constructor.
        ''' </summary>
        Shared Sub New()
            NGeometryArrowheadsExampleSchema = NSchema.Create(GetType(NGeometryArrowheadsExample), NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            ' Create a simple drawing
            Dim drawingViewWithRibbon As NDrawingViewWithRibbon = New NDrawingViewWithRibbon()
            m_DrawingView = drawingViewWithRibbon.View

            m_DrawingView.Document.HistoryService.Pause()
            Try
                InitDiagram(m_DrawingView.Document)
            Finally
                m_DrawingView.Document.HistoryService.Resume()
            End Try

            Return drawingViewWithRibbon
        End Function
        Protected Overrides Function CreateExampleControls() As NWidget
            Return Nothing
        End Function
        Protected Overrides Function GetExampleDescription() As String
            Return "<p>Demonstrates the arrowhead styles included in NOV Diagram.</p>"
        End Function

        Private Sub InitDiagram(ByVal drawingDocument As NDrawingDocument)
            Dim drawing = drawingDocument.Content
            Dim activePage = drawing.ActivePage
            activePage.Layout.ContentPadding = New NMargins(20)

            ' switch selected edit mode to geometry
            ' this instructs the diagram to show geometry handles for the selected shapes.
            drawing.ScreenVisibility.ShowGrid = False

            Dim connectorShapes As NConnectorShapeFactory = New NConnectorShapeFactory()
            Dim arrowheadShapes As ENArrowheadShape() = NEnum.GetValues(Of ENArrowheadShape)()

            Dim x As Double = 20
            Dim y As Double = 0

            For i = 1 To arrowheadShapes.Length - 1
                Dim arrowheadShape = arrowheadShapes(i)
                Dim shape = connectorShapes.CreateShape(ENConnectorShape.Line)
                drawing.ActivePage.Items.Add(shape)

                ' create geometry arrowheads
                shape.Geometry.BeginArrowhead = New NArrowhead(arrowheadShape)
                shape.Geometry.EndArrowhead = New NArrowhead(arrowheadShape)

                shape.Text = NEnum.GetLocalizedString(arrowheadShape)

                shape.SetBeginPoint(New NPoint(x, y))
                shape.SetEndPoint(New NPoint(x + 350, y))

                y += 30

                If i = arrowheadShapes.Length / 2 Then
                    ' Begin a second column of shapes
                    x += 400
                    y = 0
                End If
            Next

            activePage.SizeToContent()
        End Sub

#End Region

#Region "Fields"

        Private m_DrawingView As NDrawingView

#End Region

#Region "Schema"

        ''' <summary>
        ''' Schema associated with NGeometryArrowheadsExample.
        ''' </summary>
        Public Shared ReadOnly NGeometryArrowheadsExampleSchema As NSchema

#End Region
    End Class
End Namespace

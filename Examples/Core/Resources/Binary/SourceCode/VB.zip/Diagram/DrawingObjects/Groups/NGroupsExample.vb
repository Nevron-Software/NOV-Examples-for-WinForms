Imports Nevron.Nov.Diagram
Imports Nevron.Nov.Diagram.Batches
Imports Nevron.Nov.Diagram.Shapes
Imports Nevron.Nov.Dom
Imports Nevron.Nov.Graphics
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.Diagram
    ''' <summary>
    ''' 
    ''' </summary>
    Public Class NGroupsExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' Default constructor.
        ''' </summary>
        Public Sub New()
        End Sub

        ''' <summary>
        ''' Static constructor.
        ''' </summary>
        Shared Sub New()
            NGroupsExampleSchema = NSchema.Create(GetType(NGroupsExample), NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            ' Create a simple drawing
            Dim drawingViewWithRibbon As NDrawingViewWithRibbon = New NDrawingViewWithRibbon()
            m_DrawingView = drawingViewWithRibbon.View

            m_DrawingView.Document.HistoryService.Pause()
            Try
                InitDiagram(m_DrawingView.Document)
            Finally
                m_DrawingView.Document.HistoryService.Resume()
            End Try

            Return drawingViewWithRibbon
        End Function
        Protected Overrides Function CreateExampleControls() As NWidget
            Return Nothing
        End Function
        Protected Overrides Function GetExampleDescription() As String
            Return "Demonstrates how to create and use groups."
        End Function

        Private Sub InitDiagram(ByVal drawingDocument As NDrawingDocument)
            ' create networks
            Dim network1 As NGroup = CreateNetwork(New NPoint(200, 20), "Network 1")
            Dim network2 As NGroup = CreateNetwork(New NPoint(400, 250), "Network 2")
            Dim network3 As NGroup = CreateNetwork(New NPoint(20, 250), "Network 3")
            Dim network4 As NGroup = CreateNetwork(New NPoint(200, 475), "Network 4")

            ' connect networks
            ConnectNetworks(network1, network2)
            ConnectNetworks(network1, network3)
            ConnectNetworks(network1, network4)

            ' hide some elements
            drawingDocument.Content.ScreenVisibility.ShowPorts = False
            drawingDocument.Content.ScreenVisibility.ShowGrid = False
        End Sub

#End Region

#Region "Implementation"

        Protected Function CreateNetwork(ByVal location As NPoint, ByVal labelText As String) As NGroup
            Dim rectValid = False
            Dim rect = NRectangle.Zero
            Dim activePage = m_DrawingView.ActivePage

            Dim shapes = activePage.GetShapes(False)
            For i = 0 To shapes.Count - 1
                Dim bounds As NRectangle = shapes(i).GetAlignBoxInPage()
                If rectValid Then
                    rect = NRectangle.Union(rect, bounds)
                Else
                    rect = bounds
                    rectValid = True
                End If
            Next

            If rectValid Then
                ' determine how much is out of layout area
            End If

            ' create computer1
            Dim computer1 As NShape = CreateComputer()
            computer1.SetBounds(0, 0, computer1.Width, computer1.Height)

            ' create computer2
            Dim computer2 As NShape = CreateComputer()
            computer2.SetBounds(150, 0, computer2.Width, computer2.Height)

            ' create computer3
            Dim computer3 As NShape = CreateComputer()
            computer3.SetBounds(75, 120, computer3.Width, computer3.Height)

            ' create the group that contains the comptures
            Dim group As NGroup = New NGroup()
            Dim batchGroup As NBatchGroup(Of NShape) = New NBatchGroup(Of NShape)(m_DrawingView.Document)
            batchGroup.Build(computer1, computer2, computer3)
            batchGroup.Group(m_DrawingView.ActivePage, group)

            ' connect the computers in the network
            ConnectComputers(computer1, computer2, group)
            ConnectComputers(computer2, computer3, group)
            ConnectComputers(computer3, computer1, group)

            ' insert a frame
            Dim drawRect As NDrawRectangle = New NDrawRectangle(0, 0, 1, 1)
            drawRect.Relative = True
            group.Geometry.Add(drawRect)

            ' change group fill style
            group.Geometry.Fill = New NStockGradientFill(ENGradientStyle.FromCenter, ENGradientVariant.Variant2, NColor.Gainsboro, NColor.White)

            ' reposition and resize the group
            group.SetBounds(location.X, location.Y, group.Width, group.Height)

            ' set label text
            group.TextBlock.Text = labelText

            Return group
        End Function

        Protected Function CreateComputer() As NShape
            Dim computerShape = NLibrary.FlowchartShapes.CreateShape(ENFlowchartingShape.Database)
            Return computerShape
        End Function

        Private Sub ConnectNetworks(ByVal fromNetwork As NGroup, ByVal toNetwork As NGroup)
            Dim lineShape = m_ConnectorShapes.CreateShape(ENConnectorShape.Line)
            lineShape.GlueBeginToShape(fromNetwork)
            lineShape.GlueEndToShape(toNetwork)
            m_DrawingView.ActivePage.Items.Add(lineShape)
        End Sub

        Private Sub ConnectComputers(ByVal fromComputer As NShape, ByVal toComputer As NShape, ByVal group As NGroup)
            Dim lineShape = m_ConnectorShapes.CreateShape(ENConnectorShape.Line)
            lineShape.GlueBeginToShapeBoxIntersection(fromComputer)
            lineShape.GlueEndToShapeBoxIntersection(toComputer)
            group.Shapes.Add(lineShape)
        End Sub

#End Region

#Region "Fields"

        Private m_DrawingView As NDrawingView
        Private m_ConnectorShapes As NConnectorShapeFactory = New NConnectorShapeFactory()

#End Region

#Region "Schema"

        ''' <summary>
        ''' Schema associated with NGroupsExample.
        ''' </summary>
        Public Shared ReadOnly NGroupsExampleSchema As NSchema

#End Region
    End Class
End Namespace

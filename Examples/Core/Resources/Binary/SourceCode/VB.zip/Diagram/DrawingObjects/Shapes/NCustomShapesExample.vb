Imports Nevron.Nov.Diagram
Imports Nevron.Nov.Diagram.Batches
Imports Nevron.Nov.Diagram.Expressions
Imports Nevron.Nov.Dom
Imports Nevron.Nov.Graphics
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.Diagram
    Public Class NCustomShapesExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' Default constructor.
        ''' </summary>
        Public Sub New()
        End Sub

        ''' <summary>
        ''' Static constructor.
        ''' </summary>
        Shared Sub New()
            NCustomShapesExampleSchema = NSchema.Create(GetType(NCustomShapesExample), NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            ' Create a simple drawing
            Dim drawingViewWithRibbon As NDrawingViewWithRibbon = New NDrawingViewWithRibbon()
            m_DrawingView = drawingViewWithRibbon.View
            m_DrawingView.Document.HistoryService.Pause()

            Try
                InitDiagram(m_DrawingView.Document)
            Finally
                m_DrawingView.Document.HistoryService.Resume()
            End Try

            Return drawingViewWithRibbon
        End Function

        Protected Overrides Function CreateExampleControls() As NWidget
            Return Nothing
        End Function

        Protected Overrides Function GetExampleDescription() As String
            Return "
<p>
    Demonstrates how to create custom shapes by combining shapes and also how to create custom formula shapes with control points.
</p>
<p>
    The Coffee Cup shape is created by grouping shapes with different fill styles inside a group. 
    By using this approach you can create shapes that mix different fill and stroke styles.
</p>
<p>
    The Trapezoid Shape is a replica of the Visio Trapezoid Smart Shape. 
    It demonstrates that with NOV Diagram you can replicate the Shape Sheet behavior of almost any Visio shape.
    Select the shape and move its control point to modify the trapezoid strip width. 
    Note that the geometry, left and right ports and XControl point behavior of this shape are driven by formula expressions.
</p>
            "
        End Function

        Private Sub InitDiagram(ByVal drawingDocument As NDrawingDocument)
            AddHandler m_DrawingView.ActivePage.Interaction.GluingShapes, AddressOf Interaction_GluingShapes

            ' create the coffee cup
            Dim coffeeCup As NShape = CreateCoffeeCupShape()
            coffeeCup.SetBounds(New NRectangle(50, 50, 100, 200))
            drawingDocument.Content.ActivePage.Items.Add(coffeeCup)
            Dim trapedzoid As NShape = CreateTrapedzoidShape()
            trapedzoid.SetBounds(New NRectangle(200, 150, 100, 100))
            drawingDocument.Content.ActivePage.Items.Add(trapedzoid)
        End Sub

        ''' <summary>
        ''' Creates a custom shape that is essentially a group consisting of three other shapes each with different filling.
        ''' You need to use groups to have shapes that mix different fill, or stroke styles.
        ''' </summary>
        ''' <returns></returns>
        Private Function CreateCoffeeCupShape() As NShape
            ' create the points and paths from which the shape consits
            Dim cupPoints As NPoint() = New NPoint() {New NPoint(45, 268), New NPoint(63, 331), New NPoint(121, 331), New NPoint(140, 268)}
            Dim handleGraphicsPath As NGraphicsPath = New NGraphicsPath()
            handleGraphicsPath.AddClosedCurve(New NPoint() {New NPoint(175, 295), New NPoint(171, 278), New NPoint(140, 283), New NPoint(170, 290), New NPoint(128, 323)}, 1)
            Dim steamGraphicsPath As NGraphicsPath = New NGraphicsPath()
            steamGraphicsPath.AddCubicBeziers(New NPoint() {New NPoint(92, 270), New NPoint(53, 163), New NPoint(145, 160), New NPoint(86, 50), New NPoint(138, 194), New NPoint(45, 145), New NPoint(92, 270)})
            steamGraphicsPath.CloseFigure()

            ' calculate some bounds
            Dim handleBounds = handleGraphicsPath.ExactBounds
            Dim cupBounds = NGeometry2D.GetBounds(cupPoints)
            Dim steamBounds = steamGraphicsPath.ExactBounds
            Dim geometryBounds = NRectangle.Union(cupBounds, handleBounds, steamBounds)

            ' normalize the points and paths by transforming them to relative coordinates
            Dim normalRect As NRectangle = New NRectangle(0, 0, 1, 1)
            Dim transform = NMatrix.CreateBoundsStretchMatrix(geometryBounds, normalRect)
            transform.TransformPoints(cupPoints)
            handleGraphicsPath.Transform(transform)
            steamGraphicsPath.Transform(transform)

            ' create the cup shape
            Dim cupPolygon As NDrawPolygon = New NDrawPolygon(normalRect, cupPoints)
            cupPolygon.Relative = True
            Dim cupShape As NShape = New NShape()
            cupShape.Init2DShape()
            cupShape.Geometry.Fill = New NColorFill(NColor.Brown)
            cupShape.Geometry.Add(cupPolygon)
            cupShape.SetBounds(geometryBounds)

            ' create the cup handle
            Dim handlePath As NDrawPath = New NDrawPath(normalRect, handleGraphicsPath)
            handlePath.Relative = True
            Dim handleShape As NShape = New NShape()
            handleShape.Init2DShape()
            handleShape.Geometry.Fill = New NColorFill(NColor.LightSalmon)
            handleShape.Geometry.Add(handlePath)
            handleShape.SetBounds(geometryBounds)

            ' create the steam
            Dim steamPath As NDrawPath = New NDrawPath(steamGraphicsPath.Bounds, steamGraphicsPath)
            steamPath.Relative = True
            Dim steamShape As NShape = New NShape()
            steamShape.Init2DShape()
            steamShape.Geometry.Fill = New NColorFill(New NColor(50, 122, 122, 122))
            steamShape.Geometry.Add(steamPath)
            steamShape.SetBounds(geometryBounds)

            ' group the shapes as a single group
            Dim group As NGroup
            Dim batch As NBatchGroup = New NBatchGroup(m_DrawingView.Document)
            batch.Build(cupShape, handleShape, steamShape)
            batch.Group(Nothing, group)

            ' alter some properties of the group
            group.SelectionMode = ENGroupSelectionMode.GroupOnly
            group.SnapToShapes = False
            Return group
        End Function
        ''' <summary>
        ''' Creates a custom shape that is a replica of the Visio Trapedzoid shape. With NOV diagram you can replicate the smart behavior of any Visio smart shape.
        ''' </summary>
        ''' <returns></returns>
        Private Function CreateTrapedzoidShape() As NShape
            Dim shape As NShape = New NShape()
            shape.Init2DShape()

            ' add controls
            Dim control As NControl = New NControl()
            control.SetFx(NControl.XProperty, New NShapeWidthFactorFx(0.3))
            control.Y = 0.0R
            control.SetFx(NControl.XBehaviorProperty, String.Format("IF(X<Width/2,{0},{1})", ENCoordinateBehavior.OffsetFromMin, ENCoordinateBehavior.OffsetFromMax))
            control.YBehavior = ENCoordinateBehavior.Locked
            control.Tooltip = "Modify strip width"
            shape.Controls.Add(control)

            ' add a geometry
            Dim geometry1 = shape.Geometry

            If True Then
                Dim plotFigure = geometry1.MoveTo("MIN(Controls.0.X,Width-Controls.0.X)", 0.0R)
                geometry1.LineTo("Width-Geometry.0.X", 0.0R)
                geometry1.LineTo("Width", "Height")
                geometry1.LineTo(0.0R, "Height")
                geometry1.LineTo("Geometry.0.X", "Geometry.0.Y")
                plotFigure.CloseFigure = True
            End If

            ' add ports
            For i = 0 To 4 - 1
                Dim port As NPort = New NPort()
                shape.Ports.Add(port)

                Select Case i
                    Case 0 ' top
                        port.Relative = True
                        port.X = 0.5
                        port.Y = 0.0R
                        port.SetDirection(ENBoxDirection.Up)
                    Case 1 ' right
                        port.SetFx(NPort.XProperty, "(Geometry.1.X + Geometry.2.X) / 2")
                        port.SetFx(NPort.YProperty, New NShapeHeightFactorFx(0.5))
                        port.SetDirection(ENBoxDirection.Right)
                    Case 2 ' bottom
                        port.Relative = True
                        port.X = 0.5
                        port.Y = 1.0R
                        port.SetDirection(ENBoxDirection.Down)
                    Case 3 ' left
                        port.SetFx(NPort.XProperty, "(Geometry.0.X + Geometry.3.X) / 2")
                        port.SetFx(NPort.YProperty, New NShapeHeightFactorFx(0.5))
                        port.SetDirection(ENBoxDirection.Left)
                End Select
            Next

            Return shape
        End Function

#End Region

#Region "Event Handlers"

        Private Sub Interaction_GluingShapes(ByVal args As NGlueShapesEventArgs)
            ' safely get the ports collection
            Dim ports = CType(args.Shape2D.GetChild(NShape.PortsChild, False), NPortCollection)
            If ports Is Nothing AndAlso ports.Count = 0 Then Return

            ' get the anchor point in page coordinates
            Dim anchorInPage As NPoint = If(args.ConnectBegin, args.Shape1D.GetEndPointInPage(), args.Shape1D.GetBeginPointInPage())

            ' get the nearest port
            Dim neartestPort = ports(0)
            Dim neartestDistance As Double = NGeometry2D.PointsDistance(anchorInPage, neartestPort.GetLocationInPage())

            For i = 1 To ports.Count - 1
                Dim curPort = ports(i)
                Dim curDistance As Double = NGeometry2D.PointsDistance(anchorInPage, curPort.GetLocationInPage())

                If curDistance < neartestDistance Then
                    neartestDistance = curDistance
                    neartestPort = curPort
                End If
            Next

            ' connect begin or end 
            If args.ConnectBegin Then
                args.Shape1D.GlueBeginToPort(neartestPort)
            Else
                args.Shape1D.GlueEndToPort(neartestPort)
            End If

            ' cancel the event so that the diagram does not perform default connection
            args.Cancel = True
        End Sub

#End Region

#Region "Fields"

        Private m_DrawingView As NDrawingView

#End Region

#Region "Schema"

        ''' <summary>
        ''' Schema associated with NCustomShapesExample.
        ''' </summary>
        Public Shared ReadOnly NCustomShapesExampleSchema As NSchema

#End Region
    End Class
End Namespace

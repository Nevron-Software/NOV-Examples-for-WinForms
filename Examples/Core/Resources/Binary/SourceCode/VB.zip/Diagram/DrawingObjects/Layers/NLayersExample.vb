Imports Nevron.Nov.Diagram
Imports Nevron.Nov.Diagram.Shapes
Imports Nevron.Nov.Dom
Imports Nevron.Nov.Editors
Imports Nevron.Nov.Graphics
Imports Nevron.Nov.Layout
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.Diagram
    Public Class NLayersExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' Default constructor.
        ''' </summary>
        Public Sub New()
        End Sub

        ''' <summary>
        ''' Static constructor.
        ''' </summary>
        Shared Sub New()
            NLayersExampleSchema = NSchema.Create(GetType(NLayersExample), NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            ' create a library browser that displays all predefined shape factories
            Dim libraryBrowser As NLibraryBrowser = New NLibraryBrowser()
            libraryBrowser.LibraryViewType = ENLibraryViewType.Thumbnails

            'NLibrary library = new NBasicShapeFactory().CreateLibrary();
            'libraryBrowser.AddLibrarySection(library);

            ' create pan and zoom
            Dim m_PanAndZoom As NPanAndZoomView = New NPanAndZoomView()
            m_PanAndZoom.PreferredSize = New NSize(150, 150)

            ' create a drawing view
            m_DrawingView = New NDrawingView()
            m_DrawingView.HorizontalPlacement = ENHorizontalPlacement.Fit
            m_DrawingView.VerticalPlacement = ENVerticalPlacement.Fit

            ' bind components to drawing view
            libraryBrowser.DrawingView = m_DrawingView
            libraryBrowser.ResetLibraries()
            m_PanAndZoom.DrawingView = m_DrawingView

            ' create splitters
            Dim libraryPanSplitter As NSplitter = New NSplitter()
            libraryPanSplitter.Orientation = ENHVOrientation.Vertical
            libraryPanSplitter.SplitMode = ENSplitterSplitMode.OffsetFromFarSide
            libraryPanSplitter.Pane1.Content = libraryBrowser
            libraryPanSplitter.Pane2.Content = m_PanAndZoom

            Dim mainSplitter As NSplitter = New NSplitter()
            mainSplitter.Orientation = ENHVOrientation.Horizontal
            mainSplitter.SplitMode = ENSplitterSplitMode.OffsetFromNearSide
            mainSplitter.SplitOffset = 370
            mainSplitter.Pane1.Content = libraryPanSplitter
            mainSplitter.Pane2.Content = m_DrawingView

            ' Create the ribbon UI
            Dim builder As NDiagramRibbonBuilder = New NDiagramRibbonBuilder()

            m_DrawingView.Document.HistoryService.Pause()
            Try
                InitDiagram(m_DrawingView.Document)
            Finally
                m_DrawingView.Document.HistoryService.Resume()
            End Try

            Return builder.CreateUI(mainSplitter, m_DrawingView)
        End Function
        Protected Overrides Function CreateExampleControls() As NWidget
            Dim stackPanel As NStackPanel = New NStackPanel()

            Dim designer = NDesigner.GetDesigner(m_DrawingView.Content.Pages(0).Layers)
            Dim editor = designer.CreateInstanceEditor(m_DrawingView.Content.Pages(0).Layers)
            stackPanel.Add(editor)

            Return stackPanel
        End Function
        Protected Overrides Function GetExampleDescription() As String
            Return "<p>Demonstrates page layers.</p>"
        End Function

        Private Sub InitDiagram(ByVal drawingDocument As NDrawingDocument)
            Dim drawing = drawingDocument.Content

            ' hide the grid
            drawing.ScreenVisibility.ShowGrid = False

            ' create several layers
            Dim redLayer As NLayer = New NLayer()
            redLayer.Color = NColor.Red
            redLayer.Name = "Red"
            drawing.ActivePage.Layers.Add(redLayer)

            Dim greenLayer As NLayer = New NLayer()
            greenLayer.Color = NColor.Green
            greenLayer.Name = "Green"
            drawing.ActivePage.Layers.Add(greenLayer)

            Dim blueLayer As NLayer = New NLayer()
            blueLayer.Name = "Blue"
            blueLayer.Color = NColor.Blue
            drawing.ActivePage.Layers.Add(blueLayer)

            ' create several shapes, each assigned to different layer(s)
            Dim shapeFactory As NBasicShapeFactory = New NBasicShapeFactory()

            Dim redShape = shapeFactory.CreateShape(ENBasicShape.Rectangle)
            redShape.Text = "Red"
            redShape.Geometry.Fill = New NColorFill(NColor.Red)
            redShape.SetBounds(10, 10, 100, 100)
            redShape.AssignToLayers(redLayer)
            drawing.ActivePage.Items.Add(redShape)

            Dim greenShape = shapeFactory.CreateShape(ENBasicShape.Rectangle)
            greenShape.Text = "Green"
            greenShape.Geometry.Fill = New NColorFill(NColor.Green)
            greenShape.SetBounds(120, 10, 100, 100)
            greenShape.AssignToLayers(greenLayer)
            drawing.ActivePage.Items.Add(greenShape)

            Dim blueShape = shapeFactory.CreateShape(ENBasicShape.Rectangle)
            blueShape.Text = "Blue"
            blueShape.Geometry.Fill = New NColorFill(NColor.Blue)
            blueShape.SetBounds(230, 10, 100, 100)
            blueShape.AssignToLayers(blueLayer)
            drawing.ActivePage.Items.Add(blueShape)

            Dim grayShape = shapeFactory.CreateShape(ENBasicShape.Rectangle)
            grayShape.Text = "Red, Green and Blue"
            grayShape.Geometry.Fill = New NColorFill(NColor.Gray)
            grayShape.SetBounds(10, 120, 320, 100)
            grayShape.AssignToLayers(redLayer, greenLayer, blueLayer)
            drawing.ActivePage.Items.Add(grayShape)
        End Sub

#End Region


#Region "Fields"

        Private m_DrawingView As NDrawingView

#End Region

#Region "Schema"

        ''' <summary>
        ''' Schema associated with NLayersExample.
        ''' </summary>
        Public Shared ReadOnly NLayersExampleSchema As NSchema

#End Region
    End Class
End Namespace

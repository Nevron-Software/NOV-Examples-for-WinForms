Imports Nevron.Nov.Diagram
Imports Nevron.Nov.Dom
Imports Nevron.Nov.Graphics
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.Diagram
    Public Class NInputAndOutputPortsExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' Default constructor.
        ''' </summary>
        Public Sub New()
        End Sub

        ''' <summary>
        ''' Static constructor.
        ''' </summary>
        Shared Sub New()
            NInputAndOutputPortsExampleSchema = NSchema.Create(GetType(NInputAndOutputPortsExample), NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            ' Create a simple drawing
            Dim drawingViewWithRibbon As NDrawingViewWithRibbon = New NDrawingViewWithRibbon()
            m_DrawingView = drawingViewWithRibbon.View

            m_DrawingView.Document.HistoryService.Pause()
            Try
                InitDiagram(m_DrawingView.Document)
            Finally
                m_DrawingView.Document.HistoryService.Resume()
            End Try

            Return drawingViewWithRibbon
        End Function
        Protected Overrides Function CreateExampleControls() As NWidget
            Return Nothing
        End Function
        Protected Overrides Function GetExampleDescription() As String
            Return "
<p>
    Demonstrates the behavior of input and output ports. Try to connect the AND shape ports with lines.
</p>
<p> 
    In NOV Diagram each port FlowMode can be set to Input, Output or InputAndOutput (the default). 
</p>
<p>
    <b>Input</b> ports can accept connections with End points of 1D shapes and output ports of 2D shapes.
    Input ports are painted in green color.
</p>
<p>
    <b>Output</b> ports can accept connections with Begin points of 1D shapes and input ports of 2D shapes.
    Output ports are painted in red color.
</p>
<p>
    <b>InputAndOutput</b> ports behave as both input and output ports (the default).
    InputAndOutput ports are painted in blue color.
</p>
" End Function

        Private Sub InitDiagram(ByVal drawingDocument As NDrawingDocument)
            Dim drawing = drawingDocument.Content
            Dim activePage = drawing.ActivePage

            ' hide the grid
            drawing.ScreenVisibility.ShowGrid = False

            ' create a AND shape
            Dim andShape As NShape = CreateAndShape()
            andShape.SetBounds(300, 100, 150, 100)
            activePage.Items.Add(andShape)
        End Sub

#End Region

#Region "Implementation "

        Private Function CreateAndShape() As NShape
            Dim shape As NShape = New NShape()
            shape.Init2DShape()

            Dim normalSize As NSize = New NSize(1, 1)
            Dim path As NGraphicsPath = New NGraphicsPath()

            ' create input lines
            Dim x1 As Double = 0
            Dim y1 = normalSize.Height / 3
            path.StartFigure(x1, y1)
            path.LineTo(normalSize.Width / 4, y1)

            Dim y2 = normalSize.Height * 2 / 3
            Dim x2 As Double = 0
            path.StartFigure(x2, y2)
            path.LineTo(normalSize.Width / 4, y2)

            ' create body
            path.StartFigure(normalSize.Width / 4, 0)
            path.LineTo(normalSize.Width / 4, 1)
            Dim ellipseCenter As NPoint = New NPoint(normalSize.Width / 4, 0.5)
            path.AddEllipseSegment(NRectangle.FromCenterAndSize(ellipseCenter, normalSize.Width, normalSize.Height), NMath.PIHalf, -NMath.PI)
            path.CloseFigure()

            ' create output
            Dim y3 = normalSize.Height / 2
            Dim x3 = normalSize.Width
            path.StartFigure(normalSize.Width * 3 / 4, y3)
            path.LineTo(x3, y3)

            shape.Geometry.AddRelative(New NDrawPath(New NRectangle(0, 0, 1, 1), path))

            ' create ports
            Dim input1 As NPort = New NPort()
            input1.X = x1
            input1.Y = y1
            input1.Relative = True
            input1.SetDirection(ENBoxDirection.Left)
            input1.FlowMode = ENPortFlowMode.Input
            shape.Ports.Add(input1)

            Dim input2 As NPort = New NPort()
            input2.X = x2
            input2.Y = y2
            input2.Relative = True
            input2.SetDirection(ENBoxDirection.Left)
            input2.FlowMode = ENPortFlowMode.Input
            shape.Ports.Add(input2)

            Dim output1 As NPort = New NPort()
            output1.X = x3
            output1.Y = y3
            output1.Relative = True
            output1.SetDirection(ENBoxDirection.Right)
            output1.FlowMode = ENPortFlowMode.Output
            shape.Ports.Add(output1)

            ' by default this shape does not accept shape-to-shape connections
            shape.DefaultShapeGlue = ENDefaultShapeGlue.None

            ' set text
            shape.Text = "AND"

            Return shape

        End Function

#End Region

#Region "Fields"

        Private m_DrawingView As NDrawingView

#End Region

#Region "Schema"

        ''' <summary>
        ''' Schema associated with NInputAndOutputPortsExample.
        ''' </summary>
        Public Shared ReadOnly NInputAndOutputPortsExampleSchema As NSchema

#End Region
    End Class
End Namespace

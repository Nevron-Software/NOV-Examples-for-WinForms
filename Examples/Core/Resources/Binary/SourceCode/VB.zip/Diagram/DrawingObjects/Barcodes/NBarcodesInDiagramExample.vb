Imports Nevron.Nov.Barcode
Imports Nevron.Nov.Diagram
Imports Nevron.Nov.Dom
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.Diagram
    Public Class NBarcodesInDiagramExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' Default constructor.
        ''' </summary>
        Public Sub New()
        End Sub

        ''' <summary>
        ''' Static constructor.
        ''' </summary>
        Shared Sub New()
            NBarcodesInDiagramExampleSchema = NSchema.Create(GetType(NBarcodesInDiagramExample), NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            ' Create a simple drawing
            Dim drawingViewWithRibbon As NDrawingViewWithRibbon = New NDrawingViewWithRibbon()
            m_DrawingView = drawingViewWithRibbon.View

            m_DrawingView.Document.HistoryService.Pause()
            Try
                InitDiagram(m_DrawingView.Document)
            Finally
                m_DrawingView.Document.HistoryService.Resume()
            End Try

            Return drawingViewWithRibbon
        End Function
        Protected Overrides Function CreateExampleControls() As NWidget
            Return Nothing
        End Function
        Protected Overrides Function GetExampleDescription() As String
            Return "<p>Demonstrates how to create and host barcodes in diagram shapes.</p>"
        End Function

        Private Sub InitDiagram(ByVal drawingDocument As NDrawingDocument)
            Dim activePage = drawingDocument.Content.ActivePage

            ' Create a barcode widget
            Dim barcode As NMatrixBarcode = New NMatrixBarcode(ENMatrixBarcodeSymbology.QrCode, "https://www.nevron.com")

            ' Create a shape and place the barcode widget in it
            Dim shape As NShape = New NShape()
            shape.SetBounds(100, 100, 100, 100)
            shape.Widget = barcode
            activePage.Items.Add(shape)
        End Sub

#End Region

#Region "Fields"

        Private m_DrawingView As NDrawingView

#End Region

#Region "Schema"

        ''' <summary>
        ''' Schema associated with NBarcodesInDiagramExample.
        ''' </summary>
        Public Shared ReadOnly NBarcodesInDiagramExampleSchema As NSchema

#End Region
    End Class
End Namespace

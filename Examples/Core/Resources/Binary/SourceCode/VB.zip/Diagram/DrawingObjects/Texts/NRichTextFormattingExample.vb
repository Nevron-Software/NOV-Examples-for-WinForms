Imports Nevron.Nov.Diagram
Imports Nevron.Nov.Diagram.Shapes
Imports Nevron.Nov.Dom
Imports Nevron.Nov.Graphics
Imports Nevron.Nov.Text
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.Diagram
    Public Class NRichTextFormattingExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' Default constructor.
        ''' </summary>
        Public Sub New()
        End Sub

        ''' <summary>
        ''' Static constructor.
        ''' </summary>
        Shared Sub New()
            NRichTextFormattingExampleSchema = NSchema.Create(GetType(NRichTextFormattingExample), NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            ' Create a simple drawing
            Dim drawingViewWithRibbon As NDrawingViewWithRibbon = New NDrawingViewWithRibbon()
            m_DrawingView = drawingViewWithRibbon.View

            m_DrawingView.Document.HistoryService.Pause()
            Try
                InitDiagram(m_DrawingView.Document)
            Finally
                m_DrawingView.Document.HistoryService.Resume()
            End Try

            Return drawingViewWithRibbon
        End Function
        Protected Overrides Function CreateExampleControls() As NWidget
            Return Nothing
        End Function
        Protected Overrides Function GetExampleDescription() As String
            Return "<p>Demonstrates how to apply rich text formatting to texts.</p>"
        End Function

        Private Sub InitDiagram(ByVal drawingDocument As NDrawingDocument)
            Dim drawing = drawingDocument.Content

            ' hide the grid
            drawing.ScreenVisibility.ShowGrid = False

            Dim basicShapes As NBasicShapeFactory = New NBasicShapeFactory()

            Dim shape1 = basicShapes.CreateShape(ENBasicShape.Rectangle)
            shape1.SetBounds(10, 10, 381, 600)

            Dim textBlock1 As NTextBlock = New NTextBlock()
            shape1.TextBlock = textBlock1
            textBlock1.Content.Blocks.Clear()
            AddFormattedTextToContent(textBlock1.Content)
            drawing.ActivePage.Items.Add(shape1)

            Dim shape2 = basicShapes.CreateShape(ENBasicShape.Rectangle)
            shape2.SetBounds(401, 10, 381, 600)
            Dim textBlock2 As NTextBlock = New NTextBlock()
            shape2.TextBlock = textBlock2
            textBlock2.Content.Blocks.Clear()
            AddFormattedTextWithImagesToContent(textBlock2.Content)
            drawing.ActivePage.Items.Add(shape2)
        End Sub

#End Region

#Region "Implementation "

        ''' <summary>
        ''' Adds rich formatted text to the specified text block content
        ''' </summary>
        ''' <paramname="content"></param>
        Private Sub AddFormattedTextToContent(ByVal content As NTextBlockContent)
            If True Then
                ' font style control
                Dim paragraph As NParagraph = New NParagraph()

                Dim textInline1 As NTextInline = New NTextInline("This paragraph contains text inlines with altered ")
                paragraph.Inlines.Add(textInline1)

                Dim textInline2 As NTextInline = New NTextInline("Font Name, ")
                textInline2.FontName = "Tahoma"
                paragraph.Inlines.Add(textInline2)

                Dim textInline3 As NTextInline = New NTextInline("Font Size, ")
                textInline3.FontSize = 14
                paragraph.Inlines.Add(textInline3)

                Dim textInline4 As NTextInline = New NTextInline("Font Style (Bold), ")
                textInline4.FontStyle = textInline4.FontStyle Or ENFontStyle.Bold
                paragraph.Inlines.Add(textInline4)

                Dim textInline5 As NTextInline = New NTextInline("Font Style (Italic), ")
                textInline5.FontStyle = textInline5.FontStyle Or ENFontStyle.Italic
                paragraph.Inlines.Add(textInline5)

                Dim textInline6 As NTextInline = New NTextInline("Font Style (Underline), ")
                textInline6.FontStyle = textInline6.FontStyle Or ENFontStyle.Underline
                paragraph.Inlines.Add(textInline6)

                Dim textInline7 As NTextInline = New NTextInline("Font Style (StrikeTrough) ")
                textInline7.FontStyle = textInline7.FontStyle Or ENFontStyle.Strikethrough
                paragraph.Inlines.Add(textInline7)

                Dim textInline8 As NTextInline = New NTextInline(", and Font Style All.")
                textInline8.FontStyle = ENFontStyle.Bold Or ENFontStyle.Italic Or ENFontStyle.Underline Or ENFontStyle.Strikethrough
                paragraph.Inlines.Add(textInline8)

                content.Blocks.Add(paragraph)
            End If

            If True Then
                ' appearance control
                Dim paragraph As NParagraph = New NParagraph()

                Dim textInline1 As NTextInline = New NTextInline("Each text inline element can contain text with different fill and background. ")
                paragraph.Inlines.Add(textInline1)

                Dim textInline2 As NTextInline = New NTextInline("Fill (Red), Background Fill Inherit. ")
                textInline2.Fill = New NColorFill(ENNamedColor.Red)
                paragraph.Inlines.Add(textInline2)

                Dim textInline3 As NTextInline = New NTextInline("Fill inherit, Background Fill (Green).")
                textInline3.BackgroundFill = New NColorFill(ENNamedColor.Green)
                paragraph.Inlines.Add(textInline3)

                content.Blocks.Add(paragraph)
            End If

            If True Then
                ' line breaks
                ' appearance control
                Dim paragraph As NParagraph = New NParagraph()

                Dim textInline1 As NTextInline = New NTextInline("Line breaks allow you to break...")
                paragraph.Inlines.Add(textInline1)

                Dim lineBreak As NLineBreakInline = New NLineBreakInline()
                paragraph.Inlines.Add(lineBreak)

                Dim textInline2 As NTextInline = New NTextInline("the current line in the paragraph.")
                paragraph.Inlines.Add(textInline2)

                content.Blocks.Add(paragraph)
            End If

            If True Then
                ' tabs
                Dim paragraph As NParagraph = New NParagraph()

                Dim tabInline As NTabInline = New NTabInline()
                paragraph.Inlines.Add(tabInline)

                Dim textInline1 As NTextInline = New NTextInline("(Tabs) are not supported by HTML, however, they are essential when importing text documents.")
                paragraph.Inlines.Add(textInline1)

                content.Blocks.Add(paragraph)
            End If
        End Sub
        ''' <summary>
        ''' Adds formatted text with image elements to the specified text block content
        ''' </summary>
        ''' <paramname="content"></param>
        Private Sub AddFormattedTextWithImagesToContent(ByVal content As NTextBlockContent)
            ' adding a raster image with automatic size
            If True Then
                Dim paragraph As NParagraph = New NParagraph()

                paragraph.Inlines.Add(New NTextInline("Raster image in its original size (125x100):"))
                paragraph.Inlines.Add(New NLineBreakInline())

                Dim imageInline As NImageInline = New NImageInline()
                imageInline.Image = NResources.Image_Artistic_FishBowl_jpg
                paragraph.Inlines.Add(imageInline)

                content.Blocks.Add(paragraph)
            End If


            ' adding a raster image with specified preferred width and height
            If True Then
                Dim paragraph As NParagraph = New NParagraph()

                paragraph.Inlines.Add(New NTextInline("Raster image with preferred width and height (80x60):"))
                paragraph.Inlines.Add(New NLineBreakInline())

                Dim imageInline As NImageInline = New NImageInline()

                imageInline.Image = NResources.Image_Artistic_FishBowl_jpg
                imageInline.PreferredWidth = New NMultiLength(ENMultiLengthUnit.Dip, 80)
                imageInline.PreferredHeight = New NMultiLength(ENMultiLengthUnit.Dip, 60)

                paragraph.Inlines.Add(imageInline)

                content.Blocks.Add(paragraph)
            End If

            ' adding a metafile image with preferred width and height
            If True Then
                Dim paragraph As NParagraph = New NParagraph()

                paragraph.Inlines.Add(New NTextInline("Metafile image with preferred width and height (125x100):"))
                paragraph.Inlines.Add(New NLineBreakInline())

                Dim imageInline As NImageInline = New NImageInline()
                imageInline.Image = NResources.Image_FishBowl_wmf
                imageInline.PreferredWidth = New NMultiLength(ENMultiLengthUnit.Dip, 125)
                imageInline.PreferredHeight = New NMultiLength(ENMultiLengthUnit.Dip, 100)

                paragraph.Inlines.Add(imageInline)

                content.Blocks.Add(paragraph)
            End If


            ' adding a metafile image with preferred width and height
            If True Then
                Dim paragraph As NParagraph = New NParagraph()

                paragraph.Inlines.Add(New NTextInline("Metafile image with preferred width and height (80x60):"))
                paragraph.Inlines.Add(New NLineBreakInline())

                Dim imageInline As NImageInline = New NImageInline()
                imageInline.Image = NResources.Image_FishBowl_wmf
                imageInline.PreferredWidth = New NMultiLength(ENMultiLengthUnit.Dip, 80)
                imageInline.PreferredHeight = New NMultiLength(ENMultiLengthUnit.Dip, 60)

                paragraph.Inlines.Add(imageInline)

                content.Blocks.Add(paragraph)
            End If
        End Sub

#End Region

#Region "Fields"

        Private m_DrawingView As NDrawingView

#End Region

#Region "Schema"

        ''' <summary>
        ''' Schema associated with NRichTextFormattingExample.
        ''' </summary>
        Public Shared ReadOnly NRichTextFormattingExampleSchema As NSchema

#End Region
    End Class
End Namespace

Imports Nevron.Nov.DataStructures
Imports Nevron.Nov.Diagram
Imports Nevron.Nov.Diagram.Shapes
Imports Nevron.Nov.Dom
Imports Nevron.Nov.Graphics
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.Diagram
    Public Class NWidgetHostingExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' Default constructor.
        ''' </summary>
        Public Sub New()
        End Sub

        ''' <summary>
        ''' Static constructor.
        ''' </summary>
        Shared Sub New()
            NWidgetHostingExampleSchema = NSchema.Create(GetType(NWidgetHostingExample), NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            ' Create a simple drawing
            Dim drawingViewWithRibbon As NDrawingViewWithRibbon = New NDrawingViewWithRibbon()
            m_DrawingView = drawingViewWithRibbon.View
            m_DrawingView.Document.HistoryService.Pause()

            Try
                InitDiagram(m_DrawingView.Document)
            Finally
                m_DrawingView.Document.HistoryService.Resume()
            End Try

            Return drawingViewWithRibbon
        End Function

        Protected Overrides Function CreateExampleControls() As NWidget
            Return Nothing
        End Function

        Protected Overrides Function GetExampleDescription() As String
            Return "
<p>
    This example demonstrates the ability to embed any NOV UI Widget in shapes. This allows the creation of interactive
    diagrams that are incredibly rich on interaction features.
</p>
"
        End Function

        Private Sub InitDiagram(ByVal drawingDocument As NDrawingDocument)
            ' create the books list
            CreateBooksList()

            ' create the shopping cart
            m_ShoppingCart = New NShoppingCart()
            Dim drawing = drawingDocument.Content
            Dim activePage = drawing.ActivePage

            ' hide the grid
            drawing.ScreenVisibility.ShowGrid = False

            ' create a shape which hosts a widget
            CreateBookStore(activePage)
        End Sub

#End Region

#Region "Implementation"

        ''' <summary>
        ''' Creates the list of books through which the user can browse
        ''' </summary>
        Private Sub CreateBooksList()
            m_Books = New NList(Of NBook)()
            m_Books.Add(New NBook("The Name Of The Wind", "Patrick Rothfuss", "This is the riveting first-person narrative of Kvothe, a young man who grows to be one of the most notorious magicians his world has ever seen. From his childhood in a troupe of traveling players, to years spent as a near-feral orphan in a crime-riddled city, to his daringly brazen yet successful bid to enter a legendary school of magic, The Name of the Wind is a masterpiece that transports readers into the body and mind of a wizard.", NResources.Image_Books_NameOfTheWind_jpg, 12.90))
            m_Books.Add(New NBook("Lord of Ohe Rings", "J.R.R. Tolkien", "In ancient times the Rings of Power were crafted by the Elven-smiths, and Sauron, the Dark Lord, forged the One Ring, filling it with his own power so that he could rule all others. But the One Ring was taken from him, and though he sought it throughout Middle-earth, it remained lost to him. After many ages it fell by chance into the hands of the hobbit Bilbo Baggins.", NResources.Image_Books_LordOfTheRings_jpg, 13.99))
            m_Books.Add(New NBook("A Game Of Thrones", "George R.R. Martin", "Long ago, in a time forgotten, a preternatural event threw the seasons out of balance. In a land where summers can last decades and winters a lifetime, trouble is brewing. The cold is returning, and in the frozen wastes to the north of Winterfell, sinister and supernatural forces are massing beyond the kingdom’s protective Wall. At the center of the conflict lie the Starks of Winterfell, a family as harsh and unyielding as the land they were born to.", NResources.Image_Books_AGameOfThrones_jpg, 12.79))
            m_Books.Add(New NBook("The Way Of Kings", "Brandon Sanderson", "Roshar is a world of stone and storms. Uncanny tempests of incredible power sweep across the rocky terrain so frequently that they have shaped ecology and civilization alike. Animals hide in shells, trees pull in branches, and grass retracts into the soilless ground. Cities are built only where the topography offers shelter.", NResources.Image_Books_TheWayOfKings_jpg, 7.38))
            m_Books.Add(New NBook("Mistborn", "Brandon Sanderson", "For a thousand years the ash fell and no flowers bloomed. For a thousand years the Skaa slaved in misery and lived in fear. For a thousand years the Lord Ruler, the 'Sliver of Infinity' reigned with absolute power and ultimate terror, divinely invincible. Then, when hope was so long lost that not even its memory remained, a terribly scarred, heart-broken half-Skaa rediscovered it in the depths of the Lord Ruler’s most hellish prison. Kelsier 'snapped' and found in himself the powers of a Mistborn. A brilliant thief and natural leader, he turned his talents to the ultimate caper, with the Lord Ruler himself as the mark. ", NResources.Image_Books_Mistborn_jpg, 6.38))
        End Sub
        ''' <summary>
        ''' Gets the min Width and Height of all book images
        ''' </summary>
        ''' <returns></returns>
        Private Function GetMinBookImageSize() As NSize
            Dim size As NSize = New NSize(Double.MaxValue, Double.MaxValue)

            For i = 0 To m_Books.Count - 1
                Dim book = m_Books(i)

                If book.Image.Width < size.Width Then
                    size.Width = book.Image.Width
                End If

                If book.Image.Height < size.Height Then
                    size.Height = book.Image.Height
                End If
            Next

            Return size
        End Function
        ''' <summary>
        ''' Creates the book store interface
        ''' </summary>
        ''' <paramname="activePage"></param>
        Private Sub CreateBookStore(ByVal activePage As NPage)
            Const x1 As Double = 50
            Const x2 = x1 + 200
            Const x3 = x2 + 50
            Const x4 = x3 + 400
            Const y1 As Double = 50
            Const y2 = y1 + 50
            Const y3 = y2 + 50
            Const y4 = y3 + 20
            Const y5 = y4 + 200
            Const y6 = y5 + 20
            Const y7 = y6 + 50

            ' prev button
            Dim prevButtonShape = CreateButtonShape("Show Prev Book")
            SetLeftTop(prevButtonShape, New NPoint(x1, y1))
            AddHandler CType(prevButtonShape.Widget, NButton).Click, Sub(ByVal args) LoadBook(m_nSelectedBook - 1)
            activePage.Items.Add(prevButtonShape)

            ' next button
            Dim nextButtonShape = CreateButtonShape("Show Next Book")
            SetRightTop(nextButtonShape, New NPoint(x2, y1))
            AddHandler CType(nextButtonShape.Widget, NButton).Click, Sub(ByVal args) LoadBook(m_nSelectedBook + 1)
            activePage.Items.Add(nextButtonShape)

            ' add to cart
            Dim addToCartButton = CreateButtonShape("Add to Cart")
            SetRightTop(addToCartButton, New NPoint(x2, y6))
            AddHandler CType(addToCartButton.Widget, NButton).Click, Sub(ByVal args) m_ShoppingCart.AddItem(m_Books(m_nSelectedBook), Me)
            activePage.Items.Add(addToCartButton)

            ' create selected book shapes
            Dim basicShapes As NBasicShapeFactory = New NBasicShapeFactory()

            ' selected image
            m_SelectedBookImage = basicShapes.CreateShape(ENBasicShape.Rectangle)
            SetLeftTop(m_SelectedBookImage, New NPoint(x1, y2))
            Dim minBookSize As NSize = GetMinBookImageSize()
            m_SelectedBookImage.Width = x2 - x1
            m_SelectedBookImage.Height = y5 - y2
            activePage.Items.Add(m_SelectedBookImage)

            ' selected title
            m_SelectedBookTitle = basicShapes.CreateShape(ENBasicShape.Text)
            m_SelectedBookTitle.TextBlock.InitXForm(ENTextBlockXForm.ShapeBox)
            m_SelectedBookTitle.TextBlock.FontSize = 25
            m_SelectedBookTitle.TextBlock.Fill = New NColorFill(NColor.DarkBlue)
            SetLeftTop(m_SelectedBookTitle, New NPoint(x3, y2))
            m_SelectedBookTitle.Width = x4 - x3
            m_SelectedBookTitle.Height = y3 - y2
            activePage.Items.Add(m_SelectedBookTitle)

            ' selected description
            m_SelectedBookDescription = basicShapes.CreateShape(ENBasicShape.Text)
            m_SelectedBookDescription.TextBlock.InitXForm(ENTextBlockXForm.ShapeBox)
            SetLeftTop(m_SelectedBookDescription, New NPoint(x3, y4))
            m_SelectedBookDescription.Width = x4 - x3
            m_SelectedBookDescription.Height = y5 - y4
            activePage.Items.Add(m_SelectedBookDescription)

            ' load the first book
            LoadBook(0)

            ' create the shape that hosts the shopping cart widget
            Dim shoppingCartShape As NShape = New NShape()
            shoppingCartShape.Init2DShape()
            m_ShoppingCartWidget = New NContentHolder()
            m_ShoppingCartWidget.Content = m_ShoppingCart.CreateWidget(Me)
            shoppingCartShape.Widget = m_ShoppingCartWidget
            SetLeftTop(shoppingCartShape, New NPoint(x1, y7))
            BindSizeToDesiredSize(shoppingCartShape)
            activePage.Items.Add(shoppingCartShape)
        End Sub
        ''' <summary>
        ''' Loads a book with the specified index
        ''' </summary>
        ''' <paramname="index"></param>
        Private Sub LoadBook(ByVal index As Integer)
            m_nSelectedBook = NMath.Clamp(0, m_Books.Count - 1, index)
            Dim book = m_Books(m_nSelectedBook)
            m_SelectedBookImage.Geometry.Fill = New NImageFill(CType(book.Image.DeepClone(), NImage))
            m_SelectedBookTitle.Text = book.Name
            m_SelectedBookDescription.Text = book.Description
        End Sub
        ''' <summary>
        ''' Creates a shape
        ''' </summary>
        ''' <paramname="text"></param>
        ''' <returns></returns>
        Private Function CreateButtonShape(ByVal text As String) As NShape
            Dim buttonShape As NShape = New NShape()
            buttonShape.Init2DShape()

            ' make a button and place it in the shape
            Dim button As NButton = New NButton(text)
            buttonShape.Widget = button

            ' bind size to button desired size 
            BindSizeToDesiredSize(buttonShape)
            Return buttonShape
        End Function
        ''' <summary>
        ''' Sets the left top corner of a shape
        ''' </summary>
        ''' <paramname="shape"></param>
        ''' <paramname="location"></param>
        Private Sub SetLeftTop(ByVal shape As NShape, ByVal location As NPoint)
            ' align local pin to left/top corner so pin point can change the location 
            shape.LocPinX = 0
            shape.LocPinY = 0
            shape.LocPinRelative = True

            ' set the pin point
            shape.SetPinPoint(location)
        End Sub
        ''' <summary>
        ''' Sets the right top corner of a shape
        ''' </summary>
        ''' <paramname="shape"></param>
        ''' <paramname="location"></param>
        Private Sub SetRightTop(ByVal shape As NShape, ByVal location As NPoint)
            ' align local pin to left/top corner so pin point can change the location 
            shape.LocPinX = 1
            shape.LocPinY = 0
            shape.LocPinRelative = True

            ' set the pin point
            shape.SetPinPoint(location)
        End Sub
        ''' <summary>
        ''' Binds the size of the shape to the embedded widget desired size
        ''' </summary>
        ''' <paramname="shape"></param>
        Private Sub BindSizeToDesiredSize(ByVal shape As NShape)
            Dim widget = shape.Widget

            ' bind shape width to button desired width
            Dim bx As NBindingFx = New NBindingFx(widget, NBoxElement.DesiredWidthProperty)
            bx.Guard = True
            shape.SetFx(NShape.WidthProperty, bx)

            ' bind shape height to button desired height
            Dim by As NBindingFx = New NBindingFx(widget, NBoxElement.DesiredHeightProperty)
            by.Guard = True
            shape.SetFx(NShape.HeightProperty, by)
            shape.AllowResizeX = False
            shape.AllowRotate = False
            shape.AllowResizeY = False
        End Sub

#End Region

#Region "Fields"

        Private m_DrawingView As NDrawingView
        Private m_nSelectedBook As Integer = 0
        Private m_SelectedBookImage As NShape
        Private m_SelectedBookTitle As NShape
        Private m_SelectedBookDescription As NShape
        Private m_Books As NList(Of NBook)
        Private m_ShoppingCart As NShoppingCart
        Private m_ShoppingCartWidget As NContentHolder

#End Region

#Region "Schema"

        ''' <summary>
        ''' Schema associated with NWidgetHostingExample.
        ''' </summary>
        Public Shared ReadOnly NWidgetHostingExampleSchema As NSchema

#End Region

#Region "Nested Types"

        Friend Class NBook
            Implements INDeeplyCloneable
#Region "Constructors"

            ''' <summary>
            ''' Initializer contructor
            ''' </summary>
            ''' <paramname="name"></param>
            ''' <paramname="author"></param>
            ''' <paramname="description"></param>
            ''' <paramname="image"></param>
            ''' <paramname="price"></param>
            Public Sub New(ByVal name As String, ByVal author As String, ByVal description As String, ByVal image As NImage, ByVal price As Double)
                Me.Name = name
                Me.Author = author
                Me.Description = description
                Me.Image = image
                Me.Price = price
            End Sub
            ''' <summary>
            ''' Copy constructor
            ''' </summary>
            ''' <paramname="bookInfo"></param>
            Public Sub New(ByVal bookInfo As NBook)
                Name = bookInfo.Name
                Author = bookInfo.Author
                Description = bookInfo.Description
                Image = CType(bookInfo.Image.DeepClone(), NImage)
                Price = bookInfo.Price
            End Sub

#End Region

#Region "Fields"

            Public ReadOnly Name As String
            Public ReadOnly Author As String
            Public ReadOnly Description As String
            Public ReadOnly Image As NImage
            Public ReadOnly Price As Double

#End Region

#Region "INDeeplyCloneable"

            Public Function DeepClone() As Object Implements INDeeplyCloneable.DeepClone
                Return New NBook(Me)
            End Function

#End Region
        End Class

        Friend Class NShoppingCartItem
            Public Sub New()
            End Sub

            Public Name As String
            Public Quantity As Integer
            Public Price As Double

            Public Function GetTotal() As Double
                Return Quantity * Price
            End Function
        End Class

        Friend Class NShoppingCart
            Private Items As NList(Of NShoppingCartItem) = New NList(Of NShoppingCartItem)()

            ''' <summary>
            ''' Adds a book to the shopping cart.
            ''' </summary>
            ''' <paramname="book"></param>
            ''' <paramname="example"></param>
            Public Sub AddItem(ByVal book As NBook, ByVal example As NWidgetHostingExample)
                ' try find an item with the same name. if such exists -> incerase quantity and rebuild shopping cart widget
                For i = 0 To Items.Count - 1

                    If Equals(Items(i).Name, book.Name) Then
                        Items(i).Quantity += 1
                        example.m_ShoppingCartWidget.Content = CreateWidget(example)
                        Return
                    End If
                Next

                ' add new item and rebuild shopping cart widget
                Dim item As NShoppingCartItem = New NShoppingCartItem()
                item.Name = book.Name
                item.Price = book.Price
                item.Quantity = 1
                Items.Add(item)
                example.m_ShoppingCartWidget.Content = CreateWidget(example)
            End Sub

            Public Sub DeleteItem(ByVal item As NShoppingCartItem, ByVal example As NWidgetHostingExample)
                ' remove the item and rebuild the shopping cart
                Items.Remove(item)
                example.m_ShoppingCartWidget.Content = CreateWidget(example)
            End Sub

            ''' <summary>
            ''' Gets the grand total of items
            ''' </summary>
            ''' <returns></returns>
            Public Function GetGrandTotal() As Double
                Dim grandTotal As Double = 0

                For i = 0 To Items.Count - 1
                    grandTotal += Items(i).GetTotal()
                Next

                Return grandTotal
            End Function

            ''' <summary>
            ''' Creates the widget that represents the current state of the shopping cart.
            ''' </summary>
            ''' <paramname="example"></param>
            ''' <returns></returns>
            Public Function CreateWidget(ByVal example As NWidgetHostingExample) As NWidget
                If Items.Count = 0 Then
                    Return New NLabel("The Shopping Cart is Empty")
                End If

                Const spacing As Double = 10

                ' create the grand total label
                Dim grandTotalLabel As NLabel = New NLabel(GetGrandTotal().ToString("0.00"))

                ' items table
                Dim tableFlowPanel As NTableFlowPanel = New NTableFlowPanel()
                tableFlowPanel.HorizontalSpacing = spacing
                tableFlowPanel.VerticalSpacing = spacing
                tableFlowPanel.MaxOrdinal = 5

                ' add headers
                tableFlowPanel.Add(New NLabel("Name"))
                tableFlowPanel.Add(New NLabel("Quantity"))
                tableFlowPanel.Add(New NLabel("Price"))
                tableFlowPanel.Add(New NLabel("Total"))
                tableFlowPanel.Add(New NLabel())

                For i = 0 To Items.Count - 1
                    Dim item = Items(i)

                    ' name
                    Dim nameLabel As NLabel = New NLabel(item.Name)
                    Dim priceLabel As NLabel = New NLabel(item.Price.ToString("0.00"))
                    Dim totalLabel As NLabel = New NLabel(item.GetTotal().ToString("0.00"))

                    ' quantity
                    Dim quantityNud As NNumericUpDown = New NNumericUpDown()
                    quantityNud.Value = item.Quantity
                    quantityNud.DecimalPlaces = 0
                    quantityNud.Minimum = 0
                    AddHandler quantityNud.ValueChanged, Sub(ByVal args)
                                                             item.Quantity = CInt(CType(args.TargetNode, NNumericUpDown).Value)
                                                             totalLabel.Text = item.GetTotal().ToString("0.00")
                                                             grandTotalLabel.Text = GetGrandTotal().ToString("0.00")
                                                         End Sub

                    Dim deleteButton As NButton = New NButton("Delete")
                    AddHandler deleteButton.Click, Sub(ByVal args) DeleteItem(item, example)
                    tableFlowPanel.Add(nameLabel)
                    tableFlowPanel.Add(quantityNud)
                    tableFlowPanel.Add(priceLabel)
                    tableFlowPanel.Add(totalLabel)
                    tableFlowPanel.Add(deleteButton)
                Next

                ' add grand total
                tableFlowPanel.Add(New NLabel("Grand Total"))
                tableFlowPanel.Add(New NLabel())
                tableFlowPanel.Add(New NLabel())
                tableFlowPanel.Add(grandTotalLabel)
                tableFlowPanel.Add(New NLabel())
                Return tableFlowPanel
            End Function
        End Class

#End Region
    End Class
End Namespace

Imports Nevron.Nov.Diagram
Imports Nevron.Nov.Diagram.Layout
Imports Nevron.Nov.Diagram.Shapes
Imports Nevron.Nov.Dom
Imports Nevron.Nov.Graphics
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.Diagram
    Public Class NLayoutGroupExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' Default constructor.
        ''' </summary>
        Public Sub New()
        End Sub

        ''' <summary>
        ''' Static constructor.
        ''' </summary>
        Shared Sub New()
            NLayoutGroupExampleSchema = NSchema.Create(GetType(NLayoutGroupExample), NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            ' Create a simple drawing
            Dim drawingViewWithRibbon As NDrawingViewWithRibbon = New NDrawingViewWithRibbon()
            m_DrawingView = drawingViewWithRibbon.View

            m_DrawingView.Document.HistoryService.Pause()
            Try
                InitDiagram(m_DrawingView.Document)
            Finally
                m_DrawingView.Document.HistoryService.Resume()
            End Try

            Return drawingViewWithRibbon
        End Function
        Protected Overrides Function CreateExampleControls() As NWidget
            Return Nothing
        End Function
        Protected Overrides Function GetExampleDescription() As String
            Return "Demonstrates how to layout the shapes in a group."
        End Function

        Private Sub InitDiagram(ByVal drawingDocument As NDrawingDocument)
            ' Create a group
            Dim group As NGroup = New NGroup()
            drawingDocument.Content.ActivePage.Items.Add(group)
            group.PinX = 300
            group.PinY = 300

            ' Create some shapes and add them to the group
            Dim factory As NBasicShapeFactory = New NBasicShapeFactory()

            Dim root = factory.CreateShape(ENBasicShape.Rectangle)
            root.Text = "Root"
            group.Shapes.Add(root)

            Dim shape1 = factory.CreateShape(ENBasicShape.Circle)
            shape1.Text = "Circle 1"
            group.Shapes.Add(shape1)

            Dim shape2 = factory.CreateShape(ENBasicShape.Circle)
            shape2.Text = "Circle 2"
            group.Shapes.Add(shape2)

            Dim shape3 = factory.CreateShape(ENBasicShape.Circle)
            shape3.Text = "Circle 3"
            group.Shapes.Add(shape3)

            ' Connect the shapes
            ConnectShapes(root, shape1)
            ConnectShapes(root, shape2)
            ConnectShapes(root, shape3)

            ' Update group bounds
            group.UpdateBounds()

            ' Create a layout context and configure the area you want the group to be arranged in.
            ' The layout area is in page coordinates
            Dim layoutContext As NDrawingLayoutContext = New NDrawingLayoutContext(drawingDocument, group)
            layoutContext.LayoutArea = New NRectangle(100, 100, 200, 200)

            ' Layout the shapes in the group
            Dim layout As NRadialGraphLayout = New NRadialGraphLayout()
            layout.Arrange(group.Shapes.ToArray(), layoutContext)

            ' Update the group bounds
            group.UpdateBounds()
        End Sub

#End Region

#Region "Implementation"

        Private Sub ConnectShapes(ByVal shape1 As NShape, ByVal shape2 As NShape)
            Dim group = shape1.OwnerGroup

            Dim connector As NRoutableConnector = New NRoutableConnector()
            connector.UserClass = NDR.StyleSheetNameConnectors
            group.Shapes.Add(connector)
            connector.GlueBeginToShape(shape1)
            connector.GlueEndToShape(shape2)
        End Sub

#End Region

#Region "Fields"

        Private m_DrawingView As NDrawingView

#End Region

#Region "Schema"

        ''' <summary>
        ''' Schema associated with NLayoutGroupExample.
        ''' </summary>
        Public Shared ReadOnly NLayoutGroupExampleSchema As NSchema

#End Region
    End Class
End Namespace

Imports Nevron.Nov.Diagram
Imports Nevron.Nov.Diagram.Shapes
Imports Nevron.Nov.Dom
Imports Nevron.Nov.Graphics
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.Diagram
    Public Class NConnectorWithMultipleLabelsExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' Default constructor.
        ''' </summary>
        Public Sub New()
        End Sub

        ''' <summary>
        ''' Static constructor.
        ''' </summary>
        Shared Sub New()
            NConnectorWithMultipleLabelsExampleSchema = NSchema.Create(GetType(NConnectorWithMultipleLabelsExample), NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            ' Create a simple drawing
            Dim drawingViewWithRibbon As NDrawingViewWithRibbon = New NDrawingViewWithRibbon()
            m_DrawingView = drawingViewWithRibbon.View
            m_DrawingView.Document.HistoryService.Pause()

            Try
                InitDiagram(m_DrawingView.Document)
            Finally
                m_DrawingView.Document.HistoryService.Resume()
            End Try

            Return drawingViewWithRibbon
        End Function

        Protected Overrides Function CreateExampleControls() As NWidget
            Return Nothing
        End Function

        Protected Overrides Function GetExampleDescription() As String
            Return "
<p>This example demonstrates how to create a connector with multiple labels. This can be done by adding
outward ports to a connector and then gluing shapes that only have text to these outward ports.</p>
"
        End Function

        Private Sub InitDiagram(ByVal drawingDocument As NDrawingDocument)
            Dim drawing = drawingDocument.Content
            Dim activePage = drawing.ActivePage

            ' 1. Create some shape factories
            Dim basicShapesFactory As NBasicShapeFactory = New NBasicShapeFactory()
            Dim connectorShapesFactory As NConnectorShapeFactory = New NConnectorShapeFactory()

            ' 2. Create and add some shapes
            Dim shape1 = basicShapesFactory.CreateShape(ENBasicShape.Rectangle)
            shape1.SetBounds(New NRectangle(50, 50, 100, 100))
            activePage.Items.Add(shape1)
            Dim shape2 = basicShapesFactory.CreateShape(ENBasicShape.Rectangle)
            shape2.SetBounds(New NRectangle(400, 50, 100, 100))
            activePage.Items.Add(shape2)

            ' 3. Connect the shapes
            Dim connector = connectorShapesFactory.CreateShape(ENConnectorShape.Line)
            activePage.Items.Add(connector)
            connector.GlueBeginToShape(shape1)
            connector.GlueEndToShape(shape2)

            ' Add 2 outward ports to the connector
            Dim port1 As NPort = New NPort(0.3, 0.3, True)
            port1.GlueMode = ENPortGlueMode.Outward
            connector.Ports.Add(port1)
            Dim port2 As NPort = New NPort(0.7, 0.7, True)
            port2.GlueMode = ENPortGlueMode.Outward
            connector.Ports.Add(port2)

            ' Attach label shapes to the outward ports of the connector
            Dim labelShape1 = CreateLabelShape("Label 1")
            activePage.Items.Add(labelShape1)
            labelShape1.GlueMasterPortToPort(labelShape1.Ports(0), port1)
            Dim labelShape2 = CreateLabelShape("Label 2")
            activePage.Items.Add(labelShape2)
            labelShape2.GlueMasterPortToPort(labelShape2.Ports(0), port2)
        End Sub

#End Region

#Region "Implementation"

        Private Function CreateLabelShape(ByVal text As String) As NShape
            Dim labelShape As NShape = New NShape()

            ' Configure shape
            labelShape.SetBounds(0, 0, 100, 30)
            labelShape.SetProtectionMask(ENDiagramItemOperationMask.All)
            labelShape.CanSplit = False
            labelShape.GraphPart = False
            labelShape.RouteThroughHorizontally = True
            labelShape.RouteThroughVertically = True

            ' Set text and make text block resize to text
            labelShape.Text = text
            CType(labelShape.TextBlock, NTextBlock).ResizeMode = ENTextBlockResizeMode.TextSize

            ' Set text background and border
            labelShape.TextBlock.BackgroundFill = New NColorFill(NColor.White)
            labelShape.TextBlock.Border = NBorder.CreateFilledBorder(NColor.Black)
            labelShape.TextBlock.BorderThickness = New NMargins(1)
            labelShape.TextBlock.Padding = New NMargins(2)

            ' Add a port to the shape
            labelShape.Ports.Add(New NPort(0.5, 0.5, True))
            Return labelShape
        End Function

#End Region

#Region "Fields"

        Private m_DrawingView As NDrawingView

#End Region

#Region "Schema"

        ''' <summary>
        ''' Schema associated with NConnectorWithMultipleLabelsExample.
        ''' </summary>
        Public Shared ReadOnly NConnectorWithMultipleLabelsExampleSchema As NSchema

#End Region
    End Class
End Namespace

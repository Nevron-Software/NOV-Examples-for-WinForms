Imports Nevron.Nov.Diagram
Imports Nevron.Nov.Dom
Imports Nevron.Nov.Graphics
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.Diagram
    Public Class NPortsGlueExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' Default constructor.
        ''' </summary>
        Public Sub New()
        End Sub

        ''' <summary>
        ''' Static constructor.
        ''' </summary>
        Shared Sub New()
            NPortsGlueExampleSchema = NSchema.Create(GetType(NPortsGlueExample), NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            ' Create a simple drawing
            Dim drawingViewWithRibbon As NDrawingViewWithRibbon = New NDrawingViewWithRibbon()
            m_DrawingView = drawingViewWithRibbon.View

            m_DrawingView.Document.HistoryService.Pause()
            Try
                InitDiagram(m_DrawingView.Document)
            Finally
                m_DrawingView.Document.HistoryService.Resume()
            End Try

            Return drawingViewWithRibbon
        End Function
        Protected Overrides Function CreateExampleControls() As NWidget
            Return Nothing
        End Function
        Protected Overrides Function GetExampleDescription() As String
            Return "
<p>
    Demonstrates the ports glue. Move the rectangle close to the Connector or the Line to test the port direction that is syncrhonized with the geometry tangenta at this point.
</p>
<p> 
    In NOV Diagram each port GlueMode can be set to Inward, Outward or InwardAndOutward. 
</p>
<p>
    <b>Inward</b> ports can accept connections with Begin and End points of 1D shapes as well as other shapes Outward ports.
    Most of the ports are only Inward ports.
</p>
<p>
    <b>Outward</b> ports can be connected only to other shapes Inward ports. When a shape with outward ports
	is moved closed a shape with inward ports. The two shapes are glued in master-slave relation. The shape
	to which the outward port belongs is rotated and translated so that its outward port location matches
	the inward port location and so that the ports directions form a line.
</p>
<p>
    <b>InwardAndOutward</b> ports behave as both inward and outward.
</p>
" End Function

        Private Sub InitDiagram(ByVal drawingDocument As NDrawingDocument)
            Dim drawing = drawingDocument.Content
            Dim activePage = drawing.ActivePage

            activePage.Interaction.Enable1DShapeSplitting = False
            activePage.Interaction.AutoConnectToBeginPoints = False
            activePage.Interaction.AutoConnectToEndPoints = False

            ' hide the grid
            drawing.ScreenVisibility.ShowGrid = False

            ' Port Glue To Geometry Contour
            If True Then
                ' create a connector with begin, end and middle ports
                ' start and end ports are offset with absolute values
                Dim connector As NRoutableConnector = New NRoutableConnector()
                activePage.Items.Add(connector)
                connector.SetBeginPoint(New NPoint(50, 50))
                connector.SetEndPoint(New NPoint(250, 250))

                Dim beginPort As NPort = New NPort()
                connector.Ports.Add(beginPort)
                beginPort.GlueToGeometryContour(0, 10, True, NAngle.Zero)

                Dim endPort As NPort = New NPort()
                connector.Ports.Add(endPort)
                endPort.GlueToGeometryContour(1, -10, True, NAngle.Zero)

                Dim middlePort As NPort = New NPort()
                connector.Ports.Add(middlePort)
                middlePort.GlueToGeometryContour(0.5, 0, True, NAngle.Zero)
            End If

            ' Port Glue To Shape Line
            If True Then
                Dim lineShape As NShape = NShape.CreateLineShape()
                activePage.Items.Add(lineShape)
                lineShape.SetBeginPoint(New NPoint(350, 50))
                lineShape.SetEndPoint(New NPoint(550, 250))

                Dim middlePort As NPort = New NPort()
                lineShape.Ports.Add(middlePort)
                middlePort.GlueToGeometryContour(0.5, 0, True, NAngle.Zero)
            End If

            ' create a rectangle shape with 
            If True Then
                Dim rectShape As NShape = NShape.CreateRectangle()
                rectShape.SetBounds(300, 300, 100, 100)
                rectShape.Text = "Test Port Direction with Me"

                Dim port As NPort = New NPort(0.5, 0, True)
                port.DirectionMode = ENPortDirectionMode.AutoCenter
                port.GlueMode = ENPortGlueMode.Outward
                rectShape.Ports.Add(port)

                activePage.Items.Add(rectShape)
            End If
        End Sub

#End Region

#Region "Fields"

        Private m_DrawingView As NDrawingView

#End Region

#Region "Schema"

        ''' <summary>
        ''' Schema associated with NPortsGlueExample.
        ''' </summary>
        Public Shared ReadOnly NPortsGlueExampleSchema As NSchema

#End Region
    End Class
End Namespace

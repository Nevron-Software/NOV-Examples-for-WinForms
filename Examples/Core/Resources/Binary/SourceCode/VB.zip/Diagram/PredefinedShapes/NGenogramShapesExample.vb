Imports Nevron.Nov.Diagram
Imports Nevron.Nov.Diagram.Shapes
Imports Nevron.Nov.Dom
Imports Nevron.Nov.Graphics
Imports Nevron.Nov.Layout
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.Diagram
    Public Class NGenogramShapesExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' Default constructor.
        ''' </summary>
        Public Sub New()
        End Sub

        ''' <summary>
        ''' Static constructor
        ''' </summary>
        Shared Sub New()
            NGenogramShapesExampleSchema = NSchema.Create(GetType(NGenogramShapesExample), NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            ' Create a simple drawing
            Dim drawingViewWithRibbon As NDrawingViewWithRibbon = New NDrawingViewWithRibbon()
            m_DrawingView = drawingViewWithRibbon.View
            m_DrawingView.Document.HistoryService.Pause()

            Try
                InitDiagram(m_DrawingView.Document)
            Finally
                m_DrawingView.Document.HistoryService.Resume()
            End Try

            Return drawingViewWithRibbon
        End Function

        Protected Overrides Function CreateExampleControls() As NWidget
            Return Nothing
        End Function

        Protected Overrides Function GetExampleDescription() As String
            Return "
<p>
    This example demonstrates the genogram shapes, which are created by the NGenogramShapeFactory.
</p>
"
        End Function

        Private Sub InitDiagram(ByVal drawingDocument As NDrawingDocument)
            Dim drawing = drawingDocument.Content
            Dim activePage = drawing.ActivePage

            ' Hide grid and ports
            drawing.ScreenVisibility.ShowGrid = False
            drawing.ScreenVisibility.ShowPorts = False

            ' Create all shapes
            Dim factory As NGenogramShapeFactory = New NGenogramShapeFactory()
            Dim row = 0, col = 0
            Dim cellWidth As Double = 240
            Dim cellHeight As Double = 150
            Dim i = 0

            While i < factory.ShapeCount
                Dim shape = factory.CreateShape(i)
                shape.HorizontalPlacement = ENHorizontalPlacement.Center
                shape.VerticalPlacement = ENVerticalPlacement.Center
                Dim textBlock As NTextBlock = shape.GetFirstDescendant(Of NTextBlock)()

                If textBlock Is Nothing OrElse i = ENGenogramShape.Male OrElse i = ENGenogramShape.Female OrElse i = ENGenogramShape.Pet OrElse i = ENGenogramShape.UnknownGender Then
                    textBlock = CType(shape.TextBlock, NTextBlock)
                End If

                textBlock.Text = factory.GetShapeInfo(i).Name
                activePage.Items.Add(shape)

                If col >= 4 Then
                    row += 1
                    col = 0
                End If

                Dim beginPoint As NPoint = New NPoint(50 + col * cellWidth, 50 + row * cellHeight)

                If shape.ShapeType = ENShapeType.Shape1D Then
                    Dim endPoint As NPoint = beginPoint + New NPoint(cellWidth - 50, cellHeight - 50)
                    shape.SetBeginPoint(beginPoint)
                    shape.SetEndPoint(endPoint)
                Else
                    textBlock.SetFx(NShapeBlock.PinYProperty, "$Parent.Height + Height + 10")
                    textBlock.ResizeMode = ENTextBlockResizeMode.TextSize
                    shape.SetBounds(beginPoint.X, beginPoint.Y, shape.Width, shape.Height)
                End If

                i += 1
                col += 1
            End While

            ' size page to content
            activePage.Layout.ContentPadding = New NMargins(50)
            activePage.SizeToContent()
        End Sub

#End Region

#Region "Fields"

        Private m_DrawingView As NDrawingView

#End Region

#Region "Schema"

        ''' <summary>
        ''' Schema associated with NGenogramShapesExample.
        ''' </summary>
        Public Shared ReadOnly NGenogramShapesExampleSchema As NSchema

#End Region
    End Class
End Namespace

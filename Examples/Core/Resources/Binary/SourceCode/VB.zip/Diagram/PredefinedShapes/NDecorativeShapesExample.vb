Imports Nevron.Nov.Diagram
Imports Nevron.Nov.Diagram.Layout
Imports Nevron.Nov.Diagram.Shapes
Imports Nevron.Nov.Dom
Imports Nevron.Nov.Graphics
Imports Nevron.Nov.Layout
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.Diagram
    Public Class NDecorativeShapesExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' Default constructor.
        ''' </summary>
        Public Sub New()
        End Sub

        ''' <summary>
        ''' Static constructor
        ''' </summary>
        Shared Sub New()
            NDecorativeShapesExampleSchema = NSchema.Create(GetType(NDecorativeShapesExample), NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            ' Create a simple drawing
            Dim drawingViewWithRibbon As NDrawingViewWithRibbon = New NDrawingViewWithRibbon()
            m_DrawingView = drawingViewWithRibbon.View
            m_DrawingView.Document.HistoryService.Pause()

            Try
                InitDiagram(m_DrawingView.Document)
            Finally
                m_DrawingView.Document.HistoryService.Resume()
            End Try

            Return drawingViewWithRibbon
        End Function

        Protected Overrides Function CreateExampleControls() As NWidget
            Return Nothing
        End Function

        Protected Overrides Function GetExampleDescription() As String
            Return "
<p>
    This example demonstrates the decorative shapes, which are created by the NDecorativeShapeFactory.
</p>
"
        End Function

        Private Sub InitDiagram(ByVal drawingDocument As NDrawingDocument)
            Dim drawing = drawingDocument.Content
            Dim activePage = drawing.ActivePage

            ' Hide grid and ports
            drawing.ScreenVisibility.ShowGrid = False
            drawing.ScreenVisibility.ShowPorts = False

            ' create all shapes
            Dim factory As NDecorativeShapeFactory = New NDecorativeShapeFactory()
            factory.DefaultSize = New NSize(80, 60)

            For i = 0 To factory.ShapeCount - 1
                Dim shape = factory.CreateShape(i)
                shape.HorizontalPlacement = ENHorizontalPlacement.Center
                shape.VerticalPlacement = ENVerticalPlacement.Center
                shape.Text = factory.GetShapeInfo(i).Name
                shape.MoveTextBlockBelowShape()
                activePage.Items.Add(shape)
            Next

            ' arrange them
            Dim shapes = activePage.GetShapes(False)
            Dim layoutContext As NLayoutContext = New NLayoutContext()
            layoutContext.BodyAdapter = New NShapeBodyAdapter(drawingDocument)
            layoutContext.GraphAdapter = New NShapeGraphAdapter()
            layoutContext.LayoutArea = activePage.Bounds
            Dim flowLayout As NTableFlowLayout = New NTableFlowLayout()
            flowLayout.HorizontalSpacing = 30
            flowLayout.VerticalSpacing = 50
            flowLayout.Direction = ENHVDirection.LeftToRight
            flowLayout.MaxOrdinal = 5
            flowLayout.Arrange(shapes.CastAll(Of Object)(), layoutContext)

            ' size page to content
            activePage.Layout.ContentPadding = New NMargins(40)
            activePage.SizeToContent()
        End Sub

#End Region

#Region "Fields"

        Private m_DrawingView As NDrawingView

#End Region

#Region "Schema"

        ''' <summary>
        ''' Schema associated with NDecorativeShapesExample
        ''' </summary>
        Public Shared ReadOnly NDecorativeShapesExampleSchema As NSchema

#End Region
    End Class
End Namespace

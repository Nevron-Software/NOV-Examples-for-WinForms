Imports Nevron.Nov.Diagram
Imports Nevron.Nov.Diagram.Shapes
Imports Nevron.Nov.Dom
Imports Nevron.Nov.Graphics
Imports Nevron.Nov.Layout
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.Diagram
    Public Class NDimensioningEngineeringShapesExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' Default constructor.
        ''' </summary>
        Public Sub New()
        End Sub

        ''' <summary>
        ''' Static constructor.
        ''' </summary>
        Shared Sub New()
            NDimensioningEngineeringShapesExampleSchema = NSchema.Create(GetType(NDimensioningEngineeringShapesExample), NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            ' Create a simple drawing
            Dim drawingViewWithRibbon As NDrawingViewWithRibbon = New NDrawingViewWithRibbon()
            m_DrawingView = drawingViewWithRibbon.View
            m_DrawingView.Document.HistoryService.Pause()

            Try
                InitDiagram(m_DrawingView.Document)
            Finally
                m_DrawingView.Document.HistoryService.Resume()
            End Try

            Return drawingViewWithRibbon
        End Function

        Protected Overrides Function CreateExampleControls() As NWidget
            Return Nothing
        End Function

        Protected Overrides Function GetExampleDescription() As String
            Return "
<p>
    This example demonstrates the dimensioning engineering shapes, which are created by the NDimensioningEngineeringShapeFactory.
</p>
"
        End Function

        Private Sub InitDiagram(ByVal drawingDocument As NDrawingDocument)
            Const XStep As Double = 150
            Const YStep As Double = 200
            Dim drawing = drawingDocument.Content
            Dim activePage = drawing.ActivePage

            ' Hide grid and ports
            drawing.ScreenVisibility.ShowGrid = False
            drawing.ScreenVisibility.ShowPorts = False

            ' create all shapes
            Dim factory As NDimensioningEngineeringShapeFactory = New NDimensioningEngineeringShapeFactory()
            factory.DefaultSize = New NSize(90, 90)
            Dim x As Double = 0
            Dim y As Double = 0

            For i = 0 To factory.ShapeCount - 1
                Dim shape = factory.CreateShape(i)
                shape.HorizontalPlacement = ENHorizontalPlacement.Center
                shape.VerticalPlacement = ENVerticalPlacement.Center
                shape.Tooltip = New NTooltip(factory.GetShapeInfo(i).Name)
                activePage.Items.Add(shape)

                If shape.ShapeType = ENShapeType.Shape1D Then
                    Dim shapeType As ENDimensioningEngineeringShapes = i

                    Select Case shapeType
                        Case ENDimensioningEngineeringShapes.VerticalBaseline, ENDimensioningEngineeringShapes.Vertical, ENDimensioningEngineeringShapes.VerticalOutside, ENDimensioningEngineeringShapes.OrdinateVertical, ENDimensioningEngineeringShapes.OrdinateVerticalMultiple
                            shape.SetBeginPoint(New NPoint(x + shape.Width, y + shape.Height))
                            shape.SetEndPoint(New NPoint(x + shape.Width, y))
                        Case ENDimensioningEngineeringShapes.OrdinateHorizontalMultiple, ENDimensioningEngineeringShapes.OrdinateHorizontal
                            shape.SetBeginPoint(New NPoint(x, y))
                            shape.SetEndPoint(New NPoint(x + shape.Width, y))
                        Case ENDimensioningEngineeringShapes.Radius, ENDimensioningEngineeringShapes.RadiusOutside, ENDimensioningEngineeringShapes.ArcRadius, ENDimensioningEngineeringShapes.Diameter, ENDimensioningEngineeringShapes.DiameterOutside
                            shape.SetBeginPoint(New NPoint(x, y + shape.Height / 2))
                            shape.SetEndPoint(New NPoint(x + shape.Width, y - shape.Height / 2))
                        Case ENDimensioningEngineeringShapes.AngleCenter, ENDimensioningEngineeringShapes.AngleEven, ENDimensioningEngineeringShapes.AngleOutside, ENDimensioningEngineeringShapes.AngleUneven
                            shape.SetBeginPoint(New NPoint(x, y + shape.Width / 2))
                            shape.SetEndPoint(New NPoint(x + shape.Width, y + shape.Width / 2))
                        Case Else
                            shape.SetBeginPoint(New NPoint(x, y))
                            shape.SetEndPoint(New NPoint(x + shape.Width, y + shape.Height))
                    End Select
                Else
                    shape.SetBounds(x, y, shape.Width, shape.Height)
                    shape.LocPinY = 1
                End If

                x += XStep

                If x > activePage.Width Then
                    x = 0
                    y += YStep
                End If
            Next

            ' size page to content
            activePage.Layout.ContentPadding = New NMargins(50)
            activePage.SizeToContent()
        End Sub

#End Region

#Region "Fields"

        Private m_DrawingView As NDrawingView

#End Region

#Region "Schema"

        ''' <summary>
        ''' Schema associated with NDimensioningEngineeringShapesExample.
        ''' </summary>
        Public Shared ReadOnly NDimensioningEngineeringShapesExampleSchema As NSchema

#End Region
    End Class
End Namespace

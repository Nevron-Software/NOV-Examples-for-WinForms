Imports Nevron.Nov.Diagram
Imports Nevron.Nov.Diagram.Expressions
Imports Nevron.Nov.Diagram.Shapes
Imports Nevron.Nov.Dom
Imports Nevron.Nov.Graphics
Imports Nevron.Nov.Layout
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.Diagram
    Public Class NDrawingToolShapesExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' Default constructor.
        ''' </summary>
        Public Sub New()
        End Sub

        ''' <summary>
        ''' Static constructor.
        ''' </summary>
        Shared Sub New()
            NDrawingToolShapesExampleSchema = NSchema.Create(GetType(NDrawingToolShapesExample), NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            ' Create a simple drawing
            Dim drawingViewWithRibbon As NDrawingViewWithRibbon = New NDrawingViewWithRibbon()
            m_DrawingView = drawingViewWithRibbon.View
            m_DrawingView.Document.HistoryService.Pause()

            Try
                InitDiagram(m_DrawingView.Document)
            Finally
                m_DrawingView.Document.HistoryService.Resume()
            End Try

            Return drawingViewWithRibbon
        End Function

        Protected Overrides Function CreateExampleControls() As NWidget
            Return Nothing
        End Function

        Protected Overrides Function GetExampleDescription() As String
            Return "
<p>
    This example demonstrates the drawing tool shapes, which are created by the NDrawingToolShapeFactory.
</p>
"
        End Function

        Private Sub InitDiagram(ByVal drawingDocument As NDrawingDocument)
            Const XStep As Double = 150
            Const YStep As Double = 200
            Dim drawing = drawingDocument.Content
            Dim activePage = drawing.ActivePage

            ' Hide grid and ports
            drawing.ScreenVisibility.ShowGrid = False
            drawing.ScreenVisibility.ShowPorts = False

            ' create all shapes
            Dim factory As NDrawingToolShapeFactory = New NDrawingToolShapeFactory()
            factory.DefaultSize = New NSize(90, 90)
            Dim x As Double = 0
            Dim y As Double = 0

            For i = 0 To factory.ShapeCount - 1
                Dim shape = factory.CreateShape(i)
                shape.HorizontalPlacement = ENHorizontalPlacement.Center
                shape.VerticalPlacement = ENVerticalPlacement.Center
                shape.Tooltip = New NTooltip(factory.GetShapeInfo(i).Name)

                If i <> ENDrawingToolShapes.SectorNumeric AndAlso i <> ENDrawingToolShapes.ArcNumeric AndAlso i <> ENDrawingToolShapes.RightTriangle Then
                    shape.Text = factory.GetShapeInfo(i).Name
                    MoveTextBelowShape(shape)
                End If

                activePage.Items.Add(shape)

                If shape.ShapeType = ENShapeType.Shape1D Then
                    If i = ENDrawingToolShapes.CircleRadius Then
                        shape.SetBeginPoint(New NPoint(x + shape.Width / 2, y))
                    Else
                        shape.SetBeginPoint(New NPoint(x, y))
                    End If

                    Dim width = shape.Width

                    If i = ENDrawingToolShapes.MultigonEdge Then
                        width = 90
                    ElseIf i = ENDrawingToolShapes.MultigonCenter Then
                        width = 30
                    End If

                    shape.SetEndPoint(New NPoint(x + width, y + shape.Height))
                Else
                    shape.SetBounds(x, y, shape.Width, shape.Height)
                    shape.LocPinY = 1
                End If

                x += XStep

                If x > activePage.Width Then
                    x = 0
                    y += YStep
                End If
            Next

            ' size page to content
            activePage.Layout.ContentPadding = New NMargins(50)
            activePage.SizeToContent()
        End Sub

        Private Sub MoveTextBelowShape(ByVal shape As NShape)
            If shape.ShapeType = ENShapeType.Shape1D Then
                Dim textBlock = CType(shape.TextBlock, NTextBlock)
                textBlock.Padding = New NMargins(0, 5, 0, 0)
                textBlock.ResizeMode = ENTextBlockResizeMode.TextSize
                textBlock.SetFx(NShapeBlock.PinYProperty, New NShapeHeightFactorFx(1.0))
                textBlock.LocPinY = -2
            Else
                shape.MoveTextBlockBelowShape()
            End If
        End Sub

#End Region

#Region "Fields"

        Private m_DrawingView As NDrawingView

#End Region

#Region "Schema"

        ''' <summary>
        ''' Schema associated with NBasicShapesExample.
        ''' </summary>
        Public Shared ReadOnly NDrawingToolShapesExampleSchema As NSchema

#End Region
    End Class
End Namespace

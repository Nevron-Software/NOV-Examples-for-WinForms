Imports Nevron.Nov.Diagram
Imports Nevron.Nov.Dom
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.Diagram
    Public Class NFishboneShapesExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' Default constructor.
        ''' </summary>
        Public Sub New()
        End Sub

        ''' <summary>
        ''' Static constructor.
        ''' </summary>
        Shared Sub New()
            NFishboneShapesExampleSchema = NSchema.Create(GetType(NFishboneShapesExample), NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            ' Create a simple drawing
            Dim drawingViewWithRibbon As NDrawingViewWithRibbon = New NDrawingViewWithRibbon()
            m_DrawingView = drawingViewWithRibbon.View
            m_DrawingView.Document.HistoryService.Pause()

            Try
                InitDiagram(m_DrawingView.Document)
            Finally
                m_DrawingView.Document.HistoryService.Resume()
            End Try

            Return drawingViewWithRibbon
        End Function

        Protected Overrides Function CreateExampleControls() As NWidget
            Return Nothing
        End Function

        Protected Overrides Function GetExampleDescription() As String
            Return "
<p>
    This example demonstrates the fishbone shapes, which are created by the NFishboneShapeFactory.
</p>
"
        End Function

        Private Sub InitDiagram(ByVal drawingDocument As NDrawingDocument)
            m_DrawingView.LoadFromResource(NResources.RBIN_NDX_FishboneDiagram_ndx)
        End Sub

#End Region

#Region "Fields"

        Private m_DrawingView As NDrawingView

#End Region

#Region "Schema"

        ''' <summary>
        ''' Schema associated with NFishboneShapesExample.
        ''' </summary>
        Public Shared ReadOnly NFishboneShapesExampleSchema As NSchema

#End Region
    End Class
End Namespace

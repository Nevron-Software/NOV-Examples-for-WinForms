Imports Nevron.Nov.Diagram
Imports Nevron.Nov.Diagram.Shapes
Imports Nevron.Nov.Dom
Imports Nevron.Nov.Graphics
Imports Nevron.Nov.Layout
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.Diagram
    Public Class NEPCShapesExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' Default constructor.
        ''' </summary>
        Public Sub New()
        End Sub

        ''' <summary>
        ''' Static constructor.
        ''' </summary>
        Shared Sub New()
            NEPCShapesExampleSchema = NSchema.Create(GetType(NEPCShapesExample), NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            ' Create a simple drawing
            Dim drawingViewWithRibbon As NDrawingViewWithRibbon = New NDrawingViewWithRibbon()
            m_DrawingView = drawingViewWithRibbon.View
            m_DrawingView.Document.HistoryService.Pause()

            Try
                InitDiagram(m_DrawingView.Document)
            Finally
                m_DrawingView.Document.HistoryService.Resume()
            End Try

            Return drawingViewWithRibbon
        End Function

        Protected Overrides Function CreateExampleControls() As NWidget
            Return Nothing
        End Function

        Protected Overrides Function GetExampleDescription() As String
            Return "
<p>
    This example demonstrates the EPC shapes, which are created by the NEpcShapeFactory.
</p>
"
        End Function

        Private Sub InitDiagram(ByVal drawingDocument As NDrawingDocument)
            Dim drawing = drawingDocument.Content
            Dim activePage = drawing.ActivePage

            ' Hide grid and ports
            drawing.ScreenVisibility.ShowGrid = False
            drawing.ScreenVisibility.ShowPorts = False

            ' Create all shapes
            Dim factory As NEPCDiagramShapesFactory = New NEPCDiagramShapesFactory()
            factory.DefaultSize = New NSize(80, 60)
            Dim row = 0, col = 0
            Dim cellWidth As Double = 180
            Dim cellHeight As Double = 120
            Dim i = 0

            While i < factory.ShapeCount
                Dim shape = factory.CreateShape(i)
                Dim tempShape As NShape
                shape.HorizontalPlacement = ENHorizontalPlacement.Center
                shape.VerticalPlacement = ENVerticalPlacement.Center

                If i = ENEpcShape.AND OrElse i = ENEpcShape.OR OrElse i = ENEpcShape.XOR Then
                    Dim group As NGroup = New NGroup()
                    group.Width = shape.Width
                    group.Height = shape.Height
                    group.Shapes.Add(shape)
                    group.TextBlock = New NTextBlock(factory.GetShapeInfo(i).Name)
                    shape.SetFx(NShape.PinXProperty, "Width / 2")
                    shape.SetFx(NShape.PinYProperty, "Height / 2")
                    shape.SetFx(NShape.WidthProperty, "$ParentSheet.Width")
                    shape.SetFx(NShape.HeightProperty, "$ParentSheet.Height")
                    group.MoveTextBlockBelowShape()
                    activePage.Items.Add(group)
                    tempShape = group
                Else
                    shape.Text = factory.GetShapeInfo(i).Name

                    If i = ENEpcShape.InformationMaterial Then
                        shape.TextBlock.Fill = New NColorFill(NColor.Black)
                    End If

                    shape.MoveTextBlockBelowShape()
                    activePage.Items.Add(shape)
                    tempShape = shape
                End If

                If col >= 4 Then
                    row += 1
                    col = 0
                End If

                Dim beginPoint As NPoint = New NPoint(50 + col * cellWidth, 50 + row * cellHeight)

                If shape.ShapeType = ENShapeType.Shape1D Then
                    Dim endPoint As NPoint = beginPoint + New NPoint(cellWidth - 100, cellHeight - 100)
                    tempShape.SetBeginPoint(beginPoint)
                    tempShape.SetEndPoint(endPoint)
                Else
                    tempShape.SetBounds(beginPoint.X, beginPoint.Y, shape.Width, shape.Height)
                End If

                i += 1
                col += 1
            End While

            ' size page to content
            activePage.Layout.ContentPadding = New NMargins(40)
            activePage.SizeToContent()
        End Sub

#End Region

#Region "Fields"

        Private m_DrawingView As NDrawingView

#End Region

#Region "Schema"

        ''' <summary>
        ''' Schema associated with NEPCShapesExample.
        ''' </summary>
        Public Shared ReadOnly NEPCShapesExampleSchema As NSchema

#End Region
    End Class
End Namespace

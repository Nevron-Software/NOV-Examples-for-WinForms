Imports Nevron.Nov.Diagram
Imports Nevron.Nov.Diagram.Shapes
Imports Nevron.Nov.Dom
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.Diagram
    Public Class NDrawingThemesExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' Default constructor.
        ''' </summary>
        Public Sub New()
        End Sub

        ''' <summary>
        ''' Static constructor.
        ''' </summary>
        Shared Sub New()
            NDrawingThemesExampleSchema = NSchema.Create(GetType(NDrawingThemesExample), NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            ' Create a simple drawing
            Dim drawingViewWithRibbon As NDrawingViewWithRibbon = New NDrawingViewWithRibbon()
            m_DrawingView = drawingViewWithRibbon.View

            m_DrawingView.Document.HistoryService.Pause()
            Try
                InitDiagram(m_DrawingView.Document)
            Finally
                m_DrawingView.Document.HistoryService.Resume()
            End Try

            Return drawingViewWithRibbon
        End Function
        Protected Overrides Function CreateExampleControls() As NWidget
            Return Nothing
        End Function
        Protected Overrides Function GetExampleDescription() As String
            Return "
<p>
	This example shows how the different shape styles of a drawing theme look. Select a new page theme and
	page theme variant from the <b>Design</b> tab of the ribbon to see another theme.
</p>" End Function

#End Region

#Region "Implementation"

        Private Sub InitDiagram(ByVal drawingDocument As NDrawingDocument)
            Const ShapeWidth As Double = 70
            Const ShapeHeight As Double = 50
            Const Spacing As Double = 20
            Const ShapeType = ENBasicShape.Rectangle

            Dim drawing = drawingDocument.Content
            Dim page = drawing.ActivePage
            Dim factory As NBasicShapeFactory = New NBasicShapeFactory()
            ' Hide ports
            drawing.ScreenVisibility.ShowPorts = False

            ' Create the variant styled shapes
            Dim x As Double = 0
            Dim y As Double = 0

            For i = 0 To 3
                Dim shape = factory.CreateShape(ShapeType)
                shape.SetBounds(x, y, ShapeWidth, ShapeHeight)
                shape.Text = "Text"

                ' Set the shape style
                Dim styleIndex = 100 + i
                Dim colorIndex = 100 + i
                shape.Style = New NShapeStyle(styleIndex, colorIndex)

                ' Add the shape to the page
                page.Items.Add(shape)

                x += ShapeWidth + Spacing
            Next

            For i = 0 To 5
                Dim styleIndex = i
                y += ShapeHeight + Spacing
                x = 0

                For j = 0 To 6
                    Dim shape = factory.CreateShape(ShapeType)
                    shape.SetBounds(x, y, ShapeWidth, ShapeHeight)
                    shape.Text = "Text"

                    ' Set the shape style
                    Dim colorIndex = 200 + j
                    shape.Style = New NShapeStyle(styleIndex, colorIndex)

                    ' Add the page to the shape
                    page.Items.Add(shape)

                    x += ShapeWidth + Spacing
                Next
            Next

            ' Connect 2 shapes with a connector
            Dim shape1 = CType(page.Items(0), NShape)
            Dim shape2 = CType(page.Items(11), NShape)

            Dim connector As NRoutableConnector = New NRoutableConnector()
            connector.Text = "Text"
            page.Items.Add(connector)
            connector.UserClass = NDR.StyleSheetNameConnectors
            connector.RerouteMode = ENRoutableConnectorRerouteMode.Always
            connector.GlueBeginToShape(shape1)
            connector.GlueEndToShape(shape2)

            shape1.AllowMoveX = False
            shape1.AllowMoveY = False

            page.SizeToContent()
        End Sub

#End Region

#Region "Fields"

        Private m_DrawingView As NDrawingView

#End Region

#Region "Schema"

        ''' <summary>
        ''' Schema associated with NDrawingThemesExample.
        ''' </summary>
        Public Shared ReadOnly NDrawingThemesExampleSchema As NSchema

#End Region
    End Class
End Namespace

Imports Nevron.Nov.Diagram
Imports Nevron.Nov.Dom
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.Diagram
    Public Class NVisioDrawingImportExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' Default constructor.
        ''' </summary>
        Public Sub New()
        End Sub

        ''' <summary>
        ''' Static constructor.
        ''' </summary>
        Shared Sub New()
            NVisioDrawingImportExampleSchema = NSchema.Create(GetType(NVisioDrawingImportExample), NExampleBaseSchema)
        End Sub

#End Region

#Region "Protected Overrides"

        Protected Overrides Function CreateExampleContent() As NWidget
            ' Create a simple drawing
            Dim drawingViewWithRibbon As NDrawingViewWithRibbon = New NDrawingViewWithRibbon()
            m_DrawingView = drawingViewWithRibbon.View

            m_DrawingView.Document.HistoryService.Pause()
            Try
                InitDiagram(m_DrawingView.Document)
            Finally
                m_DrawingView.Document.HistoryService.Resume()
            End Try

            Return drawingViewWithRibbon
        End Function
        Protected Overrides Function CreateExampleControls() As NWidget
            Return Nothing
        End Function
        Protected Overrides Function GetExampleDescription() As String
            Return "<p>Demonstrates how to import a Visio drawing (in VSDX format) to NOV Diagram.</p>"
        End Function

        Private Sub InitDiagram(ByVal drawingDocument As NDrawingDocument)
            ' Import a Visio diagram
            m_DrawingView.LoadFromResourceAsync(NResources.RBIN_VSDX_CorporateDiagramShapes_vsdx)

            ' Hide ports
            drawingDocument.Content.ScreenVisibility.ShowPorts = False
        End Sub

#End Region

#Region "Fields"

        Private m_DrawingView As NDrawingView

#End Region

#Region "Schema"

        ''' <summary>
        ''' Schema associated with NVisioDrawingImportExample.
        ''' </summary>
        Public Shared ReadOnly NVisioDrawingImportExampleSchema As NSchema

#End Region
    End Class
End Namespace

Imports Nevron.Nov.Diagram
Imports Nevron.Nov.Diagram.Shapes
Imports Nevron.Nov.Dom
Imports Nevron.Nov.Graphics
Imports Nevron.Nov.Text
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.Diagram
    ''' <summary>
    ''' 
    ''' </summary>
    Public Class NFindAndReplaceExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' Default constructor.
        ''' </summary>
        Public Sub New()
        End Sub

        ''' <summary>
        ''' Static constructor.
        ''' </summary>
        Shared Sub New()
            NFindAndReplaceExampleSchema = NSchema.Create(GetType(NFindAndReplaceExample), NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            ' Create a simple drawing
            Dim drawingViewWithRibbon As NDrawingViewWithRibbon = New NDrawingViewWithRibbon()
            m_DrawingView = drawingViewWithRibbon.View

            m_DrawingView.Document.HistoryService.Pause()
            Try
                InitDiagram(m_DrawingView.Document)
            Finally
                m_DrawingView.Document.HistoryService.Resume()
            End Try

            Return drawingViewWithRibbon
        End Function
        Protected Overrides Function CreateExampleControls() As NWidget
            Dim stack As NStackPanel = New NStackPanel()

            m_FindTextBox = New NTextBox()
            m_FindTextBox.Text = "quick"
            stack.Add(New NPairBox(New NLabel("Find:"), m_FindTextBox, ENPairBoxRelation.Box1AboveBox2))

            m_ReplaceTextBox = New NTextBox()
            m_ReplaceTextBox.Text = "slow"
            stack.Add(New NPairBox(New NLabel("Replace:"), m_ReplaceTextBox, ENPairBoxRelation.Box1AboveBox2))

            Dim findAllButton As NButton = New NButton("Find All")
            findAllButton.Click += New [Function](Of NEventArgs)(AddressOf OnFindAllButtonClick)
            stack.Add(findAllButton)

            Dim replaceAllButton As NButton = New NButton("Replace All")
            replaceAllButton.Click += New [Function](Of NEventArgs)(AddressOf OnReplaceAllButtonClick)
            stack.Add(replaceAllButton)

            Dim clearHighlightButton As NButton = New NButton("Clear Highlight")
            clearHighlightButton.Click += New [Function](Of NEventArgs)(AddressOf OnClearHighlightButtonClick)
            stack.Add(clearHighlightButton)

            Return stack
        End Function
        Protected Overrides Function GetExampleDescription() As String
            Return "
<p>This example demonstrates how to find and replace text.</p>
<p>Press the ""Find All"" button to highlight all occurrences of ""Find"".</p>
<p>Press the ""Replace All"" button to replace and highlight all occurrences of ""Find"" with ""Replace""</p>
<p>Press the ""Clear Highlight"" button to clear all highlighting</p>
" End Function

        Private Sub InitDiagram(ByVal drawingDocument As NDrawingDocument)
            Dim drawing = drawingDocument.Content

            ' hide the grid
            drawing.ScreenVisibility.ShowGrid = False

            Dim padding As Double = 10
            Dim sizeX As Double = 160
            Dim sizeY As Double = 160

            Dim factory As NBasicShapeFactory = New NBasicShapeFactory()
            For x = 0 To 3
                For y = 0 To 3
                    Dim shape1 = factory.CreateShape(ENBasicShape.Rectangle)
                    shape1.SetBounds(padding + x * (padding + sizeX), padding + y * (padding + sizeY), sizeX, sizeY)
                    shape1.TextBlock = New NTextBlock()
                    shape1.TextBlock.Padding = New NMargins(20)
                    shape1.TextBlock.Text = "The quick brown fox jumps over the lazy dog"
                    drawing.ActivePage.Items.Add(shape1)
                Next
            Next
        End Sub

#End Region

#Region "Event Handlers"

        ''' <summary>
        ''' Called when the user presses the find all button
        ''' </summary>
        ''' <paramname="arg"></param>
        Private Sub OnFindAllButtonClick(ByVal arg As NEventArgs)
            ' init find settings
            Dim settings As NFindTextSettings = New NFindTextSettings()
            settings.FindWhat = m_FindTextBox.Text
            settings.SearchDirection = ENDiagramTextSearchDirection.ForwardReading

            ' loop through all occurrences
            Dim searcher As NTextSearcher = New NTextSearcher(m_DrawingView, settings)
            searcher.ActivateEditor = False
            Dim state As NShapeTextSearchState

            While searcher.FindNext(state)
                state.Shape.GetTextSelection().SetHighlightFillToSelectedInlines(New NColorFill(ENNamedColor.Red))
            End While
        End Sub
        ''' <summary>
        ''' Called when the user presses the replace all button
        ''' </summary>
        ''' <paramname="arg"></param>
        Private Sub OnReplaceAllButtonClick(ByVal arg As NEventArgs)
            ' init find settings
            Dim settings As NFindTextSettings = New NFindTextSettings()
            settings.FindWhat = m_FindTextBox.Text
            settings.SearchDirection = ENDiagramTextSearchDirection.ForwardReading

            ' find all occurrences 
            Dim searcher As NTextSearcher = New NTextSearcher(m_DrawingView, settings)
            searcher.ActivateEditor = False
            Dim state As NShapeTextSearchState

            While searcher.FindNext(state)
                Dim selection As NSelection = state.Shape.GetTextSelection()

                ' replace 
                Dim selectedRange As NRangeI = selection.SelectedRange
                selection.InsertText(m_ReplaceTextBox.Text)

                If m_ReplaceTextBox.Text.Length > 0 Then
                    selection.SelectRange(New NRangeI(selectedRange.Begin, selectedRange.Begin + m_ReplaceTextBox.Text.Length - 1))
                    selection.SetHighlightFillToSelectedInlines(New NColorFill(ENNamedColor.LimeGreen))
                End If
            End While
        End Sub
        ''' <summary>
        ''' Called when the user presses clear highlight button
        ''' </summary>
        ''' <paramname="arg"></param>
        Private Sub OnClearHighlightButtonClick(ByVal arg As NEventArgs)
            Dim shapes = m_DrawingView.Content.GetDescendants(NShape.NShapeSchema)

            For i = 0 To shapes.Count - 1
                Dim shape = CType(shapes(i), NShape)

                Dim rootTextElement As NRangeTextElement = CType(shape.GetTextBlockContentNoCreate(), NRangeTextElement)

                If rootTextElement Is Nothing Then Continue For

                rootTextElement.VisitRanges(Sub(ByVal range As NRangeTextElement)
                                                Dim inline As NInline = TryCast(range, NInline)

                                                If inline IsNot Nothing Then
                                                    inline.ClearLocalValue(NTextElement.HighlightFillProperty)
                                                End If
                                            End Sub)
            Next
        End Sub

#End Region

#Region "Fields"

        Private m_DrawingView As NDrawingView

        Private m_FindTextBox As NTextBox
        Private m_ReplaceTextBox As NTextBox

#End Region

#Region "Schema"

        ''' <summary>
        ''' Schema associated with NFindAndReplaceExample.
        ''' </summary>
        Public Shared ReadOnly NFindAndReplaceExampleSchema As NSchema

#End Region
    End Class
End Namespace

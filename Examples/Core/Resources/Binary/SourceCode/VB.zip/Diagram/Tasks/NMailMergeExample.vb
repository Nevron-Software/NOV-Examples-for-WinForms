Imports System.IO
Imports Nevron.Nov.Diagram
Imports Nevron.Nov.Diagram.Shapes
Imports Nevron.Nov.Dom
Imports Nevron.Nov.Graphics
Imports Nevron.Nov.Text
Imports Nevron.Nov.Text.Data
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.Diagram
    Public Class NMailMergeExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' Default constructor.
        ''' </summary>
        Public Sub New()
        End Sub

        ''' <summary>
        ''' Static constructor.
        ''' </summary>
        Shared Sub New()
            NMailMergeExampleSchema = NSchema.Create(GetType(NMailMergeExample), NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            ' Create a simple drawing
            Dim drawingViewWithRibbon As NDrawingViewWithRibbon = New NDrawingViewWithRibbon()
            m_DrawingView = drawingViewWithRibbon.View
            m_DrawingView.Document.HistoryService.Pause()

            Try
                InitDiagram(m_DrawingView.Document)
            Finally
                m_DrawingView.Document.HistoryService.Resume()
            End Try

            Return drawingViewWithRibbon
        End Function

        Protected Overrides Function CreateExampleControls() As NWidget
            Return Nothing
        End Function

        Protected Overrides Function GetExampleDescription() As String
            Dim previewMailMergeUri = NDataUri.FromImage(NResources.Image_Documentation_PreviewResults_png)
            Return "
<p>
	This example demonstrates how to use the mail merge functionality of the Nevron Diagram control.
</p>
<p>
	Click the <b>Preview Mail Merge</b> button (&nbsp;<img src=""" & previewMailMergeUri.ToString() & """ />&nbsp;) from the <b>Mailings</b> ribbon tab to see the values for the currently selected
    mail merge record. When ready click the <b>Merge & Save</b> button to save all merged documents to a file.
</p>
<p>
	The <b>Merge & Save</b> button saves each of the individual documents result of the mail
	merge operation to a folder.	
</p>
"
        End Function

        Private Sub InitDiagram(ByVal drawingDocument As NDrawingDocument)
            Dim drawing = drawingDocument.Content
            Dim activePage = drawing.ActivePage

            ' Hide the grid and the ports
            drawing.ScreenVisibility.ShowGrid = False
            drawing.ScreenVisibility.ShowPorts = False

            ' Create a shape factory
            Dim basicShapeFactory As NBasicShapeFactory = New NBasicShapeFactory()
            basicShapeFactory.DefaultSize = New NSize(100, 100)

            ' Create the Name shape
            Dim nameShape = basicShapeFactory.CreateShape(ENBasicShape.Rectangle)
            nameShape.Width = 150
            nameShape.PinX = activePage.Width / 2
            nameShape.PinY = 100
            Dim paragraph As NParagraph = New NParagraph()
            paragraph.Inlines.Add(New NFieldInline(New NMailMergePredefinedFieldValue(ENMailMergeDataField.FirstName)))
            paragraph.Inlines.Add(New NTextInline(" "))
            paragraph.Inlines.Add(New NFieldInline(New NMailMergePredefinedFieldValue(ENMailMergeDataField.LastName)))
            nameShape.GetTextBlock().Content.Blocks.Clear()
            nameShape.GetTextBlock().Content.Blocks.Add(paragraph)
            activePage.Items.Add(nameShape)

            ' Create the City shape
            Dim cityShape = basicShapeFactory.CreateShape(ENBasicShape.SixPointStar)
            cityShape.PinX = nameShape.PinX - 150
            cityShape.PinY = nameShape.PinY + 200
            paragraph = New NParagraph()
            paragraph.Inlines.Add(New NFieldInline(New NMailMergePredefinedFieldValue(ENMailMergeDataField.City)))
            cityShape.GetTextBlock().Content.Blocks.Clear()
            cityShape.GetTextBlock().Content.Blocks.Add(paragraph)
            activePage.Items.Add(cityShape)

            ' Create the Birth Date shape
            Dim birthDateShape = basicShapeFactory.CreateShape(ENBasicShape.Circle)
            birthDateShape.PinX = nameShape.PinX + 150
            birthDateShape.PinY = cityShape.PinY
            paragraph = New NParagraph()
            paragraph.Inlines.Add(New NFieldInline(New NMailMergeSourceFieldValue("BirthDate")))
            birthDateShape.GetTextBlock().Content.Blocks.Clear()
            birthDateShape.GetTextBlock().Content.Blocks.Add(paragraph)
            activePage.Items.Add(birthDateShape)

            ' Connect the shapes
            Dim connector As NRoutableConnector = New NRoutableConnector()
            connector.Text = "City"
            connector.TextBlock.BackgroundFill = New NColorFill(NColor.White)
            connector.GlueBeginToNearestPort(nameShape)
            connector.GlueEndToNearestPort(cityShape)
            activePage.Items.Add(connector)
            connector = New NRoutableConnector()
            connector.Text = "Birth Date"
            connector.TextBlock.BackgroundFill = New NColorFill(NColor.White)
            connector.GlueBeginToNearestPort(nameShape)
            connector.GlueEndToNearestPort(birthDateShape)
            activePage.Items.Add(connector)

            ' Load a mail merge data source from resource
            Dim stream As Stream = NResources.Instance.GetResourceStream("RSTR_Employees_csv")
            Dim dataSource As NMailMergeDataSource = NDataSourceFormat.Csv.LoadFromStream(stream, New NDataSourceLoadSettings(Nothing, Nothing, True))

            ' Set some field mappings
            Dim fieldMap As NMailMergeFieldMap = New NMailMergeFieldMap()
            fieldMap.Set(ENMailMergeDataField.CourtesyTitle, "TitleOfCourtesy")
            fieldMap.Set(ENMailMergeDataField.FirstName, "FirstName")
            fieldMap.Set(ENMailMergeDataField.LastName, "LastName")
            fieldMap.Set(ENMailMergeDataField.City, "City")

            ' Configure the drawing's mail merge
            drawing.MailMerge.DataSource = dataSource
        End Sub

#End Region

#Region "Fields"

        Private m_DrawingView As NDrawingView

#End Region

#Region "Schema"

        ''' <summary>
        ''' Schema associated with NMailMergeExample.
        ''' </summary>
        Public Shared ReadOnly NMailMergeExampleSchema As NSchema

#End Region
    End Class
End Namespace

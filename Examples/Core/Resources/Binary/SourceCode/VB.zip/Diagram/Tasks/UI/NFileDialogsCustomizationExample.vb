Imports Nevron.Nov.Diagram
Imports Nevron.Nov.Diagram.DrawingCommands
Imports Nevron.Nov.Diagram.Formats
Imports Nevron.Nov.Diagram.Shapes
Imports Nevron.Nov.Dom
Imports Nevron.Nov.Graphics
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.Diagram
    Public Class NFileDialogsCustomizationExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' Default constructor.
        ''' </summary>
        Public Sub New()
        End Sub

        ''' <summary>
        ''' Static constructor.
        ''' </summary>
        Shared Sub New()
            NFileDialogsCustomizationExampleSchema = NSchema.Create(GetType(NFileDialogsCustomizationExample), NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            ' Create a simple drawing
            Dim drawingViewWithRibbon As NDrawingViewWithRibbon = New NDrawingViewWithRibbon()
            m_DrawingView = drawingViewWithRibbon.View

            m_DrawingView.Document.HistoryService.Pause()
            Try
                InitDiagram(m_DrawingView.Document)
            Finally
                m_DrawingView.Document.HistoryService.Resume()
            End Try

            ' Replace the "Open" and "Save As" command actions with the custom ones
            m_DrawingView.Commander.ReplaceCommandAction(New CustomOpenCommandAction())
            m_DrawingView.Commander.ReplaceCommandAction(New CustomSaveAsCommandAction())

            Return drawingViewWithRibbon
        End Function
        Protected Overrides Function CreateExampleControls() As NWidget
            Return Nothing
        End Function
        Protected Overrides Function GetExampleDescription() As String
            Return "<p>This example demonstrates how to customize the NOV Diagram Open and Save As file dialogs.</p>"
        End Function

        Private Sub InitDiagram(ByVal drawingDocument As NDrawingDocument)
            Dim drawing = drawingDocument.Content
            Dim activePage = drawing.ActivePage

            drawing.ScreenVisibility.ShowGrid = False
            drawing.ScreenVisibility.ShowPorts = False

            Dim basicShapes As NBasicShapeFactory = New NBasicShapeFactory()
            Dim connectorShapes As NConnectorShapeFactory = New NConnectorShapeFactory()
            Dim flowchartShapes = NLibrary.FlowchartShapes

            Dim nonPrintableShape = basicShapes.CreateShape(ENBasicShape.Rectangle)
            nonPrintableShape.Text = "Non printable shape"
            nonPrintableShape.AllowPrint = False
            nonPrintableShape.Geometry.Fill = New NColorFill(NColor.Tomato)
            nonPrintableShape.SetBounds(50, 50, 150, 50)
            activePage.Items.Add(nonPrintableShape)

            Dim isLifeGood = flowchartShapes.CreateShape(ENFlowchartingShape.Decision)
            isLifeGood.Text = "Is Life Good?"
            isLifeGood.SetBounds(300, 50, 150, 100)
            isLifeGood.Geometry.Fill = New NColorFill(NColor.LightSkyBlue)
            activePage.Items.Add(isLifeGood)

            Dim goodShape = flowchartShapes.CreateShape(ENFlowchartingShape.Termination)
            goodShape.Text = "Good"
            goodShape.SetBounds(200, 200, 100, 100)
            goodShape.Geometry.Fill = New NColorFill(NColor.Gold)
            activePage.Items.Add(goodShape)

            Dim changeSomething = flowchartShapes.CreateShape(ENFlowchartingShape.Process)
            changeSomething.Text = "Change Something"
            changeSomething.Geometry.Fill = New NColorFill(NColor.Thistle)
            changeSomething.SetBounds(450, 200, 100, 100)
            activePage.Items.Add(changeSomething)

            Dim yesConnector = connectorShapes.CreateShape(ENConnectorShape.RoutableConnector)
            yesConnector.Text = "Yes"
            yesConnector.GlueBeginToPort(isLifeGood.GetPortByName("Left"))
            yesConnector.GlueEndToPort(goodShape.GetPortByName("Top"))
            activePage.Items.Add(yesConnector)

            Dim noConnector = connectorShapes.CreateShape(ENConnectorShape.RoutableConnector)
            noConnector.Text = "No"
            noConnector.GlueBeginToPort(isLifeGood.GetPortByName("Right"))
            noConnector.GlueEndToPort(changeSomething.GetPortByName("Top"))
            activePage.Items.Add(noConnector)

            Dim gobackConnector = connectorShapes.CreateShape(ENConnectorShape.RoutableConnector)
            gobackConnector.GlueBeginToPort(changeSomething.GetPortByName("Right"))
            gobackConnector.GlueEndToPort(isLifeGood.GetPortByName("Top"))
            activePage.Items.Add(gobackConnector)
        End Sub

#End Region

#Region "Fields"

        Private m_DrawingView As NDrawingView

#End Region

#Region "Schema"

        ''' <summary>
        ''' Schema associated with NFileDialogsCustomizationExample.
        ''' </summary>
        Public Shared ReadOnly NFileDialogsCustomizationExampleSchema As NSchema

#End Region

#Region "Nested Types"

        Private Class CustomOpenCommandAction
            Inherits NOpenCommandAction
            Public Sub New()
            End Sub
            Shared Sub New()
                CustomOpenCommandActionSchema = NSchema.Create(GetType(CustomOpenCommandAction), NOpenCommandActionSchema)
            End Sub

            Protected Overrides Function GetFormats() As NDrawingFormat()
                Return New NDrawingFormat() {NDrawingFormat.Visio, NDrawingFormat.VectorAutoCadDxf}
            End Function

            Public Shared ReadOnly CustomOpenCommandActionSchema As NSchema
        End Class

        Private Class CustomSaveAsCommandAction
            Inherits NSaveAsCommandAction
            Public Sub New()
            End Sub
            Shared Sub New()
                CustomSaveAsCommandActionSchema = NSchema.Create(GetType(CustomSaveAsCommandAction), NSaveAsCommandActionSchema)
            End Sub

            Protected Overrides Function GetFormats() As NDrawingFormat()
                Return New NDrawingFormat() {NDrawingFormat.Visio, NDrawingFormat.VectorAutoCadDxf}
            End Function

            Public Shared ReadOnly CustomSaveAsCommandActionSchema As NSchema
        End Class

#End Region
    End Class
End Namespace

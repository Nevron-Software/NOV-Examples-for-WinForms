Imports Nevron.Nov.Diagram
Imports Nevron.Nov.Diagram.Themes
Imports Nevron.Nov.Dom
Imports Nevron.Nov.Graphics
Imports Nevron.Nov.Layout
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.Diagram
    Public Class NCustomLibrariesExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' Default constructor.
        ''' </summary>
        Public Sub New()
        End Sub

        ''' <summary>
        ''' Static constructor.
        ''' </summary>
        Shared Sub New()
            NCustomLibrariesExampleSchema = NSchema.Create(GetType(NCustomLibrariesExample), NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            ' Create a drawing view
            Dim drawingView As NDrawingView = New NDrawingView()

            ' Create a library view
            m_LibraryView = New NLibraryView()

            ' Create a custom library in the library view
            m_LibraryView.Document = CreateLibraryDocument()

            ' Associate the drawing view with the library view to make
            ' the drawing theme update the appearance of shapes in the library
            m_LibraryView.DrawingView = drawingView

            ' Place the library view and the drawing view in a splitter
            Dim splitter As NSplitter = New NSplitter(m_LibraryView, drawingView, ENSplitterSplitMode.OffsetFromNearSide, 275)

            ' Create a diagram ribbon
            Dim builder As NDiagramRibbonBuilder = New NDiagramRibbonBuilder()
            Return builder.CreateUI(splitter, drawingView)
        End Function
        Protected Overrides Function CreateExampleControls() As NWidget
            Dim openLibraryButton = NButton.CreateImageAndText(NResources.Image_Library_LibraryOpen_png, "Open Library...")
            openLibraryButton.HorizontalPlacement = ENHorizontalPlacement.Left
            openLibraryButton.VerticalPlacement = ENVerticalPlacement.Top
            openLibraryButton.Click += AddressOf OnOpenLibraryButtonClick
            Return openLibraryButton
        End Function
        Protected Overrides Function GetExampleDescription() As String
            Return "
<p>This example shows how to create various NOV Diagram library items and place them in a library.</p>
<p>If you want to open a NOV Diagram library file or a Visio Stencil, use the <b>Open Library</b> button on the right.</p>" End Function

#End Region

#Region "Event Handlers"

        Private Sub OnOpenLibraryButtonClick(ByVal arg As NEventArgs)
            m_LibraryView.OpenFileAsync()
        End Sub

#End Region

#Region "Implementation"

        Private Function CreateLibraryDocument() As NLibraryDocument
            Dim libraryDocument As NLibraryDocument = New NLibraryDocument()
            Dim library = libraryDocument.Content

            Dim shapeBounds As NRectangle = New NRectangle(0, 0, 150, 100)

            ' 1. Rectangle shape library item
            Dim rectangleShape As NShape = New NShape()
            rectangleShape.SetBounds(shapeBounds)
            rectangleShape.Geometry.AddRelative(New NDrawRectangle(0, 0, 1, 1))
            library.Items.Add(New NLibraryItem(rectangleShape, "Rectangle Shape", "This is a rectangle shape"))

            ' 2. Image shape library item
            Dim imageShape As NShape = New NShape()
            imageShape.SetBounds(0, 0, 128, 128)
            imageShape.ImageBlock.Image = NResources.Image__256x256_FemaleIcon_jpg
            library.Items.Add(New NLibraryItem(imageShape, "Image Shape", "This is a shape with an image"))

            ' 3. Shape filled with a hatch
            Dim hatchShape As NShape = New NShape()
            hatchShape.SetBounds(shapeBounds)
            hatchShape.Geometry.AddRelative(New NDrawRectangle(0, 0, 1, 1))
            hatchShape.Geometry.Fill = New NHatchFill(ENHatchStyle.DiagonalCross, NColor.Black, NColor.White)
            hatchShape.Geometry.Stroke = New NStroke(NColor.Black)
            library.Items.Add(New NLibraryItem(hatchShape, "Hatch Shape", "Shape filled with a theme independent hatch"))

            ' 4. Shape filled with a theme based hatch
            Dim themeShape As NShape = New NShape()
            themeShape.SetBounds(shapeBounds)
            themeShape.Geometry.AddRelative(New NDrawRectangle(0, 0, 1, 1))

            ' FIX: Remove this line when serialization is fixed
            themeShape.Tag = New NLineSegment(0, 0, 100, 100)

            ' Make color1 a theme variant color
            Dim theme = NDrawingTheme.MyDrawNature
            Dim color1 = theme.ColorPalette.Variants(0)(0)
            color1.Tag = New NThemeVariantColorInfo(0)

            ' Make color2 a theme palette color
            Dim color2 As NColor = theme.ColorPalette.Light1
            color2.Tag = New NThemePaletteColorInfo(ENThemeColorName.Light1, 0)

            themeShape.Geometry.Fill = New NHatchFill(ENHatchStyle.DiagonalCross, color1, color2)
            library.Items.Add(New NLibraryItem(themeShape, "Theme Based Shape", "Shape filled with a theme dependent hatch"))

            Return libraryDocument
        End Function

#End Region

#Region "Fields"

        Private m_LibraryView As NLibraryView

#End Region

#Region "Schema"

        ''' <summary>
        ''' Schema associated with NLibrariesExample.
        ''' </summary>
        Public Shared ReadOnly NCustomLibrariesExampleSchema As NSchema

#End Region
    End Class
End Namespace

Imports Nevron.Nov.Diagram
Imports Nevron.Nov.Diagram.Shapes
Imports Nevron.Nov.Dom
Imports Nevron.Nov.Layout
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.Diagram
    Public Class NRibbonAndCommandBarsExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' Default constructor.
        ''' </summary>
        Public Sub New()
        End Sub

        ''' <summary>
        ''' Static constructor.
        ''' </summary>
        Shared Sub New()
            NRibbonAndCommandBarsExampleSchema = NSchema.Create(GetType(NRibbonAndCommandBarsExample), NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            ' Create a simple drawing
            m_DrawingView = New NDrawingView()

            m_DrawingView.Document.HistoryService.Pause()
            Try
                InitDiagram(m_DrawingView.Document)
            Finally
                m_DrawingView.Document.HistoryService.Resume()
            End Try

            ' Create and execute a ribbon UI builder
            m_RibbonBuilder = New NDiagramRibbonBuilder()
            Return m_RibbonBuilder.CreateUI(m_DrawingView)
        End Function
        Protected Overrides Function CreateExampleControls() As NWidget
            ' Switch UI button
            Dim switchUIButton As NButton = New NButton(SwitchToCommandBars)
            switchUIButton.VerticalPlacement = ENVerticalPlacement.Top
            switchUIButton.Click += AddressOf OnSwitchUIButtonClick

            Return switchUIButton
        End Function
        Protected Overrides Function GetExampleDescription() As String
            Return "<p>This example demonstrates how to add commanding interface to the NOV Diagram and how to switch between ribbon and command bars.</p>"
        End Function

        Private Sub InitDiagram(ByVal drawingDocument As NDrawingDocument)
            Dim shape As NShape = New NBasicShapeFactory().CreateShape(ENBasicShape.Rectangle)
            shape.SetBounds(100, 100, 150, 100)
            drawingDocument.Content.ActivePage.Items.Add(shape)
        End Sub

#End Region

#Region "Implementation"

        Private Sub SetUI(ByVal oldUiHolder As NCommandUIHolder, ByVal widget As NWidget)
            If TypeOf oldUiHolder.ParentNode Is NTabPage Then
                CType(oldUiHolder.ParentNode, NTabPage).Content = widget
            ElseIf TypeOf oldUiHolder.ParentNode Is NPairBox Then
                CType(oldUiHolder.ParentNode, NPairBox).Box1 = widget
            End If
        End Sub

#End Region

#Region "Event Handlers"

        Private Sub OnSwitchUIButtonClick(ByVal arg As NEventArgs)
            Dim switchUIButton = CType(arg.TargetNode, NButton)
            Dim label = CType(switchUIButton.Content, NLabel)

            ' Remove the drawing view from its parent
            Dim uiHolder As NCommandUIHolder = m_DrawingView.GetFirstAncestor(Of NCommandUIHolder)()
            m_DrawingView.ParentNode.RemoveChild(m_DrawingView)

            If Equals(label.Text, SwitchToRibbon) Then
                ' We are in "Command Bars" mode, so switch to "Ribbon"
                label.Text = SwitchToCommandBars

                ' Create the ribbon
                SetUI(uiHolder, m_RibbonBuilder.CreateUI(m_DrawingView))
            Else
                ' We are in "Ribbon" mode, so switch to "Command Bars"
                label.Text = SwitchToRibbon

                ' Create the command bars
                If m_CommandBarBuilder Is Nothing Then
                    m_CommandBarBuilder = New NDiagramCommandBarBuilder()
                End If

                SetUI(uiHolder, m_CommandBarBuilder.CreateUI(m_DrawingView))
            End If
        End Sub

#End Region

#Region "Fields"

        Private m_DrawingView As NDrawingView
        Private m_RibbonBuilder As NDiagramRibbonBuilder
        Private m_CommandBarBuilder As NDiagramCommandBarBuilder

#End Region

#Region "Schema"

        ''' <summary>
        ''' Schema associated with NRibbonAndCommandBarsSwitchingExample.
        ''' </summary>
        Public Shared ReadOnly NRibbonAndCommandBarsExampleSchema As NSchema

#End Region

#Region "Constants"

        Private Const SwitchToCommandBars As String = "Switch to Command Bars"
        Private Const SwitchToRibbon As String = "Switch to Ribbon"

#End Region
    End Class
End Namespace

Imports System

Imports Nevron.Nov.Chart
Imports Nevron.Nov.Chart.Tools
Imports Nevron.Nov.Dom
Imports Nevron.Nov.Graphics
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.Chart
    ''' <summary>
    ''' Rectangle Zoom Tool Example.
    ''' </summary>
    Public Class NZoomingAndScrollingExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' Default constructor
        ''' </summary>
        Public Sub New()

        End Sub
        ''' <summary>
        ''' Static constructor
        ''' </summary>
        Shared Sub New()
            NZoomingAndScrollingExampleSchema = NSchema.Create(GetType(NZoomingAndScrollingExample), NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            Dim chartViewWithCommandBars As NChartViewWithCommandBars = New NChartViewWithCommandBars()
            Dim chartView = chartViewWithCommandBars.View
            chartView.Surface.CreatePredefinedChart(ENPredefinedChartType.Cartesian)

            ' configure title
            chartView.Surface.Titles(0).Text = "Rectangle Zoom Tool"

            ' configure chart
            m_Chart = CType(chartView.Surface.Charts(0), NCartesianChart)

            m_Chart.SetPredefinedCartesianAxes(ENPredefinedCartesianAxis.XYLinear)

            ' setup X axis
            Dim scaleX As NLinearScale = New NLinearScale()
            scaleX.MajorGridLines = New NScaleGridLines()
            scaleX.MajorGridLines.Stroke.DashStyle = ENDashStyle.Dot
            m_Chart.Axes(ENCartesianAxis.PrimaryX).Scale = scaleX

            ' setup Y axis
            Dim scaleY As NLinearScale = New NLinearScale()
            scaleY.MajorGridLines = New NScaleGridLines()
            scaleY.MajorGridLines.Stroke.DashStyle = ENDashStyle.Dot
            m_Chart.Axes(ENCartesianAxis.PrimaryY).Scale = scaleY

            ' add a point series
            m_Point = New NPointSeries()
            m_Point.Name = "Point Series"
            m_Point.DataLabelStyle = New NDataLabelStyle(False)
            m_Point.Fill = New NColorFill(New NColor(NColor.DarkOrange, 160))
            m_Point.Size = 5
            m_Point.Shape = ENPointShape3D.Bar
            m_Point.UseXValues = True
            m_Chart.Series.Add(m_Point)

            ' add some sample data
            Dim dataPoints = m_Point.DataPoints

            Dim random As Random = New Random()

            For i = 0 To 999
                Dim u1 As Double = random.NextDouble()
                Dim u2 As Double = random.NextDouble()

                If u1 = 0 Then u1 += 0.0001

                If u2 = 0 Then u2 += 0.0001

                Dim z0 = Math.Sqrt(-2 * Math.Log(u1)) * Math.Cos(2 * Math.PI * u2)
                Dim z1 = Math.Sqrt(-2 * Math.Log(u1)) * Math.Sin(2 * Math.PI * u2)

                dataPoints.Add(New NPointDataPoint(z0, z1))
            Next

            m_Chart.Enabled = True
            Dim interactor As NInteractor = New NInteractor()

            m_RectangleZoomTool = New NRectangleZoomTool()
            interactor.Add(m_RectangleZoomTool)

            Dim dataPanTool As NDataPanTool = New NDataPanTool()
            dataPanTool.StartMouseButtonEvent = ENMouseButtonEvent.RightButtonDown
            dataPanTool.EndMouseButtonEvent = ENMouseButtonEvent.RightButtonUp
            interactor.Add(dataPanTool)

            m_Chart.Interactor = interactor

            chartView.Document.StyleSheets.ApplyTheme(New NChartTheme(ENChartPalette.Bright, ENChartPaletteTarget.Series))

            Return chartViewWithCommandBars
        End Function
        Protected Overrides Function CreateExampleControls() As NWidget
            Dim stack As NStackPanel = New NStackPanel()
            Dim group As NUniSizeBoxGroup = New NUniSizeBoxGroup(stack)

            Dim orientationComboBox As NComboBox = New NComboBox()
            orientationComboBox.FillFromEnum(Of ENCartesianChartOrientation)()
            orientationComboBox.SelectedIndex = m_Chart.Orientation
            orientationComboBox.SelectedIndexChanged += New [Function](Of NValueChangeEventArgs)(AddressOf OnOrientationComboBoxSelectedIndexChanged)
            stack.Add(NPairBox.Create("Orientation:", orientationComboBox))

            Dim snapToMajorTicksCheckBox As NCheckBox = New NCheckBox("Snap To Major Ticks")
            snapToMajorTicksCheckBox.CheckedChanged += AddressOf OnSnapToMajorTicksCheckBoxCheckedChanged
            stack.Add(snapToMajorTicksCheckBox)

            Dim invertScaleCheckBox As NCheckBox = New NCheckBox("Invert Scale")
            invertScaleCheckBox.CheckedChanged += AddressOf OnInvertScaleCheckBoxCheckedChanged
            stack.Add(invertScaleCheckBox)

            Dim showScrollbarsWhenZoomedCheckBox As NCheckBox = New NCheckBox("Show Scrollbars When Zoomed")
            showScrollbarsWhenZoomedCheckBox.Checked = True
            showScrollbarsWhenZoomedCheckBox.CheckedChanged += AddressOf OnShowScrollbarsWhenZoomedCheckBoxCheckedChanged
            stack.Add(showScrollbarsWhenZoomedCheckBox)

            Return group
        End Function
        Protected Overrides Function GetExampleDescription() As String
            Return "<p>This example demonstrates how to implement zooming and scrolling. Press the left mouse button over the chart and select an area.</p>"
        End Function

#End Region

#Region "Event Handlers"

        Private Sub OnSnapToMajorTicksCheckBoxCheckedChanged(ByVal arg As NValueChangeEventArgs)
            If CType(arg.TargetNode, NCheckBox).Checked Then
                m_RectangleZoomTool.HorizontalValueSnapper = New NAxisMajorTickSnapper()
                m_RectangleZoomTool.VerticalValueSnapper = New NAxisMajorTickSnapper()
            Else
                m_RectangleZoomTool.HorizontalValueSnapper = Nothing
                m_RectangleZoomTool.VerticalValueSnapper = Nothing
            End If
        End Sub

        Private Sub OnInvertScaleCheckBoxCheckedChanged(ByVal arg As NValueChangeEventArgs)
            For i = 0 To m_Chart.Axes.Count - 1
                m_Chart.Axes(i).Scale.Invert = CType(arg.TargetNode, NCheckBox).Checked
            Next
        End Sub

        Private Sub OnOrientationComboBoxSelectedIndexChanged(ByVal arg As NValueChangeEventArgs)
            m_Chart.Orientation = CType(CType(arg.TargetNode, NComboBox).SelectedIndex, ENCartesianChartOrientation)
        End Sub

        Private Sub OnShowScrollbarsWhenZoomedCheckBoxCheckedChanged(ByVal arg As NValueChangeEventArgs)
            Dim showScrollbars = CType(arg.TargetNode, NCheckBox).Checked

            m_Chart.Axes(ENCartesianAxis.PrimaryX).ShowScrollbarWhenZoomed = showScrollbars
            m_Chart.Axes(ENCartesianAxis.PrimaryY).ShowScrollbarWhenZoomed = showScrollbars
        End Sub


#End Region

#Region "Fields"

        Private m_Point As NPointSeries
        Private m_Chart As NCartesianChart

        Private m_RectangleZoomTool As NRectangleZoomTool

#End Region

#Region "Schema"

        Public Shared ReadOnly NZoomingAndScrollingExampleSchema As NSchema

#End Region
    End Class
End Namespace

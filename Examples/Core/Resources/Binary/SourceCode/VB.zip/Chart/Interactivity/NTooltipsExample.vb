Imports Nevron.Nov.Chart
Imports Nevron.Nov.Chart.Tools
Imports Nevron.Nov.Dom
Imports Nevron.Nov.Graphics
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.Chart
    ''' <summary>
    ''' Tooltip Example
    ''' </summary>
    Public Class NTooltipsExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' Default constructor
        ''' </summary>
        Public Sub New()
        End Sub
        ''' <summary>
        ''' Static constructor
        ''' </summary>
        Shared Sub New()
            NTooltipsExampleSchema = NSchema.Create(GetType(NTooltipsExample), NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            Dim chartViewWithCommandBars As NChartViewWithCommandBars = New NChartViewWithCommandBars()
            Dim chartView = chartViewWithCommandBars.View
            chartView.Surface.CreatePredefinedChart(ENPredefinedChartType.Pie)

            ' configure title
            chartView.Surface.Titles(0).Text = "Tooltips"

            ' configure chart
            m_PieChart = CType(chartView.Surface.Charts(0), NPieChart)
            m_PieChart.Enable3D = True
            m_PieChart.EnableInteractivity = True
            m_PieChart.Projection.SetPredefinedProjection(ENPredefinedProjection.PerspectiveElevated)
            m_PieChart.LightModel.SetPredefinedLightModel(ENPredefinedLightModel.Arena)
            m_PieChart.Interactor = New NInteractor(New NTrackballTool())

            m_PieSeries = New NPieSeries()
            m_PieChart.Series.Add(m_PieSeries)
            m_PieChart.DockSpiderLabelsToSides = True

            Dim dataLabelStyle As NDataLabelStyle = New NDataLabelStyle()
            dataLabelStyle.ArrowLength = 15
            dataLabelStyle.ArrowPointerLength = 0
            m_PieSeries.DataLabelStyle = dataLabelStyle

            m_PieSeries.LabelMode = ENPieLabelMode.Spider
            m_PieSeries.LegendView.Mode = ENSeriesLegendMode.DataPoints
            m_PieSeries.LegendView.Format = "<label> <percent>"

            m_PieSeries.DataPoints.Add(CreateDataPoint(24, "Cars"))
            m_PieSeries.DataPoints.Add(CreateDataPoint(18, "Airplanes"))
            m_PieSeries.DataPoints.Add(CreateDataPoint(32, "Trains"))
            m_PieSeries.DataPoints.Add(CreateDataPoint(23, "Ships"))
            m_PieSeries.DataPoints.Add(CreateDataPoint(19, "Buses"))

            ' detach airplanes
            m_PieSeries.DataPoints(1).DetachmentPercent = 10

            chartView.Document.StyleSheets.ApplyTheme(New NChartTheme(ENChartPalette.Bright, ENChartPaletteTarget.DataPoints))

            Return chartViewWithCommandBars
        End Function
        Protected Overrides Function CreateExampleControls() As NWidget
            Dim stack As NStackPanel = New NStackPanel()
            Dim group As NUniSizeBoxGroup = New NUniSizeBoxGroup(stack)

            Dim enable3DCheckBox As NCheckBox = New NCheckBox("Enable 3D")
            enable3DCheckBox.Checked = True
            enable3DCheckBox.CheckedChanged += AddressOf OnEnable3DCheckBoxCheckedChanged
            stack.Add(enable3DCheckBox)

            Dim beginAngleUpDown As NNumericUpDown = New NNumericUpDown()
            beginAngleUpDown.Value = m_PieChart.BeginAngle
            beginAngleUpDown.ValueChanged += AddressOf OnBeginAngleUpDownValueChanged
            stack.Add(NPairBox.Create("Begin Angle:", beginAngleUpDown))

            Dim sweepAngleUpDown As NNumericUpDown = New NNumericUpDown()
            sweepAngleUpDown.Value = m_PieChart.SweepAngle
            sweepAngleUpDown.Minimum = -360
            sweepAngleUpDown.Maximum = 360
            sweepAngleUpDown.ValueChanged += AddressOf OnSweepAngleUpDownValueChanged
            stack.Add(NPairBox.Create("Sweep Angle:", sweepAngleUpDown))

            Return group
        End Function
        Protected Overrides Function GetExampleDescription() As String
            Return "<p>This example demonstrates how to create tooltips attached to chart objects.</p>"
        End Function

#End Region

#Region "Implementation"

        Private Function CreateDataPoint(ByVal value As Double, ByVal text As String) As NPieDataPoint
            Dim pieDataPoint As NPieDataPoint = New NPieDataPoint(value, text)

            pieDataPoint.Tooltip = New NTooltip(text & " [" & value.ToString() & "]")

            Return pieDataPoint
        End Function

#End Region

#Region "Event Handlers"

        Private Sub OnBeginAngleUpDownValueChanged(ByVal arg As NValueChangeEventArgs)
            m_PieChart.BeginAngle = CType(arg.TargetNode, NNumericUpDown).Value
        End Sub

        Private Sub OnSweepAngleUpDownValueChanged(ByVal arg As NValueChangeEventArgs)
            m_PieChart.SweepAngle = CType(arg.TargetNode, NNumericUpDown).Value
        End Sub

        Private Sub OnPieLabelModeSelectedIndexChanged(ByVal arg As NValueChangeEventArgs)
            m_PieSeries.LabelMode = CType(CType(arg.TargetNode, NComboBox).SelectedIndex, ENPieLabelMode)
        End Sub

        Private Sub OnEnable3DCheckBoxCheckedChanged(ByVal arg As NValueChangeEventArgs)
            m_PieChart.Enable3D = CBool(arg.NewValue)
        End Sub

#End Region

#Region "Fields"

        Private m_PieSeries As NPieSeries
        Private m_PieChart As NPieChart

#End Region

#Region "Schema"

        Public Shared ReadOnly NTooltipsExampleSchema As NSchema

#End Region
    End Class
End Namespace

Imports System

Imports Nevron.Nov.Chart
Imports Nevron.Nov.Chart.Tools
Imports Nevron.Nov.Dom
Imports Nevron.Nov.Graphics
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.Chart
    ''' <summary>
    ''' Hit testing Example
    ''' </summary>
    Public Class NHitTestingExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' Default constructor
        ''' </summary>
        Public Sub New()

        End Sub
        ''' <summary>
        ''' Static constructor
        ''' </summary>
        Shared Sub New()
            NHitTestingExampleSchema = NSchema.Create(GetType(NHitTestingExample), NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            Dim chartViewWithCommandBars As NChartViewWithCommandBars = New NChartViewWithCommandBars()
            Dim chartView = chartViewWithCommandBars.View
            chartView.Surface.CreatePredefinedChart(ENPredefinedChartType.Cartesian)

            ' configure title
            chartView.Surface.Titles(0).Text = "Hit Testing"

            ' configure chart
            m_Chart = CType(chartView.Surface.Charts(0), NCartesianChart)

            m_Chart.SetPredefinedCartesianAxes(ENPredefinedCartesianAxis.XYLinear)

            ' setup X axis
            Dim scaleX As NLinearScale = New NLinearScale()
            scaleX.MajorGridLines = New NScaleGridLines()
            scaleX.MajorGridLines.Stroke.DashStyle = ENDashStyle.Dot
            m_Chart.Axes(ENCartesianAxis.PrimaryX).Scale = scaleX

            ' setup Y axis
            Dim scaleY As NLinearScale = New NLinearScale()
            scaleY.MajorGridLines = New NScaleGridLines()
            scaleY.MajorGridLines.Stroke.DashStyle = ENDashStyle.Dot
            m_Chart.Axes(ENCartesianAxis.PrimaryY).Scale = scaleY

            ' add a point series
            m_Point = New NPointSeries()
            m_Point.Name = "Point Series"
            m_Point.DataLabelStyle = New NDataLabelStyle(False)
            m_Point.Fill = New NColorFill(New NColor(NColor.DarkOrange, 160))
            m_Point.Size = 20
            m_Point.Shape = ENPointShape3D.Bar
            m_Point.UseXValues = True
            m_Chart.Series.Add(m_Point)

            ' add some sample data
            Dim dataPoints = m_Point.DataPoints

            Dim random As Random = New Random()

            For i = 0 To 9
                Dim u1 As Double = random.NextDouble()
                Dim u2 As Double = random.NextDouble()

                If u1 = 0 Then u1 += 0.0001

                If u2 = 0 Then u2 += 0.0001

                Dim z0 = Math.Sqrt(-2 * Math.Log(u1)) * Math.Cos(2 * Math.PI * u2)
                Dim z1 = Math.Sqrt(-2 * Math.Log(u1)) * Math.Sin(2 * Math.PI * u2)

                Dim dataPoint As NPointDataPoint = New NPointDataPoint(z0, z1)
                dataPoint.MouseDown += AddressOf OnDataPointMouseDown
                dataPoints.Add(dataPoint)
            Next

            m_Chart.Enabled = True
            Dim interactor As NInteractor = New NInteractor()

            m_AxisCursorsTool = New NAxisCursorTool()
            m_AxisCursorsTool.Enabled = True
            interactor.Add(m_AxisCursorsTool)
            m_Chart.Interactor = interactor

            chartView.Document.StyleSheets.ApplyTheme(New NChartTheme(ENChartPalette.Bright, ENChartPaletteTarget.Series))

            Return chartViewWithCommandBars
        End Function
        Protected Overrides Function CreateExampleControls() As NWidget
            Dim stack As NStackPanel = New NStackPanel()
            Dim group As NUniSizeBoxGroup = New NUniSizeBoxGroup(stack)

            Dim hitTestModeComboBox As NComboBox = New NComboBox()
            hitTestModeComboBox.FillFromEnum(Of ENHitTestMode)()
            hitTestModeComboBox.SelectedIndexChanged += AddressOf OnHitTestModeComboBoxSelectedIndexChanged
            hitTestModeComboBox.SelectedIndex = CInt(ENScaleOrientation.Auto)
            stack.Add(NPairBox.Create("Hit Test Mode:", hitTestModeComboBox))

            Dim orientationComboBox As NComboBox = New NComboBox()
            orientationComboBox.FillFromEnum(Of ENCartesianChartOrientation)()
            orientationComboBox.SelectedIndex = m_Chart.Orientation
            orientationComboBox.SelectedIndexChanged += New [Function](Of NValueChangeEventArgs)(AddressOf OnOrientationComboBoxSelectedIndexChanged)
            stack.Add(NPairBox.Create("Orientation:", orientationComboBox))

            Dim resetColorsButton As NButton = New NButton("Reset Colors")
            resetColorsButton.Click += AddressOf OnResetColorsButtonClick
            stack.Add(resetColorsButton)

            Return group
        End Function
        Protected Overrides Function GetExampleDescription() As String
            Return "<p>This example demonstrates how to implement chart element hit testing.</p>"
        End Function

#End Region

#Region "Event Handlers"

        Private Sub OnResetColorsButtonClick(ByVal arg As NEventArgs)
            Dim seriesCount = m_Chart.Series.Count
            For i = 0 To seriesCount - 1
                Dim series As NSeries = m_Chart.Series(i)

                Dim dataPointCount As Integer = series.GetDataPointsChild().GetChildrenCount()

                For j = 0 To dataPointCount - 1
                    Dim dataPoint As NDataPoint = CType(series.GetDataPointsChild().GetChildAt(j), NDataPoint)

                    dataPoint.ClearLocalValue(NDataPoint.FillProperty)
                    dataPoint.ClearLocalValue(NDataPoint.StrokeProperty)
                Next
            Next
        End Sub
        Private Sub OnHitTestModeComboBoxSelectedIndexChanged(ByVal arg As NValueChangeEventArgs)
            m_Chart.HitTestMode = CType(CType(arg.TargetNode, NComboBox).SelectedIndex, ENHitTestMode)
        End Sub
        Private Sub OnOrientationComboBoxSelectedIndexChanged(ByVal arg As NValueChangeEventArgs)
            m_Chart.Orientation = CType(CType(arg.TargetNode, NComboBox).SelectedIndex, ENCartesianChartOrientation)
        End Sub

        Public Shared Sub OnDataPointMouseDown(ByVal arg As NMouseButtonEventArgs)
            If TypeOf arg.TargetNode Is NDataPoint Then
                CType(arg.TargetNode, NDataPoint).Fill = New NColorFill(NColor.Blue)
                CType(arg.TargetNode, NDataPoint).Stroke = New NStroke(2, NColor.Blue)
            ElseIf TypeOf arg.TargetNode Is NSeries Then
                CType(arg.TargetNode, NSeries).Fill = New NColorFill(NColor.Blue)
            End If
        End Sub

#End Region

#Region "Fields"

        Private m_Point As NPointSeries
        Private m_Chart As NCartesianChart

        Private m_AxisCursorsTool As NAxisCursorTool

#End Region

#Region "Schema"

        Public Shared ReadOnly NHitTestingExampleSchema As NSchema

#End Region
    End Class
End Namespace

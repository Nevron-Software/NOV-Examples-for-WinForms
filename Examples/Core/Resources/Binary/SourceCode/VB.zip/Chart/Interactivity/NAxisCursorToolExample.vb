Imports System

Imports Nevron.Nov.Chart
Imports Nevron.Nov.Chart.Tools
Imports Nevron.Nov.Dom
Imports Nevron.Nov.Graphics
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.Chart
    ''' <summary>
    ''' Axis Cursor Tool Example.
    ''' </summary>
    Public Class NAxisCursorToolExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' Default constructor
        ''' </summary>
        Public Sub New()

        End Sub
        ''' <summary>
        ''' Static constructor
        ''' </summary>
        Shared Sub New()
            NAxisCursorToolExampleSchema = NSchema.Create(GetType(NAxisCursorToolExample), NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            Dim chartViewWithCommandBars As NChartViewWithCommandBars = New NChartViewWithCommandBars()
            Dim chartView = chartViewWithCommandBars.View
            chartView.Surface.CreatePredefinedChart(ENPredefinedChartType.Cartesian)

            ' configure title
            chartView.Surface.Titles(0).Text = "Axis Cursor Tool"

            ' configure chart
            m_Chart = CType(chartView.Surface.Charts(0), NCartesianChart)

            m_Chart.SetPredefinedCartesianAxes(ENPredefinedCartesianAxis.XYLinear)

            ' setup X axis
            Dim scaleX As NLinearScale = New NLinearScale()
            scaleX.MajorGridLines = New NScaleGridLines()
            scaleX.MajorGridLines.Stroke.DashStyle = ENDashStyle.Dot
            m_Chart.Axes(ENCartesianAxis.PrimaryX).Scale = scaleX

            ' setup Y axis
            Dim scaleY As NLinearScale = New NLinearScale()
            scaleY.MajorGridLines = New NScaleGridLines()
            scaleY.MajorGridLines.Stroke.DashStyle = ENDashStyle.Dot
            m_Chart.Axes(ENCartesianAxis.PrimaryY).Scale = scaleY

            ' add a point series
            m_Point = New NPointSeries()
            m_Point.Name = "Point Series"
            m_Point.DataLabelStyle = New NDataLabelStyle(False)
            m_Point.Fill = New NColorFill(New NColor(NColor.DarkOrange, 160))
            m_Point.Size = 5
            m_Point.Shape = ENPointShape3D.Bar
            m_Point.UseXValues = True
            m_Chart.Series.Add(m_Point)

            ' add some sample data
            Dim dataPoints = m_Point.DataPoints

            Dim random As Random = New Random()

            For i = 0 To 999
                Dim u1 As Double = random.NextDouble()
                Dim u2 As Double = random.NextDouble()

                If u1 = 0 Then u1 += 0.0001

                If u2 = 0 Then u2 += 0.0001

                Dim z0 = Math.Sqrt(-2 * Math.Log(u1)) * Math.Cos(2 * Math.PI * u2)
                Dim z1 = Math.Sqrt(-2 * Math.Log(u1)) * Math.Sin(2 * Math.PI * u2)

                dataPoints.Add(New NPointDataPoint(z0, z1))
            Next

            m_Chart.Enabled = True
            Dim interactor As NInteractor = New NInteractor()

            m_AxisCursorsTool = New NAxisCursorTool()
            m_AxisCursorsTool.Enabled = True
            Me.m_AxisCursorsTool.HorizontalValueChanged += AddressOf OnAxisCursorsToolHorizontalValueChanged
            Me.m_AxisCursorsTool.VerticalValueChanged += AddressOf OnAxisCursorsToolVerticalValueChanged

            interactor.Add(m_AxisCursorsTool)
            m_Chart.Interactor = interactor

            chartView.Document.StyleSheets.ApplyTheme(New NChartTheme(ENChartPalette.Bright, ENChartPaletteTarget.Series))

            Return chartViewWithCommandBars
        End Function
        Protected Overrides Function CreateExampleControls() As NWidget
            Dim stack As NStackPanel = New NStackPanel()
            Dim group As NUniSizeBoxGroup = New NUniSizeBoxGroup(stack)

            Dim orientationComboBox As NComboBox = New NComboBox()
            orientationComboBox.FillFromEnum(Of ENCartesianChartOrientation)()
            orientationComboBox.SelectedIndex = m_Chart.Orientation
            orientationComboBox.SelectedIndexChanged += New [Function](Of NValueChangeEventArgs)(AddressOf OnOrientationComboBoxSelectedIndexChanged)
            stack.Add(NPairBox.Create("Orientation:", orientationComboBox))

            Dim snapToMajorTicksCheckBox As NCheckBox = New NCheckBox("Snap To Major Ticks")
            snapToMajorTicksCheckBox.CheckedChanged += AddressOf OnSnapToMajorTicksCheckBoxCheckedChanged
            stack.Add(snapToMajorTicksCheckBox)

            Dim autoHideCheckBox As NCheckBox = New NCheckBox("Auto Hide")
            autoHideCheckBox.CheckedChanged += AddressOf OnAutoHideCheckBoxCheckedChanged
            stack.Add(autoHideCheckBox)

            Dim invertScaleCheckBox As NCheckBox = New NCheckBox("Invert Scale")
            invertScaleCheckBox.CheckedChanged += AddressOf OnInvertScaleCheckBoxCheckedChanged
            stack.Add(invertScaleCheckBox)

            m_HorizontalValueLabel = New NLabel()
            stack.Add(NPairBox.Create("Horizontal Value:", m_HorizontalValueLabel))

            m_VerticalValueLabel = New NLabel()
            stack.Add(NPairBox.Create("Vertical Value:", m_VerticalValueLabel))

            Return group
        End Function
        Protected Overrides Function GetExampleDescription() As String
            Return "<p>This example demonstrates how to use the axis cursors tool.</p>"
        End Function

#End Region

#Region "Event Handlers"

        Private Sub OnAutoHideCheckBoxCheckedChanged(ByVal arg As NValueChangeEventArgs)
        End Sub

        ''' <summary>
        ''' 
        ''' </summary>
        ''' <paramname="arg"></param>
        Private Sub OnSnapToMajorTicksCheckBoxCheckedChanged(ByVal arg As NValueChangeEventArgs)
            If CType(arg.TargetNode, NCheckBox).Checked Then
                m_AxisCursorsTool.HorizontalValueSnapper = New NAxisMajorTickSnapper()
                m_AxisCursorsTool.VerticalValueSnapper = New NAxisMajorTickSnapper()
            Else
                m_AxisCursorsTool.HorizontalValueSnapper = Nothing
                m_AxisCursorsTool.VerticalValueSnapper = Nothing
            End If
        End Sub

        Private Sub OnInvertScaleCheckBoxCheckedChanged(ByVal arg As NValueChangeEventArgs)
            For i = 0 To m_Chart.Axes.Count - 1
                m_Chart.Axes(i).Scale.Invert = CType(arg.TargetNode, NCheckBox).Checked
            Next
        End Sub

        Private Sub OnOrientationComboBoxSelectedIndexChanged(ByVal arg As NValueChangeEventArgs)
            m_Chart.Orientation = CType(CType(arg.TargetNode, NComboBox).SelectedIndex, ENCartesianChartOrientation)
        End Sub

        Private Sub OnAxisCursorsToolVerticalValueChanged(ByVal arg As NValueChangeEventArgs)
            Dim tool = CType(arg.TargetNode, NAxisCursorTool)

            If Double.IsNaN(tool.VerticalValue) Then
                m_VerticalValueLabel.Text = String.Empty
            Else
                m_VerticalValueLabel.Text = tool.VerticalValue.ToString()
            End If
        End Sub

        Private Sub OnAxisCursorsToolHorizontalValueChanged(ByVal arg As NValueChangeEventArgs)
            Dim tool = CType(arg.TargetNode, NAxisCursorTool)

            If Double.IsNaN(tool.HorizontalValue) Then
                m_HorizontalValueLabel.Text = String.Empty
            Else
                m_HorizontalValueLabel.Text = tool.HorizontalValue.ToString()
            End If
        End Sub

#End Region

#Region "Fields"

        Private m_Point As NPointSeries
        Private m_Chart As NCartesianChart

        Private m_AxisCursorsTool As NAxisCursorTool
        Private m_HorizontalValueLabel As NLabel
        Private m_VerticalValueLabel As NLabel

#End Region

#Region "Schema"

        Public Shared ReadOnly NAxisCursorToolExampleSchema As NSchema

#End Region
    End Class
End Namespace

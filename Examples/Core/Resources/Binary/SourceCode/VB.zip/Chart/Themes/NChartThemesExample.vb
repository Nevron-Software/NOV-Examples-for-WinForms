Imports System

Imports Nevron.Nov.Chart
Imports Nevron.Nov.Dom
Imports Nevron.Nov.Graphics
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.Chart
    ''' <summary>
    ''' Chart Themes Example
    ''' </summary>
    Public Class NChartThemesExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' Default constructor
        ''' </summary>
        Public Sub New()

        End Sub
        ''' <summary>
        ''' Static constructor
        ''' </summary>
        Shared Sub New()
            NChartThemesExampleSchema = NSchema.Create(GetType(NChartThemesExample), NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            Dim chartViewWithCommandBars As NChartViewWithCommandBars = New NChartViewWithCommandBars()
            m_ChartView = chartViewWithCommandBars.View
            m_ChartView.Surface.CreatePredefinedChart(ENPredefinedChartType.Cartesian)

            ' configure title
            m_ChartView.Surface.Titles(0).Text = "Chart Themes"

            ' configure chart
            Dim chart = CType(m_ChartView.Surface.Charts(0), NCartesianChart)

            ' add interlace stripe
            Dim linearScale As NLinearScale = TryCast(chart.Axes(ENCartesianAxis.PrimaryY).Scale, NLinearScale)
            Dim strip As NScaleStrip = New NScaleStrip(New NColorFill(ENNamedColor.Beige), Nothing, True, 0, 0, 1, 1)
            strip.Interlaced = True
            linearScale.Strips.Add(strip)

            ' add a bar series
            Dim random As Random = New Random()
            For i = 0 To 5
                Dim bar As NBarSeries = New NBarSeries()
                bar.Name = "Bar" & i.ToString()
                bar.MultiBarMode = ENMultiBarMode.Clustered
                bar.DataLabelStyle = New NDataLabelStyle(False)
                bar.ValueFormatter = New NNumericValueFormatter("0.###")
                chart.Series.Add(bar)

                For j = 0 To 5
                    bar.DataPoints.Add(New NBarDataPoint(random.Next(10, 100)))
                Next
            Next

            m_ChartView.Document.StyleSheets.ApplyTheme(New NChartTheme(DefaultChartPalette, ENChartPaletteTarget.Series))

            Return chartViewWithCommandBars
        End Function
        Protected Overrides Function CreateExampleControls() As NWidget
            Dim stack As NStackPanel = New NStackPanel()

            m_ChartPaletteComboBox = New NComboBox()
            m_ChartPaletteComboBox.FillFromEnum(Of ENChartPalette)()
            Me.m_ChartPaletteComboBox.SelectedIndexChanged += AddressOf OnChartPaletteComboBoxSelectedIndexChanged
            stack.Add(NPairBox.Create("Palette:", m_ChartPaletteComboBox))

            m_ChartPaletteTargetComboBox = New NComboBox()
            m_ChartPaletteTargetComboBox.FillFromEnum(Of ENChartPaletteTarget)()
            Me.m_ChartPaletteTargetComboBox.SelectedIndexChanged += AddressOf OnChartPaletteComboBoxSelectedIndexChanged
            stack.Add(NPairBox.Create("Target:", m_ChartPaletteTargetComboBox))

            m_ChartPaletteComboBox.SelectedIndex = CInt(DefaultChartPalette)
            m_ChartPaletteTargetComboBox.SelectedIndex = CInt(ENChartPaletteTarget.DataPoints)

            Return New NUniSizeBoxGroup(stack)
        End Function

        Protected Overrides Function GetExampleDescription() As String
            Return "<p>This example demonstrates how to apply different chart color themes.</p>"
        End Function

#End Region

#Region "Event Handlers"

        Private Sub OnChartPaletteComboBoxSelectedIndexChanged(ByVal arg As NValueChangeEventArgs)
            m_ChartView.Document.StyleSheets.ApplyTheme(New NChartTheme(CType(m_ChartPaletteComboBox.SelectedIndex, ENChartPalette), CType(m_ChartPaletteTargetComboBox.SelectedIndex, ENChartPaletteTarget)))
        End Sub

#End Region

#Region "Fields"

        Private m_ChartView As NChartView
        Private m_ChartPaletteComboBox As NComboBox
        Private m_ChartPaletteTargetComboBox As NComboBox

#End Region

#Region "Schema"

        Public Shared ReadOnly NChartThemesExampleSchema As NSchema

#End Region

#Region "Constants"

        Private Const DefaultChartPalette As ENChartPalette = ENChartPalette.Autumn

#End Region
    End Class
End Namespace

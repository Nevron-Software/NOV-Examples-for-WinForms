Imports System

Imports Nevron.Nov.Chart
Imports Nevron.Nov.Chart.Tools
Imports Nevron.Nov.Dom
Imports Nevron.Nov.Graphics
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.Chart
    ''' <summary>
    ''' Chart Aspect 3D example
    ''' </summary>
    Public Class NChartAspect3DExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' Default constructor
        ''' </summary>
        Public Sub New()

        End Sub
        ''' <summary>
        ''' Static constructor
        ''' </summary>
        Shared Sub New()
            NChartAspect3DExampleSchema = NSchema.Create(GetType(NChartAspect3DExample), NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            Dim chartViewWithCommandBars As NChartViewWithCommandBars = New NChartViewWithCommandBars()
            m_ChartView = chartViewWithCommandBars.View
            m_ChartView.Surface.CreatePredefinedChart(ENPredefinedChartType.Cartesian)

            ' configure title
            m_ChartView.Surface.Titles(0).Text = "Chart Aspect 3D"

            ' configure chart
            Dim chart = CType(m_ChartView.Surface.Charts(0), NCartesianChart)

            chart.Interactor = New NInteractor(New NTrackballTool())

            chart.Enable3D = True
            chart.ModelWidth = 50
            chart.ModelHeight = 50
            chart.ModelDepth = 50
            chart.FitMode = ENCartesianChartFitMode.Aspect
            chart.Walls(ENChartWall.Back).Width = 0.01F
            chart.Walls(ENChartWall.Bottom).Width = 0.01F
            chart.Walls(ENChartWall.Left).Width = 0.01F

            ' apply predefined projection and lighting
            chart.Projection.SetPredefinedProjection(ENPredefinedProjection.PerspectiveTilted)
            chart.LightModel.SetPredefinedLightModel(ENPredefinedLightModel.BrightCameraLight)

            ' add axis labels
            Dim ordinalScale As NOrdinalScale = TryCast(chart.Axes(ENCartesianAxis.Depth).Scale, NOrdinalScale)
            ordinalScale.Labels.TextProvider = New NOrdinalScaleLabelTextProvider(New String() {"Miami", "Chicago", "Los Angeles", "New York"})
            ordinalScale.Labels.Style.Angle = New NScaleLabelAngle(ENScaleLabelAngleMode.Scale, 0)

            ordinalScale = TryCast(chart.Axes(ENCartesianAxis.PrimaryX).Scale, NOrdinalScale)
            ordinalScale.MajorGridLines.SetShowAtWall(ENChartWall.Bottom, True)
            ordinalScale.MajorGridLines.SetShowAtWall(ENChartWall.Back, True)

            ' add interlace stripe to the Y axis
            Dim linearScale As NLinearScale = TryCast(chart.Axes(ENCartesianAxis.PrimaryY).Scale, NLinearScale)
            Dim strip As NScaleStrip = New NScaleStrip(New NColorFill(NColor.Beige), Nothing, True, 0, 0, 1, 1)
            strip.Interlaced = True
            strip.SetShowAtWall(ENChartWall.Back, True)
            strip.SetShowAtWall(ENChartWall.Left, True)
            linearScale.Strips.Add(strip)

            ' add the first bar
            Dim bar1 As NBarSeries = New NBarSeries()
            chart.Series.Add(bar1)
            bar1.MultiBarMode = ENMultiBarMode.Series
            bar1.Name = "Bar1"
            bar1.DataLabelStyle = New NDataLabelStyle(False)
            bar1.Stroke = New NStroke(NColor.FromRGB(210, 210, 255))

            ' add the second bar
            Dim bar2 As NBarSeries = New NBarSeries()
            chart.Series.Add(bar2)
            bar2.MultiBarMode = ENMultiBarMode.Series
            bar2.Name = "Bar2"
            bar2.DataLabelStyle = New NDataLabelStyle(False)
            bar2.Stroke = New NStroke(NColor.FromRGB(210, 255, 210))

            ' add the third bar
            Dim bar3 As NBarSeries = New NBarSeries()
            chart.Series.Add(bar3)
            bar3.MultiBarMode = ENMultiBarMode.Series
            bar3.Name = "Bar3"
            bar3.DataLabelStyle = New NDataLabelStyle(False)
            bar3.Stroke = New NStroke(NColor.FromRGB(255, 255, 210))

            ' add the second bar
            Dim bar4 As NBarSeries = New NBarSeries()
            chart.Series.Add(bar4)
            bar4.MultiBarMode = ENMultiBarMode.Series
            bar4.Name = "Bar4"
            bar4.DataLabelStyle = New NDataLabelStyle(False)
            bar4.Stroke = New NStroke(NColor.FromRGB(255, 210, 210))

            ' fill with random data
            Dim random As Random = New Random()
            For i = 0 To 6
                bar1.DataPoints.Add(New NBarDataPoint((random.Next() + 1.0) * 30 + 10))
                bar2.DataPoints.Add(New NBarDataPoint((random.Next() + 1.0) * 30 + 30))
                bar3.DataPoints.Add(New NBarDataPoint((random.Next() + 1.0) * 30 + 50))
                bar4.DataPoints.Add(New NBarDataPoint((random.Next() + 1.0) * 30 + 70))
            Next

            ' apply theme
            m_ChartView.Document.StyleSheets.ApplyTheme(New NChartTheme(ENChartPalette.Bright, ENChartPaletteTarget.Series))

            Return chartViewWithCommandBars
        End Function
        Protected Overrides Function CreateExampleControls() As NWidget
            Dim stack As NStackPanel = New NStackPanel()
            Dim boxGroup As NUniSizeBoxGroup = New NUniSizeBoxGroup(stack)

            Dim chart = CType(m_ChartView.Surface.Charts(0), NCartesianChart)

            Dim proportionXComboBox As NComboBox = CreateProportionComboBox()
            proportionXComboBox.SelectedIndexChanged += AddressOf OnProportionXComboBoxSelectedIndexChanged
            stack.Add(NPairBox.Create("Proportion X:", proportionXComboBox))

            Dim proportionYComboBox As NComboBox = CreateProportionComboBox()
            proportionYComboBox.SelectedIndexChanged += AddressOf OnProportionYComboBoxSelectedIndexChanged
            stack.Add(NPairBox.Create("Proportion Y:", proportionYComboBox))

            Dim proportionZComboBox As NComboBox = CreateProportionComboBox()
            proportionZComboBox.SelectedIndexChanged += AddressOf OnProportionZComboBoxSelectedIndexChanged
            stack.Add(NPairBox.Create("Proportion Z:", proportionZComboBox))

            Return boxGroup
        End Function

        Protected Overrides Function GetExampleDescription() As String
            Return "<p>This example demonstrates how change the chart aspect ratio in 2D.</p>"
        End Function

#End Region

#Region "Implementation"

        Private Sub NormalizeProportions()
            Dim chart = CType(m_ChartView.Surface.Charts(0), NCartesianChart)
            Dim max = Math.Max(Math.Max(chart.ModelWidth, chart.ModelHeight), chart.ModelDepth)

            Dim scale = 50 / max

            chart.ModelWidth *= scale
            chart.ModelHeight *= scale
            chart.ModelDepth *= scale
        End Sub

        Private Function CreateProportionComboBox() As NComboBox
            Dim comboBox As NComboBox = New NComboBox()

            For i = 0 To 4
                comboBox.Items.Add(New NComboBoxItem((i + 1).ToString()))
            Next

            comboBox.SelectedIndex = 0

            Return comboBox
        End Function

#End Region

#Region "Event Handlers"

        Private Sub OnProportionXComboBoxSelectedIndexChanged(ByVal arg As NValueChangeEventArgs)
            Dim chart = CType(m_ChartView.Surface.Charts(0), NCartesianChart)
            chart.ModelWidth = CInt(arg.NewValue) + 1
            NormalizeProportions()
        End Sub

        Private Sub OnProportionYComboBoxSelectedIndexChanged(ByVal arg As NValueChangeEventArgs)
            Dim chart = CType(m_ChartView.Surface.Charts(0), NCartesianChart)
            chart.ModelHeight = CInt(arg.NewValue) + 1
            NormalizeProportions()
        End Sub

        Private Sub OnProportionZComboBoxSelectedIndexChanged(ByVal arg As NValueChangeEventArgs)
            Dim chart = CType(m_ChartView.Surface.Charts(0), NCartesianChart)
            chart.ModelDepth = CInt(arg.NewValue) + 1
            NormalizeProportions()
        End Sub

#End Region

#Region "Fields"

        Private m_ChartView As NChartView

#End Region

#Region "Schema"

        Public Shared ReadOnly NChartAspect3DExampleSchema As NSchema

#End Region
    End Class
End Namespace

Imports System
Imports Nevron.Nov.Chart
Imports Nevron.Nov.Dom
Imports Nevron.Nov.Graphics
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.Chart
    ''' <summary>
    ''' Chart orientation example
    ''' </summary>
    Public Class NChartOrientationExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' Default constructor
        ''' </summary>
        Public Sub New()
        End Sub
        ''' <summary>
        ''' Static constructor
        ''' </summary>
        Shared Sub New()
            NChartOrientationExampleSchema = NSchema.Create(GetType(NChartOrientationExample), NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            Dim chartView As NChartView = CreateCartesianChartView()

            ' configure title
            chartView.Surface.Titles(0).Text = "Chart Orientation"

            ' configure chart
            m_Chart = CType(chartView.Surface.Charts(0), NCartesianChart)
            m_Chart.Orientation = ENCartesianChartOrientation.LeftToRight
            m_Chart.SetPredefinedCartesianAxes(ENPredefinedCartesianAxis.XOrdinalYLinear)

            ' add interlace stripe
            Dim linearScale As NLinearScale = TryCast(m_Chart.Axes(ENCartesianAxis.PrimaryY).Scale, NLinearScale)
            Dim strip As NScaleStrip = New NScaleStrip(New NColorFill(ENNamedColor.Beige), Nothing, True, 0, 0, 1, 1)
            strip.Interlaced = True
            linearScale.Strips.Add(strip)

            ' add a bar series
            m_Bar1 = New NBarSeries()
            m_Bar1.MultiBarMode = ENMultiBarMode.Series
            m_Bar1.Name = "Bar 1"
            Dim dataLabelStyle As NDataLabelStyle = New NDataLabelStyle()
            dataLabelStyle.Format = "<value>"
            dataLabelStyle.Visible = True
            m_Bar1.DataLabelStyle = dataLabelStyle
            m_Bar1.LegendView.Mode = ENSeriesLegendMode.DataPoints
            m_Chart.Series.Add(m_Bar1)
            chartView.Document.StyleSheets.ApplyTheme(New NChartTheme(ENChartPalette.Bright, True))
            OnPositiveDataButtonClick(Nothing)
            Return chartView
        End Function

        Protected Overrides Function CreateExampleControls() As NWidget
            Dim stack As NStackPanel = New NStackPanel()
            Dim boxGroup As NUniSizeBoxGroup = New NUniSizeBoxGroup(stack)
            Dim orientationComboBox As NComboBox = New NComboBox()
            orientationComboBox.FillFromEnum(Of ENCartesianChartOrientation)()
            orientationComboBox.SelectedIndex = m_Chart.Orientation
            AddHandler orientationComboBox.SelectedIndexChanged, New [Function](Of NValueChangeEventArgs)(AddressOf OnOrientationComboBoxSelectedIndexChanged)
            stack.Add(NPairBox.Create("Orientation:", orientationComboBox))
            Dim positiveDataButton As NButton = New NButton("Positive Values")
            AddHandler positiveDataButton.Click, New [Function](Of NEventArgs)(AddressOf OnPositiveDataButtonClick)
            stack.Add(positiveDataButton)
            Dim positiveAndNegativeDataButton As NButton = New NButton("Positive and Negative Values")
            AddHandler positiveAndNegativeDataButton.Click, New [Function](Of NEventArgs)(AddressOf OnPositiveAndNegativeDataButtonClick)
            stack.Add(positiveAndNegativeDataButton)
            Return boxGroup
        End Function

        Protected Overrides Function GetExampleDescription() As String
            Return "<p>This example demonstrates how change the chart orientation. This feature allows you to display left to right and right to left charts</p>"
        End Function

#End Region

#Region "Event Handlers"

        Private Sub OnOrientationComboBoxSelectedIndexChanged(ByVal arg As NValueChangeEventArgs)
            m_Chart.Orientation = CType(CType(arg.TargetNode, NComboBox).SelectedIndex, ENCartesianChartOrientation)
        End Sub

        Private Sub OnPositiveAndNegativeDataButtonClick(ByVal arg As NEventArgs)
            m_Bar1.DataPoints.Clear()
            Dim random As Random = New Random()

            For i = 0 To 12 - 1
                m_Bar1.DataPoints.Add(New NBarDataPoint(random.Next(100) - 50))
            Next
        End Sub

        Private Sub OnPositiveDataButtonClick(ByVal arg As NEventArgs)
            m_Bar1.DataPoints.Clear()
            Dim random As Random = New Random()

            For i = 0 To 12 - 1
                m_Bar1.DataPoints.Add(New NBarDataPoint(random.Next(90) + 10))
            Next
        End Sub

#End Region

#Region "Fields"

        Private m_Chart As NCartesianChart
        Private m_Bar1 As NBarSeries

#End Region

#Region "Schema"

        Public Shared ReadOnly NChartOrientationExampleSchema As NSchema

#End Region

#Region "Static Methods"

        Private Shared Function CreateCartesianChartView() As NChartView
            Dim chartView As NChartView = New NChartView()
            chartView.Surface.CreatePredefinedChart(ENPredefinedChartType.Cartesian)
            Return chartView
        End Function

#End Region
    End Class
End Namespace

Imports System

Imports Nevron.Nov.Chart
Imports Nevron.Nov.Dom
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.Chart
    ''' <summary>
    ''' Chart Aspect 2D example
    ''' </summary>
    Public Class NChartAspect2DExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' Default constructor
        ''' </summary>
        Public Sub New()

        End Sub
        ''' <summary>
        ''' Static constructor
        ''' </summary>
        Shared Sub New()
            NChartAspect2DExampleSchema = NSchema.Create(GetType(NChartAspect2DExample), NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            Dim chartViewWithCommandBars As NChartViewWithCommandBars = New NChartViewWithCommandBars()
            m_ChartView = chartViewWithCommandBars.View
            m_ChartView.Surface.CreatePredefinedChart(ENPredefinedChartType.Cartesian)

            ' configure title
            m_ChartView.Surface.Titles(0).Text = "Chart Aspect 2D"

            ' configure chart
            Dim chart = CType(m_ChartView.Surface.Charts(0), NCartesianChart)

            chart.FitMode = ENCartesianChartFitMode.Aspect

            ' Add a x linear axis
            Dim primaryXAxis As NCartesianAxis = New NCartesianAxis()
            primaryXAxis.Anchor = New NDockCartesianAxisAnchor(ENCartesianAxisDockZone.Bottom)
            Dim primaryXScale As NLinearScale = New NLinearScale()
            primaryXScale.Title.Text = "X Scale Title"
            primaryXScale.Labels.Style.AlwaysInsideScale = True
            primaryXScale.Labels.Style.Angle = New NScaleLabelAngle(ENScaleLabelAngleMode.View, 90, False)
            primaryXAxis.Scale = primaryXScale
            chart.Axes.Add(primaryXAxis)

            ' Add a y linear axis
            Dim primaryYAxis As NCartesianAxis = New NCartesianAxis()
            primaryYAxis.Anchor = New NDockCartesianAxisAnchor(ENCartesianAxisDockZone.Left)
            Dim primaryYScale As NLinearScale = New NLinearScale()
            primaryYScale.Title.Text = "Y Scale Title"
            primaryYScale.Title.Angle = New NScaleLabelAngle(ENScaleLabelAngleMode.Scale, 0)
            primaryYScale.Labels.Style.AlwaysInsideScale = True

            primaryYAxis.Scale = primaryYScale
            chart.Axes.Add(primaryYAxis)

            ' Create the x / y crossed axes
            Dim secondaryXAxis As NCartesianAxis = New NCartesianAxis()
            Dim secondaryXScale As NLinearScale = New NLinearScale()

            secondaryXScale.Labels.Visible = False
            secondaryXAxis.Scale = secondaryXScale
            chart.Axes.Add(secondaryXAxis)

            Dim secondaryYAxis As NCartesianAxis = New NCartesianAxis()
            Dim secondaryYScale As NLinearScale = New NLinearScale()
            secondaryYScale.Labels.Visible = False
            secondaryYAxis.Scale = secondaryYScale
            chart.Axes.Add(secondaryYAxis)

            ' cross them
            Dim secondaryXAxisCrossing As NAxisCrossing = New NValueAxisCrossing(secondaryYAxis, 0)
            Dim secondaryXAxisAnchor As NCrossCartesianAxisAnchor = New NCrossCartesianAxisAnchor(ENCartesianAxisOrientation.Horizontal, ENScaleOrientation.Right, 0, 100)
            secondaryXAxisAnchor.YAxisCrossing = secondaryXAxisCrossing

            secondaryXAxis.Anchor = secondaryXAxisAnchor

            Dim secondaryYAxisCrossing As NAxisCrossing = New NValueAxisCrossing(secondaryXAxis, 0)
            Dim secondaryYAxisAnchor As NCrossCartesianAxisAnchor = New NCrossCartesianAxisAnchor(ENCartesianAxisOrientation.Vertical, ENScaleOrientation.Right, 0, 100)
            secondaryYAxisAnchor.XAxisCrossing = secondaryYAxisCrossing

            secondaryYAxis.Anchor = secondaryYAxisAnchor

            ' add some dummy data
            Dim point As NPointSeries = New NPointSeries()
            chart.Series.Add(point)

            Dim dataLabelStyle As NDataLabelStyle = New NDataLabelStyle()
            dataLabelStyle.Visible = False
            point.DataLabelStyle = dataLabelStyle

            point.UseXValues = True
            point.Size = 2

            ' add some random data in the range [-100, 100]
            Dim rand As Random = New Random()

            For i = 0 To 2999
                Dim x As Double = rand.Next(190) - 95
                Dim y As Double = rand.Next(190) - 95
                point.DataPoints.Add(New NPointDataPoint(x, y))
            Next

            m_ChartView.Document.StyleSheets.ApplyTheme(New NChartTheme(ENChartPalette.Bright, ENChartPaletteTarget.Series))

            Return chartViewWithCommandBars
        End Function
        Protected Overrides Function CreateExampleControls() As NWidget
            Dim stack As NStackPanel = New NStackPanel()
            Dim boxGroup As NUniSizeBoxGroup = New NUniSizeBoxGroup(stack)

            Dim chart = CType(m_ChartView.Surface.Charts(0), NCartesianChart)

            Dim chartFitMode As NComboBox = New NComboBox()
            chartFitMode.FillFromEnum(Of ENCartesianChartFitMode)()
            chartFitMode.SelectedIndex = chart.FitMode
            chartFitMode.SelectedIndexChanged += New [Function](Of NValueChangeEventArgs)(AddressOf OnChartFitModeSelectedIndexChanged)
            stack.Add(NPairBox.Create("Fit Mode:", chartFitMode))

            m_ProportionXComboBox = CreateProportionComboBox()
            m_ProportionXComboBox.SelectedIndexChanged += New [Function](Of NValueChangeEventArgs)(AddressOf OnProportionComboBoxSelectedIndexChanged)
            stack.Add(NPairBox.Create("X:", m_ProportionXComboBox))

            m_ProportionYComboBox = CreateProportionComboBox()
            m_ProportionYComboBox.SelectedIndexChanged += New [Function](Of NValueChangeEventArgs)(AddressOf OnProportionComboBoxSelectedIndexChanged)
            stack.Add(NPairBox.Create("Y:", m_ProportionYComboBox))

            Return boxGroup
        End Function
        Protected Overrides Function GetExampleDescription() As String
            Return "<p>This example demonstrates how change the chart aspect ratio in 2D.</p>"
        End Function

#End Region

#Region "Implementation"

        Private Function CreateProportionComboBox() As NComboBox
            Dim comboBox As NComboBox = New NComboBox()

            For i = 0 To 4
                comboBox.Items.Add(New NComboBoxItem((i + 1).ToString()))
            Next

            comboBox.SelectedIndex = 0

            Return comboBox
        End Function

#End Region

#Region "Event Handlers"

        Private Sub OnChartFitModeSelectedIndexChanged(ByVal arg As NValueChangeEventArgs)
            Dim chart = CType(m_ChartView.Surface.Charts(0), NCartesianChart)
            chart.FitMode = CType(CType(arg.TargetNode, NComboBox).SelectedIndex, ENCartesianChartFitMode)

            Select Case chart.FitMode
                Case ENCartesianChartFitMode.Aspect, ENCartesianChartFitMode.AspectWithAxes
                    m_ProportionXComboBox.Enabled = True
                    m_ProportionYComboBox.Enabled = True
                Case ENCartesianChartFitMode.Stretch
                    m_ProportionXComboBox.Enabled = False
                    m_ProportionYComboBox.Enabled = False
            End Select
        End Sub

        Private Sub OnProportionComboBoxSelectedIndexChanged(ByVal arg As NValueChangeEventArgs)
            Dim chart = CType(m_ChartView.Surface.Charts(0), NCartesianChart)

            chart.Aspect = (m_ProportionXComboBox.SelectedIndex + 1) / (m_ProportionYComboBox.SelectedIndex + 1)
        End Sub

#End Region

#Region "Fields"

        Private m_ChartView As NChartView
        Private m_ProportionXComboBox As NComboBox
        Private m_ProportionYComboBox As NComboBox

#End Region

#Region "Schema"

        Public Shared ReadOnly NChartAspect2DExampleSchema As NSchema

#End Region
    End Class
End Namespace

Imports System

Imports Nevron.Nov.Chart
Imports Nevron.Nov.Chart.Tools
Imports Nevron.Nov.Dom
Imports Nevron.Nov.Graphics
Imports Nevron.Nov.Layout
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.Chart
    ''' <summary>
    ''' The example shows how to align different chart areas
    ''' </summary>
    Public Class NAligningChartAreasExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' Default constructor
        ''' </summary>
        Public Sub New()

        End Sub
        ''' <summary>
        ''' Static constructor
        ''' </summary>
        Shared Sub New()
            NAligningChartAreasExampleSchema = NSchema.Create(GetType(NAligningChartAreasExample), NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            Dim chartViewWithCommandBars As NChartViewWithCommandBars = New NChartViewWithCommandBars()
            m_ChartView = chartViewWithCommandBars.View

            Dim dockPanel As NDockPanel = New NDockPanel()
            m_ChartView.Surface.Content = dockPanel

            Dim label As NLabel = New NLabel()
            label.Margins = New NMargins(10)
            label.Font = New NFont(NFontDescriptor.DefaultSansFamilyName, 12)
            label.TextFill = New NColorFill(NColor.Black)
            label.TextAlignment = ENContentAlignment.MiddleCenter
            label.Text = "Aligning Chart Areas"
            NDockLayout.SetDockArea(label, ENDockArea.Top)
            dockPanel.AddChild(label)

            ' configure title
            Dim stackPanel As NStackPanel = New NStackPanel()
            stackPanel.UniformHeights = ENUniformSize.Max
            stackPanel.FillMode = ENStackFillMode.Equal
            stackPanel.FitMode = ENStackFitMode.Equal
            NDockLayout.SetDockArea(stackPanel, ENDockArea.Center)
            dockPanel.AddChild(stackPanel)

            Dim stockPriceChart As NCartesianChart = New NCartesianChart()
            stockPriceChart.Tag = "Chart 1"

            stockPriceChart.SetPredefinedCartesianAxes(ENPredefinedCartesianAxis.XValueTimelineYLinear)
            stockPriceChart.FitMode = ENCartesianChartFitMode.Stretch
            stockPriceChart.Margins = New NMargins(10, 0, 10, 10)
            ConfigureInteractivity(stockPriceChart)
            stackPanel.AddChild(stockPriceChart)

            ' setup the stock series
            m_StockPrice = New NStockSeries()
            stockPriceChart.Series.Add(m_StockPrice)
            m_StockPrice.Name = "Price"
            m_StockPrice.LegendView.Mode = ENSeriesLegendMode.None
            m_StockPrice.DataLabelStyle = New NDataLabelStyle(False)
            m_StockPrice.CandleShape = ENCandleShape.Stick

            m_StockPrice.UpStroke = New NStroke(1, NColor.RoyalBlue)
            m_StockPrice.CandleWidth = 10
            m_StockPrice.UseXValues = True
            m_StockPrice.InflateMargins = False

            ' setup the volume chart
            Dim stockVolumeChart As NCartesianChart = New NCartesianChart()
            stockVolumeChart.Tag = "Chart 2"

            stockVolumeChart.SetPredefinedCartesianAxes(ENPredefinedCartesianAxis.XValueTimelineYLinear)
            stockVolumeChart.FitMode = ENCartesianChartFitMode.Stretch
            stockVolumeChart.Margins = New NMargins(10, 0, 10, 10)
            ConfigureInteractivity(stockVolumeChart)
            stackPanel.AddChild(stockVolumeChart)

            ' setup the stock volume series
            ' setup the volume series
            m_StockVolume = New NAreaSeries()
            stockVolumeChart.Series.Add(m_StockVolume)
            m_StockVolume.Name = "Volume"
            m_StockVolume.DataLabelStyle = New NDataLabelStyle(False)
            m_StockVolume.LegendView.Mode = ENSeriesLegendMode.None
            m_StockVolume.Fill = New NColorFill(NColor.YellowGreen)
            m_StockVolume.UseXValues = True

            ' make sure all axes are synchronized
            stockPriceChart.Axes(ENCartesianAxis.PrimaryX).SynchronizedAxes = New NDomArray(Of NNodeRef)(New NNodeRef(stockVolumeChart.Axes(ENCartesianAxis.PrimaryX)))
            stockVolumeChart.Axes(ENCartesianAxis.PrimaryX).SynchronizedAxes = New NDomArray(Of NNodeRef)(New NNodeRef(stockPriceChart.Axes(ENCartesianAxis.PrimaryX)))

            GenerateData()

            ' align the left parts of those charts
            Dim guideLines As NAlignmentGuidelineCollection = New NAlignmentGuidelineCollection()

            Dim guideLine As NAlignmentGuideline = New NAlignmentGuideline()
            guideLine.ContentSide = ENContentSide.Left
            guideLine.Targets = New NDomArray(Of NNodeRef)(New NNodeRef() {New NNodeRef(stockPriceChart), New NNodeRef(stockVolumeChart)})

            guideLines.Add(guideLine)

            m_ChartView.Surface.AlignmentGuidelines = guideLines

            m_ChartView.Document.StyleSheets.ApplyTheme(New NChartTheme(ENChartPalette.Bright, ENChartPaletteTarget.Series))

            Return chartViewWithCommandBars
        End Function
        Protected Overrides Function CreateExampleControls() As NWidget
            Dim stack As NStackPanel = New NStackPanel()
            Dim boxGroup As NUniSizeBoxGroup = New NUniSizeBoxGroup(stack)

            Return boxGroup
        End Function
        Protected Overrides Function GetExampleDescription() As String
            Return "<p>This example demonstrates how to align different chart areas.</p>"
        End Function

#End Region

#Region "Implementation"

        Private Sub ConfigureInteractivity(ByVal chart As NChart)
            Dim interactor As NInteractor = New NInteractor()

            Dim rectangleZoomTool As NRectangleZoomTool = New NRectangleZoomTool()
            rectangleZoomTool.VerticalValueSnapper = New NAxisRulerMinMaxSnapper()
            interactor.Add(rectangleZoomTool)

            Dim dataPanTool As NDataPanTool = New NDataPanTool()
            dataPanTool.StartMouseButtonEvent = ENMouseButtonEvent.RightButtonDown
            dataPanTool.EndMouseButtonEvent = ENMouseButtonEvent.RightButtonUp
            interactor.Add(dataPanTool)

            chart.Interactor = interactor
        End Sub
        Private Sub GenerateData()
            Dim open, high, low, close As Double

            m_StockPrice.DataPoints.Clear()
            m_StockVolume.DataPoints.Clear()
            Dim dt As Date = Date.Now - New TimeSpan(120, 0, 0, 0)
            Dim dPrevClose As Double = 100
            Dim dVolume As Double = 15
            Dim random As Random = New Random()

            For nIndex = 0 To 99
                open = dPrevClose

                If dPrevClose < 25 OrElse random.NextDouble() > 0.5 Then
                    ' upward price change
                    close = open + (2 + (random.NextDouble() * 20))
                    high = close + (random.NextDouble() * 10)
                    low = open - (random.NextDouble() * 10)
                Else
                    ' downward price change
                    close = open - (2 + (random.NextDouble() * 20))
                    high = open + (random.NextDouble() * 10)
                    low = close - (random.NextDouble() * 10)
                End If

                If low < 1 Then
                    low = 1
                End If

                While dt.DayOfWeek = DayOfWeek.Saturday OrElse dt.DayOfWeek = DayOfWeek.Sunday
                    dt = dt.AddDays(1)
                End While

                ' add stock / volume data
                m_StockPrice.DataPoints.Add(New NStockDataPoint(NDateTimeHelpers.ToOADate(dt), open, close, high, low))
                m_StockVolume.DataPoints.Add(New NAreaDataPoint(NDateTimeHelpers.ToOADate(dt), dVolume))

                ' move forward
                dVolume += 10 * (0.5 - random.NextDouble())
                If dVolume <= 0 Then dVolume += 15

                dt = dt.AddDays(1)
            Next
        End Sub

#End Region

#Region "Fields"

        Private m_ChartView As NChartView
        Private m_StockPrice As NStockSeries
        Private m_StockVolume As NAreaSeries

#End Region

#Region "Schema"

        Public Shared ReadOnly NAligningChartAreasExampleSchema As NSchema

#End Region
    End Class
End Namespace

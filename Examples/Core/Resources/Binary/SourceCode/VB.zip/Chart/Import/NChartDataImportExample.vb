Imports System
Imports System.Collections

Imports Nevron.Nov.Chart
Imports Nevron.Nov.Data
Imports Nevron.Nov.DataStructures
Imports Nevron.Nov.Dom
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.Chart
    ''' <summary>
    ''' Chart Data Import Example.
    ''' </summary>
    Public Class NChartDataImportExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' Default constructor
        ''' </summary>
        Public Sub New()

        End Sub
        ''' <summary>
        ''' Static constructor
        ''' </summary>
        Shared Sub New()
            NChartDataImportExampleSchema = NSchema.Create(GetType(NChartDataImportExample), NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            Dim chartViewWithCommandBars As NChartViewWithCommandBars = New NChartViewWithCommandBars()
            m_ChartView = chartViewWithCommandBars.View
            m_ChartView.Surface.CreatePredefinedChart(ENPredefinedChartType.Cartesian)

            ' configure title
            m_ChartView.Surface.Titles(0).Text = "Chart Data Import"

            ' use bright theme
            m_ChartView.Document.StyleSheets.ApplyTheme(New NChartTheme(ENChartPalette.Bright, ENChartPaletteTarget.DataPoints))

            ' import single data series
            OnImportSingleDataSeriesClick(Nothing)

            Return chartViewWithCommandBars
        End Function
        Protected Overrides Function CreateExampleControls() As NWidget
            Dim stack As NStackPanel = New NStackPanel()
            Dim group As NUniSizeBoxGroup = New NUniSizeBoxGroup(stack)

            Dim importSingleDataSeries As NButton = New NButton("Import Single Data Series")
            importSingleDataSeries.Click += AddressOf OnImportSingleDataSeriesClick
            stack.Add(importSingleDataSeries)

            Dim importMultipleDataSeriesFromEnumrables As NButton = New NButton("Import Multiple Data Series" & vbCrLf & "(from IEnumerables)")
            importMultipleDataSeriesFromEnumrables.Click += AddressOf OnImportMultipleDataSeriesFromEnumerablesClick
            stack.Add(importMultipleDataSeriesFromEnumrables)

            Dim importMultipleDataSeriesFromTable As NButton = New NButton("Import Multiple Data Series" & vbCrLf & "(from NDataTable)")
            importMultipleDataSeriesFromTable.Click += AddressOf OnImportMultipleDataSeriesFromTableClick
            stack.Add(importMultipleDataSeriesFromTable)

            If NDbConnection.IsTypeSupported(ENDbConnectionType.Odbc) Then
                Dim importMultipleDataSeriesFromDBReader As NButton = New NButton("Import Multiple Data Series" & vbCrLf & "(from NDbReader)")
                importMultipleDataSeriesFromDBReader.Click += AddressOf OnImportMultipleDataSeriesFromDBReaderClick
                stack.Add(importMultipleDataSeriesFromDBReader)
            End If

            Return group
        End Function
        Protected Overrides Function GetExampleDescription() As String
            Return "<p>This example demonstrates how import data from various data sources.</p>"
        End Function

#End Region

#Region "Implementation"

        Private Sub OnImportMultipleDataSeriesFromEnumerablesClick(ByVal arg As NEventArgs)
            ' clear chart
            ClearChart()

            ' get chart
            Dim chart = CType(m_ChartView.Surface.Charts(0), NCartesianChart)

            ' switch X axis in linear scale
            chart.Axes(ENCartesianAxis.PrimaryX).Scale = New NLinearScale()

            ' create a point series to show the imported values
            Dim pointSeries As NPointSeries = New NPointSeries()
            chart.Series.Add(pointSeries)
            pointSeries.ValueFormatter = New NNumericValueFormatter("0.00")
            pointSeries.DataLabelStyle = New NDataLabelStyle()
            pointSeries.DataLabelStyle.Visible = True
            pointSeries.DataLabelStyle.Format = "<label>"
            pointSeries.DataLabelStyle.VertAlign = ENVerticalAlignment.Bottom
            pointSeries.DataLabelStyle.ArrowLength = 30

            ' create random data series
            Const dataPointCount = 10

            Dim values As Double() = CreateRandomData(dataPointCount)
            Dim xvalues As Double() = CreateRandomData(dataPointCount)
            Dim labels = New String(values.Length - 1) {}
            For i = 0 To dataPointCount - 1
                labels(i) = "Label: " & (i + 1).ToString()
            Next

            ' import multiple data series
            pointSeries.DataPoints.SetDataSeries(New NKeyValuePair(Of IEnumerable, String)() {New NKeyValuePair(Of IEnumerable, String)(values, "Value"), New NKeyValuePair(Of IEnumerable, String)(xvalues, "X"), New NKeyValuePair(Of IEnumerable, String)(labels, "Label")})
        End Sub

        Private Sub OnImportMultipleDataSeriesFromTableClick(ByVal arg As NEventArgs)
            ' clear chart
            ClearChart()

            ' get chart
            Dim chart = CType(m_ChartView.Surface.Charts(0), NCartesianChart)

            ' switch X axis in linear scale
            chart.Axes(ENCartesianAxis.PrimaryX).Scale = New NLinearScale()

            ' create a line series to show the imported values
            Dim lineSeries As NLineSeries = New NLineSeries()
            chart.Series.Add(lineSeries)
            lineSeries.ValueFormatter = New NNumericValueFormatter("0.00")
            lineSeries.DataLabelStyle = New NDataLabelStyle()
            lineSeries.DataLabelStyle.Visible = True
            lineSeries.DataLabelStyle.Format = "<label>"
            lineSeries.DataLabelStyle.VertAlign = ENVerticalAlignment.Bottom
            lineSeries.DataLabelStyle.ArrowLength = 30

            ' create a table with random data
            Dim table As NMemoryDataTable = New NMemoryDataTable(New NFieldInfo("Y", GetType(Double)), New NFieldInfo("X", GetType(Double)), New NFieldInfo("Label", GetType(String)))

            Const dataPointCount = 10
            Dim rnd As Random = New Random()
            For i = 0 To dataPointCount - 1
                table.AddRow()
                table.SetValue(i, "Y", rnd.Next(0, 100))
                table.SetValue(i, "X", rnd.Next(0, 100))
                table.SetValue(i, "Label", "Label: " & i.ToString())
            Next

            ' import multiple data series
            lineSeries.DataPoints.SetDataSeries(table, New NKeyValuePair(Of String, String)() {New NKeyValuePair(Of String, String)("Y", "Value"), New NKeyValuePair(Of String, String)("X", "X"), New NKeyValuePair(Of String, String)("Label", "Label")})
        End Sub

        Private Sub OnImportMultipleDataSeriesFromDBReaderClick(ByVal arg As NEventArgs)
            Dim topLevelWindow As NTopLevelWindow = NApplication.CreateTopLevelWindow()
            topLevelWindow.Title = "Select DB Source"

            Dim stack As NStackPanel = New NStackPanel()

            ' connection string
            Dim connectionString As NTextBox = New NTextBox()
            connectionString.Text = "DSN=Xtreme"
            stack.Add(New NPairBox("Connection String:", connectionString))

            ' connection string
            Dim sqlQuery As NTextBox = New NTextBox()
            sqlQuery.Text = "SELECT * FROM SALES"
            stack.Add(New NPairBox("SQL Query:", sqlQuery))

            ' value column
            Dim valueColumn As NTextBox = New NTextBox()
            valueColumn.Text = "<value_field>"
            stack.Add(New NPairBox("Value Column:", valueColumn))

            ' label column
            Dim labelColumn As NTextBox = New NTextBox()
            labelColumn.Text = "<label_field>"
            stack.Add(New NPairBox("Label Column:", labelColumn))

            Dim buttonStrip As NButtonStrip = New NButtonStrip()
            buttonStrip.AddOKCancelButtons()
            stack.Add(buttonStrip)

            topLevelWindow.Content = stack
            topLevelWindow.Open()

            topLevelWindow.Closed += Sub(e)
                                         ' clear chart
                                         ClearChart()

                                         ' get chart
                                         Dim chart = CType(m_ChartView.Surface.Charts(0), NCartesianChart)

                                         ' switch X axis in linear scale
                                         chart.Axes(ENCartesianAxis.PrimaryX).Scale = New NOrdinalScale()

                                         ' create a point series to show the imported values
                                         Dim pointSeries As NPointSeries = New NPointSeries()
                                         chart.Series.Add(pointSeries)
                                         pointSeries.ValueFormatter = New NNumericValueFormatter("0.00")
                                         pointSeries.DataLabelStyle = New NDataLabelStyle()
                                         pointSeries.DataLabelStyle.Visible = True
                                         pointSeries.DataLabelStyle.Format = "<label>"
                                         pointSeries.DataLabelStyle.VertAlign = ENVerticalAlignment.Bottom
                                         pointSeries.DataLabelStyle.ArrowLength = 30

                                         ' created random data series
                                         Dim connection As NDbConnection = Nothing
                                         Try
                                             ' try open the connection
                                             connection = NDbConnection.Open(ENDbConnectionType.Odbc, connectionString.Text)
                                             Dim dataReader = connection.ExecuteReader("SELECT * FROM SALES")

                                             ' TODO - execute queries and commands
                                             ' import multiple data series
                                             Dim dataMappings As NList(Of NKeyValuePair(Of String, String)) = New NList(Of NKeyValuePair(Of String, String))()
                                             If Not String.IsNullOrEmpty(valueColumn.Text) Then
                                                 dataMappings.Add(New NKeyValuePair(Of String, String)(valueColumn.Text, "Value"))
                                             End If
                                             If Not String.IsNullOrEmpty(labelColumn.Text) Then
                                                 dataMappings.Add(New NKeyValuePair(Of String, String)(labelColumn.Text, "Label"))
                                             End If

                                             pointSeries.DataPoints.SetDataSeries(dataReader, dataMappings.ToArray())
                                         Catch ex As Exception
                                             ' TODO: report connection or execution error
                                             NMessageBox.Show(ex.Message, "Data Import Error")
                                         Finally
                                             ' close the connection
                                             If connection IsNot Nothing Then
                                                 connection.Close()
                                             End If
                                         End Try
                                     End Sub
        End Sub

        Private Sub OnImportSingleDataSeriesClick(ByVal arg As NEventArgs)
            ' clear chart
            ClearChart()

            ' get chart
            Dim chart = CType(m_ChartView.Surface.Charts(0), NCartesianChart)

            ' switch X axis in ordinal scale
            chart.Axes(ENCartesianAxis.PrimaryX).Scale = New NOrdinalScale()

            ' create a bar series to show the imported values
            Dim barSeries As NBarSeries = New NBarSeries()
            chart.Series.Add(barSeries)
            barSeries.ValueFormatter = New NNumericValueFormatter("0.00")

            ' import randomly created double[] 
            Dim values As Double() = CreateRandomData(10)
            barSeries.DataPoints.SetDataSeries(values, "Value")


        End Sub

        Private Sub ClearChart()
            Dim chart = CType(m_ChartView.Surface.Charts(0), NCartesianChart)
            chart.Series.Clear()
        End Sub

#End Region

#Region "Fields"

        Private m_ChartView As NChartView

#End Region

#Region "Schema"

        Public Shared ReadOnly NChartDataImportExampleSchema As NSchema

#End Region
    End Class
End Namespace

Imports Nevron.Nov.Chart
Imports Nevron.Nov.Data
Imports Nevron.Nov.Dom
Imports Nevron.Nov.Grid
Imports Nevron.Nov.Layout
Imports Nevron.Nov.UI
Imports System

Namespace Nevron.Nov.Examples.Chart
    ''' <summary>
    ''' Chart Data Binding Example
    ''' </summary>
    Public Class NChartDataBindingExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' Default constructor
        ''' </summary>
        Public Sub New()

        End Sub
        ''' <summary>
        ''' Static constructor
        ''' </summary>
        Shared Sub New()
            NChartDataBindingExampleSchema = NSchema.Create(GetType(NChartDataBindingExample), NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            ' create a dummy data source, which to share between the grid and the chart
            m_MemoryDataTable = New NMemoryDataTable(New NFieldInfo("Value", GetType(Double), False), New NFieldInfo("XValue", GetType(Double), False), New NFieldInfo("Label", GetType(String), False))

            Dim rnd As Random = New Random()
            For i = 0 To 14
                m_MemoryDataTable.AddRow(rnd.Next(0, 100), rnd.Next(0, 100), "Label: " & i.ToString())

            Next

            ' create cartesian chart view 
            Dim chartViewWithCommandBars As NChartViewWithCommandBars = New NChartViewWithCommandBars()
            Dim chartView = chartViewWithCommandBars.View
            chartView.Surface.CreatePredefinedChart(ENPredefinedChartType.Cartesian)

            ' get chart
            Dim chart = CType(chartView.Surface.Charts(0), NCartesianChart)

            ' switch X axis in linear scale
            chart.Axes(ENCartesianAxis.PrimaryX).Scale = New NLinearScale()

            ' create a point series to show the data source values
            Dim pointSeries As NPointSeries = New NPointSeries()
            chart.Series.Add(pointSeries)
            pointSeries.UseXValues = True
            pointSeries.ValueFormatter = New NNumericValueFormatter("0.00")
            pointSeries.DataLabelStyle = New NDataLabelStyle()
            pointSeries.DataLabelStyle.Visible = True
            pointSeries.DataLabelStyle.Format = "<label>"
            pointSeries.DataLabelStyle.VertAlign = ENVerticalAlignment.Bottom
            pointSeries.DataLabelStyle.ArrowLength = 30

            ' bind point series
            pointSeries.DataPoints.Bind(New NDataSource(m_MemoryDataTable), New NKeyValuePair(Of String, String)("Value", "Value"), New NKeyValuePair(Of String, String)("XValue", "X"), New NKeyValuePair(Of String, String)("Label", "Label"))

            ' configure title
            chartView.Surface.Titles(0).Text = "Chart Data Binding"

            ' use bright theme
            chartView.Document.StyleSheets.ApplyTheme(New NChartTheme(ENChartPalette.Bright, ENChartPaletteTarget.DataPoints))
            Return chartViewWithCommandBars
        End Function
        Protected Overrides Function CreateExampleControls() As NWidget
            Dim stack As NStackPanel = New NStackPanel()
            stack.FillMode = ENStackFillMode.First
            stack.FitMode = ENStackFitMode.First

            ' table to edit the data
            Dim tableGridView As NTableGridView = New NTableGridView()
            tableGridView.GroupingPanel.Visibility = ENVisibility.Collapsed

            tableGridView.Content.RowHeaders.ShowRowNumbers = True
            tableGridView.Content.AutoCreateColumns = True
            tableGridView.Content.AllowEdit = True
            tableGridView.Content.DataSource = New NDataSource(m_MemoryDataTable)
            stack.Add(tableGridView)

            Dim hstack As NStackPanel = New NStackPanel()
            stack.Add(hstack)

            Return stack
        End Function
        Protected Overrides Function GetExampleDescription() As String
            Return "<p>This example demonstrates how bind the chart data points to a data source. 
                </br>
                Once the data points are bound, they will be automatically updated when the data source changes.</p>" End Function

#End Region

#Region "Fields"

        Private m_MemoryDataTable As NMemoryDataTable

#End Region

#Region "Schema"

        Public Shared ReadOnly NChartDataBindingExampleSchema As NSchema

#End Region
    End Class
End Namespace

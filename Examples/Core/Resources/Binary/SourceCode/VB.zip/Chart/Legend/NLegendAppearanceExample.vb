Imports Nevron.Nov.Chart
Imports Nevron.Nov.Dom
Imports Nevron.Nov.Graphics
Imports Nevron.Nov.Layout
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.Chart
    ''' <summary>
    ''' Legend Appearance Example
    ''' </summary>
    Public Class NLegendAppearanceExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' Default constructor
        ''' </summary>
        Public Sub New()
        End Sub
        ''' <summary>
        ''' Static constructor
        ''' </summary>
        Shared Sub New()
            NLegendAppearanceExampleSchema = NSchema.Create(GetType(NLegendAppearanceExample), NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            Dim chartView As NChartView = CreateCartesianChartView()

            ' configure title
            chartView.Surface.Titles(0).Text = "Legend Appearance"
            m_Legend = chartView.Surface.Legends(0)
            m_Legend.ExpandMode = ENLegendExpandMode.ColsFixed
            m_Legend.ColCount = 3
            m_Legend.Border = NBorder.CreateFilledBorder(NColor.Black)
            m_Legend.BorderThickness = New NMargins(2)
            m_Legend.BackgroundFill = New NStockGradientFill(NColor.White, NColor.LightGray)
            m_Legend.VerticalPlacement = ENVerticalPlacement.Top

            ' configure chart
            Dim chart = CType(chartView.Surface.Charts(0), NCartesianChart)
            chart.SetPredefinedCartesianAxes(ENPredefinedCartesianAxis.XOrdinalYLinear)

            ' add interlace stripe
            Dim linearScale As NLinearScale = TryCast(chart.Axes(ENCartesianAxis.PrimaryY).Scale, NLinearScale)
            Dim strip As NScaleStrip = New NScaleStrip(New NColorFill(ENNamedColor.Beige), Nothing, True, 0, 0, 1, 1)
            strip.Interlaced = True
            'linearScale.Strips.Add(strip);

            ' setup a bar series
            Dim bar As NBarSeries = New NBarSeries()
            bar.Name = "Bar Series"
            bar.InflateMargins = True
            bar.UseXValues = False
            bar.LegendView.Mode = ENSeriesLegendMode.DataPoints

            ' add some data to the bar series
            bar.LegendView.Mode = ENSeriesLegendMode.DataPoints
            bar.DataPoints.Add(New NBarDataPoint(18, "C++"))
            bar.DataPoints.Add(New NBarDataPoint(15, "Ruby"))
            bar.DataPoints.Add(New NBarDataPoint(21, "Python"))
            bar.DataPoints.Add(New NBarDataPoint(23, "Java"))
            bar.DataPoints.Add(New NBarDataPoint(27, "Javascript"))
            bar.DataPoints.Add(New NBarDataPoint(29, "C#"))
            bar.DataPoints.Add(New NBarDataPoint(26, "PHP"))
            bar.DataPoints.Add(New NBarDataPoint(17, "Objective C"))
            bar.DataPoints.Add(New NBarDataPoint(24, "SQL"))
            bar.DataPoints.Add(New NBarDataPoint(13, "Object Pascal"))
            bar.DataPoints.Add(New NBarDataPoint(19, "Visual Basic"))
            bar.DataPoints.Add(New NBarDataPoint(16, "Open Edge ABL"))
            chart.Series.Add(bar)
            Return chartView
        End Function

        Protected Overrides Function CreateExampleControls() As NWidget
            Dim stack As NStackPanel = New NStackPanel()
            Dim boxGroup As NUniSizeBoxGroup = New NUniSizeBoxGroup(stack)
            Dim legendHeaderTextBox As NTextBox = New NTextBox()
            AddHandler legendHeaderTextBox.TextChanged, AddressOf OnLegendHeaderTextBoxChanged
            stack.Add(NPairBox.Create("Header: ", legendHeaderTextBox))
            Dim legendFooterTextBox As NTextBox = New NTextBox()
            AddHandler legendFooterTextBox.TextChanged, AddressOf OnLegendFooterTextBoxChanged
            stack.Add(NPairBox.Create("Footer: ", legendFooterTextBox))
            m_HorizontalInterlaceStripesCheckBox = New NCheckBox("Horizontal Interlace Stripes")
            AddHandler m_HorizontalInterlaceStripesCheckBox.CheckedChanged, AddressOf OnVerticalInterlaceStripesCheckBoxCheckedChanged
            stack.Add(m_HorizontalInterlaceStripesCheckBox)
            m_VerticalInterlaceStripesCheckBox = New NCheckBox("Vertical Interlace Stripes")
            AddHandler m_VerticalInterlaceStripesCheckBox.CheckedChanged, AddressOf OnHorizontalInterlaceStripesCheckBoxCheckedChanged
            stack.Add(m_VerticalInterlaceStripesCheckBox)
            Dim showHorizontalGridLinesCheckBox As NCheckBox = New NCheckBox("Show Horizontal Gridlines")
            showHorizontalGridLinesCheckBox.Checked = True
            AddHandler showHorizontalGridLinesCheckBox.CheckedChanged, AddressOf OnShowHorizontalGridLinesCheckBoxCheckedChanged
            stack.Add(showHorizontalGridLinesCheckBox)
            Dim showVerticalGridLinesCheckBox As NCheckBox = New NCheckBox("Show Vertical Gridlines")
            showVerticalGridLinesCheckBox.Checked = True
            AddHandler showVerticalGridLinesCheckBox.CheckedChanged, AddressOf OnShowVerticalGridLinesCheckBoxCheckedChanged
            stack.Add(showVerticalGridLinesCheckBox)
            Return boxGroup
        End Function

        Protected Overrides Function GetExampleDescription() As String
            Return "<p>This example demonstrates how to modify the legend appearance.</p>"
        End Function

#End Region

#Region "Implementation"

        Private Sub ApplyInterlaceStyles()
            Dim interlaceStyles As NLegendInterlaceStylesCollection = New NLegendInterlaceStylesCollection()

            If m_HorizontalInterlaceStripesCheckBox.Checked Then
                Dim horzInterlaceStyle As NLegendInterlaceStyle = New NLegendInterlaceStyle()
                horzInterlaceStyle.Fill = New NColorFill(NColor.FromColor(NColor.LightBlue, 0.5F))
                horzInterlaceStyle.Type = ENLegendInterlaceStyleType.Row
                horzInterlaceStyle.Length = 1
                horzInterlaceStyle.Interval = 1
                interlaceStyles.Add(horzInterlaceStyle)
            End If

            If m_VerticalInterlaceStripesCheckBox.Checked Then
                Dim vertInterlaceStyle As NLegendInterlaceStyle = New NLegendInterlaceStyle()
                vertInterlaceStyle.Fill = New NColorFill(NColor.FromColor(NColor.DarkGray, 0.5F))
                vertInterlaceStyle.Type = ENLegendInterlaceStyleType.Col
                vertInterlaceStyle.Length = 1
                vertInterlaceStyle.Interval = 1
                interlaceStyles.Add(vertInterlaceStyle)
            End If

            m_Legend.InterlaceStyles = interlaceStyles
        End Sub

#End Region

#Region "Event Handlers"

        Private Sub OnShowVerticalGridLinesCheckBoxCheckedChanged(ByVal arg As NValueChangeEventArgs)
            If CType(arg.TargetNode, NCheckBox).Checked Then
                m_Legend.ClearLocalValue(NLegend.VerticalGridStrokeProperty)
            Else
                m_Legend.VerticalGridStroke = Nothing
            End If
        End Sub

        Private Sub OnShowHorizontalGridLinesCheckBoxCheckedChanged(ByVal arg As NValueChangeEventArgs)
            If CType(arg.TargetNode, NCheckBox).Checked Then
                m_Legend.ClearLocalValue(NLegend.HorizontalGridStrokeProperty)
            Else
                m_Legend.HorizontalGridStroke = Nothing
            End If
        End Sub

        Private Sub OnLegendHeaderTextBoxChanged(ByVal arg As NValueChangeEventArgs)
            Dim header As NLabel = New NLabel(CType(arg.TargetNode, NTextBox).Text)
            header.HorizontalPlacement = ENHorizontalPlacement.Center
            header.TextAlignment = ENContentAlignment.MiddleCenter
            header.Font = New NFont("Arimo", 14, ENFontStyle.Bold)
            m_Legend.Header = header
        End Sub

        Private Sub OnLegendFooterTextBoxChanged(ByVal arg As NValueChangeEventArgs)
            Dim footer As NLabel = New NLabel(CType(arg.TargetNode, NTextBox).Text)
            footer.HorizontalPlacement = ENHorizontalPlacement.Center
            footer.TextAlignment = ENContentAlignment.MiddleCenter
            footer.Font = New NFont("Arimo", 14, ENFontStyle.Bold)
            m_Legend.Footer = footer
        End Sub

        Private Sub OnVerticalInterlaceStripesCheckBoxCheckedChanged(ByVal arg As NValueChangeEventArgs)
            ApplyInterlaceStyles()
        End Sub

        Private Sub OnHorizontalInterlaceStripesCheckBoxCheckedChanged(ByVal arg As NValueChangeEventArgs)
            ApplyInterlaceStyles()
        End Sub

#End Region

#Region "Fields"

        Private m_Legend As NLegend
        Private m_HorizontalInterlaceStripesCheckBox As NCheckBox
        Private m_VerticalInterlaceStripesCheckBox As NCheckBox

#End Region

#Region "Schema"

        Public Shared ReadOnly NLegendAppearanceExampleSchema As NSchema

#End Region

#Region "Static Methods"

        Private Shared Function CreateCartesianChartView() As NChartView
            Dim chartView As NChartView = New NChartView()
            chartView.Surface.CreatePredefinedChart(ENPredefinedChartType.Cartesian)
            Return chartView
        End Function

#End Region
    End Class
End Namespace

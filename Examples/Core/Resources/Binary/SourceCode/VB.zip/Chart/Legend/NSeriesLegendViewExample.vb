Imports System
Imports Nevron.Nov.Chart
Imports Nevron.Nov.Dom
Imports Nevron.Nov.Graphics
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.Chart
    ''' <summary>
    ''' Series Legend Modes Example
    ''' </summary>
    Public Class NSeriesLegendViewExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' Default constructor
        ''' </summary>
        Public Sub New()
        End Sub
        ''' <summary>
        ''' Static constructor
        ''' </summary>
        Shared Sub New()
            NSeriesLegendViewExampleSchema = NSchema.Create(GetType(NSeriesLegendViewExample), NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            Dim chartView As NChartView = CreateCartesianChartView()

            ' configure title
            chartView.Surface.Titles(0).Text = "Series Legend View"

            ' configure chart
            m_Chart = CType(chartView.Surface.Charts(0), NCartesianChart)
            m_Chart.SetPredefinedCartesianAxes(ENPredefinedCartesianAxis.XOrdinalYLinear)

            ' add interlace stripe
            Dim linearScale As NLinearScale = TryCast(m_Chart.Axes(ENCartesianAxis.PrimaryY).Scale, NLinearScale)
            Dim strip As NScaleStrip = New NScaleStrip(New NColorFill(ENNamedColor.Beige), Nothing, True, 0, 0, 1, 1)
            strip.Interlaced = True
            linearScale.Strips.Add(strip)

            ' add a bar series
            Dim bar1 As NBarSeries = New NBarSeries()
            bar1.Name = "Bar1"
            bar1.MultiBarMode = ENMultiBarMode.Series
            bar1.DataLabelStyle = New NDataLabelStyle(False)
            bar1.ValueFormatter = New NNumericValueFormatter("0.###")
            m_Chart.Series.Add(bar1)

            ' add another bar series
            Dim bar2 As NBarSeries = New NBarSeries()
            bar2.Name = "Bar2"
            bar2.MultiBarMode = ENMultiBarMode.Clustered
            bar2.DataLabelStyle = New NDataLabelStyle(False)
            bar2.ValueFormatter = New NNumericValueFormatter("0.###")
            m_Chart.Series.Add(bar2)

            ' add another bar series
            Dim bar3 As NBarSeries = New NBarSeries()
            bar3.Name = "Bar2"
            bar3.MultiBarMode = ENMultiBarMode.Clustered
            bar3.DataLabelStyle = New NDataLabelStyle(False)
            bar3.ValueFormatter = New NNumericValueFormatter("0.###")
            m_Chart.Series.Add(bar3)
            Dim random As Random = New Random()

            For i = 0 To 5 - 1
                bar1.DataPoints.Add(New NBarDataPoint(random.Next(10, 100)))
                bar2.DataPoints.Add(New NBarDataPoint(random.Next(10, 100)))
                bar3.DataPoints.Add(New NBarDataPoint(random.Next(10, 100)))
            Next

            chartView.Document.StyleSheets.ApplyTheme(New NChartTheme(ENChartPalette.Bright, False))
            Return chartView
        End Function

        Protected Overrides Function CreateExampleControls() As NWidget
            Dim stack As NStackPanel = New NStackPanel()
            Dim boxGroup As NUniSizeBoxGroup = New NUniSizeBoxGroup(stack)
            Dim seriesLegendModeComboBox As NComboBox = New NComboBox()
            seriesLegendModeComboBox.FillFromEnum(Of ENSeriesLegendMode)()
            AddHandler seriesLegendModeComboBox.SelectedIndexChanged, AddressOf OnSeriesLegendModeComboBoxSelectedIndexChanged
            seriesLegendModeComboBox.SelectedIndex = ENSeriesLegendMode.Series
            stack.Add(NPairBox.Create("Legend Mode: ", seriesLegendModeComboBox))
            Dim seriesLegendOrderComboBox As NComboBox = New NComboBox()
            seriesLegendOrderComboBox.FillFromEnum(Of ENSeriesLegendOrder)()
            AddHandler seriesLegendOrderComboBox.SelectedIndexChanged, AddressOf OnSeriesLegendOrderComboBoxSelectedIndexChanged
            seriesLegendOrderComboBox.SelectedIndex = ENSeriesLegendOrder.Append
            stack.Add(NPairBox.Create("Legend Order: ", seriesLegendOrderComboBox))
            Dim markSizeUpDown As NNumericUpDown = New NNumericUpDown()
            AddHandler markSizeUpDown.ValueChanged, AddressOf OnMarkSizeUpDownValueChanged
            markSizeUpDown.Value = 10
            stack.Add(NPairBox.Create("Mark Size: ", markSizeUpDown))
            Dim fontSizeUpDown As NNumericUpDown = New NNumericUpDown()
            AddHandler fontSizeUpDown.ValueChanged, AddressOf OnFontSizeUpDownValueChanged
            fontSizeUpDown.Value = 10
            stack.Add(NPairBox.Create("Font Size: ", fontSizeUpDown))
            Return boxGroup
        End Function

        Protected Overrides Function GetExampleDescription() As String
            Return "<p>This example demonstrates the effect of different series legend view settings.</p>"
        End Function

#End Region

#Region "Event Handlers"

        Private Sub OnSeriesLegendModeComboBoxSelectedIndexChanged(ByVal arg As NValueChangeEventArgs)
            Dim seriesLegendMode As ENSeriesLegendMode = CType(arg.TargetNode, NComboBox).SelectedIndex

            For i = 0 To m_Chart.Series.Count - 1
                m_Chart.Series(i).LegendView.Mode = seriesLegendMode
            Next
        End Sub

        Private Sub OnSeriesLegendOrderComboBoxSelectedIndexChanged(ByVal arg As NValueChangeEventArgs)
            Dim seriesLegendOrder As ENSeriesLegendOrder = CType(arg.TargetNode, NComboBox).SelectedIndex

            For i = 0 To m_Chart.Series.Count - 1
                m_Chart.Series(i).LegendView.Order = seriesLegendOrder
            Next
        End Sub

        Private Sub OnFontSizeUpDownValueChanged(ByVal arg As NValueChangeEventArgs)
            Dim fontSize = CType(arg.TargetNode, NNumericUpDown).Value

            For i = 0 To m_Chart.Series.Count - 1
                m_Chart.Series(i).LegendView.TextStyle.Font.Size = fontSize
            Next
        End Sub

        Private Sub OnMarkSizeUpDownValueChanged(ByVal arg As NValueChangeEventArgs)
            Dim markSize = CType(arg.TargetNode, NNumericUpDown).Value

            For i = 0 To m_Chart.Series.Count - 1
                m_Chart.Series(i).LegendView.MarkSize = New NSize(markSize, markSize)
            Next
        End Sub

#End Region

#Region "Fields"

        Private m_Chart As NCartesianChart

#End Region

#Region "Schema"

        Public Shared ReadOnly NSeriesLegendViewExampleSchema As NSchema

#End Region

#Region "Static Methods"

        Private Shared Function CreateCartesianChartView() As NChartView
            Dim chartView As NChartView = New NChartView()
            chartView.Surface.CreatePredefinedChart(ENPredefinedChartType.Cartesian)
            Return chartView
        End Function

#End Region
    End Class
End Namespace

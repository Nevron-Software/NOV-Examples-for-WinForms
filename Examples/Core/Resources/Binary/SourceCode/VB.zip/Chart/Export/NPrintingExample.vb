Imports System

Imports Nevron.Nov.Chart
Imports Nevron.Nov.Chart.Export
Imports Nevron.Nov.Dom
Imports Nevron.Nov.Graphics
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.Chart
    ''' <summary>
    ''' Pdf Export Example
    ''' </summary>
    Public Class NPrintingExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' Default constructor
        ''' </summary>
        Public Sub New()

        End Sub
        ''' <summary>
        ''' Static constructor
        ''' </summary>
        Shared Sub New()
            NPrintingExampleSchema = NSchema.Create(GetType(NPrintingExample), NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            Dim chartViewWithCommandBars As NChartViewWithCommandBars = New NChartViewWithCommandBars()
            m_ChartView = chartViewWithCommandBars.View
            m_ChartView.Surface.CreatePredefinedChart(ENPredefinedChartType.Cartesian)

            ' configure title
            m_ChartView.Surface.Titles(0).Text = "Printing Example"

            ' configure chart
            Dim chart = CType(m_ChartView.Surface.Charts(0), NCartesianChart)

            chart.SetPredefinedCartesianAxes(ENPredefinedCartesianAxis.XYLinear)

            ' setup X axis
            Dim xScale As NLinearScale = chart.Axes(ENCartesianAxis.PrimaryX).Scale

            xScale.MajorGridLines.Visible = True

            ' setup Y axis
            Dim yScale As NLinearScale = chart.Axes(ENCartesianAxis.PrimaryY).Scale
            yScale.MajorGridLines.Visible = True

            ' add interlaced stripe
            Dim strip As NScaleStrip = New NScaleStrip(New NColorFill(NColor.Beige), Nothing, True, 0, 0, 1, 1)
            strip.Interlaced = True
            yScale.Strips.Add(strip)

            ' setup shape series
            Dim range As NRangeSeries = New NRangeSeries()
            chart.Series.Add(range)

            range.DataLabelStyle = New NDataLabelStyle(False)
            range.UseXValues = True
            range.Fill = New NColorFill(NColor.DarkOrange)
            range.Stroke = New NStroke(NColor.DarkRed)

            ' fill data
            Dim intervals = New Double() {5, 5, 5, 5, 5, 5, 5, 5, 5, 15, 30, 60}
            Dim values = New Double() {4180, 13687, 18618, 19634, 17981, 7190, 16369, 3212, 4122, 9200, 6461, 3435}

            Dim count = Math.Min(intervals.Length, values.Length)
            Dim x As Double = 0

            For i = 0 To count - 1
                Dim interval = intervals(i)
                Dim value = values(i)

                Dim x1 = x
                Dim y1 As Double = 0

                x += interval
                Dim x2 = x
                Dim y2 = value / interval

                range.DataPoints.Add(New NRangeDataPoint(x1, y1, x2, y2))
            Next

            m_ChartView.Document.StyleSheets.ApplyTheme(New NChartTheme(ENChartPalette.Bright, ENChartPaletteTarget.Series))

            Return chartViewWithCommandBars
        End Function
        Protected Overrides Function CreateExampleControls() As NWidget
            Dim stack As NStackPanel = New NStackPanel()
            Dim group As NUniSizeBoxGroup = New NUniSizeBoxGroup(stack)

            Dim printButton As NButton = New NButton("Print...")
            printButton.Click += AddressOf OnPrintButtonClick
            stack.Add(printButton)

            Return group
        End Function
        Protected Overrides Function GetExampleDescription() As String
            Return "<p>This example demonstrates how to print the chart.</p>"
        End Function

#End Region

#Region "Event Handlers"

        Private Sub OnPrintButtonClick(ByVal arg As NEventArgs)
            Dim printExporter As NChartPrintExporter = New NChartPrintExporter(m_ChartView.Content)
            printExporter.ShowDialog(m_ChartView.DisplayWindow, True)
        End Sub

#End Region

#Region "Fields"

        Private m_ChartView As NChartView

#End Region

#Region "Schema"

        Public Shared ReadOnly NPrintingExampleSchema As NSchema

#End Region
    End Class
End Namespace

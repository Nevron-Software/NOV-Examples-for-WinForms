Imports System
Imports Nevron.Nov.Chart
Imports Nevron.Nov.Chart.Export
Imports Nevron.Nov.Dom
Imports Nevron.Nov.Graphics
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.Chart
    ''' <summary>
    ''' Pdf Export Example
    ''' </summary>
    Public Class NPdfExportExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' Default constructor
        ''' </summary>
        Public Sub New()
        End Sub
        ''' <summary>
        ''' Static constructor
        ''' </summary>
        Shared Sub New()
            NPdfExportExampleSchema = NSchema.Create(GetType(NPdfExportExample), NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            m_ChartView = CreateCartesianChartView()

            ' configure title
            m_ChartView.Surface.Titles(0).Text = "Pdf Export Example"

            ' configure chart
            Dim chart = CType(m_ChartView.Surface.Charts(0), NCartesianChart)
            chart.SetPredefinedCartesianAxes(ENPredefinedCartesianAxis.XYLinear)

            ' setup X axis
            Dim xScale = CType(chart.Axes(ENCartesianAxis.PrimaryX).Scale, NLinearScale)
            xScale.MajorGridLines.Visible = True

            ' setup Y axis
            Dim yScale = CType(chart.Axes(ENCartesianAxis.PrimaryY).Scale, NLinearScale)
            yScale.MajorGridLines.Visible = True

            ' add interlaced stripe
            Dim strip As NScaleStrip = New NScaleStrip(New NColorFill(NColor.Beige), Nothing, True, 0, 0, 1, 1)
            strip.Interlaced = True
            yScale.Strips.Add(strip)

            ' setup shape series
            Dim range As NRangeSeries = New NRangeSeries()
            chart.Series.Add(range)
            range.DataLabelStyle = New NDataLabelStyle(False)
            range.UseXValues = True
            range.Fill = New NColorFill(NColor.DarkOrange)
            range.Stroke = New NStroke(NColor.DarkRed)

            ' fill data
            Dim intervals = New Double() {5, 5, 5, 5, 5, 5, 5, 5, 5, 15, 30, 60}
            Dim values = New Double() {4180, 13687, 18618, 19634, 17981, 7190, 16369, 3212, 4122, 9200, 6461, 3435}
            Dim count = Math.Min(intervals.Length, values.Length)
            Dim x As Double = 0

            For i = 0 To count - 1
                Dim interval = intervals(i)
                Dim value = values(i)
                Dim x1 = x
                Dim y1 As Double = 0
                x += interval
                Dim x2 = x
                Dim y2 = value / interval
                range.DataPoints.Add(New NRangeDataPoint(x1, y1, x2, y2))
            Next

            m_ChartView.Document.StyleSheets.ApplyTheme(New NChartTheme(ENChartPalette.Bright, False))
            Return m_ChartView
        End Function

        Protected Overrides Function CreateExampleControls() As NWidget
            Dim stack As NStackPanel = New NStackPanel()
            Dim group As NUniSizeBoxGroup = New NUniSizeBoxGroup(stack)
            Dim saveAsPdfFileButton As NButton = New NButton("Save as PDF File...")
            AddHandler saveAsPdfFileButton.Click, AddressOf OnSaveAsPdfFileButtonClick
            stack.Add(saveAsPdfFileButton)
            Return group
        End Function

        Protected Overrides Function GetExampleDescription() As String
            Return "<p>This example demonstrates how to export the chart to Pdf file or stream.</p>"
        End Function

#End Region

#Region "Event Handlers"

        Private Sub OnSaveAsPdfFileButtonClick(ByVal arg As NEventArgs)
            Dim pdfExporter As NChartPdfExporter = New NChartPdfExporter(m_ChartView.Document)
            pdfExporter.SaveAsPdf(New NRectangle(0, 0, 400, 300))

            ' Note: You can also use SaveToFile like:
            ' pdfExporter.SaveToFile("c:\\SomePdf.pdf", new NRectangle(0, 0, 400, 300));

            ' or SaveToStream:
            ' MemoryStream memoryStream = new MemoryStream();
            ' imageExporter.SaveToStream(memoryStream, NImageFormat.Png, new NSize(400, 300), 96);
            ' pdfExporter.SaveToStream(memoryStream, new NRectangle(0, 0, 400, 300), 96);
            ' byte[] imageBytes = memoryStream.ToArray();
        End Sub

#End Region

#Region "Fields"

        Private m_ChartView As NChartView

#End Region

#Region "Schema"

        Public Shared ReadOnly NPdfExportExampleSchema As NSchema

#End Region

#Region "Static Methods"

        Private Shared Function CreateCartesianChartView() As NChartView
            Dim chartView As NChartView = New NChartView()
            chartView.Surface.CreatePredefinedChart(ENPredefinedChartType.Cartesian)
            Return chartView
        End Function

#End Region
    End Class
End Namespace

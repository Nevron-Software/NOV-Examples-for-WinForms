Imports System

Imports Nevron.Nov.Chart
Imports Nevron.Nov.Chart.Commands
Imports Nevron.Nov.Chart.UI
Imports Nevron.Nov.Dom
Imports Nevron.Nov.Graphics
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.Chart
    Public Class NRibbonCustomizationExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' Default constructor.
        ''' </summary>
        Public Sub New()
        End Sub

        ''' <summary>
        ''' Static constructor.
        ''' </summary>
        Shared Sub New()
            NRibbonCustomizationExampleSchema = NSchema.Create(GetType(NRibbonCustomizationExample), NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            ' Create a simple chart
            m_ChartView = New NChartView()

            m_ChartView.Document.HistoryService.Pause()
            Try
                InitChart(m_ChartView.Document)
            Finally
                m_ChartView.Document.HistoryService.Resume()
            End Try

            ' Create and customize a ribbon UI builder
            Dim ribbonBuilder As NChartRibbonBuilder = New NChartRibbonBuilder()

            ' Add the custom command action to the chart view's commander
            m_ChartView.Commander.Add(New CustomCommandAction())

            ' Rename the "Home" ribbon tab page
            Dim homeTabBuilder = ribbonBuilder.TabPageBuilders(NChartRibbonBuilder.TabPageHomeName)
            homeTabBuilder.Name = "Start"

            ' Rename the "Export" ribbon group of the "Home" tab page
            Dim exportGroupBuilder = homeTabBuilder.RibbonGroupBuilders(NHomeTabPageBuilder.GroupExportName)
            exportGroupBuilder.Name = "Custom Name"

            ' Remove the "Design" ribbon group from the "Home" tab page
            homeTabBuilder.RibbonGroupBuilders.Remove(NHomeTabPageBuilder.GroupDesignName)

            ' Insert the custom ribbon group at the beginning of the home tab page
            homeTabBuilder.RibbonGroupBuilders.Insert(0, New CustomRibbonGroupBuilder())

            ' Create the commanding UI
            Dim chartViewWithRibbon As NCommandUIHolder = ribbonBuilder.CreateUI(m_ChartView)

            ' Remove the Open, Save and SaveAs commands
            chartViewWithRibbon.RemoveCommands(NChartView.OpenCommand, NChartView.SaveCommand, NChartView.SaveAsCommand)

            Return chartViewWithRibbon
        End Function
        Protected Overrides Function CreateExampleControls() As NWidget
            Return Nothing
        End Function
        Protected Overrides Function GetExampleDescription() As String
            Return "<p>This example demonstrates how to customize the NOV Chart ribbon.</p>"
        End Function

        Private Sub InitChart(ByVal chartDocument As NChartDocument)
            Dim chartSurface = chartDocument.Content
            chartSurface.CreatePredefinedChart(ENPredefinedChartType.Cartesian)

            ' Set the title
            chartSurface.Titles(0).Text = "Chart Commanding Interface"

            ' Configure the chart
            Dim chart = CType(chartSurface.Charts(0), NCartesianChart)
            chart.Enable3D = True
            chart.Projection.SetPredefinedProjection(ENPredefinedProjection.Perspective)

            ' Add an interlace stripe
            Dim linearScale As NLinearScale = TryCast(chart.Axes(ENCartesianAxis.PrimaryY).Scale, NLinearScale)
            Dim strip As NScaleStrip = New NScaleStrip(New NColorFill(ENNamedColor.Beige), Nothing, True, 0, 0, 1, 1)
            strip.Interlaced = True
            linearScale.Strips.Add(strip)

            ' Add a bar series
            Dim random As Random = New Random()
            For i = 0 To 5
                Dim bar As NBarSeries = New NBarSeries()
                bar.Name = "Bar" & i.ToString()
                bar.MultiBarMode = ENMultiBarMode.Clustered
                bar.DataLabelStyle = New NDataLabelStyle(False)
                bar.ValueFormatter = New NNumericValueFormatter("0.###")
                chart.Series.Add(bar)

                For j = 0 To 5
                    bar.DataPoints.Add(New NBarDataPoint(random.Next(10, 100)))
                Next
            Next
        End Sub

#End Region

#Region "Fields"

        Private m_ChartView As NChartView

#End Region

#Region "Schema"

        ''' <summary>
        ''' Schema associated with NRibbonCustomizationExample.
        ''' </summary>
        Public Shared ReadOnly NRibbonCustomizationExampleSchema As NSchema

#End Region

#Region "Constants"

        Public Shared ReadOnly CustomCommand As NCommand = NCommand.Create(GetType(NRibbonCustomizationExample), "CustomCommand", "Custom Command")

#End Region

#Region "Nested Types"

        Public Class CustomRibbonGroupBuilder
            Inherits NRibbonGroupBuilder
#Region "Constructors"

            Public Sub New()
                MyBase.New("Custom Group", NResources.Image_Ribbon_16x16_smiley_png)
            End Sub

#End Region

#Region "Protected Overrides"

            Protected Overrides Sub AddRibbonGroupItems(ByVal items As NRibbonGroupItemCollection)
                ' Add the "Copy" command
                items.Add(MyBase.CreateRibbonButton(Presentation.NResources.Image_Ribbon_AppMenu_Open_png, Presentation.NResources.Image_File_Open_png, NChartView.OpenCommand))

                ' Add the custom command
                items.Add(CreateRibbonButton(NResources.Image_Ribbon_32x32_smiley_png, NResources.Image_Ribbon_16x16_smiley_png, CustomCommand))
            End Sub

#End Region
        End Class

        Public Class CustomCommandAction
            Inherits NChartCommandAction
#Region "Constructors"

            ''' <summary>
            ''' Default constructor.
            ''' </summary>
            Public Sub New()
            End Sub

            ''' <summary>
            ''' Static constructor.
            ''' </summary>
            Shared Sub New()
                CustomCommandActionSchema = NSchema.Create(GetType(CustomCommandAction), NChartCommandActionSchema)
            End Sub

#End Region

#Region "Public Overrides"

            ''' <summary>
            ''' Gets the command associated with this command action.
            ''' </summary>
            ''' <returns></returns>
            Public Overrides Function GetCommand() As NCommand
                Return CustomCommand
            End Function
            ''' <summary>
            ''' Executes the command action.
            ''' </summary>
            ''' <paramname="target"></param>
            ''' <paramname="parameter"></param>
            Public Overrides Sub Execute(ByVal target As NNode, ByVal parameter As Object)
                Dim chartView = GetChartView(target)

                NMessageBox.Show("Chart Custom Command executed!", "Custom Command", ENMessageBoxButtons.OK, ENMessageBoxIcon.Information)
            End Sub

#End Region

#Region "Schema"

            ''' <summary>
            ''' Schema associated with CustomCommandAction.
            ''' </summary>
            Public Shared ReadOnly CustomCommandActionSchema As NSchema

#End Region
        End Class

#End Region
    End Class
End Namespace

Imports System

Imports Nevron.Nov.Chart
Imports Nevron.Nov.Dom
Imports Nevron.Nov.Graphics
Imports Nevron.Nov.Layout
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.Chart
    Public Class NRibbonAndCommandBarsExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' Default constructor.
        ''' </summary>
        Public Sub New()
        End Sub

        ''' <summary>
        ''' Static constructor.
        ''' </summary>
        Shared Sub New()
            NRibbonAndCommandBarsExampleSchema = NSchema.Create(GetType(NRibbonAndCommandBarsExample), NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            ' Create a simple chart
            m_ChartView = New NChartView()

            m_ChartView.Document.HistoryService.Pause()
            Try
                InitChart(m_ChartView.Document)
            Finally
                m_ChartView.Document.HistoryService.Resume()
            End Try

            ' Create and execute a ribbon UI builder
            m_RibbonBuilder = New NChartRibbonBuilder()
            Return m_RibbonBuilder.CreateUI(m_ChartView)
        End Function
        Protected Overrides Function CreateExampleControls() As NWidget
            ' Switch UI button
            Dim switchUIButton As NButton = New NButton(SwitchToCommandBars)
            switchUIButton.VerticalPlacement = ENVerticalPlacement.Top
            switchUIButton.Click += AddressOf OnSwitchUIButtonClick

            Return switchUIButton
        End Function
        Protected Overrides Function GetExampleDescription() As String
            Return "<p>This example demonstrates how to add a commanding interface to the NOV Chart and how to switch between ribbon and command bars.</p>"
        End Function

        Private Sub InitChart(ByVal chartDocument As NChartDocument)
            Dim chartSurface = chartDocument.Content
            chartSurface.CreatePredefinedChart(ENPredefinedChartType.Cartesian)

            ' Set the title
            chartSurface.Titles(0).Text = "Chart Commanding Interface"

            ' Configure the chart
            Dim chart = CType(chartSurface.Charts(0), NCartesianChart)
            chart.Enable3D = True
            chart.Projection.SetPredefinedProjection(ENPredefinedProjection.Perspective)

            ' Add an interlace stripe
            Dim linearScale As NLinearScale = TryCast(chart.Axes(ENCartesianAxis.PrimaryY).Scale, NLinearScale)
            Dim strip As NScaleStrip = New NScaleStrip(New NColorFill(ENNamedColor.Beige), Nothing, True, 0, 0, 1, 1)
            strip.Interlaced = True
            linearScale.Strips.Add(strip)

            ' Add a bar series
            Dim random As Random = New Random()
            For i = 0 To 5
                Dim bar As NBarSeries = New NBarSeries()
                bar.Name = "Bar" & i.ToString()
                bar.MultiBarMode = ENMultiBarMode.Clustered
                bar.DataLabelStyle = New NDataLabelStyle(False)
                bar.ValueFormatter = New NNumericValueFormatter("0.###")
                chart.Series.Add(bar)

                For j = 0 To 5
                    bar.DataPoints.Add(New NBarDataPoint(random.Next(10, 100)))
                Next
            Next
        End Sub

#End Region

#Region "Implementation"

        Private Sub SetUI(ByVal oldUiHolder As NCommandUIHolder, ByVal widget As NWidget)
            If TypeOf oldUiHolder.ParentNode Is NTabPage Then
                CType(oldUiHolder.ParentNode, NTabPage).Content = widget
            ElseIf TypeOf oldUiHolder.ParentNode Is NPairBox Then
                CType(oldUiHolder.ParentNode, NPairBox).Box1 = widget
            End If
        End Sub

#End Region

#Region "Event Handlers"

        Private Sub OnSwitchUIButtonClick(ByVal arg As NEventArgs)
            Dim switchUIButton = CType(arg.TargetNode, NButton)
            Dim label = CType(switchUIButton.Content, NLabel)

            ' Remove the chart view from its parent
            Dim uiHolder As NCommandUIHolder = m_ChartView.GetFirstAncestor(Of NCommandUIHolder)()
            m_ChartView.ParentNode.RemoveChild(m_ChartView)

            If Equals(label.Text, SwitchToRibbon) Then
                ' We are in "Command Bars" mode, so switch to "Ribbon"
                label.Text = SwitchToCommandBars

                ' Create the ribbon
                SetUI(uiHolder, m_RibbonBuilder.CreateUI(m_ChartView))
            Else
                ' We are in "Ribbon" mode, so switch to "Command Bars"
                label.Text = SwitchToRibbon

                ' Create the command bars
                If m_CommandBarBuilder Is Nothing Then
                    m_CommandBarBuilder = New NChartCommandBarBuilder()
                End If

                SetUI(uiHolder, m_CommandBarBuilder.CreateUI(m_ChartView))
            End If
        End Sub

#End Region

#Region "Fields"

        Private m_ChartView As NChartView
        Private m_RibbonBuilder As NChartRibbonBuilder
        Private m_CommandBarBuilder As NChartCommandBarBuilder

#End Region

#Region "Schema"

        ''' <summary>
        ''' Schema associated with NRibbonAndCommandBarsSwitchingExample.
        ''' </summary>
        Public Shared ReadOnly NRibbonAndCommandBarsExampleSchema As NSchema

#End Region

#Region "Constants"

        Private Const SwitchToCommandBars As String = "Switch to Command Bars"
        Private Const SwitchToRibbon As String = "Switch to Ribbon"

#End Region
    End Class
End Namespace

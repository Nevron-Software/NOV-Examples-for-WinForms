Imports System

Imports Nevron.Nov.Chart
Imports Nevron.Nov.Chart.Commands
Imports Nevron.Nov.Dom
Imports Nevron.Nov.Graphics
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.Chart
    Public Class NCommandBarsCustomizationExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' Default constructor.
        ''' </summary>
        Public Sub New()
        End Sub

        ''' <summary>
        ''' Static constructor.
        ''' </summary>
        Shared Sub New()
            NCommandBarsCustomizationExampleSchema = NSchema.Create(GetType(NCommandBarsCustomizationExample), NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            ' Create a simple chart
            m_ChartView = New NChartView()

            m_ChartView.Document.HistoryService.Pause()
            Try
                InitChart(m_ChartView.Document)
            Finally
                m_ChartView.Document.HistoryService.Resume()
            End Try

            ' Create and customize a chart command bar UI builder
            Dim commandBarBuilder As NChartCommandBarBuilder = New NChartCommandBarBuilder()

            ' Add the custom command action to the chart view's commander
            m_ChartView.Commander.Add(New CustomCommandAction())

            ' Remove the "Standard" toolbar and insert a custom one
            commandBarBuilder.ToolBarBuilders.Remove(NChartCommandBarBuilder.ToolBarStandardName)
            commandBarBuilder.ToolBarBuilders.Insert(0, New CustomToolBarBuilder())

            ' Create the commanding UI
            Dim chartViewWithRibbon As NCommandUIHolder = commandBarBuilder.CreateUI(m_ChartView)

            ' Remove the Open, Save and SaveAs commands
            chartViewWithRibbon.RemoveCommands(NChartView.OpenCommand, NChartView.SaveCommand, NChartView.SaveAsCommand)

            Return chartViewWithRibbon
        End Function
        Protected Overrides Function CreateExampleControls() As NWidget
            Return Nothing
        End Function
        Protected Overrides Function GetExampleDescription() As String
            Return "<p>This example demonstrates how to customize the NOV Chart command bars.</p>"
        End Function

        Private Sub InitChart(ByVal chartDocument As NChartDocument)
            Dim chartSurface = chartDocument.Content
            chartSurface.CreatePredefinedChart(ENPredefinedChartType.Cartesian)

            ' Set the title
            chartSurface.Titles(0).Text = "Chart Commanding Interface"

            ' Configure the chart
            Dim chart = CType(chartSurface.Charts(0), NCartesianChart)
            chart.Enable3D = True
            chart.Projection.SetPredefinedProjection(ENPredefinedProjection.Perspective)

            ' Add an interlace stripe
            Dim linearScale As NLinearScale = TryCast(chart.Axes(ENCartesianAxis.PrimaryY).Scale, NLinearScale)
            Dim strip As NScaleStrip = New NScaleStrip(New NColorFill(ENNamedColor.Beige), Nothing, True, 0, 0, 1, 1)
            strip.Interlaced = True
            linearScale.Strips.Add(strip)

            ' Add a bar series
            Dim random As Random = New Random()
            For i = 0 To 5
                Dim bar As NBarSeries = New NBarSeries()
                bar.Name = "Bar" & i.ToString()
                bar.MultiBarMode = ENMultiBarMode.Clustered
                bar.DataLabelStyle = New NDataLabelStyle(False)
                bar.ValueFormatter = New NNumericValueFormatter("0.###")
                chart.Series.Add(bar)

                For j = 0 To 5
                    bar.DataPoints.Add(New NBarDataPoint(random.Next(10, 100)))
                Next
            Next
        End Sub

#End Region

#Region "Fields"

        Private m_ChartView As NChartView

#End Region

#Region "Schema"

        ''' <summary>
        ''' Schema associated with NCommandBarsCustomizationExample.
        ''' </summary>
        Public Shared ReadOnly NCommandBarsCustomizationExampleSchema As NSchema

#End Region

#Region "Constants"

        Public Shared ReadOnly CustomCommand As NCommand = NCommand.Create(GetType(NCommandBarsCustomizationExample), "CustomCommand", "Custom Command")

#End Region

#Region "Nested Types"

        Public Class CustomToolBarBuilder
            Inherits NToolBarBuilder
            Public Sub New()
                MyBase.New("Custom Toolbar")
            End Sub

            Protected Overrides Sub AddItems(ByVal items As NCommandBarItemCollection)
                ' Add the "Open" button
                items.Add(MyBase.CreateButton(Presentation.NResources.Image_File_Open_png, NChartView.OpenCommand))

                ' Add the custom command button
                items.Add(CreateButton(NResources.Image_Ribbon_16x16_smiley_png, CustomCommand))
            End Sub
        End Class

        Public Class CustomCommandAction
            Inherits NChartCommandAction
#Region "Constructors"

            ''' <summary>
            ''' Default constructor.
            ''' </summary>
            Public Sub New()
            End Sub

            ''' <summary>
            ''' Static constructor.
            ''' </summary>
            Shared Sub New()
                CustomCommandActionSchema = NSchema.Create(GetType(CustomCommandAction), NChartCommandActionSchema)
            End Sub

#End Region

#Region "Public Overrides"

            ''' <summary>
            ''' Gets the command associated with this command action.
            ''' </summary>
            ''' <returns></returns>
            Public Overrides Function GetCommand() As NCommand
                Return CustomCommand
            End Function
            ''' <summary>
            ''' Executes the command action.
            ''' </summary>
            ''' <paramname="target"></param>
            ''' <paramname="parameter"></param>
            Public Overrides Sub Execute(ByVal target As NNode, ByVal parameter As Object)
                Dim chartView = GetChartView(target)

                NMessageBox.Show("Chart Custom Command executed!", "Custom Command", ENMessageBoxButtons.OK, ENMessageBoxIcon.Information)
            End Sub

#End Region

#Region "Schema"

            ''' <summary>
            ''' Schema associated with CustomCommandAction.
            ''' </summary>
            Public Shared ReadOnly CustomCommandActionSchema As NSchema

#End Region
        End Class

#End Region

    End Class
End Namespace

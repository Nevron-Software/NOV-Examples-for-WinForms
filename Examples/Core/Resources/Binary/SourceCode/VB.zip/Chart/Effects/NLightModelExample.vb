Imports System

Imports Nevron.Nov.Chart
Imports Nevron.Nov.Chart.Tools
Imports Nevron.Nov.Dom
Imports Nevron.Nov.Graphics
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.Chart
    ''' <summary>
    ''' Chart Light Model Example.
    ''' </summary>
    Public Class NLightModelExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' Default constructor
        ''' </summary>
        Public Sub New()

        End Sub
        ''' <summary>
        ''' Static constructor
        ''' </summary>
        Shared Sub New()
            NLightModelExampleSchema = NSchema.Create(GetType(NLightModelExample), NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            Dim chartViewWithCommandBars As NChartViewWithCommandBars = New NChartViewWithCommandBars()
            Dim chartView = chartViewWithCommandBars.View
            chartView.Surface.CreatePredefinedChart(ENPredefinedChartType.Cartesian)

            ' configure title
            chartView.Surface.Titles(0).Text = "Lighting in 3D"

            ' configure chart
            m_Chart = CType(chartView.Surface.Charts(0), NCartesianChart)

            m_Chart.Enable3D = True
            m_Chart.Projection.SetPredefinedProjection(ENPredefinedProjection.PerspectiveTilted)
            m_Chart.SetPredefinedCartesianAxes(ENPredefinedCartesianAxis.XYZLinear)
            m_Chart.Interactor = New NInteractor(New NTrackballTool())

            ' setup chart
            m_Chart.ModelWidth = 50
            m_Chart.ModelHeight = 50
            m_Chart.ModelDepth = 50

            ' setup X axis
            Dim axisX = m_Chart.Axes(ENCartesianAxis.PrimaryX)
            Dim scaleX As NLinearScale = New NLinearScale()
            scaleX.ViewRangeInflateMode = ENScaleViewRangeInflateMode.MajorTick
            axisX.Scale = scaleX

            ' setup Y axis
            Dim axisY = m_Chart.Axes(ENCartesianAxis.PrimaryY)
            Dim scaleY As NLinearScale = New NLinearScale()
            scaleY.MajorGridLines.ShowAtWalls = ENChartWall.NoneMask
            scaleY.ViewRangeInflateMode = ENScaleViewRangeInflateMode.MajorTick
            scaleY.MinTickDistance = 15
            axisY.Scale = scaleY

            ' setup Z axis
            Dim axisZ = m_Chart.Axes(ENCartesianAxis.Depth)
            Dim scaleZ As NLinearScale = New NLinearScale()
            scaleZ.ViewRangeInflateMode = ENScaleViewRangeInflateMode.MajorTick
            axisZ.Scale = scaleZ

            ' create chart series
            CreateBoxes(m_Chart)

            chartView.Document.StyleSheets.ApplyTheme(New NChartTheme(ENChartPalette.Bright, ENChartPaletteTarget.Series))

            Return chartViewWithCommandBars
        End Function
        Private Sub CreateBoxes(ByVal chart As NCartesianChart)
            Dim rangeSeries As NRangeSeries = New NRangeSeries()
            chart.Series.Add(rangeSeries)
            rangeSeries.DataLabelStyle = New NDataLabelStyle(False)
            rangeSeries.Shape = ENBarShape.Rectangle
            rangeSeries.InflateMargins = True
            rangeSeries.UseXValues = True
            rangeSeries.UseZValues = True

            Dim color = NColor.FromRGB(147, 120, 197)
            rangeSeries.Fill = New NColorFill(color)
            rangeSeries.Stroke = New NStroke(1, color)

            Dim barShapes = [Enum].GetValues(GetType(ENBarShape))
            For i = 0 To barShapes.Length - 1
                Dim size As Double = i * 5 + 5
                Dim center As Double = i * 20 + 10

                Dim dataPoint As NRangeDataPoint = New NRangeDataPoint(center - size, center - size, center - size, center + size, center + size, center + size)
                dataPoint.Shape = CType(barShapes.GetValue(i), ENBarShape)
                rangeSeries.DataPoints.Add(dataPoint)
            Next
        End Sub

        Protected Overrides Function CreateExampleControls() As NWidget
            Dim stack As NStackPanel = New NStackPanel()
            Dim boxGroup As NUniSizeBoxGroup = New NUniSizeBoxGroup(stack)

            Dim radioButtonGroup As NRadioButtonGroup = New NRadioButtonGroup()
            radioButtonGroup.Content = boxGroup

            ' Custom light model group
            Dim useCustomLightModelRadioButton As NRadioButton = New NRadioButton("Use Custom Light Model")
            stack.Add(useCustomLightModelRadioButton)
            m_CustomLightModelComboBox = New NComboBox()
            m_CustomLightModelComboBox.FillFromArray(New String() {"Directional Light", "Point Light", "Point Light in Camera Space", "Spot Light", "Multiple Light Sources"})
            stack.Add(NPairBox.Create("Custom Light Model:", m_CustomLightModelComboBox))

            ' predefined light model group
            Dim usePredefinedLightModelRadioButton As NRadioButton = New NRadioButton("Use Predefined Light Model")
            stack.Add(usePredefinedLightModelRadioButton)

            m_PredefinedLightModelComboBox = New NComboBox()
            m_PredefinedLightModelComboBox.FillFromEnum(Of ENPredefinedLightModel)()
            stack.Add(NPairBox.Create("Predefined Light Model:", m_PredefinedLightModelComboBox))

            Me.m_CustomLightModelComboBox.SelectedIndexChanged += AddressOf OnCustomLightModelComboBoxSelectedIndexChanged
            Me.m_PredefinedLightModelComboBox.SelectedIndexChanged += AddressOf OnPredefinedLightModelComboBoxSelectedIndexChanged
            useCustomLightModelRadioButton.CheckedChanged += AddressOf UseCustomLightModelRadioButton_CheckedChanged
            usePredefinedLightModelRadioButton.CheckedChanged += AddressOf UsePredefinedLightModelRadioButton_CheckedChanged

            useCustomLightModelRadioButton.Checked = True
            OnCustomLightModelComboBoxSelectedIndexChanged(Nothing)

            Return radioButtonGroup
        End Function

        Protected Overrides Function GetExampleDescription() As String
            Return "<p>This example demonstrates the chart lighting model. 
            The lighting model is a collection of light sources, each of which can emit light with different ambient, diffuse and specular color.
            There are three types of light sources:
</p>
            <ul>

            <li>Directional - directional light sources are treated as if they are located infinitely far away from the scene. 
            A directional light source has only a direction vector, but no location. 
            The effect of an infinite location is that the rays of light can be considered parallel by the time they reach an object. 
            An example of a real-world directional light source is the sun. Directional lights are rendered faster than point lights and spot lights.
            </li>

            <li>Point - point light sources have position but no direction, so they emit light equally in all directions. 
            Light intensity can attenuate with distance, so that objects located near a point light source get more illuminated than distant objects.
            </li>

            <li>Spot - spot light sources have both position and direction vectors. 
            They illuminate a part of the 3D scene that is enclosed by a cone. A real world example of a spot light is a desk lamp.
            </li>

            </ul>

<p>
            NOV Chart for .NET also features a large selection of predefined lighting sources, which are also demonstrated by this example.
            </p>" End Function

#End Region

#Region "Implementation"

        Private Sub ConfigureDirectionalLight()
            Dim light As NDirectionalLightSource = New NDirectionalLightSource()

            light.CoordinateMode = ENLightSourceCoordinateMode.Model
            light.Direction = New NVector3DF(-2, -4, -3)
            light.AmbientColor = NColor.FromRGB(60, 60, 60)
            light.DiffuseColor = NColor.FromRGB(230, 230, 230)
            light.SpecularColor = NColor.FromRGB(50, 50, 50)

            m_Chart.LightModel.LightSources.Clear()
            m_Chart.LightModel.LightSources.Add(light)
            m_Chart.LightModel.EnableLighting = True
            m_Chart.LightModel.LocalViewpointLighting = True
            m_Chart.LightModel.GlobalAmbientColor = NColor.FromRGB(60, 60, 60)
        End Sub
        Private Sub ConfigurePointLight()
            Dim light As NPointLightSource = New NPointLightSource()

            light.CoordinateMode = ENLightSourceCoordinateMode.Model
            light.Position = New NVector3DF(9, 36, 14)
            light.AmbientColor = NColor.FromRGB(100, 100, 100)
            light.DiffuseColor = NColor.FromRGB(210, 210, 210)
            light.SpecularColor = NColor.FromRGB(70, 70, 70)
            light.ConstantAttenuation = 0.6F
            light.LinearAttenuation = 0.004F
            light.QuadraticAttenuation = 0.0002F

            m_Chart.LightModel.LightSources.Clear()
            m_Chart.LightModel.LightSources.Add(light)
            m_Chart.LightModel.EnableLighting = True
            m_Chart.LightModel.LocalViewpointLighting = True
            m_Chart.LightModel.GlobalAmbientColor = NColor.FromRGB(60, 60, 60)
        End Sub
        Private Sub ConfigurePointLightInCameraSpace()
            Dim light As NPointLightSource = New NPointLightSource()

            light.CoordinateMode = ENLightSourceCoordinateMode.Camera
            light.Position = New NVector3DF(0, 0, 0)
            light.AmbientColor = NColor.FromRGB(100, 100, 100)
            light.DiffuseColor = NColor.FromRGB(210, 210, 210)
            light.SpecularColor = NColor.FromRGB(90, 90, 90)
            light.ConstantAttenuation = 0.3F
            light.LinearAttenuation = 0.0003F
            light.QuadraticAttenuation = 0.00003F

            m_Chart.LightModel.LightSources.Clear()
            m_Chart.LightModel.LightSources.Add(light)
            m_Chart.LightModel.EnableLighting = True
            m_Chart.LightModel.LocalViewpointLighting = True
            m_Chart.LightModel.GlobalAmbientColor = NColor.FromRGB(60, 60, 60)
        End Sub
        Private Sub ConfigureMultipleLightSources()
            Dim light1 As NPointLightSource = New NPointLightSource()
            light1.CoordinateMode = ENLightSourceCoordinateMode.Model
            light1.Position = New NVector3DF(0, 36, 16)
            light1.AmbientColor = NColor.FromRGB(60, 0, 0)
            light1.DiffuseColor = NColor.FromRGB(110, 20, 20)
            light1.SpecularColor = NColor.FromRGB(80, 60, 60)
            light1.ConstantAttenuation = 0.6F
            light1.LinearAttenuation = 0.004F
            light1.QuadraticAttenuation = 0.0002F

            Dim light2 As NPointLightSource = New NPointLightSource()
            light2.CoordinateMode = ENLightSourceCoordinateMode.Model
            light2.Position = New NVector3DF(13.85F, 36, -8)
            light2.AmbientColor = NColor.FromRGB(0, 60, 0)
            light2.DiffuseColor = NColor.FromRGB(20, 110, 20)
            light2.SpecularColor = NColor.FromRGB(60, 80, 60)
            light2.ConstantAttenuation = 0.6F
            light2.LinearAttenuation = 0.004F
            light2.QuadraticAttenuation = 0.0002F

            Dim light3 As NPointLightSource = New NPointLightSource()
            light3.CoordinateMode = ENLightSourceCoordinateMode.Model
            light3.Position = New NVector3DF(-13.85F, 36, -8)
            light3.AmbientColor = NColor.FromRGB(0, 0, 60)
            light3.DiffuseColor = NColor.FromRGB(20, 20, 110)
            light3.SpecularColor = NColor.FromRGB(60, 60, 80)
            light3.ConstantAttenuation = 0.6F
            light3.LinearAttenuation = 0.004F
            light3.QuadraticAttenuation = 0.0002F

            Dim light4 As NPointLightSource = New NPointLightSource()
            light4.CoordinateMode = ENLightSourceCoordinateMode.Camera
            light4.Position = New NVector3DF(0, 0, 0)
            light4.AmbientColor = NColor.FromRGB(0, 0, 0)
            light4.DiffuseColor = NColor.FromRGB(90, 90, 90)
            light4.SpecularColor = NColor.FromRGB(80, 80, 80)
            light4.ConstantAttenuation = 0.9F
            light4.LinearAttenuation = 0.0004F
            light4.QuadraticAttenuation = 0.0F

            m_Chart.LightModel.LightSources.Clear()
            m_Chart.LightModel.LightSources.Add(light1)
            m_Chart.LightModel.LightSources.Add(light2)
            m_Chart.LightModel.LightSources.Add(light3)
            m_Chart.LightModel.LightSources.Add(light4)
            m_Chart.LightModel.EnableLighting = True
            m_Chart.LightModel.LocalViewpointLighting = True
            m_Chart.LightModel.GlobalAmbientColor = NColor.FromRGB(60, 60, 60)
        End Sub
        Private Sub SpotLight(ByVal chart As NChart)
            Dim light As NSpotLightSource = New NSpotLightSource()

            light.CoordinateMode = ENLightSourceCoordinateMode.Model
            light.Position = New NVector3DF(14, 30, 14)
            light.Direction = New NVector3DF(-0.5F, -1, -0.4F)
            light.AmbientColor = NColor.FromRGB(50, 50, 50)
            light.DiffuseColor = NColor.FromRGB(180, 180, 210)
            light.SpecularColor = NColor.FromRGB(80, 80, 80)
            light.ConstantAttenuation = 0.3F
            light.LinearAttenuation = 0.001F
            light.QuadraticAttenuation = 0.0001F
            light.SpotCutoff = 45
            light.SpotExponent = 15

            chart.LightModel.LightSources.Clear()
            chart.LightModel.LightSources.Add(light)
            chart.LightModel.EnableLighting = True
            chart.LightModel.LocalViewpointLighting = True
            chart.LightModel.GlobalAmbientColor = NColor.FromRGB(100, 100, 100)
        End Sub

#End Region

#Region "Event Handlers"

        Private Sub OnCustomLightModelComboBoxSelectedIndexChanged(ByVal arg As NValueChangeEventArgs)
            Select Case m_CustomLightModelComboBox.SelectedIndex
                Case 0
                    ConfigureDirectionalLight()

                Case 1
                    ConfigurePointLight()

                Case 2
                    ConfigurePointLightInCameraSpace()

                Case 3
                    SpotLight(m_Chart)

                Case 4
                    ConfigureMultipleLightSources()
            End Select
        End Sub
        Private Sub OnPredefinedLightModelComboBoxSelectedIndexChanged(ByVal arg As NValueChangeEventArgs)
            Dim lm As ENPredefinedLightModel = m_PredefinedLightModelComboBox.SelectedIndex

            m_Chart.LightModel.SetPredefinedLightModel(lm)
        End Sub

        Private Sub UsePredefinedLightModelRadioButton_CheckedChanged(ByVal arg As NValueChangeEventArgs)
            m_CustomLightModelComboBox.Enabled = False
            m_PredefinedLightModelComboBox.Enabled = True

            OnPredefinedLightModelComboBoxSelectedIndexChanged(Nothing)
        End Sub

        Private Sub UseCustomLightModelRadioButton_CheckedChanged(ByVal arg As NValueChangeEventArgs)
            m_CustomLightModelComboBox.Enabled = True
            m_PredefinedLightModelComboBox.Enabled = False

            OnPredefinedLightModelComboBoxSelectedIndexChanged(Nothing)
        End Sub

#End Region

#Region "Fields"

        Private m_Chart As NCartesianChart
        Private m_CustomLightModelComboBox As NComboBox
        Private m_PredefinedLightModelComboBox As NComboBox

#End Region

#Region "Schema"

        Public Shared ReadOnly NLightModelExampleSchema As NSchema

#End Region
    End Class
End Namespace

Imports System

Imports Nevron.Nov.Chart
Imports Nevron.Nov.Chart.Tools
Imports Nevron.Nov.Dom
Imports Nevron.Nov.Graphics
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.Chart
    ''' <summary>
    ''' Grid Surface Example
    ''' </summary>
    Public Class NGridSurfaceExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' Default constructor
        ''' </summary>
        Public Sub New()

        End Sub
        ''' <summary>
        ''' Static constructor
        ''' </summary>
        Shared Sub New()
            NGridSurfaceExampleSchema = NSchema.Create(GetType(NGridSurfaceExample), NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            Dim chartViewWithCommandBars As NChartViewWithCommandBars = New NChartViewWithCommandBars()
            Dim chartView = chartViewWithCommandBars.View
            chartView.Surface.CreatePredefinedChart(ENPredefinedChartType.Cartesian)

            ' configure title
            chartView.Surface.Titles(0).Text = "Grid Surface Chart"

            ' setup chart
            Dim chart = CType(chartView.Surface.Charts(0), NCartesianChart)
            chart.Enable3D = True
            chart.ModelWidth = 60.0F
            chart.ModelDepth = 60.0F
            chart.ModelHeight = 25.0F
            chart.Projection.SetPredefinedProjection(ENPredefinedProjection.PerspectiveTilted)
            chart.LightModel.SetPredefinedLightModel(ENPredefinedLightModel.ShinyTopLeft)
            chart.Interactor = New NInteractor(New NTrackballTool())

            Dim scale As NLinearScale = chart.Axes(ENCartesianAxis.PrimaryY).Scale
            scale.ViewRangeInflateMode = ENScaleViewRangeInflateMode.None

            ' setup axes
            Dim ordinalScale As NOrdinalScale = chart.Axes(ENCartesianAxis.PrimaryX).Scale
            ordinalScale.MajorGridLines.SetShowAtWall(ENChartWall.Bottom, True)
            ordinalScale.MajorGridLines.SetShowAtWall(ENChartWall.Back, True)
            ordinalScale.DisplayDataPointsBetweenTicks = False

            ordinalScale = chart.Axes(ENCartesianAxis.Depth).Scale
            ordinalScale.MajorGridLines.SetShowAtWall(ENChartWall.Bottom, True)
            ordinalScale.MajorGridLines.SetShowAtWall(ENChartWall.Left, True)
            ordinalScale.DisplayDataPointsBetweenTicks = False

            ' add the surface series
            m_Surface = New NGridSurfaceSeries()
            chart.Series.Add(m_Surface)

            m_Surface.Name = "Surface"
            m_Surface.LegendView.Mode = ENSeriesLegendMode.SeriesLogic
            m_Surface.FlatPositionValue = 10.0
            m_Surface.Data.HasColor = True
            m_Surface.Data.SetGridSize(100, 100)
            m_Surface.Palette.InterpolateColors = False

            m_Surface.ValueFormatter = New NNumericValueFormatter("0.00")
            m_Surface.Fill = New NColorFill(NColor.YellowGreen)

            m_Surface.FillMode = ENSurfaceFillMode.Zone
            m_Surface.FrameMode = ENSurfaceFrameMode.Contour
            m_Surface.FrameColorMode = ENSurfaceFrameColorMode.Uniform

            m_Surface.LegendView.Mode = ENSeriesLegendMode.SeriesLogic
            chartView.Surface.Legends(0).Visibility = ENVisibility.Visible

            FillData(m_Surface)

            Return chartViewWithCommandBars
        End Function

        Private Sub FillData(ByVal surface As NGridSurfaceSeries)
            Dim y, x, z As Double
            Dim nCountX = surface.Data.GridSizeX
            Dim nCountZ = surface.Data.GridSizeZ

            Const dIntervalX = 30.0
            Const dIntervalZ = 30.0
            Dim dIncrementX = dIntervalX / nCountX
            Dim dIncrementZ = dIntervalZ / nCountZ

            Dim semiWidth As Single = Math.Min(nCountX / 2, nCountZ / 2)

            Dim startColor = NColor.Red
            Dim endColor = NColor.Green

            Dim centerX As Integer = nCountX / 2
            Dim centerZ As Integer = nCountZ / 2

            z = -(dIntervalZ / 2)

            Dim j = 0

            While j < nCountZ
                x = -(dIntervalX / 2)

                Dim i = 0

                While i < nCountX
                    y = x * z / 64.0 - Math.Sin(z / 2.4) * Math.Cos(x / 2.4)
                    y = 10 * Math.Sqrt(Math.Abs(y))

                    If y <= 0 Then
                        y = 1 + Math.Cos(x / 2.4)
                    End If

                    surface.Data.SetValue(i, j, y)

                    Dim dx = centerX - i
                    Dim dz = centerZ - j
                    Dim factor As Double = CSng(Math.Sqrt(dx * dx + dz * dz)) / semiWidth

                    If factor > 1 Then
                        factor = 1
                    End If

                    surface.Data.SetColor(i, j, NColor.InterpolateColors(startColor, endColor, factor))
                    i += 1
                    x += dIncrementX
                End While

                j += 1
                z += dIncrementZ
            End While
        End Sub

        Protected Overrides Function CreateExampleControls() As NWidget
            Dim stack As NStackPanel = New NStackPanel()
            Dim group As NUniSizeBoxGroup = New NUniSizeBoxGroup(stack)

            Dim fillModeCombo As NComboBox = New NComboBox()
            fillModeCombo.FillFromEnum(Of ENSurfaceFillMode)()
            fillModeCombo.SelectedIndexChanged += AddressOf OnFillModeComboSelectedIndexChanged
            fillModeCombo.SelectedIndex = m_Surface.FillMode
            stack.Add(NPairBox.Create("Fill Mode:", fillModeCombo))

            Dim frameModeCombo As NComboBox = New NComboBox()
            frameModeCombo.FillFromEnum(Of ENSurfaceFrameMode)()
            frameModeCombo.SelectedIndexChanged += AddressOf OnFrameModeComboSelectedIndexChanged
            frameModeCombo.SelectedIndex = m_Surface.FrameMode
            stack.Add(NPairBox.Create("Frame Mode:", frameModeCombo))

            Dim frameColorModeCombo As NComboBox = New NComboBox()
            frameColorModeCombo.FillFromEnum(Of ENSurfaceFrameColorMode)()
            frameColorModeCombo.SelectedIndexChanged += AddressOf OnFrameColorModeComboSelectedIndexChanged
            frameColorModeCombo.SelectedIndex = m_Surface.FrameColorMode
            stack.Add(NPairBox.Create("Frame Color Mode:", frameColorModeCombo))

            Dim smoothShadingCheckBox As NCheckBox = New NCheckBox()
            smoothShadingCheckBox.CheckedChanged += AddressOf OnSmoothShadingCheckBoxCheckedChanged
            smoothShadingCheckBox.Checked = False
            smoothShadingCheckBox.HorizontalPlacement = Layout.ENHorizontalPlacement.Left
            stack.Add(NPairBox.Create("Smooth Shading:", smoothShadingCheckBox))

            Dim drawFlatCheckBox As NCheckBox = New NCheckBox()
            drawFlatCheckBox.CheckedChanged += AddressOf OnDrawFlatCheckBoxCheckedChanged
            drawFlatCheckBox.Checked = False
            drawFlatCheckBox.HorizontalPlacement = Layout.ENHorizontalPlacement.Left
            stack.Add(NPairBox.Create("Draw Flat:", drawFlatCheckBox))

            Return group
        End Function

        Private Sub OnDrawFlatCheckBoxCheckedChanged(ByVal arg As NValueChangeEventArgs)
            m_Surface.DrawFlat = CBool(arg.NewValue)
        End Sub

        Private Sub OnFrameColorModeComboSelectedIndexChanged(ByVal arg As NValueChangeEventArgs)
            m_Surface.FrameColorMode = CType(arg.NewValue, ENSurfaceFrameColorMode)
        End Sub

        Private Sub OnSmoothShadingCheckBoxCheckedChanged(ByVal arg As NValueChangeEventArgs)
            m_Surface.ShadingMode = If(arg.NewValue, ENShadingMode.Smooth, ENShadingMode.Flat)
        End Sub

        Private Sub OnFrameModeComboSelectedIndexChanged(ByVal arg As NValueChangeEventArgs)
            m_Surface.FrameMode = CType(arg.NewValue, ENSurfaceFrameMode)

            If m_Surface.FrameMode Is ENSurfaceFrameMode.Dots Then
                m_Surface.Stroke = New NStroke(3, NColor.Black)
            Else
                m_Surface.Stroke = New NStroke(1, NColor.Black)
            End If
        End Sub

        Private Sub OnFillModeComboSelectedIndexChanged(ByVal arg As NValueChangeEventArgs)
            m_Surface.FillMode = CType(arg.NewValue, ENSurfaceFillMode)
        End Sub

        Protected Overrides Function GetExampleDescription() As String
            Return "<p>This example demonstrates how to create a scatter funnel chart.</p>"
        End Function

#End Region

#Region "Fields"

        Private m_Surface As NGridSurfaceSeries

#End Region

#Region "Schema"

        Public Shared ReadOnly NGridSurfaceExampleSchema As NSchema

#End Region
    End Class
End Namespace

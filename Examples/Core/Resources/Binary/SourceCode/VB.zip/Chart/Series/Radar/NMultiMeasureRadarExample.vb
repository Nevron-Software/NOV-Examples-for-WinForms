Imports Nevron.Nov.Chart
Imports Nevron.Nov.Dom
Imports Nevron.Nov.Graphics
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.Chart
    ''' <summary>
    ''' Multi Measure Radar example
    ''' </summary>
    Public Class NMultiMeasureRadarExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' Default constructor
        ''' </summary>
        Public Sub New()

        End Sub
        ''' <summary>
        ''' Static constructor
        ''' </summary>
        Shared Sub New()
            NMultiMeasureRadarExampleSchema = NSchema.Create(GetType(NMultiMeasureRadarExample), NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            Dim chartViewWithCommandBars As NChartViewWithCommandBars = New NChartViewWithCommandBars()
            Dim chartView = chartViewWithCommandBars.View
            chartView.Surface.CreatePredefinedChart(ENPredefinedChartType.Radar)

            ' configure title
            chartView.Surface.Titles(0).Text = "Radar Axis Titles"

            ' configure chart
            m_Chart = CType(chartView.Surface.Charts(0), NRadarChart)

            m_Chart.RadarMode = ENRadarMode.MultiMeasure
            m_Chart.InnerRadius = 60

            ' set some axis labels
            AddAxis(m_Chart, "Population", True)
            AddAxis(m_Chart, "Housing Units", True)
            AddAxis(m_Chart, "Water", False)
            AddAxis(m_Chart, "Land", True)
            AddAxis(m_Chart, "Population" & vbCrLf & "Density", False)
            AddAxis(m_Chart, "Housing" & vbCrLf & "Density", False)

            ' sample data
            Dim data = New Object() {"Cascade County", 80357, 35225, 13.75, 2697.90, 29.8, 13.1, "Custer County", 11696, 5360, 10.09, 3783.13, 3.1, 1.4, "Dawson County", 9059, 4168, 9.99, 2373.14, 3.8, 1.8, "Jefferson County", 10049, 4199, 2.19, 1656.64, 6.1, 2.5, "Missoula County", 95802, 41319, 20.37, 2597.97, 36.9, 15.9, "Powell County", 7180, 2930, 6.74, 2325.94, 3.1, 1.3}

            Dim palette As NColor() = NChartPalette.BrightPalette

            For i = 0 To 5
                Dim radarLine As NRadarLineSeries = New NRadarLineSeries()
                m_Chart.Series.Add(radarLine)

                Dim baseIndex = i * 7
                radarLine.Name = data(baseIndex).ToString()
                baseIndex = baseIndex + 1

                For j = 0 To 5
                    radarLine.DataPoints.Add(New NRadarLineDataPoint(Convert.ToDouble(data(baseIndex))))
                    baseIndex = baseIndex + 1
                Next

                radarLine.DataLabelStyle = New NDataLabelStyle(False)

                Dim markerStyle As NMarkerStyle = New NMarkerStyle()
                markerStyle.Size = New NSize(4, 4)
                markerStyle.Visible = True
                markerStyle.Fill = New NColorFill(palette(i))
                radarLine.MarkerStyle = markerStyle

                radarLine.Stroke = New NStroke(2, palette(i))
            Next

            chartView.Document.StyleSheets.ApplyTheme(New NChartTheme(ENChartPalette.Bright, ENChartPaletteTarget.Series))

            Return chartViewWithCommandBars
        End Function
        Protected Overrides Function CreateExampleControls() As NWidget
            Dim stack As NStackPanel = New NStackPanel()
            Dim group As NUniSizeBoxGroup = New NUniSizeBoxGroup(stack)
            Return group
        End Function
        Protected Overrides Function GetExampleDescription() As String
            Return "<p>This example demonstrates how to create a multi measure radar chart.</p>"
        End Function

#End Region

#Region "Event Handlers"



#End Region

#Region "Implementation"

        Private Sub AddAxis(ByVal radar As NRadarChart, ByVal title As String, ByVal applyKFormatting As Boolean)
            Dim axis As NRadarAxis = New NRadarAxis()

            ' set title
            axis.Title = title
            radar.Axes.Add(axis)

            Dim linearScale As NLinearScale = TryCast(axis.Scale, NLinearScale)
            linearScale.MajorGridLines.Visible = False

            If applyKFormatting Then
                linearScale.Labels.TextProvider = New NFormattedScaleLabelTextProvider(New NNumericValueFormatter("0,K"))
            End If
        End Sub

#End Region

#Region "Fields"

        Private m_Chart As NRadarChart

#End Region

#Region "Schema"

        Public Shared ReadOnly NMultiMeasureRadarExampleSchema As NSchema

#End Region
    End Class
End Namespace

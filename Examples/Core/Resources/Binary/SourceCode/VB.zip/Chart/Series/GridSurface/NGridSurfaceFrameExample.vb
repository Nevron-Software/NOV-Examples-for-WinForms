Imports System

Imports Nevron.Nov.Chart
Imports Nevron.Nov.Chart.Tools
Imports Nevron.Nov.Dom
Imports Nevron.Nov.Graphics
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.Chart
    ''' <summary>
    ''' Grid Frame Example
    ''' </summary>
    Public Class NGridSurfaceFrameExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' Default constructor
        ''' </summary>
        Public Sub New()

        End Sub
        ''' <summary>
        ''' Static constructor
        ''' </summary>
        Shared Sub New()
            NGridSurfaceFrameExampleSchema = NSchema.Create(GetType(NGridSurfaceFrameExample), NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            Dim chartViewWithCommandBars As NChartViewWithCommandBars = New NChartViewWithCommandBars()
            Dim chartView = chartViewWithCommandBars.View
            chartView.Surface.CreatePredefinedChart(ENPredefinedChartType.Cartesian)

            ' configure title
            chartView.Surface.Titles(0).Text = "Grid Surface Wireframe"

            m_Chart = CType(chartView.Surface.Charts(0), NCartesianChart)
            m_Chart.Interactor = New NInteractor(New NTrackballTool())
            m_Chart.Projection.SetPredefinedProjection(ENPredefinedProjection.PerspectiveTilted)
            m_Chart.Enable3D = True
            m_Chart.ModelWidth = 60.0F
            m_Chart.ModelDepth = 60.0F
            m_Chart.ModelHeight = 25.0F

            ' setup axes
            Dim ordinalScaleX As NOrdinalScale = New NOrdinalScale()
            m_Chart.Axes(ENCartesianAxis.PrimaryX).Scale = ordinalScaleX
            ordinalScaleX.MajorGridLines.SetShowAtWall(ENChartWall.Bottom, True)
            ordinalScaleX.MajorGridLines.SetShowAtWall(ENChartWall.Back, True)
            ordinalScaleX.DisplayDataPointsBetweenTicks = False

            Dim ordinalScaleY As NOrdinalScale = New NOrdinalScale()
            m_Chart.Axes(ENCartesianAxis.Depth).Scale = ordinalScaleY
            ordinalScaleY.MajorGridLines.SetShowAtWall(ENChartWall.Bottom, True)
            ordinalScaleY.MajorGridLines.SetShowAtWall(ENChartWall.Left, True)
            ordinalScaleY.DisplayDataPointsBetweenTicks = False

            ' add the surface series
            m_Surface = New NGridSurfaceSeries()
            m_Chart.Series.Add(m_Surface)
            m_Surface.Name = "Surface"
            m_Surface.FillMode = ENSurfaceFillMode.None
            m_Surface.FrameMode = ENSurfaceFrameMode.Mesh
            m_Surface.Data.HasColor = True
            m_Surface.Data.SetGridSize(30, 30)

            FillData(m_Surface)

            Return chartViewWithCommandBars
        End Function

        Private Sub FillData(ByVal surface As NGridSurfaceSeries)
            Dim y, x, z As Double
            Dim nCountX = surface.Data.GridSizeX
            Dim nCountZ = surface.Data.GridSizeZ

            Const dIntervalX = 30.0
            Const dIntervalZ = 30.0
            Dim dIncrementX = dIntervalX / nCountX
            Dim dIncrementZ = dIntervalZ / nCountZ

            z = -(dIntervalZ / 2)

            Dim semiWidth As Single = Math.Min(nCountX / 2, nCountZ / 2)
            Dim centerX As Integer = nCountX / 2
            Dim centerZ As Integer = nCountZ / 2
            Dim startColor = NColor.Red
            Dim endColor = NColor.Green

            Dim j = 0

            While j < nCountZ
                x = -(dIntervalX / 2)

                Dim i = 0

                While i < nCountX
                    y = x * z / 64.0 - Math.Sin(z / 2.4) * Math.Cos(x / 2.4)
                    y = 10 * Math.Sqrt(Math.Abs(y))

                    If y <= 0 Then
                        y = 1 + Math.Cos(x / 2.4)
                    End If

                    surface.Data.SetValue(i, j, y)

                    Dim dx = centerX - i
                    Dim dz = centerZ - j
                    Dim distance As Single = Math.Sqrt(dx * dx + dz * dz)
                    surface.Data.SetColor(i, j, InterpolateColors(startColor, endColor, distance / semiWidth))
                    i += 1
                    x += dIncrementX
                End While

                j += 1
                z += dIncrementZ
            End While
        End Sub

        Public Shared Function InterpolateColors(ByVal color1 As NColor, ByVal color2 As NColor, ByVal factor As Single) As NColor
            If factor > 1.0F Then
                factor = 1.0F
            ElseIf factor < 0.0 Then
                factor = 0.0F
            End If

            Dim r1 As Integer = color1.R
            Dim g1 As Integer = color1.G
            Dim b1 As Integer = color1.B

            Dim r2 As Integer = color2.R
            Dim g2 As Integer = color2.G
            Dim b2 As Integer = color2.B

            Dim num7 As Byte = r1 + (r2 - r1) * factor
            Dim num8 As Byte = g1 + (g2 - g1) * factor
            Dim num9 As Byte = b1 + (b2 - b1) * factor

            Return NColor.FromRGB(num7, num8, num9)
        End Function

        Protected Overrides Function CreateExampleControls() As NWidget
            Dim stack As NStackPanel = New NStackPanel()
            Dim group As NUniSizeBoxGroup = New NUniSizeBoxGroup(stack)

            Dim frameModeComboBox As NComboBox = New NComboBox()
            frameModeComboBox.FillFromEnum(Of ENSurfaceFrameMode)()
            frameModeComboBox.SelectedIndexChanged += AddressOf OnFrameModeComboBoxSelectedIndexChanged
            frameModeComboBox.SelectedIndex = m_Surface.FrameMode
            stack.Add(NPairBox.Create("Frame Mode:", frameModeComboBox))

            Dim frameColorModeComboBox As NComboBox = New NComboBox()
            frameColorModeComboBox.FillFromEnum(Of ENSurfaceFrameColorMode)()
            frameColorModeComboBox.SelectedIndexChanged += AddressOf OnFrameColorModeComboBoxSelectedIndexChanged
            frameColorModeComboBox.SelectedIndex = m_Surface.FrameColorMode
            stack.Add(NPairBox.Create("Frame Color Mode:", frameColorModeComboBox))

            Return group
        End Function

        Private Sub OnFrameColorModeComboBoxSelectedIndexChanged(ByVal arg As NValueChangeEventArgs)
            m_Surface.FrameColorMode = CType(arg.NewValue, ENSurfaceFrameColorMode)
        End Sub

        Private Sub OnFrameModeComboBoxSelectedIndexChanged(ByVal arg As NValueChangeEventArgs)
            m_Surface.FrameMode = CType(arg.NewValue, ENSurfaceFrameMode)

            If m_Surface.FrameMode Is ENSurfaceFrameMode.Dots Then
                m_Surface.Stroke = New NStroke(3, NColor.Black)
            Else
                m_Surface.Stroke = New NStroke(1, NColor.Black)
            End If
        End Sub

        Protected Overrides Function GetExampleDescription() As String
            Return "<p>This example demonstrates different settings for the surface frame.</p>"
        End Function

#End Region

#Region "Fields"

        Private m_Chart As NCartesianChart
        Private m_Surface As NGridSurfaceSeries

#End Region

#Region "Schema"

        Public Shared ReadOnly NGridSurfaceFrameExampleSchema As NSchema

#End Region
    End Class
End Namespace

Imports Nevron.Nov.Chart
Imports Nevron.Nov.Chart.Tools
Imports Nevron.Nov.Dom
Imports Nevron.Nov.Graphics
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.Chart
    ''' <summary>
    ''' Standard 3D Pie Example
    ''' </summary>
    Public Class NStandardPie3DExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' Default constructor
        ''' </summary>
        Public Sub New()

        End Sub
        ''' <summary>
        ''' Static constructor
        ''' </summary>
        Shared Sub New()
            NStandardPie3DExampleSchema = NSchema.Create(GetType(NStandardPie3DExample), NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            Dim chartViewWithCommandBars As NChartViewWithCommandBars = New NChartViewWithCommandBars()
            Dim chartView = chartViewWithCommandBars.View
            chartView.Surface.CreatePredefinedChart(ENPredefinedChartType.Pie)

            ' configure title
            chartView.Surface.Titles(0).Text = "Standard Pie"

            ' configure chart
            m_PieChart = CType(chartView.Surface.Charts(0), NPieChart)

            m_PieSeries = New NPieSeries()
            m_PieChart.Series.Add(m_PieSeries)
            m_PieChart.DockSpiderLabelsToSides = True
            m_PieChart.Enable3D = True
            m_PieChart.LightModel.SetPredefinedLightModel(ENPredefinedLightModel.BrightCameraLight)
            m_PieChart.Projection.SetPredefinedProjection(ENPredefinedProjection.PerspectiveElevated)
            m_PieChart.Interactor = New NInteractor(New NTrackballTool())

            Dim dataLabelStyle As NDataLabelStyle = New NDataLabelStyle()
            dataLabelStyle.ArrowLength = 15
            dataLabelStyle.ArrowPointerLength = 0
            m_PieSeries.DataLabelStyle = dataLabelStyle

            m_PieSeries.LabelMode = ENPieLabelMode.Spider
            m_PieSeries.LegendView.Mode = ENSeriesLegendMode.DataPoints
            m_PieSeries.LegendView.Format = "<label> <percent>"

            m_PieSeries.DataPoints.Add(New NPieDataPoint(24, "Cars"))
            m_PieSeries.DataPoints.Add(New NPieDataPoint(18, "Airplanes"))
            m_PieSeries.DataPoints.Add(New NPieDataPoint(32, "Trains"))
            m_PieSeries.DataPoints.Add(New NPieDataPoint(23, "Ships"))
            m_PieSeries.DataPoints.Add(New NPieDataPoint(19, "Buses"))

            For i = 0 To m_PieSeries.DataPoints.Count - 1
                m_PieSeries.DataPoints(i).Tooltip = New NTooltip("This is a test tooltip for dataPoint [" & i.ToString() & "]")
            Next

            ' detach airplanes
            m_PieSeries.DataPoints(1).DetachmentPercent = 10

            chartView.Document.StyleSheets.ApplyTheme(New NChartTheme(ENChartPalette.Bright, ENChartPaletteTarget.DataPoints))

            Return chartViewWithCommandBars
        End Function
        Protected Overrides Function CreateExampleControls() As NWidget
            Dim stack As NStackPanel = New NStackPanel()
            Dim group As NUniSizeBoxGroup = New NUniSizeBoxGroup(stack)

            Dim beginAngleUpDown As NNumericUpDown = New NNumericUpDown()
            beginAngleUpDown.Value = m_PieChart.BeginAngle
            beginAngleUpDown.ValueChanged += AddressOf OnBeginAngleUpDownValueChanged
            stack.Add(NPairBox.Create("Begin Angle:", beginAngleUpDown))

            Dim sweepAngleUpDown As NNumericUpDown = New NNumericUpDown()
            sweepAngleUpDown.Value = m_PieChart.SweepAngle
            sweepAngleUpDown.Minimum = -360
            sweepAngleUpDown.Maximum = 360
            sweepAngleUpDown.ValueChanged += AddressOf OnSweepAngleUpDownValueChanged
            stack.Add(NPairBox.Create("Sweep Angle:", sweepAngleUpDown))

            Dim beginRadiusPercentUpDown As NNumericUpDown = New NNumericUpDown()
            beginRadiusPercentUpDown.Value = m_PieSeries.BeginRadiusPercent
            beginRadiusPercentUpDown.ValueChanged += AddressOf OnBeginRadiusPercentValueChanged
            stack.Add(NPairBox.Create("Begin Radius %:", beginRadiusPercentUpDown))
            beginRadiusPercentUpDown.Value = 30

            Dim endRadiusPercentUpDown As NNumericUpDown = New NNumericUpDown()
            endRadiusPercentUpDown.Value = m_PieSeries.EndRadiusPercent
            endRadiusPercentUpDown.ValueChanged += AddressOf OnEndRadiusPercentValueChanged
            stack.Add(NPairBox.Create("End Radius %:", endRadiusPercentUpDown))

            Dim pieShapeComboBox As NComboBox = New NComboBox()
            pieShapeComboBox.FillFromEnum(Of ENPieSegmentShape)()
            pieShapeComboBox.SelectedIndexChanged += AddressOf OnPieShapeComboBoxSelectedIndexChanged
            stack.Add(NPairBox.Create("Pie Shape:", pieShapeComboBox))
            pieShapeComboBox.SelectedIndex = CInt(ENPieSegmentShape.SmoothEdgePie)

            Dim pieEdgePercentUpDown As NNumericUpDown = New NNumericUpDown()
            stack.Add(NPairBox.Create("Pie Edge Percent:", pieEdgePercentUpDown))
            pieEdgePercentUpDown.ValueChanged += AddressOf OnPieEdgePercentUpDownValueChanged

            Dim pieLabelMode As NComboBox = New NComboBox()
            pieLabelMode.FillFromEnum(Of ENPieLabelMode)()
            pieLabelMode.SelectedIndexChanged += AddressOf OnPieLabelModeSelectedIndexChanged
            stack.Add(NPairBox.Create("Pie Label Mode:", pieLabelMode))
            pieLabelMode.SelectedIndex = CInt(ENPieLabelMode.Spider)

            Return group
        End Function

        Protected Overrides Function GetExampleDescription() As String
            Return "<p>This example demonstrates how to create a standard pie chart.</p>"
        End Function

#End Region

#Region "Event Handlers"

        Private Sub OnBeginAngleUpDownValueChanged(ByVal arg As NValueChangeEventArgs)
            m_PieChart.BeginAngle = CType(arg.TargetNode, NNumericUpDown).Value
        End Sub

        Private Sub OnSweepAngleUpDownValueChanged(ByVal arg As NValueChangeEventArgs)
            m_PieChart.SweepAngle = CType(arg.TargetNode, NNumericUpDown).Value
        End Sub

        Private Sub OnPieShapeComboBoxSelectedIndexChanged(ByVal arg As NValueChangeEventArgs)
            m_PieSeries.PieSegmentShape = CType(CType(arg.TargetNode, NComboBox).SelectedIndex, ENPieSegmentShape)
        End Sub

        Private Sub OnPieEdgePercentUpDownValueChanged(ByVal arg As NValueChangeEventArgs)
            m_PieSeries.PieEdgePercent = CSng(CType(arg.TargetNode, NNumericUpDown).Value)
        End Sub

        Private Sub OnPieLabelModeSelectedIndexChanged(ByVal arg As NValueChangeEventArgs)
            m_PieSeries.LabelMode = CType(CType(arg.TargetNode, NComboBox).SelectedIndex, ENPieLabelMode)
        End Sub

        Private Sub OnBeginRadiusPercentValueChanged(ByVal arg As NValueChangeEventArgs)
            m_PieSeries.BeginRadiusPercent = CType(arg.TargetNode, NNumericUpDown).Value
        End Sub

        Private Sub OnEndRadiusPercentValueChanged(ByVal arg As NValueChangeEventArgs)
            m_PieSeries.EndRadiusPercent = CType(arg.TargetNode, NNumericUpDown).Value
        End Sub

#End Region

#Region "Fields"

        Private m_PieSeries As NPieSeries
        Private m_PieChart As NPieChart

#End Region

#Region "Schema"

        Public Shared ReadOnly NStandardPie3DExampleSchema As NSchema

#End Region
    End Class
End Namespace

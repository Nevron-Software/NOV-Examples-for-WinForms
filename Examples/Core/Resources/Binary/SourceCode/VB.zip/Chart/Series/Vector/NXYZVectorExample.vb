Imports System

Imports Nevron.Nov.Chart
Imports Nevron.Nov.Chart.Tools
Imports Nevron.Nov.Dom
Imports Nevron.Nov.Graphics
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.Chart
    ''' <summary>
    ''' Standard Vector Example
    ''' </summary>
    Public Class NXYZVectorExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' Default constructor
        ''' </summary>
        Public Sub New()

        End Sub
        ''' <summary>
        ''' Static constructor
        ''' </summary>
        Shared Sub New()
            NXYZVectorExampleSchema = NSchema.Create(GetType(NXYZVectorExample), NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            Dim chartViewWithCommandBars As NChartViewWithCommandBars = New NChartViewWithCommandBars()
            Dim chartView = chartViewWithCommandBars.View
            chartView.Surface.CreatePredefinedChart(ENPredefinedChartType.Cartesian)

            ' configure title
            chartView.Surface.Titles(0).Text = "Standard Vector"

            ' configure chart
            Dim chart = CType(chartView.Surface.Charts(0), NCartesianChart)

            chart.Enable3D = True

            chart.Enable3D = True
            chart.Projection.SetPredefinedProjection(ENPredefinedProjection.PerspectiveTilted)
            chart.LightModel.SetPredefinedLightModel(ENPredefinedLightModel.BrightCameraLight)
            chart.ModelDepth = 55.0F
            chart.ModelWidth = 55.0F
            chart.ModelHeight = 55.0F
            chart.SetPredefinedCartesianAxes(ENPredefinedCartesianAxis.XYZLinear)
            chart.Interactor = New NInteractor(New NTrackballTool())

            ' setup X axis
            If True Then
                Dim scaleX As NLinearScale = chart.Axes(ENCartesianAxis.PrimaryX).Scale
                scaleX.MajorGridLines.SetShowAtWall(ENChartWall.Back, True)
                scaleX.MajorGridLines.SetShowAtWall(ENChartWall.Bottom, True)
                scaleX.MajorGridLines.Stroke.DashStyle = ENDashStyle.Dot
            End If

            ' setup Y axis
            If True Then
                Dim scaleY As NLinearScale = chart.Axes(ENCartesianAxis.PrimaryY).Scale
                scaleY.MajorGridLines.SetShowAtWall(ENChartWall.Back, True)
                scaleY.MajorGridLines.SetShowAtWall(ENChartWall.Left, True)
                scaleY.MajorGridLines.Stroke.DashStyle = ENDashStyle.Dot

                ' add interlaced stripe
                Dim stripStyle As NScaleStrip = New NScaleStrip(New NColorFill(NColor.Beige), Nothing, True, 0, 0, 1, 1)
                stripStyle.SetShowAtWall(ENChartWall.Back, True)
                stripStyle.SetShowAtWall(ENChartWall.Left, True)
                stripStyle.Interlaced = True
                scaleY.Strips.Add(stripStyle)
            End If

            ' setup Depth axis
            If True Then
                Dim scaleZ As NLinearScale = chart.Axes(ENCartesianAxis.Depth).Scale
                scaleZ.MajorGridLines.SetShowAtWall(ENChartWall.Left, True)
                scaleZ.MajorGridLines.SetShowAtWall(ENChartWall.Bottom, True)
                scaleZ.MajorGridLines.Stroke.DashStyle = ENDashStyle.Dot
            End If

            ' setup X axis
            Dim linearScale As NLinearScale = New NLinearScale()
            chart.Axes(ENCartesianAxis.PrimaryX).Scale = linearScale

            ' setup Y axis
            linearScale = New NLinearScale()
            chart.Axes(ENCartesianAxis.PrimaryY).Scale = linearScale

            ' setup shape series
            m_VectorSeries = New NVectorSeries()
            chart.Series.Add(m_VectorSeries)
            m_VectorSeries.DataLabelStyle = New NDataLabelStyle(False)
            m_VectorSeries.InflateMargins = False
            m_VectorSeries.UseXValues = True
            m_VectorSeries.UseZValues = True
            m_VectorSeries.MinArrowheadSize = New NSize(2, 3)
            m_VectorSeries.MaxArrowheadSize = New NSize(4, 6)

            ' fill data
            FillData(m_VectorSeries)

            Return chartViewWithCommandBars
        End Function
        Protected Overrides Function CreateExampleControls() As NWidget
            Dim stack As NStackPanel = New NStackPanel()
            Dim group As NUniSizeBoxGroup = New NUniSizeBoxGroup(stack)

            m_ArrowheadShapeComboBox = New NComboBox()
            m_ArrowheadShapeComboBox.FillFromEnum(Of ENVectorArrowheadShape)()
            Me.m_ArrowheadShapeComboBox.SelectedIndexChanged += AddressOf OnArrowHeadShapeComboBoxSelectedIndexChanged
            m_ArrowheadShapeComboBox.SelectedIndex = CInt(ENVectorArrowheadShape.Arrow)

            stack.Add(NPairBox.Create("Arrowhead shape:", m_ArrowheadShapeComboBox))

            Return group
        End Function

        Private Sub OnArrowHeadShapeComboBoxSelectedIndexChanged(ByVal arg As NValueChangeEventArgs)
            m_VectorSeries.ArrowheadShape = CType(m_ArrowheadShapeComboBox.SelectedIndex, ENVectorArrowheadShape)
        End Sub

        Protected Overrides Function GetExampleDescription() As String
            Return "<p>This example demonstrates how to create a standard 2D vector chart.</p>"
        End Function

#End Region

#Region "Implementation"

        Private Sub FillData(ByVal vectorSeries As NVectorSeries)
            Dim x As Double = 0, y As Double = 0, z As Double = 0

            For w = 0 To 4
                y = 0
                z += 1

                For i = 0 To 4
                    x = 0
                    y += 1

                    For j = 0 To 4
                        x += 1

                        Dim dx = Math.Sin(x / 4.0) * Math.Sin(x / 4.0)
                        Dim dy = Math.Cos(y / 8.0) * Math.Cos(w / 4.0)

                        Dim stroke As NStroke = New NStroke(1, ColorFromVector(dx, dy))

                        Dim dataPoint As NVectorDataPoint = New NVectorDataPoint(x, y, z, x + dx, y + dy, z - 0.5, Nothing)
                        dataPoint.Stroke = stroke
                        vectorSeries.DataPoints.Add(dataPoint)
                    Next
                Next
            Next
        End Sub

        Private Function ColorFromVector(ByVal dx As Double, ByVal dy As Double) As NColor
            Dim length = Math.Sqrt(dx * dx + dy * dy)

            Dim sq2 = Math.Sqrt(2)

            Dim r As Integer = 255 / sq2 * length
            Dim g = 20
            Dim b As Integer = 255 / sq2 * (sq2 - length)

            Return NColor.FromRGB(CByte(r), CByte(g), CByte(b))
        End Function

#End Region

#Region "Fields"

        Private m_VectorSeries As NVectorSeries
        Private m_ArrowheadShapeComboBox As NComboBox

#End Region

#Region "Schema"

        Public Shared ReadOnly NXYZVectorExampleSchema As NSchema

#End Region
    End Class
End Namespace

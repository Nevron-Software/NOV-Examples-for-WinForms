Imports System

Imports Nevron.Nov.Chart
Imports Nevron.Nov.Dom
Imports Nevron.Nov.Graphics
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.Chart
    ''' <summary>
    ''' Standard Line Example
    ''' </summary>
    Public Class NSmoothLineExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' Default constructor
        ''' </summary>
        Public Sub New()

        End Sub
        ''' <summary>
        ''' Static constructor
        ''' </summary>
        Shared Sub New()
            NSmoothLineExampleSchema = NSchema.Create(GetType(NSmoothLineExample), NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            Dim chartViewWithCommandBars As NChartViewWithCommandBars = New NChartViewWithCommandBars()
            Dim chartView = chartViewWithCommandBars.View
            chartView.Surface.CreatePredefinedChart(ENPredefinedChartType.Cartesian)

            ' configure title
            chartView.Surface.Titles(0).Text = "Smooth Line"

            ' configure chart
            m_Chart = CType(chartView.Surface.Charts(0), NCartesianChart)

            m_Chart.SetPredefinedCartesianAxes(ENPredefinedCartesianAxis.XOrdinalYLinear)

            ' add interlaced stripe to the Y axis
            Dim strip As NScaleStrip = New NScaleStrip(New NColorFill(ENNamedColor.Beige), Nothing, True, 0, 0, 1, 1)
            strip.Interlaced = True
            m_Chart.Axes(ENCartesianAxis.PrimaryY).Scale.Strips.Add(strip)

            m_Line = New NLineSeries()
            m_Line.Name = "Line Series"
            m_Line.InflateMargins = True
            m_Line.DataLabelStyle = New NDataLabelStyle("<value>")
            m_Line.MarkerStyle = New NMarkerStyle(New NSize(4, 4))
            m_Line.LineSegmentMode = ENLineSegmentMode.Spline

            Dim random As Random = New Random()

            For i = 0 To 7
                m_Line.DataPoints.Add(New NLineDataPoint(random.Next(80) + 20))
            Next

            m_Chart.Series.Add(m_Line)

            chartView.Document.StyleSheets.ApplyTheme(New NChartTheme(ENChartPalette.Bright, ENChartPaletteTarget.Series))

            Return chartViewWithCommandBars
        End Function
        Protected Overrides Function CreateExampleControls() As NWidget
            Dim stack As NStackPanel = New NStackPanel()
            Dim group As NUniSizeBoxGroup = New NUniSizeBoxGroup(stack)
            Return group
        End Function
        Protected Overrides Function GetExampleDescription() As String
            Return "<p>This example demonstrates how to create smooth line (spline) charts.</p>"
        End Function

#End Region

#Region "Event Handlers"


#End Region

#Region "Fields"

        Private m_Chart As NCartesianChart
        Private m_Line As NLineSeries

#End Region

#Region "Schema"

        Public Shared ReadOnly NSmoothLineExampleSchema As NSchema

#End Region
    End Class
End Namespace

Imports Nevron.Nov.Chart
Imports Nevron.Nov.Chart.Tools
Imports Nevron.Nov.Dom
Imports Nevron.Nov.Graphics
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.Chart
    ''' <summary>
    ''' XYZ Range Example
    ''' </summary>
    Public Class NXYZRangeExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' Default constructor
        ''' </summary>
        Public Sub New()

        End Sub
        ''' <summary>
        ''' Static constructor
        ''' </summary>
        Shared Sub New()
            NXYZRangeExampleSchema = NSchema.Create(GetType(NXYZRangeExample), NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            Dim chartViewWithCommandBars As NChartViewWithCommandBars = New NChartViewWithCommandBars()
            Dim chartView = chartViewWithCommandBars.View
            chartView.Surface.CreatePredefinedChart(ENPredefinedChartType.Cartesian)

            ' configure title
            chartView.Surface.Titles(0).Text = "XYZ Range Series"

            ' configure chart
            m_Chart = CType(chartView.Surface.Charts(0), NCartesianChart)

            m_Chart.Enable3D = True
            m_Chart.Projection.SetPredefinedProjection(ENPredefinedProjection.PerspectiveTilted)
            m_Chart.Projection.Rotation = -18
            m_Chart.Projection.Elevation = 13
            m_Chart.LightModel.SetPredefinedLightModel(ENPredefinedLightModel.BrightCameraLight)
            m_Chart.ModelDepth = 55.0F
            m_Chart.ModelWidth = 55.0F
            m_Chart.ModelHeight = 55.0F
            m_Chart.SetPredefinedCartesianAxes(ENPredefinedCartesianAxis.XYZLinear)
            m_Chart.Interactor = New NInteractor(New NTrackballTool())

            ' setup X axis
            If True Then
                Dim scaleX As NLinearScale = m_Chart.Axes(ENCartesianAxis.PrimaryX).Scale
                scaleX.MajorGridLines.SetShowAtWall(ENChartWall.Back, True)
                scaleX.MajorGridLines.SetShowAtWall(ENChartWall.Bottom, True)
                scaleX.MajorGridLines.Stroke.DashStyle = ENDashStyle.Dot
                m_Chart.Axes(ENCartesianAxis.PrimaryX).SetFixedViewRange(0, 20)
            End If

            ' setup Y axis
            If True Then
                Dim scaleY As NLinearScale = m_Chart.Axes(ENCartesianAxis.PrimaryY).Scale
                scaleY.MajorGridLines.SetShowAtWall(ENChartWall.Back, True)
                scaleY.MajorGridLines.SetShowAtWall(ENChartWall.Left, True)
                scaleY.MajorGridLines.Stroke.DashStyle = ENDashStyle.Dot

                ' add interlaced stripe
                Dim stripStyle As NScaleStrip = New NScaleStrip(New NColorFill(NColor.Beige), Nothing, True, 0, 0, 1, 1)
                stripStyle.SetShowAtWall(ENChartWall.Back, True)
                stripStyle.SetShowAtWall(ENChartWall.Left, True)
                stripStyle.Interlaced = True
                scaleY.Strips.Add(stripStyle)

                m_Chart.Axes(ENCartesianAxis.PrimaryY).SetFixedViewRange(0, 20)
            End If

            ' setup Depth axis
            If True Then
                Dim scaleZ As NLinearScale = m_Chart.Axes(ENCartesianAxis.Depth).Scale
                scaleZ.MajorGridLines.SetShowAtWall(ENChartWall.Left, True)
                scaleZ.MajorGridLines.SetShowAtWall(ENChartWall.Bottom, True)
                scaleZ.MajorGridLines.Stroke.DashStyle = ENDashStyle.Dot
                m_Chart.Axes(ENCartesianAxis.Depth).SetFixedViewRange(0, 20)
            End If

            ' setup shape series
            m_Range = New NRangeSeries()
            m_Chart.Series.Add(m_Range)

            m_Range.Fill = New NColorFill(NColor.Red)
            m_Range.Stroke = New NStroke(NColor.DarkRed)
            m_Range.LegendView.Mode = ENSeriesLegendMode.None
            m_Range.UseXValues = True
            m_Range.UseZValues = True

            ' add data
            m_Range.DataPoints.Add(New NRangeDataPoint(1, 11, 5, 5, 17, 9))
            m_Range.DataPoints.Add(New NRangeDataPoint(4, 15, 16, 7, 19, 19))
            m_Range.DataPoints.Add(New NRangeDataPoint(5, 6, 12, 15, 11, 18))
            m_Range.DataPoints.Add(New NRangeDataPoint(9, 2, 3, 14, 5, 5))
            m_Range.DataPoints.Add(New NRangeDataPoint(15, 2, 3, 19, 5, 5))

            chartView.Document.StyleSheets.ApplyTheme(New NChartTheme(ENChartPalette.Bright, ENChartPaletteTarget.DataPoints))

            Return chartViewWithCommandBars
        End Function
        Protected Overrides Function CreateExampleControls() As NWidget
            Dim stack As NStackPanel = New NStackPanel()
            Dim group As NUniSizeBoxGroup = New NUniSizeBoxGroup(stack)

            Dim rangeShapeComboBox As NComboBox = New NComboBox()
            rangeShapeComboBox.FillFromEnum(Of ENBarShape)()
            rangeShapeComboBox.SelectedIndexChanged += New [Function](Of NValueChangeEventArgs)(AddressOf OnRangeShapeComboBoxSelectedIndexChanged)
            stack.Add(NPairBox.Create("Range Shape: ", rangeShapeComboBox))

            Dim showDataLabels As NCheckBox = New NCheckBox("Show Data Labels")
            showDataLabels.CheckedChanged += New [Function](Of NValueChangeEventArgs)(AddressOf OnShowDataLabelsCheckedChanged)
            showDataLabels.Checked = False
            stack.Add(showDataLabels)

            rangeShapeComboBox.SelectedIndex = CInt(ENBarShape.Rectangle)
            showDataLabels.Checked = False

            Return group
        End Function
        Protected Overrides Function GetExampleDescription() As String
            Return "<p>This example demonstrates how to create a 3D range m_Chart.</p>"
        End Function

#End Region

#Region "Event Handlers"

        Private Sub OnShowDataLabelsCheckedChanged(ByVal arg As NValueChangeEventArgs)
            If TryCast(arg.TargetNode, NCheckBox).Checked Then
                m_Range.DataLabelStyle = New NDataLabelStyle(True)
                m_Range.DataLabelStyle.Format = "<y2>"
            Else
                m_Range.DataLabelStyle = New NDataLabelStyle(False)
            End If
        End Sub

        Private Sub OnRangeShapeComboBoxSelectedIndexChanged(ByVal arg As NValueChangeEventArgs)
            m_Range.Shape = CType(TryCast(arg.TargetNode, NComboBox).SelectedIndex, ENBarShape)
        End Sub

#End Region

#Region "Fields"

        Private m_Range As NRangeSeries
        Private m_Chart As NCartesianChart

#End Region

#Region "Schema"

        Public Shared ReadOnly NXYZRangeExampleSchema As NSchema

#End Region
    End Class
End Namespace

Imports System
Imports Nevron.Nov.Chart
Imports Nevron.Nov.Dom
Imports Nevron.Nov.Graphics
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.Chart
    ''' <summary>
    ''' This example demonstrates how to associate a palette with an area series
    ''' </summary>
    Public Class NAreaPaletteExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' 
        ''' </summary>
        Public Sub New()
        End Sub
        ''' <summary>
        ''' 
        ''' </summary>
        Shared Sub New()
            NAreaPaletteExampleSchema = NSchema.Create(GetType(NAreaPaletteExample), NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            Dim chartView As NChartView = CreateCartesianChartView()
            AddHandler chartView.Registered, AddressOf OnChartViewRegistered
            AddHandler chartView.Unregistered, AddressOf OnChartViewUnregistered

            ' configure title
            chartView.Surface.Titles(0).Text = "Area Palette"

            ' configure chart
            m_Chart = CType(chartView.Surface.Charts(0), NCartesianChart)
            m_Chart.SetPredefinedCartesianAxes(ENPredefinedCartesianAxis.XOrdinalYLinear)

            ' add interlace stripe
            Dim linearScale As NLinearScale = TryCast(m_Chart.Axes(ENCartesianAxis.PrimaryY).Scale, NLinearScale)
            Dim strip As NScaleStrip = New NScaleStrip(New NColorFill(ENNamedColor.Beige), Nothing, True, 0, 0, 1, 1)
            strip.Interlaced = True
            linearScale.Strips.Add(strip)

            ' setup an area series
            m_Area = New NAreaSeries()
            m_Area.Name = "Area Series"
            m_Area.InflateMargins = True
            m_Area.UseXValues = False
            m_Area.DataLabelStyle = New NDataLabelStyle(False)
            m_Area.Palette = New NColorValuePalette(New NColorValuePair() {New NColorValuePair(0, NColor.Green), New NColorValuePair(60, NColor.Yellow), New NColorValuePair(120, NColor.Red)})
            m_AxisRange = New NRange(0, 130)

            ' limit the axis range to 0, 130
            Dim yAxis = m_Chart.Axes(ENCartesianAxis.PrimaryY)
            yAxis.ViewRangeMode = ENAxisViewRangeMode.FixedRange
            yAxis.MinViewRangeValue = m_AxisRange.Begin
            yAxis.MaxViewRangeValue = m_AxisRange.End
            m_Chart.Series.Add(m_Area)
            Dim indicatorCount = 10
            m_IndicatorPhase = New Double(indicatorCount - 1) {}

            ' add some data to the area series
            For i = 0 To indicatorCount - 1
                m_IndicatorPhase(i) = i * 30
                m_Area.DataPoints.Add(New NAreaDataPoint(0))
            Next

            Return chartView
        End Function

        Protected Overrides Function CreateExampleControls() As NWidget
            Dim stack As NStackPanel = New NStackPanel()
            Dim toggleTimerButton As NButton = New NButton("Stop Timer")
            AddHandler toggleTimerButton.Click, AddressOf OnToggleTimerButtonClick
            toggleTimerButton.Tag = 0
            stack.Add(toggleTimerButton)
            Dim invertScaleCheckBox As NCheckBox = New NCheckBox("Invert Scale")
            AddHandler invertScaleCheckBox.CheckedChanged, AddressOf OnInvertScaleCheckBoxCheckedChanged
            invertScaleCheckBox.Checked = False
            stack.Add(invertScaleCheckBox)
            Dim smoothPaletteCheckBox As NCheckBox = New NCheckBox("Smooth Palette")
            AddHandler smoothPaletteCheckBox.CheckedChanged, AddressOf OnSmoothPaletteCheckBoxCheckedChanged
            smoothPaletteCheckBox.Checked = True
            stack.Add(smoothPaletteCheckBox)
            Return stack
        End Function

        Protected Overrides Function GetExampleDescription() As String
            Return "<p>This example demonstrates how to associate a palette with an area series.</p>"
        End Function

#End Region

#Region "Event Handlers"

        Private Sub OnChartViewUnregistered(ByVal arg As NEventArgs)
            m_Timer.Stop()
            RemoveHandler m_Timer.Tick, AddressOf OnTimerTick
            m_Timer = Nothing
        End Sub

        Private Sub OnChartViewRegistered(ByVal arg As NEventArgs)
            m_Timer = New NTimer()
            AddHandler m_Timer.Tick, AddressOf OnTimerTick
            m_Timer.Start()
        End Sub

        Private Sub OnInvertScaleCheckBoxCheckedChanged(ByVal arg As NValueChangeEventArgs)
            m_Chart.Axes(ENCartesianAxis.PrimaryY).Scale.Invert = CType(arg.TargetNode, NCheckBox).Checked
        End Sub

        Private Sub OnToggleTimerButtonClick(ByVal arg As NEventArgs)
            Dim button = CType(arg.TargetNode, NButton)

            If CInt(button.Tag) = 0 Then
                m_Timer.Stop()
                button.Content = New NLabel("Start Timer")
                button.Tag = 1
            Else
                m_Timer.Start()
                button.Content = New NLabel("Stop Timer")
                button.Tag = 0
            End If
        End Sub

        Private Sub OnTimerTick()
            Dim random As Random = New Random()

            For i = 0 To m_Area.DataPoints.Count - 1
                Dim value As Double = (m_AxisRange.Begin + m_AxisRange.End) / 2.0 + Math.Sin(m_IndicatorPhase(i) * NAngle.Degree2Rad) * m_AxisRange.GetLength() / 2
                value = m_AxisRange.GetValueInRange(value)
                m_Area.DataPoints(i).Value = value
                m_IndicatorPhase(i) += 10
            Next
        End Sub

        Private Sub OnSmoothPaletteCheckBoxCheckedChanged(ByVal arg As NValueChangeEventArgs)
            Dim smoothPalette = CType(arg.TargetNode, NCheckBox).Checked
            m_Area.Palette.SmoothColors = smoothPalette
        End Sub

#End Region

#Region "Fields"

        Private m_Chart As NCartesianChart
        Private m_Area As NAreaSeries
        Private m_Timer As NTimer
        Private m_IndicatorPhase As Double()
        Private m_AxisRange As NRange

#End Region

#Region "Schema"

        Public Shared ReadOnly NAreaPaletteExampleSchema As NSchema

#End Region

#Region "Static Methods"

        Private Shared Function CreateCartesianChartView() As NChartView
            Dim chartView As NChartView = New NChartView()
            chartView.Surface.CreatePredefinedChart(ENPredefinedChartType.Cartesian)
            Return chartView
        End Function

#End Region
    End Class
End Namespace

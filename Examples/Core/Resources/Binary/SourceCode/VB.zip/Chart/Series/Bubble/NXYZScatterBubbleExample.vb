Imports System

Imports Nevron.Nov.Chart
Imports Nevron.Nov.Chart.Tools
Imports Nevron.Nov.Dom
Imports Nevron.Nov.Graphics
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.Chart
    ''' <summary>
    ''' Standard Bubble Example
    ''' </summary>
    Public Class NXYZScatterBubbleExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' Default constructor
        ''' </summary>
        Public Sub New()

        End Sub
        ''' <summary>
        ''' Static constructor
        ''' </summary>
        Shared Sub New()
            NXYZScatterBubbleExampleSchema = NSchema.Create(GetType(NXYZScatterBubbleExample), NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            Dim chartViewWithCommandBars As NChartViewWithCommandBars = New NChartViewWithCommandBars()
            Dim chartView = chartViewWithCommandBars.View
            chartView.Surface.CreatePredefinedChart(ENPredefinedChartType.Cartesian)

            ' configure title
            chartView.Surface.Titles(0).Text = "XYZ Scatter Bubble"

            ' configure chart
            m_Chart = CType(chartView.Surface.Charts(0), NCartesianChart)

            m_Chart.SetPredefinedCartesianAxes(ENPredefinedCartesianAxis.XYZLinear)

            ' setup chart
            m_Chart.Enable3D = True
            m_Chart.ModelWidth = 50
            m_Chart.ModelDepth = 50
            m_Chart.ModelHeight = 50
            m_Chart.Projection.SetPredefinedProjection(ENPredefinedProjection.PerspectiveTilted)
            m_Chart.LightModel.SetPredefinedLightModel(ENPredefinedLightModel.GlitterLeft)
            m_Chart.Interactor = New NInteractor(New NTrackballTool())

            Dim depthScale As NLinearScale = New NLinearScale()
            depthScale.MajorGridLines.Stroke.DashStyle = ENDashStyle.Dot
            depthScale.MajorGridLines.SetShowAtWall(ENChartWall.Bottom, True)
            depthScale.MajorGridLines.SetShowAtWall(ENChartWall.Left, True)
            m_Chart.Axes(ENCartesianAxis.Depth).Scale = depthScale

            Dim yScale As NLinearScale = New NLinearScale()
            yScale.MajorGridLines.Stroke.DashStyle = ENDashStyle.Dot
            yScale.MajorGridLines.SetShowAtWall(ENChartWall.Back, True)
            yScale.MajorGridLines.SetShowAtWall(ENChartWall.Left, True)

            ' add interlace style
            Dim strip As NScaleStrip = New NScaleStrip(New NColorFill(NColor.Beige), Nothing, True, 0, 0, 1, 1)
            strip.Interlaced = True
            strip.SetShowAtWall(ENChartWall.Back, True)
            strip.SetShowAtWall(ENChartWall.Left, True)
            strip.Interlaced = True
            yScale.Strips.Add(strip)
            m_Chart.Axes(ENCartesianAxis.PrimaryY).Scale = yScale

            ' switch the x axis in linear mode
            Dim xScale As NLinearScale = New NLinearScale()
            xScale.MajorGridLines.Stroke.DashStyle = ENDashStyle.Dot
            xScale.MajorGridLines.SetShowAtWall(ENChartWall.Bottom, True)
            xScale.MajorGridLines.SetShowAtWall(ENChartWall.Back, True)
            m_Chart.Axes(ENCartesianAxis.PrimaryX).Scale = xScale

            m_Bubble = New NBubbleSeries()
            m_Chart.Series.Add(m_Bubble)
            m_Bubble.InflateMargins = True
            m_Bubble.Shape = ENPointShape3D.Sphere
            m_Bubble.LegendView.Format = "x:<xvalue> y:<value> z:<zvalue> sz:<size>"
            m_Bubble.LegendView.Mode = ENSeriesLegendMode.DataPoints
            m_Bubble.MinSize = 20
            m_Bubble.MaxSize = 100
            m_Bubble.UseXValues = True
            m_Bubble.UseZValues = True

            chartView.Document.StyleSheets.ApplyTheme(New NChartTheme(ENChartPalette.Bright, ENChartPaletteTarget.DataPoints))

            OnChangeDataButtonClick(Nothing)

            Return chartViewWithCommandBars
        End Function
        Protected Overrides Function CreateExampleControls() As NWidget
            Dim stack As NStackPanel = New NStackPanel()

            Dim changeDataButton As NButton = New NButton("Change Data")
            changeDataButton.Click += New [Function](Of NEventArgs)(AddressOf OnChangeDataButtonClick)
            stack.Add(changeDataButton)

            Return stack
        End Function
        Protected Overrides Function GetExampleDescription() As String
            Return "<p>This example demonstrates how to create a xy scatter bubble chart.</p>"
        End Function

#End Region

#Region "Event Handlers"

        ''' <summary>
        ''' 
        ''' </summary>
        ''' <paramname="arg"></param>
        Private Sub OnChangeDataButtonClick(ByVal arg As NEventArgs)
            Dim random As Random = New Random()
            m_Bubble.DataPoints.Clear()

            For i = 0 To 5
                Dim dataPoint As NBubbleDataPoint = New NBubbleDataPoint()

                dataPoint.Value = random.Next(-100, 100)
                dataPoint.X = random.Next(-100, 100)
                dataPoint.Z = random.Next(-100, 100)
                dataPoint.Size = random.NextDouble()

                m_Bubble.DataPoints.Add(dataPoint)
            Next
        End Sub

#End Region

#Region "Fields"

        Private m_Bubble As NBubbleSeries
        Private m_Chart As NCartesianChart

#End Region

#Region "Schema"

        Public Shared ReadOnly NXYZScatterBubbleExampleSchema As NSchema

#End Region
    End Class
End Namespace

Imports Nevron.Nov.Chart
Imports Nevron.Nov.Chart.Tools
Imports Nevron.Nov.Dom
Imports Nevron.Nov.Graphics
Imports Nevron.Nov.UI
Imports System

Namespace Nevron.Nov.Examples.Chart
    ''' <summary>
    ''' Vertex Surface Example
    ''' </summary>
    Public Class NVertexSurfaceExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' Default constructor
        ''' </summary>
        Public Sub New()

        End Sub
        ''' <summary>
        ''' Static constructor
        ''' </summary>
        Shared Sub New()
            NVertexSurfaceExampleSchema = NSchema.Create(GetType(NVertexSurfaceExample), NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            Dim chartViewWithCommandBars As NChartViewWithCommandBars = New NChartViewWithCommandBars()
            Dim chartView = chartViewWithCommandBars.View
            chartView.Surface.CreatePredefinedChart(ENPredefinedChartType.Cartesian)

            ' configure title
            m_Label = chartView.Surface.Titles(0)
            chartView.Surface.Titles(0).Text = "Vertex Surface Series"

            ' setup chart
            Dim chart = CType(chartView.Surface.Charts(0), NCartesianChart)
            chart.Enable3D = True
            chart.ModelWidth = 60.0F
            chart.ModelDepth = 60.0F
            chart.ModelHeight = 25.0F
            chart.Projection.SetPredefinedProjection(ENPredefinedProjection.PerspectiveTilted)
            chart.LightModel.SetPredefinedLightModel(ENPredefinedLightModel.ShinyTopLeft)
            chart.Interactor = New NInteractor(New NTrackballTool())

            Dim scale As NLinearScale = chart.Axes(ENCartesianAxis.PrimaryY).Scale
            scale.ViewRangeInflateMode = ENScaleViewRangeInflateMode.None

            ' setup axes
            Dim ordinalScale As NOrdinalScale = chart.Axes(ENCartesianAxis.PrimaryX).Scale
            ordinalScale.MajorGridLines.SetShowAtWall(ENChartWall.Bottom, True)
            ordinalScale.MajorGridLines.SetShowAtWall(ENChartWall.Back, True)
            ordinalScale.DisplayDataPointsBetweenTicks = False

            ordinalScale = chart.Axes(ENCartesianAxis.Depth).Scale
            ordinalScale.MajorGridLines.SetShowAtWall(ENChartWall.Bottom, True)
            ordinalScale.MajorGridLines.SetShowAtWall(ENChartWall.Left, True)
            ordinalScale.DisplayDataPointsBetweenTicks = False

            ' add the surface series
            m_Surface = New NVertexSurfaceSeries()
            chart.Series.Add(m_Surface)

            m_Surface.Name = "Surface"
            m_Surface.LegendView.Mode = ENSeriesLegendMode.SeriesLogic
            m_Surface.FlatPositionValue = 10.0

            m_Surface.Palette.InterpolateColors = False

            m_Surface.ValueFormatter = New NNumericValueFormatter("0.00")
            m_Surface.Fill = New NColorFill(NColor.YellowGreen)
            m_Surface.FillMode = ENSurfaceFillMode.Zone
            m_Surface.FrameMode = ENSurfaceFrameMode.Contour
            m_Surface.FrameColorMode = ENSurfaceFrameColorMode.Uniform
            m_Surface.ShadingMode = ENShadingMode.Smooth

            Return chartViewWithCommandBars
        End Function

        Protected Overrides Function CreateExampleControls() As NWidget
            Dim stack As NStackPanel = New NStackPanel()
            Dim group As NUniSizeBoxGroup = New NUniSizeBoxGroup(stack)

            Dim vertexPrimitiveCombo As NComboBox = New NComboBox()
            vertexPrimitiveCombo.FillFromEnum(Of ENVertexPrimitive)()
            vertexPrimitiveCombo.SelectedIndexChanged += AddressOf OnVertexPrimitiveComboSelectedIndexChanged
            vertexPrimitiveCombo.SelectedIndex = m_Surface.VertexPrimitive
            stack.Add(NPairBox.Create("Vertex Primitive:", vertexPrimitiveCombo))

            Dim smoothShadingCheckBox As NCheckBox = New NCheckBox()
            smoothShadingCheckBox.CheckedChanged += AddressOf OnSmoothShadingCheckBoxCheckedChanged
            stack.Add(NPairBox.Create("Smooth Shading:", smoothShadingCheckBox))


            Return group
        End Function

        Private Sub OnSmoothShadingCheckBoxCheckedChanged(ByVal arg As NValueChangeEventArgs)
            m_Surface.ShadingMode = If(arg.NewValue, ENShadingMode.Smooth, ENShadingMode.Flat)
        End Sub

        Private Sub OnVertexPrimitiveComboSelectedIndexChanged(ByVal arg As NValueChangeEventArgs)
            m_Surface.VertexPrimitive = CType(arg.NewValue, ENVertexPrimitive)
            m_Surface.UseIndices = False

            Dim rand As Random = New Random()
            Dim descriptionText = String.Empty

            m_Surface.Data.Clear()

            Select Case m_Surface.VertexPrimitive
                Case ENVertexPrimitive.Points
                    descriptionText = "Each vertex represents a 3d point"

                    m_Surface.FrameMode = ENSurfaceFrameMode.Dots

                    For i = 0 To 9999
                        m_Surface.Data.AddValue(rand.Next(100), rand.Next(100), rand.Next(100))
                    Next
                Case ENVertexPrimitive.Lines
                    descriptionText = "Each consecutive pair of vertices represents a line segment"

                    m_Surface.FrameMode = ENSurfaceFrameMode.Dots

                    For i = 0 To 199
                        m_Surface.Data.AddValue(rand.Next(100), rand.Next(100), rand.Next(100))

                        m_Surface.Data.AddValue(rand.Next(100), rand.Next(100), rand.Next(100))
                    Next

                Case ENVertexPrimitive.LineLoop, ENVertexPrimitive.LineStrip
                    descriptionText = "Adjacent vertices are connected with a line segment"

                    For i = 0 To 4
                        m_Surface.Data.AddValue(rand.Next(100), rand.Next(100), rand.Next(100))
                    Next

                Case ENVertexPrimitive.Triangles
                    descriptionText = "Each three consequtive vertices are considered a triangle"

                    m_Surface.FrameMode = ENSurfaceFrameMode.Mesh

                    Dim top As NVector3DD = New NVector3DD(0.5, 1, 0.5)
                    Dim baseA As NVector3DD = New NVector3DD(0, 0, 0)
                    Dim baseB As NVector3DD = New NVector3DD(1, 0, 0)
                    Dim baseC As NVector3DD = New NVector3DD(1, 0, 1)
                    Dim baseD As NVector3DD = New NVector3DD(0, 0, 1)

                    m_Surface.Data.AddValue(top)
                    m_Surface.Data.AddValue(baseA)
                    m_Surface.Data.AddValue(baseB)

                    m_Surface.Data.AddValue(top)
                    m_Surface.Data.AddValue(baseB)
                    m_Surface.Data.AddValue(baseC)

                    m_Surface.Data.AddValue(top)
                    m_Surface.Data.AddValue(baseC)
                    m_Surface.Data.AddValue(baseD)

                    m_Surface.Data.AddValue(top)
                    m_Surface.Data.AddValue(baseD)
                    m_Surface.Data.AddValue(baseA)
                Case ENVertexPrimitive.TriangleStrip
                    descriptionText = "A series of connected triangles that share common vertices"

                    m_Surface.FrameMode = ENSurfaceFrameMode.Mesh

                    Dim A As NVector3DD = New NVector3DD(0, 0, 0)
                    Dim B As NVector3DD = New NVector3DD(1, 0, 0)
                    Dim C As NVector3DD = New NVector3DD(0, 1, 1)
                    Dim D As NVector3DD = New NVector3DD(1, 1, 1)

                    m_Surface.Data.AddValue(A)
                    m_Surface.Data.AddValue(B)
                    m_Surface.Data.AddValue(C)
                    m_Surface.Data.AddValue(D)
                Case ENVertexPrimitive.TriangleFan
                    descriptionText = "A series of connected triangles that share a common vertex"

                    m_Surface.FrameMode = ENSurfaceFrameMode.Mesh

                    m_Surface.Data.AddValue(0, 100, 0)

                    Dim steps = 10

                    For i = 0 To 2999
                        Dim angle = i * 2 * Math.PI / steps

                        m_Surface.Data.AddValue(Math.Cos(angle) * 100, 0, Math.Sin(angle) * 100)
                    Next
                Case ENVertexPrimitive.Quads
                    descriptionText = "Each for consecutive vertices form a quad"

                    m_Surface.FrameMode = ENSurfaceFrameMode.Mesh
                    m_Surface.FillMode = ENSurfaceFillMode.Zone

                    Dim A As NVector3DD = New NVector3DD(0, 0, 0)
                    Dim B As NVector3DD = New NVector3DD(1, 0, 0)
                    Dim C As NVector3DD = New NVector3DD(0, 1, 1)
                    Dim D As NVector3DD = New NVector3DD(1, 1, 1)


                    m_Surface.Data.AddValue(A)
                    m_Surface.Data.AddValue(B)
                    m_Surface.Data.AddValue(D)
                    m_Surface.Data.AddValue(C)
                Case ENVertexPrimitive.QuadStrip
                    descriptionText = "A series of connected quads that share common vertices"

                    m_Surface.FrameMode = ENSurfaceFrameMode.Mesh
                    m_Surface.FillMode = ENSurfaceFillMode.Zone

                    Dim A As NVector3DD = New NVector3DD(0, 0, 0)
                    Dim B As NVector3DD = New NVector3DD(1, 0, 0)
                    Dim C As NVector3DD = New NVector3DD(0, 1, 1)
                    Dim D As NVector3DD = New NVector3DD(1, 1, 1)
                    Dim E As NVector3DD = New NVector3DD(0, 2, 2)
                    Dim F As NVector3DD = New NVector3DD(1, 2, 2)


                    m_Surface.Data.AddValue(A)
                    m_Surface.Data.AddValue(B)
                    m_Surface.Data.AddValue(C)
                    m_Surface.Data.AddValue(D)
                    m_Surface.Data.AddValue(E)
                    m_Surface.Data.AddValue(F)
            End Select

            m_Label.Text = "Vertex Surface " & descriptionText
        End Sub
        ''' <summary>
        ''' 
        ''' </summary>
        ''' <returns></returns>
        Protected Overrides Function GetExampleDescription() As String
            Return "<p>The example demonstrates the capabilities of the Vertex Surface Series. This type of series allows you to plot an arbitrary OpenGL primitive.</p>"
        End Function

#End Region

#Region "Fields"

        Private m_Label As NLabel
        Private m_Surface As NVertexSurfaceSeries

#End Region

#Region "Schema"

        Public Shared ReadOnly NVertexSurfaceExampleSchema As NSchema

#End Region
    End Class
End Namespace

Imports Nevron.Nov.Chart
Imports Nevron.Nov.Dom
Imports Nevron.Nov.Graphics
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.Chart
    ''' <summary>
    ''' Standard Bubble Example
    ''' </summary>
    Public Class NStandardBubbleExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' Default constructor
        ''' </summary>
        Public Sub New()
        End Sub
        ''' <summary>
        ''' Static constructor
        ''' </summary>
        Shared Sub New()
            NStandardBubbleExampleSchema = NSchema.Create(GetType(NStandardBubbleExample), NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            Dim chartView As NChartView = CreateCartesianChartView()

            ' configure title
            chartView.Surface.Titles(0).Text = "Standard Bubble"

            ' configure chart
            m_Chart = CType(chartView.Surface.Charts(0), NCartesianChart)
            m_Chart.SetPredefinedCartesianAxes(ENPredefinedCartesianAxis.XOrdinalYLinear)

            ' configure the chart
            Dim yScale = CType(m_Chart.Axes(ENCartesianAxis.PrimaryY).Scale, NLinearScale)
            yScale.MajorGridLines = New NScaleGridLines()
            yScale.MajorGridLines.Stroke.DashStyle = ENDashStyle.Dot

            ' add interlace stripe
            Dim strip As NScaleStrip = New NScaleStrip(New NColorFill(NColor.Beige), Nothing, True, 0, 0, 1, 1)
            strip.Interlaced = True
            yScale.Strips.Add(strip)
            Dim xScale = CType(m_Chart.Axes(ENCartesianAxis.PrimaryX).Scale, NOrdinalScale)
            xScale.MajorGridLines = New NScaleGridLines()
            xScale.MajorGridLines.Stroke.DashStyle = ENDashStyle.Dot

            ' add a bubble series
            m_Bubble = New NBubbleSeries()
            m_Bubble.DataLabelStyle = New NDataLabelStyle()
            m_Bubble.DataLabelStyle.VertAlign = ENVerticalAlignment.Center
            m_Bubble.DataLabelStyle.Visible = False
            m_Bubble.LegendView.Mode = ENSeriesLegendMode.DataPoints
            m_Bubble.MinSize = 20
            m_Bubble.MaxSize = 100
            m_Bubble.DataPoints.Add(New NBubbleDataPoint(10, 10, "Company 1"))
            m_Bubble.DataPoints.Add(New NBubbleDataPoint(15, 20, "Company 2"))
            m_Bubble.DataPoints.Add(New NBubbleDataPoint(12, 25, "Company 3"))
            m_Bubble.DataPoints.Add(New NBubbleDataPoint(8, 15, "Company 4"))
            m_Bubble.DataPoints.Add(New NBubbleDataPoint(14, 17, "Company 5"))
            m_Bubble.DataPoints.Add(New NBubbleDataPoint(11, 12, "Company 6"))
            m_Chart.Series.Add(m_Bubble)
            chartView.Document.StyleSheets.ApplyTheme(New NChartTheme(ENChartPalette.Bright, True))
            Return chartView
        End Function

        Protected Overrides Function CreateExampleControls() As NWidget
            Dim stack As NStackPanel = New NStackPanel()
            Dim group As NUniSizeBoxGroup = New NUniSizeBoxGroup(stack)
            Dim bubbleShapeComboBox As NComboBox = New NComboBox()
            bubbleShapeComboBox.FillFromEnum(Of ENPointShape)()
            AddHandler bubbleShapeComboBox.SelectedIndexChanged, New [Function](Of NValueChangeEventArgs)(AddressOf OnBubbleShapeComboBoxSelectedIndexChanged)
            stack.Add(NPairBox.Create("Bubble Shape: ", bubbleShapeComboBox))
            bubbleShapeComboBox.SelectedIndex = ENPointShape.Ellipse
            Dim minBubbleSizeUpDown As NNumericUpDown = New NNumericUpDown()
            AddHandler minBubbleSizeUpDown.ValueChanged, New [Function](Of NValueChangeEventArgs)(AddressOf OnMinBubbleSizeUpDownValueChanged)
            stack.Add(NPairBox.Create("Min Bubble Size:", minBubbleSizeUpDown))
            minBubbleSizeUpDown.Value = 50
            Dim maxBubbleSizeUpDown As NNumericUpDown = New NNumericUpDown()
            AddHandler maxBubbleSizeUpDown.ValueChanged, New [Function](Of NValueChangeEventArgs)(AddressOf OnMaxBubbleSizeUpDownValueChanged)
            stack.Add(NPairBox.Create("Max Bubble Size:", maxBubbleSizeUpDown))
            maxBubbleSizeUpDown.Value = 200
            Dim inflateMarginsCheckBox As NCheckBox = New NCheckBox()
            AddHandler inflateMarginsCheckBox.CheckedChanged, New [Function](Of NValueChangeEventArgs)(AddressOf OnInflateMarginsCheckBoxCheckedChanged)
            inflateMarginsCheckBox.Checked = True
            stack.Add(NPairBox.Create("Inflate Margins: ", inflateMarginsCheckBox))
            Dim legendFormatComboBox As NComboBox = CreateLegendFormatCombo()
            AddHandler legendFormatComboBox.SelectedIndexChanged, New [Function](Of NValueChangeEventArgs)(AddressOf OnLegendFormatComboBoxSelectedIndexChanged)
            stack.Add(NPairBox.Create("Legend Format:", legendFormatComboBox))
            Return group
        End Function

        Protected Overrides Function GetExampleDescription() As String
            Return "<p>This example demonstrates how to create a standard bubble chart.</p>"
        End Function

#End Region

#Region "Event Handlers"

        Private Sub OnLegendFormatComboBoxSelectedIndexChanged(ByVal arg As NValueChangeEventArgs)
            m_Bubble.LegendView.Format = CStr(CType(arg.TargetNode, NComboBox).SelectedItem.Tag)
        End Sub

        Private Sub OnBubbleShapeComboBoxSelectedIndexChanged(ByVal arg As NValueChangeEventArgs)
            m_Bubble.Shape = CType(CType(arg.TargetNode, NComboBox).SelectedIndex, ENPointShape)
        End Sub

        Private Sub OnInflateMarginsCheckBoxCheckedChanged(ByVal arg As NValueChangeEventArgs)
            m_Bubble.InflateMargins = CType(arg.TargetNode, NCheckBox).Checked
        End Sub

        Private Sub OnMaxBubbleSizeUpDownValueChanged(ByVal arg As NValueChangeEventArgs)
            m_Bubble.MaxSize = CType(arg.TargetNode, NNumericUpDown).Value
        End Sub

        Private Sub OnMinBubbleSizeUpDownValueChanged(ByVal arg As NValueChangeEventArgs)
            m_Bubble.MinSize = CType(arg.TargetNode, NNumericUpDown).Value
        End Sub

#End Region

#Region "Implementation"

        Private Function CreateLegendFormatCombo() As NComboBox
            Dim comboBox As NComboBox = New NComboBox()
            Dim item As NComboBoxItem = New NComboBoxItem("Value and Label")
            item.Tag = "<value> <label>"
            comboBox.Items.Add(item)
            item = New NComboBoxItem("Value")
            item.Tag = "<value>"
            comboBox.Items.Add(item)
            item = New NComboBoxItem("Label")
            item.Tag = "<label>"
            comboBox.Items.Add(item)
            item = New NComboBoxItem("Size")
            item.Tag = "<size>"
            comboBox.Items.Add(item)
            Return comboBox
        End Function

#End Region

#Region "Fields"

        Private m_Bubble As NBubbleSeries
        Private m_Chart As NCartesianChart

#End Region

#Region "Schema"

        Public Shared ReadOnly NStandardBubbleExampleSchema As NSchema

#End Region

#Region "Static Methods"

        Private Shared Function CreateCartesianChartView() As NChartView
            Dim chartView As NChartView = New NChartView()
            chartView.Surface.CreatePredefinedChart(ENPredefinedChartType.Cartesian)
            Return chartView
        End Function

#End Region
    End Class
End Namespace

Imports Nevron.Nov.Chart
Imports Nevron.Nov.Chart.Tools
Imports Nevron.Nov.Dom
Imports Nevron.Nov.Graphics
Imports Nevron.Nov.UI
Imports System

Namespace Nevron.Nov.Examples.Chart
    ''' <summary>
    ''' Standard Bar Example
    ''' </summary>
    Public Class NManhattanBarExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' Default constructor
        ''' </summary>
        Public Sub New()

        End Sub
        ''' <summary>
        ''' Static constructor
        ''' </summary>
        Shared Sub New()
            NManhattanBarExampleSchema = NSchema.Create(GetType(NManhattanBarExample), NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            Dim chartViewWithCommandBars As NChartViewWithCommandBars = New NChartViewWithCommandBars()
            Dim chartView = chartViewWithCommandBars.View
            chartView.Surface.CreatePredefinedChart(ENPredefinedChartType.Cartesian)

            ' configure title
            chartView.Surface.Titles(0).Text = "Manhattan Bar Chart"

            ' configure chart
            m_Chart = CType(chartView.Surface.Charts(0), NCartesianChart)

            m_Chart.Enable3D = True
            m_Chart.ModelWidth = 60
            m_Chart.ModelHeight = 25
            m_Chart.ModelDepth = 45
            m_Chart.FitMode = ENCartesianChartFitMode.Aspect
            m_Chart.Interactor = New NInteractor(New NTrackballTool())

            ' apply predefined projection and lighting
            m_Chart.Projection.SetPredefinedProjection(ENPredefinedProjection.PerspectiveTilted)
            m_Chart.LightModel.SetPredefinedLightModel(ENPredefinedLightModel.BrightCameraLight)
            m_Chart.SetPredefinedCartesianAxes(ENPredefinedCartesianAxis.Standard)

            ' add axis labels
            Dim ordinalScale As NOrdinalScale = TryCast(m_Chart.Axes(ENCartesianAxis.Depth).Scale, NOrdinalScale)

            ordinalScale.Labels.TextProvider = New NOrdinalScaleLabelTextProvider(New String() {"Chicago", "Los Angeles", "Miami", "New York"})
            ordinalScale.DisplayDataPointsBetweenTicks = True
            ordinalScale.Labels.Style.Angle = New NScaleLabelAngle(ENScaleLabelAngleMode.Scale, 0)

            ordinalScale = TryCast(m_Chart.Axes(ENCartesianAxis.PrimaryX).Scale, NOrdinalScale)
            ordinalScale.MajorGridLines.SetShowAtWall(ENChartWall.Bottom, True)
            ordinalScale.MajorGridLines.SetShowAtWall(ENChartWall.Back, True)

            ' add interlace stripe to the Y axis
            Dim linearScale As NLinearScale = TryCast(m_Chart.Axes(ENCartesianAxis.PrimaryY).Scale, NLinearScale)
            Dim stripStyle As NScaleStrip = New NScaleStrip(New NColorFill(NColor.Beige), Nothing, True, 0, 0, 1, 1)
            stripStyle.Interlaced = True
            stripStyle.SetShowAtWall(ENChartWall.Back, True)
            stripStyle.SetShowAtWall(ENChartWall.Left, True)
            linearScale.Strips.Add(stripStyle)

            ' add the first bar
            m_Bar1 = New NBarSeries()
            m_Chart.Series.Add(m_Bar1)
            m_Bar1.MultiBarMode = ENMultiBarMode.Series
            m_Bar1.Name = "Bar1"
            m_Bar1.Stroke = New NStroke(1, NColor.FromRGB(210, 210, 255))

            ' add the second bar
            m_Bar2 = New NBarSeries()
            m_Chart.Series.Add(m_Bar2)
            m_Bar2.MultiBarMode = ENMultiBarMode.Series
            m_Bar2.Name = "Bar2"
            m_Bar2.Stroke = New NStroke(1, NColor.FromRGB(210, 255, 210))

            ' add the third bar
            m_Bar3 = New NBarSeries()
            m_Chart.Series.Add(m_Bar3)
            m_Bar3.MultiBarMode = ENMultiBarMode.Series
            m_Bar3.Name = "Bar3"
            m_Bar3.Stroke = New NStroke(1, NColor.FromRGB(255, 255, 210))

            ' add the second bar
            m_Bar4 = New NBarSeries()
            m_Chart.Series.Add(m_Bar4)
            m_Bar4.MultiBarMode = ENMultiBarMode.Series
            m_Bar4.Name = "Bar4"
            m_Bar4.Stroke = New NStroke(1, NColor.FromRGB(255, 210, 210))

            OnPositiveDataButtonClick(Nothing)

            Return chartViewWithCommandBars
        End Function
        Protected Overrides Function CreateExampleControls() As NWidget
            Dim stack As NStackPanel = New NStackPanel()
            Dim boxGroup As NUniSizeBoxGroup = New NUniSizeBoxGroup(stack)

            If True Then
                Dim barShapeComobo As NComboBox = New NComboBox()
                barShapeComobo.FillFromEnum(Of ENBarShape)()
                barShapeComobo.SelectedIndexChanged += AddressOf OnBarShapeComoboSelectedIndexChanged
                barShapeComobo.SelectedIndex = CInt(ENBarShape.Rectangle)
                stack.Add(NPairBox.Create("Origin Mode: ", barShapeComobo))
            End If

            If True Then
                Dim barWidthScrollBar As NHScrollBar = New NHScrollBar()
                barWidthScrollBar.Minimum = 0
                barWidthScrollBar.Maximum = 100
                barWidthScrollBar.ValueChanged += AddressOf OnBarWidthScrollBarValueChanged
                barWidthScrollBar.Value = 50
                stack.Add(NPairBox.Create("Width Gap %: ", barWidthScrollBar))
            End If

            If True Then
                Dim barDepthScrollBar As NHScrollBar = New NHScrollBar()
                barDepthScrollBar.Minimum = 0
                barDepthScrollBar.Maximum = 100
                barDepthScrollBar.ValueChanged += AddressOf OnBarDepthScrollBarValueChanged
                barDepthScrollBar.Value = 50
                stack.Add(NPairBox.Create("Depth Gap %: ", barDepthScrollBar))
            End If

            If True Then
                Dim positiveDataButton As NButton = New NButton("Positive Data")
                positiveDataButton.Click += AddressOf OnPositiveDataButtonClick
                stack.Add(positiveDataButton)
            End If

            If True Then
                Dim positiveAndNegativeData As NButton = New NButton("Positive and Negative Data")
                positiveAndNegativeData.Click += AddressOf OnPositiveAndNegativeDataButtonClick
                stack.Add(positiveAndNegativeData)
            End If

            Return boxGroup
        End Function
        Protected Overrides Function GetExampleDescription() As String
            Return "<p>This example demonstrates a Manhattan bar chart. This type of chart is created with several bar series displayed with MultiBarMode set to Series.</p>"
        End Function

#End Region

#Region "Event Handlers"

        Private Sub OnBarWidthScrollBarValueChanged(ByVal arg As NValueChangeEventArgs)
            Dim gapFactor = CDbl(arg.NewValue) / 100

            m_Bar1.WidthGapFactor = gapFactor
            m_Bar2.WidthGapFactor = gapFactor
            m_Bar3.WidthGapFactor = gapFactor
            m_Bar4.WidthGapFactor = gapFactor
        End Sub

        Private Sub OnBarDepthScrollBarValueChanged(ByVal arg As NValueChangeEventArgs)
            Dim gapFactor = CDbl(arg.NewValue) / 100

            m_Bar1.DepthGapFactor = gapFactor
            m_Bar2.DepthGapFactor = gapFactor
            m_Bar3.DepthGapFactor = gapFactor
            m_Bar4.DepthGapFactor = gapFactor
        End Sub

        Private Sub OnPositiveDataButtonClick(ByVal arg As NEventArgs)
            m_Bar1.DataPoints.Clear()
            m_Bar2.DataPoints.Clear()
            m_Bar3.DataPoints.Clear()
            m_Bar4.DataPoints.Clear()

            Dim random As Random = New Random()
            For i = 0 To 5
                m_Bar1.DataPoints.Add(New NBarDataPoint(random.Next(100)))
                m_Bar2.DataPoints.Add(New NBarDataPoint(random.Next(100)))
                m_Bar3.DataPoints.Add(New NBarDataPoint(random.Next(100)))
                m_Bar4.DataPoints.Add(New NBarDataPoint(random.Next(100)))
            Next
        End Sub

        Private Sub OnPositiveAndNegativeDataButtonClick(ByVal arg As NEventArgs)
            m_Bar1.DataPoints.Clear()
            m_Bar2.DataPoints.Clear()
            m_Bar3.DataPoints.Clear()
            m_Bar4.DataPoints.Clear()

            Dim random As Random = New Random()
            For i = 0 To 11
                m_Bar1.DataPoints.Add(New NBarDataPoint(random.Next(100) - 50))
                m_Bar2.DataPoints.Add(New NBarDataPoint(random.Next(100) - 50))
                m_Bar3.DataPoints.Add(New NBarDataPoint(random.Next(100) - 50))
                m_Bar4.DataPoints.Add(New NBarDataPoint(random.Next(100) - 50))
            Next
        End Sub

        Private Sub OnBarShapeComoboSelectedIndexChanged(ByVal arg As NValueChangeEventArgs)
            m_Bar1.Shape = CType(arg.NewValue, ENBarShape)
            m_Bar2.Shape = CType(arg.NewValue, ENBarShape)
            m_Bar3.Shape = CType(arg.NewValue, ENBarShape)
            m_Bar4.Shape = CType(arg.NewValue, ENBarShape)
        End Sub

#End Region

#Region "Fields"

        Private m_Chart As NCartesianChart
        Private m_Bar1 As NBarSeries
        Private m_Bar2 As NBarSeries
        Private m_Bar3 As NBarSeries
        Private m_Bar4 As NBarSeries

#End Region

#Region "Schema"

        Public Shared ReadOnly NManhattanBarExampleSchema As NSchema

#End Region
    End Class
End Namespace

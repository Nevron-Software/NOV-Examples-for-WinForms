Imports System

Imports Nevron.Nov.Chart
Imports Nevron.Nov.Dom
Imports Nevron.Nov.Graphics
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.Chart
    ''' <summary>
    ''' Error Bar Example
    ''' </summary>
    Public Class NStandardErrorBarExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' Default constructor
        ''' </summary>
        Public Sub New()

        End Sub
        ''' <summary>
        ''' Static constructor
        ''' </summary>
        Shared Sub New()
            NStandardErrorBarExampleSchema = NSchema.Create(GetType(NStandardErrorBarExample), NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            Dim chartViewWithCommandBars As NChartViewWithCommandBars = New NChartViewWithCommandBars()
            Dim chartView = chartViewWithCommandBars.View
            chartView.Surface.CreatePredefinedChart(ENPredefinedChartType.Cartesian)

            ' configure title
            chartView.Surface.Titles(0).Text = "Standard Error Bar"

            ' configure chart
            Dim chart = CType(chartView.Surface.Charts(0), NCartesianChart)

            chart.SetPredefinedCartesianAxes(ENPredefinedCartesianAxis.XYLinear)

            ' add interlace stripe
            Dim stripStyle As NScaleStrip = New NScaleStrip(New NColorFill(NColor.Beige), Nothing, True, 0, 0, 1, 1)
            stripStyle.Interlaced = True
            chart.Axes(ENCartesianAxis.PrimaryY).Scale.Strips.Add(stripStyle)
            chart.Axes(ENCartesianAxis.PrimaryY).Scale.MajorGridLines.Visible = True

            chart.Axes(ENCartesianAxis.PrimaryY).Scale.ViewRangeInflateMode = ENScaleViewRangeInflateMode.MajorTick
            chart.Axes(ENCartesianAxis.PrimaryY).Scale.InflateViewRangeBegin = True
            chart.Axes(ENCartesianAxis.PrimaryY).Scale.InflateViewRangeEnd = True
            chart.Axes(ENCartesianAxis.PrimaryX).Scale.ViewRangeInflateMode = ENScaleViewRangeInflateMode.MajorTick
            chart.Axes(ENCartesianAxis.PrimaryX).Scale.InflateViewRangeBegin = True
            chart.Axes(ENCartesianAxis.PrimaryX).Scale.InflateViewRangeEnd = True

            ' add an error bar series
            m_ErrorBar = New NErrorBarSeries()
            chart.Series.Add(m_ErrorBar)
            m_ErrorBar.DataLabelStyle = New NDataLabelStyle(False)
            m_ErrorBar.Stroke = New NStroke(NColor.Black)
            m_ErrorBar.UseXValues = True

            GenerateData()

            chartView.Document.StyleSheets.ApplyTheme(New NChartTheme(ENChartPalette.Bright, ENChartPaletteTarget.Series))

            Return chartViewWithCommandBars
        End Function
        Protected Overrides Function CreateExampleControls() As NWidget
            Dim stack As NStackPanel = New NStackPanel()
            Dim group As NUniSizeBoxGroup = New NUniSizeBoxGroup(stack)

            Dim inflateMarginsCheckBox As NCheckBox = New NCheckBox("Inflate Margins")
            inflateMarginsCheckBox.CheckedChanged += AddressOf OnInflateMarginsCheckBoxCheckedChanged
            inflateMarginsCheckBox.Checked = True
            stack.Add(inflateMarginsCheckBox)

            Dim showUpperXErrorCheckBox As NCheckBox = New NCheckBox("Show Upper X Error")
            showUpperXErrorCheckBox.CheckedChanged += AddressOf OnShowUpperXErrorCheckBoxCheckedChanged
            showUpperXErrorCheckBox.Checked = True
            stack.Add(showUpperXErrorCheckBox)

            Dim showLowerXErrorCheckBox As NCheckBox = New NCheckBox("Show Lower X Error")
            showLowerXErrorCheckBox.CheckedChanged += AddressOf OnShowLowerXErrorCheckBoxCheckedChanged
            showLowerXErrorCheckBox.Checked = True
            stack.Add(showLowerXErrorCheckBox)

            Dim xErrorSizeUpDown As NNumericUpDown = New NNumericUpDown()
            xErrorSizeUpDown.Value = m_ErrorBar.XErrorSize
            xErrorSizeUpDown.ValueChanged += AddressOf OnXErrorSizeUpDownValueChanged
            stack.Add(NPairBox.Create("X Error Size:", xErrorSizeUpDown))

            Dim showUpperYErrorCheckBox As NCheckBox = New NCheckBox("Show Upper Y Error")
            showUpperYErrorCheckBox.CheckedChanged += AddressOf OnShowUpperYErrorCheckBoxCheckedChanged
            showUpperYErrorCheckBox.Checked = True
            stack.Add(showUpperYErrorCheckBox)

            Dim showLowerYErrorCheckBox As NCheckBox = New NCheckBox("Show Lower Y Error")
            showLowerYErrorCheckBox.CheckedChanged += AddressOf OnShowLowerYErrorCheckBoxCheckedChanged
            showLowerYErrorCheckBox.Checked = True
            stack.Add(showLowerYErrorCheckBox)

            Dim yErrorSizeUpDown As NNumericUpDown = New NNumericUpDown()
            yErrorSizeUpDown.Value = m_ErrorBar.YErrorSize
            yErrorSizeUpDown.ValueChanged += AddressOf OnYErrorSizeUpDownValueChanged
            stack.Add(NPairBox.Create("X Error Size:", yErrorSizeUpDown))

            Return group
        End Function
        Protected Overrides Function GetExampleDescription() As String
            Return "<p>This example demonstrates the functionality of the error bar series.</p>"
        End Function

#End Region

#Region "Implementation"

        Private Sub GenerateData()
            m_ErrorBar.DataPoints.Clear()

            Dim y As Double
            Dim x = 50.0

            Dim random As Random = New Random()

            For i = 0 To 14
                y = 20 + random.NextDouble() * 30
                x += 2.0 + random.NextDouble() * 2

                Dim lowerYError As Double = 1 + random.NextDouble()
                Dim upperYError As Double = 1 + random.NextDouble()

                Dim lowerXError As Double = 1 + random.NextDouble()
                Dim upperXError As Double = 1 + random.NextDouble()

                m_ErrorBar.DataPoints.Add(New NErrorBarDataPoint(x, y, upperXError, lowerXError, upperYError, lowerYError))
            Next
        End Sub

#End Region

#Region "Event Handlers"

        Private Sub OnInflateMarginsCheckBoxCheckedChanged(ByVal arg As NValueChangeEventArgs)
            m_ErrorBar.InflateMargins = CType(arg.TargetNode, NCheckBox).Checked
        End Sub

        Private Sub OnYErrorSizeUpDownValueChanged(ByVal arg As NValueChangeEventArgs)
            m_ErrorBar.YErrorSize = CType(arg.TargetNode, NNumericUpDown).Value
        End Sub

        Private Sub OnXErrorSizeUpDownValueChanged(ByVal arg As NValueChangeEventArgs)
            m_ErrorBar.XErrorSize = CType(arg.TargetNode, NNumericUpDown).Value
        End Sub

        Private Sub OnShowLowerYErrorCheckBoxCheckedChanged(ByVal arg As NValueChangeEventArgs)
            m_ErrorBar.ShowLowerYError = CType(arg.TargetNode, NCheckBox).Checked
        End Sub

        Private Sub OnShowUpperYErrorCheckBoxCheckedChanged(ByVal arg As NValueChangeEventArgs)
            m_ErrorBar.ShowUpperYError = CType(arg.TargetNode, NCheckBox).Checked
        End Sub

        Private Sub OnShowLowerXErrorCheckBoxCheckedChanged(ByVal arg As NValueChangeEventArgs)
            m_ErrorBar.ShowLowerXError = CType(arg.TargetNode, NCheckBox).Checked
        End Sub

        Private Sub OnShowUpperXErrorCheckBoxCheckedChanged(ByVal arg As NValueChangeEventArgs)
            m_ErrorBar.ShowUpperXError = CType(arg.TargetNode, NCheckBox).Checked
        End Sub

#End Region

#Region "Fields"

        Private m_ErrorBar As NErrorBarSeries

#End Region

#Region "Schema"

        Public Shared ReadOnly NStandardErrorBarExampleSchema As NSchema

#End Region
    End Class
End Namespace

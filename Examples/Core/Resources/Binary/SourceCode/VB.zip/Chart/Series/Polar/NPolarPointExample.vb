Imports System
Imports Nevron.Nov.Chart
Imports Nevron.Nov.Dom
Imports Nevron.Nov.Graphics
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.Chart
    ''' <summary>
    ''' Polar point example
    ''' </summary>
    Public Class NPolarPointExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' Default constructor
        ''' </summary>
        Public Sub New()
        End Sub
        ''' <summary>
        ''' Static constructor
        ''' </summary>
        Shared Sub New()
            NPolarPointExampleSchema = NSchema.Create(GetType(NPolarPointExample), NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            Dim chartView As NChartView = CreatePolarChartView()

            ' configure title
            chartView.Surface.Titles(0).Text = "Polar Point"

            ' configure chart
            m_Chart = CType(chartView.Surface.Charts(0), NPolarChart)
            m_Chart.SetPredefinedPolarAxes(ENPredefinedPolarAxes.AngleValue)

            ' setup polar axis
            Dim linearScale = CType(m_Chart.Axes(ENPolarAxis.PrimaryValue).Scale, NLinearScale)
            linearScale.ViewRangeInflateMode = ENScaleViewRangeInflateMode.MajorTick
            linearScale.InflateViewRangeBegin = True
            linearScale.InflateViewRangeEnd = True
            linearScale.MajorGridLines.Stroke.DashStyle = ENDashStyle.Dot
            Dim strip As NScaleStrip = New NScaleStrip()
            strip.Fill = New NColorFill(NColor.FromColor(NColor.Cyan, 0.4F))
            strip.Interlaced = True
            linearScale.Strips.Add(strip)
            linearScale.MajorGridLines.Visible = True

            ' setup polar angle axis
            Dim angularScale = CType(m_Chart.Axes(ENPolarAxis.PrimaryAngle).Scale, NAngularScale)
            strip = New NScaleStrip()
            strip.Fill = New NColorFill(NColor.FromRGBA(192, 192, 192, 125))
            strip.Interlaced = True
            angularScale.Strips.Add(strip)
            angularScale.MajorGridLines.Visible = True

            ' create three polar point series
            Dim random As Random = New Random()
            Dim s1 = CreatePolarPointSeries("Sample 1", ENPointShape.Ellipse, random)
            Dim s2 = CreatePolarPointSeries("Sample 2", ENPointShape.Rectangle, random)
            Dim s3 = CreatePolarPointSeries("Sample 3", ENPointShape.Triangle, random)

            ' add the series to the chart
            m_Chart.Series.Add(s1)
            m_Chart.Series.Add(s2)
            m_Chart.Series.Add(s3)
            chartView.Document.StyleSheets.ApplyTheme(New NChartTheme(ENChartPalette.Bright, False))
            Return chartView
        End Function

        Protected Overrides Function CreateExampleControls() As NWidget
            Dim stack As NStackPanel = New NStackPanel()
            Dim group As NUniSizeBoxGroup = New NUniSizeBoxGroup(stack)
            Return group
        End Function

        Protected Overrides Function GetExampleDescription() As String
            Return "<p>This example demonstrates how to create a polar point chart.</p>"
        End Function

#End Region

#Region "Event Handlers"



#End Region

#Region "Implementation"

        Private Function CreatePolarPointSeries(ByVal name As String, ByVal shape As ENPointShape, ByVal random As Random) As NSeries
            Dim series As NPolarPointSeries = New NPolarPointSeries()
            series.Name = name
            series.InflateMargins = False
            Dim dataLabelStyle As NDataLabelStyle = New NDataLabelStyle()
            dataLabelStyle.Visible = False
            dataLabelStyle.Format = "<value> - <angle_in_degrees>"
            series.DataLabelStyle = dataLabelStyle
            series.Shape = shape
            series.Size = 3.0

            ' add data
            For i = 0 To 1000 - 1
                series.DataPoints.Add(New NPolarPointDataPoint(random.Next(360), random.Next(100)))
            Next

            Return series
        End Function

#End Region

#Region "Fields"

        Private m_Chart As NPolarChart

#End Region

#Region "Schema"

        Public Shared ReadOnly NPolarPointExampleSchema As NSchema

#End Region

#Region "Static Methods"

        Private Shared Function CreatePolarChartView() As NChartView
            Dim chartView As NChartView = New NChartView()
            chartView.Surface.CreatePredefinedChart(ENPredefinedChartType.Polar)
            Return chartView
        End Function

#End Region
    End Class
End Namespace

Imports System.IO

Imports Nevron.Nov.Chart
Imports Nevron.Nov.Chart.Tools
Imports Nevron.Nov.Dom
Imports Nevron.Nov.Graphics
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.Chart
    ''' <summary>
    ''' Grid Surface Example
    ''' </summary>
    Public Class NTriangulatedSurfaceExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' Default constructor
        ''' </summary>
        Public Sub New()

        End Sub
        ''' <summary>
        ''' Static constructor
        ''' </summary>
        Shared Sub New()
            NTriangulatedSurfaceExampleSchema = NSchema.Create(GetType(NTriangulatedSurfaceExample), NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            Dim chartViewWithCommandBars As NChartViewWithCommandBars = New NChartViewWithCommandBars()
            Dim chartView = chartViewWithCommandBars.View
            chartView.Surface.CreatePredefinedChart(ENPredefinedChartType.Cartesian)

            ' configure title
            chartView.Surface.Titles(0).Text = "Triangulated Surface Chart"

            ' setup chart
            Dim chart = CType(chartView.Surface.Charts(0), NCartesianChart)
            chart.Enable3D = True
            chart.ModelWidth = 60.0F
            chart.ModelDepth = 60.0F
            chart.ModelHeight = 25.0F
            chart.Projection.SetPredefinedProjection(ENPredefinedProjection.PerspectiveTilted)
            chart.LightModel.SetPredefinedLightModel(ENPredefinedLightModel.ShinyTopLeft)
            chart.Interactor = New NInteractor(New NTrackballTool())

            Dim scale As NLinearScale = chart.Axes(ENCartesianAxis.PrimaryY).Scale
            scale.ViewRangeInflateMode = ENScaleViewRangeInflateMode.None

            ' setup axes
            Dim ordinalScale As NOrdinalScale = chart.Axes(ENCartesianAxis.PrimaryX).Scale
            ordinalScale.MajorGridLines.SetShowAtWall(ENChartWall.Bottom, True)
            ordinalScale.MajorGridLines.SetShowAtWall(ENChartWall.Back, True)
            ordinalScale.DisplayDataPointsBetweenTicks = False

            ordinalScale = chart.Axes(ENCartesianAxis.Depth).Scale
            ordinalScale.MajorGridLines.SetShowAtWall(ENChartWall.Bottom, True)
            ordinalScale.MajorGridLines.SetShowAtWall(ENChartWall.Left, True)
            ordinalScale.DisplayDataPointsBetweenTicks = False

            ' add the surface series
            m_Surface = New NTriangulatedSurfaceSeries()
            chart.Series.Add(m_Surface)

            m_Surface.Name = "Surface"
            m_Surface.LegendView.Mode = ENSeriesLegendMode.SeriesLogic
            m_Surface.FlatPositionValue = 10.0

            m_Surface.Palette.InterpolateColors = False

            m_Surface.ValueFormatter = New NNumericValueFormatter("0.00")
            m_Surface.Fill = New NColorFill(NColor.YellowGreen)

            m_Surface.FillMode = ENSurfaceFillMode.Zone
            m_Surface.FrameMode = ENSurfaceFrameMode.Contour
            m_Surface.FrameColorMode = ENSurfaceFrameColorMode.Uniform

            FillData()

            Return chartViewWithCommandBars
        End Function

        Private Sub FillData()
            Dim stream As Stream = Nothing
            Dim reader As BinaryReader = Nothing

            Try
                ' fill the XYZ data from a binary resource
                stream = New MemoryStream(NResources.RBIN_SampleData_DataXYZ_bin.Data)
                reader = New BinaryReader(stream)

                Dim nDataPointsCount As Integer = stream.Length / 12

                m_Surface.Data.SetCapacity(nDataPointsCount)
                Dim data = New NVector3DF(nDataPointsCount - 1) {}

                ' fill Y values
                For i = 0 To nDataPointsCount - 1
                    data(i).Y = reader.ReadSingle()
                Next

                ' fill X values
                For i = 0 To nDataPointsCount - 1
                    data(i).X = reader.ReadSingle()
                Next

                ' fill Z values
                For i = 0 To nDataPointsCount - 1
                    data(i).Z = reader.ReadSingle()
                Next

                For i = 0 To nDataPointsCount - 1
                    m_Surface.Data.AddValue(data(i))
                Next

            Finally
                If reader IsNot Nothing Then reader.Close()

                If stream IsNot Nothing Then stream.Close()
            End Try
        End Sub


        Protected Overrides Function CreateExampleControls() As NWidget
            Dim stack As NStackPanel = New NStackPanel()
            Dim group As NUniSizeBoxGroup = New NUniSizeBoxGroup(stack)

            Dim fillModeCombo As NComboBox = New NComboBox()
            fillModeCombo.FillFromEnum(Of ENSurfaceFillMode)()
            fillModeCombo.SelectedIndexChanged += AddressOf OnFillModeComboSelectedIndexChanged
            fillModeCombo.SelectedIndex = m_Surface.FillMode
            stack.Add(NPairBox.Create("Fill Mode:", fillModeCombo))

            Dim frameModeCombo As NComboBox = New NComboBox()
            frameModeCombo.FillFromEnum(Of ENSurfaceFrameMode)()
            frameModeCombo.SelectedIndexChanged += AddressOf OnFrameModeComboSelectedIndexChanged
            frameModeCombo.SelectedIndex = m_Surface.FrameMode
            stack.Add(NPairBox.Create("Frame Mode:", frameModeCombo))

            Dim frameColorModeCombo As NComboBox = New NComboBox()
            frameColorModeCombo.FillFromEnum(Of ENSurfaceFrameColorMode)()
            frameColorModeCombo.SelectedIndexChanged += AddressOf OnFrameColorModeComboSelectedIndexChanged
            frameColorModeCombo.SelectedIndex = m_Surface.FrameColorMode
            stack.Add(NPairBox.Create("Frame Color Mode:", frameColorModeCombo))

            Dim smoothShadingCheckBox As NCheckBox = New NCheckBox()
            smoothShadingCheckBox.CheckedChanged += AddressOf OnSmoothShadingCheckBoxCheckedChanged
            smoothShadingCheckBox.Checked = False
            smoothShadingCheckBox.HorizontalPlacement = Layout.ENHorizontalPlacement.Left
            stack.Add(NPairBox.Create("Smooth Shading:", smoothShadingCheckBox))

            Dim drawFlatCheckBox As NCheckBox = New NCheckBox()
            drawFlatCheckBox.CheckedChanged += AddressOf OnDrawFlatCheckBoxCheckedChanged
            drawFlatCheckBox.Checked = False
            drawFlatCheckBox.HorizontalPlacement = Layout.ENHorizontalPlacement.Left
            stack.Add(NPairBox.Create("Draw Flat:", drawFlatCheckBox))

            Dim smoothPaletteCheckBox As NCheckBox = New NCheckBox()
            smoothPaletteCheckBox.CheckedChanged += AddressOf OnSmoothPaletteCheckBoxCheckedChanged
            smoothPaletteCheckBox.Checked = False
            smoothPaletteCheckBox.HorizontalPlacement = Layout.ENHorizontalPlacement.Left
            stack.Add(NPairBox.Create("Smooth Palette:", smoothPaletteCheckBox))

            Return group
        End Function

        Private Sub OnSmoothPaletteCheckBoxCheckedChanged(ByVal arg As NValueChangeEventArgs)
            m_Surface.Palette.InterpolateColors = CBool(arg.NewValue)
        End Sub

        Private Sub OnDrawFlatCheckBoxCheckedChanged(ByVal arg As NValueChangeEventArgs)
            m_Surface.DrawFlat = CBool(arg.NewValue)
        End Sub

        Private Sub OnFrameColorModeComboSelectedIndexChanged(ByVal arg As NValueChangeEventArgs)
            m_Surface.FrameColorMode = CType(arg.NewValue, ENSurfaceFrameColorMode)
        End Sub

        Private Sub OnSmoothShadingCheckBoxCheckedChanged(ByVal arg As NValueChangeEventArgs)
            m_Surface.ShadingMode = If(arg.NewValue, ENShadingMode.Smooth, ENShadingMode.Flat)
        End Sub

        Private Sub OnFrameModeComboSelectedIndexChanged(ByVal arg As NValueChangeEventArgs)
            m_Surface.FrameMode = CType(arg.NewValue, ENSurfaceFrameMode)
        End Sub

        Private Sub OnFillModeComboSelectedIndexChanged(ByVal arg As NValueChangeEventArgs)
            m_Surface.FillMode = CType(arg.NewValue, ENSurfaceFillMode)
        End Sub

        Protected Overrides Function GetExampleDescription() As String
            Return "<p>This example demonstrates how to create a scatter funnel chart.</p>"
        End Function

#End Region

#Region "Fields"

        Private m_Surface As NTriangulatedSurfaceSeries

#End Region

#Region "Schema"

        Public Shared ReadOnly NTriangulatedSurfaceExampleSchema As NSchema

#End Region
    End Class
End Namespace

Imports System

Imports Nevron.Nov.Chart
Imports Nevron.Nov.Dom
Imports Nevron.Nov.Graphics
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.Chart
    ''' <summary>
    ''' Standard Area Example
    ''' </summary>
    Public Class NAreaLabelsExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' Default constructor
        ''' </summary>
        Public Sub New()

        End Sub
        ''' <summary>
        ''' Static constructor
        ''' </summary>
        Shared Sub New()
            NAreaLabelsExampleSchema = NSchema.Create(GetType(NAreaLabelsExample), NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            Dim chartViewWithCommandBars As NChartViewWithCommandBars = New NChartViewWithCommandBars()
            Dim chartView = chartViewWithCommandBars.View
            chartView.Surface.CreatePredefinedChart(ENPredefinedChartType.Cartesian)

            ' configure title
            chartView.Surface.Titles(0).Text = "Area Labels"

            ' configure chart
            m_Chart = CType(chartView.Surface.Charts(0), NCartesianChart)

            m_Chart.SetPredefinedCartesianAxes(ENPredefinedCartesianAxis.XYLinear)

            ' add interlaced stripe for Y axis
            Dim stripStyle As NScaleStrip = New NScaleStrip(New NColorFill(NColor.Beige), Nothing, True, 0, 0, 1, 1)
            stripStyle.Interlaced = True

            Dim scaleY As NLinearScale = m_Chart.Axes(ENCartesianAxis.PrimaryY).Scale
            scaleY.Strips.Add(stripStyle)

            scaleY.MajorGridLines.Visible = True

            m_Area = New NAreaSeries()
            m_Chart.Series.Add(m_Area)

            ' setup area series
            m_Area.InflateMargins = True
            m_Area.UseXValues = True
            m_Area.ValueFormatter = New NNumericValueFormatter("0.000")

            m_Area.Fill = New NColorFill(NColor.DarkOrange)
            m_Area.Stroke = New NStroke(NColor.Black)

            Dim dataLabelStyle As NDataLabelStyle = New NDataLabelStyle()
            dataLabelStyle.Visible = True
            dataLabelStyle.VertAlign = ENVerticalAlignment.Top
            dataLabelStyle.ArrowLength = 20
            dataLabelStyle.ArrowStroke = New NStroke(NColor.Black)
            dataLabelStyle.Format = "<value>"
            dataLabelStyle.TextStyle.Background.Visible = True
            dataLabelStyle.TextStyle.Background.Padding = New NMargins(0)

            m_Area.DataLabelStyle = dataLabelStyle

            ' disable initial label positioning
            m_Chart.LabelLayout.EnableInitialPositioning = False

            ' enable label adjustment
            m_Chart.LabelLayout.EnableLabelAdjustment = True

            ' enable the data point safesuard and set its size
            m_Area.LabelLayout.EnableDataPointSafeguard = True
            m_Area.LabelLayout.DataPointSafeguardSize = New NSize(2, 2)

            ' fill with random data
            OnGenerateDataButtonClick(Nothing)

            Return chartViewWithCommandBars
        End Function
        Protected Overrides Function CreateExampleControls() As NWidget
            Dim stack As NStackPanel = New NStackPanel()
            Dim boxGroup As NUniSizeBoxGroup = New NUniSizeBoxGroup(stack)

            Dim enableLabelAdjustmentCheckBox As NCheckBox = New NCheckBox("Enable Label Adjustment")
            enableLabelAdjustmentCheckBox.CheckedChanged += New [Function](Of NValueChangeEventArgs)(AddressOf OnEnableLabelAdjustmentCheckBoxCheckedChanged)
            stack.Add(enableLabelAdjustmentCheckBox)
            enableLabelAdjustmentCheckBox.Checked = True

            Dim enableDataPointSafeGuardCheckBox As NCheckBox = New NCheckBox("Enable Data Point Safeguard")
            enableDataPointSafeGuardCheckBox.CheckedChanged += New [Function](Of NValueChangeEventArgs)(AddressOf OnEnableDataPointSafeGuardCheckBoxCheckedChanged)
            stack.Add(enableDataPointSafeGuardCheckBox)
            enableDataPointSafeGuardCheckBox.Checked = True

            Dim generateDataButton As NButton = New NButton("Generate Data")
            generateDataButton.Click += New [Function](Of NEventArgs)(AddressOf OnGenerateDataButtonClick)
            stack.Add(generateDataButton)

            Return boxGroup
        End Function
        Protected Overrides Function GetExampleDescription() As String
            Return "<p>This example demonstrates how the automatic data label layout works with area data labels.</p>"
        End Function

#End Region

#Region "Event Handlers"

        Private Sub OnEnableLabelAdjustmentCheckBoxCheckedChanged(ByVal arg As NValueChangeEventArgs)
            m_Chart.LabelLayout.EnableLabelAdjustment = CType(arg.TargetNode, NCheckBox).Checked
        End Sub

        Private Sub OnEnableDataPointSafeGuardCheckBoxCheckedChanged(ByVal arg As NValueChangeEventArgs)
            m_Area.LabelLayout.EnableDataPointSafeguard = CType(arg.TargetNode, NCheckBox).Checked
        End Sub

        Private Sub OnGenerateDataButtonClick(ByVal arg As NEventArgs)
            m_Area.DataPoints.Clear()

            Dim xvalue As Double = 10
            Dim random As Random = New Random()

            For i = 0 To 23
                Dim value As Double = Math.Sin(i * 0.4) * 5 + random.NextDouble() * 3
                xvalue += 1 + random.NextDouble() * 20

                m_Area.DataPoints.Add(New NAreaDataPoint(xvalue, value))
            Next
        End Sub


#End Region

#Region "Fields"

        Private m_Chart As NCartesianChart
        Private m_Area As NAreaSeries

#End Region

#Region "Static Fields"

        Friend Shared monthValues As Double() = New Double() {16, 19, 16, 15, 18, 19, 24, 21, 22, 17, 19, 15}
        Friend Shared monthLetters As String() = New String() {"J", "F", "M", "A", "M", "J", "J", "A", "S", "O", "N", "D"}

#End Region

#Region "Schema"

        Public Shared ReadOnly NAreaLabelsExampleSchema As NSchema

#End Region
    End Class
End Namespace

Imports Nevron.Nov.Chart
Imports Nevron.Nov.Chart.Tools
Imports Nevron.Nov.Dom
Imports Nevron.Nov.Graphics
Imports Nevron.Nov.UI
Imports System

Namespace Nevron.Nov.Examples.Chart
    ''' <summary>
    ''' Grid Surface Projected Contour Example
    ''' </summary>
    Public Class NGridSurfaceSpacingExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' Default constructor
        ''' </summary>
        Public Sub New()

        End Sub
        ''' <summary>
        ''' Static constructor
        ''' </summary>
        Shared Sub New()
            NGridSurfaceSpacingExampleSchema = NSchema.Create(GetType(NGridSurfaceSpacingExample), NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        ''' <summary>
        ''' 
        ''' </summary>
        ''' <returns></returns>
        Protected Overrides Function CreateExampleContent() As NWidget
            Dim chartViewWithCommandBars As NChartViewWithCommandBars = New NChartViewWithCommandBars()
            Dim chartView = chartViewWithCommandBars.View
            chartView.Surface.CreatePredefinedChart(ENPredefinedChartType.Cartesian)

            ' configure title
            chartView.Surface.Titles(0).Text = "Grid Surface Grid Spacing"

            ' setup chart
            Dim chart = CType(chartView.Surface.Charts(0), NCartesianChart)
            chart.Enable3D = True
            chart.ModelWidth = 55.0F
            chart.ModelDepth = 55.0F
            chart.ModelHeight = 45.0F
            chart.Projection.SetPredefinedProjection(ENPredefinedProjection.PerspectiveTilted)
            chart.LightModel.SetPredefinedLightModel(ENPredefinedLightModel.SoftCameraLight)
            chart.Interactor = New NInteractor(New NTrackballTool())

            ' add a surface series
            m_Surface = New NGridSurfaceSeries()
            chart.Series.Add(m_Surface)
            m_Surface.Name = "Surface"
            m_Surface.LegendView.Mode = ENSeriesLegendMode.None
            m_Surface.Fill = New NColorFill(NColor.FromRGB(160, 170, 212))
            m_Surface.FillMode = ENSurfaceFillMode.Uniform
            m_Surface.FrameMode = ENSurfaceFrameMode.Mesh
            m_Surface.CellTriangulationMode = ENSurfaceCellTriangulationMode.Diagonal1
            m_Surface.Data.SetGridSize(500, 500)

            ' setup axes
            Dim scaleX As NLinearScale = New NLinearScale()
            chart.Axes(ENCartesianAxis.PrimaryX).Scale = scaleX
            scaleX.MajorGridLines.ShowAtWalls = ENChartWall.Bottom Or ENChartWall.Back
            scaleX.InflateViewRangeBegin = False
            scaleX.InflateViewRangeEnd = False

            Dim scaleZ As NLinearScale = New NLinearScale()
            chart.Axes(ENCartesianAxis.Depth).Scale = scaleZ
            scaleZ.MajorGridLines.ShowAtWalls = ENChartWall.Bottom Or ENChartWall.Left
            scaleZ.InflateViewRangeBegin = False
            scaleZ.InflateViewRangeEnd = False

            ' specify that the surface should use custom X and Z values
            m_Surface.XValuesMode = ENGridSurfaceValuesMode.CustomValues
            m_Surface.ZValuesMode = ENGridSurfaceValuesMode.CustomValues

            m_Surface.Data.SetGridSize(40, 40)

            GenerateCustomXValues(m_Surface)
            GenerateCustomZValues(m_Surface)
            FillData(m_Surface)

            Return chartViewWithCommandBars
        End Function

        Private Sub GenerateCustomXValues(ByVal surface As NGridSurfaceSeries)
            Dim sizeX = surface.Data.GridSizeX

            Dim x As Double = 0
            Dim xValues = New Double(sizeX - 1) {}
            Dim random As Random = New Random()

            For i = 0 To sizeX - 1
                xValues(i) = x
                x += random.NextDouble() * 10.0
            Next

            surface.XValues = New NDomArray(Of Double)(xValues)
        End Sub

        Private Sub GenerateCustomZValues(ByVal surface As NGridSurfaceSeries)
            Dim sizeZ = surface.Data.GridSizeZ

            Dim zValues = New Double(sizeZ - 1) {}
            Dim z As Double = 0
            Dim random As Random = New Random()

            For i = 0 To sizeZ - 1
                zValues(i) = z
                z += random.NextDouble() * 10
            Next

            surface.ZValues = New NDomArray(Of Double)(zValues)
        End Sub

        Private Sub FillData(ByVal surface As NGridSurfaceSeries)
            Dim nCountX = surface.Data.GridSizeX
            Dim nCountZ = surface.Data.GridSizeZ

            Dim sizeXOrigin = -2.3
            Dim sizeXScale = 4.6 / nCountX


            For z = 0 To nCountZ - 1
                For x = 0 To nCountX - 1
                    Dim xVal = x * sizeXScale + sizeXOrigin
                    Dim yVal = z * sizeXScale + sizeXOrigin

                    Dim zVal = xVal * Math.Exp(-(xVal * xVal + yVal * yVal))

                    surface.Data.SetValue(x, z, zVal)
                Next
            Next
        End Sub

        Protected Overrides Function CreateExampleControls() As NWidget
            Dim stack As NStackPanel = New NStackPanel()
            Dim group As NUniSizeBoxGroup = New NUniSizeBoxGroup(stack)

            Dim spacingComboBox As NComboBox = New NComboBox()
            spacingComboBox.FillFromEnum(Of ENGridSurfaceValuesMode)()
            stack.Add(NPairBox.Create("Spacing Mode:", spacingComboBox))

            m_XGridOriginNumericUpDown = New NNumericUpDown()
            stack.Add(NPairBox.Create("X Origin:", m_XGridOriginNumericUpDown))
            Me.m_XGridOriginNumericUpDown.ValueChanged += AddressOf OnXOriginNumericUpDownValueChanged

            m_XGridStepNumericUpDown = New NNumericUpDown()
            stack.Add(NPairBox.Create("X Grid Step:", m_XGridStepNumericUpDown))
            Me.m_XGridStepNumericUpDown.ValueChanged += AddressOf OnXGridStepNumericUpDownValueChanged

            m_ZGridOriginNumericUpDown = New NNumericUpDown()
            stack.Add(NPairBox.Create("Z Origin:", m_ZGridOriginNumericUpDown))
            Me.m_ZGridOriginNumericUpDown.ValueChanged += AddressOf OnZOriginNumericUpDownValueChanged

            m_ZGridStepNumericUpDown = New NNumericUpDown()
            stack.Add(NPairBox.Create("Z Grid Step:", m_ZGridStepNumericUpDown))
            Me.m_ZGridStepNumericUpDown.ValueChanged += AddressOf OnZGridStepNumericUpDownValueChanged

            spacingComboBox.SelectedIndexChanged += AddressOf OnSpacingModeComboBoxSelectedIndexChanged
            spacingComboBox.SelectedIndex = 1

            m_XGridOriginNumericUpDown.Value = 0
            m_ZGridOriginNumericUpDown.Value = 0
            m_XGridStepNumericUpDown.Value = 1
            m_ZGridStepNumericUpDown.Value = 1

            Return group
        End Function

        Private Sub OnXGridStepNumericUpDownValueChanged(ByVal arg As NValueChangeEventArgs)
            m_Surface.StepX = CDbl(arg.NewValue)
        End Sub

        Private Sub OnXOriginNumericUpDownValueChanged(ByVal arg As NValueChangeEventArgs)
            m_Surface.OriginX = CDbl(arg.NewValue)
        End Sub

        Private Sub OnZOriginNumericUpDownValueChanged(ByVal arg As NValueChangeEventArgs)
            m_Surface.OriginZ = CDbl(arg.NewValue)
        End Sub

        Private Sub OnZGridStepNumericUpDownValueChanged(ByVal arg As NValueChangeEventArgs)
            m_Surface.StepZ = CDbl(arg.NewValue)
        End Sub

        Protected Overrides Function GetExampleDescription() As String
            Return "<p>This example demonstrates how to control the spacing between the grid cells in a grid surface series.</p>"
        End Function

#End Region

#Region "Events"

        Private Sub OnEnableShaderRenderingCheckBoxCheckedChanged(ByVal arg As NValueChangeEventArgs)
            m_Surface.EnableShaderRendering = CBool(arg.NewValue)
        End Sub

        Private Sub OnSpacingModeComboBoxSelectedIndexChanged(ByVal arg As NValueChangeEventArgs)
            Dim valuesMode As ENGridSurfaceValuesMode = arg.NewValue
            m_Surface.XValuesMode = valuesMode
            m_Surface.ZValuesMode = valuesMode

            Dim originAndStepMode = valuesMode Is ENGridSurfaceValuesMode.OriginAndStep

            m_XGridOriginNumericUpDown.Enabled = originAndStepMode
            m_XGridStepNumericUpDown.Enabled = originAndStepMode
            m_ZGridOriginNumericUpDown.Enabled = originAndStepMode
            m_ZGridStepNumericUpDown.Enabled = originAndStepMode
        End Sub

#End Region

#Region "Fields"

        Private m_Surface As NGridSurfaceSeries
        Private m_XGridOriginNumericUpDown As NNumericUpDown
        Private m_XGridStepNumericUpDown As NNumericUpDown
        Private m_ZGridOriginNumericUpDown As NNumericUpDown
        Private m_ZGridStepNumericUpDown As NNumericUpDown

#End Region

#Region "Schema"

        Public Shared ReadOnly NGridSurfaceSpacingExampleSchema As NSchema

#End Region
    End Class
End Namespace

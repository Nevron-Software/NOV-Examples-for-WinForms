Imports System
Imports Nevron.Nov.Chart
Imports Nevron.Nov.Dom
Imports Nevron.Nov.Graphics
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.Chart
    ''' <summary>
    ''' Polar range example
    ''' </summary>
    Public Class NPolarRangeExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' Default constructor
        ''' </summary>
        Public Sub New()
        End Sub
        ''' <summary>
        ''' Static constructor
        ''' </summary>
        Shared Sub New()
            NPolarRangeExampleSchema = NSchema.Create(GetType(NPolarRangeExample), NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            Dim chartView As NChartView = CreatePolarChartView()

            ' configure title
            chartView.Surface.Titles(0).Text = "Polar Range"

            ' configure chart
            m_Chart = CType(chartView.Surface.Charts(0), NPolarChart)
            m_Chart.SetPredefinedPolarAxes(ENPredefinedPolarAxes.AngleValue)

            ' setup polar axis
            Dim linearScale = CType(m_Chart.Axes(ENPolarAxis.PrimaryValue).Scale, NLinearScale)
            linearScale.ViewRangeInflateMode = ENScaleViewRangeInflateMode.MajorTick
            linearScale.InflateViewRangeBegin = True
            linearScale.InflateViewRangeEnd = True
            linearScale.MajorGridLines.Visible = True
            Dim strip As NScaleStrip = New NScaleStrip()
            strip.Fill = New NColorFill(New NColor(NColor.Gray, 100))
            strip.Interlaced = True
            linearScale.Strips.Add(strip)
            linearScale.MajorGridLines.Visible = True

            ' setup polar angle axis			
            Dim angleAxis = m_Chart.Axes(ENPolarAxis.PrimaryAngle)
            Dim ordinalScale As NOrdinalScale = New NOrdinalScale()
            strip = New NScaleStrip()
            strip.Fill = New NColorFill(New NColor(NColor.DarkGray, 100))
            strip.Interlaced = True
            ordinalScale.Strips.Add(strip)
            ordinalScale.InflateContentRange = False
            ordinalScale.MajorTickMode = ENMajorTickMode.CustomTicks
            ordinalScale.DisplayDataPointsBetweenTicks = False
            ordinalScale.MajorTickMode = ENMajorTickMode.CustomStep
            ordinalScale.CustomStep = 1
            Dim labels = New String() {"E", "NE", "N", "NW", "W", "SW", "S", "SE"}
            ordinalScale.Labels.TextProvider = New NOrdinalScaleLabelTextProvider(labels)
            ordinalScale.Labels.DisplayLast = False
            angleAxis.Scale = ordinalScale
            angleAxis.ViewRangeMode = ENAxisViewRangeMode.FixedRange
            angleAxis.MinViewRangeValue = 0
            angleAxis.MaxViewRangeValue = 8
            Dim polarRange As NPolarRangeSeries = New NPolarRangeSeries()
            polarRange.DataLabelStyle = New NDataLabelStyle(False)
            m_Chart.Series.Add(polarRange)
            Dim rand As Random = New Random()

            For i = 0 To 8 - 1
                polarRange.DataPoints.Add(New NPolarRangeDataPoint(i - 0.4, 0.0, i + 0.4, rand.Next(80) + 20.0))
            Next

            chartView.Document.StyleSheets.ApplyTheme(New NChartTheme(ENChartPalette.Bright, False))
            Return chartView
        End Function

        Protected Overrides Function CreateExampleControls() As NWidget
            Dim stack As NStackPanel = New NStackPanel()
            Dim group As NUniSizeBoxGroup = New NUniSizeBoxGroup(stack)
            Return group
        End Function

        Protected Overrides Function GetExampleDescription() As String
            Return "<p>This example demonstrates how to create a polar range chart.</p>"
        End Function

#End Region

#Region "Event Handlers"



#End Region

#Region "Implementation"

        ''' <summary>
        ''' 
        ''' </summary>
        ''' <paramname="series"></param>
        ''' <paramname="count"></param>
        Friend Shared Sub Curve1(ByVal series As NPolarLineSeries, ByVal count As Integer)
            series.DataPoints.Clear()
            Dim angleStep = 2 * Math.PI / count

            For i = 0 To count - 1
                Dim angle = i * angleStep
                Dim radius = 1 + Math.Cos(angle)
                series.DataPoints.Add(New NPolarLineDataPoint(angle * 180 / Math.PI, radius))
            Next
        End Sub
        ''' <summary>
        ''' 
        ''' </summary>
        ''' <paramname="series"></param>
        ''' <paramname="count"></param>
        Friend Shared Sub Curve2(ByVal series As NPolarLineSeries, ByVal count As Integer)
            series.DataPoints.Clear()
            Dim angleStep = 2 * Math.PI / count

            For i = 0 To count - 1
                Dim angle = i * angleStep
                Dim radius = 0.2 + 1.7 * Math.Sin(2 * angle) + 1.7 * Math.Cos(2 * angle)
                radius = Math.Abs(radius)
                series.DataPoints.Add(New NPolarLineDataPoint(angle * 180 / Math.PI, radius))
            Next
        End Sub
        ''' <summary>
        ''' 
        ''' </summary>
        ''' <paramname="series"></param>
        ''' <paramname="count"></param>
        Friend Shared Sub Curve3(ByVal series As NPolarLineSeries, ByVal count As Integer)
            series.DataPoints.Clear()
            Dim angleStep = 4 * Math.PI / count

            For i = 0 To count - 1
                Dim angle = i * angleStep
                Dim radius = 0.2 + angle / 5.0
                series.DataPoints.Add(New NPolarLineDataPoint(angle * 180 / Math.PI, radius))
            Next
        End Sub

#End Region

#Region "Fields"

        Private m_Chart As NPolarChart

#End Region

#Region "Schema"

        Public Shared ReadOnly NPolarRangeExampleSchema As NSchema

#End Region

#Region "Static Methods"

        Private Shared Function CreatePolarChartView() As NChartView
            Dim chartView As NChartView = New NChartView()
            chartView.Surface.CreatePredefinedChart(ENPredefinedChartType.Polar)
            Return chartView
        End Function

#End Region
    End Class
End Namespace

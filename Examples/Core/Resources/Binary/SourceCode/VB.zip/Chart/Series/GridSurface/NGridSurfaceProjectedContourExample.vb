Imports Nevron.Nov.Chart
Imports Nevron.Nov.Chart.Tools
Imports Nevron.Nov.Dom
Imports Nevron.Nov.Graphics
Imports Nevron.Nov.UI
Imports System
Imports System.IO

Namespace Nevron.Nov.Examples.Chart
    ''' <summary>
    ''' Grid Surface Projected Contour Example
    ''' </summary>
    Public Class NGridSurfaceProjectedContourExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' Default constructor
        ''' </summary>
        Public Sub New()

        End Sub
        ''' <summary>
        ''' Static constructor
        ''' </summary>
        Shared Sub New()
            NGridSurfaceProjectedContourExampleSchema = NSchema.Create(GetType(NGridSurfaceProjectedContourExample), NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            Dim chartViewWithCommandBars As NChartViewWithCommandBars = New NChartViewWithCommandBars()
            Dim chartView = chartViewWithCommandBars.View
            chartView.Surface.CreatePredefinedChart(ENPredefinedChartType.Cartesian)

            ' configure title
            chartView.Surface.Titles(0).Text = "Grid Surface Projected Contour Chart"

            ' setup chart
            Dim chart = CType(chartView.Surface.Charts(0), NCartesianChart)
            chart.Enable3D = True
            chart.ModelWidth = 55.0F
            chart.ModelDepth = 55.0F
            chart.ModelHeight = 45.0F
            chart.Projection.SetPredefinedProjection(ENPredefinedProjection.PerspectiveTilted)
            chart.LightModel.SetPredefinedLightModel(ENPredefinedLightModel.ShinyCameraLight)
            chart.Interactor = New NInteractor(New NTrackballTool())

            ' setup Y axis
            Dim scaleY As NLinearScale = New NLinearScale()
            scaleY.ViewRangeInflateMode = ENScaleViewRangeInflateMode.None
            Dim axisY = chart.Axes(ENCartesianAxis.PrimaryY)
            axisY.MinViewRangeValue = 100
            axisY.MaxViewRangeValue = 100
            axisY.Scale = scaleY

            ' setup X axis
            Dim scaleX As NLinearScale = New NLinearScale()
            scaleX.ViewRangeInflateMode = ENScaleViewRangeInflateMode.None
            Dim axisX = chart.Axes(ENCartesianAxis.PrimaryX)
            axisX.Scale = scaleX

            ' setup Z axis
            Dim scaleZ As NLinearScale = New NLinearScale()
            scaleZ.MajorGridLines.ShowAtWalls = ENChartWall.NoneMask
            scaleZ.ViewRangeInflateMode = ENScaleViewRangeInflateMode.None
            Dim axisZ = chart.Axes(ENCartesianAxis.Depth)
            axisZ.Scale = scaleZ

            ' add a surface series
            Dim surface As NGridSurfaceSeries = New NGridSurfaceSeries()
            chart.Series.Add(surface)
            surface.Name = "Surface"
            surface.LegendView.Mode = ENSeriesLegendMode.None
            surface.Fill = New NColorFill(NColor.FromRGB(160, 170, 212))
            surface.FillMode = ENSurfaceFillMode.Uniform
            surface.FrameMode = ENSurfaceFrameMode.None
            surface.DrawFlat = False
            surface.ShadingMode = ENShadingMode.Smooth
            SetupCommonSurfaceProperties(surface)

            ' fill both surfaces with the same data
            FillData(surface)

            ' add a surface series
            Dim contour As NGridSurfaceSeries = New NGridSurfaceSeries()
            chart.Series.Add(contour)
            contour.Name = "Contour"
            contour.LegendView.Mode = ENSeriesLegendMode.SeriesLogic
            contour.FillMode = ENSurfaceFillMode.Zone
            contour.FrameMode = ENSurfaceFrameMode.Contour
            contour.DrawFlat = True
            contour.FlatPositionMode = ENSurfaceFlatPositionMode.CustomValue
            contour.FlatPositionValue = 0
            contour.ShadingMode = ENShadingMode.Flat
            SetupCommonSurfaceProperties(contour)

            ' fill both surfaces with the same data
            FillData(contour)

            Dim palette As NColorValuePalette = New NColorValuePalette()
            palette.ColorValuePairs = New NDomArray(Of NColorValuePair)(New NColorValuePair() {New NColorValuePair(250, NColor.FromRGB(112, 211, 162)), New NColorValuePair(311, NColor.FromRGB(113, 197, 212)), New NColorValuePair(328, NColor.FromRGB(114, 162, 212)), New NColorValuePair(344, NColor.FromRGB(196, 185, 206)), New NColorValuePair(358, NColor.FromRGB(161, 130, 191)), New NColorValuePair(370, NColor.FromRGB(198, 170, 165)), New NColorValuePair(400, NColor.FromRGB(255, 0, 0))})

            ' contour.Palette.Add(0, Color.Red);
            ' contour.Palette.Add(100, Color.Blue);

            contour.Palette = palette

            FillData(surface)

            Return chartViewWithCommandBars
        End Function

        Private Sub SetupCommonSurfaceProperties(ByVal surface As NGridSurfaceSeries)
            surface.Palette = New NRangeMultiColorPalette()
            surface.XValuesMode = ENGridSurfaceValuesMode.OriginAndStep
            surface.OriginX = -150
            surface.StepX = 10
            surface.ZValuesMode = ENGridSurfaceValuesMode.OriginAndStep
            surface.OriginZ = -150
            surface.StepZ = 10
        End Sub

        Private Sub FillData(ByVal surface As NGridSurfaceSeries)
            Dim stream As Stream = Nothing
            Dim reader As BinaryReader = Nothing

            Try
                ' fill the XYZ data from a binary resource
                stream = New MemoryStream(NResources.RBIN_SampleData_DataY_bin.Data)
                reader = New BinaryReader(stream)

                Dim dataPointsCount As Integer = stream.Length / 4
                Dim sizeX As Integer = Math.Sqrt(dataPointsCount)
                Dim sizeZ = sizeX

                surface.Data.SetGridSize(sizeX, sizeZ)

                For z = 0 To sizeZ - 1
                    For x = 0 To sizeX - 1
                        Dim value As Double = 300 + 0.3 * CDbl(reader.ReadSingle())
                        surface.Data.SetValue(x, z, value)
                    Next
                Next

            Finally
                If reader IsNot Nothing Then reader.Close()

                If stream IsNot Nothing Then stream.Close()
            End Try
        End Sub

        Protected Overrides Function CreateExampleControls() As NWidget
            Dim stack As NStackPanel = New NStackPanel()
            Dim group As NUniSizeBoxGroup = New NUniSizeBoxGroup(stack)

            Return group
        End Function

        Protected Overrides Function GetExampleDescription() As String
            Return "<p>This example demonstrates a 2D contour chart projection displayed with the a Grid Surface Series with flat rendering.</p>"
        End Function

#End Region

#Region "Fields"


#End Region

#Region "Schema"

        Public Shared ReadOnly NGridSurfaceProjectedContourExampleSchema As NSchema

#End Region
    End Class
End Namespace

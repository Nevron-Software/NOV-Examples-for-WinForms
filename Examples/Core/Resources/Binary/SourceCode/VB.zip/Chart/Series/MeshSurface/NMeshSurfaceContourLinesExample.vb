Imports System

Imports Nevron.Nov.Chart
Imports Nevron.Nov.Chart.Tools
Imports Nevron.Nov.Dom
Imports Nevron.Nov.Graphics
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.Chart
    ''' <summary>
    ''' Mesh Surface Contour lines example
    ''' </summary>
    Public Class NMeshSurfaceContourLinesExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' Default constructor
        ''' </summary>
        Public Sub New()

        End Sub
        ''' <summary>
        ''' Static constructor
        ''' </summary>
        Shared Sub New()
            NMeshSurfaceContourLinesExampleSchema = NSchema.Create(GetType(NMeshSurfaceContourLinesExample), NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            Dim chartViewWithCommandBars As NChartViewWithCommandBars = New NChartViewWithCommandBars()
            Dim chartView = chartViewWithCommandBars.View
            chartView.Surface.CreatePredefinedChart(ENPredefinedChartType.Cartesian)

            ' configure title
            chartView.Surface.Titles(0).Text = "Mesh Surface Contour Lines"

            ' setup chart
            Dim chart = CType(chartView.Surface.Charts(0), NCartesianChart)

            chart.Enable3D = True
            chart.ModelWidth = 60.0F
            chart.ModelDepth = 60.0F
            chart.ModelHeight = 25.0F
            chart.Projection.SetPredefinedProjection(ENPredefinedProjection.PerspectiveTilted)
            chart.LightModel.SetPredefinedLightModel(ENPredefinedLightModel.SoftTopLeft)
            chart.Interactor = New NInteractor(New NTrackballTool())

            Dim scale As NLinearScale = chart.Axes(ENCartesianAxis.PrimaryY).Scale
            scale.ViewRangeInflateMode = ENScaleViewRangeInflateMode.None

            ' setup axes
            Dim scaleX As NLinearScale = New NLinearScale()
            chart.Axes(ENCartesianAxis.PrimaryX).Scale = scaleX
            scaleX.MajorGridLines.SetShowAtWall(ENChartWall.Bottom, True)
            scaleX.MajorGridLines.SetShowAtWall(ENChartWall.Back, True)

            Dim scaleZ As NLinearScale = New NLinearScale()
            chart.Axes(ENCartesianAxis.Depth).Scale = scaleZ
            scaleZ.MajorGridLines.SetShowAtWall(ENChartWall.Bottom, True)
            scaleZ.MajorGridLines.SetShowAtWall(ENChartWall.Left, True)

            ' add the surface series
            m_Surface = New NMeshSurfaceSeries()
            chart.Series.Add(m_Surface)

            m_Surface.Name = "Surface"
            m_Surface.LegendView.Mode = ENSeriesLegendMode.SeriesLogic
            m_Surface.FillMode = ENSurfaceFillMode.Zone
            m_Surface.FrameMode = ENSurfaceFrameMode.None
            m_Surface.FlatPositionValue = 0.5
            m_Surface.Data.SetGridSize(20, 20)
            m_Surface.Fill = New NColorFill(NColor.YellowGreen)

            m_RedIsoline = New NContourLine()
            m_RedIsoline.Value = 100
            m_RedIsoline.Stroke = New NStroke(2.0F, NColor.Red)
            m_Surface.ContourLines.Add(m_RedIsoline)

            m_BlueIsoline = New NContourLine()
            m_BlueIsoline.Value = 50
            m_BlueIsoline.Stroke = New NStroke(2.0F, NColor.Blue)
            m_Surface.ContourLines.Add(m_BlueIsoline)

            FillData(m_Surface)

            Return chartViewWithCommandBars
        End Function
        Private Sub FillData(ByVal surface As NMeshSurfaceSeries)
            Dim nCountX = surface.Data.GridSizeX
            Dim nCountZ = surface.Data.GridSizeZ

            Const dIntervalX = 20.0
            Const dIntervalZ = 20.0
            Dim dIncrementX = dIntervalX / nCountX
            Dim dIncrementZ = dIntervalZ / nCountZ

            Dim pz = -(dIntervalZ / 2)

            Dim j = 0

            While j < nCountZ
                Dim px = -(dIntervalX / 2)

                Dim i = 0

                While i < nCountX
                    Dim x = px + Math.Sin(pz) * 0.4
                    Dim z = pz + Math.Cos(px) * 0.4
                    Dim y = Math.Sin(px * 0.33) * Math.Sin(pz * 0.33) * 200

                    If y < 0 Then
                        y = -y * 0.7
                    End If

                    Dim tmp = 1 - x * x - z * z
                    y -= tmp * tmp * 0.000001

                    surface.Data.SetValue(i, j, y, x, z)
                    i += 1
                    px += dIncrementX
                End While

                j += 1
                pz += dIncrementZ
            End While
        End Sub

        Protected Overrides Function CreateExampleControls() As NWidget
            Dim stack As NStackPanel = New NStackPanel()
            Dim group As NUniSizeBoxGroup = New NUniSizeBoxGroup(stack)

            Dim redIsolineValueUpDown As NNumericUpDown = New NNumericUpDown()
            redIsolineValueUpDown.Value = m_RedIsoline.Value
            redIsolineValueUpDown.ValueChanged += AddressOf OnRedIsolineValueUpDownValueChanged
            redIsolineValueUpDown.HorizontalPlacement = Layout.ENHorizontalPlacement.Left
            stack.Add(NPairBox.Create("Red Isoline Value:", redIsolineValueUpDown))

            Dim blueIsolineValueUpDown As NNumericUpDown = New NNumericUpDown()
            blueIsolineValueUpDown.Value = m_BlueIsoline.Value
            blueIsolineValueUpDown.ValueChanged += AddressOf OnBlueIsolineValueUpDownValueChanged
            blueIsolineValueUpDown.HorizontalPlacement = Layout.ENHorizontalPlacement.Left
            stack.Add(NPairBox.Create("Blue Isoline Value:", blueIsolineValueUpDown))

            Return group
        End Function

        Private Sub OnRedIsolineValueUpDownValueChanged(ByVal arg As NValueChangeEventArgs)
            m_RedIsoline.Value = CDbl(arg.NewValue)
        End Sub

        Private Sub OnBlueIsolineValueUpDownValueChanged(ByVal arg As NValueChangeEventArgs)
            m_BlueIsoline.Value = CDbl(arg.NewValue)
        End Sub

        Protected Overrides Function GetExampleDescription() As String
            Return "<p>The example demonstrates how to create contour lines (isolines) on a mesh surface chart.</p>"
        End Function

#End Region

#Region "Fields"

        Private m_Surface As NMeshSurfaceSeries
        Private m_RedIsoline As NContourLine
        Private m_BlueIsoline As NContourLine

#End Region

#Region "Schema"

        Public Shared ReadOnly NMeshSurfaceContourLinesExampleSchema As NSchema

#End Region
    End Class
End Namespace

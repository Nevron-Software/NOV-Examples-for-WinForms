Imports System
Imports Nevron.Nov.Chart
Imports Nevron.Nov.Dom
Imports Nevron.Nov.Graphics
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.Chart
    ''' <summary>
    ''' Step Line Example
    ''' </summary>
    Public Class NStepLineExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' Default constructor
        ''' </summary>
        Public Sub New()
        End Sub
        ''' <summary>
        ''' Static constructor
        ''' </summary>
        Shared Sub New()
            NStepLineExampleSchema = NSchema.Create(GetType(NStepLineExample), NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            Dim chartView As NChartView = CreateCartesianChartView()

            ' configure title
            chartView.Surface.Titles(0).Text = "Step Line"

            ' configure chart
            m_Chart = CType(chartView.Surface.Charts(0), NCartesianChart)
            m_Chart.SetPredefinedCartesianAxes(ENPredefinedCartesianAxis.XOrdinalYLinear)

            ' add interlaced stripe to the Y axis
            Dim strip As NScaleStrip = New NScaleStrip(New NColorFill(ENNamedColor.Beige), Nothing, True, 0, 0, 1, 1)
            strip.Interlaced = True
            m_Chart.Axes(ENCartesianAxis.PrimaryY).Scale.Strips.Add(strip)
            m_Line = New NLineSeries()
            m_Line.Name = "Line Series"
            m_Line.InflateMargins = True
            m_Line.DataLabelStyle = New NDataLabelStyle("<value>")
            m_Line.MarkerStyle = New NMarkerStyle(New NSize(4, 4))
            Dim random As Random = New Random()

            For i = 0 To 8 - 1
                m_Line.DataPoints.Add(New NLineDataPoint(random.Next(80) + 20))
            Next

            m_Chart.Series.Add(m_Line)
            chartView.Document.StyleSheets.ApplyTheme(New NChartTheme(ENChartPalette.Bright, False))
            Return chartView
        End Function

        Protected Overrides Function CreateExampleControls() As NWidget
            Dim stack As NStackPanel = New NStackPanel()
            Dim group As NUniSizeBoxGroup = New NUniSizeBoxGroup(stack)
            Dim lineSegmentModeComboBox As NComboBox = New NComboBox()
            lineSegmentModeComboBox.Items.Add(New NComboBoxItem("HV Step Line"))
            lineSegmentModeComboBox.Items.Add(New NComboBoxItem("VH Step Line"))
            lineSegmentModeComboBox.Items.Add(New NComboBoxItem("HV Ascending VH Descending Step Line"))
            lineSegmentModeComboBox.Items.Add(New NComboBoxItem("VH Ascending HV Descending Step Line"))
            AddHandler lineSegmentModeComboBox.SelectedIndexChanged, AddressOf OnLineSegmentModeComboBoxSelectedIndexChanged
            lineSegmentModeComboBox.SelectedIndex = 0
            stack.Add(NPairBox.Create("Mode:", lineSegmentModeComboBox))
            Return group
        End Function

        Protected Overrides Function GetExampleDescription() As String
            Return "<p>This example demonstrates how to create step line charts.</p>"
        End Function

#End Region

#Region "Implementation"

        Private Sub OnLineSegmentModeComboBoxSelectedIndexChanged(ByVal arg As NValueChangeEventArgs)
            Select Case CType(arg.TargetNode, NComboBox).SelectedIndex
                Case 0
                    m_Line.LineSegmentMode = ENLineSegmentMode.HVStep
                Case 1
                    m_Line.LineSegmentMode = ENLineSegmentMode.VHStep
                Case 2
                    m_Line.LineSegmentMode = ENLineSegmentMode.HVAscentVHDescentStep
                Case 3
                    m_Line.LineSegmentMode = ENLineSegmentMode.VHAscentHVDescentStep
            End Select
        End Sub

#End Region

#Region "Event Handlers"


#End Region

#Region "Fields"

        Private m_Chart As NCartesianChart
        Private m_Line As NLineSeries

#End Region

#Region "Schema"

        Public Shared ReadOnly NStepLineExampleSchema As NSchema

#End Region

#Region "Static Methods"

        Private Shared Function CreateCartesianChartView() As NChartView
            Dim chartView As NChartView = New NChartView()
            chartView.Surface.CreatePredefinedChart(ENPredefinedChartType.Cartesian)
            Return chartView
        End Function

#End Region
    End Class
End Namespace

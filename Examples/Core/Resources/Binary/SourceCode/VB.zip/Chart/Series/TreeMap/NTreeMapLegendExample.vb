Imports System.Globalization
Imports System.IO

Imports Nevron.Nov.Chart
Imports Nevron.Nov.Dom
Imports Nevron.Nov.Graphics
Imports Nevron.Nov.UI
Imports Nevron.Nov.Xml

Namespace Nevron.Nov.Examples.Chart
    ''' <summary>
    ''' TreeMap Legend Example
    ''' </summary>
    Public Class NTreeMapLegendExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' Default constructor
        ''' </summary>
        Public Sub New()
        End Sub
        ''' <summary>
        ''' Static constructor
        ''' </summary>
        Shared Sub New()
            NTreeMapLegendExampleSchema = NSchema.Create(GetType(NTreeMapLegendExample), NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            Dim chartViewWithCommandBars As NChartViewWithCommandBars = New NChartViewWithCommandBars()
            Dim chartView = chartViewWithCommandBars.View
            chartView.Surface.CreatePredefinedChart(ENPredefinedChartType.TreeMap)

            ' configure title
            chartView.Surface.Titles(0).Text = "TreeMap Legend"

            Dim treeMap = CType(chartView.Surface.Charts(0), NTreeMapChart)

            ' Get the country list XML stream
            Dim stream As Stream = NResources.Instance.GetResourceStream("RSTR_TreeMapDataSmall_xml")

            ' Load an xml document from the stream
            Dim xmlDocument = NXmlDocument.LoadFromStream(stream)

            m_RootTreeMapNode = New NGroupTreeMapNode()

            Dim palette As NThreeColorPalette = New NThreeColorPalette()
            palette.OriginColor = NColor.White
            palette.BeginColor = NColor.Red
            palette.EndColor = NColor.Green
            m_RootTreeMapNode.Label = "Tree Map - Industry by Sector"
            m_RootTreeMapNode.Palette = palette

            m_RootTreeMapNode.LegendView = New NGroupTreeMapNodeLegendView()

            treeMap.RootTreeMapNode = m_RootTreeMapNode

            Dim rootElement = CType(xmlDocument.GetChildAt(0), NXmlElement)

            For i = 0 To rootElement.ChildrenCount - 1
                Dim industry = CType(rootElement.GetChildAt(i), NXmlElement)
                Dim treeMapSeries As NGroupTreeMapNode = New NGroupTreeMapNode()

                treeMapSeries.BorderThickness = New NMargins(4.0)
                treeMapSeries.Border = NBorder.CreateFilledBorder(NColor.Black)
                treeMapSeries.Padding = New NMargins(2.0)

                m_RootTreeMapNode.ChildNodes.Add(treeMapSeries)

                treeMapSeries.Label = industry.GetAttributeValue("Name")
                treeMapSeries.Tooltip = New NTooltip(treeMapSeries.Label)

                For j = 0 To industry.ChildrenCount - 1
                    Dim company = CType(industry.GetChildAt(j), NXmlElement)

                    Dim value = Double.Parse(company.GetAttributeValue("Size"), CultureInfo.InvariantCulture)
                    Dim change = Double.Parse(company.GetAttributeValue("Change"), CultureInfo.InvariantCulture)
                    Dim label = company.GetAttributeValue("Name")

                    Dim node As NValueTreeMapNode = New NValueTreeMapNode(value, change, label)
                    node.Format = "<label> <change_percent>"
                    node.ChangeValueType = ENChangeValueType.Percentage
                    node.Tooltip = New NTooltip(label)

                    treeMapSeries.ChildNodes.Add(node)
                Next
            Next

            Return chartViewWithCommandBars
        End Function
        Protected Overrides Function CreateExampleControls() As NWidget
            Dim stack As NStackPanel = New NStackPanel()
            Dim group As NUniSizeBoxGroup = New NUniSizeBoxGroup(stack)

            Dim legendModeComboBox As NComboBox = New NComboBox()
            legendModeComboBox.FillFromEnum(Of ENTreeMapNodeLegendMode)()
            legendModeComboBox.SelectedIndexChanged += AddressOf OnLegendModeComboBoxSelectedIndexChanged
            legendModeComboBox.SelectedIndex = CInt(ENTreeMapNodeLegendMode.Group)
            stack.Add(NPairBox.Create("Legend Mode:", legendModeComboBox))

            Return group
        End Function
        Protected Overrides Function GetExampleDescription() As String
            Return "<p>This example demonstrates how to control the treemap legend.</p>"
        End Function

#End Region

#Region "Event Handlers"

        Private Sub OnLegendModeComboBoxSelectedIndexChanged(ByVal arg As NValueChangeEventArgs)
            m_RootTreeMapNode.LegendView.Mode = CType(CType(arg.TargetNode, NComboBox).SelectedIndex, ENTreeMapNodeLegendMode)

            Select Case m_RootTreeMapNode.LegendView.Mode
                Case ENTreeMapNodeLegendMode.None, ENTreeMapNodeLegendMode.Group, ENTreeMapNodeLegendMode.ValueNodes, ENTreeMapNodeLegendMode.GroupAndChildNodes
                    m_RootTreeMapNode.LegendView.Format = "<label> <value>"

                Case ENTreeMapNodeLegendMode.Palette
                    m_RootTreeMapNode.LegendView.Format = "<change_begin>"
            End Select
        End Sub

#End Region

#Region "Fields"

        Private m_RootTreeMapNode As NGroupTreeMapNode

#End Region

#Region "Schema"

        Public Shared ReadOnly NTreeMapLegendExampleSchema As NSchema

#End Region
    End Class
End Namespace

Imports System
Imports Nevron.Nov.Chart
Imports Nevron.Nov.Dom
Imports Nevron.Nov.Graphics
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.Chart
    ''' <summary>
    ''' Standard HeatMap Example
    ''' </summary>
    Public Class NStandardHeatMapExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' Default constructor
        ''' </summary>
        Public Sub New()
        End Sub
        ''' <summary>
        ''' Static constructor
        ''' </summary>
        Shared Sub New()
            NStandardHeatMapExampleSchema = NSchema.Create(GetType(NStandardHeatMapExample), NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            Dim chartView As NChartView = CreateCartesianChartView()

            ' configure title
            chartView.Surface.Titles(0).Text = "Standard Heat Map"

            ' configure chart
            Dim chart = CType(chartView.Surface.Charts(0), NCartesianChart)
            chart.SetPredefinedCartesianAxes(ENPredefinedCartesianAxis.XYLinear)
            m_HeatMap = New NHeatMapSeries()
            chart.Series.Add(m_HeatMap)
            Dim data = m_HeatMap.Data
            m_HeatMap.Palette = New NColorValuePalette(New NColorValuePair() {New NColorValuePair(0.0, NColor.Purple), New NColorValuePair(1.5, NColor.MediumSlateBlue), New NColorValuePair(3.0, NColor.CornflowerBlue), New NColorValuePair(4.5, NColor.LimeGreen), New NColorValuePair(6.0, NColor.LightGreen), New NColorValuePair(7.5, NColor.Yellow), New NColorValuePair(9.0, NColor.Orange), New NColorValuePair(10.5, NColor.Red)})
            Dim gridSizeX = 100
            Dim gridSizeY = 100
            data.Size = New NSizeI(gridSizeX, gridSizeY)
            Dim y, x, z As Double
            Const dIntervalX = 10.0
            Const dIntervalZ = 10.0
            Dim dIncrementX = dIntervalX / gridSizeX
            Dim dIncrementZ = dIntervalZ / gridSizeY
            z = -(dIntervalZ / 2)
            Dim j = 0

            While j < gridSizeY
                x = -(dIntervalX / 2)
                Dim i = 0

                While i < gridSizeX
                    y = 10 - Math.Sqrt(x * x + z * z + 2)
                    y += 3.0 * Math.Sin(x) * Math.Cos(z)
                    data.SetValue(i, j, y)
                    i += 1
                    x += dIncrementX
                End While

                j += 1
                z += dIncrementZ
            End While

            Return chartView
        End Function

        Protected Overrides Function CreateExampleControls() As NWidget
            Dim stack As NStackPanel = New NStackPanel()
            Dim boxGroup As NUniSizeBoxGroup = New NUniSizeBoxGroup(stack)
            Dim smoothPaletteCheckBox As NCheckBox = New NCheckBox("Smooth Palette")
            AddHandler smoothPaletteCheckBox.CheckedChanged, AddressOf OnSmoothPaletteCheckBoxCheckedChanged
            smoothPaletteCheckBox.Checked = True
            stack.Add(smoothPaletteCheckBox)
            Return boxGroup
        End Function

        Protected Overrides Function GetExampleDescription() As String
            Return "<p>This example demonstrates how to create a standard heat map chart.</p>"
        End Function

#End Region

#Region "Event Handlers"

        Private Sub OnSmoothPaletteCheckBoxCheckedChanged(ByVal arg As NValueChangeEventArgs)
            m_HeatMap.Palette.SmoothColors = CType(arg.TargetNode, NCheckBox).Checked
        End Sub

#End Region

#Region "Fields"

        Private m_HeatMap As NHeatMapSeries

#End Region

#Region "Schema"

        Public Shared ReadOnly NStandardHeatMapExampleSchema As NSchema

#End Region

#Region "Static Methods"

        Private Shared Function CreateCartesianChartView() As NChartView
            Dim chartView As NChartView = New NChartView()
            chartView.Surface.CreatePredefinedChart(ENPredefinedChartType.Cartesian)
            Return chartView
        End Function

#End Region
    End Class
End Namespace

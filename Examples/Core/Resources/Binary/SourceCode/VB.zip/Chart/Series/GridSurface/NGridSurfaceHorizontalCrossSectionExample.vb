Imports Nevron.Nov.Chart
Imports Nevron.Nov.Chart.Tools
Imports Nevron.Nov.Dom
Imports Nevron.Nov.Graphics
Imports Nevron.Nov.UI
Imports System

Namespace Nevron.Nov.Examples.Chart
    ''' <summary>
    ''' Grid Surface Horizontal Cross Section Example
    ''' </summary>
    Public Class NGridSurfaceHorizontalCrossSectionExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' Default constructor
        ''' </summary>
        Public Sub New()

        End Sub
        ''' <summary>
        ''' Static constructor
        ''' </summary>
        Shared Sub New()
            NGridSurfaceHorizontalCrossSectionExampleSchema = NSchema.Create(GetType(NGridSurfaceHorizontalCrossSectionExample), NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        ''' <summary>
        ''' 
        ''' </summary>
        ''' <returns></returns>
        Protected Overrides Function CreateExampleContent() As NWidget
            Dim chartViewWithCommandBars As NChartViewWithCommandBars = New NChartViewWithCommandBars()
            Dim chartView = chartViewWithCommandBars.View
            chartView.Surface.CreatePredefinedChart(ENPredefinedChartType.Cartesian)

            ' configure title
            chartView.Surface.Titles(0).Text = "Grid Surface Series Horizontal Cross Section"

            ' Configure surface chart
            Dim chart = CType(chartView.Surface.Charts(0), NCartesianChart)

            chart.Enable3D = True
            chart.ModelWidth = 60.0F
            chart.ModelDepth = 60.0F
            chart.ModelHeight = 15.0F
            chart.FitMode = ENCartesianChartFitMode.Aspect
            chart.Projection.SetPredefinedProjection(ENPredefinedProjection.PerspectiveTilted)
            chart.Projection.Elevation = 22
            chart.Projection.Rotation = -68
            chart.LightModel.SetPredefinedLightModel(ENPredefinedLightModel.ShinyTopLeft)

            ' setup axes
            Dim ordinalScale As NOrdinalScale = chart.Axes(ENCartesianAxis.PrimaryX).Scale
            ordinalScale.MajorGridLines.SetShowAtWall(ENChartWall.Bottom, True)
            ordinalScale.MajorGridLines.SetShowAtWall(ENChartWall.Back, True)
            ordinalScale.DisplayDataPointsBetweenTicks = False

            ordinalScale = chart.Axes(ENCartesianAxis.Depth).Scale
            ordinalScale.MajorGridLines.SetShowAtWall(ENChartWall.Bottom, True)
            ordinalScale.MajorGridLines.SetShowAtWall(ENChartWall.Left, True)
            ordinalScale.DisplayDataPointsBetweenTicks = False

            chart.Axes(ENCartesianAxis.PrimaryY).SetFixedViewRange(New NRange(0, 15.001))

            ' add the surface series
            m_SurfaceSeries = New NGridSurfaceSeries()
            chart.Series.Add(m_SurfaceSeries)
            m_SurfaceSeries.Name = "Surface"
            m_SurfaceSeries.LegendView.Mode = ENSeriesLegendMode.SeriesLogic
            m_SurfaceSeries.FlatPositionValue = 10.0
            m_SurfaceSeries.Data.SetGridSize(1000, 1000)
            m_SurfaceSeries.Fill = New NColorFill(NColor.YellowGreen)
            m_SurfaceSeries.ShadingMode = ENShadingMode.Smooth
            m_SurfaceSeries.FrameMode = ENSurfaceFrameMode.None
            m_SurfaceSeries.FillMode = ENSurfaceFillMode.Zone
            m_SurfaceSeries.ContourLines.Add(New NContourLine(10, New NStroke(2.0F, NColor.Blue)))

            m_ContourLineSeries = New NLineSeries()
            chart.Series.Add(m_ContourLineSeries)

            m_ContourLineSeries.UseXValues = True
            m_ContourLineSeries.UseZValues = True
            m_ContourLineSeries.Stroke = New NStroke(2, NColor.Red)

            m_ContourLineSeries.DataLabelStyle = New NDataLabelStyle(False)
            m_ContourLineSeries.LegendView.Mode = ENSeriesLegendMode.None

            m_CrossSectionPlane = New NAxisReferenceLine()
            m_CrossSectionPlane.DisplayMode = ENReferenceLineDisplayMode.Plane
            m_CrossSectionPlane.Fill = New NColorFill(NColor.FromARGB(25, 0, 0, 255))
            chart.Axes(ENCartesianAxis.PrimaryY).ReferenceLines.Add(m_CrossSectionPlane)

            FillData(m_SurfaceSeries)

            ' make sure min / max for all axes is calculated
            chartView.Document.Evaluate()

            chart.Interactor = New NInteractor(New NTool() {New NTrackballTool()})

            Return chartViewWithCommandBars
        End Function

        Private Sub FillData(ByVal surface As NGridSurfaceSeries)
            Dim y, x, z As Double
            Dim nCountX = surface.Data.GridSizeX
            Dim nCountZ = surface.Data.GridSizeZ

            Const dIntervalX = 10.0
            Const dIntervalZ = 10.0
            Dim dIncrementX = dIntervalX / nCountX
            Dim dIncrementZ = dIntervalZ / nCountZ

            z = -(dIntervalZ / 2)

            Dim j = 0

            While j < nCountZ
                x = -(dIntervalX / 2)

                Dim i = 0

                While i < nCountX
                    y = 10 - Math.Sqrt(x * x + z * z + 2)
                    y += 3.0 * Math.Sin(x) * Math.Cos(z)

                    surface.Data.SetValue(i, j, y)
                    i += 1
                    x += dIncrementX
                End While

                j += 1
                z += dIncrementZ
            End While
        End Sub

        Protected Overrides Function CreateExampleControls() As NWidget
            Dim stack As NStackPanel = New NStackPanel()
            Dim group As NUniSizeBoxGroup = New NUniSizeBoxGroup(stack)

            Dim horizontalPlaneValueUpDown As NNumericUpDown = New NNumericUpDown()
            stack.Add(NPairBox.Create("Horizontal Plane Value:", horizontalPlaneValueUpDown))
            horizontalPlaneValueUpDown.ValueChanged += AddressOf OnHorizontalPlaneValueValueChanged
            horizontalPlaneValueUpDown.Value = 10
            horizontalPlaneValueUpDown.Minimum = 0
            horizontalPlaneValueUpDown.Maximum = m_ContourYValue

            Return group
        End Function

        Protected Overrides Function GetExampleDescription() As String
            Return "<p>This example demonstrates how to get the cross section of a grid surface at specified Y value. Change the horizontal plane value on the right. The cross section will be displayed both as an isoline and projected contour at the top of the chart. </p>"
        End Function

#End Region

#Region "Events"

        Private Sub OnHorizontalPlaneValueValueChanged(ByVal arg As NValueChangeEventArgs)
            Dim value As Double = arg.NewValue

            If m_SurfaceSeries.ContourLines.Count > 0 Then
                m_SurfaceSeries.ContourLines(0).Value = value
            End If

            m_CrossSectionPlane.Value = value

            Dim path = m_SurfaceSeries.GetContourForValue(value)

            m_ContourLineSeries.DataPoints.Clear()

            For i = 0 To path.Count - 1
                Dim contour = path(i)

                If contour.Count > 0 Then
                    Dim index = m_ContourLineSeries.DataPoints.Count + 1
                    Dim pointCount = contour.Count
                    For j = 0 To pointCount - 1
                        Dim point = contour(j)
                        m_ContourLineSeries.DataPoints.Add(New NLineDataPoint(point.X, m_ContourYValue, point.Y))
                    Next

                    m_ContourLineSeries.DataPoints.Add(New NLineDataPoint(Double.NaN, Double.NaN, Double.NaN))
                End If
            Next
        End Sub

#End Region

#Region "Fields"

        Private m_SurfaceSeries As NGridSurfaceSeries
        Private m_ContourLineSeries As NLineSeries
        Private m_CrossSectionPlane As NAxisReferenceLine
        Const m_ContourYValue As Double = 15

#End Region

#Region "Schema"

        Public Shared ReadOnly NGridSurfaceHorizontalCrossSectionExampleSchema As NSchema

#End Region
    End Class
End Namespace

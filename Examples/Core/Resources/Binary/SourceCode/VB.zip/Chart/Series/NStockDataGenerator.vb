Imports Nevron.Nov.Graphics
Imports System

Namespace Nevron.Nov.Examples.Chart
    ''' <summary>
    ''' Helper class that generates sample data for stock/financial series
    ''' </summary>
    Friend Class NStockDataGenerator
#Region "Constructors"

        ''' <summary>
        ''' Initializer constructor
        ''' </summary>
        ''' <paramname="range"></param>
        ''' <paramname="reversalFactor"></param>
        ''' <paramname="valueScale"></param>
        Friend Sub New(ByVal range As NRange, ByVal reversalFactor As Double, ByVal valueScale As Double)
            m_Rand = New Random()
            m_Range = range
            m_Direction = 1
            m_StepsInCurrentTrend = 0
            m_Value = 0
            m_ReversalPorbability = 0
            m_ReversalFactor = reversalFactor
            m_ValueScale = valueScale
        End Sub

#End Region

#Region "Methods"

        ''' <summary>
        ''' Resets the enumerator
        ''' </summary>
        Friend Sub Reset()
            m_Direction = 1
            m_StepsInCurrentTrend = 0
            m_Value = (m_Range.Begin + m_Range.End) / 2
            m_ReversalPorbability = 0
        End Sub
        ''' <summary>
        ''' Gets the next price value
        ''' </summary>
        ''' <returns></returns>
        Friend Function GetNextValue() As Double
            Dim nNewValueDirection = 0

            If m_Value <= m_Range.Begin Then
                If m_Direction = -1 Then
                    m_ReversalPorbability = 1.0
                Else
                    m_ReversalPorbability = 0.0
                End If

                nNewValueDirection = 1
            ElseIf m_Value >= m_Range.End Then
                If m_Direction = 1 Then
                    m_ReversalPorbability = 1.0
                Else
                    m_ReversalPorbability = 0.0
                End If

                nNewValueDirection = -1
            Else
                If m_Rand.NextDouble() < 0.80 Then
                    nNewValueDirection = m_Direction
                Else
                    nNewValueDirection = -m_Direction
                End If

                m_ReversalPorbability += m_StepsInCurrentTrend * m_ReversalFactor
            End If

            If m_Rand.NextDouble() < m_ReversalPorbability Then
                m_Direction = -m_Direction
                m_ReversalPorbability = 0
                m_StepsInCurrentTrend = 0
            Else
                m_StepsInCurrentTrend += 1
            End If

            m_Value += nNewValueDirection * m_Rand.NextDouble() * m_ValueScale

            Return m_Value
        End Function

#End Region

#Region "Fields"

        Private m_Rand As Random
        Private m_Range As NRange
        Private m_Direction As Integer
        Private m_StepsInCurrentTrend As Integer
        Private m_Value As Double
        Private m_ReversalPorbability As Double
        Private m_ReversalFactor As Double
        Private m_ValueScale As Double

#End Region
    End Class
End Namespace

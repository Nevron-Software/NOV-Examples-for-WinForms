
Imports Nevron.Nov.Chart
Imports Nevron.Nov.Dom
Imports Nevron.Nov.Graphics
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.Chart
    ''' <summary>
    ''' Three Line Break Example
    ''' </summary>
    Public Class NThreeLineBreakExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' Default constructor
        ''' </summary>
        Public Sub New()

        End Sub
        ''' <summary>
        ''' Static constructor
        ''' </summary>
        Shared Sub New()
            NThreeLineBreakExampleSchema = NSchema.Create(GetType(NThreeLineBreakExample), NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            Dim chartViewWithCommandBars As NChartViewWithCommandBars = New NChartViewWithCommandBars()
            Dim chartView = chartViewWithCommandBars.View
            chartView.Surface.CreatePredefinedChart(ENPredefinedChartType.Cartesian)

            ' configure title
            chartView.Surface.Titles(0).Text = "Three Line Break"

            ' configure chart
            Dim chart = CType(chartView.Surface.Charts(0), NCartesianChart)

            chart.SetPredefinedCartesianAxes(ENPredefinedCartesianAxis.XYLinear)

            Dim scaleY As NLinearScale = chart.Axes(ENCartesianAxis.PrimaryY).Scale

            ' add interlace stripe
            Dim stripStyle As NScaleStrip = New NScaleStrip(New NColorFill(NColor.Beige), Nothing, True, 0, 0, 1, 1)
            stripStyle.Interlaced = True
            scaleY.Strips.Add(stripStyle)

            ' setup X axis
            Dim priceScale As NPriceTimeScale = New NPriceTimeScale()
            priceScale.InnerMajorTicks.Stroke = New NStroke(0.0, NColor.Black)
            chart.Axes(ENCartesianAxis.PrimaryX).Scale = priceScale

            ' setup line break series
            m_ThreeLineBreak = New NThreeLineBreakSeries()
            m_ThreeLineBreak.UseXValues = True
            chart.Series.Add(m_ThreeLineBreak)

            GenerateData(m_ThreeLineBreak)

            chartView.Document.StyleSheets.ApplyTheme(New NChartTheme(ENChartPalette.Bright, ENChartPaletteTarget.Series))

            Return chartViewWithCommandBars
        End Function
        Protected Overrides Function CreateExampleControls() As NWidget
            Dim stack As NStackPanel = New NStackPanel()
            Dim group As NUniSizeBoxGroup = New NUniSizeBoxGroup(stack)

            Dim boxWidthPercentUpDown As NNumericUpDown = New NNumericUpDown()
            boxWidthPercentUpDown.Minimum = 0
            boxWidthPercentUpDown.Maximum = 100
            boxWidthPercentUpDown.Value = m_ThreeLineBreak.BoxWidthPercent
            boxWidthPercentUpDown.ValueChanged += AddressOf OnBoxWidthPercentUpDownValueChanged
            stack.Add(NPairBox.Create("Box Width Percent:", boxWidthPercentUpDown))

            Dim numberOfLinesToBreakUpDown As NNumericUpDown = New NNumericUpDown()
            numberOfLinesToBreakUpDown.Minimum = 1
            numberOfLinesToBreakUpDown.Maximum = 100
            numberOfLinesToBreakUpDown.Value = m_ThreeLineBreak.NumberOfLinesToBreak
            numberOfLinesToBreakUpDown.ValueChanged += AddressOf OnNumberOfLinesToBreakUpDownValueChanged
            numberOfLinesToBreakUpDown.DecimalPlaces = 0
            stack.Add(NPairBox.Create("Number of Lines to Break:", numberOfLinesToBreakUpDown))

            Return group
        End Function
        Protected Overrides Function GetExampleDescription() As String
            Return "<p>This example demonstrates the functionality of the three line break series.</p>"
        End Function

#End Region

#Region "Implementation"

        Private Sub GenerateData(ByVal threeLineBreak As NThreeLineBreakSeries)
            Dim dataGenerator As NStockDataGenerator = New NStockDataGenerator(New NRange(50, 350), 0.002, 2)
            dataGenerator.Reset()

            Dim dt = Date.Now

            For i = 0 To 99
                threeLineBreak.DataPoints.Add(New NThreeLineBreakDataPoint(NDateTimeHelpers.ToOADate(dt), dataGenerator.GetNextValue()))

                dt = dt.AddDays(1)
            Next
        End Sub

#End Region

#Region "Event Handlers"

        Private Sub OnBoxWidthPercentUpDownValueChanged(ByVal arg As NValueChangeEventArgs)
            m_ThreeLineBreak.BoxWidthPercent = CType(arg.TargetNode, NNumericUpDown).Value
        End Sub

        Private Sub OnNumberOfLinesToBreakUpDownValueChanged(ByVal arg As NValueChangeEventArgs)
            m_ThreeLineBreak.NumberOfLinesToBreak = CInt(CType(arg.TargetNode, NNumericUpDown).Value)
        End Sub

#End Region

#Region "Fields"

        Private m_ThreeLineBreak As NThreeLineBreakSeries

#End Region

#Region "Schema"

        Public Shared ReadOnly NThreeLineBreakExampleSchema As NSchema

#End Region
    End Class
End Namespace

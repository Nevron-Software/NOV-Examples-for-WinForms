Imports System

Imports Nevron.Nov.Chart
Imports Nevron.Nov.Chart.Tools
Imports Nevron.Nov.Dom
Imports Nevron.Nov.Graphics
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.Chart
    ''' <summary>
    ''' Vertex Surface Example
    ''' </summary>
    Public Class NVertexSurfaceFillCustomColorsExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' Default constructor
        ''' </summary>
        Public Sub New()

        End Sub
        ''' <summary>
        ''' Static constructor
        ''' </summary>
        Shared Sub New()
            NVertexSurfaceFillCustomColorsExampleSchema = NSchema.Create(GetType(NVertexSurfaceFillCustomColorsExample), NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            Dim chartViewWithCommandBars As NChartViewWithCommandBars = New NChartViewWithCommandBars()
            Dim chartView = chartViewWithCommandBars.View
            chartView.Surface.CreatePredefinedChart(ENPredefinedChartType.Cartesian)

            ' configure title
            chartView.Surface.Titles(0).Text = "Vertex Surface Series Fill With Custom Colors"

            ' setup chart
            Dim chart = CType(chartView.Surface.Charts(0), NCartesianChart)
            chart.Enable3D = True
            chart.ModelWidth = 60.0F
            chart.ModelDepth = 60.0F
            chart.ModelHeight = 50.0F
            chart.Projection.SetPredefinedProjection(ENPredefinedProjection.PerspectiveTilted)
            chart.LightModel.SetPredefinedLightModel(ENPredefinedLightModel.SoftTopLeft)
            chart.Interactor = New NInteractor(New NTrackballTool())

            ' setup axes
            Dim scaleY As NLinearScale = chart.Axes(ENCartesianAxis.PrimaryY).Scale
            scaleY.ViewRangeInflateMode = ENScaleViewRangeInflateMode.None

            Dim scaleX As NLinearScale = New NLinearScale()
            scaleX.MajorGridLines.SetShowAtWall(ENChartWall.Bottom, True)
            scaleX.MajorGridLines.SetShowAtWall(ENChartWall.Back, True)
            scaleX.ViewRangeInflateMode = ENScaleViewRangeInflateMode.None
            chart.Axes(ENCartesianAxis.PrimaryX).Scale = scaleX

            Dim scaleZ As NLinearScale = New NLinearScale()
            scaleZ.MajorGridLines.SetShowAtWall(ENChartWall.Bottom, True)
            scaleZ.MajorGridLines.SetShowAtWall(ENChartWall.Left, True)
            scaleZ.ViewRangeInflateMode = ENScaleViewRangeInflateMode.None
            chart.Axes(ENCartesianAxis.Depth).Scale = scaleZ

            ' add the surface series
            m_Surface = New NVertexSurfaceSeries()
            chart.Series.Add(m_Surface)

            m_Surface.Name = "Surface"
            m_Surface.LegendView.Mode = ENSeriesLegendMode.SeriesLogic
            m_Surface.FlatPositionValue = 10.0
            m_Surface.Palette.InterpolateColors = False
            m_Surface.ValueFormatter = New NNumericValueFormatter("0.00")
            m_Surface.FillMode = ENSurfaceFillMode.CustomColors
            m_Surface.FrameMode = ENSurfaceFrameMode.None
            m_Surface.VertexPrimitive = ENVertexPrimitive.Triangles
            m_Surface.Data.HasColor = True
            m_Surface.UseIndices = True

            Return chartViewWithCommandBars
        End Function
        Protected Overrides Function CreateExampleControls() As NWidget
            Dim stack As NStackPanel = New NStackPanel()
            Dim group As NUniSizeBoxGroup = New NUniSizeBoxGroup(stack)

            Dim cubeSizeComboBox As NComboBox = New NComboBox()
            For i = 1 To 9
                cubeSizeComboBox.Items.Add(New NComboBoxItem(i.ToString() & "x" & i.ToString()))
            Next

            cubeSizeComboBox.SelectedIndexChanged += AddressOf OnCubeSizeComboBoxSelectedIndexChanged
            cubeSizeComboBox.SelectedIndex = 4
            stack.Add(NPairBox.Create("Vertex Primitive:", cubeSizeComboBox))

            Return group
        End Function

        Private Sub OnCubeSizeComboBoxSelectedIndexChanged(ByVal arg As NValueChangeEventArgs)
            Dim cubeSide = CInt(arg.NewValue) + 1
            Dim dataPointCount = 8 * CInt(Math.Pow(cubeSide, 3))

            m_Surface.Data.Clear()
            m_Surface.Indices.Clear()
            m_Surface.Data.SetCapacity(dataPointCount)

            Dim currentIndex As UInteger = 0


            ' left

            ' right

            ' front

            ' back

            ' top
            Dim cubeIndices = New UInteger() {0, 1, 3, 0, 3, 2, 2, 0, 4, 2, 4, 6, 1, 3, 5, 3, 7, 5, 0, 1, 4, 1, 5, 4, 2, 6, 3, 3, 6, 7, 4, 5, 6, 5, 7, 6}   ' bottom

            ' generate all vertexes and colors
            For x = 0 To cubeSide - 1
                Dim x1 = x + 0.1
                Dim x2 = x + 1 - 0.1

                Dim r1 As Byte = x1 * 255.0 / cubeSide
                Dim r2 As Byte = x1 * 255.0 / cubeSide

                For y = 0 To cubeSide - 1
                    Dim y1 = y + 0.1
                    Dim y2 = y + 1 - 0.1

                    Dim g1 As Byte = y1 * 255.0 / cubeSide
                    Dim g2 As Byte = y1 * 255.0 / cubeSide

                    For z = 0 To cubeSide - 1
                        Dim z1 = z + 0.1
                        Dim z2 = z + 1 - 0.1

                        Dim b1 As Byte = z1 * 255.0 / cubeSide
                        Dim b2 As Byte = z1 * 255.0 / cubeSide

                        m_Surface.Data.AddValueColor(New NVector3DD(x1, y1, z1), NColor.FromRGB(r1, g1, b1))
                        m_Surface.Data.AddValueColor(New NVector3DD(x2, y1, z1), NColor.FromRGB(r2, g1, b1))
                        m_Surface.Data.AddValueColor(New NVector3DD(x1, y2, z1), NColor.FromRGB(r1, g2, b1))
                        m_Surface.Data.AddValueColor(New NVector3DD(x2, y2, z1), NColor.FromRGB(r2, g2, b1))
                        m_Surface.Data.AddValueColor(New NVector3DD(x1, y1, z2), NColor.FromRGB(r1, g1, b2))
                        m_Surface.Data.AddValueColor(New NVector3DD(x2, y1, z2), NColor.FromRGB(r2, g1, b2))
                        m_Surface.Data.AddValueColor(New NVector3DD(x1, y2, z2), NColor.FromRGB(r1, g2, b2))
                        m_Surface.Data.AddValueColor(New NVector3DD(x2, y2, z2), NColor.FromRGB(r2, g2, b2))

                        ' add indicess
                        For i = 0 To cubeIndices.Length - 1
                            m_Surface.Indices.Add(currentIndex + cubeIndices(i))
                        Next

                        currentIndex += 8
                    Next
                Next
            Next
        End Sub
        ''' <summary>
        ''' 
        ''' </summary>
        ''' <returns></returns>
        Protected Overrides Function GetExampleDescription() As String
            Return "<p>The example demonstrates how to use the Vertex surface series to plot objects with a large amount of vertices, and with a custom color per vertex.</p>"
        End Function

#End Region

#Region "Fields"

        Private m_Surface As NVertexSurfaceSeries

#End Region

#Region "Schema"

        Public Shared ReadOnly NVertexSurfaceFillCustomColorsExampleSchema As NSchema

#End Region
    End Class
End Namespace

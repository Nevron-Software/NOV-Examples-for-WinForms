Imports Nevron.Nov.Chart
Imports Nevron.Nov.Dom
Imports Nevron.Nov.Graphics
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.Chart
    ''' <summary>
    ''' Kagi Example
    ''' </summary>
    Public Class NKagiExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' Default constructor
        ''' </summary>s
        Public Sub New()
        End Sub
        ''' <summary>
        ''' Static constructor
        ''' </summary>
        Shared Sub New()
            NKagiExampleSchema = NSchema.Create(GetType(NKagiExample), NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            Dim chartView As NChartView = CreateCartesianChartView()

            ' configure title
            chartView.Surface.Titles(0).Text = "Kagi"

            ' configure chart
            Dim chart = CType(chartView.Surface.Charts(0), NCartesianChart)
            chart.SetPredefinedCartesianAxes(ENPredefinedCartesianAxis.XYLinear)
            Dim scaleY = CType(chart.Axes(ENCartesianAxis.PrimaryY).Scale, NLinearScale)

            ' add interlace stripe
            Dim stripStyle As NScaleStrip = New NScaleStrip(New NColorFill(NColor.Beige), Nothing, True, 0, 0, 1, 1)
            stripStyle.Interlaced = True
            scaleY.Strips.Add(stripStyle)

            ' setup X axis
            Dim priceScale As NPriceTimeScale = New NPriceTimeScale()
            priceScale.InnerMajorTicks.Stroke = New NStroke(0.0, NColor.Black)
            chart.Axes(ENCartesianAxis.PrimaryX).Scale = priceScale

            ' setup line break series
            m_KagiSeries = New NKagiSeries()
            m_KagiSeries.UseXValues = True
            chart.Series.Add(m_KagiSeries)
            GenerateData(m_KagiSeries)
            chartView.Document.StyleSheets.ApplyTheme(New NChartTheme(ENChartPalette.Bright, False))
            Return chartView
        End Function

        Protected Overrides Function CreateExampleControls() As NWidget
            Dim stack As NStackPanel = New NStackPanel()
            Dim group As NUniSizeBoxGroup = New NUniSizeBoxGroup(stack)
            Dim reversalAmountUpDown As NNumericUpDown = New NNumericUpDown()
            reversalAmountUpDown.Minimum = 1
            reversalAmountUpDown.Maximum = 100
            reversalAmountUpDown.Value = m_KagiSeries.ReversalAmount
            AddHandler reversalAmountUpDown.ValueChanged, AddressOf OnReversalAmountUpDownValueChanged
            stack.Add(NPairBox.Create("Reversal Amount:", reversalAmountUpDown))
            Return group
        End Function

        Protected Overrides Function GetExampleDescription() As String
            Return "<p>This example demonstrates the functionality of the kagi series.</p>"
        End Function

#End Region

#Region "Implementation"

        Private Sub GenerateData(ByVal KagiSeries As NKagiSeries)
            Dim dataGenerator As NStockDataGenerator = New NStockDataGenerator(New NRange(50, 350), 0.002, 2)
            dataGenerator.Reset()
            Dim dt = Date.Now

            For i = 0 To 100 - 1
                KagiSeries.DataPoints.Add(New NKagiDataPoint(NDateTimeHelpers.ToOADate(dt), dataGenerator.GetNextValue()))
                dt = dt.AddDays(1)
            Next
        End Sub

#End Region

#Region "Event Handlers"

        Private Sub OnReversalAmountUpDownValueChanged(ByVal arg As NValueChangeEventArgs)
            m_KagiSeries.ReversalAmount = CType(arg.TargetNode, NNumericUpDown).Value
        End Sub

#End Region

#Region "Fields"

        Private m_KagiSeries As NKagiSeries

#End Region

#Region "Schema"

        Public Shared ReadOnly NKagiExampleSchema As NSchema

#End Region

#Region "Static Methods"

        Private Shared Function CreateCartesianChartView() As NChartView
            Dim chartView As NChartView = New NChartView()
            chartView.Surface.CreatePredefinedChart(ENPredefinedChartType.Cartesian)
            Return chartView
        End Function

#End Region
    End Class
End Namespace

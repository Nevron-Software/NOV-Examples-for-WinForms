Imports System

Imports Nevron.Nov.Chart
Imports Nevron.Nov.Chart.Tools
Imports Nevron.Nov.Dom
Imports Nevron.Nov.Graphics
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.Chart
    ''' <summary>
    ''' XY Scatter Line Example
    ''' </summary>
    Public Class NXYZScatterLineExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' Default constructor
        ''' </summary>
        Public Sub New()

        End Sub
        ''' <summary>
        ''' Static constructor
        ''' </summary>
        Shared Sub New()
            NXYZScatterLineExampleSchema = NSchema.Create(GetType(NXYZScatterLineExample), NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            Dim chartViewWithCommandBars As NChartViewWithCommandBars = New NChartViewWithCommandBars()
            Dim chartView = chartViewWithCommandBars.View
            chartView.Surface.CreatePredefinedChart(ENPredefinedChartType.Cartesian)

            ' configure title
            chartView.Surface.Titles(0).Text = "XYZ Scatter Line"

            ' configure chart
            Dim chart = CType(chartView.Surface.Charts(0), NCartesianChart)

            chart.Enable3D = True
            chart.ModelWidth = 50
            chart.ModelHeight = 50
            chart.ModelDepth = 50
            chart.SetPredefinedCartesianAxes(ENPredefinedCartesianAxis.XYZLinear)
            chart.FitMode = ENCartesianChartFitMode.Aspect
            chart.Projection.SetPredefinedProjection(ENPredefinedProjection.PerspectiveTilted)
            chart.LightModel.SetPredefinedLightModel(ENPredefinedLightModel.GlitterLeft)
            chart.Interactor = New NInteractor(New NTrackballTool())

            ' add interlaced stripe to the Y axis
            Dim stripStyle As NScaleStrip = New NScaleStrip(New NColorFill(ENNamedColor.Beige), Nothing, True, 0, 0, 1, 1)
            stripStyle.Interlaced = True
            chart.Axes(ENCartesianAxis.PrimaryY).Scale.Strips.Add(stripStyle)

            m_Line = New NLineSeries()
            m_Line.UseXValues = True
            m_Line.UseZValues = True

            chart.Series.Add(m_Line)

            m_Line.DataLabelStyle = New NDataLabelStyle(False)
            m_Line.InflateMargins = True

            m_Line.Name = "Line Series"
            m_Line.UseXValues = True

            chartView.Document.StyleSheets.ApplyTheme(New NChartTheme(ENChartPalette.Bright, ENChartPaletteTarget.Series))

            Return chartViewWithCommandBars
        End Function
        ''' <summary>
        ''' Called when windings / complexity changes
        ''' </summary>
        Private Sub ChangeData()
            ' add xy values
            Dim fSpringHeight As Single = 20

            Dim nWindings As Integer = m_WindingsNumericUpDown.Value
            Dim nComplexity As Integer = m_ComplexityNumericUpDown.Value

            Dim dCurrentAngle As Double = 0
            Dim dCurrentHeight As Double = 0
            Dim dX, dY, dZ As Double

            Dim fHeightStep = fSpringHeight / (nWindings * nComplexity)
            Dim fAngleStepRad As Single = 360 / nComplexity * 3.1415926535F / 180.0F

            m_Line.DataPoints.Clear()

            While nWindings > 0
                For i = 0 To nComplexity - 1
                    dZ = Math.Cos(dCurrentAngle) * dCurrentHeight
                    dX = Math.Sin(dCurrentAngle) * dCurrentHeight
                    dY = dCurrentHeight

                    m_Line.DataPoints.Add(New NLineDataPoint(dX, dY, dZ))

                    dCurrentAngle += fAngleStepRad
                    dCurrentHeight += fHeightStep
                Next

                nWindings -= 1
            End While
        End Sub

        Protected Overrides Function CreateExampleControls() As NWidget
            Dim stack As NStackPanel = New NStackPanel()
            Dim group As NUniSizeBoxGroup = New NUniSizeBoxGroup(stack)

            m_WindingsNumericUpDown = New NNumericUpDown()
            Me.m_WindingsNumericUpDown.ValueChanged += AddressOf OnWindingsUpDownValueChanged
            stack.Add(NPairBox.Create("Windings:", m_WindingsNumericUpDown))

            m_ComplexityNumericUpDown = New NNumericUpDown()
            Me.m_ComplexityNumericUpDown.ValueChanged += AddressOf OnComplexityUpDownValueChanged
            stack.Add(NPairBox.Create("Complexity:", m_ComplexityNumericUpDown))

            m_ComplexityNumericUpDown.Value = 20
            m_WindingsNumericUpDown.Value = 5

            Return group
        End Function

        Private Sub OnComplexityUpDownValueChanged(ByVal arg As NValueChangeEventArgs)
            ChangeData()
        End Sub

        Private Sub OnWindingsUpDownValueChanged(ByVal arg As NValueChangeEventArgs)
            ChangeData()
        End Sub

        Protected Overrides Function GetExampleDescription() As String
            Return "<p>This example demonstrates how to create a xy scatter line chart.</p>"
        End Function

#End Region

#Region "Event Handlers"

        Private Sub OnChangeXValuesButtonClick(ByVal arg As NEventArgs)
            Dim random As Random = New Random()
            m_Line.DataPoints(0).X = random.Next(10)

            For i = 1 To m_Line.DataPoints.Count - 1
                m_Line.DataPoints(i).X = m_Line.DataPoints(i - 1).X + random.Next(1, 10)
            Next
        End Sub

#End Region

#Region "Fields"

        Private m_WindingsNumericUpDown As NNumericUpDown
        Private m_ComplexityNumericUpDown As NNumericUpDown

        Private m_Line As NLineSeries

#End Region

#Region "Schema"

        Public Shared ReadOnly NXYZScatterLineExampleSchema As NSchema

#End Region
    End Class
End Namespace

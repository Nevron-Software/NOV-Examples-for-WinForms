Imports System

Imports Nevron.Nov.Chart
Imports Nevron.Nov.Dom
Imports Nevron.Nov.Graphics
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.Chart
    ''' <summary>
    ''' Standard Vector Example
    ''' </summary>
    Public Class NStandardVectorExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' Default constructor
        ''' </summary>
        Public Sub New()

        End Sub
        ''' <summary>
        ''' Static constructor
        ''' </summary>
        Shared Sub New()
            NStandardVectorExampleSchema = NSchema.Create(GetType(NStandardVectorExample), NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            Dim chartViewWithCommandBars As NChartViewWithCommandBars = New NChartViewWithCommandBars()
            Dim chartView = chartViewWithCommandBars.View
            chartView.Surface.CreatePredefinedChart(ENPredefinedChartType.Cartesian)

            ' configure title
            chartView.Surface.Titles(0).Text = "Standard Vector"

            ' configure chart
            m_Chart = CType(chartView.Surface.Charts(0), NCartesianChart)

            m_Chart.SetPredefinedCartesianAxes(ENPredefinedCartesianAxis.XOrdinalYLinear)

            ' setup X axis
            Dim linearScale As NLinearScale = New NLinearScale()
            m_Chart.Axes(ENCartesianAxis.PrimaryX).Scale = linearScale

            ' setup Y axis
            linearScale = New NLinearScale()
            m_Chart.Axes(ENCartesianAxis.PrimaryY).Scale = linearScale

            ' setup shape series
            Dim vectorSeries As NVectorSeries = New NVectorSeries()
            m_Chart.Series.Add(vectorSeries)
            vectorSeries.DataLabelStyle = New NDataLabelStyle(False)
            vectorSeries.InflateMargins = False
            vectorSeries.UseXValues = True
            vectorSeries.MinArrowheadSize = New NSize(2, 3)
            vectorSeries.MaxArrowheadSize = New NSize(4, 6)

            ' fill data
            FillData(vectorSeries)

            Return chartViewWithCommandBars
        End Function
        Protected Overrides Function CreateExampleControls() As NWidget
            Dim stack As NStackPanel = New NStackPanel()
            Dim group As NUniSizeBoxGroup = New NUniSizeBoxGroup(stack)
            Return group
        End Function
        Protected Overrides Function GetExampleDescription() As String
            Return "<p>This example demonstrates how to create a standard 2D vector chart.</p>"
        End Function

#End Region

#Region "Implementation"

        Private Sub FillData(ByVal vectorSeries As NVectorSeries)
            Dim x As Double, y As Double = 0

            For i = 0 To 9
                x = 1
                y += 1

                For j = 0 To 9
                    Dim dx = Math.Sin(x / 3.0) * Math.Cos((x - y) / 4.0)
                    Dim dy = Math.Cos(y / 8.0) * Math.Cos(y / 4.0)

                    Dim color = ColorFromVector(dx, dy)
                    vectorSeries.DataPoints.Add(New NVectorDataPoint(x, y, x + dx, y + dy, New NColorFill(color), New NStroke(1, color)))

                    x += 1
                Next
            Next
        End Sub
        Private Function ColorFromVector(ByVal dx As Double, ByVal dy As Double) As NColor
            Dim length = Math.Sqrt(dx * dx + dy * dy)

            Dim sq2 = Math.Sqrt(2)

            Dim r As Integer = 255 / sq2 * length
            Dim g = 20
            Dim b As Integer = 255 / sq2 * (sq2 - length)

            Return NColor.FromRGB(CByte(r), CByte(g), CByte(b))
        End Function

#End Region

#Region "Event Handlers"


#End Region

#Region "Fields"

        Private m_Chart As NCartesianChart

#End Region

#Region "Schema"

        Public Shared ReadOnly NStandardVectorExampleSchema As NSchema

#End Region
    End Class
End Namespace

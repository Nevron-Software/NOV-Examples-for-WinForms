Imports Nevron.Nov.Chart
Imports Nevron.Nov.Dom
Imports Nevron.Nov.Graphics
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.Chart
    ''' <summary>
    ''' Polar vector example
    ''' </summary>
    Public Class NPolarVectorExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' Default constructor
        ''' </summary>
        Public Sub New()

        End Sub
        ''' <summary>
        ''' Static constructor
        ''' </summary>
        Shared Sub New()
            NPolarVectorExampleSchema = NSchema.Create(GetType(NPolarVectorExample), NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            Dim chartViewWithCommandBars As NChartViewWithCommandBars = New NChartViewWithCommandBars()
            Dim chartView = chartViewWithCommandBars.View
            chartView.Surface.CreatePredefinedChart(ENPredefinedChartType.Polar)

            ' configure title
            chartView.Surface.Titles(0).Text = "Polar Vector"

            ' configure chart
            m_Chart = CType(chartView.Surface.Charts(0), NPolarChart)

            m_Chart.SetPredefinedPolarAxes(ENPredefinedPolarAxes.AngleValue)

            ' setup polar axis
            Dim linearScale As NLinearScale = m_Chart.Axes(ENPolarAxis.PrimaryValue).Scale
            linearScale.ViewRangeInflateMode = ENScaleViewRangeInflateMode.MajorTick
            linearScale.InflateViewRangeBegin = True
            linearScale.InflateViewRangeEnd = True
            linearScale.MajorGridLines.Visible = True

            Dim strip As NScaleStrip = New NScaleStrip()
            strip.Fill = New NColorFill(New NColor(NColor.Beige, 125))
            strip.Interlaced = True
            linearScale.Strips.Add(strip)

            ' setup polar angle axis
            Dim angularScale As NAngularScale = m_Chart.Axes(ENPolarAxis.PrimaryAngle).Scale
            strip = New NScaleStrip()
            strip.Fill = New NColorFill(NColor.FromRGBA(192, 192, 192, 125))
            strip.Interlaced = True
            angularScale.Strips.Add(strip)

            ' create a polar line series
            Dim vectorSeries As NPolarVectorSeries = New NPolarVectorSeries()
            m_Chart.Series.Add(vectorSeries)
            vectorSeries.Name = "Series 1"
            vectorSeries.DataLabelStyle = New NDataLabelStyle(False)

            For i = 0 To 359 Step 30
                For j = 10 To 100 Step 10
                    vectorSeries.DataPoints.Add(New NPolarVectorDataPoint(i, j, i + j / 10, j, Nothing, New NStroke(1, ColorFromValue(j))))
                Next
            Next

            chartView.Document.StyleSheets.ApplyTheme(New NChartTheme(ENChartPalette.Bright, ENChartPaletteTarget.Series))

            Return chartViewWithCommandBars
        End Function
        Protected Overrides Function CreateExampleControls() As NWidget
            Dim stack As NStackPanel = New NStackPanel()
            Dim group As NUniSizeBoxGroup = New NUniSizeBoxGroup(stack)



            Return group
        End Function
        Protected Overrides Function GetExampleDescription() As String
            Return "<p>This example demonstrates how to create a polar line chart.</p>"
        End Function

#End Region

#Region "Implementation"


#End Region

#Region "Fields"

        Private m_Chart As NPolarChart

#End Region

#Region "Schema"

        Public Shared ReadOnly NPolarVectorExampleSchema As NSchema

#End Region

#Region "Static Methods"

        Private Shared Function ColorFromValue(ByVal value As Double) As NColor
            Return NColor.InterpolateColors(NColor.Red, NColor.Blue, value / 100.0)
        End Function

#End Region
    End Class
End Namespace

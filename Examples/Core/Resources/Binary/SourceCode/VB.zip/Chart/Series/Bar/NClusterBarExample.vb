Imports System

Imports Nevron.Nov.Chart
Imports Nevron.Nov.Dom
Imports Nevron.Nov.Graphics
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.Chart
    ''' <summary>
    ''' Cluster Bar Example
    ''' </summary>
    Public Class NClusterBarExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' Default constructor
        ''' </summary>
        Public Sub New()

        End Sub
        ''' <summary>
        ''' Static constructor
        ''' </summary>
        Shared Sub New()
            NClusterBarExampleSchema = NSchema.Create(GetType(NClusterBarExample), NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            Dim chartViewWithCommandBars As NChartViewWithCommandBars = New NChartViewWithCommandBars()
            Dim chartView = chartViewWithCommandBars.View
            chartView.Surface.CreatePredefinedChart(ENPredefinedChartType.Cartesian)

            ' configure title
            chartView.Surface.Titles(0).Text = "Cluster Bar Labels"

            ' configure chart
            Dim chart = CType(chartView.Surface.Charts(0), NCartesianChart)

            ' add interlace stripe
            Dim linearScale As NLinearScale = TryCast(chart.Axes(ENCartesianAxis.PrimaryY).Scale, NLinearScale)
            Dim strip As NScaleStrip = New NScaleStrip(New NColorFill(ENNamedColor.Beige), Nothing, True, 0, 0, 1, 1)
            strip.Interlaced = True
            linearScale.Strips.Add(strip)

            ' add a bar series
            m_Bar1 = New NBarSeries()
            m_Bar1.Name = "Bar1"
            m_Bar1.MultiBarMode = ENMultiBarMode.Series
            m_Bar1.DataLabelStyle = CreateDataLabelStyle()
            m_Bar1.ValueFormatter = New NNumericValueFormatter("0.###")
            chart.Series.Add(m_Bar1)

            ' add another bar series
            m_Bar2 = New NBarSeries()
            m_Bar2.Name = "Bar2"
            m_Bar2.MultiBarMode = ENMultiBarMode.Clustered
            m_Bar2.DataLabelStyle = CreateDataLabelStyle()
            m_Bar2.ValueFormatter = New NNumericValueFormatter("0.###")
            chart.Series.Add(m_Bar2)

            FillRandomData()

            chartView.Document.StyleSheets.ApplyTheme(New NChartTheme(ENChartPalette.Bright, ENChartPaletteTarget.Series))

            Return chartViewWithCommandBars
        End Function
        Protected Overrides Function CreateExampleControls() As NWidget
            Dim propertyStack As NStackPanel = New NStackPanel()
            Dim boxGroup As NUniSizeBoxGroup = New NUniSizeBoxGroup(propertyStack)

            Dim gapPercentNumericUpDown As NNumericUpDown = New NNumericUpDown()
            propertyStack.Add(NPairBox.Create("Gap Percent: ", gapPercentNumericUpDown))

            gapPercentNumericUpDown.Value = m_Bar1.WidthGapFactor * 100.0
            gapPercentNumericUpDown.ValueChanged += New [Function](Of NValueChangeEventArgs)(AddressOf gapPercentNumericUpDown_ValueChanged)

            Return boxGroup
        End Function
        Protected Overrides Function GetExampleDescription() As String
            Return "<p>This example demonstrates how to create a cluster bar chart.</p>"
        End Function

#End Region

#Region "Implementation"

        ''' <summary>
        ''' Creates a new data label style object
        ''' </summary>
        ''' <returns></returns>
        Private Function CreateDataLabelStyle() As NDataLabelStyle
            Dim dataLabelStyle As NDataLabelStyle = New NDataLabelStyle()

            dataLabelStyle.Format = "<value>"

            Return dataLabelStyle
        End Function
        Private Sub FillRandomData()
            Dim random As Random = New Random()
            For i = 0 To 4
                m_Bar1.DataPoints.Add(New NBarDataPoint(random.Next(10, 100)))
                m_Bar2.DataPoints.Add(New NBarDataPoint(random.Next(10, 100)))
            Next
        End Sub

#End Region

#Region "Event Handlers"

        Private Sub gapPercentNumericUpDown_ValueChanged(ByVal arg As NValueChangeEventArgs)
            m_Bar1.WidthGapFactor = CType(arg.TargetNode, NNumericUpDown).Value / 100.0
        End Sub

#End Region

#Region "Fields"

        Private m_Bar1 As NBarSeries
        Private m_Bar2 As NBarSeries

#End Region

#Region "Schema"

        Public Shared ReadOnly NClusterBarExampleSchema As NSchema

#End Region
    End Class
End Namespace

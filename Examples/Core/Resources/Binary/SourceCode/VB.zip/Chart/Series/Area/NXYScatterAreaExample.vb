Imports System

Imports Nevron.Nov.Chart
Imports Nevron.Nov.Dom
Imports Nevron.Nov.Graphics
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.Chart
    ''' <summary>
    ''' XY Scatter Area Example
    ''' </summary>
    Public Class NXYScatterAreaExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' Default constructor
        ''' </summary>
        Public Sub New()

        End Sub
        ''' <summary>
        ''' Static constructor
        ''' </summary>
        Shared Sub New()
            NXYScatterAreaExampleSchema = NSchema.Create(GetType(NXYScatterAreaExample), NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            Dim chartViewWithCommandBars As NChartViewWithCommandBars = New NChartViewWithCommandBars()
            m_ChartView = chartViewWithCommandBars.View
            m_ChartView.Surface.CreatePredefinedChart(ENPredefinedChartType.Cartesian)

            ' configure title
            m_ChartView.Surface.Titles(0).Text = "XY Scatter Area"

            ' configure chart
            Dim chart = CType(m_ChartView.Surface.Charts(0), NCartesianChart)
            chart.SetPredefinedCartesianAxes(ENPredefinedCartesianAxis.XYLinear)

            ' add interlace stripe
            Dim linearScale As NLinearScale = chart.Axes(ENCartesianAxis.PrimaryY).Scale
            Dim stripStyle As NScaleStrip = New NScaleStrip(New NColorFill(NColor.Beige), Nothing, True, 0, 0, 1, 1)
            stripStyle.Interlaced = True
            linearScale.Strips.Add(stripStyle)

            ' show the x axis grid lines
            linearScale = chart.Axes(ENCartesianAxis.PrimaryX).Scale

            Dim majorGrid As NScaleGridLines = New NScaleGridLines()
            majorGrid.Visible = True
            linearScale.MajorGridLines = majorGrid

            ' add the area series
            m_Area = New NAreaSeries()
            m_Area.Name = "Area Series"

            Dim dataLabelStyle As NDataLabelStyle = New NDataLabelStyle()
            dataLabelStyle.Visible = True
            dataLabelStyle.ArrowStroke.Width = 0
            dataLabelStyle.Format = "<value>"
            m_Area.DataLabelStyle = dataLabelStyle

            m_Area.UseXValues = True

            ' add xy values
            m_Area.DataPoints.Add(New NAreaDataPoint(12, 10))
            m_Area.DataPoints.Add(New NAreaDataPoint(25, 23))
            m_Area.DataPoints.Add(New NAreaDataPoint(45, 12))
            m_Area.DataPoints.Add(New NAreaDataPoint(55, 24))
            m_Area.DataPoints.Add(New NAreaDataPoint(61, 16))
            m_Area.DataPoints.Add(New NAreaDataPoint(69, 19))
            m_Area.DataPoints.Add(New NAreaDataPoint(78, 17))

            chart.Series.Add(m_Area)

            Return chartViewWithCommandBars
        End Function
        Protected Overrides Function CreateExampleControls() As NWidget
            Dim stack As NStackPanel = New NStackPanel()
            Dim boxGroup As NUniSizeBoxGroup = New NUniSizeBoxGroup(stack)

            Dim changeXValuesButton As NButton = New NButton("Change X Values")
            changeXValuesButton.Click += New [Function](Of NEventArgs)(AddressOf OnChangeXValuesButtonClick)
            stack.Add(changeXValuesButton)

            Dim xAxisRoundToTickCheckBox As NCheckBox = New NCheckBox("X Axis Round To Tick")
            xAxisRoundToTickCheckBox.CheckedChanged += New [Function](Of NValueChangeEventArgs)(AddressOf OnXAxisRoundToTickCheckBoxCheckedChanged)
            stack.Add(xAxisRoundToTickCheckBox)

            Dim invertXAxisCheckBox As NCheckBox = New NCheckBox("Invert X Axis")
            invertXAxisCheckBox.CheckedChanged += New [Function](Of NValueChangeEventArgs)(AddressOf OnInvertXAxisCheckBoxCheckedChanged)
            stack.Add(invertXAxisCheckBox)

            Dim invertYAxisCheckBox As NCheckBox = New NCheckBox("Invert Y Axis")
            invertYAxisCheckBox.CheckedChanged += New [Function](Of NValueChangeEventArgs)(AddressOf OnInvertYAxisCheckBoxCheckedChanged)
            stack.Add(invertYAxisCheckBox)


            Return boxGroup
        End Function
        Protected Overrides Function GetExampleDescription() As String
            Return "<p>This example demonstrates how to create an xy scatter area chart.</p>"
        End Function

#End Region

#Region "Implementation"

#End Region

#Region "Event Handlers"

        Private Sub OnChangeXValuesButtonClick(ByVal arg As NEventArgs)
            Dim random As Random = New Random()
            Dim dataPointCount = m_Area.DataPoints.Count
            m_Area.DataPoints(0).X = random.Next(10)

            For i = 1 To dataPointCount - 1
                m_Area.DataPoints(i).X = m_Area.DataPoints(i - 1).X + random.Next(1, 10)
            Next
        End Sub

        Private Sub OnInvertXAxisCheckBoxCheckedChanged(ByVal arg As NValueChangeEventArgs)
            Dim chart = CType(m_ChartView.Surface.Charts(0), NCartesianChart)
            chart.Axes(ENCartesianAxis.PrimaryX).Scale.Invert = CType(arg.TargetNode, NCheckBox).Checked
        End Sub

        Private Sub OnInvertYAxisCheckBoxCheckedChanged(ByVal arg As NValueChangeEventArgs)
            Dim chart = CType(m_ChartView.Surface.Charts(0), NCartesianChart)
            chart.Axes(ENCartesianAxis.PrimaryY).Scale.Invert = CType(arg.TargetNode, NCheckBox).Checked
        End Sub

        Private Sub OnXAxisRoundToTickCheckBoxCheckedChanged(ByVal arg As NValueChangeEventArgs)
            Dim chart = CType(m_ChartView.Surface.Charts(0), NCartesianChart)
            Dim linearScale As NLinearScale = chart.Axes(ENCartesianAxis.PrimaryX).Scale

            If TryCast(arg.TargetNode, NCheckBox).Checked Then
                linearScale.ViewRangeInflateMode = ENScaleViewRangeInflateMode.MajorTick
                linearScale.InflateViewRangeBegin = True
                linearScale.InflateViewRangeEnd = True
            Else
                linearScale.ViewRangeInflateMode = ENScaleViewRangeInflateMode.Logical
            End If

        End Sub

#End Region

#Region "Fields"

        Private m_ChartView As NChartView
        Private m_Area As NAreaSeries

#End Region

#Region "Schema"

        Public Shared ReadOnly NXYScatterAreaExampleSchema As NSchema

#End Region
    End Class
End Namespace

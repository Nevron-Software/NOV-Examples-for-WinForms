Imports System

Imports Nevron.Nov.Chart
Imports Nevron.Nov.Dom
Imports Nevron.Nov.Graphics
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.Chart
    ''' <summary>
    ''' Polar area example
    ''' </summary>
    Public Class NPolarAreaExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' Default constructor
        ''' </summary>
        Public Sub New()

        End Sub
        ''' <summary>
        ''' Static constructor
        ''' </summary>
        Shared Sub New()
            NPolarAreaExampleSchema = NSchema.Create(GetType(NPolarAreaExample), NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            Dim chartViewWithCommandBars As NChartViewWithCommandBars = New NChartViewWithCommandBars()
            Dim chartView = chartViewWithCommandBars.View
            chartView.Surface.CreatePredefinedChart(ENPredefinedChartType.Polar)

            ' configure title
            chartView.Surface.Titles(0).Text = "Polar Area"

            ' configure chart
            m_Chart = CType(chartView.Surface.Charts(0), NPolarChart)

            m_Chart.SetPredefinedPolarAxes(ENPredefinedPolarAxes.AngleValue)

            ' setup polar axis
            Dim linearScale As NLinearScale = m_Chart.Axes(ENPolarAxis.PrimaryValue).Scale
            linearScale.ViewRangeInflateMode = ENScaleViewRangeInflateMode.MajorTick
            linearScale.InflateViewRangeBegin = True
            linearScale.InflateViewRangeEnd = True
            linearScale.MajorGridLines.Stroke = New NStroke(1, NColor.Black)

            Dim strip As NScaleStrip = New NScaleStrip()
            strip.Fill = New NColorFill(NColor.FromColor(NColor.Beige, 0.5F))
            strip.Interlaced = True
            linearScale.Strips.Add(strip)

            ' setup polar angle axis
            Dim angularScale As NAngularScale = m_Chart.Axes(ENPolarAxis.PrimaryAngle).Scale

            strip = New NScaleStrip()
            strip.Fill = New NColorFill(NColor.FromRGBA(192, 192, 192, 125))
            strip.Interlaced = True
            angularScale.Strips.Add(strip)

            ' polar area series 1
            Dim series1 As NPolarAreaSeries = New NPolarAreaSeries()
            m_Chart.Series.Add(series1)
            series1.Name = "Theoretical"
            series1.DataLabelStyle = New NDataLabelStyle(False)
            GenerateData(series1, 100, 15.0)

            ' polar area series 2
            Dim series2 As NPolarAreaSeries = New NPolarAreaSeries()
            m_Chart.Series.Add(series2)
            series2.Name = "Experimental"
            series2.DataLabelStyle = New NDataLabelStyle(False)
            GenerateData(series2, 100, 10.0)

            ' apply style sheet
            chartView.Document.StyleSheets.ApplyTheme(New NChartTheme(ENChartPalette.Bright, ENChartPaletteTarget.Series))

            Return chartViewWithCommandBars
        End Function
        Protected Overrides Function CreateExampleControls() As NWidget
            Dim stack As NStackPanel = New NStackPanel()
            Dim group As NUniSizeBoxGroup = New NUniSizeBoxGroup(stack)
            Return group
        End Function
        Protected Overrides Function GetExampleDescription() As String
            Return "<p>This example demonstrates how to create a polar area chart.</p>"
        End Function

#End Region

#Region "Event Handlers"



#End Region

#Region "Implementation"

        Private Sub GenerateData(ByVal series As NPolarAreaSeries, ByVal count As Integer, ByVal scale As Double)
            series.DataPoints.Clear()

            Dim angleStep = 2 * Math.PI / count
            Dim random As Random = New Random()

            For i = 0 To count - 1
                Dim angle = i * angleStep
                Dim c1 = 1.0 * Math.Sin(angle * 3)
                Dim c2 = 0.3 * Math.Sin(angle * 1.5)
                Dim c3 = 0.05 * Math.Cos(angle * 26)
                Dim c4 As Double = 0.05 * (0.5 - random.NextDouble())
                Dim value = scale * (Math.Abs(c1 + c2 + c3) + c4)

                If value < 0 Then value = 0

                series.DataPoints.Add(New NPolarAreaDataPoint(angle * 180 / Math.PI, value))
            Next
        End Sub

#End Region

#Region "Fields"

        Private m_Chart As NPolarChart

#End Region

#Region "Schema"

        Public Shared ReadOnly NPolarAreaExampleSchema As NSchema

#End Region
    End Class
End Namespace

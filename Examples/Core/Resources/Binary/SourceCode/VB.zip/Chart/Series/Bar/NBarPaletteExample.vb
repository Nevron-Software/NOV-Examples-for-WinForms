Imports System

Imports Nevron.Nov.Chart
Imports Nevron.Nov.Dom
Imports Nevron.Nov.Graphics
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.Chart
    ''' <summary>
    ''' This example demonstrates how to associate a palette with a bar series
    ''' </summary>
    Public Class NBarPaletteExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' 
        ''' </summary>
        Public Sub New()
        End Sub
        ''' <summary>
        ''' 
        ''' </summary>
        Shared Sub New()
            NBarPaletteExampleSchema = NSchema.Create(GetType(NBarPaletteExample), NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            Dim chartViewWithCommandBars As NChartViewWithCommandBars = New NChartViewWithCommandBars()
            Dim chartView = chartViewWithCommandBars.View
            chartView.Surface.CreatePredefinedChart(ENPredefinedChartType.Cartesian)

            chartView.Registered += AddressOf OnChartViewRegistered
            chartView.Unregistered += AddressOf OnChartViewUnregistered

            ' configure title
            chartView.Surface.Titles(0).Text = "Bar Palette"

            ' configure chart
            m_Chart = CType(chartView.Surface.Charts(0), NCartesianChart)
            m_Chart.SetPredefinedCartesianAxes(ENPredefinedCartesianAxis.XOrdinalYLinear)

            ' add interlace stripe
            Dim linearScale As NLinearScale = TryCast(m_Chart.Axes(ENCartesianAxis.PrimaryY).Scale, NLinearScale)
            Dim strip As NScaleStrip = New NScaleStrip(New NColorFill(ENNamedColor.Beige), Nothing, True, 0, 0, 1, 1)
            strip.Interlaced = True
            'linearScale.Strips.Add(strip);

            ' setup a bar series
            m_Bar = New NBarSeries()
            m_Bar.Name = "Bar Series"
            m_Bar.InflateMargins = True
            m_Bar.UseXValues = False
            m_Bar.DataLabelStyle = New NDataLabelStyle(False)

            m_Bar.Palette = New NColorValuePalette(New NColorValuePair() {New NColorValuePair(0, NColor.Green), New NColorValuePair(60, NColor.Yellow), New NColorValuePair(120, NColor.Red)})

            m_AxisRange = New NRange(0, 130)

            ' limit the axis range to 0, 130
            Dim yAxis = m_Chart.Axes(ENCartesianAxis.PrimaryY)
            yAxis.ViewRangeMode = ENAxisViewRangeMode.FixedRange
            yAxis.MinViewRangeValue = m_AxisRange.Begin
            yAxis.MaxViewRangeValue = m_AxisRange.End
            m_Chart.Series.Add(m_Bar)

            Dim indicatorCount = 10
            m_IndicatorPhase = New Double(indicatorCount - 1) {}

            ' add some data to the bar series
            For i = 0 To indicatorCount - 1
                m_IndicatorPhase(i) = i * 30
                m_Bar.DataPoints.Add(New NBarDataPoint(0))
            Next

            Return chartViewWithCommandBars
        End Function
        Protected Overrides Function CreateExampleControls() As NWidget
            Dim stack As NStackPanel = New NStackPanel()

            Dim toggleTimerButton As NButton = New NButton("Stop Timer")
            toggleTimerButton.Click += AddressOf OnToggleTimerButtonClick
            toggleTimerButton.Tag = 0
            stack.Add(toggleTimerButton)

            Dim paletteColorModeCombo As NComboBox = New NComboBox()
            paletteColorModeCombo.FillFromEnum(Of ENPaletteColorMode)()
            paletteColorModeCombo.SelectedIndexChanged += AddressOf OnPaletteColorModeComboSelectedIndexChanged
            paletteColorModeCombo.SelectedIndex = CInt(ENPaletteColorMode.Spread)
            stack.Add(NPairBox.Create("Palette Color Mode:", paletteColorModeCombo))

            Dim invertScaleCheckBox As NCheckBox = New NCheckBox("Invert Scale")
            invertScaleCheckBox.CheckedChanged += AddressOf OnInvertScaleCheckBoxCheckedChanged
            invertScaleCheckBox.Checked = False
            stack.Add(invertScaleCheckBox)

            Dim smoothPaletteCheckBox As NCheckBox = New NCheckBox("Smooth Palette")
            smoothPaletteCheckBox.CheckedChanged += AddressOf OnSmoothPaletteCheckBoxCheckedChanged
            smoothPaletteCheckBox.Checked = True
            stack.Add(smoothPaletteCheckBox)

            Return stack
        End Function
        Protected Overrides Function GetExampleDescription() As String
            Return "<p>This example demonstrates how to associate a palette with a bar series.</p>"
        End Function

#End Region

#Region "Event Handlers"

        Private Sub OnChartViewRegistered(ByVal arg As NEventArgs)
            m_Timer = New NTimer()
            Me.m_Timer.Tick += AddressOf OnTimerTick
            m_Timer.Start()
        End Sub
        Private Sub OnChartViewUnregistered(ByVal arg As NEventArgs)
            m_Timer.Stop()
            Me.m_Timer.Tick -= AddressOf OnTimerTick
            m_Timer = Nothing
        End Sub

        Private Sub OnInvertScaleCheckBoxCheckedChanged(ByVal arg As NValueChangeEventArgs)
            m_Chart.Axes(ENCartesianAxis.PrimaryY).Scale.Invert = CType(arg.TargetNode, NCheckBox).Checked
        End Sub

        Private Sub OnPaletteColorModeComboSelectedIndexChanged(ByVal arg As NValueChangeEventArgs)
            Dim paletteColorMode As ENPaletteColorMode = CType(arg.TargetNode, NComboBox).SelectedIndex

            m_Bar.PaletteColorMode = paletteColorMode
        End Sub

        Private Sub OnToggleTimerButtonClick(ByVal arg As NEventArgs)
            Dim button = CType(arg.TargetNode, NButton)
            If CInt(button.Tag) = 0 Then
                m_Timer.Stop()

                button.Content = New NLabel("Start Timer")
                button.Tag = 1
            Else
                m_Timer.Start()
                button.Content = New NLabel("Stop Timer")
                button.Tag = 0
            End If
        End Sub

        Private Sub OnTimerTick()
            Dim random As Random = New Random()

            For i = 0 To m_Bar.DataPoints.Count - 1
                Dim value As Double = (m_AxisRange.Begin + m_AxisRange.End) / 2.0 + Math.Sin(m_IndicatorPhase(i) * NAngle.Degree2Rad) * m_AxisRange.GetLength() / 2 + random.Next(20)
                value = m_AxisRange.GetValueInRange(value)

                m_Bar.DataPoints(i).Value = value
                m_IndicatorPhase(i) += 10
            Next
        End Sub

        Private Sub OnSmoothPaletteCheckBoxCheckedChanged(ByVal arg As NValueChangeEventArgs)
            Dim smoothPalette = CType(arg.TargetNode, NCheckBox).Checked
            m_Bar.Palette.InterpolateColors = smoothPalette
        End Sub

#End Region

#Region "Fields"

        Private m_Chart As NCartesianChart
        Private m_Bar As NBarSeries
        Private m_Timer As NTimer
        Private m_IndicatorPhase As Double()
        Private m_AxisRange As NRange

#End Region

#Region "Schema"

        Public Shared ReadOnly NBarPaletteExampleSchema As NSchema

#End Region
    End Class
End Namespace

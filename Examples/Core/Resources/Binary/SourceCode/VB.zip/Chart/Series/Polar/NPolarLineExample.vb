Imports System
Imports Nevron.Nov.Chart
Imports Nevron.Nov.Dom
Imports Nevron.Nov.Graphics
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.Chart
    ''' <summary>
    ''' Polar area example
    ''' </summary>
    Public Class NPolarLineExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' Default constructor
        ''' </summary>
        Public Sub New()
        End Sub
        ''' <summary>
        ''' Static constructor
        ''' </summary>
        Shared Sub New()
            NPolarLineExampleSchema = NSchema.Create(GetType(NPolarLineExample), NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            Dim chartView As NChartView = CreatePolarChartView()

            ' configure title
            chartView.Surface.Titles(0).Text = "Polar Line"

            ' configure chart
            m_Chart = CType(chartView.Surface.Charts(0), NPolarChart)
            m_Chart.SetPredefinedPolarAxes(ENPredefinedPolarAxes.AngleValue)

            ' setup polar axis
            Dim linearScale = CType(m_Chart.Axes(ENPolarAxis.PrimaryValue).Scale, NLinearScale)
            linearScale.ViewRangeInflateMode = ENScaleViewRangeInflateMode.MajorTick
            linearScale.InflateViewRangeBegin = True
            linearScale.InflateViewRangeEnd = True
            linearScale.MajorGridLines.Visible = True
            Dim strip As NScaleStrip = New NScaleStrip()
            strip.Fill = New NColorFill(New NColor(NColor.Beige, 125))
            strip.Interlaced = True
            linearScale.Strips.Add(strip)

            ' setup polar angle axis
            Dim angularScale = CType(m_Chart.Axes(ENPolarAxis.PrimaryAngle).Scale, NAngularScale)
            strip = New NScaleStrip()
            strip.Fill = New NColorFill(NColor.FromRGBA(192, 192, 192, 125))
            strip.Interlaced = True
            angularScale.Strips.Add(strip)

            ' add a const line
            Dim line As NAxisReferenceLine = New NAxisReferenceLine()
            m_Chart.Axes(ENPolarAxis.PrimaryValue).ReferenceLines.Add(line)
            line.Value = 50
            line.Stroke = New NStroke(1, NColor.SlateBlue)

            ' create a polar line series
            Dim series1 As NPolarLineSeries = New NPolarLineSeries()
            m_Chart.Series.Add(series1)
            series1.Name = "Series 1"
            series1.CloseContour = True
            series1.DataLabelStyle = New NDataLabelStyle(False)
            Curve1(series1, 50)

            ' create a polar line series
            Dim series2 As NPolarLineSeries = New NPolarLineSeries()
            m_Chart.Series.Add(series2)
            series2.Name = "Series 2"
            series2.DataLabelStyle = New NDataLabelStyle(False)
            series2.CloseContour = True
            Curve2(series2, 100)

            ' create a polar line series
            Dim series3 As NPolarLineSeries = New NPolarLineSeries()
            m_Chart.Series.Add(series3)
            series3.Name = "Series 3"
            series3.CloseContour = False
            series3.DataLabelStyle = New NDataLabelStyle(False)
            Curve3(series3, 100)
            chartView.Document.StyleSheets.ApplyTheme(New NChartTheme(ENChartPalette.Bright, False))
            Return chartView
        End Function

        Protected Overrides Function CreateExampleControls() As NWidget
            Dim stack As NStackPanel = New NStackPanel()
            Dim group As NUniSizeBoxGroup = New NUniSizeBoxGroup(stack)
            Return group
        End Function

        Protected Overrides Function GetExampleDescription() As String
            Return "<p>This example demonstrates how to create a polar line chart.</p>"
        End Function

#End Region

#Region "Event Handlers"



#End Region

#Region "Implementation"

        ''' <summary>
        ''' 
        ''' </summary>
        ''' <paramname="series"></param>
        ''' <paramname="count"></param>
        Friend Shared Sub Curve1(ByVal series As NPolarLineSeries, ByVal count As Integer)
            series.DataPoints.Clear()
            Dim angleStep = 2 * Math.PI / count

            For i = 0 To count - 1
                Dim angle = i * angleStep
                Dim radius = 1 + Math.Cos(angle)
                series.DataPoints.Add(New NPolarLineDataPoint(angle * 180 / Math.PI, radius))
            Next
        End Sub
        ''' <summary>
        ''' 
        ''' </summary>
        ''' <paramname="series"></param>
        ''' <paramname="count"></param>
        Friend Shared Sub Curve2(ByVal series As NPolarLineSeries, ByVal count As Integer)
            series.DataPoints.Clear()
            Dim angleStep = 2 * Math.PI / count

            For i = 0 To count - 1
                Dim angle = i * angleStep
                Dim radius = 0.2 + 1.7 * Math.Sin(2 * angle) + 1.7 * Math.Cos(2 * angle)
                radius = Math.Abs(radius)
                series.DataPoints.Add(New NPolarLineDataPoint(angle * 180 / Math.PI, radius))
            Next
        End Sub
        ''' <summary>
        ''' 
        ''' </summary>
        ''' <paramname="series"></param>
        ''' <paramname="count"></param>
        Friend Shared Sub Curve3(ByVal series As NPolarLineSeries, ByVal count As Integer)
            series.DataPoints.Clear()
            Dim angleStep = 4 * Math.PI / count

            For i = 0 To count - 1
                Dim angle = i * angleStep
                Dim radius = 0.2 + angle / 5.0
                series.DataPoints.Add(New NPolarLineDataPoint(angle * 180 / Math.PI, radius))
            Next
        End Sub

#End Region

#Region "Fields"

        Private m_Chart As NPolarChart

#End Region

#Region "Schema"

        Public Shared ReadOnly NPolarLineExampleSchema As NSchema

#End Region

#Region "Static Methods"

        Private Shared Function CreatePolarChartView() As NChartView
            Dim chartView As NChartView = New NChartView()
            chartView.Surface.CreatePredefinedChart(ENPredefinedChartType.Polar)
            Return chartView
        End Function

#End Region
    End Class
End Namespace

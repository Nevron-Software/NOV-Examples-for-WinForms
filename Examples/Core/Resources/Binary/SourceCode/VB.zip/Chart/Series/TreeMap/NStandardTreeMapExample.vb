Imports System.Globalization
Imports System.IO

Imports Nevron.Nov.Chart
Imports Nevron.Nov.Dom
Imports Nevron.Nov.Graphics
Imports Nevron.Nov.UI
Imports Nevron.Nov.Xml

Namespace Nevron.Nov.Examples.Chart
    ''' <summary>
    ''' Standard TreeMap Example
    ''' </summary>
    Public Class NStandardTreeMapExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' Default constructor
        ''' </summary>
        Public Sub New()

        End Sub
        ''' <summary>
        ''' Static constructor
        ''' </summary>
        Shared Sub New()
            NStandardTreeMapExampleSchema = NSchema.Create(GetType(NStandardTreeMapExample), NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            Dim chartViewWithCommandBars As NChartViewWithCommandBars = New NChartViewWithCommandBars()
            Dim chartView = chartViewWithCommandBars.View
            chartView.Surface.CreatePredefinedChart(ENPredefinedChartType.TreeMap)

            ' configure title
            chartView.Surface.Titles(0).Text = "Standard TreeMap"

            Dim treeMap = CType(chartView.Surface.Charts(0), NTreeMapChart)

            ' Get the country list XML stream
            Dim stream As Stream = NResources.Instance.GetResourceStream("RSTR_TreeMapData_xml")

            ' Load an xml document from the stream
            Dim xmlDocument = NXmlDocument.LoadFromStream(stream)

            m_RootTreeMapNode = New NGroupTreeMapNode()

            Dim palette As NThreeColorPalette = New NThreeColorPalette()
            palette.OriginColor = NColor.White
            palette.BeginColor = NColor.Red
            palette.EndColor = NColor.Green
            m_RootTreeMapNode.Label = "Tree Map - Industry by Sector"
            m_RootTreeMapNode.Palette = palette

            treeMap.RootTreeMapNode = m_RootTreeMapNode

            Dim rootElement = CType(xmlDocument.GetChildAt(0), NXmlElement)

            For i = 0 To rootElement.ChildrenCount - 1
                Dim industry = CType(rootElement.GetChildAt(i), NXmlElement)
                Dim treeMapSeries As NGroupTreeMapNode = New NGroupTreeMapNode()


                treeMapSeries.BorderThickness = New NMargins(14.0)
                If i = 0 Then
                    treeMapSeries.Border = NBorder.CreateFilledBorder(NColor.Black)
                    treeMapSeries.Border.RightTopCorner = New NBorderCorner(NColor.Red)
                    treeMapSeries.Border.BottomLeftCorner = New NBorderCorner(NColor.Blue)

                End If

                treeMapSeries.Padding = New NMargins(12.0)

                m_RootTreeMapNode.ChildNodes.Add(treeMapSeries)

                treeMapSeries.Label = industry.GetAttributeValue("Name")
                treeMapSeries.Tooltip = New NTooltip(treeMapSeries.Label)

                For j = 0 To industry.ChildrenCount - 1
                    Dim company = CType(industry.GetChildAt(j), NXmlElement)

                    Dim value = Double.Parse(company.GetAttributeValue("Size"), CultureInfo.InvariantCulture)
                    Dim change = Double.Parse(company.GetAttributeValue("Change"), CultureInfo.InvariantCulture)
                    Dim label = company.GetAttributeValue("Name")

                    Dim node As NValueTreeMapNode = New NValueTreeMapNode(value, change, label)
                    node.ChangeValueType = ENChangeValueType.Percentage
                    node.Tooltip = New NTooltip(label)

                    treeMapSeries.ChildNodes.Add(node)
                Next
            Next

            Return chartViewWithCommandBars
        End Function
        Protected Overrides Function CreateExampleControls() As NWidget
            Dim stack As NStackPanel = New NStackPanel()
            Dim group As NUniSizeBoxGroup = New NUniSizeBoxGroup(stack)

            Dim horizontalFillModeComboBox As NComboBox = New NComboBox()
            horizontalFillModeComboBox.FillFromEnum(Of ENTreeMapHorizontalFillMode)()
            horizontalFillModeComboBox.SelectedIndexChanged += AddressOf OnHorizontalFillModeComboBoxSelectedIndexChanged
            horizontalFillModeComboBox.SelectedIndex = CInt(ENTreeMapHorizontalFillMode.LeftToRight)
            stack.Add(NPairBox.Create("Horizontal Fill Mode:", horizontalFillModeComboBox))

            Dim verticalFillModeComboBox As NComboBox = New NComboBox()
            verticalFillModeComboBox.FillFromEnum(Of ENTreeMapVerticalFillMode)()
            verticalFillModeComboBox.SelectedIndexChanged += AddressOf OnVerticalFillModeComboBoxSelectedIndexChanged
            verticalFillModeComboBox.SelectedIndex = CInt(ENTreeMapVerticalFillMode.TopToBottom)
            stack.Add(NPairBox.Create("Vertical Fill Mode:", verticalFillModeComboBox))

            Dim sortOrderComboBox As NComboBox = New NComboBox()
            sortOrderComboBox.FillFromEnum(Of ENTreeMapNodeSortOrder)()
            sortOrderComboBox.SelectedIndexChanged += AddressOf OnSortOrderComboBoxSelectedIndexChanged
            sortOrderComboBox.SelectedIndex = CInt(ENTreeMapNodeSortOrder.Ascending)
            stack.Add(NPairBox.Create("Sort Order:", sortOrderComboBox))

            Return group
        End Function
        Protected Overrides Function GetExampleDescription() As String
            Return "<p>This example demonstrates how to create a standard treemap chart.</p>"
        End Function

#End Region

#Region "Event Handlers"

        Private Sub OnHorizontalFillModeComboBoxSelectedIndexChanged(ByVal arg As NValueChangeEventArgs)
            m_RootTreeMapNode.HorizontalFillMode = CType(CType(arg.TargetNode, NComboBox).SelectedIndex, ENTreeMapHorizontalFillMode)
        End Sub

        Private Sub OnVerticalFillModeComboBoxSelectedIndexChanged(ByVal arg As NValueChangeEventArgs)
            m_RootTreeMapNode.VerticalFillMode = CType(CType(arg.TargetNode, NComboBox).SelectedIndex, ENTreeMapVerticalFillMode)
        End Sub

        Private Sub OnSortOrderComboBoxSelectedIndexChanged(ByVal arg As NValueChangeEventArgs)
            m_RootTreeMapNode.SortOrder = CType(CType(arg.TargetNode, NComboBox).SelectedIndex, ENTreeMapNodeSortOrder)
        End Sub

#End Region

#Region "Fields"

        Private m_RootTreeMapNode As NGroupTreeMapNode

#End Region

#Region "Schema"

        Public Shared ReadOnly NStandardTreeMapExampleSchema As NSchema

#End Region
    End Class
End Namespace

Imports System

Imports Nevron.Nov.Chart
Imports Nevron.Nov.Dom
Imports Nevron.Nov.Graphics
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.Chart
    ''' <summary>
    ''' Standard Box and Whiskers Example
    ''' </summary>
    Public Class NStandardBoxAndWhiskersExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' Default constructor
        ''' </summary>
        Public Sub New()

        End Sub
        ''' <summary>
        ''' Static constructor
        ''' </summary>
        Shared Sub New()
            NStandardBoxAndWhiskersExampleSchema = NSchema.Create(GetType(NStandardBoxAndWhiskersExample), NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            Dim chartViewWithCommandBars As NChartViewWithCommandBars = New NChartViewWithCommandBars()
            Dim chartView = chartViewWithCommandBars.View
            chartView.Surface.CreatePredefinedChart(ENPredefinedChartType.Cartesian)

            ' configure title
            chartView.Surface.Titles(0).Text = "Standard Box and Whiskers"

            ' configure chart
            m_Chart = CType(chartView.Surface.Charts(0), NCartesianChart)

            m_Chart.SetPredefinedCartesianAxes(ENPredefinedCartesianAxis.XOrdinalYLinear)

            Dim linearScale As NLinearScale = m_Chart.Axes(ENCartesianAxis.PrimaryY).Scale
            ' add interlace stripe
            Dim strip As NScaleStrip = New NScaleStrip(New NColorFill(NColor.Beige), Nothing, True, 0, 0, 1, 1)
            strip.Interlaced = True
            linearScale.Strips.Add(strip)

            m_BoxAndWhiskerSeries = New NBoxAndWhiskerSeries()
            m_BoxAndWhiskerSeries.WidthSizeMode = ENBarSizeMode.Fixed
            m_Chart.Series.Add(m_BoxAndWhiskerSeries)

            m_BoxAndWhiskerSeries.Fill = New NStockGradientFill(ENGradientStyle.Vertical, ENGradientVariant.Variant4, NColor.LightYellow, NColor.DarkOrange)
            m_BoxAndWhiskerSeries.DataLabelStyle = New NDataLabelStyle(False)
            m_BoxAndWhiskerSeries.MedianStroke = New NStroke(NColor.Indigo)
            m_BoxAndWhiskerSeries.AverageStroke = New NStroke(1, NColor.DarkRed, ENDashStyle.Dot)
            m_BoxAndWhiskerSeries.OutlierStroke = New NStroke(NColor.DarkCyan)
            m_BoxAndWhiskerSeries.OutlierFill = New NColorFill(NColor.Red)

            GenerateData(m_BoxAndWhiskerSeries, 7)

            Return chartViewWithCommandBars
        End Function
        Protected Overrides Function CreateExampleControls() As NWidget
            Dim stack As NStackPanel = New NStackPanel()
            Dim boxGroup As NUniSizeBoxGroup = New NUniSizeBoxGroup(stack)

            Dim boxWidthUpDown As NNumericUpDown = New NNumericUpDown()
            boxWidthUpDown.Value = m_BoxAndWhiskerSeries.Width
            boxWidthUpDown.ValueChanged += AddressOf OnBoxWidthUpDownValueChanged
            stack.Add(NPairBox.Create("Box Width:", boxWidthUpDown))

            Dim whiskerWidthPercentUpDown As NNumericUpDown = New NNumericUpDown()
            whiskerWidthPercentUpDown.Value = m_BoxAndWhiskerSeries.WhiskerWidthPercent
            whiskerWidthPercentUpDown.ValueChanged += AddressOf OnWhiskerWidthPercentUpDownValueChanged
            stack.Add(NPairBox.Create("Whisker Width %:", whiskerWidthPercentUpDown))

            Dim inflateMarginsCheckBox As NCheckBox = New NCheckBox("Inflate Margins")
            inflateMarginsCheckBox.CheckedChanged += AddressOf OnInflateMarginsCheckBoxCheckedChanged
            inflateMarginsCheckBox.Checked = True
            stack.Add(inflateMarginsCheckBox)

            Dim yAxisRoundToTickCheckBox As NCheckBox = New NCheckBox("Y Axis Round To Tick")
            yAxisRoundToTickCheckBox.CheckedChanged += AddressOf OnYAxisRoundToTickCheckBoxCheckedChanged
            yAxisRoundToTickCheckBox.Checked = True
            stack.Add(yAxisRoundToTickCheckBox)

            Dim generateDataButton As NButton = New NButton("Generate Data")
            generateDataButton.Click += AddressOf OnGenerateDataButtonClick
            stack.Add(generateDataButton)

            Return boxGroup
        End Function
        Protected Overrides Function GetExampleDescription() As String
            Return "<p>This example demonstrates how to create a standard box and whisker chart.</p>"
        End Function

#End Region

#Region "Event Handlers"

        Private Sub OnBoxWidthUpDownValueChanged(ByVal arg As NValueChangeEventArgs)
            m_BoxAndWhiskerSeries.Width = CType(arg.TargetNode, NNumericUpDown).Value
        End Sub

        Private Sub OnGenerateDataButtonClick(ByVal arg As NEventArgs)
            GenerateData(m_BoxAndWhiskerSeries, 7)
        End Sub

        Private Sub OnWhiskerWidthPercentUpDownValueChanged(ByVal arg As NValueChangeEventArgs)
            m_BoxAndWhiskerSeries.WhiskerWidthPercent = CType(arg.TargetNode, NNumericUpDown).Value
        End Sub

        Private Sub OnInflateMarginsCheckBoxCheckedChanged(ByVal arg As NValueChangeEventArgs)
            m_BoxAndWhiskerSeries.InflateMargins = CType(arg.TargetNode, NCheckBox).Checked
        End Sub

        Private Sub OnYAxisRoundToTickCheckBoxCheckedChanged(ByVal arg As NValueChangeEventArgs)
            Dim yScale As NLinearScale = m_Chart.Axes(ENCartesianAxis.PrimaryY).Scale

            If CType(arg.TargetNode, NCheckBox).Checked Then
                yScale.ViewRangeInflateMode = ENScaleViewRangeInflateMode.MajorTick
                yScale.InflateViewRangeBegin = True
                yScale.InflateViewRangeEnd = True
            Else
                yScale.InflateViewRangeBegin = False
                yScale.InflateViewRangeEnd = False
            End If
        End Sub

#End Region

#Region "Implementation"

        Private Sub GenerateData(ByVal series As NBoxAndWhiskerSeries, ByVal nCount As Integer)
            series.DataPoints.Clear()
            Dim random As Random = New Random()

            For i = 0 To nCount - 1
                Dim boxLower As Double = 1000 + random.NextDouble() * 200
                Dim boxUpper As Double = boxLower + 200 + random.NextDouble() * 200
                Dim whiskersLower As Double = boxLower - (20 + random.NextDouble() * 300)
                Dim whiskersUpper As Double = boxUpper + (20 + random.NextDouble() * 300)

                Dim IQR = boxUpper - boxLower
                Dim median As Double = boxLower + IQR * 0.25 + random.NextDouble() * IQR * 0.5
                Dim average As Double = boxLower + IQR * 0.25 + random.NextDouble() * IQR * 0.5

                Dim outliersCount = random.Next(5)

                Dim outliers = New Double(outliersCount - 1) {}

                For k = 0 To outliersCount - 1
                    Dim outlier As Double = 0

                    If random.NextDouble() > 0.5 Then
                        outlier = boxUpper + IQR * 1.5 + random.NextDouble() * 100
                    Else
                        outlier = boxLower - IQR * 1.5 - random.NextDouble() * 100
                    End If

                    outliers(k) = outlier
                Next

                series.DataPoints.Add(New NBoxAndWhiskerDataPoint(i, boxUpper, boxLower, median, average, whiskersUpper, whiskersLower, outliers, String.Empty))
            Next
        End Sub

#End Region

#Region "Fields"

        Private m_Chart As NCartesianChart
        Private m_BoxAndWhiskerSeries As NBoxAndWhiskerSeries

#End Region

#Region "Schema"

        Public Shared ReadOnly NStandardBoxAndWhiskersExampleSchema As NSchema

#End Region
    End Class
End Namespace

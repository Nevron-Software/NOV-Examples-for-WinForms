Imports System

Imports Nevron.Nov.Chart
Imports Nevron.Nov.Chart.Tools
Imports Nevron.Nov.Dom
Imports Nevron.Nov.Graphics
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.Chart
    ''' <summary>
    ''' Triangulated Surface Projected Contour Example
    ''' </summary>
    Public Class NTriangulatedSurfaceRealTimeExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' Default constructor
        ''' </summary>
        Public Sub New()
            m_Random = New Random()
        End Sub
        ''' <summary>
        ''' Static constructor
        ''' </summary>
        Shared Sub New()
            NTriangulatedSurfaceRealTimeExampleSchema = NSchema.Create(GetType(NTriangulatedSurfaceRealTimeExample), NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            Dim chartViewWithCommandBars As NChartViewWithCommandBars = New NChartViewWithCommandBars()
            Dim chartView = chartViewWithCommandBars.View
            chartView.Surface.CreatePredefinedChart(ENPredefinedChartType.Cartesian)

            chartView.Registered += AddressOf OnChartViewRegistered
            chartView.Unregistered += AddressOf OnChartViewUnregistered

            ' configure title
            chartView.Surface.Titles(0).Text = "Realtime Grid Surface"

            ' setup chart
            Dim chart = CType(chartView.Surface.Charts(0), NCartesianChart)
            chart.SetPredefinedCartesianAxes(ENPredefinedCartesianAxis.XYZLinear)
            chart.Enable3D = True
            chart.ModelWidth = 50
            chart.ModelDepth = 50
            chart.ModelHeight = 30
            chart.FitMode = ENCartesianChartFitMode.Aspect
            chart.Projection.SetPredefinedProjection(ENPredefinedProjection.OrthogonalTop)
            chart.Interactor = New NInteractor(New NTrackballTool())

            For i = 0 To chart.Walls.GetChildrenCount() - 1
                CType(chart.Walls.GetChildAt(i), NChartWall).VisibilityMode = ENWallVisibilityMode.Hidden
            Next

            ' setup Y axis
            Dim scaleY As NLinearScale = New NLinearScale()
            scaleY.ViewRangeInflateMode = ENScaleViewRangeInflateMode.None
            scaleY.MinTickDistance = 10
            scaleY.MajorGridLines.ShowAtWalls = ENChartWall.Left Or ENChartWall.Back
            chart.Axes(ENCartesianAxis.PrimaryY).Scale = scaleY

            ' setup X axis
            Dim scaleX As NLinearScale = New NLinearScale()
            scaleX.ViewRangeInflateMode = ENScaleViewRangeInflateMode.None
            scaleX.MajorGridLines.ShowAtWalls = ENChartWall.Bottom Or ENChartWall.Back
            chart.Axes(ENCartesianAxis.PrimaryX).Scale = scaleX

            ' setup Z axis
            Dim scaleZ As NLinearScale = New NLinearScale()
            scaleZ.ViewRangeInflateMode = ENScaleViewRangeInflateMode.None
            scaleZ.MajorGridLines.ShowAtWalls = ENChartWall.Bottom Or ENChartWall.Left
            chart.Axes(ENCartesianAxis.Depth).Scale = scaleZ

            ' add the surface series
            Dim surface As NTriangulatedSurfaceSeries = New NTriangulatedSurfaceSeries()
            chart.Series.Add(surface)
            m_Surface = surface
            surface.Name = "Surface"

            surface.FillMode = ENSurfaceFillMode.Zone
            surface.FrameMode = ENSurfaceFrameMode.Mesh
            surface.ShadingMode = ENShadingMode.Flat

            Return chartViewWithCommandBars
        End Function

        Protected Overrides Function CreateExampleControls() As NWidget
            Dim stack As NStackPanel = New NStackPanel()
            Dim group As NUniSizeBoxGroup = New NUniSizeBoxGroup(stack)

            Dim gridSizeComboBox As NComboBox = New NComboBox()
            gridSizeComboBox.Items.Add(New NComboBoxItem("10x10"))
            gridSizeComboBox.Items.Add(New NComboBoxItem("100x100"))
            gridSizeComboBox.Items.Add(New NComboBoxItem("200x200"))
            gridSizeComboBox.Items.Add(New NComboBoxItem("500x500"))
            stack.Add(NPairBox.Create("Grid Size:", gridSizeComboBox))
            gridSizeComboBox.SelectedIndexChanged += AddressOf OnGridSizeComboBoxSelectedIndexChanged
            gridSizeComboBox.SelectedIndex = 1

            Dim enableShaderRenderingCheckBox As NCheckBox = New NCheckBox()
            stack.Add(NPairBox.Create("Enable Shader Rendering:", enableShaderRenderingCheckBox))
            enableShaderRenderingCheckBox.CheckedChanged += AddressOf OnEnableShaderRenderingCheckBoxCheckedChanged

            Dim toggleTimerButton As NButton = New NButton("Stop Timer")
            toggleTimerButton.Click += AddressOf OnToggleTimerButtonClick
            toggleTimerButton.Tag = 0
            stack.Add(toggleTimerButton)

            Return group
        End Function

        Protected Overrides Function GetExampleDescription() As String
            Return "<p>This example demonstrates the ability of the NTriangulatedSurfaceSeries to render large dynamically changing datasets with a minimal amount of CPU load. The example also shows how to efficiently fill data to the series.</p>"
        End Function

#End Region

#Region "Events"

        Private Sub OnChartViewRegistered(ByVal arg As NEventArgs)
            m_Timer = New NTimer()
            Me.m_Timer.Tick += AddressOf OnTimerTick
            m_Timer.Start()
        End Sub

        Private Sub OnChartViewUnregistered(ByVal arg As NEventArgs)
            m_Timer.Stop()
            Me.m_Timer.Tick -= AddressOf OnTimerTick
            m_Timer = Nothing
        End Sub

        Private Sub OnTimerTick()
            If m_GridSize = 0 Then Return

            ' The order of the values is x, y, z. In this case we dynamically modify only x and z.
            Const phaseStep = Math.PI / 10
                        ''' Cannot convert UnsafeStatementSyntax, CONVERSION ERROR: Conversion for UnsafeStatement not implemented, please report this issue in 'unsafe\r\n   {\r\n    fixed...' at character 7008
''' 
''' 
''' Input:
''' 
'''             unsafe
'''             {
'''                 fixed (byte* pData = &this.m_Surface.Data.Data[0])
'''                 {
'''                     float* pValues = (float*)pData;
'''                     int itemSize = this.m_Surface.Data.DataItemSize;
'''                     int count = this.m_Surface.Data.Count;
''' 
'''                     for (int x = 0; x < this.m_GridSize; x++)
'''                     {
'''                         for (int y = 0; y < this.m_GridSize; y++)
'''                         {
'''                             // The order of the values is x, y, z. In this case we dynamically modify only x and z.
'''                             pValues[0] = (float)(x + System.Math.Cos(this.m_Phase[x, y]) * this.m_Radius[x, y]);
'''                             pValues[2] = (float)(y + System.Math.Sin(this.m_Phase[x, y]) * this.m_Radius[x, y]);
''' 
'''                             this.m_Phase[x, y] += phaseStep;
''' 
'''                             pValues += itemSize;
'''                         }
'''                     }
''' 
'''                     this.m_Surface.Data.OnDataChanged();
'''                 }
'''             }
''' 
''' 
        End Sub


        Private Sub OnEnableShaderRenderingCheckBoxCheckedChanged(ByVal arg As NValueChangeEventArgs)
            m_Surface.EnableShaderRendering = CBool(arg.NewValue)
        End Sub

        Private Sub OnGridSizeComboBoxSelectedIndexChanged(ByVal arg As NValueChangeEventArgs)
            m_GridSize = 100

            Select Case arg.NewValue
                Case 0
                    m_GridSize = 10
                Case 1
                    m_GridSize = 100
                Case 2
                    m_GridSize = 200
                Case 3
                    m_GridSize = 500
            End Select

            Dim data = m_Surface.Data
            data.Clear()

            Const dIntervalX = 1.0F
            Const dIntervalZ = 1.0F

            Dim dIncrementX = dIntervalX / m_GridSize
            Dim dIncrementZ = dIntervalZ / m_GridSize

            m_Radius = New Double(m_GridSize - 1, m_GridSize - 1) {}
            m_Phase = New Double(m_GridSize - 1, m_GridSize - 1) {}

            Dim random As Random = New Random()

            Dim gridPhase As Single = Math.PI * 5 / m_GridSize

            For x = 0 To m_GridSize - 1
                Dim zVar = -(dIntervalZ / 2) + x * dIncrementZ

                For y = 0 To m_GridSize - 1
                    Dim xVar = -(dIncrementX / 2) + y * dIncrementX

                    m_Radius(x, y) = random.NextDouble()
                    m_Phase(x, y) = random.NextDouble() * Math.PI * 2

                    Dim yPos As Single = Math.Sin(y * gridPhase) + Math.Cos(x * gridPhase)
                    Dim xPos As Single = x + Math.Cos(m_Phase(x, y)) * m_Radius(x, y)
                    Dim zPos As Single = y + Math.Sin(m_Phase(x, y)) * m_Radius(x, y)

                    data.AddValue(New NVector3DF(xPos, yPos, zPos))
                Next
            Next
        End Sub

        Private Sub OnToggleTimerButtonClick(ByVal arg As NEventArgs)
            Dim button = CType(arg.TargetNode, NButton)
            If CInt(button.Tag) = 0 Then
                m_Timer.Stop()

                button.Content = New NLabel("Start Timer")
                button.Tag = 1
            Else
                m_Timer.Start()
                button.Content = New NLabel("Stop Timer")
                button.Tag = 0
            End If
        End Sub

#End Region

#Region "Fields"

        Private m_Timer As NTimer
        Private m_Surface As NTriangulatedSurfaceSeries
        Private m_GridSize As Integer
        Private m_Random As Random
        Private m_Phase As Double(,)
        Private m_Radius As Double(,)

#End Region

#Region "Schema"

        Public Shared ReadOnly NTriangulatedSurfaceRealTimeExampleSchema As NSchema

#End Region
    End Class
End Namespace

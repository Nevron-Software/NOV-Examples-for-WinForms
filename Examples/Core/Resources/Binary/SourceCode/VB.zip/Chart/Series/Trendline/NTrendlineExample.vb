Imports Nevron.Nov.Chart
Imports Nevron.Nov.Chart.Tools
Imports Nevron.Nov.Dom
Imports Nevron.Nov.Graphics
Imports Nevron.Nov.UI
Imports System

Namespace Nevron.Nov.Examples.Chart
    ''' <summary>
    ''' Trendline example
    ''' </summary>
    Public Class NTrendlineExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' Default constructor
        ''' </summary>
        Public Sub New()

        End Sub
        ''' <summary>
        ''' Static constructor
        ''' </summary>
        Shared Sub New()
            NCovarianceAndCorrelationExampleSchema = NSchema.Create(GetType(NTrendlineExample), NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            Dim chartViewWithCommandBars As NChartViewWithCommandBars = New NChartViewWithCommandBars()
            Dim chartView = chartViewWithCommandBars.View
            chartView.Surface.CreatePredefinedChart(ENPredefinedChartType.Cartesian)

            ' configure title
            chartView.Surface.Titles(0).Text = "Trendline Series"
            chartView.Surface.Legends(0).Visibility = ENVisibility.Collapsed

            ' configure chart
            m_Chart = CType(chartView.Surface.Charts(0), NCartesianChart)
            m_Chart.SetPredefinedCartesianAxes(ENPredefinedCartesianAxis.Standard)
            m_Chart.Interactor = New NInteractor(New NTrackballTool())

            ' switch X axis in linear scale
            m_Chart.Axes(ENCartesianAxis.PrimaryX).Scale = New NLinearScale()

            ' add interlace stripe
            Dim linearScale As NLinearScale = TryCast(m_Chart.Axes(ENCartesianAxis.PrimaryY).Scale, NLinearScale)
            Dim strip As NScaleStrip = New NScaleStrip(New NColorFill(ENNamedColor.Beige), Nothing, True, 0, 0, 1, 1)
            strip.Interlaced = True
            linearScale.Strips.Add(strip)

            ' setup line series to show trenline
            m_Trendline = New NTrendlineSeries()
            m_Trendline.Name = "Trendline Series"
            m_Trendline.Stroke = New NStroke(3, LineColor)
            m_Chart.Series.Add(m_Trendline)

            m_Trendline.LegendView.Mode = ENSeriesLegendMode.SeriesLogic

            ' setup point series to show XY scatter
            m_PointSeries = New NPointSeries()
            m_PointSeries.Name = "Point Series"
            m_PointSeries.UseXValues = True
            m_PointSeries.Fill = New NColorFill(BarColor)
            m_Chart.Series.Add(m_PointSeries)

            Return chartViewWithCommandBars
        End Function
        Protected Overrides Function CreateExampleControls() As NWidget
            Dim stack As NStackPanel = New NStackPanel()
            Dim boxGroup As NUniSizeBoxGroup = New NUniSizeBoxGroup(stack)

            Dim movingAveragePeriodNumericUpDown As NNumericUpDown = New NNumericUpDown()
            Dim polynomialOrderNumericUpDown As NNumericUpDown = New NNumericUpDown()
            m_PolynomialOrderNumericUpDown = polynomialOrderNumericUpDown
            m_MovingAveragePeriodNumericUpDown = movingAveragePeriodNumericUpDown

            Dim trendlineTypeComboBox As NComboBox = New NComboBox()
            trendlineTypeComboBox.FillFromEnum(Of ENTrendlineType)()
            trendlineTypeComboBox.SelectedIndexChanged += AddressOf OnTrendlineTypeComboBoxSelectedIndexChanged
            trendlineTypeComboBox.SelectedIndex = m_Trendline.TrendlineType
            stack.Add(NPairBox.Create("Trendline Type:", trendlineTypeComboBox))

            movingAveragePeriodNumericUpDown.Minimum = 1
            movingAveragePeriodNumericUpDown.Maximum = 30
            movingAveragePeriodNumericUpDown.Value = m_Trendline.MovingAveragePeriod
            movingAveragePeriodNumericUpDown.ValueChanged += AddressOf OnMovingAveragePeriodNumericUpDownValueChanged
            stack.Add(NPairBox.Create("Moving Average Period:", movingAveragePeriodNumericUpDown))

            polynomialOrderNumericUpDown.Minimum = 1
            polynomialOrderNumericUpDown.Maximum = 100
            polynomialOrderNumericUpDown.Value = m_Trendline.PolynomialOrder
            polynomialOrderNumericUpDown.ValueChanged += AddressOf OnPolynomialOrderNumericUpDownValueChanged
            stack.Add(NPairBox.Create("Polynomial Order:", polynomialOrderNumericUpDown))

            ' new positive data button
            Dim newDataButton As NButton = New NButton("New Data")
            ' fill with random data
            newDataButton.Click += Sub(e) RandomData()
            stack.Add(newDataButton)

            ' fill with random data
            RandomData()

            Return boxGroup
        End Function

        Protected Overrides Function GetExampleDescription() As String
            Return "<p>Curve fitting is the process of constructing a curve, or mathematical function, that has the best fit to a series of data points. In this example, the trendline series is used to 
display different fittings like linear, exponential, logarithmic, etc. of a source data points set.</p>" End Function

#End Region

#Region "Events"

        Private Sub OnTrendlineTypeComboBoxSelectedIndexChanged(ByVal arg As NValueChangeEventArgs)
            m_Trendline.TrendlineType = CType(arg.NewValue, ENTrendlineType)

            m_PolynomialOrderNumericUpDown.Enabled = False
            m_MovingAveragePeriodNumericUpDown.Enabled = False

            Select Case m_Trendline.TrendlineType
                Case ENTrendlineType.Polynomial
                    m_PolynomialOrderNumericUpDown.Enabled = True
                Case ENTrendlineType.MovingAverage
                    m_MovingAveragePeriodNumericUpDown.Enabled = True
            End Select
        End Sub


        Private Sub OnPolynomialOrderNumericUpDownValueChanged(ByVal arg As NValueChangeEventArgs)
            m_Trendline.PolynomialOrder = CInt(CDbl(arg.NewValue))
        End Sub

        Private Sub OnMovingAveragePeriodNumericUpDownValueChanged(ByVal arg As NValueChangeEventArgs)
            m_Trendline.MovingAveragePeriod = CInt(CDbl(arg.NewValue))
        End Sub

#End Region

#Region "Implementation"

        Private Sub RandomData()
            Dim rand As Random = New Random()

            Dim count = 100
            Dim randomDataX = New Double(count - 1) {}
            Dim randomDataY = New Double(count - 1) {}

            Dim x As Double
            For i = 0 To count - 1
                x = i + rand.NextDouble()

                randomDataX(i) = x * 10
                randomDataY(i) = x * 5.0 * rand.NextDouble() + rand.NextDouble()
            Next

            m_PointSeries.DataPoints.Clear()
            For i = 0 To randomDataX.Length - 1
                m_PointSeries.DataPoints.Add(New NPointDataPoint(randomDataX(i), randomDataY(i)))
            Next

            CalculateStatistics()
        End Sub
        Private Sub CalculateStatistics()

            ' show trendline
            m_Trendline.SourceSeries = m_PointSeries
        End Sub

        Private ReadOnly Property BarColor As NColor
            Get
                Return NChartPalette.FreshPalette(0)
            End Get
        End Property

        Private ReadOnly Property LineColor As NColor
            Get
                Return NChartPalette.FreshPalette(1)
            End Get
        End Property

#End Region

#Region "Fields"

        Private m_PointSeries As NPointSeries
        Private m_Chart As NCartesianChart
        Private m_Trendline As NTrendlineSeries
        Private m_PolynomialOrderNumericUpDown As NNumericUpDown
        Private m_MovingAveragePeriodNumericUpDown As NNumericUpDown

#End Region

#Region "Schema"

        Public Shared ReadOnly NCovarianceAndCorrelationExampleSchema As NSchema

#End Region
    End Class
End Namespace

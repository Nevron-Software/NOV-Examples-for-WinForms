Imports System

Imports Nevron.Nov.Chart
Imports Nevron.Nov.Chart.Tools
Imports Nevron.Nov.Dom
Imports Nevron.Nov.Graphics
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.Chart
    ''' <summary>
    ''' XYZ Scatter Point Example
    ''' </summary>
    Public Class NXYZScatterPointExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' Default constructor
        ''' </summary>
        Public Sub New()

        End Sub
        ''' <summary>
        ''' Static constructor
        ''' </summary>
        Shared Sub New()
            NXYZScatterPointExampleSchema = NSchema.Create(GetType(NXYZScatterPointExample), NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            Dim chartViewWithCommandBars As NChartViewWithCommandBars = New NChartViewWithCommandBars()
            Dim chartView = chartViewWithCommandBars.View
            chartView.Surface.CreatePredefinedChart(ENPredefinedChartType.Cartesian)

            ' configure title
            chartView.Surface.Titles(0).Text = "XYZ Scatter Point"

            ' configure chart
            m_Chart = CType(chartView.Surface.Charts(0), NCartesianChart)
            m_Chart.Enable3D = True
            m_Chart.FitMode = ENCartesianChartFitMode.Aspect
            m_Chart.ModelWidth = CSharpImpl.__Assign(m_Chart.ModelHeight, CSharpImpl.__Assign(m_Chart.ModelHeight, 50))

            m_Chart.Projection.SetPredefinedProjection(ENPredefinedProjection.PerspectiveTilted)
            m_Chart.LightModel.SetPredefinedLightModel(ENPredefinedLightModel.NorthernLights)

            m_Chart.SetPredefinedCartesianAxes(ENPredefinedCartesianAxis.XYZLinear)
            m_Chart.Interactor = New NInteractor(New NTrackballTool())

            ' setup X axis
            If True Then
                Dim linearScaleX As NLinearScale = New NLinearScale()
                m_Chart.Axes(ENCartesianAxis.PrimaryX).Scale = linearScaleX
                linearScaleX.MajorGridLines.Stroke.DashStyle = ENDashStyle.Dot
                linearScaleX.MajorGridLines.SetShowAtWall(ENChartWall.Back, True)
                linearScaleX.MajorGridLines.SetShowAtWall(ENChartWall.Bottom, True)

                Dim m_Strip As NScaleStrip = New NScaleStrip(New NColorFill(NColor.DarkGray), Nothing, True, 0, 0, 1, 1)
                m_Strip.Interlaced = True
                linearScaleX.Strips.Add(m_Strip)
            End If

            ' setup Y axis
            If True Then
                Dim linearScaleY As NLinearScale = New NLinearScale()
                m_Chart.Axes(ENCartesianAxis.PrimaryY).Scale = linearScaleY
                linearScaleY.MajorGridLines.Stroke.DashStyle = ENDashStyle.Dot
                linearScaleY.MajorGridLines.SetShowAtWall(ENChartWall.Back, True)
                linearScaleY.MajorGridLines.SetShowAtWall(ENChartWall.Left, True)

                Dim m_Strip As NScaleStrip = New NScaleStrip(New NColorFill(NColor.DarkGray), Nothing, True, 0, 0, 1, 1)
                m_Strip.Interlaced = True
                linearScaleY.Strips.Add(m_Strip)
            End If

            ' setup Z axis
            If True Then
                Dim linearScaleZ As NLinearScale = New NLinearScale()
                m_Chart.Axes(ENCartesianAxis.Depth).Scale = linearScaleZ
                linearScaleZ.MajorGridLines.Stroke.DashStyle = ENDashStyle.Dot
                linearScaleZ.MajorGridLines.SetShowAtWall(ENChartWall.Bottom, True)
                linearScaleZ.MajorGridLines.SetShowAtWall(ENChartWall.Left, True)

                Dim m_Strip As NScaleStrip = New NScaleStrip(New NColorFill(NColor.DarkGray), Nothing, True, 0, 0, 1, 1)
                m_Strip.Interlaced = True
                linearScaleZ.Strips.Add(m_Strip)
            End If

            ' add a point series
            m_Point = New NPointSeries()
            m_Point.Name = "Point Series"
            m_Point.DataLabelStyle = New NDataLabelStyle(False)
            m_Point.Fill = New NColorFill(New NColor(NColor.DarkOrange, 160))
            m_Point.Size = 20
            m_Point.Shape = ENPointShape3D.Sphere
            m_Point.UseXValues = True
            m_Point.UseZValues = True
            m_Point.ValueFormatter = New NNumericValueFormatter(ENNumericValueFormat.LimitedPrecision2)
            m_Chart.Series.Add(m_Point)

            OnNewDataButtonClick(Nothing)

            chartView.Document.StyleSheets.ApplyTheme(New NChartTheme(ENChartPalette.Bright, ENChartPaletteTarget.DataPoints))

            Return chartViewWithCommandBars
        End Function
        Protected Overrides Function CreateExampleControls() As NWidget
            Dim stack As NStackPanel = New NStackPanel()
            Dim group As NUniSizeBoxGroup = New NUniSizeBoxGroup(stack)

            Dim inflateMarginsCheckBox As NCheckBox = New NCheckBox()
            inflateMarginsCheckBox.CheckedChanged += New [Function](Of NValueChangeEventArgs)(AddressOf OnInflateMarginsCheckBoxCheckedChanged)
            stack.Add(NPairBox.Create("Inflate Margins: ", inflateMarginsCheckBox))

            Dim verticalAxisRoundToTick As NCheckBox = New NCheckBox()
            verticalAxisRoundToTick.CheckedChanged += New [Function](Of NValueChangeEventArgs)(AddressOf OnAxesRoundToTickCheckedChanged)
            stack.Add(NPairBox.Create("Axes Round To Tick: ", verticalAxisRoundToTick))
            verticalAxisRoundToTick.Checked = True

            Dim showDataLabels As NCheckBox = New NCheckBox("Show Data Labels")
            showDataLabels.CheckedChanged += New [Function](Of NValueChangeEventArgs)(AddressOf OnShowDataLabelsCheckedChanged)
            showDataLabels.Checked = False
            stack.Add(showDataLabels)

            Dim newDataButton As NButton = New NButton("New Data")
            newDataButton.Click += New [Function](Of NEventArgs)(AddressOf OnNewDataButtonClick)
            stack.Add(newDataButton)

            Return group
        End Function
        Protected Overrides Function GetExampleDescription() As String
            Return "<p>This example demonstrates how to create a xy scatter point chart.</p>"
        End Function

#End Region

#Region "Event Handlers"

        Private Sub OnShowDataLabelsCheckedChanged(ByVal arg As NValueChangeEventArgs)
            If TryCast(arg.TargetNode, NCheckBox).Checked Then
                m_Point.DataLabelStyle = New NDataLabelStyle(True)
                m_Point.DataLabelStyle.Format = "<value>"
            Else
                m_Point.DataLabelStyle = New NDataLabelStyle(False)
            End If
        End Sub

        Private Sub OnNewDataButtonClick(ByVal arg As NEventArgs)
            m_Point.DataPoints.Clear()
            Dim dataPoints = m_Point.DataPoints

            Dim random As Random = New Random()

            For i = 0 To 9
                Dim u1 As Double = random.NextDouble()
                Dim u2 As Double = random.NextDouble()
                Dim u3 As Double = random.NextDouble()

                If u1 = 0 Then u1 += 0.0001

                If u2 = 0 Then u2 += 0.0001

                Dim z0 = Math.Sqrt(-2 * Math.Log(u1)) * Math.Cos(2 * Math.PI * u2)
                Dim z1 = Math.Sqrt(-2 * Math.Log(u1)) * Math.Sin(2 * Math.PI * u2)
                Dim z2 = Math.Sqrt(-2 * Math.Log(u1)) * Math.Sin(2 * Math.PI * u3)

                dataPoints.Add(New NPointDataPoint(z0, z1, z2))
            Next
        End Sub

        Private Sub OnAxesRoundToTickCheckedChanged(ByVal arg As NValueChangeEventArgs)
            For i = 0 To m_Chart.Axes.Count - 1
                Dim linearScale As NLinearScale = TryCast(m_Chart.Axes(i).Scale, NLinearScale)

                If linearScale IsNot Nothing Then
                    If TryCast(arg.TargetNode, NCheckBox).Checked Then
                        linearScale.ViewRangeInflateMode = ENScaleViewRangeInflateMode.MajorTick
                        linearScale.InflateViewRangeBegin = True
                        linearScale.InflateViewRangeEnd = True
                    Else
                        linearScale.ViewRangeInflateMode = ENScaleViewRangeInflateMode.Logical
                    End If
                End If
            Next
        End Sub

        Private Sub OnInflateMarginsCheckBoxCheckedChanged(ByVal arg As NValueChangeEventArgs)
            m_Point.InflateMargins = TryCast(arg.TargetNode, NCheckBox).Checked
        End Sub

#End Region

#Region "Fields"

        Private m_Point As NPointSeries
        Private m_Chart As NCartesianChart

#End Region

#Region "Schema"

        Public Shared ReadOnly NXYZScatterPointExampleSchema As NSchema

        Private Class CSharpImpl
            <Obsolete("Please refactor calling code to use normal Visual Basic assignment")>
            Shared Function __Assign(Of T)(ByRef target As T, value As T) As T
                target = value
                Return value
            End Function
        End Class

#End Region
    End Class
End Namespace

Imports System
Imports Nevron.Nov.Chart
Imports Nevron.Nov.Dom
Imports Nevron.Nov.Graphics
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.Chart
    ''' <summary>
    ''' Line Labels Example
    ''' </summary>
    Public Class NLineLabelsExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' Default constructor
        ''' </summary>
        Public Sub New()
        End Sub
        ''' <summary>
        ''' Static constructor
        ''' </summary>
        Shared Sub New()
            NLineLabelsExampleSchema = NSchema.Create(GetType(NLineLabelsExample), NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            Dim chartView As NChartView = CreateCartesianChartView()

            ' configure title
            chartView.Surface.Titles(0).Text = "Line Labels"

            ' configure chart
            m_Chart = CType(chartView.Surface.Charts(0), NCartesianChart)
            m_Chart.SetPredefinedCartesianAxes(ENPredefinedCartesianAxis.XOrdinalYLinear)

            ' configure Y axis
            Dim scaleY = CType(m_Chart.Axes(ENCartesianAxis.PrimaryY).Scale, NLinearScale)
            scaleY.MajorGridLines.Stroke.DashStyle = ENDashStyle.Dot

            ' add interlaced stripe for Y axis
            Dim strip As NScaleStrip = New NScaleStrip(New NColorFill(NColor.Beige), Nothing, True, 0, 0, 1, 1)
            strip.Interlaced = True
            scaleY.Strips.Add(strip)

            ' line series
            m_Line = New NLineSeries()
            m_Chart.Series.Add(m_Line)
            m_Line.InflateMargins = True
            Dim markerStyle As NMarkerStyle = New NMarkerStyle()
            markerStyle.Visible = True
            markerStyle.Fill = New NColorFill(NColor.DarkOrange)
            markerStyle.Shape = ENPointShape.Ellipse
            markerStyle.Size = New NSize(2, 2)
            m_Line.MarkerStyle = markerStyle
            m_Line.ValueFormatter = New NNumericValueFormatter("0.000")
            Dim dataLabelStyle As NDataLabelStyle = New NDataLabelStyle()
            dataLabelStyle.Visible = True
            dataLabelStyle.VertAlign = ENVerticalAlignment.Top
            dataLabelStyle.ArrowLength = 10
            dataLabelStyle.ArrowStroke = New NStroke(NColor.DarkOrange)
            dataLabelStyle.TextStyle.Background.Border = New NStroke(NColor.DarkOrange)
            dataLabelStyle.Format = "<value>"
            m_Chart.LabelLayout.EnableInitialPositioning = True
            m_Chart.LabelLayout.EnableLabelAdjustment = True
            m_Line.LabelLayout.EnableDataPointSafeguard = True
            m_Line.LabelLayout.DataPointSafeguardSize = New NSize(2, 2)
            m_Line.LabelLayout.UseLabelLocations = True
            m_Line.LabelLayout.OutOfBoundsLocationMode = ENOutOfBoundsLocationMode.PushWithinBounds
            m_Line.LabelLayout.InvertLocationsIfIgnored = True

            ' fill with random data
            OnGenerateDataButtonClick(Nothing)
            Return chartView
        End Function

        Protected Overrides Function CreateExampleControls() As NWidget
            Dim stack As NStackPanel = New NStackPanel()
            Dim boxGroup As NUniSizeBoxGroup = New NUniSizeBoxGroup(stack)
            Dim enableInitialPositioningCheckBox As NCheckBox = New NCheckBox("Enable Initial Positioning")
            AddHandler enableInitialPositioningCheckBox.CheckedChanged, New [Function](Of NValueChangeEventArgs)(AddressOf OnEnableInitialPositioningCheckBoxCheckedChanged)
            stack.Add(enableInitialPositioningCheckBox)
            Dim enableLabelAdjustmentCheckBox As NCheckBox = New NCheckBox("Enable Label Adjustment")
            AddHandler enableLabelAdjustmentCheckBox.CheckedChanged, New [Function](Of NValueChangeEventArgs)(AddressOf OnEnableLabelAdjustmentCheckBoxCheckedChanged)
            stack.Add(enableLabelAdjustmentCheckBox)
            Dim generateDataButton As NButton = New NButton("Generate Data")
            AddHandler generateDataButton.Click, New [Function](Of NEventArgs)(AddressOf OnGenerateDataButtonClick)
            stack.Add(generateDataButton)
            enableInitialPositioningCheckBox.Checked = True
            enableLabelAdjustmentCheckBox.Checked = True
            Return boxGroup
        End Function

        Protected Overrides Function GetExampleDescription() As String
            Return "<p>This example demonstrates how automatic data label layout works with line data labels.</p>"
        End Function

#End Region

#Region "Event Handlers"

        Private Sub OnEnableLabelAdjustmentCheckBoxCheckedChanged(ByVal arg As NValueChangeEventArgs)
            m_Chart.LabelLayout.EnableLabelAdjustment = CType(arg.TargetNode, NCheckBox).Checked
        End Sub

        Private Sub OnEnableInitialPositioningCheckBoxCheckedChanged(ByVal arg As NValueChangeEventArgs)
            m_Chart.LabelLayout.EnableInitialPositioning = CType(arg.TargetNode, NCheckBox).Checked
        End Sub

        Private Sub OnGenerateDataButtonClick(ByVal arg As NEventArgs)
            m_Line.DataPoints.Clear()
            Dim random As Random = New Random()

            For i = 0 To 30 - 1
                Dim value As Double = Math.Sin(i * 0.2) * 10 + random.NextDouble() * 2
                m_Line.DataPoints.Add(New NLineDataPoint(value))
            Next
        End Sub

#End Region

#Region "Fields"

        Private m_Chart As NCartesianChart
        Private m_Line As NLineSeries

#End Region

#Region "Schema"

        Public Shared ReadOnly NLineLabelsExampleSchema As NSchema

#End Region

#Region "Static Methods"

        Private Shared Function CreateCartesianChartView() As NChartView
            Dim chartView As NChartView = New NChartView()
            chartView.Surface.CreatePredefinedChart(ENPredefinedChartType.Cartesian)
            Return chartView
        End Function

#End Region
    End Class
End Namespace

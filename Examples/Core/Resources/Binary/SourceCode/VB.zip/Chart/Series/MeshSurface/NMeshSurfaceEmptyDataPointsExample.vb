Imports Nevron.Nov.Chart
Imports Nevron.Nov.Chart.Tools
Imports Nevron.Nov.Dom
Imports Nevron.Nov.Graphics
Imports Nevron.Nov.UI
Imports System

Namespace Nevron.Nov.Examples.Chart
    ''' <summary>
    ''' Mesh Surface Example
    ''' </summary>
    Public Class NMeshSurfaceEmptyDataPointsExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' Default constructor
        ''' </summary>
        Public Sub New()

        End Sub
        ''' <summary>
        ''' Static constructor
        ''' </summary>
        Shared Sub New()
            NMeshSurfaceEmptyDataPointsExampleSchema = NSchema.Create(GetType(NMeshSurfaceEmptyDataPointsExample), NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            Dim chartViewWithCommandBars As NChartViewWithCommandBars = New NChartViewWithCommandBars()
            Dim chartView = chartViewWithCommandBars.View
            chartView.Surface.CreatePredefinedChart(ENPredefinedChartType.Cartesian)

            ' configure title
            chartView.Surface.Titles(0).Text = "Mesh Surface Chart"

            ' setup chart
            Dim chart = CType(chartView.Surface.Charts(0), NCartesianChart)
            m_Chart = chart

            chart.Enable3D = True
            chart.ModelWidth = 60.0F
            chart.ModelDepth = 60.0F
            chart.ModelHeight = 25.0F
            chart.Projection.SetPredefinedProjection(ENPredefinedProjection.PerspectiveTilted)
            chart.LightModel.SetPredefinedLightModel(ENPredefinedLightModel.SoftTopLeft)
            chart.Interactor = New NInteractor(New NTrackballTool())

            Dim scale As NLinearScale = chart.Axes(ENCartesianAxis.PrimaryY).Scale
            scale.ViewRangeInflateMode = ENScaleViewRangeInflateMode.None

            ' setup axes
            Dim scaleX As NLinearScale = New NLinearScale()
            chart.Axes(ENCartesianAxis.PrimaryX).Scale = scaleX
            scaleX.MajorGridLines.SetShowAtWall(ENChartWall.Bottom, True)
            scaleX.MajorGridLines.SetShowAtWall(ENChartWall.Back, True)

            Dim scaleZ As NLinearScale = New NLinearScale()
            chart.Axes(ENCartesianAxis.Depth).Scale = scaleZ
            scaleZ.MajorGridLines.SetShowAtWall(ENChartWall.Bottom, True)
            scaleZ.MajorGridLines.SetShowAtWall(ENChartWall.Left, True)

            ' add the surface series
            m_Surface = New NMeshSurfaceSeries()
            chart.Series.Add(m_Surface)

            m_Surface.Name = "Surface"
            m_Surface.LegendView.Mode = ENSeriesLegendMode.SeriesLogic
            m_Surface.FillMode = ENSurfaceFillMode.Zone
            m_Surface.FlatPositionValue = 0.5
            m_Surface.Data.SetGridSize(20, 20)
            m_Surface.Fill = New NColorFill(NColor.YellowGreen)

            FillData(m_Surface)

            Return chartViewWithCommandBars
        End Function

        Private Sub FillData(ByVal surface As NMeshSurfaceSeries)
            Dim x, y, z As Double
            Dim nCountX = surface.Data.GridSizeX
            Dim nCountZ = surface.Data.GridSizeZ

            Const dIntervalX = 8.0
            Const dIntervalZ = 8.0
            Dim dIncrementX = dIntervalX / nCountX
            Dim dIncrementZ = dIntervalZ / nCountZ

            For j = 0 To nCountZ - 1
                For i = 0 To nCountX - 1
                    x = -(dIntervalX / 2) + i * dIncrementX
                    z = -(dIntervalZ / 2) + j * dIncrementZ

                    y = Math.Log(Math.Abs(x) * Math.Abs(z))

                    x += Math.Sin(j / 2.0) / 2.2
                    z += Math.Cos(i / 2.0) / 2.2

                    If y > -7 Then
                        surface.Data.SetValue(i, j, y, x, z)
                    Else
                        surface.Data.SetValue(i, j, DBNull.Value, DBNull.Value, DBNull.Value)
                    End If
                Next
            Next
        End Sub

        Protected Overrides Function CreateExampleControls() As NWidget
            Dim stack As NStackPanel = New NStackPanel()
            Dim group As NUniSizeBoxGroup = New NUniSizeBoxGroup(stack)

            Dim smoothShadingCheckBox As NCheckBox = New NCheckBox()
            smoothShadingCheckBox.CheckedChanged += AddressOf OnSmoothShadingCheckBoxCheckedChanged
            smoothShadingCheckBox.Checked = False
            smoothShadingCheckBox.HorizontalPlacement = Layout.ENHorizontalPlacement.Left
            stack.Add(NPairBox.Create("Smooth Shading:", smoothShadingCheckBox))

            Return group
        End Function

        Private Sub OnSmoothShadingCheckBoxCheckedChanged(ByVal arg As NValueChangeEventArgs)
            m_Surface.ShadingMode = If(arg.NewValue, ENShadingMode.Smooth, ENShadingMode.Flat)
        End Sub

        Protected Overrides Function GetExampleDescription() As String
            Return "<p>This example demonstrates the mesh surface support for Empty Data Points.</p>"
        End Function

#End Region

#Region "Fields"

        Private m_Chart As NChart
        Private m_Surface As NMeshSurfaceSeries

#End Region

#Region "Schema"

        Public Shared ReadOnly NMeshSurfaceEmptyDataPointsExampleSchema As NSchema

#End Region
    End Class
End Namespace

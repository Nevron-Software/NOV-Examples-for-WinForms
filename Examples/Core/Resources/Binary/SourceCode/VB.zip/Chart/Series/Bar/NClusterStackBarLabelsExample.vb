Imports System

Imports Nevron.Nov.Chart
Imports Nevron.Nov.Dom
Imports Nevron.Nov.Graphics
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.Chart
    ''' <summary>
    ''' Cluster Stack Bar Labels Example
    ''' </summary>
    Public Class NClusterStackBarLabelsExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' Default constructor
        ''' </summary>
        Public Sub New()

        End Sub
        ''' <summary>
        ''' Static constructor
        ''' </summary>
        Shared Sub New()
            NClusterStackBarLabelsExampleSchema = NSchema.Create(GetType(NClusterStackBarLabelsExample), NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            Dim chartViewWithCommandBars As NChartViewWithCommandBars = New NChartViewWithCommandBars()
            Dim chartView = chartViewWithCommandBars.View
            chartView.Surface.CreatePredefinedChart(ENPredefinedChartType.Cartesian)

            ' configure title
            chartView.Surface.Titles(0).Text = "Cluster Stack Bar Labels"

            ' configure chart
            m_Chart = CType(chartView.Surface.Charts(0), NCartesianChart)

            m_Chart.SetPredefinedCartesianAxes(ENPredefinedCartesianAxis.XOrdinalYLinear)

            ' configure Y axis
            Dim scaleY As NLinearScale = New NLinearScale()
            scaleY.MajorGridLines.Stroke.DashStyle = ENDashStyle.Dash
            m_Chart.Axes(ENCartesianAxis.PrimaryY).Scale = scaleY

            ' add interlaced stripe for Y axis
            Dim stripStyle As NScaleStrip = New NScaleStrip(New NColorFill(NColor.Beige), Nothing, True, 0, 0, 1, 1)
            stripStyle.Interlaced = True
            scaleY.Strips.Add(stripStyle)

            Dim dataPointSafeguardSize As NSize = New NSize(2, 2)

            ' series 1
            m_Bar1 = New NBarSeries()
            m_Chart.Series.Add(m_Bar1)
            m_Bar1.Name = "Bar 1"
            m_Bar1.Fill = New NColorFill(NColor.DarkOrange)
            m_Bar1.DataLabelStyle = CreateDataLabelStyle(ENVerticalAlignment.Center)

            ' series 2
            m_Bar2 = New NBarSeries()
            m_Chart.Series.Add(m_Bar2)
            m_Bar2.Name = "Bar 2"
            m_Bar2.MultiBarMode = ENMultiBarMode.Stacked
            m_Bar2.Fill = New NColorFill(NColor.OrangeRed)
            m_Bar2.DataLabelStyle = CreateDataLabelStyle(ENVerticalAlignment.Center)

            ' series 3
            m_Bar3 = New NBarSeries()
            m_Chart.Series.Add(m_Bar3)
            m_Bar3.Name = "Bar 3"
            m_Bar3.MultiBarMode = ENMultiBarMode.Clustered
            m_Bar3.Fill = New NColorFill(NColor.LightGreen)
            m_Bar3.DataLabelStyle = CreateDataLabelStyle(ENVerticalAlignment.Top)

            ' enable initial labels positioning
            m_Chart.LabelLayout.EnableInitialPositioning = True

            ' enable label adjustment
            m_Chart.LabelLayout.EnableLabelAdjustment = True

            ' series 1 data points must not be overlapped
            m_Bar1.LabelLayout.EnableDataPointSafeguard = True
            m_Bar1.LabelLayout.DataPointSafeguardSize = dataPointSafeguardSize

            ' do not use label location proposals for series 1
            m_Bar1.LabelLayout.UseLabelLocations = False

            ' series 2 data points must not be overlapped
            m_Bar2.LabelLayout.EnableDataPointSafeguard = True
            m_Bar2.LabelLayout.DataPointSafeguardSize = dataPointSafeguardSize

            ' do not use label location proposals for series 2
            m_Bar2.LabelLayout.UseLabelLocations = False

            ' series 3 data points must not be overlapped
            m_Bar3.LabelLayout.EnableDataPointSafeguard = True
            m_Bar3.LabelLayout.DataPointSafeguardSize = dataPointSafeguardSize

            ' series 3 data labels can be placed above and below the origin point
            m_Bar3.LabelLayout.UseLabelLocations = True
            m_Bar3.LabelLayout.LabelLocations = New NDomArray(Of ENLabelLocation)(New ENLabelLocation() {ENLabelLocation.Top, ENLabelLocation.Bottom})
            m_Bar3.LabelLayout.InvertLocationsIfIgnored = False
            m_Bar3.LabelLayout.OutOfBoundsLocationMode = ENOutOfBoundsLocationMode.PushWithinBounds

            ' fill with random data
            OnGenerateDataButtonClick(Nothing)

            Return chartViewWithCommandBars
        End Function
        Protected Overrides Function CreateExampleControls() As NWidget
            Dim stack As NStackPanel = New NStackPanel()
            Dim boxGroup As NUniSizeBoxGroup = New NUniSizeBoxGroup(stack)

            m_EnableInitialPositioningCheckBox = New NCheckBox("Enable Initial Positioning")
            m_EnableInitialPositioningCheckBox.CheckedChanged += New [Function](Of NValueChangeEventArgs)(AddressOf OnEnableInitialPositioningCheckBoxCheckedChanged)
            stack.Add(m_EnableInitialPositioningCheckBox)

            m_EnableLabelAdjustmentCheckBox = New NCheckBox("Enable Label Adjustment")
            m_EnableLabelAdjustmentCheckBox.CheckedChanged += New [Function](Of NValueChangeEventArgs)(AddressOf OnEnableLabelAdjustmentCheckBoxCheckedChanged)
            stack.Add(m_EnableLabelAdjustmentCheckBox)

            Dim generateDataButton As NButton = New NButton("Generate Data")
            generateDataButton.Click += New [Function](Of NEventArgs)(AddressOf OnGenerateDataButtonClick)
            stack.Add(generateDataButton)

            m_EnableInitialPositioningCheckBox.Checked = True
            m_EnableLabelAdjustmentCheckBox.Checked = True

            Return boxGroup
        End Function
        Protected Overrides Function GetExampleDescription() As String
            Return "<p>This example demonstrates how automatic data label layout works with cluster stack bar labels.</p>"
        End Function

#End Region

#Region "Event Handlers"

        Private Sub OnEnableLabelAdjustmentCheckBoxCheckedChanged(ByVal arg As NValueChangeEventArgs)
            m_Chart.LabelLayout.EnableLabelAdjustment = m_EnableLabelAdjustmentCheckBox.Checked
        End Sub

        Private Sub OnEnableInitialPositioningCheckBoxCheckedChanged(ByVal arg As NValueChangeEventArgs)
            m_Chart.LabelLayout.EnableInitialPositioning = m_EnableInitialPositioningCheckBox.Checked
        End Sub

        Private Sub OnGenerateDataButtonClick(ByVal arg As NEventArgs)
            m_Bar1.DataPoints.Clear()
            m_Bar2.DataPoints.Clear()
            m_Bar3.DataPoints.Clear()

            Dim random As Random = New Random()
            For i = 0 To 9
                m_Bar1.DataPoints.Add(New NBarDataPoint(random.Next(5, 20)))
                m_Bar2.DataPoints.Add(New NBarDataPoint(random.Next(5, 20)))
                m_Bar3.DataPoints.Add(New NBarDataPoint(random.Next(5, 20)))
            Next
        End Sub

#End Region

#Region "Implementation"

        Private Function CreateDataLabelStyle(ByVal vertAlign As ENVerticalAlignment) As NDataLabelStyle
            Dim dataLabelStyle As NDataLabelStyle = New NDataLabelStyle()

            dataLabelStyle.Visible = True
            dataLabelStyle.VertAlign = ENVerticalAlignment.Top
            dataLabelStyle.ArrowLength = 20
            dataLabelStyle.Format = "<value>"

            Return dataLabelStyle

        End Function

#End Region

#Region "Fields"

        Private m_Chart As NCartesianChart
        Private m_Bar1 As NBarSeries
        Private m_Bar2 As NBarSeries
        Private m_Bar3 As NBarSeries

        Private m_EnableInitialPositioningCheckBox As NCheckBox
        Private m_EnableLabelAdjustmentCheckBox As NCheckBox

#End Region

#Region "Schema"

        Public Shared ReadOnly NClusterStackBarLabelsExampleSchema As NSchema

#End Region
    End Class
End Namespace

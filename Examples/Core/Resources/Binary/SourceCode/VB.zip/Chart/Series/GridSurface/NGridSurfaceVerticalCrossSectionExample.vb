Imports System
Imports System.IO

Imports Nevron.Nov.Chart
Imports Nevron.Nov.Chart.Tools
Imports Nevron.Nov.DataStructures
Imports Nevron.Nov.Dom
Imports Nevron.Nov.Graphics
Imports Nevron.Nov.Layout
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.Chart
    ''' <summary>
    ''' Grid Surface Vertical Cross Section Example
    ''' </summary>
    Public Class NGridSurfaceVerticalCrossSectionExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' Default constructor
        ''' </summary>
        Public Sub New()

        End Sub
        ''' <summary>
        ''' Static constructor
        ''' </summary>
        Shared Sub New()
            NGridSurfaceVerticalCrossSectionExampleSchema = NSchema.Create(GetType(NGridSurfaceVerticalCrossSectionExample), NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            Dim chartViewWithCommandBars As NChartViewWithCommandBars = New NChartViewWithCommandBars()
            Dim chartView = chartViewWithCommandBars.View

            ' configure title
            chartView.Surface.Titles(0).Text = "Grid Surface Series Vertical Cross Section"

            Dim dockPanel As NDockPanel = New NDockPanel()
            chartView.Surface.Content = dockPanel

            Dim label As NLabel = New NLabel()
            label.Margins = New NMargins(10, 10, 10, 10)
            label.Font = New NFont(NFontDescriptor.DefaultSansFamilyName, 12)
            label.TextFill = New NColorFill(NColor.Black)
            label.TextAlignment = ENContentAlignment.MiddleCenter
            NDockLayout.SetDockArea(label, ENDockArea.Top)
            dockPanel.AddChild(label)

            ' configure the chart
            Dim crossSectionChart As NCartesianChart = New NCartesianChart()
            crossSectionChart.PreferredHeight = 200
            crossSectionChart.Margins = New NMargins(10, 0, 0, 10)
            NDockLayout.SetDockArea(crossSectionChart, ENDockArea.Bottom)

            crossSectionChart.FitMode = ENCartesianChartFitMode.Stretch
            crossSectionChart.Margins = New NMargins(0, 10, 0, 0)

            crossSectionChart.Axes(ENCartesianAxis.PrimaryX).Scale = New NLinearScale()
            crossSectionChart.Axes(ENCartesianAxis.PrimaryX).Scale.Title.Text = "Distance"
            crossSectionChart.Axes(ENCartesianAxis.PrimaryY).Scale.Title.Text = "Value"

            m_CrossSection2DSeries = New NLineSeries()
            m_CrossSection2DSeries.DataLabelStyle = New NDataLabelStyle(False)
            m_CrossSection2DSeries.UseXValues = True

            crossSectionChart.Series.Add(m_CrossSection2DSeries)

            dockPanel.AddChild(crossSectionChart)

            ' Configure surface chart
            Dim surfaceChart As NCartesianChart = New NCartesianChart()
            dockPanel.AddChild(surfaceChart)
            surfaceChart.Margins = New NMargins(10, 0, 0, 10)
            NDockLayout.SetDockArea(surfaceChart, ENDockArea.Center)

            surfaceChart.Enable3D = True
            surfaceChart.ModelWidth = 60.0F
            surfaceChart.ModelDepth = 60.0F
            surfaceChart.ModelHeight = 15.0F
            surfaceChart.FitMode = ENCartesianChartFitMode.Aspect
            surfaceChart.Projection.SetPredefinedProjection(ENPredefinedProjection.PerspectiveTilted)
            surfaceChart.Projection.Elevation = 22
            surfaceChart.Projection.Rotation = -68
            surfaceChart.LightModel.SetPredefinedLightModel(ENPredefinedLightModel.ShinyTopLeft)

            ' setup axes
            Dim ordinalScale As NOrdinalScale = surfaceChart.Axes(ENCartesianAxis.PrimaryX).Scale
            ordinalScale.MajorGridLines.SetShowAtWall(ENChartWall.Bottom, True)
            ordinalScale.MajorGridLines.SetShowAtWall(ENChartWall.Back, True)
            ordinalScale.DisplayDataPointsBetweenTicks = False

            ordinalScale = surfaceChart.Axes(ENCartesianAxis.Depth).Scale
            ordinalScale.MajorGridLines.SetShowAtWall(ENChartWall.Bottom, True)
            ordinalScale.MajorGridLines.SetShowAtWall(ENChartWall.Left, True)
            ordinalScale.DisplayDataPointsBetweenTicks = False

            ' add the surface series
            m_SurfaceSeries = New NGridSurfaceSeries()
            surfaceChart.Series.Add(m_SurfaceSeries)
            m_SurfaceSeries.Name = "Surface"
            m_SurfaceSeries.LegendView.Mode = ENSeriesLegendMode.SeriesLogic
            m_SurfaceSeries.FlatPositionValue = 10.0
            m_SurfaceSeries.Data.SetGridSize(1000, 1000)
            m_SurfaceSeries.Fill = New NColorFill(NColor.YellowGreen)
            m_SurfaceSeries.ShadingMode = ENShadingMode.Smooth
            m_SurfaceSeries.FrameMode = ENSurfaceFrameMode.None
            m_SurfaceSeries.FillMode = ENSurfaceFillMode.Zone

            ' add the cross section line series
            m_CrossSection3DSeries = New NPointSeries()
            surfaceChart.Series.Add(m_CrossSection3DSeries)
            m_CrossSection3DSeries.Size = 10
            m_CrossSection3DSeries.Shape = ENPointShape3D.Sphere
            m_CrossSection3DSeries.Fill = New NColorFill(NColor.Red)
            m_CrossSection3DSeries.DataLabelStyle = New NDataLabelStyle(False)
            m_CrossSection3DSeries.UseXValues = True
            m_CrossSection3DSeries.UseZValues = True

            FillData(m_SurfaceSeries)

            Dim xAxesRange As NRange = New NRange(0, m_SurfaceSeries.Data.GridSizeX)
            Dim yAxesRange As NRange = New NRange(0, 400)
            Dim zAxesRange As NRange = New NRange(0, m_SurfaceSeries.Data.GridSizeZ)

            m_DragPlane = New NDragPlane(surfaceChart, New NVector3DD(0, yAxesRange.End, 0), New NVector3DD(xAxesRange.End, yAxesRange.End, zAxesRange.End), New NVector3DD(xAxesRange.End, 0, zAxesRange.End), New NVector3DD(0, 0, 0))

            Me.m_DragPlane.DragPlaneChanged += AddressOf OnDragPlaneDragPlaneChanged

            m_DragPlaneTool = New NDragPlaneTool(m_DragPlane)
            surfaceChart.Interactor = New NInteractor(New NTool() {m_DragPlaneTool, New NTrackballTool()})

            ' enable fixed Axes ranges
            surfaceChart.Axes(ENCartesianAxis.PrimaryX).SetFixedViewRange(xAxesRange)
            surfaceChart.Axes(ENCartesianAxis.PrimaryY).SetFixedViewRange(yAxesRange)
            surfaceChart.Axes(ENCartesianAxis.Depth).SetFixedViewRange(zAxesRange)

            ' turn off plot box clipping
            surfaceChart.Axes(ENCartesianAxis.PrimaryX).ClipMode = ENAxisClipMode.Never
            surfaceChart.Axes(ENCartesianAxis.PrimaryY).ClipMode = ENAxisClipMode.Never
            surfaceChart.Axes(ENCartesianAxis.Depth).ClipMode = ENAxisClipMode.Never

            OnDragPlaneDragPlaneChanged(Nothing, Nothing)

            Return chartViewWithCommandBars
        End Function

        Private Sub FillData(ByVal surface As NGridSurfaceSeries)
            Dim stream As Stream = Nothing
            Dim reader As BinaryReader = Nothing

            Try
                ' fill the XYZ data from a binary resource
                stream = New MemoryStream(NResources.RBIN_SampleData_DataY_bin.Data)
                reader = New BinaryReader(stream)

                Dim dataPointsCount As Integer = stream.Length / 4
                Dim sizeX As Integer = Math.Sqrt(dataPointsCount)
                Dim sizeZ = sizeX

                surface.Data.SetGridSize(sizeX, sizeZ)

                For z = 0 To sizeZ - 1
                    For x = 0 To sizeX - 1
                        surface.Data.SetValue(x, z, reader.ReadSingle())
                    Next
                Next

            Finally
                If reader IsNot Nothing Then reader.Close()

                If stream IsNot Nothing Then stream.Close()
            End Try
        End Sub

        Protected Overrides Function CreateExampleControls() As NWidget
            Dim stack As NStackPanel = New NStackPanel()
            Dim group As NUniSizeBoxGroup = New NUniSizeBoxGroup(stack)

            m_DragPlaneComboBox = New NComboBox()
            stack.Add(NPairBox.Create("Drag Plane:", m_DragPlaneComboBox))

            m_DragPlaneComboBox.FillFromEnum(Of DragPlaneSurface)()
            Me.m_DragPlaneComboBox.SelectedIndexChanged += AddressOf OnDragPlaneComboBoxSelectedIndexChanged
            m_DragPlaneComboBox.SelectedIndex = CInt(DragPlaneSurface.XZ)

            Return group
        End Function

        Protected Overrides Function GetExampleDescription() As String
            Return "<p>The example demonstrates how to get the cross section of a grid surface given begin and end point on the XY grid. Press the mouse over the red or blue surface end points and begin to drag. On the right side you can control the plane in which the point dragging occurs.</p>"
        End Function

#End Region

#Region "Events"

        ''' <summary>
        ''' 
        ''' </summary>
        ''' <paramname="sender"></param>
        ''' <paramname="e"></param>
        Private Sub OnDragPlaneDragPlaneChanged(ByVal sender As Object, ByVal e As EventArgs)
            Dim intersections3D As NList(Of NVector3DD) = m_SurfaceSeries.Get3DIntersections(New NPoint(m_DragPlane.PointA.X, m_DragPlane.PointA.Z), New NPoint(m_DragPlane.PointB.X, m_DragPlane.PointB.Z))
            Dim intersections2D As NList(Of NVector2DD) = m_SurfaceSeries.Get2DIntersections(New NPoint(m_DragPlane.PointA.X, m_DragPlane.PointA.Z), New NPoint(m_DragPlane.PointB.X, m_DragPlane.PointB.Z))

            m_CrossSection3DSeries.DataPoints.Clear()

            For i = 0 To intersections3D.Count - 1
                Dim intersection3D = intersections3D(i)

                m_CrossSection3DSeries.DataPoints.Add(New NPointDataPoint(intersection3D.X, intersection3D.Z + 1, intersection3D.Y))
            Next

            m_CrossSection2DSeries.DataPoints.Clear()

            For i = 0 To intersections2D.Count - 1
                Dim intersection2D = intersections2D(i)

                m_CrossSection2DSeries.DataPoints.Add(New NLineDataPoint(intersection2D.X, intersection2D.Y))
            Next

        End Sub
        ''' <summary>
        ''' 
        ''' </summary>
        ''' <paramname="arg"></param>
        Private Sub OnDragPlaneComboBoxSelectedIndexChanged(ByVal arg As NValueChangeEventArgs)
            m_DragPlaneTool.DragPlaneSurface = CType(arg.NewValue, DragPlaneSurface)
        End Sub

#End Region

#Region "Fields"

        Private m_DragPlane As NDragPlane
        Private m_CrossSection3DSeries As NPointSeries
        Private m_CrossSection2DSeries As NLineSeries
        Private m_SurfaceSeries As NGridSurfaceSeries
        Private m_DragPlaneTool As NDragPlaneTool

        Private m_DragPlaneComboBox As NComboBox

#End Region

#Region "Schema"

        Public Shared ReadOnly NGridSurfaceVerticalCrossSectionExampleSchema As NSchema

#End Region
    End Class
End Namespace

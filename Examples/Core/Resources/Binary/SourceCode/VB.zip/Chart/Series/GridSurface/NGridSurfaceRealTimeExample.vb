Imports System

Imports Nevron.Nov.Chart
Imports Nevron.Nov.Chart.Tools
Imports Nevron.Nov.Dom
Imports Nevron.Nov.Graphics
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.Chart
    ''' <summary>
    ''' Grid Surface Projected Contour Example
    ''' </summary>
    Public Class NGridSurfaceRealTimeExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' Default constructor
        ''' </summary>
        Public Sub New()

        End Sub
        ''' <summary>
        ''' Static constructor
        ''' </summary>
        Shared Sub New()
            NGridSurfaceRealTimeExampleSchema = NSchema.Create(GetType(NGridSurfaceRealTimeExample), NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        ''' <summary>
        ''' 
        ''' </summary>
        ''' <returns></returns>
        Protected Overrides Function CreateExampleContent() As NWidget
            Dim chartViewWithCommandBars As NChartViewWithCommandBars = New NChartViewWithCommandBars()
            Dim chartView = chartViewWithCommandBars.View
            chartView.Surface.CreatePredefinedChart(ENPredefinedChartType.Cartesian)

            chartView.Registered += AddressOf OnChartViewRegistered
            chartView.Unregistered += AddressOf OnChartViewUnregistered

            ' configure title
            chartView.Surface.Titles(0).Text = "Realtime Grid Surface"

            ' setup chart
            Dim chart = CType(chartView.Surface.Charts(0), NCartesianChart)
            chart.Enable3D = True
            chart.ModelWidth = 55.0F
            chart.ModelDepth = 55.0F
            chart.ModelHeight = 45.0F
            chart.Projection.SetPredefinedProjection(ENPredefinedProjection.PerspectiveTilted)
            chart.LightModel.SetPredefinedLightModel(ENPredefinedLightModel.ShinyTopLeft)
            chart.Interactor = New NInteractor(New NTrackballTool())

            ' add a surface series
            m_Surface = New NGridSurfaceSeries()
            chart.Series.Add(m_Surface)
            m_Surface.Name = "Surface"
            m_Surface.LegendView.Mode = ENSeriesLegendMode.None
            m_Surface.Fill = New NColorFill(NColor.FromRGB(160, 170, 212))
            m_Surface.FillMode = ENSurfaceFillMode.Uniform
            m_Surface.FrameMode = ENSurfaceFrameMode.None
            m_Surface.CellTriangulationMode = ENSurfaceCellTriangulationMode.Diagonal1
            m_Surface.Data.SetGridSize(500, 500)
            SetupCommonSurfaceProperties(m_Surface)

            ' setup axes
            chart.Axes(ENCartesianAxis.PrimaryY).ViewRangeMode = ENAxisViewRangeMode.FixedRange
            chart.Axes(ENCartesianAxis.PrimaryY).MinViewRangeValue = -3
            chart.Axes(ENCartesianAxis.PrimaryY).MaxViewRangeValue = 3

            Dim xScale As NOrdinalScale = chart.Axes(ENCartesianAxis.PrimaryX).Scale
            xScale.MajorGridLines.SetShowAtWall(ENChartWall.Bottom, True)
            xScale.MajorGridLines.SetShowAtWall(ENChartWall.Back, True)
            xScale.DisplayDataPointsBetweenTicks = False

            Dim zScale As NOrdinalScale = chart.Axes(ENCartesianAxis.Depth).Scale
            zScale.MajorGridLines.SetShowAtWall(ENChartWall.Bottom, True)
            zScale.MajorGridLines.SetShowAtWall(ENChartWall.Left, True)
            zScale.DisplayDataPointsBetweenTicks = False

            Return chartViewWithCommandBars
        End Function

        Private phase As Double = 0
        Private random As Random = New Random()

        Private Sub GenerateWaves()
            Dim surface = m_Surface

            Dim nCountX = surface.Data.GridSizeX
            Dim nCountZ = surface.Data.GridSizeZ

            Dim [step] = Math.PI * 10 / nCountX
                        ''' Cannot convert UnsafeStatementSyntax, CONVERSION ERROR: Conversion for UnsafeStatement not implemented, please report this issue in 'unsafe\r\n   {\r\n    fixed...' at character 4664
''' 
''' 
''' Input:
''' 
'''             unsafe
'''             {
'''                 fixed (byte* pData = &surface.Data.Data[0])
'''                 {
'''                     float* pValue = (float*)pData + 1;
'''                     int itemSize = surface.Data.DataItemSize;
''' 
'''                     double randomAmplitude = System.Math.Sin(this.phase) * 2 + this.random.NextDouble();
''' 
'''                     for (int z = 0; z < nCountZ; z++)
'''                     {
'''                         for (int x = 0; x < nCountX; x++)
'''                         {
'''                             float zVal = (float)(randomAmplitude * System.Math.Sin(this.phase + x * step) * System.Math.Cos(this.phase + z * step));
''' 
'''                             *pValue = zVal;
''' 
'''                             pValue += itemSize;
'''                         }
'''                     }
''' 
'''                     surface.Data.OnDataChanged();
'''                 }
'''             }
''' 
''' 

            phase += 3 * [step]
        End Sub

        Private Sub SetupCommonSurfaceProperties(ByVal surface As NGridSurfaceSeries)
            surface.Palette = New NRangeMultiColorPalette()
            surface.XValuesMode = ENGridSurfaceValuesMode.OriginAndStep
            surface.OriginX = -150
            surface.StepX = 10
            surface.ZValuesMode = ENGridSurfaceValuesMode.OriginAndStep
            surface.OriginZ = -150
            surface.StepZ = 10
        End Sub

        Protected Overrides Function CreateExampleControls() As NWidget
            Dim stack As NStackPanel = New NStackPanel()
            Dim group As NUniSizeBoxGroup = New NUniSizeBoxGroup(stack)

            Dim gridSizeComboBox As NComboBox = New NComboBox()
            gridSizeComboBox.Items.Add(New NComboBoxItem("250x250"))
            gridSizeComboBox.Items.Add(New NComboBoxItem("500x500"))
            gridSizeComboBox.Items.Add(New NComboBoxItem("1000x1000"))
            stack.Add(NPairBox.Create("Grid Size:", gridSizeComboBox))
            gridSizeComboBox.SelectedIndexChanged += AddressOf OnGridSizeComboBoxSelectedIndexChanged
            gridSizeComboBox.SelectedIndex = 1

            Dim enableShaderRenderingCheckBox As NCheckBox = New NCheckBox()
            stack.Add(NPairBox.Create("Enable Shader Rendering:", enableShaderRenderingCheckBox))
            enableShaderRenderingCheckBox.CheckedChanged += AddressOf OnEnableShaderRenderingCheckBoxCheckedChanged

            Dim toggleTimerButton As NButton = New NButton("Stop Timer")
            toggleTimerButton.Click += AddressOf OnToggleTimerButtonClick
            toggleTimerButton.Tag = 0
            stack.Add(toggleTimerButton)

            Return group
        End Function

        Protected Overrides Function GetExampleDescription() As String
            Return "<p>This example demonstrates the ability of the NGridSurfaceSeries to render large dynamically changing datasets with a minimal amount of CPU load. The example also shows how to efficiently fill data to the series.</p>"
        End Function

#End Region

#Region "Events"

        Private Sub OnChartViewRegistered(ByVal arg As NEventArgs)
            m_Timer = New NTimer()
            Me.m_Timer.Tick += AddressOf OnTimerTick
            m_Timer.Start()
        End Sub

        Private Sub OnChartViewUnregistered(ByVal arg As NEventArgs)
            m_Timer.Stop()
            Me.m_Timer.Tick -= AddressOf OnTimerTick
            m_Timer = Nothing
        End Sub

        Private Sub OnTimerTick()
            GenerateWaves()
        End Sub

        Private Sub OnEnableShaderRenderingCheckBoxCheckedChanged(ByVal arg As NValueChangeEventArgs)
            m_Surface.EnableShaderRendering = CBool(arg.NewValue)
        End Sub

        Private Sub OnGridSizeComboBoxSelectedIndexChanged(ByVal arg As NValueChangeEventArgs)
            Dim gridSize = 0
            Select Case arg.NewValue
                Case 0
                    gridSize = 250
                Case 1
                    gridSize = 500
                Case 2
                    gridSize = 1000
            End Select

            m_Surface.Data.SetSize(gridSize, gridSize)
            GenerateWaves()
        End Sub

        Private Sub OnToggleTimerButtonClick(ByVal arg As NEventArgs)
            Dim button = CType(arg.TargetNode, NButton)
            If CInt(button.Tag) = 0 Then
                m_Timer.Stop()

                button.Content = New NLabel("Start Timer")
                button.Tag = 1
            Else
                m_Timer.Start()
                button.Content = New NLabel("Stop Timer")
                button.Tag = 0
            End If
        End Sub

#End Region

#Region "Fields"

        Private m_Timer As NTimer
        Private m_Surface As NGridSurfaceSeries

#End Region

#Region "Schema"

        Public Shared ReadOnly NGridSurfaceRealTimeExampleSchema As NSchema

#End Region
    End Class
End Namespace

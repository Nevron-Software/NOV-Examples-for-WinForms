Imports Nevron.Nov.Chart
Imports Nevron.Nov.Chart.Tools
Imports Nevron.Nov.Dom
Imports Nevron.Nov.Graphics
Imports Nevron.Nov.UI
Imports System

Namespace Nevron.Nov.Examples.Chart
    ''' <summary>
    ''' Vertex Surface Example
    ''' </summary>
    Public Class NVertexSurfaceFrameCustomColorsExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' Default constructor
        ''' </summary>
        Public Sub New()

        End Sub
        ''' <summary>
        ''' Static constructor
        ''' </summary>
        Shared Sub New()
            NVertexSurfaceFrameCustomColorsExampleSchema = NSchema.Create(GetType(NVertexSurfaceFrameCustomColorsExample), NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            Dim chartViewWithCommandBars As NChartViewWithCommandBars = New NChartViewWithCommandBars()
            Dim chartView = chartViewWithCommandBars.View
            chartView.Surface.CreatePredefinedChart(ENPredefinedChartType.Cartesian)

            ' configure title
            chartView.Surface.Titles(0).Text = "Vertex Surface Series Line With Custom Colors"

            ' setup chart
            m_Chart = CType(chartView.Surface.Charts(0), NCartesianChart)
            m_Chart.Enable3D = True
            m_Chart.ModelWidth = 60.0F
            m_Chart.ModelDepth = 60.0F
            m_Chart.ModelHeight = 50.0F
            m_Chart.Projection.SetPredefinedProjection(ENPredefinedProjection.PerspectiveTilted)
            m_Chart.LightModel.SetPredefinedLightModel(ENPredefinedLightModel.SoftTopLeft)
            m_Chart.Interactor = New NInteractor(New NTrackballTool())

            ' setup axes
            Dim scaleY As NLinearScale = m_Chart.Axes(ENCartesianAxis.PrimaryY).Scale
            scaleY.ViewRangeInflateMode = ENScaleViewRangeInflateMode.None

            Dim scaleX As NLinearScale = New NLinearScale()
            scaleX.MajorGridLines.SetShowAtWall(ENChartWall.Bottom, True)
            scaleX.MajorGridLines.SetShowAtWall(ENChartWall.Back, True)
            scaleX.ViewRangeInflateMode = ENScaleViewRangeInflateMode.None
            m_Chart.Axes(ENCartesianAxis.PrimaryX).Scale = scaleX

            Dim scaleZ As NLinearScale = New NLinearScale()
            scaleZ.MajorGridLines.SetShowAtWall(ENChartWall.Bottom, True)
            scaleZ.MajorGridLines.SetShowAtWall(ENChartWall.Left, True)
            scaleZ.ViewRangeInflateMode = ENScaleViewRangeInflateMode.None
            m_Chart.Axes(ENCartesianAxis.Depth).Scale = scaleZ

            ' add the surface series
            m_Surface = New NVertexSurfaceSeries()
            m_Chart.Series.Add(m_Surface)

            m_Surface.Name = "Surface"
            m_Surface.LegendView.Mode = ENSeriesLegendMode.SeriesLogic
            m_Surface.FlatPositionValue = 10.0
            m_Surface.Palette.InterpolateColors = False
            m_Surface.ValueFormatter = New NNumericValueFormatter("0.00")
            m_Surface.FillMode = ENSurfaceFillMode.CustomColors
            m_Surface.FrameMode = ENSurfaceFrameMode.None
            m_Surface.VertexPrimitive = ENVertexPrimitive.Triangles
            m_Surface.Data.HasColor = True
            m_Surface.UseIndices = True

            Return chartViewWithCommandBars
        End Function
        Protected Overrides Function CreateExampleControls() As NWidget
            Dim stack As NStackPanel = New NStackPanel()
            Dim group As NUniSizeBoxGroup = New NUniSizeBoxGroup(stack)

            m_NumberOfLinesUpDown = New NNumericUpDown()
            m_NumberOfLinesUpDown.Minimum = 1
            m_NumberOfLinesUpDown.Maximum = 10
            Me.m_NumberOfLinesUpDown.ValueChanged += AddressOf OnNumberOfLinesUpDownValueChanged
            stack.Add(NPairBox.Create("Number of Lines:", m_NumberOfLinesUpDown))

            m_DataCountPerLineComboBox = New NComboBox()

            m_DataCountPerLineComboBox.Items.Add(New NComboBoxItem("10K"))
            m_DataCountPerLineComboBox.Items.Add(New NComboBoxItem("100K"))
            m_DataCountPerLineComboBox.Items.Add(New NComboBoxItem("500K"))

            Me.m_DataCountPerLineComboBox.SelectedIndexChanged += AddressOf OnDataCountPerLineComboBoxSelectedIndexChanged

            stack.Add(NPairBox.Create("Data Count Per Line:", m_DataCountPerLineComboBox))

            m_DataCountPerLineComboBox.SelectedIndex = 1
            m_NumberOfLinesUpDown.Value = 7

            Return group
        End Function

        Private Sub UpdateData()
            Dim dataPointCount = 0

            Select Case m_DataCountPerLineComboBox.SelectedIndex
                Case 0
                    dataPointCount = 10000
                Case 1
                    dataPointCount = 100000
                Case 2
                    dataPointCount = 500000
            End Select

            Dim lineCount As Integer = m_NumberOfLinesUpDown.Value
            m_Chart.Series.Clear()
            Dim random As Random = New Random()

            Dim palette = NChartPalette.GetColors(ENChartPalette.Fresh)

            For lineIndex = 0 To lineCount - 1
                ' setup surface series
                Dim surface As NVertexSurfaceSeries = New NVertexSurfaceSeries()
                m_Chart.Series.Add(surface)

                surface.Name = "Surface"
                surface.FillMode = ENSurfaceFillMode.CustomColors
                surface.FrameMode = ENSurfaceFrameMode.Dots
                surface.FrameColorMode = ENSurfaceFrameColorMode.CustomColors
                surface.VertexPrimitive = ENVertexPrimitive.LineStrip
                surface.Data.HasColor = True
                surface.Data.SetCapacity(dataPointCount)

                Dim x = 0.1
                Dim y As Double = 0
                Dim z As Double = 0
                Dim a = 10.0
                Dim b As Double = 18 + lineIndex ' 28.0 - ;
                Dim c = (lineIndex + 3) / 3.0 '8.0
                Dim t = lineIndex * (0.01 / lineCount) + 0.01

                Dim color1 = palette(lineIndex Mod palette.Length)
                Dim color2 = palette((lineIndex + 1) Mod palette.Length)
                                ''' Cannot convert UnsafeStatementSyntax, CONVERSION ERROR: Conversion for UnsafeStatement not implemented, please report this issue in 'unsafe\r\n    {\r\n     fix...' at character 7817
''' 
''' 
''' Input:
''' 
'''                 unsafe
'''                 {
'''                     fixed (byte* pData = &surface.Data.Data[0])
'''                     {
'''                         float* pVertex = (float*)pData;
'''                         uint* pColor = (uint*)(pData + surface.Data.ColorOffset * 4);
''' 
'''                         for (int dataPointIndex = 0; dataPointIndex < dataPointCount; dataPointIndex++)
'''                         {
'''                             float xt = (float)(x + t * a * (y - x));
'''                             float yt = (float)(y + t * (x * (b - z) - y));
'''                             float zt = (float)(z + t * (x * y - c * z));
''' 
'''                             pVertex[0] = xt;
'''                             pVertex[1] = yt;
'''                             pVertex[2] = zt;
''' 
'''                             Nevron.Nov.Graphics.NColor color = Nevron.Nov.Graphics.NColor.InterpolateColors(color1, color2, (float)((yt + 40.0) / 80.0));
'''                             *pColor = color.PackedARGB;
''' 
'''                             pVertex += 4;
'''                             pColor += 4;
''' 
'''                             x = xt;
'''                             y = yt;
'''                             z = zt;
'''                         }
'''                     }
'''                 }
''' 
''' 

                ' notify series that data has changed as we've modified it directly using pointers
                surface.Data.SetCount(dataPointCount)
            Next
        End Sub
        ''' <summary>
        ''' 
        ''' </summary>
        ''' <paramname="arg"></param>
        Private Sub OnNumberOfLinesUpDownValueChanged(ByVal arg As NValueChangeEventArgs)
            UpdateData()
        End Sub
        ''' <summary>
        ''' 
        ''' </summary>
        ''' <paramname="arg"></param>
        Private Sub OnDataCountPerLineComboBoxSelectedIndexChanged(ByVal arg As NValueChangeEventArgs)
            UpdateData()
        End Sub
        ''' <summary>
        ''' 
        ''' </summary>
        ''' <returns></returns>
        Protected Overrides Function GetExampleDescription() As String
            Return "<p>The example demonstrates how to use the Vertex Surface series to plot lines with large amounts of vertices, and with custom color per vertex.</p>"
        End Function

#End Region

#Region "Fields"

        Private m_NumberOfLinesUpDown As NNumericUpDown
        Private m_DataCountPerLineComboBox As NComboBox
        Private m_Surface As NVertexSurfaceSeries
        Private m_Chart As NCartesianChart

#End Region

#Region "Schema"

        Public Shared ReadOnly NVertexSurfaceFrameCustomColorsExampleSchema As NSchema

#End Region
    End Class
End Namespace


Imports Nevron.Nov.Chart
Imports Nevron.Nov.Graphics

Namespace Nevron.Nov.Examples.Chart
    ''' <summary>
    ''' Simple class for maintaining a draggable plane
    ''' </summary>
    Public Class NDragPlane
#Region "Constructors"

        ''' <summary>
        ''' Initializer constructor
        ''' </summary>
        ''' <paramname="chart"></param>
        ''' <paramname="vecA"></param>
        ''' <paramname="vecB"></param>
        ''' <paramname="vecC"></param>
        ''' <paramname="vecD"></param>
        Public Sub New(ByVal chart As NCartesianChart, ByVal vecA As NVector3DD, ByVal vecB As NVector3DD, ByVal vecC As NVector3DD, ByVal vecD As NVector3DD)
            Dim pointSeries As NPointSeries = New NPointSeries()

            pointSeries.Tag = 1
            pointSeries.Shape = ENPointShape3D.Sphere
            pointSeries.UseXValues = True
            pointSeries.UseZValues = True
            pointSeries.DataLabelStyle = New NDataLabelStyle(False)
            pointSeries.InflateMargins = False
            pointSeries.Size = 8

            pointSeries.DataPoints.Add(New NPointDataPoint(vecA.X, vecA.Y, vecA.Z, New NColorFill(NColor.Red), Nothing, ENPointShape3D.Sphere))
            pointSeries.DataPoints.Add(New NPointDataPoint(vecB.X, vecB.Y, vecB.Z, New NColorFill(NColor.Blue), Nothing, ENPointShape3D.Sphere))
            pointSeries.DataPoints.Add(New NPointDataPoint(vecC.X, vecC.Y, vecC.Z, New NColorFill(NColor.Blue), Nothing, ENPointShape3D.Sphere))
            pointSeries.DataPoints.Add(New NPointDataPoint(vecD.X, vecD.Y, vecD.Z, New NColorFill(NColor.Red), Nothing, ENPointShape3D.Sphere))

            m_PointSeries = pointSeries

            Dim meshSeries As NMeshSurfaceSeries = New NMeshSurfaceSeries()
            meshSeries.Data.SetGridSize(2, 2)

            m_MeshSurface = meshSeries
            m_MeshSurface.FillMode = ENSurfaceFillMode.Uniform
            m_MeshSurface.FrameMode = ENSurfaceFrameMode.None
            m_MeshSurface.Fill = New NColorFill(NColor.FromARGB(125, 0, 0, 255))

            UpdateMeshSurface()

            chart.Series.Add(m_MeshSurface)
            chart.Series.Add(m_PointSeries)
        End Sub

#End Region

#Region "Properties"

        ''' <summary>
        ''' Gets the point series
        ''' </summary>
        Public ReadOnly Property PointSeries As NPointSeries
            Get
                Return m_PointSeries
            End Get
        End Property
        ''' <summary>
        ''' Gets the A point
        ''' </summary>
        Public ReadOnly Property PointA As NVector3DD
            Get
                Return GetVectorFromPoint(0)
            End Get
        End Property
        ''' <summary>
        ''' Gets the B point
        ''' </summary>
        Public ReadOnly Property PointB As NVector3DD
            Get
                Return GetVectorFromPoint(1)
            End Get
        End Property
        ''' <summary>
        ''' Gets the C point
        ''' </summary>
        Public ReadOnly Property PointC As NVector3DD
            Get
                Return GetVectorFromPoint(2)
            End Get
        End Property
        ''' <summary>
        ''' Gets the D point
        ''' </summary>
        Public ReadOnly Property PointD As NVector3DD
            Get
                Return GetVectorFromPoint(3)
            End Get
        End Property
        ''' <summary>
        ''' Gets or sets whether to lock the x coordinate
        ''' </summary>
        Public Property LockX As Boolean
            Get
                Return m_LockX
            End Get
            Set(ByVal value As Boolean)
                m_LockX = value
            End Set
        End Property
        ''' <summary>
        ''' Gets or sets whether to lock the z coordinate
        ''' </summary>
        Public Property LockZ As Boolean
            Get
                Return m_LockZ
            End Get
            Set(ByVal value As Boolean)
                m_LockZ = value
            End Set
        End Property

#End Region

#Region "Methods"

        ''' <summary>
        ''' Gets the horizontal plane length 
        ''' </summary>
        ''' <paramname="axisRange"></param>
        ''' <paramname="origin"></param>
        ''' <returns></returns>
        Public Function GetPlaneLength(ByVal axisRange As NRange, ByVal origin As Double, ByVal originPoint As Integer, ByVal xOrZ As Boolean) As Double
            Dim vecA = GetVectorFromPoint(0)
            Dim vecB = GetVectorFromPoint(1)

            Dim lengthVector As NVector3DD = New NVector3DD()
            lengthVector.Subtract(vecB, vecA)
            Dim orgPlaneLength As Double = lengthVector.GetLength()
            Dim sign As Double

            If originPoint = 0 OrElse originPoint = 2 Then
                ' left point
                If xOrZ Then
                    sign = If(vecA.X < vecB.X, 1, -1)
                Else
                    sign = If(vecA.Z < vecB.Z, 1, -1)
                End If
            Else
                ' right point
                If xOrZ Then
                    sign = If(vecB.X < vecA.X, 1, -1)
                Else
                    sign = If(vecB.Z < vecA.Z, 1, -1)
                End If
            End If

            axisRange.Normalize()

            If sign > 0 Then
                If origin + orgPlaneLength > axisRange.End Then
                    orgPlaneLength = axisRange.End - origin
                End If
            Else
                If origin - orgPlaneLength < axisRange.Begin Then
                    orgPlaneLength = origin - axisRange.Begin
                End If
            End If

            Return orgPlaneLength * sign
        End Function
        ''' <summary>
        ''' Drags the specified point
        ''' </summary>
        ''' <paramname="dragPlane"></param>
        ''' <paramname="vector"></param>
        ''' <paramname="dataPointIndex"></param>
        Public Sub MovePoint(ByVal dragPlane As DragPlaneSurface, ByVal vector As NPoint3D, ByVal dataPointIndex As Integer)
            ' modify the point coordinates. Don't modify the y coords only x, z or xz
            ' take into account the currently selected axes from NViewToScale3DTransformation
            Select Case dragPlane
                Case DragPlaneSurface.XY
                    SetXPointCoordinate(dataPointIndex, ClampXCoordinateToRuler(vector.X))
                Case DragPlaneSurface.XZ
                    SetXPointCoordinate(dataPointIndex, ClampXCoordinateToRuler(vector.X))
                    SetZPointCoordinate(dataPointIndex, ClampZCoordinateToRuler(vector.Y))
                Case DragPlaneSurface.ZY
                    SetZPointCoordinate(dataPointIndex, ClampXCoordinateToRuler(vector.X))
            End Select

            SynchronizePoints(dataPointIndex)
            UpdateMeshSurface()

            FireDragPlaneChanged()
        End Sub
        ''' <summary>
        ''' Orients the plane in the X direction
        ''' </summary>
        ''' <paramname="anchorPoint"></param>
        Public Sub OrientPlaneX(ByVal anchorPoint As Integer)
            Dim z = GetVectorFromPoint(anchorPoint).Z
            Dim x = GetVectorFromPoint(anchorPoint).X

            Dim hasDifferentXPoint = False
            For i = 0 To 3
                If GetVectorFromPoint(i).X <> x Then
                    hasDifferentXPoint = True
                End If
            Next

            If Not hasDifferentXPoint Then Return

            Dim viewRange As NRange = m_PointSeries.GetFirstAncestor(Of NCartesianChart)().Axes(ENCartesianAxis.Depth).ViewRange
            Dim planeLength = GetPlaneLength(viewRange, z, anchorPoint, False)

            ' make the x coordinate equal
            For i = 0 To 3
                If i <> anchorPoint Then
                    SetXPointCoordinate(i, x)
                End If
            Next

            For i = 0 To 3
                If GetVectorFromPoint(i).Z <> z Then
                    SetZPointCoordinate(i, z + planeLength)
                End If
            Next

            ' update the plane / intersections
            UpdateMeshSurface()
            FireDragPlaneChanged()
        End Sub
        ''' <summary>
        ''' Orients the plane in the Z direction
        ''' </summary>
        Public Sub OrientPlaneZ(ByVal anchorPoint As Integer)
            Dim z = GetVectorFromPoint(anchorPoint).Z
            Dim x = GetVectorFromPoint(anchorPoint).X

            Dim hasDifferentZPoint = False
            For i = 0 To 3
                If GetVectorFromPoint(i).Z <> z Then
                    hasDifferentZPoint = True
                End If
            Next

            If Not hasDifferentZPoint Then Return

            Dim viewRange As NRange = m_PointSeries.GetFirstAncestor(Of NCartesianChart)().Axes(ENCartesianAxis.PrimaryX).ViewRange
            Dim planeLength = GetPlaneLength(viewRange, x, anchorPoint, True)

            ' make the z coordinate equal
            For i = 0 To 3
                If i <> anchorPoint Then
                    SetZPointCoordinate(i, z)
                End If
            Next

            For i = 0 To 3
                If GetVectorFromPoint(i).X <> x Then
                    SetXPointCoordinate(i, x + planeLength)
                End If
            Next

            UpdateMeshSurface()
            FireDragPlaneChanged()
        End Sub
        ''' <summary>
        ''' Synchronizes the points so that they are coplanar
        ''' </summary>
        ''' <paramname="modifiedPointIndex"></param>
        Public Sub SynchronizePoints(ByVal modifiedPointIndex As Integer)
            ' then align points depending on which point is being dragged
            Dim vecA = GetVectorFromPoint(0)
            Dim vecB = GetVectorFromPoint(1)
            Dim vecC = GetVectorFromPoint(2)
            Dim vecD = GetVectorFromPoint(3)

            Select Case modifiedPointIndex
                                        ' sync point 3 (left bottom)
                Case 0 ' left top
                    Dim vecCB As NVector3DD = New NVector3DD()
                    vecCB.Subtract(vecC, vecB)

                    vecD.Add(vecA, vecCB)

                    SetVectorToPoint(3, vecD)
                Case 1 ' right top
                    ' sync point 2 (right bottom)
                    Dim vecDA As NVector3DD = New NVector3DD()
                    vecDA.Subtract(vecD, vecA)

                    vecC.Add(vecB, vecDA)

                    SetVectorToPoint(2, vecC)
                Case 2 ' right bottom
                    ' sync point 1 (right top)
                    Dim vecAD As NVector3DD = New NVector3DD()
                    vecAD.Subtract(vecA, vecD)

                    vecB.Add(vecC, vecAD)

                    SetVectorToPoint(1, vecB)
                Case 3 ' left bottom
                    ' sync point 0 (left top)
                    Dim vecCB As NVector3DD = New NVector3DD()
                    vecCB.Subtract(vecB, vecC)

                    vecA.Add(vecD, vecCB)

                    SetVectorToPoint(0, vecA)
            End Select

            ' handle x / z locking
            If m_LockX Then
                Dim x = GetVectorFromPoint(modifiedPointIndex).X
                For i = 0 To 3
                    If i <> modifiedPointIndex Then
                        SetXPointCoordinate(i, x)
                    End If
                Next
            End If

            If m_LockZ Then
                Dim z = GetVectorFromPoint(modifiedPointIndex).Z

                For i = 0 To 3
                    If i <> modifiedPointIndex Then
                        SetZPointCoordinate(i, z)
                    End If
                Next
            End If
        End Sub
        ''' <summary>
        ''' Restores the position of the point
        ''' </summary>
        ''' <paramname="dataPointIndex"></param>
        ''' <paramname="vector"></param>
        Public Sub RestorePoint(ByVal dataPointIndex As Integer, ByVal vector As NVector3DD)
            SetVectorToPoint(dataPointIndex, vector)

            SynchronizePoints(dataPointIndex)
            UpdateMeshSurface()

            FireDragPlaneChanged()
        End Sub
        ''' <summary>
        ''' Gets the vector from the currently selected point
        ''' </summary>
        ''' <paramname="dataPointIndex"></param>
        ''' <returns></returns>
        Public Function GetVectorFromPoint(ByVal dataPointIndex As Integer) As NVector3DD
            Dim vector As NVector3DD

            Dim dataPoint = m_PointSeries.DataPoints(dataPointIndex)

            vector.X = dataPoint.X
            vector.Y = dataPoint.Y
            vector.Z = dataPoint.Z

            Return vector

#End Region

#Region "Events"

            ''' <summary>
            ''' Occurs when the drag plane has changed
            ''' </summary>
        End Function

                ''' Cannot convert EventFieldDeclarationSyntax, System.InvalidCastException: Unable to cast object of type 'Microsoft.CodeAnalysis.VisualBasic.Syntax.EmptyStatementSyntax' to type 'Microsoft.CodeAnalysis.VisualBasic.Syntax.AttributeListSyntax'.
'''    at ICSharpCode.CodeConverter.VB.NodesVisitor.ConvertAndSplitAttributes(SyntaxList`1 attributeLists, SyntaxList`1& attributes, SyntaxList`1& returnAttributes) in D:\Nevron\NOV\Tools\CodeConverter\CodeConverterLibNuget\VB\NodesVisitor.cs:line 706
'''    at ICSharpCode.CodeConverter.VB.NodesVisitor.VisitEventFieldDeclaration(EventFieldDeclarationSyntax node) in D:\Nevron\NOV\Tools\CodeConverter\CodeConverterLibNuget\VB\NodesVisitor.cs:line 680
'''    at Microsoft.CodeAnalysis.CSharp.Syntax.EventFieldDeclarationSyntax.Accept[TResult](CSharpSyntaxVisitor`1 visitor)
'''    at Microsoft.CodeAnalysis.CSharp.CSharpSyntaxVisitor`1.Visit(SyntaxNode node)
'''    at ICSharpCode.CodeConverter.VB.CommentConvertingVisitorWrapper`1.Accept(SyntaxNode csNode, Boolean addSourceMapping) in D:\Nevron\NOV\Tools\CodeConverter\CodeConverterLibNuget\VB\CommentConvertingVisitorWrapper.cs:line 20
''' 
''' Input:
''' 
'''         #endregion
''' 
'''         #region Events
''' 
'''         /// <summary>
'''         /// Occurs when the drag plane has changed
'''         /// </summary>
'''         [field: System.@NonSerializedAttribute]
'''         public event System.EventHandler DragPlaneChanged;
''' 
''' 

        ''' <summary>
        ''' Raises the drag plane changed event
        ''' </summary>
        Friend Sub FireDragPlaneChanged()
            If m_DragPlaneChanged Then
                m_DragPlaneChanged = False

                RaiseEvent DragPlaneChanged(Me, New EventArgs())
            End If
        End Sub

#End Region

#Region "Implementation"

        ''' <summary>
        ''' Clamps the passed x coordinate to the x axis range
        ''' </summary>
        ''' <paramname="x"></param>
        ''' <returns></returns>
        Private Function ClampXCoordinateToRuler(ByVal x As Double) As Double
            Return m_PointSeries.GetFirstAncestor(Of NCartesianChart)().Axes(ENCartesianAxis.PrimaryX).RulerRange.GetValueInRange(x)
        End Function
        ''' <summary>
        ''' Clamps the passed z coordinate to the x axis range
        ''' </summary>
        ''' <paramname="z"></param>
        ''' <returns></returns>
        Private Function ClampZCoordinateToRuler(ByVal z As Double) As Double
            Return m_PointSeries.GetFirstAncestor(Of NCartesianChart)().Axes(ENCartesianAxis.Depth).RulerRange.GetValueInRange(z)
        End Function
        ''' <summary>
        ''' Sets the vector to the specified point
        ''' </summary>
        ''' <paramname="dataPointIndex"></param>
        ''' <paramname="vector"></param>
        Private Sub SetVectorToPoint(ByVal dataPointIndex As Integer, ByVal vector As NVector3DD)
            SetXPointCoordinate(dataPointIndex, vector.X)
            SetYPointCoordinate(dataPointIndex, vector.Y)
            SetZPointCoordinate(dataPointIndex, vector.Z)
        End Sub
        ''' <summary>
        ''' Sets an x point coordinate
        ''' </summary>
        ''' <paramname="dataPointIndex"></param>
        ''' <paramname="x"></param>
        Private Sub SetXPointCoordinate(ByVal dataPointIndex As Integer, ByVal x As Double)
            If m_PointSeries.DataPoints(dataPointIndex).X <> x Then
                m_DragPlaneChanged = True
                m_PointSeries.DataPoints(dataPointIndex).X = x
            End If
        End Sub
        ''' <summary>
        ''' Sets an y point coordinate
        ''' </summary>
        ''' <paramname="dataPointIndex"></param>
        ''' <paramname="x"></param>
        Private Sub SetYPointCoordinate(ByVal dataPointIndex As Integer, ByVal y As Double)
            If m_PointSeries.DataPoints(dataPointIndex).Y <> y Then
                m_DragPlaneChanged = True
                m_PointSeries.DataPoints(dataPointIndex).Y = y
            End If
        End Sub
        ''' <summary>
        ''' Sets an y point coordinate
        ''' </summary>
        ''' <paramname="dataPointIndex"></param>
        ''' <paramname="x"></param>
        Private Sub SetZPointCoordinate(ByVal dataPointIndex As Integer, ByVal z As Double)
            If m_PointSeries.DataPoints(dataPointIndex).Z <> z Then
                m_DragPlaneChanged = True
                m_PointSeries.DataPoints(dataPointIndex).Z = z
            End If
        End Sub
        ''' <summary>
        ''' Updates the mesh surface from the point series
        ''' </summary>
        Private Sub UpdateMeshSurface()
            Dim vecA = GetVectorFromPoint(0)
            Dim vecB = GetVectorFromPoint(1)
            Dim vecC = GetVectorFromPoint(2)
            Dim vecD = GetVectorFromPoint(3)

            m_MeshSurface.Data.SetValue(0, 0, vecA.Y, vecA.X, vecA.Z)
            m_MeshSurface.Data.SetValue(0, 1, vecB.Y, vecB.X, vecB.Z)
            m_MeshSurface.Data.SetValue(1, 1, vecC.Y, vecC.X, vecC.Z)
            m_MeshSurface.Data.SetValue(1, 0, vecD.Y, vecD.X, vecD.Z)
            m_MeshSurface.Data.OnDataChanged()
        End Sub

#End Region

#Region "Fields"

        Private m_PointSeries As NPointSeries
        Private m_MeshSurface As NMeshSurfaceSeries

        Private m_LockX As Boolean
        Private m_LockZ As Boolean

        Private m_DragPlaneChanged As Boolean

#End Region
    End Class
End Namespace

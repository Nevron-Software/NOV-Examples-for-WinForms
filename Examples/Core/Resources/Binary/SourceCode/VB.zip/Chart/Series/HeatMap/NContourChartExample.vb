Imports System

Imports Nevron.Nov.Chart
Imports Nevron.Nov.Dom
Imports Nevron.Nov.Graphics
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.Chart
    ''' <summary>
    ''' Controur Chart Example
    ''' </summary>
    Public Class NContourChartExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' Default constructor
        ''' </summary>
        Public Sub New()

        End Sub
        ''' <summary>
        ''' Static constructor
        ''' </summary>
        Shared Sub New()
            NContourChartExampleSchema = NSchema.Create(GetType(NContourChartExample), NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            Dim chartViewWithCommandBars As NChartViewWithCommandBars = New NChartViewWithCommandBars()
            Dim chartView = chartViewWithCommandBars.View
            chartView.Surface.CreatePredefinedChart(ENPredefinedChartType.Cartesian)

            ' configure title
            chartView.Surface.Titles(0).Text = "Contour Chart"

            ' configure chart
            Dim chart = CType(chartView.Surface.Charts(0), NCartesianChart)
            chart.SetPredefinedCartesianAxes(ENPredefinedCartesianAxis.XYLinear)

            m_HeatMap = New NHeatMapSeries()
            chart.Series.Add(m_HeatMap)

            m_HeatMap.Palette = New NColorValuePalette(New NColorValuePair() {New NColorValuePair(0.0, NColor.Purple), New NColorValuePair(1.5, NColor.MediumSlateBlue), New NColorValuePair(3.0, NColor.CornflowerBlue), New NColorValuePair(4.5, NColor.LimeGreen), New NColorValuePair(6.0, NColor.LightGreen), New NColorValuePair(7.5, NColor.Yellow), New NColorValuePair(9.0, NColor.Orange), New NColorValuePair(10.5, NColor.Red)})

            ' 			m_HeatMap.Palette = new NColorValuePalette(new NColorValuePair[] { new NColorValuePair(-5.0, NColor.Purple),
            ' new NColorValuePair(1, NColor.MediumSlateBlue),
            ' new NColorValuePair(10.0, NColor.CornflowerBlue) });

            m_HeatMap.ContourDisplayMode = ENContourDisplayMode.Contour
            m_HeatMap.LegendView.Mode = ENSeriesLegendMode.SeriesLogic
            m_HeatMap.LegendView.Format = "<level_value>"

            GenerateData()

            Return chartViewWithCommandBars
        End Function
        Protected Overrides Function CreateExampleControls() As NWidget
            Dim stack As NStackPanel = New NStackPanel()
            Dim boxGroup As NUniSizeBoxGroup = New NUniSizeBoxGroup(stack)

            Dim originXUpDown As NNumericUpDown = New NNumericUpDown()
            originXUpDown.ValueChanged += AddressOf OnOriginXUpDownValueChanged
            originXUpDown.Value = 0
            stack.Add(NPairBox.Create("Origin X:", originXUpDown))

            Dim originYUpDown As NNumericUpDown = New NNumericUpDown()
            originYUpDown.ValueChanged += AddressOf OnOriginYUpDownValueChanged
            originYUpDown.Value = 0
            stack.Add(NPairBox.Create("Origin Y:", originYUpDown))

            Dim GridStepXUpDown As NNumericUpDown = New NNumericUpDown()
            GridStepXUpDown.ValueChanged += AddressOf OnGridStepXUpDownValueChanged
            GridStepXUpDown.Value = 1.0
            stack.Add(NPairBox.Create("Grid Step X:", GridStepXUpDown))

            Dim GridStepYUpDown As NNumericUpDown = New NNumericUpDown()
            GridStepYUpDown.ValueChanged += AddressOf OnGridStepYUpDownValueChanged
            GridStepYUpDown.Value = 1.0
            stack.Add(NPairBox.Create("Grid Step Y:", GridStepYUpDown))

            Dim contourDisplayModeCombo As NComboBox = New NComboBox()
            contourDisplayModeCombo.FillFromEnum(Of ENContourDisplayMode)()
            contourDisplayModeCombo.SelectedIndexChanged += AddressOf OnContourDisplayModeComboSelectedIndexChanged
            contourDisplayModeCombo.SelectedIndex = CInt(ENContourDisplayMode.Contour)
            stack.Add(NPairBox.Create("Contour Display Mode:", contourDisplayModeCombo))

            Dim contourColorModeCombo As NComboBox = New NComboBox()
            contourColorModeCombo.FillFromEnum(Of ENContourColorMode)()
            contourColorModeCombo.SelectedIndexChanged += AddressOf OnContourColorModeComboSelectedIndexChanged
            contourColorModeCombo.SelectedIndex = CInt(ENContourColorMode.Uniform)
            stack.Add(NPairBox.Create("Contour Color Mode:", contourColorModeCombo))

            Dim showFillCheckBox As NCheckBox = New NCheckBox("Show Fill")
            showFillCheckBox.CheckedChanged += AddressOf OnShowFillCheckBoxCheckedChanged
            showFillCheckBox.Checked = True
            stack.Add(showFillCheckBox)

            Dim smoothPaletteCheckBox As NCheckBox = New NCheckBox("Smooth Palette")
            smoothPaletteCheckBox.CheckedChanged += AddressOf OnSmoothPaletteCheckBoxCheckedChanged
            smoothPaletteCheckBox.Checked = True
            stack.Add(smoothPaletteCheckBox)

            Return boxGroup
        End Function
        Protected Overrides Function GetExampleDescription() As String
            Return "<p>This example demonstrates how to create a contour chart.</p>"
        End Function

#End Region

#Region "Implementation"

        ' 		private void GenerateData()
        ' 		{
        ' 			NGridData data = m_HeatMap.Data;
        ' 
        ' int GridStepX = 10;
        ' int GridStepY = 10;
        ' 			data.Size = new NSizeI(GridStepX, GridStepY);
        ' 
        ' 			for (int row = 0; row < GridStepX; row++)
        ' 			{
        ' 				for (int col = 0; col < GridStepY; col++)
        ' 				{
        ' 					int dx = 2 - row;
        ' 					int dy = 2 - col;
        ' 					double distance = Math.Sqrt(dx * dx + dy * dy);
        ' 
        ' 					data.SetValue(row, col, 5 - distance);
        ' 				}
        ' 			}
        ' 		}

        Private Sub GenerateData()
            Dim data = m_HeatMap.Data

            Dim GridStepX = 300
            Dim GridStepY = 300
            data.Size = New NSizeI(GridStepX, GridStepY)

            Const dIntervalX = 10.0
            Const dIntervalZ = 10.0
            Dim dIncrementX = dIntervalX / GridStepX
            Dim dIncrementZ = dIntervalZ / GridStepY

            Dim y, x, z As Double

            z = -(dIntervalZ / 2)

            Dim col = 0

            While col < GridStepX
                x = -(dIntervalX / 2)

                Dim row = 0

                While row < GridStepY
                    y = 10 - Math.Sqrt(x * x + z * z + 2)
                    y += 3.0 * Math.Sin(x) * Math.Cos(z)

                    data.SetValue(row, col, y)
                    row += 1
                    x += dIncrementX
                End While

                col += 1
                z += dIncrementZ
            End While
        End Sub

#End Region

#Region "Event Handlers"

        Private Sub OnOriginYUpDownValueChanged(ByVal arg As NValueChangeEventArgs)
            m_HeatMap.Data.OriginY = CType(arg.TargetNode, NNumericUpDown).Value
        End Sub

        Private Sub OnOriginXUpDownValueChanged(ByVal arg As NValueChangeEventArgs)
            m_HeatMap.Data.OriginX = CType(arg.TargetNode, NNumericUpDown).Value
        End Sub

        Private Sub OnGridStepYUpDownValueChanged(ByVal arg As NValueChangeEventArgs)
            m_HeatMap.Data.StepY = CType(arg.TargetNode, NNumericUpDown).Value
        End Sub

        Private Sub OnGridStepXUpDownValueChanged(ByVal arg As NValueChangeEventArgs)
            m_HeatMap.Data.StepX = CType(arg.TargetNode, NNumericUpDown).Value
        End Sub

        Private Sub OnShowFillCheckBoxCheckedChanged(ByVal arg As NValueChangeEventArgs)
            m_HeatMap.ShowFill = CType(arg.TargetNode, NCheckBox).Checked
        End Sub

        Private Sub OnContourColorModeComboSelectedIndexChanged(ByVal arg As NValueChangeEventArgs)
            m_HeatMap.ContourColorMode = CType(CType(arg.TargetNode, NComboBox).SelectedIndex, ENContourColorMode)
        End Sub

        Private Sub OnContourDisplayModeComboSelectedIndexChanged(ByVal arg As NValueChangeEventArgs)
            m_HeatMap.ContourDisplayMode = CType(CType(arg.TargetNode, NComboBox).SelectedIndex, ENContourDisplayMode)
        End Sub

        Private Sub OnSmoothPaletteCheckBoxCheckedChanged(ByVal arg As NValueChangeEventArgs)
            m_HeatMap.Palette.InterpolateColors = CType(arg.TargetNode, NCheckBox).Checked
        End Sub

#End Region

#Region "Fields"

        Private m_HeatMap As NHeatMapSeries

#End Region

#Region "Schema"

        Public Shared ReadOnly NContourChartExampleSchema As NSchema

#End Region
    End Class
End Namespace

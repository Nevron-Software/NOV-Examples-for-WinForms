Imports System.IO

Imports Nevron.Nov.Chart
Imports Nevron.Nov.Chart.Tools
Imports Nevron.Nov.Dom
Imports Nevron.Nov.Graphics
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.Chart
    ''' <summary>
    ''' Mesh Surface Contour Lines Example
    ''' </summary>
    Public Class NTriangulatedSurfaceContourLinesExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' Default constructor
        ''' </summary>
        Public Sub New()

        End Sub
        ''' <summary>
        ''' Static constructor
        ''' </summary>
        Shared Sub New()
            NTriangulatedSurfaceContourLinesExampleSchema = NSchema.Create(GetType(NTriangulatedSurfaceContourLinesExample), NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            Dim chartViewWithCommandBars As NChartViewWithCommandBars = New NChartViewWithCommandBars()
            Dim chartView = chartViewWithCommandBars.View
            chartView.Surface.CreatePredefinedChart(ENPredefinedChartType.Cartesian)

            ' configure title
            chartView.Surface.Titles(0).Text = "Triangulated Surface Isolines"

            ' setup chart
            Dim chart = CType(chartView.Surface.Charts(0), NCartesianChart)

            chart.Enable3D = True
            chart.ModelWidth = 60.0F
            chart.ModelDepth = 60.0F
            chart.ModelHeight = 25.0F
            chart.Projection.SetPredefinedProjection(ENPredefinedProjection.PerspectiveTilted)
            chart.LightModel.SetPredefinedLightModel(ENPredefinedLightModel.SoftTopLeft)
            chart.Interactor = New NInteractor(New NTrackballTool())

            Dim scale As NLinearScale = chart.Axes(ENCartesianAxis.PrimaryY).Scale
            scale.ViewRangeInflateMode = ENScaleViewRangeInflateMode.None

            ' setup axes
            Dim scaleX As NLinearScale = New NLinearScale()
            chart.Axes(ENCartesianAxis.PrimaryX).Scale = scaleX
            scaleX.MajorGridLines.SetShowAtWall(ENChartWall.Bottom, True)
            scaleX.MajorGridLines.SetShowAtWall(ENChartWall.Back, True)

            Dim scaleZ As NLinearScale = New NLinearScale()
            chart.Axes(ENCartesianAxis.Depth).Scale = scaleZ
            scaleZ.MajorGridLines.SetShowAtWall(ENChartWall.Bottom, True)
            scaleZ.MajorGridLines.SetShowAtWall(ENChartWall.Left, True)

            ' add the surface series
            m_Surface = New NTriangulatedSurfaceSeries()
            chart.Series.Add(m_Surface)

            m_Surface.Name = "Surface"
            m_Surface.LegendView.Mode = ENSeriesLegendMode.SeriesLogic
            m_Surface.FillMode = ENSurfaceFillMode.Zone
            m_Surface.FrameMode = ENSurfaceFrameMode.None
            m_Surface.FlatPositionValue = 0.5
            m_Surface.Fill = New NColorFill(NColor.YellowGreen)

            m_RedIsoline = New NContourLine()
            m_RedIsoline.Value = 100
            m_RedIsoline.Stroke = New NStroke(2.0F, NColor.Red)
            m_Surface.ContourLines.Add(m_RedIsoline)

            m_BlueIsoline = New NContourLine()
            m_BlueIsoline.Value = 50
            m_BlueIsoline.Stroke = New NStroke(2.0F, NColor.Blue)
            m_Surface.ContourLines.Add(m_BlueIsoline)

            FillData()

            Return chartViewWithCommandBars
        End Function

        Private Sub FillData()
            Dim surface = m_Surface

            Dim stream As Stream = Nothing
            Dim reader As BinaryReader = Nothing

            Try
                ' fill the XYZ data from a binary resource
                stream = New MemoryStream(NResources.RBIN_SampleData_DataXYZ_bin.Data)
                reader = New BinaryReader(stream)

                Dim nDataPointsCount As Integer = stream.Length / 12

                'surface.Data.SetCapacity(nDataPointsCount);
                Dim data = New NVector3DF(nDataPointsCount - 1) {}

                ' fill Y values
                For i = 0 To nDataPointsCount - 1
                    data(i).Y = reader.ReadSingle()
                Next

                ' fill X values
                For i = 0 To nDataPointsCount - 1
                    data(i).X = reader.ReadSingle()
                Next

                ' fill Z values
                For i = 0 To nDataPointsCount - 1
                    data(i).Z = reader.ReadSingle()
                Next

                surface.Data.Clear()
                surface.Data.AddValues(data)
            Finally
                If reader IsNot Nothing Then reader.Close()

                If stream IsNot Nothing Then stream.Close()
            End Try
        End Sub


        Protected Overrides Function CreateExampleControls() As NWidget
            Dim stack As NStackPanel = New NStackPanel()
            Dim group As NUniSizeBoxGroup = New NUniSizeBoxGroup(stack)

            Dim redIsolineValueUpDown As NNumericUpDown = New NNumericUpDown()
            redIsolineValueUpDown.Value = m_RedIsoline.Value
            redIsolineValueUpDown.ValueChanged += AddressOf OnRedIsolineValueUpDownValueChanged
            redIsolineValueUpDown.HorizontalPlacement = Layout.ENHorizontalPlacement.Left
            stack.Add(NPairBox.Create("Red Isoline Value:", redIsolineValueUpDown))

            Dim blueIsolineValueUpDown As NNumericUpDown = New NNumericUpDown()
            blueIsolineValueUpDown.Value = m_BlueIsoline.Value
            blueIsolineValueUpDown.ValueChanged += AddressOf OnBlueIsolineValueUpDownValueChanged
            blueIsolineValueUpDown.HorizontalPlacement = Layout.ENHorizontalPlacement.Left
            stack.Add(NPairBox.Create("Blue Isoline Value:", blueIsolineValueUpDown))

            Return group
        End Function

        Private Sub OnRedIsolineValueUpDownValueChanged(ByVal arg As NValueChangeEventArgs)
            m_RedIsoline.Value = CDbl(arg.NewValue)
        End Sub

        Private Sub OnBlueIsolineValueUpDownValueChanged(ByVal arg As NValueChangeEventArgs)
            m_BlueIsoline.Value = CDbl(arg.NewValue)
        End Sub

        Protected Overrides Function GetExampleDescription() As String
            Return "<p>The example demonstrates how to create isolines on a triangulated surface chart.</p>"
        End Function

#End Region

#Region "Fields"

        Private m_Surface As NTriangulatedSurfaceSeries
        Private m_RedIsoline As NContourLine
        Private m_BlueIsoline As NContourLine

#End Region

#Region "Schema"

        Public Shared ReadOnly NTriangulatedSurfaceContourLinesExampleSchema As NSchema

#End Region
    End Class
End Namespace

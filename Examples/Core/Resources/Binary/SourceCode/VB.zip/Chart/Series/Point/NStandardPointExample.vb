Imports Nevron.Nov.Chart
Imports Nevron.Nov.Dom
Imports Nevron.Nov.Graphics
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.Chart
    ''' <summary>
    ''' Standard Point Example
    ''' </summary>
    Public Class NStandardPointExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' Default constructor
        ''' </summary>
        Public Sub New()
        End Sub
        ''' <summary>
        ''' Static constructor
        ''' </summary>
        Shared Sub New()
            NStandardPointExampleSchema = NSchema.Create(GetType(NStandardPointExample), NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            Dim chartView As NChartView = CreateCartesianChartView()

            ' configure title
            chartView.Surface.Titles(0).Text = "Standard Point"

            ' configure chart
            m_Chart = CType(chartView.Surface.Charts(0), NCartesianChart)
            m_Chart.SetPredefinedCartesianAxes(ENPredefinedCartesianAxis.XYLinear)

            ' add interlace stripe
            Dim linearScale As NLinearScale = TryCast(m_Chart.Axes(ENCartesianAxis.PrimaryY).Scale, NLinearScale)
            Dim strip As NScaleStrip = New NScaleStrip(New NColorFill(ENNamedColor.Beige), Nothing, True, 0, 0, 1, 1)
            strip.Interlaced = True

            ' setup point series
            m_Point = New NPointSeries()

            'm_Point.DataLabelStyle.ArrowLength = 20;

            m_Point.Name = "Point Series"
            m_Point.InflateMargins = True
            m_Point.DataLabelStyle = New NDataLabelStyle(False)
            m_Point.DataPoints.Add(New NPointDataPoint(23, "Item1"))
            m_Point.DataPoints.Add(New NPointDataPoint(67, "Item2"))
            m_Point.DataPoints.Add(New NPointDataPoint(78, "Item3"))
            m_Point.DataPoints.Add(New NPointDataPoint(12, "Item4"))
            m_Point.DataPoints.Add(New NPointDataPoint(56, "Item5"))
            m_Point.DataPoints.Add(New NPointDataPoint(43, "Item6"))
            m_Point.DataPoints.Add(New NPointDataPoint(37, "Item7"))
            m_Point.DataPoints.Add(New NPointDataPoint(51, "Item8"))
            m_Point.Fill = New NColorFill(NColor.Red)
            m_Chart.Series.Add(m_Point)
            chartView.Document.StyleSheets.ApplyTheme(New NChartTheme(ENChartPalette.Bright, True))
            Return chartView
        End Function

        Protected Overrides Function CreateExampleControls() As NWidget
            Dim stack As NStackPanel = New NStackPanel()
            Dim group As NUniSizeBoxGroup = New NUniSizeBoxGroup(stack)
            Dim inflateMarginsCheckBox As NCheckBox = New NCheckBox()
            AddHandler inflateMarginsCheckBox.CheckedChanged, New [Function](Of NValueChangeEventArgs)(AddressOf OnInflateMarginsCheckBoxCheckedChanged)
            stack.Add(NPairBox.Create("Inflate Margins: ", inflateMarginsCheckBox))
            Dim verticalAxisRoundToTick As NCheckBox = New NCheckBox()
            AddHandler verticalAxisRoundToTick.CheckedChanged, New [Function](Of NValueChangeEventArgs)(AddressOf OnverticalAxisRoundToTickCheckedChanged)
            stack.Add(NPairBox.Create("Left Axis Round To Tick: ", verticalAxisRoundToTick))
            Dim pointSizeNumericUpDown As NNumericUpDown = New NNumericUpDown()
            AddHandler pointSizeNumericUpDown.ValueChanged, New [Function](Of NValueChangeEventArgs)(AddressOf OnPointSizeNumericUpDownValueChanged)
            stack.Add(NPairBox.Create("Point Size: ", pointSizeNumericUpDown))
            Dim pointShapeComboBox As NComboBox = New NComboBox()
            pointShapeComboBox.FillFromEnum(Of ENPointShape)()
            AddHandler pointShapeComboBox.SelectedIndexChanged, New [Function](Of NValueChangeEventArgs)(AddressOf OnPointShapeComboBoxSelectedIndexChanged)
            stack.Add(NPairBox.Create("Point Shape: ", pointShapeComboBox))
            Return group
        End Function

        Protected Overrides Function GetExampleDescription() As String
            Return "<p>This example demonstrates how to create a standard point chart.</p>"
        End Function

#End Region

#Region "Event Handlers"

        Private Sub OnPointShapeComboBoxSelectedIndexChanged(ByVal arg As NValueChangeEventArgs)
            m_Point.Shape = CType(TryCast(arg.TargetNode, NComboBox).SelectedIndex, ENPointShape)
        End Sub

        Private Sub OnPointSizeNumericUpDownValueChanged(ByVal arg As NValueChangeEventArgs)
            m_Point.Size = TryCast(arg.TargetNode, NNumericUpDown).Value
        End Sub

        Private Sub OnverticalAxisRoundToTickCheckedChanged(ByVal arg As NValueChangeEventArgs)
            Dim linearScale As NLinearScale = TryCast(m_Chart.Axes(ENCartesianAxis.PrimaryY).Scale, NLinearScale)

            If linearScale IsNot Nothing Then
                If TryCast(arg.TargetNode, NCheckBox).Checked Then
                    linearScale.ViewRangeInflateMode = ENScaleViewRangeInflateMode.MajorTick
                    linearScale.InflateViewRangeBegin = True
                    linearScale.InflateViewRangeEnd = True
                Else
                    linearScale.ViewRangeInflateMode = ENScaleViewRangeInflateMode.Logical
                End If
            End If
        End Sub

        Private Sub OnInflateMarginsCheckBoxCheckedChanged(ByVal arg As NValueChangeEventArgs)
            m_Point.InflateMargins = TryCast(arg.TargetNode, NCheckBox).Checked
        End Sub

#End Region

#Region "Fields"

        Private m_Point As NPointSeries
        Private m_Chart As NCartesianChart

#End Region

#Region "Schema"

        Public Shared ReadOnly NStandardPointExampleSchema As NSchema

#End Region

#Region "Static Methods"

        Private Shared Function CreateCartesianChartView() As NChartView
            Dim chartView As NChartView = New NChartView()
            chartView.Surface.CreatePredefinedChart(ENPredefinedChartType.Cartesian)
            Return chartView
        End Function

#End Region
    End Class
End Namespace

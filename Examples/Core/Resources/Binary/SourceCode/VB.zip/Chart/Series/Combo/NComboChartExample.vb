Imports System

Imports Nevron.Nov.Chart
Imports Nevron.Nov.DataStructures
Imports Nevron.Nov.Dom
Imports Nevron.Nov.Graphics
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.Chart
    ''' <summary>
    ''' Combo Chart Example
    ''' </summary>
    Public Class NComboChartExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' Default constructor
        ''' </summary>
        Public Sub New()

        End Sub
        ''' <summary>
        ''' Static constructor
        ''' </summary>
        Shared Sub New()
            NComboChartExampleSchema = NSchema.Create(GetType(NComboChartExample), NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            Dim chartViewWithCommandBars As NChartViewWithCommandBars = New NChartViewWithCommandBars()
            Dim chartView = chartViewWithCommandBars.View
            chartView.Surface.CreatePredefinedChart(ENPredefinedChartType.Cartesian)

            ' configure title
            chartView.Surface.Titles(0).Text = "Combo Chart"

            ' configure chart
            m_Chart = CType(chartView.Surface.Charts(0), NCartesianChart)

            m_Chart.SetPredefinedCartesianAxes(ENPredefinedCartesianAxis.XOrdinalYLinear)

            ' Setup the primary Y axis
            m_Chart.Axes(ENCartesianAxis.PrimaryY).Scale.Title.Text = "Number of Occurences"

            ' add interlace stripe
            Dim strip As NScaleStrip = New NScaleStrip(New NColorFill(NColor.Beige), Nothing, True, 0, 0, 1, 1)
            strip.Interlaced = True
            m_Chart.Axes(ENCartesianAxis.PrimaryY).Scale.Strips.Add(strip)

            ' Setup the secondary Y axis
            Dim scaleY2 As NLinearScale = New NLinearScale()
            scaleY2.Labels.TextProvider = New NFormattedScaleLabelTextProvider(New NNumericValueFormatter("0%"))
            scaleY2.Title.Text = "Cumulative Percent"

            Dim axisY2 As NCartesianAxis = New NCartesianAxis()
            m_Chart.Axes.Add(axisY2)

            axisY2.Anchor = New NDockCartesianAxisAnchor(ENCartesianAxisDockZone.Right)
            axisY2.Visible = True
            axisY2.Scale = scaleY2
            axisY2.ViewRangeMode = ENAxisViewRangeMode.FixedRange
            axisY2.MinViewRangeValue = 0
            axisY2.MaxViewRangeValue = 1

            ' add the bar series
            Dim bar As NBarSeries = New NBarSeries()
            m_Chart.Series.Add(bar)
            bar.Name = "Bar Series"
            bar.DataLabelStyle = New NDataLabelStyle(False)

            ' add the line series
            Dim line As NLineSeries = New NLineSeries()
            m_Chart.Series.Add(line)
            line.Name = "Cumulative %"
            line.DataLabelStyle = New NDataLabelStyle(False)

            Dim markerStyle As NMarkerStyle = New NMarkerStyle()
            markerStyle.Visible = True
            markerStyle.Shape = ENPointShape3D.Ellipse
            markerStyle.Size = New NSize(10, 10)
            markerStyle.Fill = New NColorFill(NColor.Orange)

            line.MarkerStyle = markerStyle

            line.VerticalAxis = axisY2

            ' fill with random data and sort in descending order
            Dim count = 10
            Dim randomValues As NList(Of Double) = New NList(Of Double)()
            Dim random As Random = New Random()
            For i = 0 To count - 1
                randomValues.Add(random.Next(100, 700))
            Next

            randomValues.Sort()

            For i = 0 To randomValues.Count - 1
                bar.DataPoints.Add(New NBarDataPoint(randomValues(i)))
            Next

            ' calculate cumulative sum of the bar values
            Dim cs As Double = 0
            Dim arrCumulative = New Double(count - 1) {}

            For i = 0 To count - 1
                cs += randomValues(i)
                arrCumulative(i) = cs
            Next

            If cs > 0 Then
                For i = 0 To count - 1
                    arrCumulative(i) /= cs
                    line.DataPoints.Add(New NLineDataPoint(arrCumulative(i)))
                Next
            End If

            chartView.Document.StyleSheets.ApplyTheme(New NChartTheme(ENChartPalette.Bright, ENChartPaletteTarget.Series))

            Return chartViewWithCommandBars
        End Function
        Protected Overrides Function CreateExampleControls() As NWidget
            Dim stack As NStackPanel = New NStackPanel()
            Dim group As NUniSizeBoxGroup = New NUniSizeBoxGroup(stack)

            Return group
        End Function
        Protected Overrides Function GetExampleDescription() As String
            Return "<p>This example demonstrates how to create a combo chart consisting of two series (NOV Chart supports an unlimited number of series).</p>"
        End Function

#End Region

#Region "Implementation"

        Private Function CreateLegendFormatCombo() As NComboBox
            Dim comboBox As NComboBox = New NComboBox()

            Dim item As NComboBoxItem = New NComboBoxItem("Value and Label")
            item.Tag = "<value> <label>"
            comboBox.Items.Add(item)

            item = New NComboBoxItem("Value")
            item.Tag = "<value>"
            comboBox.Items.Add(item)

            item = New NComboBoxItem("Label")
            item.Tag = "<label>"
            comboBox.Items.Add(item)

            item = New NComboBoxItem("Size")
            item.Tag = "<size>"
            comboBox.Items.Add(item)

            Return comboBox
        End Function

#End Region

#Region "Fields"

        Private m_Chart As NCartesianChart

#End Region

#Region "Schema"

        Public Shared ReadOnly NComboChartExampleSchema As NSchema

#End Region
    End Class
End Namespace

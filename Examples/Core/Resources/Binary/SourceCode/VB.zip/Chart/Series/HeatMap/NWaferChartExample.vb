Imports System
Imports Nevron.Nov.Chart
Imports Nevron.Nov.Dom
Imports Nevron.Nov.Graphics
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.Chart
    ''' <summary>
    ''' Wafer Chart Example
    ''' </summary>
    Public Class NWaferChartExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' Default constructor
        ''' </summary>
        Public Sub New()
        End Sub
        ''' <summary>
        ''' Static constructor
        ''' </summary>
        Shared Sub New()
            NWaferChartExampleSchema = NSchema.Create(GetType(NWaferChartExample), NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            Dim chartView As NChartView = CreateCartesianChartView()

            ' configure title
            chartView.Surface.Titles(0).Text = "Standard Heat Maps"

            ' configure chart
            Dim chart = CType(chartView.Surface.Charts(0), NCartesianChart)
            chart.SetPredefinedCartesianAxes(ENPredefinedCartesianAxis.XYLinear)
            Dim heatMap As NHeatMapSeries = New NHeatMapSeries()
            chart.Series.Add(heatMap)
            Dim data = heatMap.Data
            heatMap.Palette = New NTwoColorPalette(NColor.Green, NColor.Red)
            Dim gridSizeX = 100
            Dim gridSizeY = 100
            data.Size = New NSizeI(gridSizeX, gridSizeY)
            Dim centerX As Integer = gridSizeX / 2
            Dim centerY As Integer = gridSizeY / 2
            Dim radius As Integer = gridSizeX / 2
            Dim rand As Random = New Random()

            For y = 0 To gridSizeY - 1

                For x = 0 To gridSizeX - 1
                    Dim dx = x - centerX
                    Dim dy = y - centerY
                    Dim pointDistance = Math.Sqrt(dx * dx + dy * dy)

                    If pointDistance < radius Then
                        ' assign value
                        data.SetValue(x, y, pointDistance + rand.Next(20))
                    Else
                        data.SetValue(x, y, Double.NaN)
                    End If
                Next
            Next

            Return chartView
        End Function

        Protected Overrides Function CreateExampleControls() As NWidget
            Dim stack As NStackPanel = New NStackPanel()
            Dim boxGroup As NUniSizeBoxGroup = New NUniSizeBoxGroup(stack)
            Return boxGroup
        End Function

        Protected Overrides Function GetExampleDescription() As String
            Return "<p>This example demonstrates how to create a standard bar chart.</p>"
        End Function

#End Region

#Region "Event Handlers"

#End Region

#Region "Fields"


#End Region

#Region "Schema"

        Public Shared ReadOnly NWaferChartExampleSchema As NSchema

#End Region

#Region "Static Methods"

        Private Shared Function CreateCartesianChartView() As NChartView
            Dim chartView As NChartView = New NChartView()
            chartView.Surface.CreatePredefinedChart(ENPredefinedChartType.Cartesian)
            Return chartView
        End Function

#End Region
    End Class
End Namespace

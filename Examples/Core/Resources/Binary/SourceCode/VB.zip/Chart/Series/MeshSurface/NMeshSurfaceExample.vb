Imports System

Imports Nevron.Nov.Chart
Imports Nevron.Nov.Chart.Tools
Imports Nevron.Nov.Dom
Imports Nevron.Nov.Graphics
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.Chart
    ''' <summary>
    ''' Mesh Surface Example
    ''' </summary>
    Public Class NMeshSurfaceExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' Default constructor
        ''' </summary>
        Public Sub New()

        End Sub
        ''' <summary>
        ''' Static constructor
        ''' </summary>
        Shared Sub New()
            NMeshSurfaceExampleSchema = NSchema.Create(GetType(NMeshSurfaceExample), NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            Dim chartViewWithCommandBars As NChartViewWithCommandBars = New NChartViewWithCommandBars()
            Dim chartView = chartViewWithCommandBars.View
            chartView.Surface.CreatePredefinedChart(ENPredefinedChartType.Cartesian)

            ' configure title
            chartView.Surface.Titles(0).Text = "Mesh Surface Chart"

            ' setup chart
            Dim chart = CType(chartView.Surface.Charts(0), NCartesianChart)
            chart.Enable3D = True
            chart.ModelWidth = 60.0F
            chart.ModelDepth = 60.0F
            chart.ModelHeight = 25.0F
            chart.Projection.SetPredefinedProjection(ENPredefinedProjection.PerspectiveTilted)
            chart.LightModel.SetPredefinedLightModel(ENPredefinedLightModel.SoftTopLeft)
            chart.Interactor = New NInteractor(New NTrackballTool())

            Dim scale As NLinearScale = chart.Axes(ENCartesianAxis.PrimaryY).Scale
            scale.ViewRangeInflateMode = ENScaleViewRangeInflateMode.None

            ' setup axes
            Dim scaleX As NLinearScale = New NLinearScale()
            chart.Axes(ENCartesianAxis.PrimaryX).Scale = scaleX
            scaleX.MajorGridLines.SetShowAtWall(ENChartWall.Bottom, True)
            scaleX.MajorGridLines.SetShowAtWall(ENChartWall.Back, True)

            Dim scaleZ As NLinearScale = New NLinearScale()
            chart.Axes(ENCartesianAxis.Depth).Scale = scaleZ
            scaleZ.MajorGridLines.SetShowAtWall(ENChartWall.Bottom, True)
            scaleZ.MajorGridLines.SetShowAtWall(ENChartWall.Left, True)

            ' add the surface series
            m_Surface = New NMeshSurfaceSeries()
            chart.Series.Add(m_Surface)

            m_Surface.Name = "Surface"
            m_Surface.LegendView.Mode = ENSeriesLegendMode.SeriesLogic
            m_Surface.FillMode = ENSurfaceFillMode.Zone
            m_Surface.FlatPositionValue = 0.5
            m_Surface.Data.SetGridSize(20, 20)
            m_Surface.Fill = New NColorFill(NColor.YellowGreen)

            FillData(m_Surface)

            Return chartViewWithCommandBars
        End Function

        Private Sub FillData(ByVal surface As NMeshSurfaceSeries)
            Dim x, y, z As Double
            Dim nCountX = surface.Data.GridSizeX
            Dim nCountZ = surface.Data.GridSizeZ

            For j = 0 To nCountZ - 1
                For i = 0 To nCountX - 1
                    x = 2 + i + Math.Sin(j / 4.0) * 2
                    z = 1 + j + Math.Cos(i / 4.0)

                    y = Math.Sin(i / 3.0) * Math.Sin(j / 3.0)

                    If y < 0 Then
                        y = Math.Abs(y / 2.0)
                    End If

                    surface.Data.SetValue(i, j, y, x, z)
                Next
            Next
        End Sub

        Protected Overrides Function CreateExampleControls() As NWidget
            Dim stack As NStackPanel = New NStackPanel()
            Dim group As NUniSizeBoxGroup = New NUniSizeBoxGroup(stack)

            Dim fillModeCombo As NComboBox = New NComboBox()
            fillModeCombo.FillFromEnum(Of ENSurfaceFillMode)()
            fillModeCombo.SelectedIndexChanged += AddressOf OnFillModeComboSelectedIndexChanged
            fillModeCombo.SelectedIndex = m_Surface.FillMode
            stack.Add(NPairBox.Create("Fill Mode:", fillModeCombo))

            Dim frameModeCombo As NComboBox = New NComboBox()
            frameModeCombo.FillFromEnum(Of ENSurfaceFrameMode)()
            frameModeCombo.SelectedIndexChanged += AddressOf OnFrameModeComboSelectedIndexChanged
            frameModeCombo.SelectedIndex = m_Surface.FrameMode
            stack.Add(NPairBox.Create("Frame Mode:", frameModeCombo))

            Dim frameColorModeCombo As NComboBox = New NComboBox()
            frameColorModeCombo.FillFromEnum(Of ENSurfaceFrameColorMode)()
            frameColorModeCombo.SelectedIndexChanged += AddressOf OnFrameColorModeComboSelectedIndexChanged
            frameColorModeCombo.SelectedIndex = m_Surface.FrameColorMode
            stack.Add(NPairBox.Create("Frame Color Mode:", frameColorModeCombo))

            Dim smoothShadingCheckBox As NCheckBox = New NCheckBox()
            smoothShadingCheckBox.CheckedChanged += AddressOf OnSmoothShadingCheckBoxCheckedChanged
            smoothShadingCheckBox.Checked = False
            smoothShadingCheckBox.HorizontalPlacement = Layout.ENHorizontalPlacement.Left
            stack.Add(NPairBox.Create("Smooth Shading:", smoothShadingCheckBox))

            Dim drawFlatCheckBox As NCheckBox = New NCheckBox()
            drawFlatCheckBox.CheckedChanged += AddressOf OnDrawFlatCheckBoxCheckedChanged
            drawFlatCheckBox.Checked = False
            drawFlatCheckBox.HorizontalPlacement = Layout.ENHorizontalPlacement.Left
            stack.Add(NPairBox.Create("Draw Flat:", drawFlatCheckBox))

            Return group
        End Function

        Private Sub OnDrawFlatCheckBoxCheckedChanged(ByVal arg As NValueChangeEventArgs)
            m_Surface.DrawFlat = CBool(arg.NewValue)
        End Sub

        Private Sub OnFrameColorModeComboSelectedIndexChanged(ByVal arg As NValueChangeEventArgs)
            m_Surface.FrameColorMode = CType(arg.NewValue, ENSurfaceFrameColorMode)
        End Sub

        Private Sub OnSmoothShadingCheckBoxCheckedChanged(ByVal arg As NValueChangeEventArgs)
            m_Surface.ShadingMode = If(arg.NewValue, ENShadingMode.Smooth, ENShadingMode.Flat)
        End Sub

        Private Sub OnFrameModeComboSelectedIndexChanged(ByVal arg As NValueChangeEventArgs)
            m_Surface.FrameMode = CType(arg.NewValue, ENSurfaceFrameMode)
        End Sub

        Private Sub OnFillModeComboSelectedIndexChanged(ByVal arg As NValueChangeEventArgs)
            m_Surface.FillMode = CType(arg.NewValue, ENSurfaceFillMode)
        End Sub

        Protected Overrides Function GetExampleDescription() As String
            Return "<p>This example demonstrates how to create a scatter funnel chart.</p>"
        End Function

#End Region

#Region "Fields"

        Private m_Surface As NMeshSurfaceSeries

#End Region

#Region "Schema"

        Public Shared ReadOnly NMeshSurfaceExampleSchema As NSchema

#End Region
    End Class
End Namespace

Imports System
Imports Nevron.Nov.Chart
Imports Nevron.Nov.Dom
Imports Nevron.Nov.Graphics
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.Chart
    ''' <summary>
    ''' XY Scatter Point Example
    ''' </summary>
    Public Class NXYScatterPointExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' Default constructor
        ''' </summary>
        Public Sub New()
        End Sub
        ''' <summary>
        ''' Static constructor
        ''' </summary>
        Shared Sub New()
            NXYScatterPointExampleSchema = NSchema.Create(GetType(NXYScatterPointExample), NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            Dim chartView As NChartView = CreateCartesianChartView()

            ' configure title
            chartView.Surface.Titles(0).Text = "XY Scatter Point"

            ' configure chart
            m_Chart = CType(chartView.Surface.Charts(0), NCartesianChart)
            m_Chart.SetPredefinedCartesianAxes(ENPredefinedCartesianAxis.XYLinear)

            ' setup X axis
            Dim scaleX As NLinearScale = New NLinearScale()
            scaleX.MajorGridLines = New NScaleGridLines()
            scaleX.MajorGridLines.Stroke.DashStyle = ENDashStyle.Dot
            m_Chart.Axes(ENCartesianAxis.PrimaryX).Scale = scaleX

            ' setup Y axis
            Dim scaleY As NLinearScale = New NLinearScale()
            scaleY.MajorGridLines = New NScaleGridLines()
            scaleY.MajorGridLines.Stroke.DashStyle = ENDashStyle.Dot
            m_Chart.Axes(ENCartesianAxis.PrimaryY).Scale = scaleY

            ' add a point series
            m_Point = New NPointSeries()
            m_Point.Name = "Point Series"
            m_Point.DataLabelStyle = New NDataLabelStyle(False)
            m_Point.Fill = New NColorFill(New NColor(NColor.DarkOrange, 160))
            m_Point.Size = 5
            m_Point.Shape = ENPointShape.Ellipse
            m_Point.UseXValues = True
            m_Chart.Series.Add(m_Point)
            OnNewDataButtonClick(Nothing)
            chartView.Document.StyleSheets.ApplyTheme(New NChartTheme(ENChartPalette.Bright, False))
            Return chartView
        End Function

        Protected Overrides Function CreateExampleControls() As NWidget
            Dim stack As NStackPanel = New NStackPanel()
            Dim group As NUniSizeBoxGroup = New NUniSizeBoxGroup(stack)
            Dim inflateMarginsCheckBox As NCheckBox = New NCheckBox()
            AddHandler inflateMarginsCheckBox.CheckedChanged, New [Function](Of NValueChangeEventArgs)(AddressOf OnInflateMarginsCheckBoxCheckedChanged)
            stack.Add(NPairBox.Create("Inflate Margins: ", inflateMarginsCheckBox))
            Dim verticalAxisRoundToTick As NCheckBox = New NCheckBox()
            AddHandler verticalAxisRoundToTick.CheckedChanged, New [Function](Of NValueChangeEventArgs)(AddressOf OnAxesRoundToTickCheckedChanged)
            stack.Add(NPairBox.Create("Axes Round To Tick: ", verticalAxisRoundToTick))
            Dim newDataButton As NButton = New NButton("New Data")
            AddHandler newDataButton.Click, New [Function](Of NEventArgs)(AddressOf OnNewDataButtonClick)
            stack.Add(newDataButton)
            Return group
        End Function

        Protected Overrides Function GetExampleDescription() As String
            Return "<p>This example demonstrates how to create a xy scatter point chart.</p>"
        End Function

#End Region

#Region "Event Handlers"

        Private Sub OnNewDataButtonClick(ByVal arg As NEventArgs)
            m_Point.DataPoints.Clear()
            Dim dataPoints = m_Point.DataPoints
            Dim random As Random = New Random()

            For i = 0 To 1000 - 1
                Dim u1 As Double = random.NextDouble()
                Dim u2 As Double = random.NextDouble()
                If u1 = 0 Then u1 += 0.0001
                If u2 = 0 Then u2 += 0.0001
                Dim z0 = Math.Sqrt(-2 * Math.Log(u1)) * Math.Cos(2 * Math.PI * u2)
                Dim z1 = Math.Sqrt(-2 * Math.Log(u1)) * Math.Sin(2 * Math.PI * u2)
                dataPoints.Add(New NPointDataPoint(z0, z1))
            Next
        End Sub

        Private Sub OnAxesRoundToTickCheckedChanged(ByVal arg As NValueChangeEventArgs)
            For i = 0 To m_Chart.Axes.Count - 1
                Dim linearScale As NLinearScale = TryCast(m_Chart.Axes(i).Scale, NLinearScale)

                If linearScale IsNot Nothing Then
                    If TryCast(arg.TargetNode, NCheckBox).Checked Then
                        linearScale.ViewRangeInflateMode = ENScaleViewRangeInflateMode.MajorTick
                        linearScale.InflateViewRangeBegin = True
                        linearScale.InflateViewRangeEnd = True
                    Else
                        linearScale.ViewRangeInflateMode = ENScaleViewRangeInflateMode.Logical
                    End If
                End If
            Next
        End Sub

        Private Sub OnInflateMarginsCheckBoxCheckedChanged(ByVal arg As NValueChangeEventArgs)
            m_Point.InflateMargins = TryCast(arg.TargetNode, NCheckBox).Checked
        End Sub

#End Region

#Region "Fields"

        Private m_Point As NPointSeries
        Private m_Chart As NCartesianChart

#End Region

#Region "Schema"

        Public Shared ReadOnly NXYScatterPointExampleSchema As NSchema

#End Region

#Region "Static Methods"

        Private Shared Function CreateCartesianChartView() As NChartView
            Dim chartView As NChartView = New NChartView()
            chartView.Surface.CreatePredefinedChart(ENPredefinedChartType.Cartesian)
            Return chartView
        End Function

#End Region
    End Class
End Namespace

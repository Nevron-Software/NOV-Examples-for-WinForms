Imports Nevron.Nov.Chart
Imports Nevron.Nov.Chart.Tools
Imports Nevron.Nov.Dom
Imports Nevron.Nov.Graphics
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.Chart
    ''' <summary>
    ''' Standard 3D Area Example
    ''' </summary>
    Public Class NStandard3DAreaExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' Default constructor
        ''' </summary>
        Public Sub New()

        End Sub
        ''' <summary>
        ''' Static constructor
        ''' </summary>
        Shared Sub New()
            NStandard3DAreaExampleSchema = NSchema.Create(GetType(NStandard3DAreaExample), NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            Dim chartViewWithCommandBars As NChartViewWithCommandBars = New NChartViewWithCommandBars()
            Dim chartView = chartViewWithCommandBars.View
            chartView.Surface.CreatePredefinedChart(ENPredefinedChartType.Cartesian)

            ' configure title
            chartView.Surface.Titles(0).Text = "Standard Area"

            ' configure chart
            Dim chart = CType(chartView.Surface.Charts(0), NCartesianChart)

            chart.Enable3D = True
            chart.LightModel.SetPredefinedLightModel(ENPredefinedLightModel.BrightCameraLight)
            chart.Projection.SetPredefinedProjection(ENPredefinedProjection.PerspectiveTilted)
            chart.Interactor = New NInteractor(New NTrackballTool())

            ' setup X axis
            Dim scaleX As NOrdinalScale = chart.Axes(ENCartesianAxis.PrimaryX).Scale
            scaleX.InflateContentRange = False
            scaleX.MajorTickMode = ENMajorTickMode.AutoMaxCount
            scaleX.DisplayDataPointsBetweenTicks = False
            scaleX.Labels.Visible = False

            For i = 0 To monthLetters.Length - 1
                scaleX.CustomLabels.Add(New NCustomValueLabel(i, monthLetters(i)))
            Next

            ' add interlaced stripe for Y axis
            Dim stripStyle As NScaleStrip = New NScaleStrip(New NColorFill(NColor.Beige), Nothing, True, 0, 0, 1, 1)
            stripStyle.Interlaced = True

            Dim scaleY As NLinearScale = chart.Axes(ENCartesianAxis.PrimaryY).Scale
            scaleY.Strips.Add(stripStyle)

            ' setup area series
            m_Area = New NAreaSeries()
            m_Area.Name = "Area Series"

            Dim dataLabelStyle As NDataLabelStyle = New NDataLabelStyle()

            dataLabelStyle.Visible = True
            dataLabelStyle.Format = "<value>"

            m_Area.DataLabelStyle = dataLabelStyle

            For i = 0 To monthValues.Length - 1
                m_Area.DataPoints.Add(New NAreaDataPoint(monthValues(i)))
            Next

            chart.Series.Add(m_Area)

            Return chartViewWithCommandBars
        End Function
        ''' <summary>
        ''' 
        ''' </summary>
        ''' <returns></returns>
        Protected Overrides Function CreateExampleControls() As NWidget
            Dim stack As NStackPanel = New NStackPanel()
            Dim boxGroup As NUniSizeBoxGroup = New NUniSizeBoxGroup(stack)

            Dim originModeComboBox As NComboBox = New NComboBox()
            originModeComboBox.FillFromEnum(Of ENSeriesOriginMode)()
            originModeComboBox.SelectedIndexChanged += New [Function](Of NValueChangeEventArgs)(AddressOf OnOriginModeComboBoxSelectedIndexChanged)
            stack.Add(NPairBox.Create("Origin Mode: ", originModeComboBox))

            Dim customOriginUpDown As NNumericUpDown = New NNumericUpDown()
            m_CustomOriginUpDown = customOriginUpDown
            m_CustomOriginUpDown.Enabled = m_Area.OriginMode Is ENSeriesOriginMode.CustomOrigin

            customOriginUpDown.ValueChanged += New [Function](Of NValueChangeEventArgs)(AddressOf OnCustomOriginUpDownValueChanged)
            customOriginUpDown.Value = 17
            stack.Add(NPairBox.Create("Custom Origin: ", customOriginUpDown))

            Dim depthPercentUpDown As NNumericUpDown = New NNumericUpDown()
            depthPercentUpDown.ValueChanged += AddressOf OnDepthPercentUpDownValueChanged
            depthPercentUpDown.Value = 50.0F
            stack.Add(NPairBox.Create("Depth Percent: ", depthPercentUpDown))

            Return boxGroup
        End Function
        ''' <summary>
        ''' 
        ''' </summary>
        ''' <returns></returns>
        Protected Overrides Function GetExampleDescription() As String
            Return "<p>This example demonstrates how to create a standard 3D area chart.</p>"
        End Function

#End Region

#Region "Event Handlers"

        Private Sub OnCustomOriginUpDownValueChanged(ByVal arg As NValueChangeEventArgs)
            m_Area.CustomOrigin = CType(arg.TargetNode, NNumericUpDown).Value
        End Sub

        Private Sub OnOriginModeComboBoxSelectedIndexChanged(ByVal arg As NValueChangeEventArgs)
            m_Area.OriginMode = CType(CType(arg.TargetNode, NComboBox).SelectedIndex, ENSeriesOriginMode)
            m_CustomOriginUpDown.Enabled = m_Area.OriginMode Is ENSeriesOriginMode.CustomOrigin
        End Sub

        Private Sub OnDepthPercentUpDownValueChanged(ByVal arg As NValueChangeEventArgs)
            m_Area.DepthPercent = CSng(CType(arg.TargetNode, NNumericUpDown).Value)
        End Sub

#End Region

#Region "Fields"

        Private m_Area As NAreaSeries
        Private m_CustomOriginUpDown As NNumericUpDown

#End Region

#Region "Schema"

        Public Shared ReadOnly NStandard3DAreaExampleSchema As NSchema

#End Region

#Region "Constants"

        Friend Shared ReadOnly monthValues As Double() = New Double() {16, 19, 16, 15, 18, 19, 24, 21, 22, 17, 19, 15}
        Friend Shared ReadOnly monthLetters As String() = New String() {"J", "F", "M", "A", "M", "J", "J", "A", "S", "O", "N", "D"}

#End Region
    End Class
End Namespace

Imports System

Imports Nevron.Nov.Chart
Imports Nevron.Nov.Chart.Tools
Imports Nevron.Nov.Dom
Imports Nevron.Nov.Graphics
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.Chart
    ''' <summary>
    ''' Point Drop Lines Example
    ''' </summary>
    Public Class N3DPointDropLinesExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' Default constructor
        ''' </summary>
        Public Sub New()

        End Sub
        ''' <summary>
        ''' Static constructor
        ''' </summary>
        Shared Sub New()
            N3DPointDropLinesExampleSchema = NSchema.Create(GetType(N3DPointDropLinesExample), NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            Dim chartViewWithCommandBars As NChartViewWithCommandBars = New NChartViewWithCommandBars()
            Dim chartView = chartViewWithCommandBars.View
            chartView.Surface.CreatePredefinedChart(ENPredefinedChartType.Cartesian)

            ' configure title
            chartView.Surface.Titles(0).Text = "Point Drop Lines"

            ' configure chart
            m_Chart = CType(chartView.Surface.Charts(0), NCartesianChart)
            m_Chart.Enable3D = True
            m_Chart.FitMode = ENCartesianChartFitMode.Aspect
            m_Chart.ModelWidth = CSharpImpl.__Assign(m_Chart.ModelHeight, CSharpImpl.__Assign(m_Chart.ModelHeight, 50))

            m_Chart.Projection.SetPredefinedProjection(ENPredefinedProjection.PerspectiveTilted)
            m_Chart.LightModel.SetPredefinedLightModel(ENPredefinedLightModel.NorthernLights)
            m_Chart.SetPredefinedCartesianAxes(ENPredefinedCartesianAxis.XYZLinear)
            m_Chart.Interactor = New NInteractor(New NTrackballTool())

            ' setup X axis
            Dim scaleX As NLinearScale = New NLinearScale()
            scaleX.MajorGridLines = New NScaleGridLines()
            scaleX.MajorGridLines.Visible = True
            scaleX.MajorGridLines.Stroke.DashStyle = ENDashStyle.Dot
            m_Chart.Axes(ENCartesianAxis.PrimaryX).Scale = scaleX

            ' setup Y axis
            Dim scaleY As NLinearScale = New NLinearScale()
            scaleY.MajorGridLines = New NScaleGridLines()
            scaleY.MajorGridLines.Visible = True
            scaleY.MajorGridLines.Stroke.DashStyle = ENDashStyle.Dot
            m_Chart.Axes(ENCartesianAxis.PrimaryY).Scale = scaleY

            ' add a point series
            m_Point = New NPointSeries()
            m_Point.Name = "Point Series"
            m_Point.DataLabelStyle = New NDataLabelStyle(False)
            m_Point.Fill = New NColorFill(NColor.DarkOrange)
            m_Point.Size = 10
            m_Point.Shape = ENPointShape3D.Sphere
            m_Point.UseXValues = True
            m_Point.UseZValues = True
            m_Chart.Series.Add(m_Point)

            Dim random As Random = New Random()
            Dim dataPoints = m_Point.DataPoints

            For i = 0 To 99 Step 5
                dataPoints.Add(New NPointDataPoint(random.Next(200) - 100, random.Next(200) - 100, random.Next(200) - 100))
            Next

            chartView.Document.StyleSheets.ApplyTheme(New NChartTheme(ENChartPalette.Bright, ENChartPaletteTarget.Series))

            Return chartViewWithCommandBars
        End Function
        Protected Overrides Function CreateExampleControls() As NWidget
            Dim stack As NStackPanel = New NStackPanel()
            Dim group As NUniSizeBoxGroup = New NUniSizeBoxGroup(stack)

            Dim showHorizontalDropLinesCheckBox As NCheckBox = New NCheckBox("Show Horizontal Drop Lines")
            showHorizontalDropLinesCheckBox.CheckedChanged += AddressOf OnShowHorizontalDropLinesCheckBoxCheckedChanged
            showHorizontalDropLinesCheckBox.Checked = True
            stack.Add(showHorizontalDropLinesCheckBox)

            Dim horizontalDropLinesOriginModeCombo As NComboBox = New NComboBox()
            horizontalDropLinesOriginModeCombo.FillFromEnum(Of ENDropLineOriginMode)()
            horizontalDropLinesOriginModeCombo.SelectedIndexChanged += AddressOf OnHorizontalDropLinesOriginModeComboSelectedIndexChanged
            horizontalDropLinesOriginModeCombo.SelectedIndex = CInt(ENDropLineOriginMode.ScaleMin)
            stack.Add(NPairBox.Create("Origin Mode:", horizontalDropLinesOriginModeCombo))

            Dim horizontalDropLinesOriginUpDown As NNumericUpDown = New NNumericUpDown()
            horizontalDropLinesOriginUpDown.ValueChanged += AddressOf OnHorizontalDropLinesOriginUpDownValueChanged
            stack.Add(NPairBox.Create("Origin:", horizontalDropLinesOriginUpDown))

            Dim showVerticalDropLinesCheckBox As NCheckBox = New NCheckBox("Show Vertical Drop Lines")
            showVerticalDropLinesCheckBox.CheckedChanged += AddressOf OnShowVerticalDropLinesCheckBoxCheckedChanged
            showVerticalDropLinesCheckBox.Checked = True
            stack.Add(showVerticalDropLinesCheckBox)

            Dim verticalDropLinesOriginModeCombo As NComboBox = New NComboBox()
            verticalDropLinesOriginModeCombo.FillFromEnum(Of ENDropLineOriginMode)()
            verticalDropLinesOriginModeCombo.SelectedIndexChanged += AddressOf OnVerticalDropLinesOriginModeComboSelectedIndexChanged
            verticalDropLinesOriginModeCombo.SelectedIndex = CInt(ENDropLineOriginMode.ScaleMin)
            stack.Add(NPairBox.Create("Origin Mode:", verticalDropLinesOriginModeCombo))

            Dim verticalDropLinesOriginUpDown As NNumericUpDown = New NNumericUpDown()
            verticalDropLinesOriginUpDown.ValueChanged += AddressOf OnVerticalDropLinesOriginUpDownValueChanged
            verticalDropLinesOriginUpDown.Value = 0
            stack.Add(NPairBox.Create("Origin", verticalDropLinesOriginUpDown))

            Dim showDepthDropLinesCheckBox As NCheckBox = New NCheckBox("Show Depth Drop Lines")
            showDepthDropLinesCheckBox.CheckedChanged += AddressOf OnShowDepthDropLinesCheckBoxCheckedChanged
            showDepthDropLinesCheckBox.Checked = True
            stack.Add(showDepthDropLinesCheckBox)

            Dim depthDropLinesOriginModeCombo As NComboBox = New NComboBox()
            depthDropLinesOriginModeCombo.FillFromEnum(Of ENDropLineOriginMode)()
            depthDropLinesOriginModeCombo.SelectedIndexChanged += AddressOf OnDepthDropLinesOriginModeComboSelectedIndexChanged
            depthDropLinesOriginModeCombo.SelectedIndex = CInt(ENDropLineOriginMode.ScaleMax)
            stack.Add(NPairBox.Create("Origin Mode:", depthDropLinesOriginModeCombo))

            Dim depthDropLinesOriginUpDown As NNumericUpDown = New NNumericUpDown()
            depthDropLinesOriginUpDown.ValueChanged += AddressOf OnDepthDropLinesOriginUpDownValueChanged
            stack.Add(NPairBox.Create("Origin:", depthDropLinesOriginUpDown))

            Return group
        End Function
        Protected Overrides Function GetExampleDescription() As String
            Return "<p>This example demonstrates how to enable point drop lines in 3D.</p>"
        End Function

#End Region

#Region "Event Handlers"

        Private Sub OnHorizontalDropLinesOriginUpDownValueChanged(ByVal arg As NValueChangeEventArgs)
            m_Point.HorizontalDropLineOrigin = CType(arg.TargetNode, NNumericUpDown).Value
        End Sub

        Private Sub OnHorizontalDropLinesOriginModeComboSelectedIndexChanged(ByVal arg As NValueChangeEventArgs)
            m_Point.HorizontalDropLineOriginMode = CType(CType(arg.TargetNode, NComboBox).SelectedIndex, ENDropLineOriginMode)
        End Sub

        Private Sub OnShowHorizontalDropLinesCheckBoxCheckedChanged(ByVal arg As NValueChangeEventArgs)
            m_Point.ShowHorizontalDropLines = CType(arg.TargetNode, NCheckBox).Checked
        End Sub

        Private Sub OnVerticalDropLinesOriginUpDownValueChanged(ByVal arg As NValueChangeEventArgs)
            m_Point.VerticalDropLineOrigin = CType(arg.TargetNode, NNumericUpDown).Value
        End Sub

        Private Sub OnVerticalDropLinesOriginModeComboSelectedIndexChanged(ByVal arg As NValueChangeEventArgs)
            m_Point.VerticalDropLineOriginMode = CType(CType(arg.TargetNode, NComboBox).SelectedIndex, ENDropLineOriginMode)
        End Sub

        Private Sub OnShowVerticalDropLinesCheckBoxCheckedChanged(ByVal arg As NValueChangeEventArgs)
            m_Point.ShowVerticalDropLines = CType(arg.TargetNode, NCheckBox).Checked
        End Sub

        Private Sub OnDepthDropLinesOriginUpDownValueChanged(ByVal arg As NValueChangeEventArgs)
            m_Point.DepthDropLineOrigin = CType(arg.TargetNode, NNumericUpDown).Value
        End Sub

        Private Sub OnDepthDropLinesOriginModeComboSelectedIndexChanged(ByVal arg As NValueChangeEventArgs)
            m_Point.DepthDropLineOriginMode = CType(CType(arg.TargetNode, NComboBox).SelectedIndex, ENDropLineOriginMode)
        End Sub

        Private Sub OnShowDepthDropLinesCheckBoxCheckedChanged(ByVal arg As NValueChangeEventArgs)
            m_Point.ShowDepthDropLines = CType(arg.TargetNode, NCheckBox).Checked
        End Sub

#End Region

#Region "Fields"

        Private m_Point As NPointSeries
        Private m_Chart As NCartesianChart

#End Region

#Region "Schema"

        Public Shared ReadOnly N3DPointDropLinesExampleSchema As NSchema

        Private Class CSharpImpl
            <Obsolete("Please refactor calling code to use normal Visual Basic assignment")>
            Shared Function __Assign(Of T)(ByRef target As T, value As T) As T
                target = value
                Return value
            End Function
        End Class

#End Region
    End Class
End Namespace

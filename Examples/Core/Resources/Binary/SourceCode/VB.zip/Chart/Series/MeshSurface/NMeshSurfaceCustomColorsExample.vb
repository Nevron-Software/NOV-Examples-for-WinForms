Imports System

Imports Nevron.Nov.Chart
Imports Nevron.Nov.Chart.Tools
Imports Nevron.Nov.Dom
Imports Nevron.Nov.Graphics
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.Chart
    ''' <summary>
    ''' Mesh Surface Custom Colors Example
    ''' </summary>
    Public Class NMeshSurfaceCustomColorsExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' Default constructor
        ''' </summary>
        Public Sub New()

        End Sub
        ''' <summary>
        ''' Static constructor
        ''' </summary>
        Shared Sub New()
            NMeshSurfaceCustomColorsExampleSchema = NSchema.Create(GetType(NMeshSurfaceCustomColorsExample), NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            Dim chartViewWithCommandBars As NChartViewWithCommandBars = New NChartViewWithCommandBars()
            Dim chartView = chartViewWithCommandBars.View
            chartView.Surface.CreatePredefinedChart(ENPredefinedChartType.Cartesian)

            ' configure title
            chartView.Surface.Titles(0).Text = "Mesh Surface With Custom Colors"

            ' setup chart
            Dim chart = CType(chartView.Surface.Charts(0), NCartesianChart)
            m_Chart = chart

            chart.Enable3D = True
            chart.ModelWidth = 55.0F
            chart.ModelDepth = 55.0F
            chart.ModelHeight = 55.0F
            chart.Projection.SetPredefinedProjection(ENPredefinedProjection.PerspectiveTilted)
            chart.LightModel.SetPredefinedLightModel(ENPredefinedLightModel.SoftTopLeft)
            chart.Interactor = New NInteractor(New NTrackballTool())

            Dim scale As NLinearScale = chart.Axes(ENCartesianAxis.PrimaryY).Scale
            scale.ViewRangeInflateMode = ENScaleViewRangeInflateMode.None

            ' setup axes
            Dim scaleX As NLinearScale = New NLinearScale()
            chart.Axes(ENCartesianAxis.PrimaryX).Scale = scaleX
            scaleX.MajorGridLines.SetShowAtWall(ENChartWall.Bottom, True)
            scaleX.MajorGridLines.SetShowAtWall(ENChartWall.Back, True)

            Dim scaleZ As NLinearScale = New NLinearScale()
            chart.Axes(ENCartesianAxis.Depth).Scale = scaleZ
            scaleZ.MajorGridLines.SetShowAtWall(ENChartWall.Bottom, True)
            scaleZ.MajorGridLines.SetShowAtWall(ENChartWall.Left, True)

            ' add the surface series
            m_Surface = New NMeshSurfaceSeries()
            chart.Series.Add(m_Surface)

            m_Surface.Name = "Surface"
            m_Surface.LegendView.Mode = ENSeriesLegendMode.SeriesLogic
            m_Surface.FillMode = ENSurfaceFillMode.Zone
            m_Surface.FrameMode = ENSurfaceFrameMode.None
            m_Surface.FlatPositionValue = 0.5
            m_Surface.Data.SetGridSize(20, 20)
            m_Surface.Fill = New NColorFill(NColor.YellowGreen)

            FillData(m_Surface)

            Return chartViewWithCommandBars
        End Function

        Private Sub FillData(ByVal surface As NMeshSurfaceSeries)
            Dim m = 200
            Dim n = 100

            Dim lastM = m - 1
            Dim lastN = n - 1

            Dim centerX As Double = 0
            Dim centerZ As Double = 0
            Dim centerY As Double = 0

            Dim radius1 = 100.0
            Dim radius2 = 10.0

            Dim beginAlpha As Double = 0
            Dim endAlpha = NMath.PI2
            Dim alphaStep = 2 * NMath.PI2 / m

            Dim beginBeta As Double = 0
            Dim endBeta = NMath.PI2
            Dim betaStep = NMath.PI2 / n

            Dim arrPrecomputedData = New NVector2DD(m - 1) {}

            For i = 0 To m - 1
                ' calculate the current angle, its cos and sin
                Dim alpha = If(i = lastM, endAlpha, beginAlpha + i * alphaStep)

                arrPrecomputedData(i).X = Math.Cos(alpha)
                arrPrecomputedData(i).Y = Math.Sin(alpha)
            Next

            Dim vertexIndex = 0

            surface.Data.HasColor = True
            surface.Data.SetGridSize(m, n)

            Dim beginColor = NColor.Red
            Dim endColor = NColor.Blue

            Dim offset As Single = -100

            For j = 0 To n - 1
                ' calculate the current beta angle
                Dim beta = If(j = lastN, endBeta, beginBeta + j * betaStep)
                Dim fCosBeta As Double = CSng(Math.Cos(beta))
                Dim fSinBeta As Double = CSng(Math.Sin(beta))

                offset = -100

                For i = 0 To m - 1
                    Dim fCosAlpha = arrPrecomputedData(i).X
                    Dim fSinAlpha = arrPrecomputedData(i).Y

                    Dim fx = fCosBeta * radius2 + radius1

                    Dim dx = fx * fCosAlpha
                    Dim dz = fx * fSinAlpha
                    Dim dy = -(fSinBeta * radius2)

                    Dim x = centerX + dx
                    Dim y = centerY + dy + offset
                    Dim z = centerZ + dz

                    offset += 1

                    surface.Data.SetValue(i, j, y, x, z)

                    Dim length = Math.Sqrt(dx * dx + dz * dz + dy * dy)
                    surface.Data.SetColor(i, j, InterpolateColors(beginColor, endColor, i / 100.0F)) '(length - (radius1 - radius2)) / radius2));

                    vertexIndex += 1
                Next
            Next
        End Sub

        Public Shared Function InterpolateColors(ByVal color1 As NColor, ByVal color2 As NColor, ByVal factor As Single) As NColor
            If factor > 1.0F Then
                factor = 1.0F
            ElseIf factor < 0.0 Then
                factor = 0.0F
            End If

            Dim r1 As Integer = color1.R
            Dim g1 As Integer = color1.G
            Dim b1 As Integer = color1.B

            Dim r2 As Integer = color2.R
            Dim g2 As Integer = color2.G
            Dim b2 As Integer = color2.B

            Dim num7 As Byte = r1 + (r2 - r1) * factor
            Dim num8 As Byte = g1 + (g2 - g1) * factor
            Dim num9 As Byte = b1 + (b2 - b1) * factor

            Return NColor.FromRGB(num7, num8, num9)
        End Function

        Protected Overrides Function CreateExampleControls() As NWidget
            Dim stack As NStackPanel = New NStackPanel()
            Dim group As NUniSizeBoxGroup = New NUniSizeBoxGroup(stack)

            Dim smoothShadingCheckBox As NCheckBox = New NCheckBox()
            smoothShadingCheckBox.CheckedChanged += AddressOf OnSmoothShadingCheckBoxCheckedChanged
            smoothShadingCheckBox.Checked = False
            smoothShadingCheckBox.HorizontalPlacement = Layout.ENHorizontalPlacement.Left
            stack.Add(NPairBox.Create("Smooth Shading:", smoothShadingCheckBox))

            Return group
        End Function

        Private Sub OnSmoothShadingCheckBoxCheckedChanged(ByVal arg As NValueChangeEventArgs)
            m_Surface.ShadingMode = If(arg.NewValue, ENShadingMode.Smooth, ENShadingMode.Flat)
        End Sub

        Protected Overrides Function GetExampleDescription() As String
            Return "<p>The example demonstrates the ability of the Mesh Surface Series to assign custom color per each individual surface vertex.</p>"
        End Function

#End Region

#Region "Fields"

        Private m_Chart As NChart
        Private m_Surface As NMeshSurfaceSeries

#End Region

#Region "Schema"

        Public Shared ReadOnly NMeshSurfaceCustomColorsExampleSchema As NSchema

#End Region
    End Class
End Namespace

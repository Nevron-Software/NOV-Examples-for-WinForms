Imports System

Imports Nevron.Nov.Chart
Imports Nevron.Nov.Chart.Tools
Imports Nevron.Nov.Dom
Imports Nevron.Nov.Graphics
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.Chart
    ''' <summary>
    ''' Grid Surface Empty data points example
    ''' </summary>
    Public Class NGridSurfaceEmptyDataPointsExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' Default constructor
        ''' </summary>
        Public Sub New()

        End Sub
        ''' <summary>
        ''' Static constructor
        ''' </summary>
        Shared Sub New()
            NGridSurfaceEmptyDataPointsExampleSchema = NSchema.Create(GetType(NGridSurfaceEmptyDataPointsExample), NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            Dim chartViewWithCommandBars As NChartViewWithCommandBars = New NChartViewWithCommandBars()
            Dim chartView = chartViewWithCommandBars.View
            chartView.Surface.CreatePredefinedChart(ENPredefinedChartType.Cartesian)

            ' configure title
            chartView.Surface.Titles(0).Text = "Grid Surface With Empty Data Points"

            ' set a chart title
            chartView.Surface.Titles(0).Text = "Surface With Empty Data Points"

            ' setup chart
            Dim chart = CType(chartView.Surface.Charts(0), NCartesianChart)
            chart.Enable3D = True
            chart.ModelWidth = 60.0F
            chart.ModelDepth = 60.0F
            chart.ModelHeight = 25.0F
            chart.Projection.SetPredefinedProjection(ENPredefinedProjection.PerspectiveTilted)
            chart.LightModel.SetPredefinedLightModel(ENPredefinedLightModel.ShinyTopLeft)
            chart.Interactor = New NInteractor(New NTrackballTool())

            ' setup axes
            Dim ordinalScaleX As NOrdinalScale = New NOrdinalScale()
            ordinalScaleX.MajorGridLines.SetShowAtWall(ENChartWall.Bottom, True)
            ordinalScaleX.MajorGridLines.SetShowAtWall(ENChartWall.Back, True)
            ordinalScaleX.DisplayDataPointsBetweenTicks = False

            Dim ordinalScaleY As NOrdinalScale = New NOrdinalScale()
            ordinalScaleY.MajorGridLines.SetShowAtWall(ENChartWall.Bottom, True)
            ordinalScaleY.MajorGridLines.SetShowAtWall(ENChartWall.Left, True)
            ordinalScaleY.DisplayDataPointsBetweenTicks = False

            ' add the surface series
            m_Surface = New NGridSurfaceSeries()
            chart.Series.Add(m_Surface)
            m_Surface.Name = "Surface"
            m_Surface.LegendView.Mode = ENSeriesLegendMode.SeriesLogic
            m_Surface.FlatPositionValue = 10.0
            m_Surface.Data.SetGridSize(40, 40)
            m_Surface.Palette = New NAxisTicksPalette()
            m_Surface.Palette.InterpolateColors = False

            FillData(m_Surface)

            Return chartViewWithCommandBars
        End Function

        Private Sub FillData(ByVal surface As NGridSurfaceSeries)
            Dim y, x, z As Double
            Dim nCountX = surface.Data.GridSizeX
            Dim nCountZ = surface.Data.GridSizeZ

            Const dIntervalX = 8.0
            Const dIntervalZ = 8.0

            Dim dIncrementX = dIntervalX / nCountX
            Dim dIncrementZ = dIntervalZ / nCountZ

            z = -(dIntervalZ / 2)

            Dim j = 0

            While j < nCountZ
                x = -(dIntervalX / 2)

                Dim i = 0

                While i < nCountX
                    y = Math.Log(Math.Abs(x) * Math.Abs(z))

                    If y > -3 Then
                        surface.Data.SetValue(i, j, y)
                    Else
                        surface.Data.SetValue(i, j, DBNull.Value)
                    End If

                    i += 1
                    x += dIncrementX
                End While

                j += 1
                z += dIncrementZ
            End While
        End Sub

        Protected Overrides Function CreateExampleControls() As NWidget
            Dim stack As NStackPanel = New NStackPanel()
            Dim group As NUniSizeBoxGroup = New NUniSizeBoxGroup(stack)

            Dim frameModeComboBox As NComboBox = New NComboBox()
            frameModeComboBox.FillFromEnum(Of ENSurfaceFrameMode)()
            frameModeComboBox.SelectedIndexChanged += AddressOf OnFrameModeComboBoxSelectedIndexChanged
            frameModeComboBox.SelectedIndex = m_Surface.FrameMode
            stack.Add(NPairBox.Create("Frame Mode:", frameModeComboBox))

            Dim frameColorModeComboBox As NComboBox = New NComboBox()
            frameColorModeComboBox.FillFromEnum(Of ENSurfaceFrameColorMode)()
            frameColorModeComboBox.SelectedIndexChanged += AddressOf OnFrameColorModeComboBoxSelectedIndexChanged
            frameColorModeComboBox.SelectedIndex = m_Surface.FrameColorMode
            stack.Add(NPairBox.Create("Frame Color Mode:", frameColorModeComboBox))

            Return group
        End Function

        Private Sub OnFrameColorModeComboBoxSelectedIndexChanged(ByVal arg As NValueChangeEventArgs)
            m_Surface.FrameColorMode = CType(arg.NewValue, ENSurfaceFrameColorMode)
        End Sub

        Private Sub OnFrameModeComboBoxSelectedIndexChanged(ByVal arg As NValueChangeEventArgs)
            m_Surface.FrameMode = CType(arg.NewValue, ENSurfaceFrameMode)
        End Sub

        Protected Overrides Function GetExampleDescription() As String
            Return "<p>This example demonstrates the surface support for Empty Data Points.</p>"
        End Function

#End Region

#Region "Fields"

        Private m_Surface As NGridSurfaceSeries

#End Region

#Region "Schema"

        Public Shared ReadOnly NGridSurfaceEmptyDataPointsExampleSchema As NSchema

#End Region
    End Class
End Namespace

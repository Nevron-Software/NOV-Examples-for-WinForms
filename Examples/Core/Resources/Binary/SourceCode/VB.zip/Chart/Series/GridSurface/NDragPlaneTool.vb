Imports Nevron.Nov.Chart
Imports Nevron.Nov.Dom
Imports Nevron.Nov.Graphics
Imports Nevron.Nov.UI
Imports System

Namespace Nevron.Nov.Examples.Chart
    Public Enum DragPlaneSurface
        XY
        XZ
        ZY
    End Enum

    <Serializable>
    Public Class NDragPlaneTool
        Inherits NDragTool
#Region "Constructors"

        ''' <summary>
        ''' Initializer constructor
        ''' </summary>
        ''' <paramname="dragPlane"></param>
        Public Sub New(ByVal dragPlane As NDragPlane)
            Enabled = True

            m_DragPlane = dragPlane
            m_OriginalPosition = New NVector3DD()
        End Sub
        ''' <summary>
        ''' Static constructor
        ''' </summary>
        Shared Sub New()
            NDragPlaneToolSchema = NSchema.Create(GetType(NDragPlaneTool), NDragToolSchema)
        End Sub

#End Region

#Region "Properties"

        ''' <summary>
        ''' The freedom plane
        ''' </summary>
        Public Property DragPlaneSurface As DragPlaneSurface
            Get
                Return m_DragPlaneSurface
            End Get
            Set(ByVal value As DragPlaneSurface)
                m_DragPlaneSurface = value
            End Set
        End Property
        ''' <summary>
        ''' Whether to use x locking
        ''' </summary>
        Public Shared ReadOnly Property LockX As Boolean
            Get
                Return (m_LockXKey And NKeyboard.PressedModifiers) <> 0
            End Get
        End Property
        ''' <summary>
        ''' Whether to use Z locking
        ''' </summary>
        Public Shared ReadOnly Property LockZ As Boolean
            Get
                Return (m_LockZKey And NKeyboard.PressedModifiers) <> 0
            End Get
        End Property

#End Region

#Region "Overrides"

        ''' <summary>
        ''' 
        ''' </summary>
        ''' <paramname="args"></param>
        Public Overrides Sub OnMouseMove(ByVal args As NMouseEventArgs)
            MyBase.OnMouseMove(args)

            If IsActive Then
                Dim chart As NCartesianChart = GetFirstAncestor(Of NCartesianChart)()
                Dim viewToScale As NPoint3D

                Select Case m_DragPlaneSurface
                    Case DragPlaneSurface.XY
                        If Not chart.TransformViewToLogical3D(args.CurrentTargetPosition, ENCartesianAxis.PrimaryX, ENCartesianAxis.PrimaryY, ENCartesianAxis.Depth, m_OriginalPosition.Z, viewToScale) Then Return
                    Case DragPlaneSurface.XZ
                        If Not chart.TransformViewToLogical3D(args.CurrentTargetPosition, ENCartesianAxis.PrimaryX, ENCartesianAxis.Depth, ENCartesianAxis.PrimaryY, m_OriginalPosition.Y, viewToScale) Then Return
                    Case DragPlaneSurface.ZY
                        If Not chart.TransformViewToLogical3D(args.CurrentTargetPosition, ENCartesianAxis.Depth, ENCartesianAxis.PrimaryY, ENCartesianAxis.PrimaryX, m_OriginalPosition.X, viewToScale) Then Return
                    Case Else
                        NDebug.Assert(False) ' new drag plane
                        Return
                End Select

                m_DragPlane.LockX = False
                m_DragPlane.LockZ = False

                If LockX Then
                    m_DragPlane.LockX = True
                ElseIf LockZ Then
                    m_DragPlane.LockZ = True
                End If

                m_DragPlane.MovePoint(m_DragPlaneSurface, viewToScale, m_DataPointIndex)
            End If
        End Sub
        ''' <summary>
        ''' Return true if dragging can start
        ''' </summary>
        ''' <paramname="args"></param>
        ''' <returns></returns>
        Protected Overrides Function CanActivate(ByVal args As NMouseButtonEventArgs) As Boolean
            If Not MyBase.CanActivate(args) Then Return False

            Dim dataPointIndex = Me.GetDataPointIndexFromPoint(args.CurrentTargetPosition)

            If dataPointIndex = -1 Then Return False

            m_DataPointIndex = dataPointIndex
            m_OriginalPosition = m_DragPlane.GetVectorFromPoint(m_DataPointIndex)

            Return True
        End Function
        ''' <summary>
        ''' Fired when key down is pressed
        ''' </summary>
        ''' <paramname="args"></param>
        Public Overrides Sub OnKeyDown(ByVal args As NKeyEventArgs)
            MyBase.OnKeyDown(args)

            If LockX OrElse LockZ Then
                m_DragPlane.LockX = LockX
                m_DragPlane.LockZ = LockZ

                Dim chart As NCartesianChart = GetFirstAncestor(Of NCartesianChart)()

                Dim dataPointIndex = Me.GetDataPointIndexFromPoint(NMouse.ScreenPosition)

                If dataPointIndex <> -1 Then
                    If LockX Then
                        m_DragPlane.OrientPlaneX(dataPointIndex)
                    ElseIf LockZ Then
                        m_DragPlane.OrientPlaneZ(dataPointIndex)
                    End If
                End If
            End If
        End Sub
        ''' <summary>
        ''' Overriden to rever the state to the original one if the user presses Esc key
        ''' </summary>
        Protected Overrides Sub OnAborted()
            MyBase.OnAborted()

            m_DragPlane.RestorePoint(m_DataPointIndex, m_OriginalPosition)
        End Sub

#End Region

#Region "Implementation"

        ''' <summary>
        ''' Gets the data point from the specified point
        ''' </summary>
        ''' <paramname="point"></param>
        ''' <returns></returns>
        Protected Function GetDataPointIndexFromPoint(ByVal point As NPoint) As Integer
            Dim pointSeries As NPointSeries = m_DragPlane.PointSeries
            Dim chart As NCartesianChart = pointSeries.GetFirstAncestor(Of NCartesianChart)()

            point = chart.TransformViewToModel2D(point)

            Dim xHotSpotArea As Single = 10
            Dim yHotSpotArea As Single = 10

            Dim dataPointIndex = -1

            For i = 0 To pointSeries.DataPoints.Count - 1
                Dim x = pointSeries.DataPoints(i).X
                Dim y = pointSeries.DataPoints(i).Y
                Dim z = pointSeries.DataPoints(i).Z

                Dim viewPoint As NPoint = chart.TransformLogicalToView3D(New NPoint3D(x, y, z), ENCartesianAxis.PrimaryX, ENCartesianAxis.PrimaryY, ENCartesianAxis.Depth)

                If Math.Abs(viewPoint.X - point.X) < xHotSpotArea AndAlso Math.Abs(viewPoint.Y - point.Y) < yHotSpotArea Then
                    dataPointIndex = i
                    Exit For
                End If
            Next

            Return dataPointIndex
        End Function


#End Region

#Region "Fields"

        ''' <summary>
        ''' The original position of the point
        ''' </summary>
        Protected m_OriginalPosition As NVector3DD
        ''' <summary>
        ''' The data point index
        ''' </summary>
        Protected m_DataPointIndex As Integer
        ''' <summary>
        ''' The freedom plane
        ''' </summary>
        Protected m_DragPlaneSurface As DragPlaneSurface
        ''' <summary>
        ''' 
        ''' </summary>
        Protected m_DragPlane As NDragPlane

#End Region

#Region "Static Fields"

        Private Shared m_LockXKey As ENModifierKeys = ENModifierKeys.Shift
        Private Shared m_LockZKey As ENModifierKeys = ENModifierKeys.Alt

        Private Shared NDragPlaneToolSchema As NSchema

#End Region
    End Class
End Namespace

Imports System

Imports Nevron.Nov.Chart
Imports Nevron.Nov.Dom
Imports Nevron.Nov.Graphics
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.Chart
    ''' <summary>
    ''' Demonstrates how to position polar value axes.
    ''' </summary>
    Public Class NPolarValueAxisPositionExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' Default constructor
        ''' </summary>
        Public Sub New()

        End Sub
        ''' <summary>
        ''' Static constructor
        ''' </summary>
        Shared Sub New()
            NPolarValueAxisPositionExampleSchema = NSchema.Create(GetType(NPolarValueAxisPositionExample), NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            Dim chartViewWithCommandBars As NChartViewWithCommandBars = New NChartViewWithCommandBars()
            Dim chartView = chartViewWithCommandBars.View
            chartView.Surface.CreatePredefinedChart(ENPredefinedChartType.Polar)

            ' configure title
            chartView.Surface.Titles(0).Text = "Polar Value Axis Position"

            ' configure chart
            m_Chart = CType(chartView.Surface.Charts(0), NPolarChart)

            m_Chart.SetPredefinedPolarAxes(ENPredefinedPolarAxes.AngleValue)

            ' setup chart
            m_Chart.InnerRadius = 20

            ' setup polar axis
            Dim linearScale As NLinearScale = m_Chart.Axes(ENPolarAxis.PrimaryValue).Scale
            linearScale.ViewRangeInflateMode = ENScaleViewRangeInflateMode.MajorTick
            linearScale.InflateViewRangeBegin = True
            linearScale.InflateViewRangeEnd = True
            linearScale.Labels.OverlapResolveLayouts = New NDomArray(Of ENLevelLabelsLayout)(New ENLevelLabelsLayout() {ENLevelLabelsLayout.AutoScale})

            linearScale.MajorGridLines.Visible = True
            linearScale.MajorGridLines.Stroke.DashStyle = ENDashStyle.Dash

            ' setup polar angle axis
            Dim angularScale As NAngularScale = m_Chart.Axes(ENPolarAxis.PrimaryAngle).Scale

            angularScale.MajorGridLines.Visible = True
            angularScale.Labels.Style.Angle = New NScaleLabelAngle(ENScaleLabelAngleMode.Scale, 0)
            Dim strip As NScaleStrip = New NScaleStrip()
            strip.Fill = New NColorFill(New NColor(192, 192, 192, 125))
            strip.Interlaced = True
            angularScale.Strips.Add(strip)

            ' add a const line
            Dim referenceLine As NAxisReferenceLine = New NAxisReferenceLine()
            referenceLine.Value = 1.0
            referenceLine.Stroke = New NStroke(1, NColor.SlateBlue)
            m_Chart.Axes(ENPolarAxis.PrimaryValue).ReferenceLines.Add(referenceLine)

            ' create a polar line series
            Dim series1 As NPolarLineSeries = New NPolarLineSeries()
            m_Chart.Series.Add(series1)
            series1.Name = "Series 1"
            series1.CloseContour = True
            series1.UseXValues = True
            series1.DataLabelStyle = New NDataLabelStyle(False)

            Dim markerStyle As NMarkerStyle = New NMarkerStyle()
            markerStyle.Visible = False
            markerStyle.Size = New NSize(2, 2)
            series1.MarkerStyle = markerStyle
            Curve1(series1, 50)

            ' create a polar line series
            Dim series2 As NPolarLineSeries = New NPolarLineSeries()
            m_Chart.Series.Add(series2)
            series2.Name = "Series 2"
            series2.CloseContour = True
            series2.UseXValues = True
            series2.DataLabelStyle = New NDataLabelStyle(False)

            markerStyle = New NMarkerStyle()
            markerStyle.Visible = False
            series2.MarkerStyle = markerStyle
            Curve2(series2, 100)

            ' add a second value axes
            m_RedAxis = m_Chart.Axes(ENPolarAxis.PrimaryValue)
            m_GreenAxis = m_Chart.AddCustomAxis(ENPolarAxisOrientation.Value)

            Dim redAxisAnchor As NCrossPolarAxisAnchor = New NCrossPolarAxisAnchor(ENPolarAxisOrientation.Value, ENScaleOrientation.Auto)
            redAxisAnchor.Crossing = New NValueAxisCrossing(m_Chart.Axes(ENPolarAxis.PrimaryAngle), 0.0F)
            m_RedAxis.Anchor = redAxisAnchor

            Dim greenAxisAnchor As NCrossPolarAxisAnchor = New NCrossPolarAxisAnchor(ENPolarAxisOrientation.Value, ENScaleOrientation.Auto)
            greenAxisAnchor.Crossing = New NValueAxisCrossing(m_Chart.Axes(ENPolarAxis.PrimaryAngle), 90)
            m_GreenAxis.Anchor = greenAxisAnchor

            ' color code the axes and series after the stylesheet is applied
            m_RedAxis.Scale.SetColor(NColor.Red)
            m_GreenAxis.Scale.SetColor(NColor.Green)

            series1.Stroke = New NStroke(2, NColor.DarkRed)
            series2.Stroke = New NStroke(2, NColor.DarkGreen)

            series2.ValueAxis = m_GreenAxis

            Return chartViewWithCommandBars
        End Function
        Protected Overrides Function CreateExampleControls() As NWidget
            Dim stack As NStackPanel = New NStackPanel()
            Dim group As NUniSizeBoxGroup = New NUniSizeBoxGroup(stack)

            ' begin angle
            Dim beginAngleUpDown As NNumericUpDown = New NNumericUpDown()
            beginAngleUpDown.ValueChanged += New [Function](Of NValueChangeEventArgs)(AddressOf OnBeginAngleUpDownValueChanged)
            stack.Add(NPairBox.Create("Begin Angle:", beginAngleUpDown))

            ' radian angle step
            Dim radianAngleStepComboBox As NComboBox = New NComboBox()

            radianAngleStepComboBox.Items.Add(New NComboBoxItem("15"))
            radianAngleStepComboBox.Items.Add(New NComboBoxItem("30"))
            radianAngleStepComboBox.Items.Add(New NComboBoxItem("45"))
            radianAngleStepComboBox.Items.Add(New NComboBoxItem("90"))
            radianAngleStepComboBox.SelectedIndexChanged += New [Function](Of NValueChangeEventArgs)(AddressOf OnRadianAngleStepComboBoxSelectedIndexChanged)

            stack.Add(NPairBox.Create("Radian Angle Step", radianAngleStepComboBox))

            ' red axis position
            stack.Add(New NLabel("Red Axis:"))

            If True Then
                Dim dockRedAxisToBottomCheckBox As NCheckBox = New NCheckBox("Dock Bottom")
                dockRedAxisToBottomCheckBox.CheckedChanged += New [Function](Of NValueChangeEventArgs)(AddressOf OnDockRedAxisToBottomCheckBoxCheckedChanged)
                stack.Add(dockRedAxisToBottomCheckBox)

                m_RedAxisAngleUpDown = New NNumericUpDown()
                m_RedAxisAngleUpDown.Value = 0
                m_RedAxisAngleUpDown.ValueChanged += New [Function](Of NValueChangeEventArgs)(AddressOf OnRedAxisAngleUpDownValueChanged)
                stack.Add(NPairBox.Create("Angle:", m_RedAxisAngleUpDown))

                Dim redAxisPaintRefelectionCheckBox As NCheckBox = New NCheckBox("Paint Reflection")
                redAxisPaintRefelectionCheckBox.Checked = True
                redAxisPaintRefelectionCheckBox.CheckedChanged += AddressOf OnRedAxisPaintRefelectionCheckBoxCheckedChanged
                stack.Add(redAxisPaintRefelectionCheckBox)

                m_RedAxisScaleLabelAngleMode = New NComboBox()
                m_RedAxisScaleLabelAngleMode.FillFromEnum(Of ENScaleLabelAngleMode)()
                m_RedAxisScaleLabelAngleMode.SelectedIndex = CInt(ENScaleLabelAngleMode.View)
                m_RedAxisScaleLabelAngleMode.SelectedIndexChanged += New [Function](Of NValueChangeEventArgs)(AddressOf OnUpdateRedAxisSaleLabelAngle)
                stack.Add(NPairBox.Create("Scale Label Angle Mode:", m_RedAxisScaleLabelAngleMode))

                m_RedAxisSaleLabelAngleUpDown = New NNumericUpDown()
                Me.m_RedAxisSaleLabelAngleUpDown.ValueChanged += AddressOf OnUpdateRedAxisSaleLabelAngle
                stack.Add(NPairBox.Create("Scale Label Angle:", m_RedAxisSaleLabelAngleUpDown))

                Dim redAxisBeginPercentUpDown As NNumericUpDown = New NNumericUpDown()
                redAxisBeginPercentUpDown.Value = m_RedAxis.Anchor.BeginPercent
                redAxisBeginPercentUpDown.ValueChanged += New [Function](Of NValueChangeEventArgs)(AddressOf OnRedAxisBeginPercentUpDownValueChanged)
                stack.Add(NPairBox.Create("Begin percent:", redAxisBeginPercentUpDown))

                Dim redAxisEndPercentUpDown As NNumericUpDown = New NNumericUpDown()
                redAxisEndPercentUpDown.Value = m_RedAxis.Anchor.EndPercent
                redAxisEndPercentUpDown.ValueChanged += New [Function](Of NValueChangeEventArgs)(AddressOf OnRedAxisEndPercentUpDownValueChanged)
                stack.Add(NPairBox.Create("End percent:", redAxisEndPercentUpDown))
            End If

            ' green axis position
            stack.Add(New NLabel("Green Axis:"))

            If True Then
                Dim dockGreenAxisToLeftCheckBox As NCheckBox = New NCheckBox("Dock Left")
                dockGreenAxisToLeftCheckBox.CheckedChanged += New [Function](Of NValueChangeEventArgs)(AddressOf OnDockGreenAxisToLeftCheckBoxCheckedChanged)
                stack.Add(dockGreenAxisToLeftCheckBox)

                m_GreenAxisAngleUpDown = New NNumericUpDown()
                m_GreenAxisAngleUpDown.Value = 90
                m_GreenAxisAngleUpDown.ValueChanged += New [Function](Of NValueChangeEventArgs)(AddressOf OnGreenAxisAngleUpDownValueChanged)
                stack.Add(NPairBox.Create("Angle:", m_GreenAxisAngleUpDown))

                Dim greenAxisPaintRefelectionCheckBox As NCheckBox = New NCheckBox("Paint Reflection")
                greenAxisPaintRefelectionCheckBox.Checked = True
                greenAxisPaintRefelectionCheckBox.CheckedChanged += AddressOf OnGreenAxisPaintRefelectionCheckBoxCheckedChanged
                stack.Add(greenAxisPaintRefelectionCheckBox)

                m_GreenAxisScaleLabelAngleMode = New NComboBox()
                m_GreenAxisScaleLabelAngleMode.FillFromEnum(Of ENScaleLabelAngleMode)()
                m_GreenAxisScaleLabelAngleMode.SelectedIndex = CInt(ENScaleLabelAngleMode.View)
                m_GreenAxisScaleLabelAngleMode.SelectedIndexChanged += New [Function](Of NValueChangeEventArgs)(AddressOf OnUpdateGreenAxisSaleLabelAngle)
                stack.Add(NPairBox.Create("Scale Label Angle Mode:", m_GreenAxisScaleLabelAngleMode))

                m_GreenAxisSaleLabelAngleUpDown = New NNumericUpDown()
                Me.m_GreenAxisSaleLabelAngleUpDown.ValueChanged += AddressOf OnUpdateGreenAxisSaleLabelAngle
                stack.Add(NPairBox.Create("Scale Label Angle:", m_GreenAxisSaleLabelAngleUpDown))

                Dim greenAxisBeginPercentUpDown As NNumericUpDown = New NNumericUpDown()
                greenAxisBeginPercentUpDown.Value = m_GreenAxis.Anchor.BeginPercent
                greenAxisBeginPercentUpDown.ValueChanged += New [Function](Of NValueChangeEventArgs)(AddressOf OnGreenAxisBeginPercentUpDownValueChanged)
                stack.Add(NPairBox.Create("Begin percent:", greenAxisBeginPercentUpDown))

                Dim greenAxisEndPercentUpDown As NNumericUpDown = New NNumericUpDown()
                greenAxisEndPercentUpDown.Value = m_GreenAxis.Anchor.EndPercent
                greenAxisEndPercentUpDown.ValueChanged += New [Function](Of NValueChangeEventArgs)(AddressOf OnGreenAxisEndPercentUpDownValueChanged)
                stack.Add(NPairBox.Create("End percent:", greenAxisEndPercentUpDown))
            End If


            Return group
        End Function
        Protected Overrides Function GetExampleDescription() As String
            Return "<p>This example demonstrates how to control the polar value axis position.</p>"
        End Function

#End Region

#Region "Event Handlers"

        Private Sub OnUpdateGreenAxisSaleLabelAngle(ByVal arg As NValueChangeEventArgs)
            TryCast(m_GreenAxis.Scale, NLinearScale).Labels.Style.Angle = New NScaleLabelAngle(m_GreenAxisScaleLabelAngleMode.SelectedIndex, m_GreenAxisSaleLabelAngleUpDown.Value)
        End Sub

        Private Sub OnGreenAxisPaintRefelectionCheckBoxCheckedChanged(ByVal arg As NValueChangeEventArgs)
            m_GreenAxis.PaintReflection = CType(arg.TargetNode, NCheckBox).Checked
        End Sub

        Private Sub OnGreenAxisEndPercentUpDownValueChanged(ByVal arg As NValueChangeEventArgs)
            m_GreenAxis.Anchor.EndPercent = CSng(CType(arg.TargetNode, NNumericUpDown).Value)
        End Sub

        Private Sub OnGreenAxisBeginPercentUpDownValueChanged(ByVal arg As NValueChangeEventArgs)
            m_GreenAxis.Anchor.BeginPercent = CSng(CType(arg.TargetNode, NNumericUpDown).Value)
        End Sub

        Private Sub OnGreenAxisAngleUpDownValueChanged(ByVal arg As NValueChangeEventArgs)
            Dim valueCrossPolarAnchor As NCrossPolarAxisAnchor = TryCast(m_GreenAxis.Anchor, NCrossPolarAxisAnchor)

            If valueCrossPolarAnchor IsNot Nothing Then
                CType(valueCrossPolarAnchor.Crossing, NValueAxisCrossing).Value = m_GreenAxisAngleUpDown.Value
            End If
        End Sub

        Private Sub OnDockGreenAxisToLeftCheckBoxCheckedChanged(ByVal arg As NValueChangeEventArgs)
            If CType(arg.TargetNode, NCheckBox).Checked Then
                m_GreenAxis.Anchor = New NDockPolarAxisAnchor(ENPolarAxisDockZone.Left)
                m_GreenAxisAngleUpDown.Enabled = False
            Else
                Dim anchor As NCrossPolarAxisAnchor = New NCrossPolarAxisAnchor(ENPolarAxisOrientation.Value, ENScaleOrientation.Auto)
                anchor.Crossing = New NValueAxisCrossing(m_Chart.Axes(ENPolarAxis.PrimaryAngle), m_GreenAxisAngleUpDown.Value)

                m_GreenAxis.Anchor = anchor
                m_GreenAxisAngleUpDown.Enabled = True
            End If
        End Sub

        Private Sub OnUpdateRedAxisSaleLabelAngle(ByVal arg As NValueChangeEventArgs)
            TryCast(m_RedAxis.Scale, NLinearScale).Labels.Style.Angle = New NScaleLabelAngle(m_RedAxisScaleLabelAngleMode.SelectedIndex, m_RedAxisSaleLabelAngleUpDown.Value)
        End Sub

        Private Sub OnRedAxisPaintRefelectionCheckBoxCheckedChanged(ByVal arg As NValueChangeEventArgs)
            m_RedAxis.PaintReflection = CType(arg.TargetNode, NCheckBox).Checked
        End Sub

        Private Sub OnRedAxisEndPercentUpDownValueChanged(ByVal arg As NValueChangeEventArgs)
            m_RedAxis.Anchor.EndPercent = CSng(CType(arg.TargetNode, NNumericUpDown).Value)
        End Sub

        Private Sub OnRedAxisBeginPercentUpDownValueChanged(ByVal arg As NValueChangeEventArgs)
            m_RedAxis.Anchor.BeginPercent = CSng(CType(arg.TargetNode, NNumericUpDown).Value)
        End Sub

        Private Sub OnRedAxisAngleUpDownValueChanged(ByVal arg As NValueChangeEventArgs)
            Dim valueCrossPolarAnchor As NCrossPolarAxisAnchor = TryCast(m_RedAxis.Anchor, NCrossPolarAxisAnchor)

            If valueCrossPolarAnchor IsNot Nothing Then
                CType(valueCrossPolarAnchor.Crossing, NValueAxisCrossing).Value = m_RedAxisAngleUpDown.Value
            End If
        End Sub

        Private Sub OnDockRedAxisToBottomCheckBoxCheckedChanged(ByVal arg As NValueChangeEventArgs)
            If CType(arg.TargetNode, NCheckBox).Checked Then
                m_RedAxis.Anchor = New NDockPolarAxisAnchor(ENPolarAxisDockZone.Bottom)
                m_RedAxisAngleUpDown.Enabled = False
            Else
                Dim anchor As NCrossPolarAxisAnchor = New NCrossPolarAxisAnchor(ENPolarAxisOrientation.Value, ENScaleOrientation.Auto)
                anchor.Crossing = New NValueAxisCrossing(m_Chart.Axes(ENPolarAxis.PrimaryAngle), m_RedAxisAngleUpDown.Value)

                m_RedAxis.Anchor = anchor
                m_RedAxisAngleUpDown.Enabled = True
            End If
        End Sub

        Private Sub OnRadianAngleStepComboBoxSelectedIndexChanged(ByVal arg As NValueChangeEventArgs)
            Dim angleScale As NAngularScale = m_Chart.Axes(ENPolarAxis.PrimaryAngle).Scale

            angleScale.MajorTickMode = ENMajorTickMode.CustomStep

            Select Case CType(arg.TargetNode, NComboBox).SelectedIndex
                Case 0
                    angleScale.CustomStep = New NAngle(15, NUnit.Degree)

                Case 1
                    angleScale.CustomStep = New NAngle(30, NUnit.Degree)

                Case 2
                    angleScale.CustomStep = New NAngle(45, NUnit.Degree)
                Case 3
                    angleScale.CustomStep = New NAngle(90, NUnit.Degree)
                Case Else
                    NDebug.Assert(False)
            End Select
        End Sub

        Private Sub OnBeginAngleUpDownValueChanged(ByVal arg As NValueChangeEventArgs)
            m_Chart.BeginAngle = New NAngle(CType(arg.TargetNode, NNumericUpDown).Value, NUnit.Degree)
        End Sub

#End Region

#Region "Implementation"

        Friend Shared Sub Curve1(ByVal series As NPolarLineSeries, ByVal count As Integer)
            series.DataPoints.Clear()

            Dim angleStep = 2 * Math.PI / count

            For i = 0 To count - 1
                Dim angle = i * angleStep
                Dim radius = 1 + Math.Cos(angle)

                series.DataPoints.Add(New NPolarLineDataPoint(angle * 180.0 / Math.PI, radius))
            Next
        End Sub

        Friend Shared Sub Curve2(ByVal series As NPolarLineSeries, ByVal count As Integer)
            series.DataPoints.Clear()

            Dim angleStep = 2 * Math.PI / count

            For i = 0 To count - 1
                Dim angle = i * angleStep
                Dim radius = 0.2 + 1.7 * Math.Sin(2 * angle) + 1.7 * Math.Cos(2 * angle)

                radius = Math.Abs(radius)

                series.DataPoints.Add(New NPolarLineDataPoint(angle * 180.0 / Math.PI, radius))
            Next
        End Sub

#End Region

#Region "Fields"

        Private m_Chart As NPolarChart

        Private m_RedAxis As NPolarAxis
        Private m_GreenAxis As NPolarAxis

        Private m_RedAxisAngleUpDown As NNumericUpDown
        Private m_GreenAxisAngleUpDown As NNumericUpDown

        Private m_RedAxisSaleLabelAngleUpDown As NNumericUpDown
        Private m_RedAxisScaleLabelAngleMode As NComboBox

        Private m_GreenAxisSaleLabelAngleUpDown As NNumericUpDown
        Private m_GreenAxisScaleLabelAngleMode As NComboBox

#End Region

#Region "Schema"

        Public Shared ReadOnly NPolarValueAxisPositionExampleSchema As NSchema

#End Region
    End Class
End Namespace

Imports System
Imports Nevron.Nov.Chart
Imports Nevron.Nov.Dom
Imports Nevron.Nov.Graphics
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.Chart
    ''' <summary>
    ''' Automatic Scale Breaks Example
    ''' </summary>
    Public Class NAutomaticScaleBreaksExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' Default constructor
        ''' </summary>
        Public Sub New()
        End Sub
        ''' <summary>
        ''' Static constructor
        ''' </summary>
        Shared Sub New()
            NAutomaticScaleBreaksExampleSchema = NSchema.Create(GetType(NAutomaticScaleBreaksExample), NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            Dim chartView As NChartView = CreateCartesianChartView()

            ' configure title
            chartView.Surface.Titles(0).Text = "Automatic Scale Breaks"

            ' configure chart
            m_Chart = CType(chartView.Surface.Charts(0), NCartesianChart)

            ' configure axes
            m_Chart.SetPredefinedCartesianAxes(ENPredefinedCartesianAxis.XOrdinalYLinear)

            ' configure scale
            Dim yScale = CType(m_Chart.Axes(ENCartesianAxis.PrimaryY).Scale, NLinearScale)
            yScale.ViewRangeInflateMode = ENScaleViewRangeInflateMode.MajorTick
            yScale.MinTickDistance = 30

            ' add an interlaced strip to the Y axis
            Dim interlacedStrip As NScaleStrip = New NScaleStrip()
            interlacedStrip.Interlaced = True
            interlacedStrip.Fill = New NColorFill(NColor.Beige)
            yScale.Strips.Add(interlacedStrip)
            OnChangeDataButtonClick(Nothing)
            chartView.Document.StyleSheets.ApplyTheme(New NChartTheme(ENChartPalette.Bright, False))
            Return chartView
        End Function

        Protected Overrides Function CreateExampleControls() As NWidget
            Dim stack As NStackPanel = New NStackPanel()
            Dim boxGroup As NUniSizeBoxGroup = New NUniSizeBoxGroup(stack)
            m_EnableScaleBreaksCheckBox = New NCheckBox("Enable Scale Breaks")
            AddHandler m_EnableScaleBreaksCheckBox.CheckedChanged, New [Function](Of NValueChangeEventArgs)(AddressOf OnEnableScaleBreaksCheckBoxCheckedChanged)
            stack.Add(m_EnableScaleBreaksCheckBox)
            m_ThresholdUpDown = New NNumericUpDown()
            m_ThresholdUpDown.Step = 0.05
            m_ThresholdUpDown.Maximum = 1
            m_ThresholdUpDown.DecimalPlaces = 2
            AddHandler m_ThresholdUpDown.ValueChanged, New [Function](Of NValueChangeEventArgs)(AddressOf OnThresholdUpDownValueChanged)
            stack.Add(NPairBox.Create("Threshold", m_ThresholdUpDown))
            m_LengthUpDown = New NNumericUpDown()
            AddHandler m_LengthUpDown.ValueChanged, New [Function](Of NValueChangeEventArgs)(AddressOf OnLengthUpDownValueChanged)
            stack.Add(NPairBox.Create("Length", m_LengthUpDown))
            m_MaxBreaksUpDown = New NNumericUpDown()
            AddHandler m_MaxBreaksUpDown.ValueChanged, New [Function](Of NValueChangeEventArgs)(AddressOf OnMaxBreaksUpDownValueChanged)
            stack.Add(NPairBox.Create("Max Breaks", m_MaxBreaksUpDown))
            m_PositionModeComboBox = New NComboBox()
            m_PositionModeComboBox.FillFromEnum(Of ENScaleBreakPositionMode)()
            AddHandler m_PositionModeComboBox.SelectedIndexChanged, New [Function](Of NValueChangeEventArgs)(AddressOf OnPositionModeComboBoxSelectedIndexChanged)
            stack.Add(NPairBox.Create("Position Mode:", m_PositionModeComboBox))
            m_PositionPercentUpDown = New NNumericUpDown()
            m_PositionPercentUpDown.Minimum = 0
            m_PositionPercentUpDown.Maximum = 100
            AddHandler m_PositionPercentUpDown.ValueChanged, New [Function](Of NValueChangeEventArgs)(AddressOf OnPositionPercentUpDownValueChanged)
            stack.Add(NPairBox.Create("Position Percent:", m_PositionPercentUpDown))
            Dim changeDataButton As NButton = New NButton("Change Data")
            AddHandler changeDataButton.Click, New [Function](Of NEventArgs)(AddressOf OnChangeDataButtonClick)
            stack.Add(changeDataButton)

            ' update initial state
            m_EnableScaleBreaksCheckBox.Checked = True
            m_LengthUpDown.Value = 5
            m_ThresholdUpDown.Value = 0.25 ' this is relatively low factor
            m_MaxBreaksUpDown.Value = 1
            m_PositionPercentUpDown.Value = 50
            m_PositionModeComboBox.SelectedIndex = ENScaleBreakPositionMode.Content ' use content mode by default
            Return boxGroup
        End Function

        Protected Overrides Function GetExampleDescription() As String
            Return "<p>This example demonstrates how to add automatic scale breaks.</p>"
        End Function

#End Region

#Region "Event Handlers"

        Private Sub OnChangeDataButtonClick(ByVal arg As NEventArgs)
            m_Chart.Series.Clear()

            ' setup bar series
            Dim bar As NBarSeries = New NBarSeries()
            m_Chart.Series.Add(bar)
            bar.DataLabelStyle = New NDataLabelStyle(False)
            bar.Stroke = New NStroke(1.5F, NColor.DarkGreen)

            ' fill in some data so that it contains several peaks of data
            Dim random As Random = New Random()
            Dim value As Double = 0

            For i = 0 To 25 - 1

                If i < 6 Then
                    value = 600 + random.Next(30)
                ElseIf i < 11 Then
                    value = 200 + random.Next(50)
                ElseIf i < 16 Then
                    value = 400 + random.Next(50)
                ElseIf i < 21 Then
                    value = random.Next(30)
                Else
                    value = random.Next(50)
                End If

                Dim dataPoint As NBarDataPoint = New NBarDataPoint(value)
                dataPoint.Fill = New NStockGradientFill(ColorFromValue(value), NColor.DarkSlateBlue)
                bar.DataPoints.Add(dataPoint)
            Next
        End Sub

        Private Sub OnPositionPercentUpDownValueChanged(ByVal arg As NValueChangeEventArgs)
            UpdateScaleBreak()
        End Sub

        Private Sub OnPositionModeComboBoxSelectedIndexChanged(ByVal arg As NValueChangeEventArgs)
            UpdateScaleBreak()
            m_PositionPercentUpDown.Enabled = m_PositionModeComboBox.SelectedIndex = ENScaleBreakPositionMode.Percent
        End Sub

        Private Sub OnMaxBreaksUpDownValueChanged(ByVal arg As NValueChangeEventArgs)
            UpdateScaleBreak()
        End Sub

        Private Sub OnLengthUpDownValueChanged(ByVal arg As NValueChangeEventArgs)
            UpdateScaleBreak()
        End Sub

        Private Sub OnThresholdUpDownValueChanged(ByVal arg As NValueChangeEventArgs)
            UpdateScaleBreak()
        End Sub

        Private Sub OnEnableScaleBreaksCheckBoxCheckedChanged(ByVal arg As NValueChangeEventArgs)
            UpdateScaleBreak()
            Dim enableControls = m_EnableScaleBreaksCheckBox.Checked
            m_ThresholdUpDown.Enabled = enableControls
            m_LengthUpDown.Enabled = enableControls
            m_MaxBreaksUpDown.Enabled = enableControls
            m_PositionModeComboBox.Enabled = enableControls
            m_PositionPercentUpDown.Enabled = enableControls AndAlso m_PositionModeComboBox.SelectedIndex = ENScaleBreakPositionMode.Percent
        End Sub

#End Region

#Region "Implementation"

        Private Sub UpdateScaleBreak()
            Dim scale = CType(m_Chart.Axes(ENCartesianAxis.PrimaryY).Scale, NLinearScale)
            scale.ScaleBreaks.Clear()

            If m_EnableScaleBreaksCheckBox.Checked Then
                Dim scaleBreak As NAutoScaleBreak = New NAutoScaleBreak(m_ThresholdUpDown.Value)
                scaleBreak.Style = ENScaleBreakStyle.Line
                scaleBreak.Length = m_LengthUpDown.Value
                scaleBreak.MaxScaleBreakCount = CInt(m_MaxBreaksUpDown.Value)
                scaleBreak.PositionMode = CType(m_PositionModeComboBox.SelectedIndex, ENScaleBreakPositionMode)
                scaleBreak.Percent = CSng(m_PositionPercentUpDown.Value)
                scale.ScaleBreaks.Add(scaleBreak)
            End If
        End Sub

        Private Shared Function ColorFromValue(ByVal value As Double) As NColor
            Dim beginColor = NColor.LightBlue
            Dim endColor = NColor.DarkSlateBlue
            Dim factor As Single = value / 650.0F
            Dim oneMinusFactor = 1.0F - factor
            Return NColor.FromRGB(CByte(beginColor.R * factor + endColor.R * oneMinusFactor), CByte(beginColor.G * factor + endColor.G * oneMinusFactor), CByte(beginColor.B * factor + endColor.B * oneMinusFactor))
        End Function

#End Region

#Region "Fields"

        Private m_Chart As NCartesianChart
        Private m_EnableScaleBreaksCheckBox As NCheckBox
        Private m_ThresholdUpDown As NNumericUpDown
        Private m_LengthUpDown As NNumericUpDown
        Private m_MaxBreaksUpDown As NNumericUpDown
        Private m_PositionModeComboBox As NComboBox
        Private m_PositionPercentUpDown As NNumericUpDown

#End Region

#Region "Schema"

        Public Shared ReadOnly NAutomaticScaleBreaksExampleSchema As NSchema

#End Region

#Region "Static Methods"

        Private Shared Function CreateCartesianChartView() As NChartView
            Dim chartView As NChartView = New NChartView()
            chartView.Surface.CreatePredefinedChart(ENPredefinedChartType.Cartesian)
            Return chartView
        End Function

#End Region
    End Class
End Namespace

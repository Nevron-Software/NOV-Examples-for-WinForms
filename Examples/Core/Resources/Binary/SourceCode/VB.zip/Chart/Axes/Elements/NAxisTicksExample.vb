Imports System

Imports Nevron.Nov.Chart
Imports Nevron.Nov.Dom
Imports Nevron.Nov.Graphics
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.Chart
    ''' <summary>
    ''' Axis ticks example.
    ''' </summary>
    Public Class NAxisTicksExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' Default constructor
        ''' </summary>
        Public Sub New()

        End Sub
        ''' <summary>
        ''' Static constructor
        ''' </summary>
        Shared Sub New()
            NAxisTicksExampleSchema = NSchema.Create(GetType(NAxisTicksExample), NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            Dim chartViewWithCommandBars As NChartViewWithCommandBars = New NChartViewWithCommandBars()
            Dim chartView = chartViewWithCommandBars.View
            chartView.Surface.CreatePredefinedChart(ENPredefinedChartType.Cartesian)

            chartView.Surface.Titles(0).Text = "Axis Ticks"

            ' configure chart
            m_Chart = CType(chartView.Surface.Charts(0), NCartesianChart)

            ' configure axes
            m_Chart.SetPredefinedCartesianAxes(ENPredefinedCartesianAxis.XOrdinalYLinear)
            Dim scaleY As NLinearScale = m_Chart.Axes(ENCartesianAxis.PrimaryY).Scale
            scaleY.MinorTickCount = 1
            scaleY.InnerMinorTicks.Visible = True
            scaleY.InnerMinorTicks.Stroke = New NStroke(1, NColor.Black)
            scaleY.InnerMinorTicks.Length = 5

            scaleY.OuterMinorTicks.Visible = True
            scaleY.OuterMinorTicks.Stroke = New NStroke(1, NColor.Black)
            scaleY.OuterMinorTicks.Length = 5

            scaleY.InnerMajorTicks.Visible = True
            scaleY.InnerMajorTicks.Stroke = New NStroke(1, NColor.Black)

            ' add interlaced stripe
            Dim strip As NScaleStrip = New NScaleStrip(New NColorFill(NColor.Beige), Nothing, True, 0, 0, 1, 1)
            strip.Interlaced = True
            scaleY.Strips.Add(strip)

            Dim scaleX As NOrdinalScale = m_Chart.Axes(ENCartesianAxis.PrimaryX).Scale

            ' create dummy data
            Dim bar As NBarSeries = New NBarSeries()
            bar.Name = "Bars"
            Dim random As Random = New Random()
            For i = 0 To 9
                bar.DataPoints.Add(New NBarDataPoint(random.Next(100)))
            Next

            m_Chart.Series.Add(bar)

            chartView.Document.StyleSheets.ApplyTheme(New NChartTheme(ENChartPalette.Bright, ENChartPaletteTarget.Series))

            Return chartViewWithCommandBars
        End Function
        Protected Overrides Function CreateExampleControls() As NWidget
            Dim stack As NStackPanel = New NStackPanel()
            Dim boxGroup As NUniSizeBoxGroup = New NUniSizeBoxGroup(stack)

            stack.Add(New NLabel("Major Outer Ticks"))

            Dim majorOuterTickColor As NColorBox = New NColorBox()
            majorOuterTickColor.SelectedColorChanged += New [Function](Of NValueChangeEventArgs)(AddressOf OnMajorOuterTickColorSelectedColorChanged)
            stack.Add(NPairBox.Create("Color", majorOuterTickColor))
            majorOuterTickColor.SelectedColor = NColor.Black

            Dim majorOuterTicksLengthNumericUpDown As NNumericUpDown = New NNumericUpDown()
            majorOuterTicksLengthNumericUpDown.ValueChanged += New [Function](Of NValueChangeEventArgs)(AddressOf OnMajorOuterTicksLengthNumericUpDownValueChanged)
            stack.Add(NPairBox.Create("Length", majorOuterTicksLengthNumericUpDown))
            majorOuterTicksLengthNumericUpDown.Value = 10


            stack.Add(New NLabel("Major Inner Ticks"))

            Dim majorInnerTickColor As NColorBox = New NColorBox()
            majorInnerTickColor.SelectedColorChanged += New [Function](Of NValueChangeEventArgs)(AddressOf OnMajorInnerTickColorSelectedColorChanged)
            stack.Add(NPairBox.Create("Color", majorInnerTickColor))
            majorInnerTickColor.SelectedColor = NColor.Black

            Dim majorInnerTicksLengthNumericUpDown As NNumericUpDown = New NNumericUpDown()
            majorInnerTicksLengthNumericUpDown.ValueChanged += New [Function](Of NValueChangeEventArgs)(AddressOf OnMajorInnerTicksLengthNumericUpDownValueChanged)
            stack.Add(NPairBox.Create("Length", majorInnerTicksLengthNumericUpDown))
            majorInnerTicksLengthNumericUpDown.Value = 10

            stack.Add(New NLabel("Minor Inner Ticks"))

            Dim minorInnerTickColor As NColorBox = New NColorBox()
            minorInnerTickColor.SelectedColorChanged += New [Function](Of NValueChangeEventArgs)(AddressOf OnMinorInnerTickColorSelectedColorChanged)
            stack.Add(NPairBox.Create("Color", minorInnerTickColor))
            minorInnerTickColor.SelectedColor = NColor.Black

            Dim minorInnerTicksLengthNumericUpDown As NNumericUpDown = New NNumericUpDown()
            minorInnerTicksLengthNumericUpDown.ValueChanged += New [Function](Of NValueChangeEventArgs)(AddressOf OnMinorInnerTicksLengthNumericUpDownValueChanged)
            stack.Add(NPairBox.Create("Length", minorInnerTicksLengthNumericUpDown))
            minorInnerTicksLengthNumericUpDown.Value = 10

            stack.Add(New NLabel("Minor Outer Ticks"))

            Dim minorOuterTickColor As NColorBox = New NColorBox()
            minorOuterTickColor.SelectedColorChanged += New [Function](Of NValueChangeEventArgs)(AddressOf OnMinorOuterTickColorSelectedColorChanged)
            stack.Add(NPairBox.Create("Color", minorOuterTickColor))
            minorOuterTickColor.SelectedColor = NColor.Black

            Dim minorOuterTicksLengthNumericUpDown As NNumericUpDown = New NNumericUpDown()
            minorOuterTicksLengthNumericUpDown.ValueChanged += New [Function](Of NValueChangeEventArgs)(AddressOf OnMinorOuterTicksLengthNumericUpDownValueChanged)
            stack.Add(NPairBox.Create("Length", minorOuterTicksLengthNumericUpDown))
            minorOuterTicksLengthNumericUpDown.Value = 10

            Return boxGroup
        End Function
        Protected Overrides Function GetExampleDescription() As String
            Return "<p>This example demonstrates how to configure axis ticks.</p>"
        End Function

#End Region

#Region "Event Handlers"

        Private Sub OnMinorOuterTicksLengthNumericUpDownValueChanged(ByVal arg As NValueChangeEventArgs)
            CType(m_Chart.Axes(ENCartesianAxis.PrimaryY).Scale, NLinearScale).OuterMinorTicks.Length = CType(arg.TargetNode, NNumericUpDown).Value
        End Sub

        Private Sub OnMinorInnerTicksLengthNumericUpDownValueChanged(ByVal arg As NValueChangeEventArgs)
            CType(m_Chart.Axes(ENCartesianAxis.PrimaryY).Scale, NLinearScale).InnerMinorTicks.Length = CType(arg.TargetNode, NNumericUpDown).Value
        End Sub

        Private Sub OnMajorOuterTicksLengthNumericUpDownValueChanged(ByVal arg As NValueChangeEventArgs)
            CType(m_Chart.Axes(ENCartesianAxis.PrimaryY).Scale, NLinearScale).OuterMajorTicks.Length = CType(arg.TargetNode, NNumericUpDown).Value
        End Sub

        Private Sub OnMajorInnerTicksLengthNumericUpDownValueChanged(ByVal arg As NValueChangeEventArgs)
            CType(m_Chart.Axes(ENCartesianAxis.PrimaryY).Scale, NLinearScale).InnerMajorTicks.Length = CType(arg.TargetNode, NNumericUpDown).Value
        End Sub

        Private Sub OnMajorInnerTickColorSelectedColorChanged(ByVal arg As NValueChangeEventArgs)
            CType(m_Chart.Axes(ENCartesianAxis.PrimaryY).Scale, NLinearScale).InnerMajorTicks.Stroke = New NStroke(1, CType(arg.TargetNode, NColorBox).SelectedColor)
        End Sub

        Private Sub OnMinorInnerTickColorSelectedColorChanged(ByVal arg As NValueChangeEventArgs)
            CType(m_Chart.Axes(ENCartesianAxis.PrimaryY).Scale, NLinearScale).InnerMinorTicks.Stroke = New NStroke(1, CType(arg.TargetNode, NColorBox).SelectedColor)
        End Sub

        Private Sub OnMajorOuterTickColorSelectedColorChanged(ByVal arg As NValueChangeEventArgs)
            CType(m_Chart.Axes(ENCartesianAxis.PrimaryY).Scale, NLinearScale).OuterMajorTicks.Stroke = New NStroke(1, CType(arg.TargetNode, NColorBox).SelectedColor)
        End Sub

        Private Sub OnMinorOuterTickColorSelectedColorChanged(ByVal arg As NValueChangeEventArgs)
            CType(m_Chart.Axes(ENCartesianAxis.PrimaryY).Scale, NLinearScale).OuterMinorTicks.Stroke = New NStroke(1, CType(arg.TargetNode, NColorBox).SelectedColor)
        End Sub

#End Region

#Region "Fields"

        Private m_Chart As NCartesianChart

#End Region

#Region "Schema"

        Public Shared ReadOnly NAxisTicksExampleSchema As NSchema

#End Region
    End Class
End Namespace

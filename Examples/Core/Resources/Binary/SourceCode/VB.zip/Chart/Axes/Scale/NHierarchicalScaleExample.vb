Imports System

Imports Nevron.Nov.Chart
Imports Nevron.Nov.Dom
Imports Nevron.Nov.Graphics
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.Chart
    ''' <summary>
    ''' Hierarchical Scale Example
    ''' </summary>
    Public Class NHierarchicalScaleExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' Default constructor
        ''' </summary>
        Public Sub New()

        End Sub
        ''' <summary>
        ''' Static constructor
        ''' </summary>
        Shared Sub New()
            NHierarchicalScaleExampleSchema = NSchema.Create(GetType(NHierarchicalScaleExample), NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            Dim chartViewWithCommandBars As NChartViewWithCommandBars = New NChartViewWithCommandBars()
            Dim chartView = chartViewWithCommandBars.View
            chartView.Surface.CreatePredefinedChart(ENPredefinedChartType.Cartesian)

            ' configure title
            chartView.Surface.Titles(0).Text = "Hierarchical Scale"

            ' configure chart
            m_Chart = CType(chartView.Surface.Charts(0), NCartesianChart)

            ' configure axes
            m_Chart.SetPredefinedCartesianAxes(ENPredefinedCartesianAxis.XOrdinalYLinear)

            ' add the first bar
            m_Bar1 = New NBarSeries()
            m_Chart.Series.Add(m_Bar1)
            m_Bar1.Name = "Coca Cola"
            m_Bar1.MultiBarMode = ENMultiBarMode.Series
            m_Bar1.DataLabelStyle = New NDataLabelStyle(False)

            ' add the second bar
            m_Bar2 = New NBarSeries()
            m_Chart.Series.Add(m_Bar2)
            m_Bar2.Name = "Pepsi"
            m_Bar2.MultiBarMode = ENMultiBarMode.Clustered
            m_Bar2.DataLabelStyle = New NDataLabelStyle(False)

            ' add custom labels to the Y axis
            Dim linearScale As NLinearScale = m_Chart.Axes(ENCartesianAxis.PrimaryY).Scale

            ' add interlace stripe
            Dim stripStyle As NScaleStrip = New NScaleStrip(New NColorFill(NColor.Beige), Nothing, True, 0, 0, 1, 1)
            stripStyle.Interlaced = True
            linearScale.Strips.Add(stripStyle)

            chartView.Document.StyleSheets.ApplyTheme(New NChartTheme(ENChartPalette.Bright, ENChartPaletteTarget.Series))

            Return chartViewWithCommandBars
        End Function
        Protected Overrides Function CreateExampleControls() As NWidget
            Dim stack As NStackPanel = New NStackPanel()
            Dim boxGroup As NUniSizeBoxGroup = New NUniSizeBoxGroup(stack)

            m_FirstRowGridStyleComboBox = New NComboBox()
            m_FirstRowGridStyleComboBox.FillFromEnum(Of ENFirstRowGridStyle)()
            m_FirstRowGridStyleComboBox.SelectedIndexChanged += New [Function](Of NValueChangeEventArgs)(AddressOf OnUpdateScale)
            stack.Add(NPairBox.Create("Grid Style:", m_FirstRowGridStyleComboBox))

            m_FirstRowTickModeComboBox = New NComboBox()
            m_FirstRowTickModeComboBox.FillFromEnum(Of ENRangeLabelTickMode)()
            m_FirstRowTickModeComboBox.SelectedIndexChanged += New [Function](Of NValueChangeEventArgs)(AddressOf OnUpdateScale)
            stack.Add(NPairBox.Create("Tick Mode:", m_FirstRowTickModeComboBox))

            m_GroupRowGridStyleComboBox = New NComboBox()
            m_GroupRowGridStyleComboBox.FillFromEnum(Of ENGroupRowGridStyle)()
            m_GroupRowGridStyleComboBox.SelectedIndexChanged += New [Function](Of NValueChangeEventArgs)(AddressOf OnUpdateScale)
            stack.Add(NPairBox.Create("Grid Style:", m_GroupRowGridStyleComboBox))

            m_GroupRowTickModeComboBox = New NComboBox()
            m_GroupRowTickModeComboBox.FillFromEnum(Of ENRangeLabelTickMode)()
            m_GroupRowTickModeComboBox.SelectedIndexChanged += New [Function](Of NValueChangeEventArgs)(AddressOf OnUpdateScale)
            stack.Add(NPairBox.Create("Tick Mode:", m_GroupRowTickModeComboBox))

            m_CreateSeparatorForEachLevelCheckBox = New NCheckBox("Create Separator For Each Level")
            m_CreateSeparatorForEachLevelCheckBox.CheckedChanged += New [Function](Of NValueChangeEventArgs)(AddressOf OnUpdateScale)
            stack.Add(m_CreateSeparatorForEachLevelCheckBox)

            Dim changeDataButton As NButton = New NButton("Change Data")
            changeDataButton.Click += New [Function](Of NEventArgs)(AddressOf OnChangeDataButtonClick)
            stack.Add(changeDataButton)

            m_FirstRowGridStyleComboBox.SelectedIndex = CInt(ENFirstRowGridStyle.Individual)
            m_FirstRowTickModeComboBox.SelectedIndex = CInt(ENRangeLabelTickMode.Separators)
            m_GroupRowGridStyleComboBox.SelectedIndex = CInt(ENGroupRowGridStyle.Individual)
            m_GroupRowTickModeComboBox.SelectedIndex = CInt(ENRangeLabelTickMode.Separators)
            m_CreateSeparatorForEachLevelCheckBox.Checked = True

            OnChangeDataButtonClick(Nothing)
            OnUpdateScale(Nothing)

            Return boxGroup
        End Function
        Protected Overrides Function GetExampleDescription() As String
            Return "<p>This example demonstrates how to create a hierarchical scale.</p>"
        End Function

#End Region

#Region "Event Handlers"

        Private Sub OnChangeDataButtonClick(ByVal arg As NEventArgs)
            ' fill with random data
            m_Bar1.DataPoints.Clear()
            m_Bar2.DataPoints.Clear()

            Dim random As Random = New Random()
            For i = 0 To 23
                m_Bar1.DataPoints.Add(New NBarDataPoint(random.Next(10, 200)))
                m_Bar2.DataPoints.Add(New NBarDataPoint(random.Next(10, 300)))
            Next
        End Sub

        Private Sub OnUpdateScale(ByVal arg As NValueChangeEventArgs)
            ' add custom labels to the X axis
            Dim scale As NHierarchicalScale = New NHierarchicalScale()
            Dim nodes = scale.ChildNodes

            scale.FirstRowGridStyle = CType(m_FirstRowGridStyleComboBox.SelectedIndex, ENFirstRowGridStyle)
            scale.GroupRowGridStyle = CType(m_GroupRowGridStyleComboBox.SelectedIndex, ENGroupRowGridStyle)
            scale.InnerMajorTicks.Visible = False
            scale.OuterMajorTicks.Visible = False

            Dim months = New String() {"Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"}

            For i = 0 To 1
                Dim yearNode As NHierarchicalScaleNode = New NHierarchicalScaleNode(0, (i + 2007).ToString())
                yearNode.LabelStyle.TickMode = CType(m_GroupRowTickModeComboBox.SelectedIndex, ENRangeLabelTickMode)
                nodes.AddChild(yearNode)

                For j = 0 To 3
                    Dim quarterNode As NHierarchicalScaleNode = New NHierarchicalScaleNode(3, "Q" & (j + 1).ToString())
                    quarterNode.LabelStyle.TickMode = CType(m_GroupRowTickModeComboBox.SelectedIndex, ENRangeLabelTickMode)
                    yearNode.Nodes.Add(quarterNode)

                    For k = 0 To 2
                        Dim monthNode As NHierarchicalScaleNode = New NHierarchicalScaleNode(1, months(j * 3 + k))
                        monthNode.LabelStyle.Angle = New NScaleLabelAngle(90)
                        monthNode.LabelStyle.TickMode = CType(m_FirstRowTickModeComboBox.SelectedIndex, ENRangeLabelTickMode)
                        quarterNode.Nodes.Add(monthNode)
                    Next
                Next
            Next

            ' update control state
            m_FirstRowTickModeComboBox.Enabled = m_FirstRowGridStyleComboBox.SelectedIndex Is ENFirstRowGridStyle.Individual
            m_GroupRowTickModeComboBox.Enabled = m_GroupRowGridStyleComboBox.SelectedIndex Is ENGroupRowGridStyle.Individual

            Dim stripStyle As NScaleStrip = New NScaleStrip()
            stripStyle.Length = 3
            stripStyle.Interval = 3
            stripStyle.Fill = New NColorFill(NColor.FromColor(NColor.LightGray, 0.5F))
            scale.Strips.Add(stripStyle)

            scale.CreateSeparatorForEachLevel = m_CreateSeparatorForEachLevelCheckBox.Checked

            m_Chart.Axes(ENCartesianAxis.PrimaryX).Scale = scale
        End Sub

#End Region

#Region "Fields"

        Private m_Chart As NCartesianChart

        Private m_Bar1 As NBarSeries
        Private m_Bar2 As NBarSeries

        Private m_FirstRowGridStyleComboBox As NComboBox
        Private m_FirstRowTickModeComboBox As NComboBox

        Private m_GroupRowGridStyleComboBox As NComboBox
        Private m_GroupRowTickModeComboBox As NComboBox

        Private m_CreateSeparatorForEachLevelCheckBox As NCheckBox

#End Region

#Region "Schema"

        Public Shared ReadOnly NHierarchicalScaleExampleSchema As NSchema

#End Region
    End Class
End Namespace

Imports System
Imports Nevron.Nov.Chart
Imports Nevron.Nov.Dom
Imports Nevron.Nov.Graphics
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.Chart
    ''' <summary>
    ''' Axis docking example
    ''' </summary>
    Public Class NAxisDockingExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' Default constructor
        ''' </summary>
        Public Sub New()
        End Sub
        ''' <summary>
        ''' Static constructor
        ''' </summary>
        Shared Sub New()
            NAxisDockingExampleSchema = NSchema.Create(GetType(NAxisDockingExample), NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            Dim chartView As NChartView = CreateCartesianChartView()

            ' configure title
            chartView.Surface.Titles(0).Text = "Axis Docking"
            Dim chart = CType(chartView.Surface.Charts(0), NCartesianChart)
            m_RedAxis = CreateLinearAxis(ENCartesianAxisDockZone.Left, NColor.Red)
            chart.Axes.Add(m_RedAxis)
            m_GreenAxis = CreateLinearAxis(ENCartesianAxisDockZone.Left, NColor.Green)
            chart.Axes.Add(m_GreenAxis)

            ' Add a custom vertical axis
            m_BlueAxis = CreateLinearAxis(ENCartesianAxisDockZone.Left, NColor.Blue)
            chart.Axes.Add(m_BlueAxis)
            chart.Axes.Add(NCartesianChart.CreateDockedAxis(ENCartesianAxisDockZone.Bottom, ENScaleType.Orindal))

            ' create three line series and dispay them on three vertical axes (red, green and blue axis)
            Dim line1 = CreateLineSeries(NColor.Red, NColor.DarkRed, 10, 20)
            chart.Series.Add(line1)
            Dim line2 = CreateLineSeries(NColor.Green, NColor.DarkGreen, 50, 100)
            chart.Series.Add(line2)
            Dim line3 = CreateLineSeries(NColor.Blue, NColor.DarkBlue, 100, 200)
            chart.Series.Add(line3)
            line1.VerticalAxis = m_RedAxis
            line2.VerticalAxis = m_GreenAxis
            line3.VerticalAxis = m_BlueAxis
            Return chartView
        End Function

        Private Function CreateAxisZoneCombo() As NComboBox
            Dim axisZoneComboBox As NComboBox = New NComboBox()
            axisZoneComboBox.Items.Add(New NComboBoxItem("Left"))
            axisZoneComboBox.Items.Add(New NComboBoxItem("Right"))
            axisZoneComboBox.SelectedIndex = 0
            AddHandler axisZoneComboBox.SelectedIndexChanged, New [Function](Of NValueChangeEventArgs)(AddressOf OnAxisZoneComboBoxSelectedIndexChanged)
            Return axisZoneComboBox
        End Function

        Protected Overrides Function CreateExampleControls() As NWidget
            Dim stack As NStackPanel = New NStackPanel()
            Dim boxGroup As NUniSizeBoxGroup = New NUniSizeBoxGroup(stack)
            m_RedAxisZoneComboBox = CreateAxisZoneCombo()
            stack.Add(NPairBox.Create("Red Axis Dock Zone:", m_RedAxisZoneComboBox))
            m_GreenAxisZoneComboBox = CreateAxisZoneCombo()
            stack.Add(NPairBox.Create("Green Axis Dock Zone:", m_GreenAxisZoneComboBox))
            m_BlueAxisZoneComboBox = CreateAxisZoneCombo()
            stack.Add(NPairBox.Create("Blue Axis Dock Zone:", m_BlueAxisZoneComboBox))
            Return boxGroup
        End Function

        Protected Overrides Function GetExampleDescription() As String
            Return "<p>This example demonstrates how to dock axes to different axis dock zones.</p>"
        End Function

#End Region

#Region "Implementation"

        Private Function CreateLinearAxis(ByVal dockZone As ENCartesianAxisDockZone, ByVal color As NColor) As NCartesianAxis
            Dim axis As NCartesianAxis = New NCartesianAxis()
            axis.Scale = CreateLinearScale(color)
            axis.Anchor = New NDockCartesianAxisAnchor(dockZone)
            Return axis
        End Function

        Private Function CreateLinearScale(ByVal color As NColor) As NLinearScale
            Dim linearScale As NLinearScale = New NLinearScale()
            linearScale.Ruler.Stroke = New NStroke(1, color)
            linearScale.InnerMajorTicks.Stroke = New NStroke(color)
            linearScale.OuterMajorTicks.Stroke = New NStroke(color)
            linearScale.MajorGridLines.Visible = False
            linearScale.Labels.Style.TextStyle.Fill = New NColorFill(color)
            Return linearScale
        End Function

        Private Function CreateLineSeries(ByVal lightColor As NColor, ByVal color As NColor, ByVal begin As Integer, ByVal [end] As Integer) As NLineSeries
            ' Add a line series
            Dim line As NLineSeries = New NLineSeries()

            For i = 0 To 5 - 1
                line.DataPoints.Add(New NLineDataPoint(m_Random.Next(begin, [end])))
            Next

            line.Stroke = New NStroke(2, color)
            Dim dataLabelStyle As NDataLabelStyle = New NDataLabelStyle()
            dataLabelStyle.Format = "<value>"
            dataLabelStyle.TextStyle.Background.Visible = False
            dataLabelStyle.ArrowStroke.Width = 0
            dataLabelStyle.ArrowLength = 10
            dataLabelStyle.TextStyle.Font = New NFont("Arial", 8)
            dataLabelStyle.TextStyle.Background.Visible = True
            line.DataLabelStyle = dataLabelStyle
            Dim markerStyle As NMarkerStyle = New NMarkerStyle()
            markerStyle.Visible = True
            markerStyle.Border = New NStroke(color)
            markerStyle.Fill = New NColorFill(lightColor)
            markerStyle.Shape = ENPointShape.Ellipse
            markerStyle.Size = New NSize(5, 5)
            line.MarkerStyle = markerStyle
            Return line
        End Function

#End Region

#Region "Event Handlers"

        Private Sub OnAxisZoneComboBoxSelectedIndexChanged(ByVal arg As NValueChangeEventArgs)
            If m_RedAxisZoneComboBox.SelectedIndex = 0 Then
                m_RedAxis.Anchor = New NDockCartesianAxisAnchor(ENCartesianAxisDockZone.Left)
            Else
                m_RedAxis.Anchor = New NDockCartesianAxisAnchor(ENCartesianAxisDockZone.Right)
            End If

            If m_GreenAxisZoneComboBox.SelectedIndex = 0 Then
                m_GreenAxis.Anchor = New NDockCartesianAxisAnchor(ENCartesianAxisDockZone.Left)
            Else
                m_GreenAxis.Anchor = New NDockCartesianAxisAnchor(ENCartesianAxisDockZone.Right)
            End If

            If m_BlueAxisZoneComboBox.SelectedIndex = 0 Then
                m_BlueAxis.Anchor = New NDockCartesianAxisAnchor(ENCartesianAxisDockZone.Left)
            Else
                m_BlueAxis.Anchor = New NDockCartesianAxisAnchor(ENCartesianAxisDockZone.Right)
            End If
        End Sub

#End Region

#Region "Fields"

        Private m_Random As Random = New Random()
        Private m_RedAxis As NCartesianAxis
        Private m_GreenAxis As NCartesianAxis
        Private m_BlueAxis As NCartesianAxis
        Private m_RedAxisZoneComboBox As NComboBox
        Private m_GreenAxisZoneComboBox As NComboBox
        Private m_BlueAxisZoneComboBox As NComboBox

#End Region

#Region "Schema"

        Public Shared ReadOnly NAxisDockingExampleSchema As NSchema

#End Region

#Region "Static Methods"

        Private Shared Function CreateCartesianChartView() As NChartView
            Dim chartView As NChartView = New NChartView()
            chartView.Surface.CreatePredefinedChart(ENPredefinedChartType.Cartesian)
            Return chartView
        End Function

#End Region
    End Class
End Namespace

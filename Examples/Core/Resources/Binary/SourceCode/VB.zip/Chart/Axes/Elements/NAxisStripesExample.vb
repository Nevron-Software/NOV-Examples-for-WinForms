Imports Nevron.Nov.Chart
Imports Nevron.Nov.Dom
Imports Nevron.Nov.Graphics
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.Chart
    ''' <summary>
    ''' Axis stripes example
    ''' </summary>
    Public Class NAxisStripesExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' Default constructor
        ''' </summary>
        Public Sub New()
        End Sub
        ''' <summary>
        ''' Static constructor
        ''' </summary>
        Shared Sub New()
            NAxisStripesExampleSchema = NSchema.Create(GetType(NAxisStripesExample), NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            Dim chartView As NChartView = CreateCartesianChartView()

            ' configure title
            chartView.Surface.Titles(0).Text = "Axis Stripes"

            ' configure chart
            Dim chart = CType(chartView.Surface.Charts(0), NCartesianChart)

            ' configure axes
            chart.SetPredefinedCartesianAxes(ENPredefinedCartesianAxis.XOrdinalYLinear)

            ' configure the y scale
            Dim yScale = CType(chart.Axes(ENCartesianAxis.PrimaryY).Scale, NLinearScale)
            Dim stripStyle As NScaleStrip = New NScaleStrip(New NColorFill(NColor.Beige), Nothing, True, 0, 0, 1, 1)
            stripStyle.Interlaced = True
            yScale.Strips.Add(stripStyle)
            yScale.MajorGridLines.Visible = True

            ' Create a point series
            Dim point As NPointSeries = New NPointSeries()
            point.InflateMargins = True
            point.UseXValues = True
            point.Name = "Series 1"
            chart.Series.Add(point)
            Dim dataLabelStyle As NDataLabelStyle = New NDataLabelStyle()
            dataLabelStyle.Visible = False
            point.DataLabelStyle = dataLabelStyle

            ' Add some data
            Dim yValues = New Double() {31, 67, 12, 84, 90}
            Dim xValues = New Double() {5, 36, 51, 76, 93}

            For i = 0 To yValues.Length - 1
                point.DataPoints.Add(New NPointDataPoint(xValues(i), yValues(i)))
            Next

            ' Add a constline for the left axis
            m_XStripe = New NAxisStripe()
            m_XStripe.Fill = New NColorFill(NColor.FromColor(NColor.SteelBlue, 0.5F))
            m_XStripe.Range = New NRange(40, 60)
            m_XStripe.Text = "X Axis Stripe"
            chart.Axes(ENCartesianAxis.PrimaryX).Stripes.Add(m_XStripe)

            ' Add a constline for the bottom axis
            m_YStripe = New NAxisStripe()
            m_YStripe.Fill = New NColorFill(NColor.FromColor(NColor.SteelBlue, 0.5F))
            m_YStripe.Range = New NRange(40, 60)
            m_YStripe.Text = "Y Axis Stripe"
            chart.Axes(ENCartesianAxis.PrimaryY).Stripes.Add(m_YStripe)
            chartView.Document.StyleSheets.ApplyTheme(New NChartTheme(ENChartPalette.Bright, False))
            Return chartView
        End Function

        Protected Overrides Function CreateExampleControls() As NWidget
            Dim stack As NStackPanel = New NStackPanel()
            Dim boxGroup As NUniSizeBoxGroup = New NUniSizeBoxGroup(stack)
            stack.Add(New NLabel("Y Axis Stripe"))
            Dim yStripeBeginValueUpDown As NNumericUpDown = New NNumericUpDown()
            AddHandler yStripeBeginValueUpDown.ValueChanged, AddressOf OnYStripeBeginValueUpDownValueChanged
            yStripeBeginValueUpDown.Value = m_YStripe.Range.Begin
            stack.Add(NPairBox.Create("Begin Value:", yStripeBeginValueUpDown))
            Dim yStripeEndValueUpDown As NNumericUpDown = New NNumericUpDown()
            AddHandler yStripeEndValueUpDown.ValueChanged, AddressOf OnYStripeEndValueUpDownValueChanged
            yStripeEndValueUpDown.Value = m_YStripe.Range.End
            stack.Add(NPairBox.Create("End Value:", yStripeEndValueUpDown))
            Dim yStripeIncludeInAxisRangeCheckBox As NCheckBox = New NCheckBox("Include in Axis Range")
            yStripeIncludeInAxisRangeCheckBox.Checked = False
            AddHandler yStripeIncludeInAxisRangeCheckBox.CheckedChanged, AddressOf OnStripeIncludeInAxisRangeCheckBoxCheckedChanged
            stack.Add(yStripeIncludeInAxisRangeCheckBox)
            Dim yStripePaintAfterSeriesCheckBox As NCheckBox = New NCheckBox("Paint After Series")
            yStripePaintAfterSeriesCheckBox.Checked = m_YStripe.PaintAfterChartContent
            AddHandler yStripePaintAfterSeriesCheckBox.CheckedChanged, AddressOf OnYStripePaintAfterSeriesCheckBoxCheckedChanged
            stack.Add(yStripePaintAfterSeriesCheckBox)
            Dim yTextAlignmentComboBox As NComboBox = New NComboBox()
            yTextAlignmentComboBox.FillFromEnum(Of ENContentAlignment)()
            yTextAlignmentComboBox.SelectedIndex = m_YStripe.TextAlignment
            AddHandler yTextAlignmentComboBox.SelectedIndexChanged, AddressOf OnYTextAlignmentComboBoxSelectedIndexChanged
            stack.Add(NPairBox.Create("Text Alignment:", yTextAlignmentComboBox))
            stack.Add(New NLabel("X Axis Stripe"))
            Dim xStripeBeginValueUpDown As NNumericUpDown = New NNumericUpDown()
            xStripeBeginValueUpDown.Value = m_XStripe.Range.Begin
            AddHandler xStripeBeginValueUpDown.ValueChanged, AddressOf OnXStripeBeginValueUpDownValueChanged
            stack.Add(NPairBox.Create("Begin Value:", xStripeBeginValueUpDown))
            Dim xStripeEndValueUpDown As NNumericUpDown = New NNumericUpDown()
            xStripeEndValueUpDown.Value = m_XStripe.Range.End
            AddHandler xStripeEndValueUpDown.ValueChanged, AddressOf OnXStripeEndValueUpDownValueChanged
            stack.Add(NPairBox.Create("End Value:", xStripeEndValueUpDown))
            Dim xStripeIncludeInAxisRangeCheckBox As NCheckBox = New NCheckBox("Include in Axis Range")
            xStripeIncludeInAxisRangeCheckBox.Checked = False
            AddHandler xStripeIncludeInAxisRangeCheckBox.CheckedChanged, AddressOf OnXStripeIncludeInAxisRangeCheckBoxCheckedChanged
            stack.Add(xStripeIncludeInAxisRangeCheckBox)
            Dim xStripePaintAfterSeriesCheckBox As NCheckBox = New NCheckBox("Paint After Series")
            xStripePaintAfterSeriesCheckBox.Checked = m_XStripe.PaintAfterChartContent
            AddHandler xStripePaintAfterSeriesCheckBox.CheckedChanged, AddressOf OnXStripePaintAfterSeriesCheckBoxCheckedChanged
            stack.Add(xStripePaintAfterSeriesCheckBox)
            Dim xTextAlignmentComboBox As NComboBox = New NComboBox()
            xTextAlignmentComboBox.FillFromEnum(Of ENContentAlignment)()
            xTextAlignmentComboBox.SelectedIndex = m_XStripe.TextAlignment
            AddHandler xTextAlignmentComboBox.SelectedIndexChanged, AddressOf OnXTextAlignmentComboBoxSelectedIndexChanged
            stack.Add(NPairBox.Create("Text Alignment:", xTextAlignmentComboBox))
            Return boxGroup
        End Function

        Protected Overrides Function GetExampleDescription() As String
            Return "<p>This example demonstrates how to configure axis stripes.</p>"
        End Function

#End Region

#Region "Event Handlers"

        Private Sub OnXStripeBeginValueUpDownValueChanged(ByVal arg As NValueChangeEventArgs)
            m_XStripe.Range = New NRange(CType(arg.TargetNode, NNumericUpDown).Value, m_XStripe.Range.End)
        End Sub

        Private Sub OnXStripeEndValueUpDownValueChanged(ByVal arg As NValueChangeEventArgs)
            m_XStripe.Range = New NRange(m_XStripe.Range.Begin, CType(arg.TargetNode, NNumericUpDown).Value)
        End Sub

        Private Sub OnXStripeIncludeInAxisRangeCheckBoxCheckedChanged(ByVal arg As NValueChangeEventArgs)
            Dim isChecked = CType(arg.TargetNode, NCheckBox).Checked
            m_XStripe.IncludeRangeBeginInAxisRange = isChecked
            m_XStripe.IncludeRangeEndInAxisRange = isChecked
        End Sub

        Private Sub OnXStripePaintAfterSeriesCheckBoxCheckedChanged(ByVal arg As NValueChangeEventArgs)
            m_XStripe.PaintAfterChartContent = CType(arg.TargetNode, NCheckBox).Checked
        End Sub

        Private Sub OnXTextAlignmentComboBoxSelectedIndexChanged(ByVal arg As NValueChangeEventArgs)
            m_XStripe.TextAlignment = CType(CType(arg.TargetNode, NComboBox).SelectedIndex, ENContentAlignment)
        End Sub

        Private Sub OnYStripeBeginValueUpDownValueChanged(ByVal arg As NValueChangeEventArgs)
            m_YStripe.Range = New NRange(CType(arg.TargetNode, NNumericUpDown).Value, m_YStripe.Range.End)
        End Sub

        Private Sub OnYStripeEndValueUpDownValueChanged(ByVal arg As NValueChangeEventArgs)
            m_YStripe.Range = New NRange(m_YStripe.Range.Begin, CType(arg.TargetNode, NNumericUpDown).Value)
        End Sub

        Private Sub OnStripeIncludeInAxisRangeCheckBoxCheckedChanged(ByVal arg As NValueChangeEventArgs)
            Dim isChecked = CType(arg.TargetNode, NCheckBox).Checked
            m_YStripe.IncludeRangeBeginInAxisRange = isChecked
            m_YStripe.IncludeRangeEndInAxisRange = isChecked
        End Sub

        Private Sub OnYStripePaintAfterSeriesCheckBoxCheckedChanged(ByVal arg As NValueChangeEventArgs)
            m_YStripe.PaintAfterChartContent = CType(arg.TargetNode, NCheckBox).Checked
        End Sub

        Private Sub OnYTextAlignmentComboBoxSelectedIndexChanged(ByVal arg As NValueChangeEventArgs)
            m_YStripe.TextAlignment = CType(CType(arg.TargetNode, NComboBox).SelectedIndex, ENContentAlignment)
        End Sub

#End Region

#Region "Fields"

        Private m_XStripe As NAxisStripe
        Private m_YStripe As NAxisStripe


#End Region

#Region "Schema"

        Public Shared ReadOnly NAxisStripesExampleSchema As NSchema

#End Region

#Region "Static Methods"

        Private Shared Function CreateCartesianChartView() As NChartView
            Dim chartView As NChartView = New NChartView()
            chartView.Surface.CreatePredefinedChart(ENPredefinedChartType.Cartesian)
            Return chartView
        End Function

#End Region
    End Class
End Namespace

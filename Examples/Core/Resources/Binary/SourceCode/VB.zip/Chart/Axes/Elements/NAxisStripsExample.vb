Imports System

Imports Nevron.Nov.Chart
Imports Nevron.Nov.Dom
Imports Nevron.Nov.Graphics
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.Chart
    ''' <summary>
    ''' Axis stripes example
    ''' </summary>
    Public Class NAxisStripsExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' Default constructor
        ''' </summary>
        Public Sub New()

        End Sub
        ''' <summary>
        ''' Static constructor
        ''' </summary>
        Shared Sub New()
            NAxisStripsExampleSchema = NSchema.Create(GetType(NAxisStripsExample), NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            Dim chartViewWithCommandBars As NChartViewWithCommandBars = New NChartViewWithCommandBars()
            Dim chartView = chartViewWithCommandBars.View
            chartView.Surface.CreatePredefinedChart(ENPredefinedChartType.Cartesian)

            chartView.Surface.Titles(0).Text = "Axis Strips"

            ' configure chart
            Dim chart = CType(chartView.Surface.Charts(0), NCartesianChart)

            ' configure axes
            Dim scaleY As NLinearScale = chart.Axes(ENCartesianAxis.PrimaryY).Scale

            ' add interlaced stripe
            m_Strip = New NScaleStrip(New NColorFill(NColor.DarkGray), Nothing, True, 0, 0, 1, 1)
            m_Strip.Interlaced = True
            scaleY.Strips.Add(m_Strip)

            ' enable the major y grid lines
            scaleY.MajorGridLines = New NScaleGridLines()

            Dim scaleX As NOrdinalScale = chart.Axes(ENCartesianAxis.PrimaryX).Scale

            ' enable the major x grid lines
            scaleX.MajorGridLines = New NScaleGridLines()

            ' create dummy data
            Dim bar As NBarSeries = New NBarSeries()
            bar.Name = "Bars"
            bar.DataLabelStyle = New NDataLabelStyle(False)
            Dim random As Random = New Random()
            For i = 0 To 9
                bar.DataPoints.Add(New NBarDataPoint(random.Next(100)))
            Next

            chart.Series.Add(bar)

            chartView.Document.StyleSheets.ApplyTheme(New NChartTheme(ENChartPalette.Bright, ENChartPaletteTarget.Series))

            Return chartViewWithCommandBars
        End Function
        Protected Overrides Function CreateExampleControls() As NWidget
            Dim stack As NStackPanel = New NStackPanel()
            Dim boxGroup As NUniSizeBoxGroup = New NUniSizeBoxGroup(stack)

            stack.Add(New NLabel("Y Axis Grid"))

            Dim beginUpDown As NNumericUpDown = New NNumericUpDown()
            beginUpDown.ValueChanged += New [Function](Of NValueChangeEventArgs)(AddressOf OnBeginUpDownValueChanged)
            stack.Add(NPairBox.Create("Begin:", beginUpDown))
            beginUpDown.Value = 0

            Dim endUpDown As NNumericUpDown = New NNumericUpDown()
            endUpDown.ValueChanged += New [Function](Of NValueChangeEventArgs)(AddressOf OnEndUpDownValueChanged)
            stack.Add(NPairBox.Create("End:", endUpDown))
            endUpDown.Value = 0

            Dim infiniteCheckBox As NCheckBox = New NCheckBox("Infinite")
            infiniteCheckBox.CheckedChanged += New [Function](Of NValueChangeEventArgs)(AddressOf OnInfiniteCheckBoxCheckedChanged)
            stack.Add(infiniteCheckBox)
            infiniteCheckBox.Checked = True

            Dim lengthUpDown As NNumericUpDown = New NNumericUpDown()
            lengthUpDown.ValueChanged += New [Function](Of NValueChangeEventArgs)(AddressOf OnLengthUpDownValueChanged)
            stack.Add(NPairBox.Create("Length:", lengthUpDown))
            lengthUpDown.Value = 1

            Dim intervalUpDown As NNumericUpDown = New NNumericUpDown()
            intervalUpDown.ValueChanged += New [Function](Of NValueChangeEventArgs)(AddressOf OnIntervalUpDownValueChanged)
            stack.Add(NPairBox.Create("Interval:", intervalUpDown))
            intervalUpDown.Value = 1

            Dim colorBox As NColorBox = New NColorBox()
            colorBox.SelectedColorChanged += New [Function](Of NValueChangeEventArgs)(AddressOf OnColorBoxSelectedColorChanged)
            stack.Add(NPairBox.Create("Color:", colorBox))
            colorBox.SelectedColor = NColor.DarkGray

            Return boxGroup
        End Function
        Protected Overrides Function GetExampleDescription() As String
            Return "<p>This example demonstrates how to configure axis strips.</p>"
        End Function

#End Region

#Region "Event Handlers"

        Private Sub OnIntervalUpDownValueChanged(ByVal arg As NValueChangeEventArgs)
            m_Strip.Interval = CInt(CType(arg.TargetNode, NNumericUpDown).Value)
        End Sub

        Private Sub OnLengthUpDownValueChanged(ByVal arg As NValueChangeEventArgs)
            m_Strip.Length = CInt(CType(arg.TargetNode, NNumericUpDown).Value)
        End Sub

        Private Sub OnColorBoxSelectedColorChanged(ByVal arg As NValueChangeEventArgs)
            m_Strip.Fill = New NColorFill(CType(arg.TargetNode, NColorBox).SelectedColor)
        End Sub

        Private Sub OnInfiniteCheckBoxCheckedChanged(ByVal arg As NValueChangeEventArgs)
            m_Strip.Infinite = CType(arg.TargetNode, NCheckBox).Checked
        End Sub

        Private Sub OnEndUpDownValueChanged(ByVal arg As NValueChangeEventArgs)
            m_Strip.End = CInt(CType(arg.TargetNode, NNumericUpDown).Value)
        End Sub

        Private Sub OnBeginUpDownValueChanged(ByVal arg As NValueChangeEventArgs)
            m_Strip.Begin = CInt(CType(arg.TargetNode, NNumericUpDown).Value)
        End Sub

#End Region

#Region "Fields"

        Private m_Strip As NScaleStrip

#End Region

#Region "Schema"

        Public Shared ReadOnly NAxisStripsExampleSchema As NSchema

#End Region
    End Class
End Namespace

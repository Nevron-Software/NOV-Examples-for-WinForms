Imports System
Imports Nevron.Nov.Chart
Imports Nevron.Nov.Dom
Imports Nevron.Nov.Graphics
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.Chart
    ''' <summary>
    ''' Axis model crossing example
    ''' </summary>
    Public Class NAxisModelCrossingExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' Default constructor
        ''' </summary>
        Public Sub New()
        End Sub
        ''' <summary>
        ''' Static constructor
        ''' </summary>
        Shared Sub New()
            NAxisModelCrossingExampleSchema = NSchema.Create(GetType(NAxisModelCrossingExample), NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        ''' <summary>
        ''' 
        ''' </summary>
        ''' <returns></returns>
        Protected Overrides Function CreateExampleContent() As NWidget
            Dim chartView As NChartView = CreateCartesianChartView()

            ' configure title
            chartView.Surface.Titles(0).Text = "Axis Model Crossing"

            ' configure chart
            m_Chart = CType(chartView.Surface.Charts(0), NCartesianChart)
            m_Chart.SetPredefinedCartesianAxes(ENPredefinedCartesianAxis.XYLinear)
            Dim primaryX = m_Chart.Axes(ENCartesianAxis.PrimaryX)
            Dim primaryY = m_Chart.Axes(ENCartesianAxis.PrimaryY)

            ' configure axes
            Dim yScale = CType(primaryY.Scale, NLinearScale)
            yScale.MajorGridLines = CreateDottedGrid()
            Dim yStrip As NScaleStrip = New NScaleStrip(New NColorFill(New NColor(NColor.LightGray, 40)), Nothing, True, 0, 0, 1, 1)
            yStrip.Interlaced = True
            yScale.Strips.Add(yStrip)
            Dim xScale = CType(primaryX.Scale, NLinearScale)
            xScale.MajorGridLines = CreateDottedGrid()
            Dim xStrip As NScaleStrip = New NScaleStrip(New NColorFill(New NColor(NColor.LightGray, 40)), Nothing, True, 0, 0, 1, 1)
            xStrip.Interlaced = True
            xScale.Strips.Add(xStrip)

            ' cross X and Y axes
            primaryX.Anchor = New NModelCrossCartesianAxisAnchor(0, ENAxisCrossAlignment.Center, primaryY, ENCartesianAxisOrientation.Horizontal, ENScaleOrientation.Right, 0.0F, 100.0F)
            primaryY.Anchor = New NModelCrossCartesianAxisAnchor(0, ENAxisCrossAlignment.Center, primaryX, ENCartesianAxisOrientation.Vertical, ENScaleOrientation.Left, 0.0F, 100.0F)

            ' setup bubble series
            Dim bubble As NBubbleSeries = New NBubbleSeries()
            bubble.Name = "Bubble Series"
            bubble.InflateMargins = True
            bubble.DataLabelStyle = New NDataLabelStyle(False)
            bubble.UseXValues = True

            ' fill with random data
            Dim random As Random = New Random()

            For i = 0 To 10 - 1
                bubble.DataPoints.Add(New NBubbleDataPoint(random.Next(-20, 20), random.Next(-20, 20), random.Next(1, 6)))
            Next

            m_Chart.Series.Add(bubble)
            chartView.Document.StyleSheets.ApplyTheme(New NChartTheme(ENChartPalette.Bright, True))
            Return chartView
        End Function

        ''' <summary>
        ''' 
        ''' </summary>
        ''' <returns></returns>
        Protected Overrides Function CreateExampleControls() As NWidget
            Dim stack As NStackPanel = New NStackPanel()
            Dim boxGroup As NUniSizeBoxGroup = New NUniSizeBoxGroup(stack)
            stack.Add(New NLabel("Vertical Axis"))
            Dim verticalAxisAlignmentComboBox As NComboBox = New NComboBox()
            verticalAxisAlignmentComboBox.FillFromEnum(Of ENAxisCrossAlignment)()
            AddHandler verticalAxisAlignmentComboBox.SelectedIndexChanged, New [Function](Of NValueChangeEventArgs)(AddressOf OnVerticalAxisAlignmentComboBoxSelectedIndexChanged)
            stack.Add(NPairBox.Create("Alignment:", verticalAxisAlignmentComboBox))
            verticalAxisAlignmentComboBox.SelectedIndex = ENAxisCrossAlignment.Center
            Dim verticalAxisOffsetUpDown As NNumericUpDown = New NNumericUpDown()
            AddHandler verticalAxisOffsetUpDown.ValueChanged, New [Function](Of NValueChangeEventArgs)(AddressOf OnVerticalAxisOffsetUpDownValueChanged)
            stack.Add(NPairBox.Create("Offset:", verticalAxisOffsetUpDown))
            stack.Add(New NLabel("Horizontal Axis"))
            Dim horizontalAxisAlignmentComboBox As NComboBox = New NComboBox()
            horizontalAxisAlignmentComboBox.FillFromEnum(Of ENAxisCrossAlignment)()
            AddHandler horizontalAxisAlignmentComboBox.SelectedIndexChanged, New [Function](Of NValueChangeEventArgs)(AddressOf OnHorizontalAxisAlignmentComboBoxSelectedIndexChanged)
            stack.Add(NPairBox.Create("Alignment:", horizontalAxisAlignmentComboBox))
            horizontalAxisAlignmentComboBox.SelectedIndex = ENAxisCrossAlignment.Center
            Dim horizontalAxisOffsetUpDown As NNumericUpDown = New NNumericUpDown()
            AddHandler horizontalAxisOffsetUpDown.ValueChanged, New [Function](Of NValueChangeEventArgs)(AddressOf OnHorizontalAxisOffsetUpDownValueChanged)
            stack.Add(NPairBox.Create("Offset:", horizontalAxisOffsetUpDown))
            Return boxGroup
        End Function

        Protected Overrides Function GetExampleDescription() As String
            Return "<p>This example demonstrates how to cross two axes at a specified model offset.</p>"
        End Function

#End Region

#Region "Event Handlers"

        Private Sub OnHorizontalAxisOffsetUpDownValueChanged(ByVal arg As NValueChangeEventArgs)
            Dim anchor As NModelCrossCartesianAxisAnchor = TryCast(m_Chart.Axes(ENCartesianAxis.PrimaryX).Anchor, NModelCrossCartesianAxisAnchor)
            anchor.Offset = CType(arg.TargetNode, NNumericUpDown).Value
        End Sub

        Private Sub OnVerticalAxisOffsetUpDownValueChanged(ByVal arg As NValueChangeEventArgs)
            Dim anchor As NModelCrossCartesianAxisAnchor = TryCast(m_Chart.Axes(ENCartesianAxis.PrimaryY).Anchor, NModelCrossCartesianAxisAnchor)
            anchor.Offset = CType(arg.TargetNode, NNumericUpDown).Value
        End Sub

        Private Sub OnHorizontalAxisAlignmentComboBoxSelectedIndexChanged(ByVal arg As NValueChangeEventArgs)
            Dim anchor As NModelCrossCartesianAxisAnchor = TryCast(m_Chart.Axes(ENCartesianAxis.PrimaryX).Anchor, NModelCrossCartesianAxisAnchor)
            anchor.Alignment = CType(CType(arg.TargetNode, NComboBox).SelectedIndex, ENAxisCrossAlignment)
        End Sub

        Private Sub OnVerticalAxisAlignmentComboBoxSelectedIndexChanged(ByVal arg As NValueChangeEventArgs)
            Dim anchor As NModelCrossCartesianAxisAnchor = TryCast(m_Chart.Axes(ENCartesianAxis.PrimaryY).Anchor, NModelCrossCartesianAxisAnchor)
            anchor.Alignment = CType(CType(arg.TargetNode, NComboBox).SelectedIndex, ENAxisCrossAlignment)
        End Sub

#End Region

#Region "Implementation"

        Private Function CreateDottedGrid() As NScaleGridLines
            Dim scaleGrid As NScaleGridLines = New NScaleGridLines()
            scaleGrid.Visible = True
            scaleGrid.Stroke.Width = 1
            scaleGrid.Stroke.DashStyle = ENDashStyle.Dot
            scaleGrid.Stroke.Color = NColor.Gray
            Return scaleGrid
        End Function

#End Region

#Region "Fields"

        Private m_Chart As NCartesianChart

#End Region

#Region "Schema"

        Public Shared ReadOnly NAxisModelCrossingExampleSchema As NSchema

#End Region


#Region "Static Methods"

        Private Shared Function CreateCartesianChartView() As NChartView
            Dim chartView As NChartView = New NChartView()
            chartView.Surface.CreatePredefinedChart(ENPredefinedChartType.Cartesian)
            Return chartView
        End Function

#End Region
    End Class
End Namespace

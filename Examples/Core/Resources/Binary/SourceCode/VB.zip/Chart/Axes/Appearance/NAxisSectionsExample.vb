Imports System

Imports Nevron.Nov.Chart
Imports Nevron.Nov.Dom
Imports Nevron.Nov.Graphics
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.Chart
    ''' <summary>
    ''' Axis sections example
    ''' </summary>
    Public Class NAxisSectionsExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' Default constructor
        ''' </summary>
        Public Sub New()

        End Sub
        ''' <summary>
        ''' Static constructor
        ''' </summary>
        Shared Sub New()
            NAxisSectionsExampleSchema = NSchema.Create(GetType(NAxisSectionsExample), NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            Dim chartViewWithCommandBars As NChartViewWithCommandBars = New NChartViewWithCommandBars()
            Dim chartView = chartViewWithCommandBars.View
            chartView.Surface.CreatePredefinedChart(ENPredefinedChartType.Cartesian)

            ' configure title
            chartView.Surface.Titles(0).Text = "Axis Sections"

            m_Chart = CType(chartView.Surface.Charts(0), NCartesianChart)

            m_Chart.SetPredefinedCartesianAxes(ENPredefinedCartesianAxis.XYLinear)

            ' create a point series
            Dim point As NPointSeries = New NPointSeries()
            point.Name = "Point Series"
            point.DataLabelStyle = New NDataLabelStyle(False)
            point.Size = 5

            Dim random As Random = New Random()

            For i = 0 To 29
                point.DataPoints.Add(New NPointDataPoint(random.Next(100), random.Next(100)))
            Next

            point.InflateMargins = True

            m_Chart.Series.Add(point)

            ' tell the x axis to display major and minor grid lines
            Dim linearScale As NLinearScale = New NLinearScale()
            m_Chart.Axes(ENCartesianAxis.PrimaryX).Scale = linearScale
            linearScale.MajorGridLines = New NScaleGridLines()
            linearScale.MajorGridLines.Stroke.DashStyle = ENDashStyle.Solid
            linearScale.MinorGridLines = New NScaleGridLines()
            linearScale.MinorGridLines.Stroke.DashStyle = ENDashStyle.Dot
            linearScale.MinorTickCount = 1

            ' tell the y axis to display major and minor grid lines
            linearScale = New NLinearScale()
            m_Chart.Axes(ENCartesianAxis.PrimaryY).Scale = linearScale
            linearScale.MajorGridLines = New NScaleGridLines()
            linearScale.MajorGridLines.Stroke.DashStyle = ENDashStyle.Solid
            linearScale.MinorGridLines = New NScaleGridLines()
            linearScale.MinorGridLines.Stroke.DashStyle = ENDashStyle.Dot
            linearScale.MinorTickCount = 1

            Dim labelStyle As NTextStyle

            ' configure the first horizontal section
            m_FirstHorizontalSection = New NScaleSection()
            m_FirstHorizontalSection.Range = New NRange(2, 8)
            m_FirstHorizontalSection.RangeFill = New NColorFill(New NColor(NColor.Red, 60))
            m_FirstHorizontalSection.MajorGridStroke = New NStroke(NColor.Red)
            m_FirstHorizontalSection.MajorTickStroke = New NStroke(NColor.DarkRed)
            m_FirstHorizontalSection.MinorTickStroke = New NStroke(1, NColor.Red, ENDashStyle.Dot)

            labelStyle = New NTextStyle()
            labelStyle.Fill = New NStockGradientFill(NColor.Red, NColor.DarkRed)
            labelStyle.Font.Style = ENFontStyle.Bold
            m_FirstHorizontalSection.LabelTextStyle = labelStyle

            ' configure the second horizontal section
            m_SecondHorizontalSection = New NScaleSection()
            m_SecondHorizontalSection.Range = New NRange(14, 18)
            m_SecondHorizontalSection.RangeFill = New NColorFill(New NColor(NColor.Green, 60))
            m_SecondHorizontalSection.MajorGridStroke = New NStroke(NColor.Green)
            m_SecondHorizontalSection.MajorTickStroke = New NStroke(NColor.DarkGreen)
            m_SecondHorizontalSection.MinorTickStroke = New NStroke(1, NColor.Green, ENDashStyle.Dot)

            labelStyle = New NTextStyle()
            labelStyle.Fill = New NStockGradientFill(NColor.Green, NColor.DarkGreen)
            labelStyle.Font.Style = ENFontStyle.Bold
            m_SecondHorizontalSection.LabelTextStyle = labelStyle

            ' configure the first vertical section
            m_FirstVerticalSection = New NScaleSection()
            m_FirstVerticalSection.Range = New NRange(20, 40)
            m_FirstVerticalSection.RangeFill = New NColorFill(New NColor(NColor.Blue, 60))
            m_FirstVerticalSection.MajorGridStroke = New NStroke(NColor.Blue)
            m_FirstVerticalSection.MajorTickStroke = New NStroke(NColor.DarkBlue)
            m_FirstVerticalSection.MinorTickStroke = New NStroke(1, NColor.Blue, ENDashStyle.Dot)

            labelStyle = New NTextStyle()
            labelStyle.Fill = New NStockGradientFill(NColor.Blue, NColor.DarkBlue)
            labelStyle.Font.Style = ENFontStyle.Bold
            m_FirstVerticalSection.LabelTextStyle = labelStyle

            ' configure the second vertical section
            m_SecondVerticalSection = New NScaleSection()
            m_SecondVerticalSection.Range = New NRange(70, 90)
            m_SecondVerticalSection.RangeFill = New NColorFill(New NColor(NColor.Orange, 60))
            m_SecondVerticalSection.MajorGridStroke = New NStroke(NColor.Orange)
            m_SecondVerticalSection.MajorTickStroke = New NStroke(NColor.DarkOrange)
            m_SecondVerticalSection.MinorTickStroke = New NStroke(1, NColor.Orange, ENDashStyle.Dot)

            labelStyle = New NTextStyle()
            labelStyle.Fill = New NStockGradientFill(NColor.Orange, NColor.DarkOrange)
            labelStyle.Font.Style = ENFontStyle.Bold
            m_SecondVerticalSection.LabelTextStyle = labelStyle

            chartView.Document.StyleSheets.ApplyTheme(New NChartTheme(ENChartPalette.Bright, ENChartPaletteTarget.Series))

            Return chartViewWithCommandBars
        End Function
        Protected Overrides Function CreateExampleControls() As NWidget
            Dim stack As NStackPanel = New NStackPanel()
            Dim boxGroup As NUniSizeBoxGroup = New NUniSizeBoxGroup(stack)

            m_ShowFirstYSectionCheckBox = New NCheckBox("Show Y Section [20, 40]")
            stack.Add(m_ShowFirstYSectionCheckBox)
            m_ShowFirstYSectionCheckBox.Checked = True

            m_ShowSecondYSectionCheckBox = New NCheckBox("Show Y Section [70, 90]")
            stack.Add(m_ShowSecondYSectionCheckBox)
            m_ShowSecondYSectionCheckBox.Checked = True

            m_ShowFirstXSectionCheckBox = New NCheckBox("Show X Section [2, 8]")
            stack.Add(m_ShowFirstXSectionCheckBox)
            m_ShowFirstXSectionCheckBox.Checked = True

            m_ShowSecondXSectionCheckBox = New NCheckBox("Show X Section [14, 18]")
            stack.Add(m_ShowSecondXSectionCheckBox)
            m_ShowSecondXSectionCheckBox.Checked = True

            m_ShowFirstYSectionCheckBox.CheckedChanged += New [Function](Of NValueChangeEventArgs)(AddressOf OnUpdateSections)
            m_ShowSecondYSectionCheckBox.CheckedChanged += New [Function](Of NValueChangeEventArgs)(AddressOf OnUpdateSections)
            m_ShowFirstXSectionCheckBox.CheckedChanged += New [Function](Of NValueChangeEventArgs)(AddressOf OnUpdateSections)
            m_ShowSecondXSectionCheckBox.CheckedChanged += New [Function](Of NValueChangeEventArgs)(AddressOf OnUpdateSections)

            OnUpdateSections(Nothing)

            Return boxGroup
        End Function
        Protected Overrides Function GetExampleDescription() As String
            Return "<p>This example demonstrates axis sections. Axis sections allow you to alter the appearance of different axis elements if they fall in a specified range.</p>"
        End Function

#End Region

#Region "Event Handlers"

        Private Sub OnUpdateSections(ByVal arg As NValueChangeEventArgs)
            Dim standardScale As NStandardScale

            ' configure horizontal axis sections
            standardScale = m_Chart.Axes(ENCartesianAxis.PrimaryX).Scale
            standardScale.Sections.Clear()

            If m_ShowFirstXSectionCheckBox.Checked Then
                standardScale.Sections.Add(m_FirstHorizontalSection)
            End If

            If m_ShowSecondXSectionCheckBox.Checked Then
                standardScale.Sections.Add(m_SecondHorizontalSection)
            End If

            ' configure vertical axis sections
            standardScale = m_Chart.Axes(ENCartesianAxis.PrimaryY).Scale
            standardScale.Sections.Clear()

            If m_ShowFirstYSectionCheckBox.Checked Then
                standardScale.Sections.Add(m_FirstVerticalSection)
            End If

            If m_ShowSecondYSectionCheckBox.Checked Then
                standardScale.Sections.Add(m_SecondVerticalSection)
            End If
        End Sub

#End Region

#Region "Fields"

        Private m_Chart As NCartesianChart

        Private m_ShowFirstYSectionCheckBox As NCheckBox
        Private m_ShowSecondYSectionCheckBox As NCheckBox
        Private m_ShowFirstXSectionCheckBox As NCheckBox
        Private m_ShowSecondXSectionCheckBox As NCheckBox

        Private m_FirstVerticalSection As NScaleSection
        Private m_SecondVerticalSection As NScaleSection
        Private m_FirstHorizontalSection As NScaleSection
        Private m_SecondHorizontalSection As NScaleSection

#End Region

#Region "Schema"

        Public Shared ReadOnly NAxisSectionsExampleSchema As NSchema

#End Region
    End Class
End Namespace

Imports Nevron.Nov.Chart
Imports Nevron.Nov.Dom
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.Chart
    ''' <summary>
    ''' Axis labels orientation example
    ''' </summary>
    Public Class NAxisLabelsOrientationtExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' Default constructor
        ''' </summary>
        Public Sub New()
        End Sub
        ''' <summary>
        ''' Static constructor
        ''' </summary>
        Shared Sub New()
            NAxisLabelsOrientationtExampleSchema = NSchema.Create(GetType(NAxisLabelsOrientationtExample), NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            m_ChartView = CreateCartesianChartView()

            ' configure title
            m_ChartView.Surface.Titles(0).Text = "Axis Labels Orientation"

            ' configure chart
            m_Chart = CType(m_ChartView.Surface.Charts(0), NCartesianChart)
            m_Chart.SetPredefinedCartesianAxes(ENPredefinedCartesianAxis.PrimaryAndSecondaryLinear)

            For i = 0 To m_Chart.Axes.Count - 1
                ' configure the axes
                Dim axis = m_Chart.Axes(i)

                ' set the range to [0, 100]
                axis.ViewRangeMode = ENAxisViewRangeMode.FixedRange
                axis.MinViewRangeValue = 0
                axis.MaxViewRangeValue = 100
                Dim linearScale = CType(axis.Scale, NLinearScale)
                Dim title = String.Empty

                Select Case i
                    Case 0
                        title = "Primary Y"
                    Case 1
                        title = "Primary X"
                    Case 2
                        title = "Secondary Y"
                    Case 3
                        title = "Secondary X"
                End Select

                linearScale.Title.Text = title
                linearScale.MinTickDistance = 30
                linearScale.Labels.Style.Angle = New NScaleLabelAngle(ENScaleLabelAngleMode.Scale, 0, False)
                linearScale.Labels.Style.AlwaysInsideScale = True
                linearScale.Labels.OverlapResolveLayouts = New NDomArray(Of ENLevelLabelsLayout)(New ENLevelLabelsLayout() {ENLevelLabelsLayout.Stagger2})
            Next

            m_ChartView.Document.StyleSheets.ApplyTheme(New NChartTheme(ENChartPalette.Bright, False))
            Return m_ChartView
        End Function

        Protected Overrides Function CreateExampleControls() As NWidget
            Dim stack As NStackPanel = New NStackPanel()
            Dim boxGroup As NUniSizeBoxGroup = New NUniSizeBoxGroup(stack)
            Dim orientationComboBox As NComboBox = New NComboBox()
            orientationComboBox.FillFromEnum(Of ENCartesianChartOrientation)()
            orientationComboBox.SelectedIndex = m_Chart.Orientation
            AddHandler orientationComboBox.SelectedIndexChanged, New [Function](Of NValueChangeEventArgs)(AddressOf OnOrientationComboBoxSelectedIndexChanged)
            stack.Add(NPairBox.Create("Orientation:", orientationComboBox))
            m_AngleModeComboBox = New NComboBox()
            m_AngleModeComboBox.FillFromEnum(Of ENScaleLabelAngleMode)()
            m_AngleModeComboBox.SelectedIndex = ENScaleLabelAngleMode.Scale
            AddHandler m_AngleModeComboBox.SelectedIndexChanged, New [Function](Of NValueChangeEventArgs)(AddressOf OnAxisLabelChanged)
            stack.Add(NPairBox.Create("Angle Mode:", m_AngleModeComboBox))
            m_CustomAngleNumericUpDown = New NNumericUpDown()
            m_CustomAngleNumericUpDown.Minimum = 0
            m_CustomAngleNumericUpDown.Maximum = 360
            m_CustomAngleNumericUpDown.Value = 0
            AddHandler m_CustomAngleNumericUpDown.ValueChanged, New [Function](Of NValueChangeEventArgs)(AddressOf OnAxisLabelChanged)
            stack.Add(NPairBox.Create("Custom Angle:", m_CustomAngleNumericUpDown))
            m_AllowLabelsToFlipCheckBox = New NCheckBox("Allow Label To Flip")
            m_AllowLabelsToFlipCheckBox.Checked = False
            AddHandler m_AllowLabelsToFlipCheckBox.CheckedChanged, New [Function](Of NValueChangeEventArgs)(AddressOf OnAxisLabelChanged)
            stack.Add(m_AllowLabelsToFlipCheckBox)
            Return boxGroup
        End Function

        Protected Overrides Function GetExampleDescription() As String
            Return "<p>This example demonstrates how to change the orientation of axis labels.</p>"
        End Function

#End Region

#Region "Event Handlers"

        Private Sub OnOrientationComboBoxSelectedIndexChanged(ByVal arg As NValueChangeEventArgs)
            m_Chart.Orientation = CType(CType(arg.TargetNode, NComboBox).SelectedIndex, ENCartesianChartOrientation)
        End Sub

        Private Sub OnAxisLabelChanged(ByVal arg As NValueChangeEventArgs)
            Dim chart = CType(m_ChartView.Surface.Charts(0), NCartesianChart)

            For i = 0 To chart.Axes.Count - 1
                ' configure the axes
                Dim scale = CType(chart.Axes(i).Scale, NLinearScale)
                scale.Labels.Style.Angle = New NScaleLabelAngle(m_AngleModeComboBox.SelectedIndex, m_CustomAngleNumericUpDown.Value, m_AllowLabelsToFlipCheckBox.Checked)
            Next
        End Sub

#End Region

#Region "Fields"

        Private m_ChartView As NChartView
        Private m_Chart As NCartesianChart
        Private m_AngleModeComboBox As NComboBox
        Private m_CustomAngleNumericUpDown As NNumericUpDown
        Private m_AllowLabelsToFlipCheckBox As NCheckBox

#End Region

#Region "Schema"

        Public Shared ReadOnly NAxisLabelsOrientationtExampleSchema As NSchema

#End Region

#Region "Static Methods"

        Private Shared Function CreateCartesianChartView() As NChartView
            Dim chartView As NChartView = New NChartView()
            chartView.Surface.CreatePredefinedChart(ENPredefinedChartType.Cartesian)
            Return chartView
        End Function

#End Region
    End Class
End Namespace

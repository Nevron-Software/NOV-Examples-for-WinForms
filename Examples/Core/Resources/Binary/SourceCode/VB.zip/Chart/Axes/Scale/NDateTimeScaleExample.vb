Imports System
Imports System.Globalization
Imports Nevron.Nov.Chart
Imports Nevron.Nov.DataStructures
Imports Nevron.Nov.Dom
Imports Nevron.Nov.Graphics
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.Chart
    ''' <summary>
    ''' Date Time Scale Example
    ''' </summary>
    Public Class NDateTimeScaleExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' Default constructor
        ''' </summary>
        Public Sub New()
        End Sub
        ''' <summary>
        ''' Static constructor
        ''' </summary>
        Shared Sub New()
            NDateTimeScaleExampleSchema = NSchema.Create(GetType(NDateTimeScaleExample), NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            Dim chartView As NChartView = CreateCartesianChartView()

            ' configure title
            chartView.Surface.Titles(0).Text = "Date Time Scale"

            ' configure chart
            m_Chart = CType(chartView.Surface.Charts(0), NCartesianChart)
            m_Chart.SetPredefinedCartesianAxes(ENPredefinedCartesianAxis.XDateTimeYLinear)

            ' add interlaced stripe to the Y axis
            Dim yScale = CType(m_Chart.Axes(ENCartesianAxis.PrimaryY).Scale, NLinearScale)
            Dim stripStyle As NScaleStrip = New NScaleStrip(New NColorFill(NColor.Beige), Nothing, True, 0, 0, 1, 1)
            stripStyle.Interlaced = True
            yScale.Strips.Add(stripStyle)

            ' Add a line series (data will be generated with example controls)
            Dim line As NLineSeries = New NLineSeries()
            m_Chart.Series.Add(line)
            line.UseXValues = True
            line.DataLabelStyle = New NDataLabelStyle(False)
            line.InflateMargins = True
            Dim markerStyle As NMarkerStyle = New NMarkerStyle()
            markerStyle.Visible = True
            line.MarkerStyle = markerStyle

            ' create a date time scale
            m_DateTimeScale = CType(m_Chart.Axes(ENCartesianAxis.PrimaryX).Scale, NDateTimeScale)
            m_DateTimeScale.Labels.Style.Angle = New NScaleLabelAngle(ENScaleLabelAngleMode.Scale, 90)
            m_DateTimeScale.Labels.Style.ContentAlignment = ENContentAlignment.TopCenter
            chartView.Document.StyleSheets.ApplyTheme(New NChartTheme(ENChartPalette.Bright, False))
            Return chartView
        End Function

        Protected Overrides Function CreateExampleControls() As NWidget
            Dim stack As NStackPanel = New NStackPanel()
            Dim boxGroup As NUniSizeBoxGroup = New NUniSizeBoxGroup(stack)
            stack.Add(New NLabel("Allowed Date Time Units"))
            Dim dateTimeUnits = New NDateTimeUnit() {NDateTimeUnit.Century, NDateTimeUnit.Decade, NDateTimeUnit.Year, NDateTimeUnit.HalfYear, NDateTimeUnit.Quarter, NDateTimeUnit.Month, NDateTimeUnit.Week, NDateTimeUnit.Day, NDateTimeUnit.HalfDay, NDateTimeUnit.Hour, NDateTimeUnit.Minute, NDateTimeUnit.Second, NDateTimeUnit.Millisecond, NDateTimeUnit.Tick}
            m_DateTimeUnitListBox = New NListBox()

            For i = 0 To dateTimeUnits.Length - 1
                Dim dateTimeUnit = dateTimeUnits(i)
                Dim dateTimeUnitCheckBox As NCheckBox = New NCheckBox(NStringHelpers.InsertSpacesBeforeUppersAndDigits(dateTimeUnit.DateTimeUnit.ToString()))
                dateTimeUnitCheckBox.Checked = True
                AddHandler dateTimeUnitCheckBox.CheckedChanged, New [Function](Of NValueChangeEventArgs)(AddressOf OnDateTimeUnitCheckBoxCheckedChanged)
                dateTimeUnitCheckBox.Tag = dateTimeUnit
                m_DateTimeUnitListBox.Items.Add(New NListBoxItem(dateTimeUnitCheckBox))
            Next

            stack.Add(m_DateTimeUnitListBox)
            OnDateTimeUnitCheckBoxCheckedChanged(Nothing)
            Dim enableUnitSensitiveFormattingCheckBox As NCheckBox = New NCheckBox("Enable Unit Sensitive Formatting")
            AddHandler enableUnitSensitiveFormattingCheckBox.CheckedChanged, New [Function](Of NValueChangeEventArgs)(AddressOf OnEnableUnitSensitiveFormattingCheckBoxCheckedChanged)
            stack.Add(enableUnitSensitiveFormattingCheckBox)
            enableUnitSensitiveFormattingCheckBox.Checked = True
            stack.Add(New NLabel("Start Date:"))
            m_StartDateTimeBox = New NDateTimeBox()
            AddHandler m_StartDateTimeBox.SelectedDateChanged, New [Function](Of NValueChangeEventArgs)(AddressOf OnStartDateTimeBoxSelectedDateChanged)
            stack.Add(m_StartDateTimeBox)
            stack.Add(New NLabel("End Date:"))
            m_EndDateTimeBox = New NDateTimeBox()
            AddHandler m_EndDateTimeBox.SelectedDateChanged, New [Function](Of NValueChangeEventArgs)(AddressOf OnEndDateTimeBoxSelectedDateChanged)
            stack.Add(m_EndDateTimeBox)
            Dim generateRandomDataButton As NButton = New NButton("Generate Random Data")
            AddHandler generateRandomDataButton.Click, New [Function](Of NEventArgs)(AddressOf OnGenerateRandomDataButtonClick)
            stack.Add(generateRandomDataButton)
            m_StartDateTimeBox.SelectedDate = Date.Now
            m_EndDateTimeBox.SelectedDate = CultureInfo.CurrentCulture.Calendar.AddYears(m_StartDateTimeBox.SelectedDate, 2)
            Return boxGroup
        End Function

        Protected Overrides Function GetExampleDescription() As String
            Return "<p>This example demonstrates how to create a standard date/time scale.</p>"
        End Function

#End Region

#Region "Event Handlers"

        Private Sub OnEnableUnitSensitiveFormattingCheckBoxCheckedChanged(ByVal arg As NValueChangeEventArgs)
            If CType(arg.TargetNode, NCheckBox).Checked Then
                m_DateTimeScale.Labels.TextProvider = New NDateTimeUnitSensitiveLabelTextProvider()
            Else
                m_DateTimeScale.Labels.TextProvider = New NFormattedScaleLabelTextProvider(New NDateTimeValueFormatter(ENDateTimeValueFormat.Date))
            End If
        End Sub

        Private Sub OnEndDateTimeBoxSelectedDateChanged(ByVal arg As NValueChangeEventArgs)
            OnGenerateRandomDataButtonClick(Nothing)
        End Sub

        Private Sub OnStartDateTimeBoxSelectedDateChanged(ByVal arg As NValueChangeEventArgs)
            OnGenerateRandomDataButtonClick(Nothing)
        End Sub

        Private Sub OnGenerateRandomDataButtonClick(ByVal arg As NEventArgs)
            Dim startDate = m_StartDateTimeBox.SelectedDate
            Dim endDate = m_EndDateTimeBox.SelectedDate

            If startDate > endDate Then
                Dim temp = startDate
                startDate = endDate
                endDate = temp
            End If

            ' Get the line series from the chart
            Dim line = CType(m_Chart.Series(0), NLineSeries)
            Dim span = endDate - startDate
            span = New TimeSpan(span.Ticks / 30)
            line.DataPoints.Clear()

            If span.Ticks > 0 Then
                Dim random As Random = New Random()

                While startDate < endDate
                    line.DataPoints.Add(New NLineDataPoint(NDateTimeHelpers.ToOADate(startDate), random.Next(100)))
                    startDate += span
                End While
            End If
        End Sub

        Private Sub OnDateTimeUnitCheckBoxCheckedChanged(ByVal arg As NValueChangeEventArgs)
            Dim dateTimeUnits As NList(Of NDateTimeUnit) = New NList(Of NDateTimeUnit)()

            ' collect the checked date time units
            For i = 0 To m_DateTimeUnitListBox.Items.Count - 1
                Dim dateTimeUnitCheckBox As NCheckBox = TryCast(m_DateTimeUnitListBox.Items(i).Content, NCheckBox)

                If dateTimeUnitCheckBox.Checked Then
                    dateTimeUnits.Add(CType(dateTimeUnitCheckBox.Tag, NDateTimeUnit))
                End If
            Next

            m_DateTimeScale.AutoDateTimeUnits = New NDomArray(Of NDateTimeUnit)(dateTimeUnits.ToArray())
        End Sub

#End Region

#Region "Fields"

        Private m_Chart As NCartesianChart
        Private m_DateTimeScale As NDateTimeScale
        Private m_DateTimeUnitListBox As NListBox
        Private m_StartDateTimeBox As NDateTimeBox
        Private m_EndDateTimeBox As NDateTimeBox

#End Region

#Region "Schema"

        Public Shared ReadOnly NDateTimeScaleExampleSchema As NSchema

#End Region

#Region "Static Methods"

        Private Shared Function CreateCartesianChartView() As NChartView
            Dim chartView As NChartView = New NChartView()
            chartView.Surface.CreatePredefinedChart(ENPredefinedChartType.Cartesian)
            Return chartView
        End Function

#End Region
    End Class
End Namespace

Imports Nevron.Nov.Chart
Imports Nevron.Nov.Dom
Imports Nevron.Nov.Graphics
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.Chart
    ''' <summary>
    ''' Logarithmic Scale Example
    ''' </summary>
    Public Class NLogarithmicScaleExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' Default constructor
        ''' </summary>
        Public Sub New()
        End Sub
        ''' <summary>
        ''' Static constructor
        ''' </summary>
        Shared Sub New()
            NLogarithmicScaleExampleSchema = NSchema.Create(GetType(NLogarithmicScaleExample), NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            Dim chartView As NChartView = CreateCartesianChartView()

            ' configure title
            chartView.Surface.Titles(0).Text = "Logarithmic Scale"

            ' configure chart
            m_Chart = CType(chartView.Surface.Charts(0), NCartesianChart)

            ' configure axes
            m_Chart.SetPredefinedCartesianAxes(ENPredefinedCartesianAxis.XOrdinalYLinear)
            Dim logarithmicScale As NLogarithmicScale = New NLogarithmicScale()
            logarithmicScale.MinorGridLines.Stroke.DashStyle = ENDashStyle.Dot
            logarithmicScale.MinorTickCount = 3
            logarithmicScale.MajorTickMode = ENMajorTickMode.CustomStep

            ' add interlaced stripe 
            Dim strip As NScaleStrip = New NScaleStrip()
            strip.Fill = New NColorFill(NColor.Beige)
            strip.Interlaced = True
            logarithmicScale.Strips.Add(strip)
            logarithmicScale.CustomStep = 1
            m_Chart.Axes(ENCartesianAxis.PrimaryY).Scale = logarithmicScale
            Dim line As NLineSeries = New NLineSeries()
            m_Chart.Series.Add(line)
            line.LegendView.Mode = ENSeriesLegendMode.None
            line.InflateMargins = False
            Dim markerStyle As NMarkerStyle = New NMarkerStyle()
            line.MarkerStyle = markerStyle
            markerStyle.Shape = ENPointShape.Ellipse
            markerStyle.Size = New NSize(15, 15)
            Dim dataLabelStyle As NDataLabelStyle = New NDataLabelStyle()
            dataLabelStyle.Visible = True
            dataLabelStyle.Format = "<value>"
            line.DataLabelStyle = dataLabelStyle
            line.DataPoints.Add(New NLineDataPoint(12))
            line.DataPoints.Add(New NLineDataPoint(100))
            line.DataPoints.Add(New NLineDataPoint(250))
            line.DataPoints.Add(New NLineDataPoint(500))
            line.DataPoints.Add(New NLineDataPoint(1500))
            line.DataPoints.Add(New NLineDataPoint(5500))
            line.DataPoints.Add(New NLineDataPoint(9090))
            chartView.Document.StyleSheets.ApplyTheme(New NChartTheme(ENChartPalette.Bright, False))
            Return chartView
        End Function

        Protected Overrides Function CreateExampleControls() As NWidget
            Dim stack As NStackPanel = New NStackPanel()
            Dim boxGroup As NUniSizeBoxGroup = New NUniSizeBoxGroup(stack)
            Dim logarithmBaseUpDown As NNumericUpDown = New NNumericUpDown()
            logarithmBaseUpDown.Minimum = 1
            AddHandler logarithmBaseUpDown.ValueChanged, New [Function](Of NValueChangeEventArgs)(AddressOf OnLogarithmBaseUpDownValueChanged)
            stack.Add(NPairBox.Create("Logarithm Base:", logarithmBaseUpDown))
            Dim invertedCheckBox As NCheckBox = New NCheckBox("Inverted")
            AddHandler invertedCheckBox.CheckedChanged, AddressOf OnInvertedCheckBoxCheckedChanged
            invertedCheckBox.Checked = False
            stack.Add(invertedCheckBox)
            logarithmBaseUpDown.Value = 10
            Return boxGroup
        End Function

        Protected Overrides Function GetExampleDescription() As String
            Return "<p>This example demonstrates how to create a logarithmic scale.</p>"
        End Function

#End Region

#Region "Event Handlers"

        Private Sub OnLogarithmBaseUpDownValueChanged(ByVal arg As NValueChangeEventArgs)
            Dim logScale As NLogarithmicScale = TryCast(m_Chart.Axes(ENCartesianAxis.PrimaryY).Scale, NLogarithmicScale)
            logScale.LogarithmBase = CType(arg.TargetNode, NNumericUpDown).Value
        End Sub

        Private Sub OnInvertedCheckBoxCheckedChanged(ByVal arg As NValueChangeEventArgs)
            CType(m_Chart.Axes(ENCartesianAxis.PrimaryY).Scale, NLogarithmicScale).Invert = CType(arg.TargetNode, NCheckBox).Checked
        End Sub

#End Region

#Region "Fields"

        Private m_Chart As NCartesianChart

#End Region

#Region "Schema"

        Public Shared ReadOnly NLogarithmicScaleExampleSchema As NSchema

#End Region

#Region "Static Methods"

        Private Shared Function CreateCartesianChartView() As NChartView
            Dim chartView As NChartView = New NChartView()
            chartView.Surface.CreatePredefinedChart(ENPredefinedChartType.Cartesian)
            Return chartView
        End Function

#End Region
    End Class
End Namespace

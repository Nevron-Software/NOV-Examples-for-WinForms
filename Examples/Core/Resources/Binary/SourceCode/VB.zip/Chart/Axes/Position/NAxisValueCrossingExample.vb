Imports System
Imports Nevron.Nov.Chart
Imports Nevron.Nov.Dom
Imports Nevron.Nov.Graphics
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.Chart
    ''' <summary>
    ''' Axis value crossing example
    ''' </summary>
    Public Class NAxisValueCrossingExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' Default constructor
        ''' </summary>
        Public Sub New()
        End Sub
        ''' <summary>
        ''' Static constructor
        ''' </summary>
        Shared Sub New()
            NAxisValueCrossingExampleSchema = NSchema.Create(GetType(NAxisValueCrossingExample), NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        ''' <summary>
        ''' 
        ''' </summary>
        ''' <returns></returns>
        Protected Overrides Function CreateExampleContent() As NWidget
            Dim chartView As NChartView = CreateCartesianChartView()
            chartView.Surface.Titles(0).Text = "Axis Value Crossing"

            ' configure chart
            m_Chart = CType(chartView.Surface.Charts(0), NCartesianChart)
            m_Chart.SetPredefinedCartesianAxes(ENPredefinedCartesianAxis.XYLinear)
            Dim primaryX = m_Chart.Axes(ENCartesianAxis.PrimaryX)
            Dim primaryY = m_Chart.Axes(ENCartesianAxis.PrimaryY)

            ' configure axes
            Dim scaleY = CType(primaryY.Scale, NLinearScale)

            ' configure scales
            Dim yScale = CType(m_Chart.Axes(ENCartesianAxis.PrimaryY).Scale, NLinearScale)
            yScale.MajorGridLines = CreateDottedGrid()
            Dim yStrip As NScaleStrip = New NScaleStrip(New NColorFill(New NColor(NColor.LightGray, 40)), Nothing, True, 0, 0, 1, 1)
            yStrip.Interlaced = True
            yScale.Strips.Add(yStrip)
            Dim xScale = CType(primaryX.Scale, NLinearScale)
            xScale.MajorGridLines = CreateDottedGrid()
            Dim xStrip As NScaleStrip = New NScaleStrip(New NColorFill(New NColor(NColor.LightGray, 40)), Nothing, True, 0, 0, 1, 1)
            xStrip.Interlaced = True
            xScale.Strips.Add(xStrip)

            ' cross X and Y axes at their 0 values
            primaryX.Anchor = New NValueCrossCartesianAxisAnchor(0, primaryY, ENCartesianAxisOrientation.Horizontal, ENScaleOrientation.Right, 0.0F, 100.0F)
            primaryY.Anchor = New NValueCrossCartesianAxisAnchor(0, primaryX, ENCartesianAxisOrientation.Vertical, ENScaleOrientation.Left, 0.0F, 100.0F)

            ' setup bubble series
            Dim bubble As NBubbleSeries = New NBubbleSeries()
            bubble.Name = "Bubble Series"
            bubble.InflateMargins = True
            bubble.DataLabelStyle = New NDataLabelStyle(False)
            bubble.UseXValues = True

            ' fill with random data
            Dim random As Random = New Random()

            For i = 0 To 10 - 1
                bubble.DataPoints.Add(New NBubbleDataPoint(random.Next(-20, 20), random.Next(-20, 20), random.Next(1, 6)))
            Next

            m_Chart.Series.Add(bubble)
            chartView.Document.StyleSheets.ApplyTheme(New NChartTheme(ENChartPalette.Bright, True))
            Return chartView
        End Function

        ''' <summary>
        ''' 
        ''' </summary>
        ''' <returns></returns>
        Protected Overrides Function CreateExampleControls() As NWidget
            Dim stack As NStackPanel = New NStackPanel()
            Dim boxGroup As NUniSizeBoxGroup = New NUniSizeBoxGroup(stack)
            stack.Add(New NLabel("Vertical Axis"))
            Dim verticalAxisUsePositionCheckBox As NCheckBox = New NCheckBox("Use Position")
            AddHandler verticalAxisUsePositionCheckBox.CheckedChanged, New [Function](Of NValueChangeEventArgs)(AddressOf OnVerticalAxisUsePositionCheckBoxCheckedChanged)
            stack.Add(verticalAxisUsePositionCheckBox)
            m_VerticalAxisPositionValueUpDown = New NNumericUpDown()
            AddHandler m_VerticalAxisPositionValueUpDown.ValueChanged, New [Function](Of NValueChangeEventArgs)(AddressOf OnVerticalAxisPositionValueUpDownValueChanged)
            stack.Add(NPairBox.Create("Position Value:", m_VerticalAxisPositionValueUpDown))
            stack.Add(New NLabel("Horizontal Axis"))
            Dim horizontalAxisUsePositionCheckBox As NCheckBox = New NCheckBox("Use Position")
            AddHandler horizontalAxisUsePositionCheckBox.CheckedChanged, New [Function](Of NValueChangeEventArgs)(AddressOf OnHorizontalAxisUsePositionCheckBoxCheckedChanged)
            stack.Add(horizontalAxisUsePositionCheckBox)
            m_HorizontalAxisPositionValueUpDown = New NNumericUpDown()
            AddHandler m_HorizontalAxisPositionValueUpDown.ValueChanged, New [Function](Of NValueChangeEventArgs)(AddressOf OnHorizontalAxisPositionValueUpDownValueChanged)
            stack.Add(NPairBox.Create("Position Value:", m_HorizontalAxisPositionValueUpDown))
            verticalAxisUsePositionCheckBox.Checked = True
            horizontalAxisUsePositionCheckBox.Checked = True
            Return boxGroup
        End Function

        Protected Overrides Function GetExampleDescription() As String
            Return "<p>This example demonstrates how to cross two axes at a specified value.</p>"
        End Function

#End Region

#Region "Implementation"

        Private Function CreateDottedGrid() As NScaleGridLines
            Dim scaleGrid As NScaleGridLines = New NScaleGridLines()
            scaleGrid.Visible = True
            scaleGrid.Stroke.Width = 1
            scaleGrid.Stroke.DashStyle = ENDashStyle.Dot
            scaleGrid.Stroke.Color = NColor.Gray
            Return scaleGrid
        End Function

#End Region

#Region "Event Handlers"

        Private Sub OnHorizontalAxisUsePositionCheckBoxCheckedChanged(ByVal arg As NValueChangeEventArgs)
            Dim usePosition = CType(arg.TargetNode, NCheckBox).Checked
            m_HorizontalAxisPositionValueUpDown.Enabled = usePosition

            If usePosition Then
                Dim posValue = m_HorizontalAxisPositionValueUpDown.Value
                m_Chart.Axes(ENCartesianAxis.PrimaryX).Anchor = New NValueCrossCartesianAxisAnchor(posValue, m_Chart.Axes(ENCartesianAxis.PrimaryY), ENCartesianAxisOrientation.Horizontal, ENScaleOrientation.Right, 0.0F, 100.0F)
            Else
                m_Chart.Axes(ENCartesianAxis.PrimaryX).Anchor = New NDockCartesianAxisAnchor(ENCartesianAxisDockZone.Bottom, True)
            End If
        End Sub

        Private Sub OnHorizontalAxisPositionValueUpDownValueChanged(ByVal arg As NValueChangeEventArgs)
            Dim crossAnchor As NValueCrossCartesianAxisAnchor = TryCast(m_Chart.Axes(ENCartesianAxis.PrimaryX).Anchor, NValueCrossCartesianAxisAnchor)

            If crossAnchor IsNot Nothing Then
                crossAnchor.Value = CType(arg.TargetNode, NNumericUpDown).Value
            End If
        End Sub

        Private Sub OnVerticalAxisPositionValueUpDownValueChanged(ByVal arg As NValueChangeEventArgs)
            Dim crossAnchor As NValueCrossCartesianAxisAnchor = TryCast(m_Chart.Axes(ENCartesianAxis.PrimaryY).Anchor, NValueCrossCartesianAxisAnchor)

            If crossAnchor IsNot Nothing Then
                crossAnchor.Value = CType(arg.TargetNode, NNumericUpDown).Value
            End If
        End Sub

        Private Sub OnVerticalAxisUsePositionCheckBoxCheckedChanged(ByVal arg As NValueChangeEventArgs)
            Dim usePosition = CType(arg.TargetNode, NCheckBox).Checked
            m_VerticalAxisPositionValueUpDown.Enabled = usePosition

            If usePosition Then
                Dim posValue = m_VerticalAxisPositionValueUpDown.Value
                m_Chart.Axes(ENCartesianAxis.PrimaryY).Anchor = New NValueCrossCartesianAxisAnchor(posValue, m_Chart.Axes(ENCartesianAxis.PrimaryX), ENCartesianAxisOrientation.Vertical, ENScaleOrientation.Left, 0.0F, 100.0F)
            Else
                m_Chart.Axes(ENCartesianAxis.PrimaryY).Anchor = New NDockCartesianAxisAnchor(ENCartesianAxisDockZone.Left, True)
            End If
        End Sub

#End Region

#Region "Fields"

        Private m_Chart As NCartesianChart
        Private m_HorizontalAxisPositionValueUpDown As NNumericUpDown
        Private m_VerticalAxisPositionValueUpDown As NNumericUpDown

#End Region

#Region "Schema"

        Public Shared ReadOnly NAxisValueCrossingExampleSchema As NSchema

#End Region

#Region "Static Methods"

        Private Shared Function CreateCartesianChartView() As NChartView
            Dim chartView As NChartView = New NChartView()
            chartView.Surface.CreatePredefinedChart(ENPredefinedChartType.Cartesian)
            Return chartView
        End Function

#End Region
    End Class
End Namespace

Imports System

Imports Nevron.Nov.Chart
Imports Nevron.Nov.Dom
Imports Nevron.Nov.Graphics
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.Chart
    ''' <summary>
    ''' Axis value crossing example.
    ''' </summary>
    Public Class NAxisValueCrossingExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' Default constructor
        ''' </summary>
        Public Sub New()

        End Sub
        ''' <summary>
        ''' Static constructor
        ''' </summary>
        Shared Sub New()
            NAxisValueCrossingExampleSchema = NSchema.Create(GetType(NAxisValueCrossingExample), NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            Dim chartViewWithCommandBars As NChartViewWithCommandBars = New NChartViewWithCommandBars()
            Dim chartView = chartViewWithCommandBars.View
            chartView.Surface.CreatePredefinedChart(ENPredefinedChartType.Cartesian)

            chartView.Surface.Titles(0).Text = "Axis Value Crossing"

            ' configure chart
            m_Chart = CType(chartView.Surface.Charts(0), NCartesianChart)
            m_Chart.SetPredefinedCartesianAxes(ENPredefinedCartesianAxis.XYLinear)

            Dim primaryX = m_Chart.Axes(ENCartesianAxis.PrimaryX)
            Dim primaryY = m_Chart.Axes(ENCartesianAxis.PrimaryY)

            ' configure scales
            Dim yScale = CType(primaryY.Scale, NLinearScale)
            yScale.MajorGridLines = CreateDottedGrid()

            Dim yStrip As NScaleStrip = New NScaleStrip(New NColorFill(New NColor(NColor.LightGray, 40)), Nothing, True, 0, 0, 1, 1)
            yStrip.Interlaced = True
            yScale.Strips.Add(yStrip)

            Dim xScale = CType(primaryX.Scale, NLinearScale)
            xScale.MajorGridLines = CreateDottedGrid()

            Dim xStrip As NScaleStrip = New NScaleStrip(New NColorFill(New NColor(NColor.LightGray, 40)), Nothing, True, 0, 0, 1, 1)
            xStrip.Interlaced = True
            xScale.Strips.Add(xStrip)

            ' cross X and Y axes at their 0 values
            Dim crossXAnchor As NCrossCartesianAxisAnchor = New NCrossCartesianAxisAnchor(ENCartesianAxisOrientation.Horizontal, ENScaleOrientation.Right, 0.0F, 100.0F)
            crossXAnchor.YAxisCrossing = New NValueAxisCrossing(primaryY, 0)
            primaryX.Anchor = crossXAnchor

            Dim crossYAnchor As NCrossCartesianAxisAnchor = New NCrossCartesianAxisAnchor(ENCartesianAxisOrientation.Vertical, ENScaleOrientation.Right, 0.0F, 100.0F)
            crossXAnchor.XAxisCrossing = New NValueAxisCrossing(primaryX, 0)
            primaryY.Anchor = crossYAnchor

            ' setup bubble series
            Dim bubble As NBubbleSeries = New NBubbleSeries()
            bubble.Name = "Bubble Series"
            bubble.InflateMargins = True
            bubble.DataLabelStyle = New NDataLabelStyle(False)
            bubble.UseXValues = True

            ' fill with random data
            Dim random As Random = New Random()

            For i = 0 To 9
                bubble.DataPoints.Add(New NBubbleDataPoint(random.Next(-20, 20), random.Next(-20, 20), random.Next(1, 6)))
            Next

            m_Chart.Series.Add(bubble)

            chartView.Document.StyleSheets.ApplyTheme(New NChartTheme(ENChartPalette.Bright, ENChartPaletteTarget.DataPoints))

            Return chartViewWithCommandBars
        End Function
        Protected Overrides Function CreateExampleControls() As NWidget
            Dim stack As NStackPanel = New NStackPanel()
            Dim boxGroup As NUniSizeBoxGroup = New NUniSizeBoxGroup(stack)

            stack.Add(New NLabel("Vertical Axis"))
            Dim verticalAxisUsePositionCheckBox As NCheckBox = New NCheckBox("Use Position")
            verticalAxisUsePositionCheckBox.CheckedChanged += New [Function](Of NValueChangeEventArgs)(AddressOf OnVerticalAxisUsePositionCheckBoxCheckedChanged)
            stack.Add(verticalAxisUsePositionCheckBox)

            m_VerticalAxisPositionValueUpDown = New NNumericUpDown()
            m_VerticalAxisPositionValueUpDown.ValueChanged += New [Function](Of NValueChangeEventArgs)(AddressOf OnVerticalAxisPositionValueUpDownValueChanged)
            stack.Add(NPairBox.Create("Position Value:", m_VerticalAxisPositionValueUpDown))

            stack.Add(New NLabel("Horizontal Axis"))
            Dim horizontalAxisUsePositionCheckBox As NCheckBox = New NCheckBox("Use Position")
            horizontalAxisUsePositionCheckBox.CheckedChanged += New [Function](Of NValueChangeEventArgs)(AddressOf OnHorizontalAxisUsePositionCheckBoxCheckedChanged)
            stack.Add(horizontalAxisUsePositionCheckBox)

            m_HorizontalAxisPositionValueUpDown = New NNumericUpDown()
            m_HorizontalAxisPositionValueUpDown.ValueChanged += New [Function](Of NValueChangeEventArgs)(AddressOf OnHorizontalAxisPositionValueUpDownValueChanged)
            stack.Add(NPairBox.Create("Position Value:", m_HorizontalAxisPositionValueUpDown))

            verticalAxisUsePositionCheckBox.Checked = True
            horizontalAxisUsePositionCheckBox.Checked = True

            Return boxGroup
        End Function
        Protected Overrides Function GetExampleDescription() As String
            Return "<p>This example demonstrates how to cross two axes at a specified value.</p>"
        End Function

#End Region

#Region "Implementation"

        Private Function CreateDottedGrid() As NScaleGridLines
            Dim scaleGrid As NScaleGridLines = New NScaleGridLines()

            scaleGrid.Visible = True
            scaleGrid.Stroke.Width = 1
            scaleGrid.Stroke.DashStyle = ENDashStyle.Dot
            scaleGrid.Stroke.Color = NColor.Gray

            Return scaleGrid

        End Function

#End Region

#Region "Event Handlers"

        Private Sub OnHorizontalAxisUsePositionCheckBoxCheckedChanged(ByVal arg As NValueChangeEventArgs)
            Dim usePosition = CType(arg.TargetNode, NCheckBox).Checked
            m_HorizontalAxisPositionValueUpDown.Enabled = usePosition

            If usePosition Then
                Dim posValue = m_HorizontalAxisPositionValueUpDown.Value

                Dim xAxisAnchor As NCrossCartesianAxisAnchor = New NCrossCartesianAxisAnchor(ENCartesianAxisOrientation.Horizontal, ENScaleOrientation.Right, 0.0F, 100.0F)
                xAxisAnchor.YAxisCrossing = New NValueAxisCrossing(m_Chart.Axes(ENCartesianAxis.PrimaryY), posValue)

                m_Chart.Axes(ENCartesianAxis.PrimaryX).Anchor = xAxisAnchor
            Else
                m_Chart.Axes(ENCartesianAxis.PrimaryX).Anchor = New NDockCartesianAxisAnchor(ENCartesianAxisDockZone.Bottom, True)
            End If
        End Sub

        Private Sub OnHorizontalAxisPositionValueUpDownValueChanged(ByVal arg As NValueChangeEventArgs)
            Dim crossAnchor As NCrossCartesianAxisAnchor = TryCast(m_Chart.Axes(ENCartesianAxis.PrimaryX).Anchor, NCrossCartesianAxisAnchor)

            If crossAnchor IsNot Nothing Then
                TryCast(crossAnchor.YAxisCrossing, NValueAxisCrossing).Value = CType(arg.TargetNode, NNumericUpDown).Value
            End If
        End Sub

        Private Sub OnVerticalAxisPositionValueUpDownValueChanged(ByVal arg As NValueChangeEventArgs)
            Dim crossAnchor As NCrossCartesianAxisAnchor = TryCast(m_Chart.Axes(ENCartesianAxis.PrimaryY).Anchor, NCrossCartesianAxisAnchor)

            If crossAnchor IsNot Nothing Then
                TryCast(crossAnchor.XAxisCrossing, NValueAxisCrossing).Value = CType(arg.TargetNode, NNumericUpDown).Value
            End If
        End Sub

        Private Sub OnVerticalAxisUsePositionCheckBoxCheckedChanged(ByVal arg As NValueChangeEventArgs)
            Dim usePosition = CType(arg.TargetNode, NCheckBox).Checked
            m_VerticalAxisPositionValueUpDown.Enabled = usePosition

            If usePosition Then
                Dim xCrossing As NAxisCrossing = New NValueAxisCrossing(m_Chart.Axes(ENCartesianAxis.PrimaryX), m_VerticalAxisPositionValueUpDown.Value)
                Dim xCrossAnchor As NCrossCartesianAxisAnchor = New NCrossCartesianAxisAnchor(ENCartesianAxisOrientation.Vertical, ENScaleOrientation.Left, 0.0F, 100.0F)
                xCrossAnchor.XAxisCrossing = xCrossing

                m_Chart.Axes(ENCartesianAxis.PrimaryY).Anchor = xCrossAnchor
            Else
                m_Chart.Axes(ENCartesianAxis.PrimaryY).Anchor = New NDockCartesianAxisAnchor(ENCartesianAxisDockZone.Left, True)
            End If
        End Sub

#End Region

#Region "Fields"

        Private m_Chart As NCartesianChart

        Private m_HorizontalAxisPositionValueUpDown As NNumericUpDown
        Private m_VerticalAxisPositionValueUpDown As NNumericUpDown

#End Region

#Region "Schema"

        Public Shared ReadOnly NAxisValueCrossingExampleSchema As NSchema

#End Region
    End Class
End Namespace

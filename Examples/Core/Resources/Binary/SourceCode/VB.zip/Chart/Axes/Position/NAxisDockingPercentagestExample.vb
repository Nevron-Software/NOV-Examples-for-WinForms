Imports System

Imports Nevron.Nov.Chart
Imports Nevron.Nov.Dom
Imports Nevron.Nov.Graphics
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.Chart
    ''' <summary>
    ''' Axis docking example.
    ''' </summary>
    Public Class NAxisDockingPercentagestExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' Default constructor
        ''' </summary>
        Public Sub New()

        End Sub
        ''' <summary>
        ''' Static constructor
        ''' </summary>
        Shared Sub New()
            NAxisDockingPercentagestExampleSchema = NSchema.Create(GetType(NAxisDockingPercentagestExample), NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            Dim chartViewWithCommandBars As NChartViewWithCommandBars = New NChartViewWithCommandBars()
            Dim chartView = chartViewWithCommandBars.View
            chartView.Surface.CreatePredefinedChart(ENPredefinedChartType.Cartesian)

            ' configure title
            chartView.Surface.Titles(0).Text = "Axis Docking Percentages"

            Dim chart = CType(chartView.Surface.Charts(0), NCartesianChart)

            ' clear the default chart axes
            chart.Axes.Clear()

            m_RedAxis = CreateLinearAxis(ENCartesianAxisDockZone.Left, NColor.Red)
            chart.Axes.Add(m_RedAxis)

            m_GreenAxis = CreateLinearAxis(ENCartesianAxisDockZone.Right, NColor.Green)
            chart.Axes.Add(m_GreenAxis)

            ' Add a custom vertical axis
            m_BlueAxis = CreateLinearAxis(ENCartesianAxisDockZone.Left, NColor.Blue)
            chart.Axes.Add(m_BlueAxis)

            chart.Axes.Add(NCartesianChart.CreateDockedAxis(ENCartesianAxisDockZone.Bottom, ENScaleType.Ordinal))

            ' create three line series and dispay them on three vertical axes (red, green and blue axis)
            Dim line1 = CreateLineSeries(NColor.Red, NColor.DarkRed, 10, 20)
            chart.Series.Add(line1)

            Dim line2 = CreateLineSeries(NColor.Green, NColor.DarkGreen, 50, 100)
            chart.Series.Add(line2)

            Dim line3 = CreateLineSeries(NColor.Blue, NColor.DarkBlue, 100, 200)
            chart.Series.Add(line3)

            line1.VerticalAxis = m_RedAxis
            line2.VerticalAxis = m_GreenAxis
            line3.VerticalAxis = m_BlueAxis

            Return chartViewWithCommandBars
        End Function
        Protected Overrides Function CreateExampleControls() As NWidget
            Dim stack As NStackPanel = New NStackPanel()
            Dim boxGroup As NUniSizeBoxGroup = New NUniSizeBoxGroup(stack)

            m_RedAxisEndPercentUpDown = New NNumericUpDown()
            m_RedAxisEndPercentUpDown.Minimum = 10
            m_RedAxisEndPercentUpDown.Maximum = 60
            m_RedAxisEndPercentUpDown.ValueChanged += New [Function](Of NValueChangeEventArgs)(AddressOf OnRedAxisEndPercentUpDownValueChanged)
            stack.Add(NPairBox.Create("Red Axis End Percent:", m_RedAxisEndPercentUpDown))

            m_BlueAxisBeginPercentUpDown = New NNumericUpDown()
            m_BlueAxisBeginPercentUpDown.Minimum = 20
            m_BlueAxisBeginPercentUpDown.Maximum = 90
            m_BlueAxisBeginPercentUpDown.ValueChanged += New [Function](Of NValueChangeEventArgs)(AddressOf OnBlueAxisEndPercentUpDownValueChanged)
            stack.Add(NPairBox.Create("Blue Axis Begin Percent:", m_BlueAxisBeginPercentUpDown))

            m_RedAxisEndPercentUpDown.Value = 30
            m_BlueAxisBeginPercentUpDown.Value = 70

            Return boxGroup
        End Function
        Protected Overrides Function GetExampleDescription() As String
            Return "<p>This example demonstrates how to change the area occupied by an axis when docked in an axis dock zone.</p>"
        End Function

#End Region

#Region "Implementation"

        Private Function CreateLinearAxis(ByVal dockZone As ENCartesianAxisDockZone, ByVal color As NColor) As NCartesianAxis
            Dim axis As NCartesianAxis = New NCartesianAxis()

            axis.Scale = CreateLinearScale(color)

            axis.Anchor = New NDockCartesianAxisAnchor(dockZone, False)

            Return axis
        End Function
        Private Function CreateLinearScale(ByVal color As NColor) As NLinearScale
            Dim linearScale As NLinearScale = New NLinearScale()

            linearScale.Ruler.Stroke = New NStroke(1, color)
            linearScale.InnerMajorTicks.Stroke = New NStroke(color)
            linearScale.OuterMajorTicks.Stroke = New NStroke(color)
            linearScale.Labels.Style.TextStyle.Fill = New NColorFill(color)

            Dim grid As NScaleGridLines = New NScaleGridLines()
            grid.Stroke.Color = color
            grid.Visible = True
            linearScale.MajorGridLines = grid

            Dim strip As NScaleStrip = New NScaleStrip()
            strip.Length = 1
            strip.Interval = 1
            strip.Fill = New NColorFill(New NColor(color, 50))
            linearScale.Strips.Add(strip)

            Return linearScale
        End Function
        Private Function CreateLineSeries(ByVal lightColor As NColor, ByVal color As NColor, ByVal begin As Integer, ByVal [end] As Integer) As NLineSeries
            ' Add a line series
            Dim line As NLineSeries = New NLineSeries()

            Dim random As Random = New Random()
            For i = 0 To 4
                line.DataPoints.Add(New NLineDataPoint(random.Next(begin, [end])))
            Next

            line.Stroke = New NStroke(2, color)

            Dim dataLabelStyle As NDataLabelStyle = New NDataLabelStyle()

            dataLabelStyle.Format = "<value>"
            dataLabelStyle.TextStyle.Background.Visible = False
            dataLabelStyle.ArrowStroke.Width = 0
            dataLabelStyle.ArrowLength = 10
            dataLabelStyle.TextStyle.Font = New NFont("Arial", 8)
            dataLabelStyle.TextStyle.Background.Visible = True

            line.DataLabelStyle = dataLabelStyle

            Dim markerStyle As NMarkerStyle = New NMarkerStyle()

            markerStyle.Visible = True
            markerStyle.Border = New NStroke(color)
            markerStyle.Fill = New NColorFill(lightColor)
            markerStyle.Shape = ENPointShape3D.Ellipse
            markerStyle.Size = New NSize(5, 5)

            line.MarkerStyle = markerStyle

            Return line
        End Function

#End Region

#Region "Event Handlers"

        Private Sub OnRedAxisEndPercentUpDownValueChanged(ByVal arg As NValueChangeEventArgs)
            m_BlueAxisBeginPercentUpDown.Minimum = m_RedAxisEndPercentUpDown.Value + 10

            RecalcAxes()
        End Sub

        Private Sub OnBlueAxisEndPercentUpDownValueChanged(ByVal arg As NValueChangeEventArgs)
            m_RedAxisEndPercentUpDown.Maximum = m_BlueAxisBeginPercentUpDown.Value - 10

            RecalcAxes()
        End Sub

        Private Sub RecalcAxes()
            Dim middleAxisBegin As Integer = m_RedAxisEndPercentUpDown.Value
            Dim middleAxisEnd As Integer = m_BlueAxisBeginPercentUpDown.Value

            ' red axis
            m_RedAxis.Anchor.EndPercent = middleAxisBegin

            ' green axis
            m_GreenAxis.Anchor.BeginPercent = middleAxisBegin
            m_GreenAxis.Anchor.EndPercent = middleAxisEnd

            ' blue axis
            m_BlueAxis.Anchor.BeginPercent = middleAxisEnd
        End Sub

#End Region

#Region "Fields"

        Private m_RedAxis As NCartesianAxis
        Private m_GreenAxis As NCartesianAxis
        Private m_BlueAxis As NCartesianAxis

        Private m_RedAxisEndPercentUpDown As NNumericUpDown
        Private m_BlueAxisBeginPercentUpDown As NNumericUpDown

#End Region

#Region "Schema"

        Public Shared ReadOnly NAxisDockingPercentagestExampleSchema As NSchema

#End Region
    End Class
End Namespace

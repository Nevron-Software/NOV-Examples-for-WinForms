Imports Nevron.Nov.Chart
Imports Nevron.Nov.Chart.Tools
Imports Nevron.Nov.Dom
Imports Nevron.Nov.Graphics
Imports Nevron.Nov.UI
Imports System

Namespace Nevron.Nov.Examples.Chart
    ''' <summary>
    ''' Weekly Schdule Wrok Calendar Example
    ''' </summary>
    Public Class NWeeklyScheduleWorkCalendarExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' Default constructor
        ''' </summary>
        Public Sub New()
        End Sub
        ''' <summary>
        ''' Static constructor
        ''' </summary>
        Shared Sub New()
            NWeeklyScheduleWorkCalendarExampleSchema = NSchema.Create(GetType(NWeeklyScheduleWorkCalendarExample), NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            Dim chartView As NChartView = CreateCartesianChartView()

            ' configure title
            chartView.Surface.Titles(0).Text = "Weekly Schedule Work Calendar"

            ' configure chart
            m_Chart = CType(chartView.Surface.Charts(0), NCartesianChart)
            m_Chart.SetPredefinedCartesianAxes(ENPredefinedCartesianAxis.XOrdinalYLinear)
            Dim ranges As NRangeSeries = New NRangeSeries()
            m_Chart.Series.Add(ranges)
            ranges.DataLabelStyle = New NDataLabelStyle(False)
            ranges.UseXValues = True
            Dim dt As Date = New DateTime(2014, 4, 14)
            Dim rand As Random = New Random()
            Dim rangeTimeline As NRangeTimelineScale = New NRangeTimelineScale()
            rangeTimeline.EnableCalendar = True
            m_Chart.Axes(ENCartesianAxis.PrimaryX).Scale = rangeTimeline
            Dim yScale = CType(m_Chart.Axes(ENCartesianAxis.PrimaryY).Scale, NLinearScale)
            yScale.MajorGridLines.Visible = True

            ' add interlaced strip
            Dim strip As NScaleStrip = New NScaleStrip(New NColorFill(NColor.Beige), Nothing, True, 0, 0, 1, 1)
            strip.Interlaced = True
            yScale.Strips.Add(strip)
            yScale.Title.Text = "Weekly Workload in %"
            Dim workCalendar = rangeTimeline.Calendar

            ' show only the working days on the scale
            Dim weekDayRule As NWeekDayRule = New NWeekDayRule(ENWeekDayBit.Monday Or ENWeekDayBit.Tuesday Or ENWeekDayBit.Wednesday Or ENWeekDayBit.Thursday Or ENWeekDayBit.Friday)
            workCalendar.Rules.Add(weekDayRule)

            ' generate data for week working days
            For i = 0 To 21 - 1

                If dt.DayOfWeek <> DayOfWeek.Saturday AndAlso dt.DayOfWeek <> DayOfWeek.Sunday Then
                    ranges.DataPoints.Add(New NRangeDataPoint(NDateTimeHelpers.ToOADate(dt), 0, NDateTimeHelpers.ToOADate(dt + New TimeSpan(1, 0, 0, 0)), rand.NextDouble() * 70 + 30.0R))
                End If

                dt += New TimeSpan(1, 0, 0, 0)
            Next

            ConfigureInteractivity(m_Chart)
            chartView.Document.StyleSheets.ApplyTheme(New NChartTheme(ENChartPalette.Bright, False))
            Return chartView
        End Function

        Protected Overrides Function CreateExampleControls() As NWidget
            Dim stack As NStackPanel = New NStackPanel()
            Dim boxGroup As NUniSizeBoxGroup = New NUniSizeBoxGroup(stack)
            Dim enableWorkCalendarCheckBox As NCheckBox = New NCheckBox("Enable Work Calendar")
            AddHandler enableWorkCalendarCheckBox.CheckedChanged, New [Function](Of NValueChangeEventArgs)(AddressOf OnEnableWorkCalendarCheckBoxCheckedChanged)
            enableWorkCalendarCheckBox.Checked = True
            stack.Add(enableWorkCalendarCheckBox)
            Return boxGroup
        End Function

        Protected Overrides Function GetExampleDescription() As String
            Return "<p>This example demonstrates the ability of the timeline and date/time scales to skip date time ranges, when it is expected that there is no data for them. Common applications of this feature are financial charts that usually display only working week days as stock markets are closed on weekends.</p>"
        End Function

#End Region

#Region "Event Handlers"

        Private Sub OnEnableWorkCalendarCheckBoxCheckedChanged(ByVal arg As NValueChangeEventArgs)
            CType(m_Chart.Axes(ENCartesianAxis.PrimaryX).Scale, NRangeTimelineScale).EnableCalendar = TryCast(arg.TargetNode, NCheckBox).Checked
        End Sub

#End Region

#Region "Implementation"

        Private Sub ConfigureInteractivity(ByVal chart As NChart)
            Dim interactor As NInteractor = New NInteractor()
            Dim rectangleZoomTool As NRectangleZoomTool = New NRectangleZoomTool()
            rectangleZoomTool.Enabled = True
            rectangleZoomTool.VerticalValueSnapper = New NAxisRulerMinMaxSnapper()
            interactor.Add(rectangleZoomTool)
            Dim dataPanTool As NDataPanTool = New NDataPanTool()
            dataPanTool.StartMouseButtonEvent = ENMouseButtonEvent.RightButtonDown
            dataPanTool.EndMouseButtonEvent = ENMouseButtonEvent.RightButtonUp
            dataPanTool.Enabled = True
            interactor.Add(dataPanTool)
            chart.Interactor = interactor
        End Sub

#End Region

#Region "Fields"

        Private m_Chart As NCartesianChart

#End Region

#Region "Schema"

        Public Shared ReadOnly NWeeklyScheduleWorkCalendarExampleSchema As NSchema

#End Region

#Region "Static Methods"

        Private Shared Function CreateCartesianChartView() As NChartView
            Dim chartView As NChartView = New NChartView()
            chartView.Surface.CreatePredefinedChart(ENPredefinedChartType.Cartesian)
            Return chartView
        End Function

#End Region
    End Class
End Namespace

Imports System

Imports Nevron.Nov.Chart
Imports Nevron.Nov.Dom
Imports Nevron.Nov.Graphics
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.Chart
    ''' <summary>
    ''' Axis ruler caps example.
    ''' </summary>
    Public Class NAxisRulerCapsExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' Default constructor
        ''' </summary>
        Public Sub New()

        End Sub
        ''' <summary>
        ''' Static constructor
        ''' </summary>
        Shared Sub New()
            NAxisRulerCapsExampleSchema = NSchema.Create(GetType(NAxisRulerCapsExample), NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            Dim chartViewWithCommandBars As NChartViewWithCommandBars = New NChartViewWithCommandBars()
            Dim chartView = chartViewWithCommandBars.View
            chartView.Surface.CreatePredefinedChart(ENPredefinedChartType.Cartesian)

            ' configure title
            chartView.Surface.Titles(0).Text = "Axis Ruler Caps"

            ' configure chart
            m_Chart = CType(chartView.Surface.Charts(0), NCartesianChart)
            m_Chart.Padding = New NMargins(20)

            ' configure axes
            m_Chart.SetPredefinedCartesianAxes(ENPredefinedCartesianAxis.XYLinear)

            ' feed some random data 
            Dim point As NPointSeries = New NPointSeries()
            point.UseXValues = True
            point.DataLabelStyle = New NDataLabelStyle(False)

            ' fill in some random data
            Dim random As Random = New Random()

            For i = 0 To 29
                point.DataPoints.Add(New NPointDataPoint(5 + random.Next(90), 5 + random.Next(90)))
            Next

            m_Chart.Series.Add(point)

            ' X Axis
            Dim xScale As NLinearScale = New NLinearScale()
            xScale.MajorGridLines = CreateScaleGrid()

            Dim xScaleBreak As NCustomScaleBreak = New NCustomScaleBreak()

            xScaleBreak.Style = ENScaleBreakStyle.Line
            xScaleBreak.Fill = New NColorFill(New NColor(NColor.Orange, 124))
            xScaleBreak.Length = 20
            xScaleBreak.Range = New NRange(29, 41)

            xScale.ScaleBreaks.Add(xScaleBreak)

            ' add an interlaced strip to the X axis
            Dim xInterlacedStrip As NScaleStrip = New NScaleStrip()

            xInterlacedStrip.Interlaced = True
            xInterlacedStrip.Fill = New NColorFill(New NColor(NColor.LightGray, 125))

            xScale.Strips.Add(xInterlacedStrip)

            Dim xAxis = m_Chart.Axes(ENCartesianAxis.PrimaryX)
            xAxis.Scale = xScale

            '			xAxis.ViewRangeMode = ENAxisViewRangeMode.FixedRange;
            '			xAxis.MinViewRangeValue = 0;
            '			xAxis.MaxViewRangeValue = 100;

            Dim xAxisAnchor As NDockCartesianAxisAnchor = New NDockCartesianAxisAnchor(ENCartesianAxisDockZone.Bottom)
            xAxisAnchor.BeforeSpace = 10
            xAxis.Anchor = xAxisAnchor

            ' Y Axis
            Dim yScale As NLinearScale = New NLinearScale()
            yScale.MajorGridLines = CreateScaleGrid()

            Dim yScaleBreak As NCustomScaleBreak = New NCustomScaleBreak()

            yScaleBreak.Style = ENScaleBreakStyle.Line
            yScaleBreak.Fill = New NColorFill(New NColor(NColor.Orange, 124))
            yScaleBreak.Length = 20
            yScaleBreak.Range = New NRange(29, 41)

            yScale.ScaleBreaks.Add(yScaleBreak)

            ' add an interlaced strip to the Y axis
            Dim yInterlacedStrip As NScaleStrip = New NScaleStrip()
            yInterlacedStrip.Interlaced = True
            yInterlacedStrip.Fill = New NColorFill(New NColor(NColor.LightGray, 125))
            yInterlacedStrip.Interval = 1
            yInterlacedStrip.Length = 1
            yScale.Strips.Add(yInterlacedStrip)

            Dim yAxis = m_Chart.Axes(ENCartesianAxis.PrimaryY)
            yAxis.Scale = yScale

            '			yAxis.ViewRangeMode = ENAxisViewRangeMode.FixedRange;
            '			yAxis.MinViewRangeValue = 0;
            '			yAxis.MaxViewRangeValue = 100;

            Dim yAxisAnchor As NDockCartesianAxisAnchor = New NDockCartesianAxisAnchor(ENCartesianAxisDockZone.Left)
            yAxisAnchor.BeforeSpace = 10
            yAxis.Anchor = yAxisAnchor

            chartView.Document.StyleSheets.ApplyTheme(New NChartTheme(ENChartPalette.Bright, ENChartPaletteTarget.Series))

            Return chartViewWithCommandBars
        End Function
        Protected Overrides Function CreateExampleControls() As NWidget
            Dim stack As NStackPanel = New NStackPanel()
            Dim boxGroup As NUniSizeBoxGroup = New NUniSizeBoxGroup(stack)

            m_BeginCapShapeComboBox = New NComboBox()
            m_BeginCapShapeComboBox.FillFromEnum(Of ENCapShape)()
            stack.Add(NPairBox.Create("Begin Cap Shape:", m_BeginCapShapeComboBox))
            m_BeginCapShapeComboBox.SelectedIndex = CInt(ENCapShape.Ellipse)

            m_ScaleBreakCapShapeComboBox = New NComboBox()
            m_ScaleBreakCapShapeComboBox.FillFromEnum(Of ENCapShape)()
            stack.Add(NPairBox.Create("Scale Break Cap Shape:", m_ScaleBreakCapShapeComboBox))
            m_ScaleBreakCapShapeComboBox.SelectedIndex = CInt(ENCapShape.VerticalLine)

            m_EndCapShapeComboBox = New NComboBox()
            m_EndCapShapeComboBox.FillFromEnum(Of ENCapShape)()
            stack.Add(NPairBox.Create("End Cap Shape:", m_EndCapShapeComboBox))
            m_EndCapShapeComboBox.SelectedIndex = CInt(ENCapShape.Arrow)

            m_PaintOnScaleBreaksCheckBox = New NCheckBox("Paint on Scale Breaks")
            stack.Add(m_PaintOnScaleBreaksCheckBox)
            m_PaintOnScaleBreaksCheckBox.Checked = False

            m_SizeUpDown = New NNumericUpDown()
            stack.Add(NPairBox.Create("Cap Size:", m_SizeUpDown))
            m_SizeUpDown.Value = 5

            ' wire for events
            m_BeginCapShapeComboBox.SelectedIndexChanged += New [Function](Of NValueChangeEventArgs)(AddressOf OnRulerStyleChanged)
            m_ScaleBreakCapShapeComboBox.SelectedIndexChanged += New [Function](Of NValueChangeEventArgs)(AddressOf OnRulerStyleChanged)
            m_EndCapShapeComboBox.SelectedIndexChanged += New [Function](Of NValueChangeEventArgs)(AddressOf OnRulerStyleChanged)
            m_PaintOnScaleBreaksCheckBox.CheckedChanged += New [Function](Of NValueChangeEventArgs)(AddressOf OnRulerStyleChanged)
            m_SizeUpDown.ValueChanged += New [Function](Of NValueChangeEventArgs)(AddressOf OnRulerStyleChanged)

            OnRulerStyleChanged(Nothing)

            Return boxGroup
        End Function
        Protected Overrides Function GetExampleDescription() As String
            Return "<p>This example demonstrates how to alter the appearance of axis ruler caps.</p>"
        End Function

#End Region

#Region "Implementation"

        Private Sub UpdateRulerStyleForAxis(ByVal axis As NCartesianAxis)
            Dim scale = CType(axis.Scale, NStandardScale)

            Dim capSize As NSize = New NSize(m_SizeUpDown.Value, m_SizeUpDown.Value)

            ' apply style to begin and end caps
            scale.Ruler.BeginCap = New NRulerCapStyle(m_BeginCapShapeComboBox.SelectedIndex, capSize, 0, New NColorFill(NColor.Black), New NStroke(NColor.Black))
            scale.Ruler.EndCap = New NRulerCapStyle(m_EndCapShapeComboBox.SelectedIndex, capSize, 3, New NColorFill(NColor.Black), New NStroke(NColor.Black))
            scale.Ruler.ScaleBreakCap = New NRulerCapStyle(m_ScaleBreakCapShapeComboBox.SelectedIndex, capSize, 0, New NColorFill(NColor.Black), New NStroke(NColor.Black))
            scale.Ruler.PaintOnScaleBreaks = m_PaintOnScaleBreaksCheckBox.Checked
        End Sub

        Private Function CreateScaleGrid() As NScaleGridLines
            Dim scaleGrid As NScaleGridLines = New NScaleGridLines()

            scaleGrid.Visible = True
            scaleGrid.Stroke = New NStroke(1, NColor.Gray, ENDashStyle.Dash)

            Return scaleGrid
        End Function

#End Region

#Region "Event Handlers"

        Private Sub OnRulerStyleChanged(ByVal arg As NValueChangeEventArgs)
            Me.UpdateRulerStyleForAxis(m_Chart.Axes(ENCartesianAxis.PrimaryX))
            Me.UpdateRulerStyleForAxis(m_Chart.Axes(ENCartesianAxis.PrimaryY))
        End Sub

#End Region

#Region "Fields"

        Private m_Chart As NCartesianChart

        Private m_BeginCapShapeComboBox As NComboBox
        Private m_ScaleBreakCapShapeComboBox As NComboBox
        Private m_EndCapShapeComboBox As NComboBox
        Private m_PaintOnScaleBreaksCheckBox As NCheckBox
        Private m_SizeUpDown As NNumericUpDown

#End Region

#Region "Schema"

        Public Shared ReadOnly NAxisRulerCapsExampleSchema As NSchema

#End Region
    End Class
End Namespace

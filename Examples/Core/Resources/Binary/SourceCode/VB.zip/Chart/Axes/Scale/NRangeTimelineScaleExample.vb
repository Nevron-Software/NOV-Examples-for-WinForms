Imports System

Imports Nevron.Nov.Chart
Imports Nevron.Nov.Dom
Imports Nevron.Nov.Graphics
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.Chart
    ''' <summary>
    ''' Range Timeline Scale Example.
    ''' </summary>
    Public Class NRangeTimelineScaleExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' Default constructor
        ''' </summary>
        Public Sub New()

        End Sub
        ''' <summary>
        ''' Static constructor
        ''' </summary>
        Shared Sub New()
            NRangeTimelineScaleExampleSchema = NSchema.Create(GetType(NRangeTimelineScaleExample), NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            Dim chartViewWithCommandBars As NChartViewWithCommandBars = New NChartViewWithCommandBars()
            Dim chartView = chartViewWithCommandBars.View
            chartView.Surface.CreatePredefinedChart(ENPredefinedChartType.Cartesian)

            ' configure title
            chartView.Surface.Titles(0).Text = "Range Timeline Scale"

            ' configure chart
            m_Chart = CType(chartView.Surface.Charts(0), NCartesianChart)

            ' configure axes
            m_Chart.SetPredefinedCartesianAxes(ENPredefinedCartesianAxis.XOrdinalYLinear)

            ' setup X axis
            Dim axis = m_Chart.Axes(ENCartesianAxis.PrimaryX)

            m_RangeTimelineScale = New NRangeTimelineScale()
            axis.Scale = m_RangeTimelineScale

            ' setup primary Y axis
            axis = m_Chart.Axes(ENCartesianAxis.PrimaryY)
            Dim linearScale = CType(axis.Scale, NLinearScale)

            ' configure ticks and grid lines
            linearScale.MajorGridLines.Stroke = New NStroke(NColor.LightGray)
            linearScale.InnerMajorTicks.Visible = False

            ' add interlaced stripe 
            Dim strip As NScaleStrip = New NScaleStrip()
            strip.Fill = New NColorFill(NColor.Beige)
            strip.Interlaced = True
            linearScale.Strips.Add(strip)

            ' Setup the stock series
            m_Stock = New NStockSeries()
            m_Chart.Series.Add(m_Stock)

            m_Stock.DataLabelStyle = New NDataLabelStyle(False)
            m_Stock.CandleShape = ENCandleShape.Stick
            m_Stock.CandleWidth = 4
            m_Stock.UseXValues = True

            chartView.Document.StyleSheets.ApplyTheme(New NChartTheme(ENChartPalette.Bright, ENChartPaletteTarget.Series))

            OnWeeklyDataButtonClick(Nothing)

            Return chartViewWithCommandBars
        End Function
        Protected Overrides Function CreateExampleControls() As NWidget
            Dim stack As NStackPanel = New NStackPanel()
            Dim boxGroup As NUniSizeBoxGroup = New NUniSizeBoxGroup(stack)

            Dim firstRowVisibleCheckBox As NCheckBox = New NCheckBox("First Row Visible")
            firstRowVisibleCheckBox.Click += New [Function](Of NEventArgs)(AddressOf OnFirstRowVisibleCheckBoxClick)
            stack.Add(firstRowVisibleCheckBox)

            Dim secondRowVisibleCheckBox As NCheckBox = New NCheckBox("Second Row Visible")
            secondRowVisibleCheckBox.Click += New [Function](Of NEventArgs)(AddressOf OnSecondRowVisibleCheckBoxClick)
            stack.Add(secondRowVisibleCheckBox)

            Dim thirdRowVisibleCheckBox As NCheckBox = New NCheckBox("Third Row Visible")
            thirdRowVisibleCheckBox.Click += New [Function](Of NEventArgs)(AddressOf OnThirdRowVisibleCheckBoxClick)
            stack.Add(thirdRowVisibleCheckBox)

            Dim dailyDataButton As NButton = New NButton("Daily Data")
            dailyDataButton.Click += New [Function](Of NEventArgs)(AddressOf OnDailyDataButtonClick)
            stack.Add(dailyDataButton)

            Dim weeklyDataButton As NButton = New NButton("Weekly Data")
            weeklyDataButton.Click += New [Function](Of NEventArgs)(AddressOf OnWeeklyDataButtonClick)
            stack.Add(weeklyDataButton)

            Dim monthlyDataButton As NButton = New NButton("Monthly Data")
            monthlyDataButton.Click += New [Function](Of NEventArgs)(AddressOf OnMonthlyDataButtonClick)
            stack.Add(monthlyDataButton)

            Dim yearlyDataButton As NButton = New NButton("Yearly Data")
            yearlyDataButton.Click += New [Function](Of NEventArgs)(AddressOf OnYearlyDataButtonClick)
            stack.Add(yearlyDataButton)

            firstRowVisibleCheckBox.Checked = True
            secondRowVisibleCheckBox.Checked = True
            thirdRowVisibleCheckBox.Checked = True

            Return boxGroup
        End Function
        Protected Overrides Function GetExampleDescription() As String
            Return "<p>This example demonstrates how to create a range timeline scale.</p>"
        End Function

#End Region

#Region "Event Handlers"

        Private Sub OnThirdRowVisibleCheckBoxClick(ByVal arg As NEventArgs)
            m_RangeTimelineScale.FirstRow.Visible = CType(arg.TargetNode, NCheckBox).Checked
        End Sub

        Private Sub OnSecondRowVisibleCheckBoxClick(ByVal arg As NEventArgs)
            m_RangeTimelineScale.SecondRow.Visible = CType(arg.TargetNode, NCheckBox).Checked
        End Sub

        Private Sub OnFirstRowVisibleCheckBoxClick(ByVal arg As NEventArgs)
            m_RangeTimelineScale.ThirdRow.Visible = CType(arg.TargetNode, NCheckBox).Checked
        End Sub

        Private Sub OnYearlyDataButtonClick(ByVal arg As NEventArgs)
            ' generate data for 30 years
            Dim dtNow = Date.Now
            Dim dtEnd As Date = New DateTime(dtNow.Year, dtNow.Month, dtNow.Day, 7, 0, 0, 0)
            Dim dtStart As Date = NDateTimeUnit.Year.Add(dtEnd, -30)

            GenerateData(dtStart, dtEnd, New NDateTimeSpan(1, NDateTimeUnit.Month))
        End Sub

        Private Sub OnMonthlyDataButtonClick(ByVal arg As NEventArgs)
            ' generate data for 30 months 
            Dim dtNow = Date.Now
            Dim dtEnd As Date = New DateTime(dtNow.Year, dtNow.Month, dtNow.Day, 7, 0, 0, 0)
            Dim dtStart As Date = NDateTimeUnit.Month.Add(dtEnd, -30)

            GenerateData(dtStart, dtEnd, New NDateTimeSpan(1, NDateTimeUnit.Week))
        End Sub

        Private Sub OnWeeklyDataButtonClick(ByVal arg As NEventArgs)
            ' generate data for 30 weeks
            Dim dtNow = Date.Now
            Dim dtEnd As Date = New DateTime(dtNow.Year, dtNow.Month, dtNow.Day, 7, 0, 0, 0)
            Dim dtStart As Date = NDateTimeUnit.Week.Add(dtEnd, -30)

            GenerateData(dtStart, dtEnd, New NDateTimeSpan(1, NDateTimeUnit.Day))
        End Sub

        Private Sub OnDailyDataButtonClick(ByVal arg As NEventArgs)
            ' generate data for 30 days
            Dim dtNow = Date.Now
            Dim dtEnd As Date = New DateTime(dtNow.Year, dtNow.Month, dtNow.Day, 17, 0, 0, 0)
            Dim dtStart As Date = New DateTime(dtNow.Year, dtNow.Month, dtNow.Day, 7, 0, 0, 0)

            GenerateData(dtStart, dtEnd, New NDateTimeSpan(5, NDateTimeUnit.Minute))
        End Sub

#End Region

#Region "Implementation"

        Private Sub GenerateData(ByVal dtStart As Date, ByVal dtEnd As Date, ByVal span As NDateTimeSpan)
            Dim count As Long = span.GetSpanCountInRange(New NDateTimeRange(dtStart, dtEnd))

            Dim open, high, low, close As Double

            m_Stock.DataPoints.Clear()
            Dim random As Random = New Random()
            Dim dtNow = dtStart

            Dim prevClose As Double = 100

            For nIndex As Integer = 0 To count - 1
                open = prevClose

                If prevClose < 25 OrElse random.NextDouble() > 0.5 Then
                    ' upward price change
                    close = open + (2 + (random.NextDouble() * 20))
                    high = close + (random.NextDouble() * 10)
                    low = open - (random.NextDouble() * 10)
                Else
                    ' downward price change
                    close = open - (2 + (random.NextDouble() * 20))
                    high = open + (random.NextDouble() * 10)
                    low = close - (random.NextDouble() * 10)
                End If

                If low < 1 Then
                    low = 1
                End If

                prevClose = close

                m_Stock.DataPoints.Add(New NStockDataPoint(NDateTimeHelpers.ToOADate(dtNow), open, close, high, low))
                dtNow = span.Add(dtNow)
            Next
        End Sub

#End Region

#Region "Fields"

        Private m_Chart As NCartesianChart
        Private m_Stock As NStockSeries
        Private m_RangeTimelineScale As NRangeTimelineScale

#End Region

#Region "Schema"

        Public Shared ReadOnly NRangeTimelineScaleExampleSchema As NSchema

#End Region
    End Class
End Namespace

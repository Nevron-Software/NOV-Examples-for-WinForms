Imports System

Imports Nevron.Nov.Chart
Imports Nevron.Nov.Dom
Imports Nevron.Nov.Graphics
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.Chart
    ''' <summary>
    ''' Real Time Bar Example.
    ''' </summary>
    Public Class NRealTimeBarExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' Default constructor
        ''' </summary>
        Public Sub New()

        End Sub
        ''' <summary>
        ''' Static constructor
        ''' </summary>
        Shared Sub New()
            NRealTimeBarExampleSchema = NSchema.Create(GetType(NRealTimeBarExample), NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            Dim chartViewWithCommandBars As NChartViewWithCommandBars = New NChartViewWithCommandBars()
            Dim chartView = chartViewWithCommandBars.View
            chartView.Surface.CreatePredefinedChart(ENPredefinedChartType.Cartesian)

            chartView.Registered += AddressOf OnChartViewRegistered
            chartView.Unregistered += AddressOf OnChartViewUnregistered

            ' configure title
            chartView.Surface.Titles(0).Text = "Real Time Bar"

            ' configure chart
            m_Chart = CType(chartView.Surface.Charts(0), NCartesianChart)

            m_Chart.SetPredefinedCartesianAxes(ENPredefinedCartesianAxis.XYLinear)

            Dim scaleY As NLinearScale = m_Chart.Axes(ENCartesianAxis.PrimaryX).Scale
            scaleY.InflateViewRangeBegin = False
            scaleY.InflateViewRangeEnd = False

            ' add interlaced stripe to the Y axis
            Dim strip As NScaleStrip = New NScaleStrip(New NColorFill(ENNamedColor.Beige), Nothing, True, 0, 0, 1, 1)
            strip.Interlaced = True
            m_Chart.Axes(ENCartesianAxis.PrimaryY).Scale.Strips.Add(strip)

            m_Random = New Random()

            m_Bar = New NBarSeries()
            m_Bar.Name = "Line Series"
            m_Bar.InflateMargins = True
            m_Bar.DataLabelStyle = New NDataLabelStyle(False)
            m_Bar.UseXValues = True
            m_Bar.WidthSizeMode = ENBarSizeMode.Scale
            m_Bar.Width = 0.5
            m_CurXValue = 0

            m_Chart.Series.Add(m_Bar)

            chartView.Document.StyleSheets.ApplyTheme(New NChartTheme(ENChartPalette.Bright, ENChartPaletteTarget.Series))

            Return chartViewWithCommandBars
        End Function
        Protected Overrides Function CreateExampleControls() As NWidget
            Dim stack As NStackPanel = New NStackPanel()
            Dim group As NUniSizeBoxGroup = New NUniSizeBoxGroup(stack)

            Dim toggleTimerButton As NButton = New NButton("Stop Timer")
            toggleTimerButton.Click += AddressOf OnToggleTimerButtonClick
            toggleTimerButton.Tag = 0
            stack.Add(toggleTimerButton)

            Dim resetButton As NButton = New NButton("Reset Data")
            resetButton.Click += AddressOf OnResetButtonClick
            stack.Add(resetButton)

            Return group
        End Function
        Protected Overrides Function GetExampleDescription() As String
            Return "<p>This example demonstrates how to create a bar chart that updates in real time.</p>"
        End Function

#End Region

#Region "Event Handlers"

        Private Sub OnChartViewRegistered(ByVal arg As NEventArgs)
            m_Timer = New NTimer()
            Me.m_Timer.Tick += AddressOf OnTimerTick
            m_Timer.Start()
        End Sub

        Private Sub OnChartViewUnregistered(ByVal arg As NEventArgs)
            m_Timer.Stop()
            Me.m_Timer.Tick -= AddressOf OnTimerTick
            m_Timer = Nothing
        End Sub

        Private Sub OnTimerTick()
            Const dataPointCount = 40
            If m_Bar.DataPoints.Count < dataPointCount Then
                m_Bar.DataPoints.Add(New NBarDataPoint(Math.Min(System.Threading.Interlocked.Increment(m_CurXValue), m_CurXValue - 1), m_Random.Next(80) + 20))
            Else
                m_Bar.DataPoints(m_Bar.OriginIndex).X = Math.Min(System.Threading.Interlocked.Increment(m_CurXValue), m_CurXValue - 1)
                m_Bar.DataPoints(m_Bar.OriginIndex).Value = m_Random.Next(80) + 20

                m_Bar.OriginIndex += 1

                If m_Bar.OriginIndex >= m_Bar.DataPoints.Count Then
                    m_Bar.OriginIndex = 0
                End If
            End If
        End Sub

        Private Sub OnResetButtonClick(ByVal arg As NEventArgs)
            m_Bar.DataPoints.Clear()
            m_Bar.OriginIndex = 0
            m_CurXValue = 0
        End Sub

        Private Sub OnToggleTimerButtonClick(ByVal arg As NEventArgs)
            Dim button = CType(arg.TargetNode, NButton)
            If CInt(button.Tag) = 0 Then
                m_Timer.Stop()

                button.Content = New NLabel("Start Timer")
                button.Tag = 1
            Else
                m_Timer.Start()
                button.Content = New NLabel("Stop Timer")
                button.Tag = 0
            End If
        End Sub

#End Region

#Region "Fields"

        Private m_Chart As NCartesianChart
        Private m_Bar As NBarSeries

        Private m_Random As Random
        Private m_Timer As NTimer
        Private m_CurXValue As Integer

#End Region

#Region "Schema"

        Public Shared ReadOnly NRealTimeBarExampleSchema As NSchema

#End Region
    End Class
End Namespace

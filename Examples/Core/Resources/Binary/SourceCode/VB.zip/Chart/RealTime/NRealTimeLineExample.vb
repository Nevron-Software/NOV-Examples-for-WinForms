Imports System
Imports Nevron.Nov.Chart
Imports Nevron.Nov.Dom
Imports Nevron.Nov.Graphics
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.Chart
    ''' <summary>
    ''' Real Time Line Example.
    ''' </summary>
    Public Class NRealTimeLineExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' Default constructor
        ''' </summary>
        Public Sub New()
        End Sub
        ''' <summary>
        ''' Static constructor
        ''' </summary>
        Shared Sub New()
            NRealTimeLineExampleSchema = NSchema.Create(GetType(NRealTimeLineExample), NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            Dim chartView As NChartView = CreateCartesianChartView()
            AddHandler chartView.Registered, AddressOf OnChartViewRegistered
            AddHandler chartView.Unregistered, AddressOf OnChartViewUnregistered

            ' configure title
            chartView.Surface.Titles(0).Text = "Real Time Line"

            ' configure chart
            m_Chart = CType(chartView.Surface.Charts(0), NCartesianChart)
            m_Chart.SetPredefinedCartesianAxes(ENPredefinedCartesianAxis.XYLinear)
            Dim scaleY = CType(m_Chart.Axes(ENCartesianAxis.PrimaryX).Scale, NLinearScale)
            scaleY.InflateViewRangeBegin = False
            scaleY.InflateViewRangeEnd = False

            ' add interlaced stripe to the Y axis
            Dim strip As NScaleStrip = New NScaleStrip(New NColorFill(ENNamedColor.Beige), Nothing, True, 0, 0, 1, 1)
            strip.Interlaced = True
            m_Chart.Axes(ENCartesianAxis.PrimaryY).Scale.Strips.Add(strip)
            m_Random = New Random()
            m_Line = New NLineSeries()
            m_Line.Name = "Line Series"
            m_Line.InflateMargins = True
            m_Line.DataLabelStyle = New NDataLabelStyle(False)
            m_Line.MarkerStyle = New NMarkerStyle(New NSize(4, 4))
            m_Line.UseXValues = True
            m_CurXValue = 0
            m_Chart.Series.Add(m_Line)
            chartView.Document.StyleSheets.ApplyTheme(New NChartTheme(ENChartPalette.Bright, False))
            Return chartView
        End Function

        Protected Overrides Function CreateExampleControls() As NWidget
            Dim stack As NStackPanel = New NStackPanel()
            Dim group As NUniSizeBoxGroup = New NUniSizeBoxGroup(stack)
            Dim toggleTimerButton As NButton = New NButton("Stop Timer")
            AddHandler toggleTimerButton.Click, AddressOf OnToggleTimerButtonClick
            toggleTimerButton.Tag = 0
            stack.Add(toggleTimerButton)
            Dim resetButton As NButton = New NButton("Reset Data")
            AddHandler resetButton.Click, AddressOf OnResetButtonClick
            stack.Add(resetButton)
            Return group
        End Function

        Protected Overrides Function GetExampleDescription() As String
            Return "<p>This example demonstrates how to create a line chart that updates in real time.</p>"
        End Function

#End Region

#Region "Event Handlers"

        Private Sub OnChartViewRegistered(ByVal arg As NEventArgs)
            m_Timer = New NTimer()
            AddHandler m_Timer.Tick, AddressOf OnTimerTick
            m_Timer.Start()
        End Sub

        Private Sub OnChartViewUnregistered(ByVal arg As NEventArgs)
            m_Timer.Stop()
            RemoveHandler m_Timer.Tick, AddressOf OnTimerTick
            m_Timer = Nothing
        End Sub

        Private Sub OnTimerTick()
            Const dataPointCount = 40

            If m_Line.DataPoints.Count < dataPointCount Then
                m_Line.DataPoints.Add(New NLineDataPoint(Math.Min(System.Threading.Interlocked.Increment(m_CurXValue), m_CurXValue - 1), m_Random.Next(80) + 20))
            Else
                m_Line.DataPoints(m_Line.OriginIndex).X = Math.Min(System.Threading.Interlocked.Increment(m_CurXValue), m_CurXValue - 1)
                m_Line.DataPoints(m_Line.OriginIndex).Value = m_Random.Next(80) + 20
                m_Line.OriginIndex += 1

                If m_Line.OriginIndex >= m_Line.DataPoints.Count Then
                    m_Line.OriginIndex = 0
                End If
            End If
        End Sub

        Private Sub OnResetButtonClick(ByVal arg As NEventArgs)
            m_Line.DataPoints.Clear()
            m_Line.OriginIndex = 0
            m_CurXValue = 0
        End Sub

        Private Sub OnToggleTimerButtonClick(ByVal arg As NEventArgs)
            Dim button = CType(arg.TargetNode, NButton)

            If CInt(button.Tag) = 0 Then
                m_Timer.Stop()
                button.Content = New NLabel("Start Timer")
                button.Tag = 1
            Else
                m_Timer.Start()
                button.Content = New NLabel("Stop Timer")
                button.Tag = 0
            End If
        End Sub

#End Region

#Region "Fields"

        Private m_Chart As NCartesianChart
        Private m_Line As NLineSeries
        Private m_Random As Random
        Private m_Timer As NTimer
        Private m_CurXValue As Integer

#End Region

#Region "Schema"

        Public Shared ReadOnly NRealTimeLineExampleSchema As NSchema

#End Region

#Region "Static Methods"

        Private Shared Function CreateCartesianChartView() As NChartView
            Dim chartView As NChartView = New NChartView()
            chartView.Surface.CreatePredefinedChart(ENPredefinedChartType.Cartesian)
            Return chartView
        End Function

#End Region
    End Class
End Namespace

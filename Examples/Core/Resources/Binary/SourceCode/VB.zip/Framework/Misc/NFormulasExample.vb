Imports System
Imports Nevron.Nov.DataStructures
Imports Nevron.Nov.Dom
Imports Nevron.Nov.Formulas
Imports Nevron.Nov.Layout
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.Framework
    Public Class NFormulasExample
        Inherits NExampleBase
#Region "Constructors"

        Public Sub New()
        End Sub

        Shared Sub New()
            NFormulasExampleSchema = NSchema.Create(GetType(NFormulasExample), NExampleBase.NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            m_FormulaEngine = New NFormulaEngine()
            Dim stack As NStackPanel = New NStackPanel()
            NDockLayout.SetDockArea(stack, ENDockArea.Center)
            m_InputTextBox = New NTextBox()
            stack.Add(m_InputTextBox)
            Dim hstack As NStackPanel = New NStackPanel()
            hstack.Direction = ENHVDirection.LeftToRight
            stack.Add(hstack)
            Dim evaluateButton As NButton = New NButton("Evaluate")
            AddHandler evaluateButton.Click, New [Function](Of NEventArgs)(AddressOf OnEvaluateButtonClick)
            hstack.Add(evaluateButton)
            Dim evaluateAllButton As NButton = New NButton("Evaluate All")
            AddHandler evaluateAllButton.Click, New [Function](Of NEventArgs)(AddressOf OnEvaluateAllButtonClick)
            hstack.Add(evaluateAllButton)
            m_ResultTextBox = New NTextBox()
            stack.Add(m_ResultTextBox)
            Return stack
        End Function

        Protected Overrides Function CreateExampleControls() As NWidget
            Dim testsView As NTreeView = CreateTestsTreeView()
            Return New NGroupBox("Predefined Examples", testsView)
        End Function

        Protected Overrides Function GetExampleDescription() As String
            Return "
<p>
Demonstrates the strong support for Formulas. Formula expressions can be assigned to any DOM Element property.
</p>
"
        End Function

#End Region

#Region "Implementation"

        Private Function CreateTestsTreeView() As NTreeView
            Dim categoryItem, folderItem As NTreeViewItem
            Dim treeView As NTreeView = New NTreeView()
            m_TestsTreeView = treeView

#Region "Operators"

            folderItem = New NTreeViewItem("Operators")
            treeView.Items.Add(folderItem)

#Region "Arithmetic Operators"

            categoryItem = New NTreeViewItem("Arithmetic")
            folderItem.Items.Add(categoryItem)
            CreateTestItems(categoryItem, New String() {"+10", "-10", "-ARRAY(10, 12)", "10 ^ 2", "ARRAY(10, 12) ^ 2", "10 * 2", "ARRAY(10, 12) * 2", "10 / 2", "ARRAY(10, 12) / 2", "10 + 2", "ARRAY(10, 12) + 2", "ARRAY(10, 12) + ARRAY(12, 23)", "10 + ""Nevron""", "10 - 2", "ARRAY(10, 12) - 2", "ARRAY(10, 12) - ARRAY(12, 23)"})

#End Region

#Region "Comparision Operators"

            categoryItem = New NTreeViewItem("Comparision")
            folderItem.Items.Add(categoryItem)
            CreateTestItems(categoryItem, New String() {"10 > 2", "10 < 2", "10 >= 2", "10 >= 10", "10 <= 2", "10 <= 10", "10 == 2", "10 != 2"})

#End Region

#Region "Logical operators"

            categoryItem = New NTreeViewItem("Logical")
            folderItem.Items.Add(categoryItem)
            CreateTestItems(categoryItem, New String() {"true && false", "true || false", "!true"})

#End Region

#Region "Bitwise operators"

            categoryItem = New NTreeViewItem("Bitwise")
            folderItem.Items.Add(categoryItem)
            CreateTestItems(categoryItem, New String() {"7 & 2", "5 | 3", "~1"})

#End Region

#Region "Assignment operators"

            categoryItem = New NTreeViewItem("Assignment")
            folderItem.Items.Add(categoryItem)
            CreateTestItems(categoryItem, New String() {"a=5; b=3; a+b;", "a=5; a+=3", "a=5; a-=3"})

#End Region

#End Region

#Region "Functions"

            folderItem = New NTreeViewItem("Functions")
            treeView.Items.Add(folderItem)

#Region "Bitwise "

            categoryItem = New NTreeViewItem("Bitwise")
            folderItem.Items.Add(categoryItem)
            CreateTestItems(categoryItem, New String() {"BITAND(7,2)", "BITNOT(1)", "BITOR(5,3)", "BITXOR(5,3)"})

#End Region

#Region "Logical"

            categoryItem = New NTreeViewItem("Logical")
            folderItem.Items.Add(categoryItem)
            CreateTestItems(categoryItem, New String() {"AND(true, false)", "AND(true, false)", "IF(true, 2, 10)", "IF(false, 2, 10)", "NOT(true)", "OR(true, false)"})

#End Region

#Region "Mathematical"

            categoryItem = New NTreeViewItem("Mathematical")
            folderItem.Items.Add(categoryItem)
            CreateTestItems(categoryItem, New String() {"ABS(-2.5)", "CEILING(1.7)", "CEILING(1.7, 0.25)", "FLOOR(1.7)", "FLOOR(1.7, 0.25)", "INT(1.2)", "INT(-1.2)", "INTUP(1.2)", "INTUP(-1.2)", "LN(10)", "LOG10(10)", "MAGNITUDE(3, 4)", "MAX(1, 3, 2)", "MIN(1, 3, 2)", "MOD(5, 1.4)", "MOD(5, -1.4)", "POW(10, 2)", "ROUND(123.654,2)", "ROUND(123.654,0)", "ROUND(123.654,-1)", "SIGN(-10)", "SIGN(0)", "SQRT(4)", "SUM(1,2,3)", "TRUNC(123.654,2)", "TRUNC(123.654,0)", "TRUNC(123.654,-1)"})

#End Region

#Region "Text"

            categoryItem = New NTreeViewItem("Text")
            folderItem.Items.Add(categoryItem)
            CreateTestItems(categoryItem, New String() {"CHAR(9)", "LEN(""Hello World"")", "LOWER(""Hello World"")", "STRSAME(""Hello"", ""hello"")", "STRSAME(""Hello"", ""hello"", true)", "TRIM("" Hello World "")", "UPPER(""Hello World"")", "INDEX(0,""Hello;World"")"})

#End Region

#Region "Trigonometrical"

            Dim trigonometrical As NTreeViewItem = New NTreeViewItem("Trigonometrical")
            folderItem.Items.Add(trigonometrical)
            CreateTestItems(trigonometrical, New String() {"ACOS(0)", "ANG360(1.4 + 2 * PI())", "ASIN(1)", "ATAN2(1,1)", "ATAN2(1,SQRT(3))", "ATAN(1)", "COS(0)", "COSH(PI()/4)", "PI()", "SIN(0)", "SINH(PI()/4)", "TAN(PI()/4)", "TANH(-PI()/4)"})

#End Region

#Region "Type"

            Dim type As NTreeViewItem = New NTreeViewItem("Type")
            folderItem.Items.Add(type)
            CreateTestItems(type, New String() {"EMPTY()", "ISARRAY(ARRAY(10,20))", "ISARRAY(10)", "ISBOOL(true)", "ISBOOL(false)", "ISBOOL(""true"")", "ISDATETIME(10)", "ISDATETIME(DATETIME(2008,9,15))", "ISEMPTY(EMPTY())", "ISEMPTY(true)", "ISMEASURE(10[mm])", "ISMEASURE(10)", "ISNUM(10)", "ISNUM(true)", "ISSTR(true)", "ISSTR(""hello world"")", "TOBOOL(""false"")", "TOBOOL(""true"")", "TOBOOL(""hello"")", "TODATETIME(""2008-09-15 09:30:41.770"")", "TONUM(true)", "TONUM(""10"")", "TONUM(""hello"")", "TOSTR(10)"})

#End Region

#End Region

            treeView.ExpandAll(True)
            AddHandler treeView.SelectedPathChanged, New [Function](Of NValueChangeEventArgs)(AddressOf OnTestsTreeViewSelectedPathChanged)
            Return treeView
        End Function

        Private Sub CreateTestItems(ByVal parentItem As NTreeViewItem, ByVal formulas As String())
            For i = 0 To formulas.Length - 1
                parentItem.Items.Add(CreateTestItem(formulas(i)))
            Next
        End Sub

        Private Function CreateTestItem(ByVal formula As String) As NTreeViewItem
            Dim item As NTreeViewItem = New NTreeViewItem(formula)
            item.Tag = formula
            Return item
        End Function

        Private Sub OnTestsTreeViewSelectedPathChanged(ByVal arg As NValueChangeEventArgs)
            Dim item = m_TestsTreeView.SelectedItem
            If item Is Nothing OrElse item.Tag Is Nothing Then Return
            m_InputTextBox.Text = item.Tag.ToString()
            EvaluateFormula()
        End Sub

        Private Sub OnEvaluateButtonClick(ByVal arg As NEventArgs)
            EvaluateFormula()
        End Sub

        Private Sub OnEvaluateAllButtonClick(ByVal arg As NEventArgs)
            Dim tests As NList(Of String) = New NList(Of String)()
            Dim it As INIterator(Of NNode) = m_TestsTreeView.GetSubtreeIterator()

            While it.MoveNext()
                Dim item As NTreeViewItem = TryCast(it.Current, NTreeViewItem)
                If item Is Nothing OrElse item.Tag Is Nothing OrElse Not (TypeOf item.Tag Is String) Then Continue While
                tests.Add(CStr(item.Tag))
            End While

            Dim stopwatch As NStopwatch = New NStopwatch()
            stopwatch.Start()
            Dim itcount = 10000

            For j = 0 To itcount - 1

                For i = 0 To tests.Count - 1

                    Try
                        m_FormulaEngine.Evaluate(tests(i))
                    Catch ex As Exception
                        m_ResultTextBox.Text = "Failed on test: " & tests(i) & ". Error was: " & ex.Message
                        m_InputTextBox.Text = tests(i)
                        Return
                    End Try
                Next
            Next

            stopwatch.Stop()
            Dim ms = stopwatch.ElapsedMilliseconds
            m_ResultTextBox.Text = tests.Count & " tests performed " & itcount & " times in: " & ms & " milliseconds."
        End Sub

        Private Sub EvaluateFormula()
            Try
                Dim result = m_FormulaEngine.Evaluate(m_InputTextBox.Text)
                m_ResultTextBox.Text = result.ToString()
            Catch ex As Exception
                m_ResultTextBox.Text = ex.Message
            End Try
        End Sub

#End Region

#Region "Fields"

        Private m_InputTextBox As NTextBox
        Private m_ResultTextBox As NTextBox
        Private m_TestsTreeView As NTreeView
        Private m_FormulaEngine As NFormulaEngine

#End Region

#Region "Schema"

        Public Shared ReadOnly NFormulasExampleSchema As NSchema

#End Region
    End Class
End Namespace

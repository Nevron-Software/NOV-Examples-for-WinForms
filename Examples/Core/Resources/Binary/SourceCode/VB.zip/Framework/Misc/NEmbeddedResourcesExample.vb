Imports System.Globalization
Imports Nevron.Nov.Data
Imports Nevron.Nov.DataStructures
Imports Nevron.Nov.Dom
Imports Nevron.Nov.Graphics
Imports Nevron.Nov.Grid
Imports Nevron.Nov.Layout
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.Framework
    Public Class NEmbeddedResourcesExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' Default constructor.
        ''' </summary>
        Public Sub New()
        End Sub

        ''' <summary>
        ''' Static constructor.
        ''' </summary>
        Shared Sub New()
            NEmbeddedResourcesExampleSchema = NSchema.Create(GetType(NEmbeddedResourcesExample), NExampleBase.NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            m_TreeView = New NTreeView()
            AddHandler m_TreeView.SelectedPathChanged, AddressOf OnTreeViewSelectedPathChanged
            m_ResourcesMap = New NMap(Of NTreeViewItem, NEmbeddedResourceContainer)()
            m_TreeView.Items.Add(CreateRootItem(Presentation.NResources.Instance))
            m_TreeView.Items.Add(CreateRootItem(Diagram.NResources.Instance))
            m_TreeView.Items.Add(CreateRootItem(Text.NResources.Instance))
            m_TreeView.Items.Add(CreateRootItem(Schedule.NResources.Instance))
            m_TreeView.Items.Add(CreateRootItem(NResources.Instance))

            ' Create a data table
            m_DataTable = New NMemoryDataTable()
            m_DataTable.AddField(New NFieldInfo("Image", GetType(NImage)))
            m_DataTable.AddField(New NFieldInfo("Name", GetType(String)))
            m_DataTable.AddField(New NFieldInfo("Size", GetType(String)))
            m_DataTable.AddField(New NFieldInfo("Action", GetType(String)))

            ' Create a grid view
            m_GridView = New NTableGridView()
            m_GridView.GroupingPanel.Visibility = ENVisibility.Collapsed
            m_GridView.ReadOnly = True
            Dim tableGrid = m_GridView.Grid
            tableGrid.AlternatingRows = False
            tableGrid.RowHeaders.Visible = False
            AddHandler tableGrid.AutoCreateColumn, AddressOf OnGridAutoCreateColumn
            tableGrid.DataSource = New NDataSource(m_DataTable)
            Dim splitter As NSplitter = New NSplitter(m_TreeView, m_GridView, ENSplitterSplitMode.OffsetFromNearSide, 200)
            Return splitter
        End Function

        Protected Overrides Function CreateExampleControls() As NWidget
            Return Nothing
        End Function

        Protected Overrides Function GetExampleDescription() As String
            Return "
<p>
	Browser for all resources embedded in the NOV assemblies. Select a category from the tree view
	with resources and then click the <b>Copy Code</b> button in the grid next to the image resource
	you are interested in to copy the code for using it to the clipboard.
</p>
"
        End Function

#End Region

#Region "Implementation"

        Private Function CreateRootItem(ByVal resourceContainer As NEmbeddedResourceContainer) As NTreeViewItem
            Dim nspace As String = resourceContainer.GetType().Namespace
            Dim name = nspace.Substring("Nevron.Nov.".Length)
            Dim rootItem As NTreeViewItem = New NTreeViewItem(name)
            m_ResourcesMap.Set(rootItem, resourceContainer)
            rootItem.Expanded = True
            Dim names As String() = resourceContainer.GetResourceNames()

            For i = 0 To names.Length - 1
                Dim tokens = names(i).Split("_"c)
                If Not Equals(tokens(0), "RIMG") Then Continue For

                ' Navigate to the path of the current image resource in the tree view
                Dim item = rootItem

                For j = 1 To tokens.Length - 2 - 1
                    item = GetOrCreateItem(item.Items, tokens(j))
                Next

                ' Add the image resource to the path
                Dim images = GetImageNames(item)

                If images Is Nothing Then
                    images = New NList(Of String)()
                    item.Tag = images
                End If

                images.Add(names(i))
            Next

            Return rootItem
        End Function

        Private Function GetOrCreateItem(ByVal items As NTreeViewItemCollection, ByVal name As String) As NTreeViewItem
            Dim i = 0, count = items.Count

            While i < count
                Dim label = CType(items(i).Header.GetFirstDescendant(NLabel.NLabelSchema), NLabel)
                If Equals(label.Text, name) Then Return items(i)
                i += 1
            End While

            Dim item As NTreeViewItem = New NTreeViewItem(NPairBox.Create(NResources.Image__16x16_Folders_png, name))
            items.Add(item)
            Return item
        End Function

        Private Function GetResourceContainer(ByVal item As NTreeViewItem) As NEmbeddedResourceContainer
            ' Find the root item of the given item
            While item.ParentItem IsNot Nothing
                item = item.ParentItem
            End While

            ' Return the resource container represented by this root item
            Return m_ResourcesMap(item)
        End Function

        Private Function GetImageNames(ByVal item As NTreeViewItem) As NList(Of String)
            Return CType(item.Tag, NList(Of String))
        End Function

#End Region

#Region "Event Handlers"

        Private Sub OnTreeViewSelectedPathChanged(ByVal arg As NValueChangeEventArgs)
            m_DataTable.RemoveAllRows()
            m_GridView.Grid.Update()
            Dim treeView = CType(arg.CurrentTargetNode, NTreeView)
            Dim selectedItem = treeView.SelectedItem
            If selectedItem Is Nothing Then Return

            ' Get the resource container and the images for the selected item
            Dim resourceContainer = GetResourceContainer(selectedItem)
            Dim images = GetImageNames(selectedItem)

            ' Populate the stack with the images in the selected resources folder
            Dim containerType As String = resourceContainer.GetType().FullName

            For i = 0 To images.Count - 1
                Dim resourceName = images(i)
                Dim imageName = resourceName.Replace("RIMG", "Image")
                Dim image = NImage.FromResource(resourceContainer.GetResource(resourceName))
                Dim imageSize = image.Width.ToString(CultureInfo.InvariantCulture) & " x " & image.Height.ToString(CultureInfo.InvariantCulture)
                Dim code = containerType & "." & imageName
                m_DataTable.AddRow(image, imageName, imageSize, code)
            Next
        End Sub

        Private Sub OnGridAutoCreateColumn(ByVal arg As NAutoCreateColumnEventArgs)
            Dim dataColumn = arg.DataColumn

            If Equals(dataColumn.FieldName, "Action") Then
                dataColumn.Format = New NButtonColumnFormat()
            End If
        End Sub

#End Region

#Region "Fields"

        Private m_TreeView As NTreeView
        Private m_GridView As NTableGridView
        Private m_DataTable As NMemoryDataTable
        Private m_ResourcesMap As NMap(Of NTreeViewItem, NEmbeddedResourceContainer)

#End Region

#Region "Schema"

        ''' <summary>
        ''' Schema associated with NEmbeddedResourcesExample.
        ''' </summary>
        Public Shared ReadOnly NEmbeddedResourcesExampleSchema As NSchema

#End Region

#Region "Nested Types"

        Private Class NButtonColumnFormat
            Inherits NColumnFormat
#Region "Constructors"

            ''' <summary>
            ''' Default constructor.
            ''' </summary>
            Public Sub New()
            End Sub

            ''' <summary>
            ''' Static constructor.
            ''' </summary>
            Shared Sub New()
                NButtonColumnFormatSchema = NSchema.Create(GetType(NButtonColumnFormat), NColumnFormatSchema)
            End Sub

#End Region

#Region "Overrides"

            Public Overrides Sub FormatDefaultDataCell(ByVal dataCell As NDataCell)
            End Sub

            Protected Overrides Function CreateValueDataCellView(ByVal dataCell As NDataCell, ByVal rowValue As Object) As NWidget
                Dim button As NButton = New NButton("Copy Code")
                button.Tag = rowValue
                AddHandler button.Click, AddressOf OnButtonClick
                Return button
            End Function

            Protected Overrides Function GetAutomaticHorizontalAlignment(ByVal dataCell As NDataCell, ByVal rowValue As Object) As ENHorizontalPlacement
                Return ENHorizontalPlacement.Center
            End Function

#End Region

#Region "Event Handlers"

            Private Sub OnButtonClick(ByVal arg As NEventArgs)
                NClipboard.SetText(CStr(arg.CurrentTargetNode.Tag))
            End Sub

#End Region

#Region "Schema"

            ''' <summary>
            ''' Schema associated with NButtonColumnFormat.
            ''' </summary>
            Public Shared ReadOnly NButtonColumnFormatSchema As NSchema

#End Region
        End Class

#End Region
    End Class
End Namespace

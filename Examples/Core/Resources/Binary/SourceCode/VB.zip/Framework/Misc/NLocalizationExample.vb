Imports System
Imports System.IO
Imports Nevron.Nov.Dom
Imports Nevron.Nov.Globalization
Imports Nevron.Nov.Graphics
Imports Nevron.Nov.Layout
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.Framework
    Public Class NLocalizationExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' Default constructor.
        ''' </summary>
        Public Sub New()
        End Sub

        ''' <summary>
        ''' Static constructor.
        ''' </summary>
        Shared Sub New()
            NLocalizationExampleSchema = NSchema.Create(GetType(NLocalizationExample), NExampleBase.NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            CreateDictionaries()
            m_CalculatorHost = New NContentHolder()
            m_CalculatorHost.Content = CreateLoanCalculator()
            Return m_CalculatorHost
        End Function

        Protected Overrides Function CreateExampleControls() As NWidget
            Dim stack As NStackPanel = New NStackPanel()
            stack.Add(New NLabel("Language:"))
            Dim listBox As NListBox = New NListBox()
            listBox.Items.Add(CreateListBoxItem(NResources.Image_CountryFlags_us_png, EnglishLanguageName))
            listBox.Items.Add(CreateListBoxItem(NResources.Image_CountryFlags_bg_png, BulgarianLanguageName))
            listBox.Items.Add(CreateListBoxItem(NResources.Image_CountryFlags_de_png, GermanLanguageName))
            listBox.Selection.SingleSelect(listBox.Items(0))
            AddHandler listBox.Selection.Selected, AddressOf OnListBoxItemSelected
            stack.Add(listBox)
            Return stack
        End Function

        Protected Overrides Function GetExampleDescription() As String
            Return "
<p>
	This example demonstrates how to take advantage of the NOV localization. Localization is the process
	of translating string literals used inside an application to different language. In your application's source
	code you should write localizable strings as NLoc.Get(""My string"") instead of directly as ""My string"".
	Thus on run time the string translation will be obtained from the localization dictionary instance.
</p>
<p>
	To see the localization in action, simply select a language from the list box on the right.
</p>
"
        End Function

#End Region

#Region "Implementation"

        Private Sub CreateDictionaries()
            Dim dictionary = NLocalizationDictionary.Instance

            ' Create the stream for the Bulgarian dictionary
            dictionary.SetTranslation("Loan Calculator", "Кредитен калкулатор")
            dictionary.SetTranslation("Amount:", "Количество:")
            dictionary.SetTranslation("Term in years:", "Срок в години:")
            dictionary.SetTranslation("Interest rate per year (%):", "Годишна лихва (%):")
            dictionary.SetTranslation("Repayment Summary", "Информация за погасяване")
            dictionary.SetTranslation("Monthly Payment:", "Месечна вноска:")
            dictionary.SetTranslation("Total Payments:", "Сума за връщане:")
            dictionary.SetTranslation("Total Interest:", "Общо лихви:")
            m_BulgarianStream = New MemoryStream()
            dictionary.SaveToStream(m_BulgarianStream)

            ' Create the stream for the German Dictionary
            dictionary.SetTranslation("Loan Calculator", "Kreditrechner")
            dictionary.SetTranslation("Amount:", "Kreditbetrag:")
            dictionary.SetTranslation("Term in years:", "Laufzeit in Jahren:")
            dictionary.SetTranslation("Interest rate per year (%):", "Zinssatz pro Jahr (%):")
            dictionary.SetTranslation("Repayment Summary", "Rückzahlung Zusammenfassung")
            dictionary.SetTranslation("Monthly Payment:", "Monatliche Bezahlung:")
            dictionary.SetTranslation("Total Payments:", "Gesamtbetrag:")
            dictionary.SetTranslation("Total Interest:", "Gesamtzins:")
            m_GermanStream = New MemoryStream()
            dictionary.SaveToStream(m_GermanStream)

            ' Create the stream for the English dictionary
            dictionary.SetTranslation("Loan Calculator", "Loan Calculator")
            dictionary.SetTranslation("Amount:", "Amount:")
            dictionary.SetTranslation("Term in years:", "Term in years:")
            dictionary.SetTranslation("Interest rate per year (%):", "Interest rate per year (%):")
            dictionary.SetTranslation("Repayment Summary", "Repayment Summary")
            dictionary.SetTranslation("Monthly Payment:", "Monthly Payment:")
            dictionary.SetTranslation("Total Payments:", "Total Payments:")
            dictionary.SetTranslation("Total Interest:", "Total Interest:")
            m_EnglishStream = New MemoryStream()
            dictionary.SaveToStream(m_EnglishStream)
        End Sub

        Private Function CreateLoanCalculator() As NWidget
            Dim stack As NStackPanel = New NStackPanel()
            stack.Font = New NFont(NFontDescriptor.DefaultSansFamilyName, 10)
            stack.HorizontalPlacement = ENHorizontalPlacement.Left
            stack.VerticalSpacing = NDesign.VerticalSpacing * 2
            Dim titleLabel As NLabel = New NLabel(NLoc.Get("Loan Calculator"))
            titleLabel.Font = New NFont(NFontDescriptor.DefaultSansFamilyName, 16)
            titleLabel.Margins = New NMargins(0, 0, 0, NDesign.VerticalSpacing)
            titleLabel.TextAlignment = ENContentAlignment.MiddleCenter
            stack.Add(titleLabel)
            m_AmountUpDown = New NNumericUpDown()
            m_AmountUpDown.Value = 10000
            m_AmountUpDown.Step = 500
            AddHandler m_AmountUpDown.ValueChanged, AddressOf OnUpDownValueChanged
            stack.Add(NPairBox.Create(NLoc.Get("Amount:"), m_AmountUpDown))
            m_TermUpDown = New NNumericUpDown()
            m_TermUpDown.Value = 8
            AddHandler m_TermUpDown.ValueChanged, AddressOf OnUpDownValueChanged
            stack.Add(NPairBox.Create(NLoc.Get("Term in years:"), m_TermUpDown))
            m_RateUpDown = New NNumericUpDown()
            m_RateUpDown.Value = 5
            m_RateUpDown.Step = 0.1
            m_RateUpDown.DecimalPlaces = 2
            AddHandler m_RateUpDown.ValueChanged, AddressOf OnUpDownValueChanged
            stack.Add(NPairBox.Create(NLoc.Get("Interest rate per year (%):"), m_RateUpDown))

            ' Create the results labels
            Dim repaymentLabel As NLabel = New NLabel(NLoc.Get("Repayment Summary"))
            repaymentLabel.Margins = New NMargins(0, NDesign.VerticalSpacing * 5, 0, 0)
            repaymentLabel.Font = New NFont(NFontDescriptor.DefaultSansFamilyName, 12, ENFontStyle.Underline)
            repaymentLabel.TextAlignment = ENContentAlignment.MiddleCenter
            stack.Add(repaymentLabel)
            m_MonthlyPaymentLabel = New NLabel()
            m_MonthlyPaymentLabel.TextAlignment = ENContentAlignment.MiddleRight
            stack.Add(NPairBox.Create(NLoc.Get("Monthly Payment:"), m_MonthlyPaymentLabel))
            m_TotalPaymentsLabel = New NLabel()
            m_TotalPaymentsLabel.TextAlignment = ENContentAlignment.MiddleRight
            stack.Add(NPairBox.Create(NLoc.Get("Total Payments:"), m_TotalPaymentsLabel))
            m_TotalInterestLabel = New NLabel()
            m_TotalInterestLabel.TextAlignment = ENContentAlignment.MiddleRight
            stack.Add(NPairBox.Create(NLoc.Get("Total Interest:"), m_TotalInterestLabel))
            CalculateResult()
            Return New NUniSizeBoxGroup(stack)
        End Function

        Private Sub CalculateResult()
            Dim amount = m_AmountUpDown.Value
            Dim payments = m_TermUpDown.Value * 12
            Dim monthlyRate = m_RateUpDown.Value / 100 / 12

            ' Calculate the repayment values
            Dim x = Math.Pow(1 + monthlyRate, payments)
            Dim monthly = amount * x * monthlyRate / (x - 1)
            Dim total = monthly * payments
            Dim interest = total - amount

            ' Display the result
            m_MonthlyPaymentLabel.Text = monthly.ToString("C")
            m_TotalPaymentsLabel.Text = total.ToString("C")
            m_TotalInterestLabel.Text = interest.ToString("C")
        End Sub

        Private Function CreateListBoxItem(ByVal icon As NImage, ByVal languageName As String) As NListBoxItem
            Dim pairBox As NPairBox = New NPairBox(icon, languageName, ENPairBoxRelation.Box1BeforeBox2)
            pairBox.Spacing = NDesign.VerticalSpacing
            Dim item As NListBoxItem = New NListBoxItem(pairBox)
            item.Text = languageName
            Return item
        End Function

#End Region

#Region "Event Handlers"

        Private Sub OnUpDownValueChanged(ByVal arg As NValueChangeEventArgs)
            CalculateResult()
        End Sub

        Private Sub OnListBoxItemSelected(ByVal arg As NSelectEventArgs(Of NListBoxItem))
            Dim selectedItem = arg.Item

            Select Case selectedItem.Text
                Case EnglishLanguageName
                    ' Load the English dictionary
                    m_EnglishStream.Position = 0
                    NLocalizationDictionary.Instance.LoadFromStream(m_EnglishStream)
                Case BulgarianLanguageName
                    ' Load the Bulgarian dictionary
                    m_BulgarianStream.Position = 0
                    NLocalizationDictionary.Instance.LoadFromStream(m_BulgarianStream)
                Case GermanLanguageName
                    ' Load the German dictionary
                    m_GermanStream.Position = 0
                    NLocalizationDictionary.Instance.LoadFromStream(m_GermanStream)
            End Select

            ' Recreate the Loan Calculator
            m_CalculatorHost.Content = CreateLoanCalculator()
        End Sub

#End Region

#Region "Fields"

        Private m_CalculatorHost As NContentHolder
        Private m_AmountUpDown As NNumericUpDown
        Private m_TermUpDown As NNumericUpDown
        Private m_RateUpDown As NNumericUpDown
        Private m_MonthlyPaymentLabel As NLabel
        Private m_TotalPaymentsLabel As NLabel
        Private m_TotalInterestLabel As NLabel
        Private m_EnglishStream As Stream
        Private m_BulgarianStream As Stream
        Private m_GermanStream As Stream

#End Region

#Region "Schema"

        ''' <summary>
        ''' Schema associated with NLocalizationExample.
        ''' </summary>
        Public Shared ReadOnly NLocalizationExampleSchema As NSchema

#End Region

#Region "Constants"

        Private Const EnglishLanguageName As String = "English (US)"
        Private Const BulgarianLanguageName As String = "Bulgarian"
        Private Const GermanLanguageName As String = "German"

#End Region
    End Class
End Namespace

Imports System
Imports System.IO

Imports Nevron.Nov.Dom
Imports Nevron.Nov.Editors
Imports Nevron.Nov.Layout
Imports Nevron.Nov.Serialization
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.Framework
    Public Class NApplicationSettingsExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' Default constructor.
        ''' </summary>
        Public Sub New()
        End Sub

        ''' <summary>
        ''' Static constructor.
        ''' </summary>
        Shared Sub New()
            NApplicationSettingsExampleSchema = NSchema.Create(GetType(NApplicationSettingsExample), NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            m_AppSettings = New MyAppSettings()

            Dim editor As NEditor = NDesigner.GetDesigner(m_AppSettings).CreateInstanceEditor(m_AppSettings)

            Dim groupBox As NGroupBox = New NGroupBox("My Application Settings", editor)
            groupBox.HorizontalPlacement = ENHorizontalPlacement.Left
            groupBox.VerticalPlacement = ENVerticalPlacement.Top

            Return groupBox
        End Function
        Protected Overrides Function CreateExampleControls() As NWidget
            Dim stack As NStackPanel = New NStackPanel()
            stack.HorizontalPlacement = ENHorizontalPlacement.Left
            stack.VerticalPlacement = ENVerticalPlacement.Top

            m_LoadSettingsButton = NButton.CreateImageAndText(Presentation.NResources.Image_File_Open_png, "Load Settings")
            m_LoadSettingsButton.Enabled = False
            Me.m_LoadSettingsButton.Click += AddressOf LoadSettingsButton_Click
            stack.Add(m_LoadSettingsButton)

            Dim saveSettingsButton = NButton.CreateImageAndText(Presentation.NResources.Image_File_Save_png, "Save Settings")
            saveSettingsButton.Click += AddressOf SaveSettingsButton_Click
            stack.Add(saveSettingsButton)

            ' If the app settings key exists, enable the "Load Settings" button
            Call NApplication.GetAllSettingsNamesAsync().[Then](Sub(ByVal settingsName As String())
                                                                    If Array.IndexOf(settingsName, AppSettingsKey) <> -1 Then
                                                                        m_LoadSettingsButton.Enabled = True
                                                                    End If
                                                                End Sub)

            Return stack
        End Function
        Protected Overrides Function GetExampleDescription() As String
            Return "
<p>
	Demonstrates how to work with the NOV application settings. Change the application settings (theme and developer mode) and
	then click the <b>Save Settings</b> button on the right. Then change the settings again and click the <b>Load Settings</b>
	button to load the saved settings. You can also switch to another example, then open this one again and click the
	<b>Load Settings</b> button to load the saved settings.
</p>" End Function

#End Region

#Region "Event Handlers"

        Private Sub LoadSettingsButton_Click(ByVal arg As NEventArgs)
            ' Load the settings data
            Call NApplication.GetSettingAsync(AppSettingsKey).[Then](Sub(ByVal settingsData As Byte())
                                                                         Using stream As MemoryStream = New MemoryStream(settingsData)
                                                                             ' Use a DOM node deserializer to load the app settings from the memory stream
                                                                             Dim deserializer As NDomNodeDeserializer = New NDomNodeDeserializer()
                                                                             Dim loadedSettings = CType(deserializer.LoadFromStream(stream, SettingsFormat)(0), MyAppSettings)

                                                                             ' Copy the loaded app settings to the original app settings object
                                                                             m_AppSettings.DeepCopy(loadedSettings, New NDomDeepCopyContext())
                                                                         End Using
                                                                     End Sub, Sub(ByVal ex As Exception) NMessageBox.ShowError("Failed to load the app settings. Exception was: " & ex.Message, "Error"))
        End Sub
        Private Sub SaveSettingsButton_Click(ByVal arg As NEventArgs)
            Using stream As MemoryStream = New MemoryStream()
                ' Use a DOM node serializer to save the app settings to a memory stream
                Dim serializer As NDomNodeSerializer = New NDomNodeSerializer()
                serializer.SaveToStream(m_AppSettings, stream, SettingsFormat)

                ' Save the settings data
                Dim settingsData As Byte() = stream.ToArray()
                ' Settings saved successfully, so enable the "Load Settings" button
                NApplication.SetSettingAsync(AppSettingsKey, settingsData).[Then](Sub(ByVal ud As NUndefined) m_LoadSettingsButton.Enabled = True)
            End Using
        End Sub

#End Region

#Region "Fields"

        Private m_AppSettings As MyAppSettings
        Private m_LoadSettingsButton As NButton

#End Region

#Region "Schema"

        ''' <summary>
        ''' Schema associated with NApplicationSettingsExample.
        ''' </summary>
        Public Shared ReadOnly NApplicationSettingsExampleSchema As NSchema

#End Region

#Region "Constants"

        Private Const AppSettingsKey As String = "MyAppSettings"
        Private Shared ReadOnly SettingsFormat As ENPersistencyFormat = ENPersistencyFormat.Binary

#End Region
    End Class

#Region "Nested Types"

    Public Class MyAppSettings
        Inherits NNode
        Public Sub New()
        End Sub
        Shared Sub New()
            MyAppSettingsSchema = NSchema.Create(GetType(MyAppSettings), NNodeSchema)
            ThemeProperty = MyAppSettingsSchema.AddSlot("Theme", GetType(ENUITheme), ENUITheme.Windows10)
            DeveloperModeProperty = MyAppSettingsSchema.AddSlot("DeveloperMode", NDomType.Boolean, False)
        End Sub

        Public Property Theme As ENUITheme
            Get
                Return MyBase.GetValue(ThemeProperty)
            End Get
            Set(ByVal value As ENUITheme)
                MyBase.SetValue(ThemeProperty, value)
            End Set
        End Property
        Public Property DeveloperMode As Boolean
            Get
                Return MyBase.GetValue(DeveloperModeProperty)
            End Get
            Set(ByVal value As Boolean)
                MyBase.SetValue(DeveloperModeProperty, value)
            End Set
        End Property

        Public Shared ReadOnly MyAppSettingsSchema As NSchema
        Public Shared ReadOnly ThemeProperty As NProperty
        Public Shared ReadOnly DeveloperModeProperty As NProperty
    End Class

#End Region
End Namespace

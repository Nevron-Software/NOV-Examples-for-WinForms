Imports Nevron.Nov.DataStructures
Imports Nevron.Nov.Editors
Imports Nevron.Nov.Dom
Imports Nevron.Nov.Layout
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.Framework
    Public Class NStyleEditorsExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' Default constructor.
        ''' </summary>
        Public Sub New()
        End Sub
        ''' <summary>
        ''' Static constructor.
        ''' </summary>
        Shared Sub New()
            NStyleEditorsExampleSchema = NSchema.Create(GetType(NStyleEditorsExample), NExampleBase.NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            Dim tab As NTab = New NTab()
            tab.TabPages.Add(CreateTabPage("Fill Styles", NStyleNode.FillProperty, NStyleNode.ColorFillProperty, NStyleNode.StockGradientFillProperty, NStyleNode.LinearGradientFillProperty, NStyleNode.RadialGradientFillProperty, NStyleNode.AdvancedGradientFillProperty, NStyleNode.HatchFillProperty, NStyleNode.ImageFillProperty))
            tab.TabPages.Add(CreateTabPage("Stroke Styles", NStyleNode.StrokeProperty))
            tab.TabPages.Add(CreateTabPage("Borders", NStyleNode.BorderProperty))
            tab.TabPages.Add(CreateTabPage("Text Styles", NStyleNode.FontProperty))
            Return tab
        End Function

        Protected Overrides Function CreateExampleControls() As NWidget
            Return Nothing
        End Function

        Protected Overrides Function GetExampleDescription() As String
            Return "
<p>
	This example demonstrates how the designers of the style related nodes look. Select the tab page of
    the style category you are interested in and click the button next to a style node to see its designer.    
</p>
"
        End Function

#End Region

#Region "Implementation"

        Private Function CreateTabPage(ByVal title As String, ParamArray properties As NProperty()) As NTabPage
            Dim page As NTabPage = New NTabPage(title)
            Dim stack As NStackPanel = New NStackPanel()
            page.Content = New NUniSizeBoxGroup(stack)
            stack.HorizontalPlacement = ENHorizontalPlacement.Left
            Dim editors As NList(Of NPropertyEditor) = Designer.CreatePropertyEditors(New NStyleNode(), properties)
            Dim i = 0, count = editors.Count

            While i < count
                stack.Add(editors(i))
                i += 1
            End While

            Return page
        End Function

#End Region

#Region "Schema"

        ''' <summary>
        ''' Schema associated with NStyleEditorsExample.
        ''' </summary>
        Public Shared ReadOnly NStyleEditorsExampleSchema As NSchema

#End Region

#Region "Constants"

        Private Shared ReadOnly Designer As NDesigner = NDesigner.GetDesigner(NStyleNode.NStyleNodeSchema)

#End Region
    End Class
End Namespace

Imports System

Imports Nevron.Nov.Editors
Imports Nevron.Nov.Dom
Imports Nevron.Nov.Graphics
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.Framework
    Public Class NStyleNode
        Inherits NNode
#Region "Constructors"

        ''' <summary>
        ''' Default constructor.
        ''' </summary>
        Public Sub New()
            m_sName = "Style Node " & Math.Min(System.Threading.Interlocked.Increment(Counter), Counter - 1).ToString()
        End Sub
        ''' <summary>
        ''' Static constructor.
        ''' </summary>
        Shared Sub New()
            defaultLinearGradientFill = New NLinearGradientFill()
            Call defaultLinearGradientFill.GradientStops.Add(New NGradientStop(0.0F, NColor.Red))
            Call defaultLinearGradientFill.GradientStops.Add(New NGradientStop(0.5F, NColor.Yellow))
            Call defaultLinearGradientFill.GradientStops.Add(New NGradientStop(1.0F, NColor.Indigo))

            defaultRadialGradientFill = New NRadialGradientFill()
            Call defaultRadialGradientFill.GradientStops.Add(New NGradientStop(0.0F, NColor.Red))
            Call defaultRadialGradientFill.GradientStops.Add(New NGradientStop(0.5F, NColor.Yellow))
            Call defaultRadialGradientFill.GradientStops.Add(New NGradientStop(1.0F, NColor.Indigo))

            defaultAdvancedGradientFill = New NAdvancedGradientFill()
            Call defaultAdvancedGradientFill.Points.Add(New NAdvancedGradientPoint(NColor.Red, NAngle.Zero, 0, 0, 1, ENAdvancedGradientPointShape.Circle))
            Call defaultAdvancedGradientFill.Points.Add(New NAdvancedGradientPoint(NColor.Blue, NAngle.Zero, 1, 1, 1, ENAdvancedGradientPointShape.Circle))

            NStyleNodeSchema = NSchema.Create(GetType(NStyleNode), NNodeSchema)

            ' Properties - fill
            FillProperty = NStyleNodeSchema.AddSlot("Fill", GetType(NFill), defaultFill)
            ColorFillProperty = NStyleNodeSchema.AddSlot("ColorFill", GetType(NColorFill), defaultColorFill)
            StockGradientFillProperty = NStyleNodeSchema.AddSlot("StockGradientFill", GetType(NStockGradientFill), defaultStockGradientFill)
            LinearGradientFillProperty = NStyleNodeSchema.AddSlot("LinearGradientFill", GetType(NLinearGradientFill), defaultLinearGradientFill)
            RadialGradientFillProperty = NStyleNodeSchema.AddSlot("RadialGradientFill", GetType(NRadialGradientFill), defaultRadialGradientFill)
            AdvancedGradientFillProperty = NStyleNodeSchema.AddSlot("AdvancedGradientFill", GetType(NAdvancedGradientFill), defaultAdvancedGradientFill)
            HatchFillProperty = NStyleNodeSchema.AddSlot("HatchFill", GetType(NHatchFill), defaultHatchFill)
            ImageFillProperty = NStyleNodeSchema.AddSlot("ImageFill", GetType(NImageFill), defaultImageFill)

            ' Broperties - border
            BorderProperty = NStyleNodeSchema.AddSlot("Border", GetType(NBorder), defaultBorder)

            ' Broperties - stroke
            StrokeProperty = NStyleNodeSchema.AddSlot("Stroke", GetType(NStroke), defaultStroke)

            ' Properties - font
            FontProperty = NStyleNodeSchema.AddSlot("Font", GetType(NFont), defaultFont)

            ' Constants
            Designers = New NDesigner() {New NStyleNodeHStackDesigner(), New NStyleNodeVStackDesigner(), New NStyleNodeTabDesigner(), New NStyleNodeMixedDesigner()}
        End Sub

#End Region

#Region "Properties"

        ''' <summary>
        ''' Gets or sets the value of the Fill property.
        ''' </summary>
        Public Property Fill As NFill
            Get
                Return MyBase.GetValue(FillProperty)
            End Get
            Set(ByVal value As NFill)
                MyBase.SetValue(FillProperty, value)
            End Set
        End Property
        ''' <summary>
        ''' Gets or sets the color fill style of the node.
        ''' </summary>
        Public Property ColorFill As NColorFill
            Get
                Return MyBase.GetValue(ColorFillProperty)
            End Get
            Set(ByVal value As NColorFill)
                MyBase.SetValue(ColorFillProperty, value)
            End Set
        End Property
        ''' <summary>
        ''' Gets or sets the value of the TwoColorGradientFill property.
        ''' </summary>
        Public Property StockGradientFill As NStockGradientFill
            Get
                Return MyBase.GetValue(StockGradientFillProperty)
            End Get
            Set(ByVal value As NStockGradientFill)
                MyBase.SetValue(StockGradientFillProperty, value)
            End Set
        End Property
        ''' <summary>
        ''' Gets or sets the value of the LinearGradientFill property.
        ''' </summary>
        Public Property LinearGradientFill As NLinearGradientFill
            Get
                Return MyBase.GetValue(LinearGradientFillProperty)
            End Get
            Set(ByVal value As NLinearGradientFill)
                MyBase.SetValue(LinearGradientFillProperty, value)
            End Set
        End Property
        ''' <summary>
        ''' Gets or sets the value of the TwoColorGradientFill property.
        ''' </summary>
        Public Property RadialGradientFill As NRadialGradientFill
            Get
                Return MyBase.GetValue(RadialGradientFillProperty)
            End Get
            Set(ByVal value As NRadialGradientFill)
                MyBase.SetValue(RadialGradientFillProperty, value)
            End Set
        End Property
        ''' <summary>
        ''' Gets or sets the value of the AdvancedGradientFill property.
        ''' </summary>
        Public Property AdvancedGradientFill As NAdvancedGradientFill
            Get
                Return MyBase.GetValue(AdvancedGradientFillProperty)
            End Get
            Set(ByVal value As NAdvancedGradientFill)
                MyBase.SetValue(AdvancedGradientFillProperty, value)
            End Set
        End Property
        ''' <summary>
        ''' Gets or sets the value of the HatchFill property.
        ''' </summary>
        Public Property HatchFill As NHatchFill
            Get
                Return MyBase.GetValue(HatchFillProperty)
            End Get
            Set(ByVal value As NHatchFill)
                MyBase.SetValue(HatchFillProperty, value)
            End Set
        End Property
        ''' <summary>
        ''' Gets or sets the value of the ImageFill property.
        ''' </summary>
        Public Property ImageFill As NImageFill
            Get
                Return MyBase.GetValue(ImageFillProperty)
            End Get
            Set(ByVal value As NImageFill)
                MyBase.SetValue(ImageFillProperty, value)
            End Set
        End Property
        ''' <summary>
        ''' Gets or sets the border of the node.
        ''' </summary>
        Public Property Border As NBorder
            Get
                Return MyBase.GetValue(BorderProperty)
            End Get
            Set(ByVal value As NBorder)
                MyBase.SetValue(BorderProperty, value)
            End Set
        End Property
        ''' <summary>
        ''' Gtes/Sets the stroke style of the node.
        ''' </summary>
        Public Property Stroke As NStroke
            Get
                Return MyBase.GetValue(StrokeProperty)
            End Get
            Set(ByVal value As NStroke)
                MyBase.SetValue(StrokeProperty, value)
            End Set
        End Property
        ''' <summary>
        ''' Gets or sets the value of the Font property.
        ''' </summary>
        Public Property Font As NFont
            Get
                Return MyBase.GetValue(FontProperty)
            End Get
            Set(ByVal value As NFont)
                MyBase.SetValue(FontProperty, value)
            End Set
        End Property

#End Region

#Region "Overrides"

        Public Overrides Function ToString() As String
            Return m_sName
        End Function

#End Region

#Region "Fields"

        Friend m_sName As String

#End Region

#Region "Schema"

        ''' <summary>
        ''' Schema associated with NStyleNode.
        ''' </summary>
        Public Shared ReadOnly NStyleNodeSchema As NSchema
        ''' <summary>
        ''' Reference to the Fill property.
        ''' </summary>
        Public Shared ReadOnly FillProperty As NProperty
        ''' <summary>
        ''' Reference to the ColorFill property.
        ''' </summary>
        Public Shared ReadOnly ColorFillProperty As NProperty
        ''' <summary>
        ''' Reference to the HatchFill property.
        ''' </summary>
        Public Shared ReadOnly HatchFillProperty As NProperty
        ''' <summary>
        ''' Reference to the TwoColorGradientFill property.
        ''' </summary>
        Public Shared ReadOnly StockGradientFillProperty As NProperty
        ''' <summary>
        ''' Reference to the LinearGradientFill property.
        ''' </summary>
        Public Shared ReadOnly LinearGradientFillProperty As NProperty
        ''' <summary>
        ''' Reference to the RadialGradientFill property.
        ''' </summary>
        Public Shared ReadOnly RadialGradientFillProperty As NProperty
        ''' <summary>
        ''' Reference to the AdvancedGradientFill property.
        ''' </summary>
        Public Shared ReadOnly AdvancedGradientFillProperty As NProperty
        ''' <summary>
        ''' Reference to the ImageFill property.
        ''' </summary>
        Public Shared ReadOnly ImageFillProperty As NProperty
        ''' <summary>
        ''' Reference to the Border property.
        ''' </summary>
        Public Shared ReadOnly BorderProperty As NProperty
        ''' <summary>
        ''' Reference to the Stroke property.
        ''' </summary>
        Public Shared ReadOnly StrokeProperty As NProperty
        ''' <summary>
        ''' Reference to the Font property.
        ''' </summary>
        Public Shared ReadOnly FontProperty As NProperty

#End Region

#Region "Static"

        Public Shared Counter As Integer = 1

#End Region

#Region "Constants"

        Private Shared ReadOnly defaultBorder As NBorder = NBorder.CreateFilledBorder(NColor.Black)
        Private Shared ReadOnly defaultFill As NFill = Nothing
        Private Shared ReadOnly defaultColorFill As NColorFill = New NColorFill(NColor.MediumBlue)
        Private Shared ReadOnly defaultStockGradientFill As NStockGradientFill = New NStockGradientFill(ENGradientStyle.FromCenter, ENGradientVariant.Variant1, NColor.Black, NColor.White)
        Private Shared ReadOnly defaultLinearGradientFill As NLinearGradientFill
        Private Shared ReadOnly defaultRadialGradientFill As NRadialGradientFill
        Private Shared ReadOnly defaultAdvancedGradientFill As NAdvancedGradientFill
        Private Shared ReadOnly defaultHatchFill As NHatchFill = New NHatchFill(ENHatchStyle.LightHorizontal, NColor.Black, NColor.White)
        Private Shared ReadOnly defaultImageFill As NImageFill = New NImageFill()
        Private Shared ReadOnly defaultStroke As NStroke = New NStroke()
        Private Shared ReadOnly defaultFont As NFont = New NFont(NFontDescriptor.DefaultSansFamilyName, 10, ENFontStyle.Regular)

        Public Shared ReadOnly Designers As NDesigner()

#End Region

#Region "Designers"

        ''' <summary>
        ''' Designer for NStyleNode.
        ''' </summary>
        Public MustInherit Class NStyleNodeDesigner
            Inherits NDesigner
            ''' <summary>
            ''' Default constructor.
            ''' </summary>
            Public Sub New()
                Schema = NStyleNodeSchema
                m_Name = "Style Node Editor"

                SetPropertyCategory(FillProperty, FillStylesCategory)
                SetPropertyCategory(ColorFillProperty, FillStylesCategory)
                SetPropertyCategory(HatchFillProperty, FillStylesCategory)
                SetPropertyCategory(StockGradientFillProperty, FillStylesCategory)
                SetPropertyCategory(LinearGradientFillProperty, FillStylesCategory)
                SetPropertyCategory(RadialGradientFillProperty, FillStylesCategory)
                SetPropertyCategory(AdvancedGradientFillProperty, FillStylesCategory)
                SetPropertyCategory(ImageFillProperty, FillStylesCategory)

                SetPropertyCategory(BorderProperty, StrokeStylesCategory)
                SetPropertyCategory(StrokeProperty, StrokeStylesCategory)

                SetPropertyCategory(FontProperty, TextStylesCategory)
            End Sub

            Public Overrides Function ToString() As String
                Return m_Name
            End Function

            Protected m_Name As String

            Protected Shared ReadOnly FillStylesCategory As NLocalizedString = New NLocalizedString("Fill Styles")
            Protected Shared ReadOnly StrokeStylesCategory As NLocalizedString = New NLocalizedString("Stroke Styles")
            Protected Shared ReadOnly TextStylesCategory As NLocalizedString = New NLocalizedString("Text Styles")
        End Class

        Public Class NStyleNodeHStackDesigner
            Inherits NStyleNodeDesigner
            Public Sub New()
                m_Name = "Horizontal Stack Category Editor"
                SetCategoryEditor(NLocalizedString.Empty, NStackCategoryEditor.HorizontalEmbedChildEditorsTemplate)
            End Sub
        End Class

        Public Class NStyleNodeVStackDesigner
            Inherits NStyleNodeDesigner
            Public Sub New()
                m_Name = "Vertical Stack Category Editor"
                SetCategoryEditor(NLocalizedString.Empty, NStackCategoryEditor.VerticalEmbedChildEditorsTemplate)
            End Sub
        End Class

        Public Class NStyleNodeTabDesigner
            Inherits NStyleNodeDesigner
            Public Sub New()
                m_Name = "Tab Category Editor"
                SetCategoryEditor(NLocalizedString.Empty, NTabCategoryEditor.HeadersTopTemplate)
            End Sub
        End Class

        Public Class NStyleNodeMixedDesigner
            Inherits NStyleNodeDesigner
            Public Sub New()
                m_Name = "Mixed Category Editor"

                SetCategoryEditor(NLocalizedString.Empty, NStackCategoryEditor.VerticalEmbedChildEditorsTemplate)
                SetCategoryEditor(StrokeStylesCategory, NTabCategoryEditor.HeadersTopTemplate)
            End Sub
        End Class

#End Region
    End Class
End Namespace

Imports System
Imports Nevron.Nov.Dom
Imports Nevron.Nov.Editors
Imports Nevron.Nov.Graphics
Imports Nevron.Nov.Layout
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.Framework
    Public Class NNodeDesignersExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' Default constructor.
        ''' </summary>
        Public Sub New()
        End Sub
        ''' <summary>
        ''' Static constructor.
        ''' </summary>
        Shared Sub New()
            NNodeDesignersExampleSchema = NSchema.Create(GetType(NNodeDesignersExample), NExampleBase.NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            Dim stack As NStackPanel = New NStackPanel()
            stack.HorizontalPlacement = ENHorizontalPlacement.Left

            ' Reset the style node counter
            NStyleNode.Counter = 1

            ' Create the show designer buttons
            stack.Add(CreateShowDesignerButton(New NSimpleNode()))
            stack.Add(CreateShowDesignerButton(New NStyleNode()))
            stack.Add(CreateShowDesignerButton(CreateStyleNodesTree()))
            stack.Add(CreateShowDesignerButton(CreateStyleNodesList()))
            Return stack
        End Function

        Protected Overrides Function CreateExampleControls() As NWidget
            Return Nothing
        End Function

        Protected Overrides Function GetExampleDescription() As String
            Return "
<p>
	This example demonstrates how to show the designer for a given Nevron DOM node.
</p>
"
        End Function

#End Region

#Region "Implementation"

        Private Function CreateShowDesignerButton(ByVal node As NNode) As NButton
            Dim button As NButton = New NButton(NDesigner.GetDesigner(node).ToString())
            button.Tag = node
            AddHandler button.Click, AddressOf OnShowDesignerClick
            Return button
        End Function

        Private Function CreateStyleNodesList() As NStyleNodeCollectionList
            Dim collection As NStyleNodeCollectionList = New NStyleNodeCollectionList()
            collection.Add(CreateStyleNode(NColor.Red))
            collection.Add(CreateStyleNode(NColor.Green))
            collection.Add(CreateStyleNode(NColor.Blue))
            Return collection
        End Function

        Private Function CreateStyleNodesTree() As NStyleNodeCollectionTree
            Dim collection As NStyleNodeCollectionTree = New NStyleNodeCollectionTree()
            collection.Add(CreateStyleNode(NColor.Red))
            collection.Add(CreateStyleNode(NColor.Green))
            collection.Add(CreateStyleNode(NColor.Blue))
            Return collection
        End Function

        Private Function CreateStyleNode(ByVal color As NColor) As NStyleNode
            Dim styleNode As NStyleNode = New NStyleNode()
            styleNode.ColorFill = New NColorFill(color)
            Return styleNode
        End Function

#End Region

#Region "Event Handlers"

        Private Sub OnShowDesignerClick(ByVal args As NEventArgs)
            Try
                Dim button = CType(args.TargetNode, NButton)
                Dim node = CType(button.Tag, NNode)
                Dim editorWindow = NEditorWindow.CreateForInstance(node, Nothing, button.DisplayWindow, Nothing)

                If TypeOf node Is NStyleNodeCollectionTree Then
                    editorWindow.PreferredSize = New NSize(500, 360)
                End If

                editorWindow.Open()
            Catch ex As Exception
                NTrace.WriteException("OnShowDesignerClick failed.", ex)
            End Try
        End Sub

#End Region

#Region "Schema"

        ''' <summary>
        ''' Schema associated with NNodeDesignersExample.
        ''' </summary>
        Public Shared ReadOnly NNodeDesignersExampleSchema As NSchema

#End Region
    End Class
End Namespace

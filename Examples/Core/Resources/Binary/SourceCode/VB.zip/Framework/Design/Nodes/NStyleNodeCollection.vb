Imports Nevron.Nov.Editors
Imports Nevron.Nov.Dom

Namespace Nevron.Nov.Examples.Framework
    Public MustInherit Class NStyleNodeCollectionBase
        Inherits NNodeCollection(Of NStyleNode)
#Region "Constructors"

        ''' <summary>
        ''' Default constructor.
        ''' </summary>
        Public Sub New()
        End Sub
        ''' <summary>
        ''' Static constructor.
        ''' </summary>
        Shared Sub New()
            NStyleNodeCollectionBaseSchema = NSchema.Create(GetType(NStyleNodeCollectionBase), NNodeCollectionSchema)
        End Sub

#End Region

#Region "Schema"

        ''' <summary>
        ''' Schema associated with NStyleNodeCollectionBase.
        ''' </summary>
        Public Shared ReadOnly NStyleNodeCollectionBaseSchema As NSchema

#End Region
    End Class

    Public Class NStyleNodeCollectionList
        Inherits NStyleNodeCollectionBase
#Region "Constructors"

        ''' <summary>
        ''' Default constructor.
        ''' </summary>
        Public Sub New()
        End Sub
        ''' <summary>
        ''' Static constructor.
        ''' </summary>
        Shared Sub New()
            NStyleNodeCollectionListSchema = NSchema.Create(GetType(NStyleNodeCollectionList), NStyleNodeCollectionBaseSchema)

            ' Designer
            Call NStyleNodeCollectionListSchema.SetMetaUnit(New NDesignerMetaUnit(GetType(NStyleNodeCollectionListDesigner)))
        End Sub

#End Region

#Region "Schema"

        ''' <summary>
        ''' Schema associated with NStyleNodeCollectionList.
        ''' </summary>
        Public Shared ReadOnly NStyleNodeCollectionListSchema As NSchema

#End Region

#Region "Designer"

        ''' <summary>
        ''' Designer for NStyleNodeCollectionList.
        ''' </summary>
        Public Class NStyleNodeCollectionListDesigner
            Inherits NDesigner
            Public Sub New()
                HierarchyEmbeddableEditor = NChildrenHierarchyEditor.ListBoxTemplate
            End Sub
        End Class

#End Region
    End Class

    Public Class NStyleNodeCollectionTree
        Inherits NStyleNodeCollectionBase
#Region "Constructors"

        ''' <summary>
        ''' Default constructor.
        ''' </summary>
        Public Sub New()
        End Sub
        ''' <summary>
        ''' Static constructor.
        ''' </summary>
        Shared Sub New()
            NStyleNodeCollectionTreeSchema = NSchema.Create(GetType(NStyleNodeCollectionTree), NStyleNodeCollectionBaseSchema)

            ' Designer
            Call NStyleNodeCollectionTreeSchema.SetMetaUnit(New NDesignerMetaUnit(GetType(NStyleNodeCollectionTreeDesigner)))
        End Sub

#End Region

#Region "Schema"

        ''' <summary>
        ''' Schema associated with NStyleNodeCollectionTree.
        ''' </summary>
        Public Shared ReadOnly NStyleNodeCollectionTreeSchema As NSchema

#End Region

#Region "Designer"

        ''' <summary>
        ''' Designer for NStyleNodeCollectionTree.
        ''' </summary>
        Public Class NStyleNodeCollectionTreeDesigner
            Inherits NDesigner
        End Class

#End Region
    End Class
End Namespace

Imports System
Imports System.Globalization
Imports Nevron.Nov.Dom
Imports Nevron.Nov.Editors
Imports Nevron.Nov.Layout
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.Framework
    Public Class NValueTypeEditorsExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' Default constructor.
        ''' </summary>
        Public Sub New()
        End Sub
        ''' <summary>
        ''' Static constructor.
        ''' </summary>
        Shared Sub New()
            NValueTypeEditorsExampleSchema = NSchema.Create(GetType(NValueTypeEditorsExample), NExampleBase.NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            Dim tab As NTab = New NTab()
            m_SimpleNode = New NSimpleNode()

            ' Primitive types
            tab.TabPages.Add(CreateBooleanPage())
            tab.TabPages.Add(CreateInt32Page())
            tab.TabPages.Add(CreateInt64Page())
            tab.TabPages.Add(CreateUInt32Page())
            tab.TabPages.Add(CreateSinglePage())
            tab.TabPages.Add(CreateDoublePage())
            tab.TabPages.Add(CreateEnumPage())

            ' Nevron types
            tab.TabPages.Add(CreateAnglePage())
            tab.TabPages.Add(CreateColorPage())
            tab.TabPages.Add(CreateGraphicsCorePage())
            tab.TabPages.Add(CreateTextPage())

            Return tab
        End Function
        Protected Overrides Function CreateExampleControls() As NWidget
            Return Nothing
        End Function
        Protected Overrides Function GetExampleDescription() As String
            Return "
<p>
	This example demonstrates the value type property editors. Select the tab page for the value types
    you are interested in and your will see their property editors.
</p>
" End Function

#End Region

#Region "Implementation - Primitive Types"

        Private Function CreateBooleanPage() As NTabPage
            Dim tabPage As NTabPage = New NTabPage("Boolean")
            Dim stack As NStackPanel = New NStackPanel()
            tabPage.Content = stack
            stack.HorizontalPlacement = ENHorizontalPlacement.Left

            Dim groupBox As NGroupBox = New NGroupBox("Default")
            stack.Add(groupBox)

            Dim editor = CType(CreateEditor(NSimpleNode.BooleanValueProperty), NBooleanPropertyEditor)
            groupBox.Content = editor

            Return tabPage
        End Function
        Private Function CreateInt32Page() As NTabPage
            Dim page As NTabPage = New NTabPage("Integer")

            Dim stack As NStackPanel = New NStackPanel()
            page.Content = stack
            stack.HorizontalPlacement = ENHorizontalPlacement.Left

            stack.Add(CreateSample("Default", NSimpleNode.IntegerValueProperty, Double.NaN, Double.NaN, Double.NaN, -1))
            stack.Add(CreateSample("Example 1", NSimpleNode.IntegerValueProperty, 2, -10, 10, -1))
            stack.Add(CreateSample("Example 2", NSimpleNode.IntegerValueProperty, 10, 200, 300, -1))

            Return page
        End Function
        Private Function CreateInt64Page() As NTabPage
            Dim page As NTabPage = New NTabPage("Long")

            Dim stack As NStackPanel = New NStackPanel()
            page.Content = stack
            stack.HorizontalPlacement = ENHorizontalPlacement.Left

            stack.Add(CreateSample("Default", NSimpleNode.LongValueProperty, Double.NaN, Double.NaN, Double.NaN, -1))
            stack.Add(CreateSample("Example 1", NSimpleNode.LongValueProperty, 2, -10, 10, -1))
            stack.Add(CreateSample("Example 2", NSimpleNode.LongValueProperty, 10, 200, 300, -1))

            Return page
        End Function
        Private Function CreateUInt32Page() As NTabPage
            Dim page As NTabPage = New NTabPage("Unsigned Integer")

            Dim stack As NStackPanel = New NStackPanel()
            page.Content = stack
            stack.HorizontalPlacement = ENHorizontalPlacement.Left

            stack.Add(CreateSample("Default", NSimpleNode.UnsignedIntegerValueProperty, Double.NaN, Double.NaN, Double.NaN, -1))
            stack.Add(CreateSample("Example 1", NSimpleNode.UnsignedIntegerValueProperty, 2, 0, 10, -1))
            stack.Add(CreateSample("Example 2", NSimpleNode.UnsignedIntegerValueProperty, 10, 200, 300, -1))

            Return page
        End Function
        Private Function CreateSinglePage() As NTabPage
            Dim page As NTabPage = New NTabPage("Single")

            Dim stack As NStackPanel = New NStackPanel()
            page.Content = stack
            stack.HorizontalPlacement = ENHorizontalPlacement.Left

            stack.Add(CreateSample("Default", NSimpleNode.SingleValueProperty, Double.NaN, Double.NaN, Double.NaN, -1))
            stack.Add(CreateSample("Example 1", NSimpleNode.SingleValueProperty, 2, -10, 10, 0))
            stack.Add(CreateSample("Example 2", NSimpleNode.SingleValueProperty, 0.2, -1, 1, 1))
            stack.Add(CreateSample("Example 3", NSimpleNode.SingleValueProperty, 0.03, 4, 5, 2))

            Return page
        End Function
        Private Function CreateDoublePage() As NTabPage
            Dim page As NTabPage = New NTabPage("Double")

            Dim stack As NStackPanel = New NStackPanel()
            page.Content = stack
            stack.HorizontalPlacement = ENHorizontalPlacement.Left

            stack.Add(CreateSample("Default", NSimpleNode.DoubleValueProperty, Double.NaN, Double.NaN, Double.NaN, -1))
            stack.Add(CreateSample("Example 1", NSimpleNode.DoubleValueProperty, 2, -10, 10, 0))
            stack.Add(CreateSample("Example 2", NSimpleNode.DoubleValueProperty, 0.2, -1, 1, 1))
            stack.Add(CreateSample("Example 3", NSimpleNode.DoubleValueProperty, 0.03, 4, 5, 2))
            stack.Add(CreateSample("Specified Double", NSimpleNode.SpecifiedDoubleValueProperty, 1, Double.MinValue, Double.MaxValue, 2))

            Return page
        End Function
        Private Function CreateEnumPage() As NTabPage
            Dim page As NTabPage = New NTabPage("Enum")
            Dim stack As NStackPanel = New NStackPanel()
            page.Content = stack
            stack.HorizontalPlacement = ENHorizontalPlacement.Left

            Dim editors = SimpleNodeDesigner.CreatePropertyEditors(m_SimpleNode, NSimpleNode.ComboBoxEnumValueProperty, NSimpleNode.ComboBoxMaskedEnumProperty, NSimpleNode.HRadioGroupEnumProperty, NSimpleNode.VRadioGroupEnumProperty)

            Dim groupBox As NGroupBox = New NGroupBox(editors(0).EditedProperty.ToString())
            stack.Add(groupBox)
            groupBox.Content = editors(0)

            groupBox = New NGroupBox(editors(1).EditedProperty.ToString())
            stack.Add(groupBox)
            groupBox.Content = editors(1)

            For i = 2 To editors.Count - 1
                Dim editor = editors(i)
                stack.Add(editor)
            Next

            Return page
        End Function

        Private Function CreateSample(ByVal title As String, ByVal [property] As NProperty, ByVal [step] As Double, ByVal min As Double, ByVal max As Double, ByVal decimalPlaces As Integer) As NGroupBox
            Dim groupBox As NGroupBox = New NGroupBox(title)

            Dim stack As NStackPanel = New NStackPanel()
            groupBox.Content = stack
            stack.VerticalSpacing = 10

            Dim propertyStack As NStackPanel = New NStackPanel()
            stack.Add(New NUniSizeBoxGroup(propertyStack))
            propertyStack.HorizontalPlacement = ENHorizontalPlacement.Left

            Dim editor = CreateEditor([property], [step], min, max, decimalPlaces)
            propertyStack.Add(New NPairBox("Step = ", editor.Step, True))
            propertyStack.Add(New NPairBox("Minimum = ", editor.Minimum, True))
            propertyStack.Add(New NPairBox("Maximum = ", editor.Maximum, True))
            If TypeOf editor Is NFloatingNumberPropertyEditor Then
                propertyStack.Add(New NPairBox("Decimal Places = ", CType(editor, NFloatingNumberPropertyEditor).DecimalPlaces, True))
            End If

            Dim i = 0, count = propertyStack.Count

            While i < count
                Dim pairBox = CType(propertyStack(i), NPairBox)
                Dim box1 = CType(pairBox.Box1, NUniSizeBox)
                box1.Content.HorizontalPlacement = ENHorizontalPlacement.Right
                i += 1
            End While

            stack.Add(editor)

            Return groupBox
        End Function
        Private Function CreateEditor(ByVal [property] As NProperty, ByVal [step] As Double, ByVal min As Double, ByVal max As Double, ByVal decimalPlaces As Integer) As NNumberPropertyEditor
            Dim editor = CType(CreateEditor([property]), NNumberPropertyEditor)
            Dim node As NSimpleNode = CType(editor.EditedNode, NSimpleNode)
            If Double.IsNaN([step]) = False Then
                editor.Step = [step]
            End If

            If Double.IsNaN(min) = False Then
                editor.Minimum = min
            End If

            If Double.IsNaN(max) = False Then
                editor.Maximum = max
            End If

            If decimalPlaces <> -1 AndAlso TypeOf editor Is NFloatingNumberPropertyEditor Then
                CType(editor, NFloatingNumberPropertyEditor).DecimalPlaces = decimalPlaces
            End If

            ' Ensure the value is in the range [min, max]
            Dim value = Convert.ToDouble(node.GetValue([property]))
            If value < min Then
                node.SetValue([property], Convert.ChangeType(editor.Minimum, [property].DomType.CLRType, CultureInfo.InvariantCulture))
            End If
            If value > max Then
                node.SetValue([property], Convert.ChangeType(editor.Maximum, [property].DomType.CLRType, CultureInfo.InvariantCulture))
            End If

            Return editor
        End Function

#End Region

#Region "Implementation - Nevron Types"

        Private Function CreateAnglePage() As NTabPage
            Dim page As NTabPage = New NTabPage("Angle")
            Dim stack As NStackPanel = CreateStackPanel()
            page.Content = stack

            Dim groupBox As NGroupBox = New NGroupBox("Default")
            stack.Add(groupBox)

            Dim editor = CType(CreateEditor(NSimpleNode.AngleProperty), NAnglePropertyEditor)
            groupBox.Content = editor

            Return page
        End Function
        Private Function CreateColorPage() As NTabPage
            Dim page As NTabPage = New NTabPage("Color")
            Dim stack As NStackPanel = CreateStackPanel()
            page.Content = stack

            ' Create a default (drop down) color editor
            Dim groupBox As NGroupBox = New NGroupBox("Default (drop down)")
            stack.Add(groupBox)

            Dim editor = CType(CreateEditor(NSimpleNode.ColorProperty), NColorPropertyEditor)
            groupBox.Content = editor

            ' Create an advanced color editor
            editor = CType(CreateEditor(NSimpleNode.AdvancedColorProperty), NColorPropertyEditor)
            stack.Add(editor)

            Return page
        End Function
        Private Function CreateGraphicsCorePage() As NTabPage
            Dim page As NTabPage = New NTabPage("Graphics Core")
            Dim stack As NStackPanel = CreateStackPanel()
            page.Content = New NUniSizeBoxGroup(stack)

            Dim editors = SimpleNodeDesigner.CreatePropertyEditors(m_SimpleNode, NSimpleNode.PointProperty, NSimpleNode.SizeProperty, NSimpleNode.RectangleProperty, NSimpleNode.MarginsProperty)

            Dim i = 0, count = editors.Count

            While i < count
                stack.Add(editors(i))
                i += 1
            End While

            Return page
        End Function
        Private Function CreateTextPage() As NTabPage
            Dim page As NTabPage = New NTabPage("Text")
            Dim stack As NStackPanel = CreateStackPanel()
            page.Content = New NUniSizeBoxGroup(stack)

            stack.Add(SimpleNodeDesigner.CreatePropertyEditor(m_SimpleNode, NSimpleNode.MultiLengthProperty))

            Return page
        End Function

#End Region

#Region "Implementation"

        Private Function CreateEditor(ByVal [property] As NProperty) As NPropertyEditor
            Return SimpleNodeDesigner.CreatePropertyEditor(m_SimpleNode, [property])
        End Function
        Private Function CreateStackPanel() As NStackPanel
            Dim stack As NStackPanel = New NStackPanel()
            stack.HorizontalPlacement = ENHorizontalPlacement.Left
            Return stack
        End Function

#End Region

#Region "Fields"

        Private m_SimpleNode As NSimpleNode

#End Region

#Region "Schema"

        ''' <summary>
        ''' Schema associated with NValueTypeEditorsExample.
        ''' </summary>
        Public Shared ReadOnly NValueTypeEditorsExampleSchema As NSchema

#End Region

#Region "Constants"

        Private Shared ReadOnly SimpleNodeDesigner As NDesigner = NDesigner.GetDesigner(NSimpleNode.NSimpleNodeSchema)

#End Region
    End Class
End Namespace

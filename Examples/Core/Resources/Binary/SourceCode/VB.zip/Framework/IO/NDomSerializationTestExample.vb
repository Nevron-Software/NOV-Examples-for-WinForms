Imports System
Imports System.IO
Imports System.Text
Imports Nevron.Nov.Dom
Imports Nevron.Nov.Examples.Text
Imports Nevron.Nov.Serialization
Imports Nevron.Nov.Text
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.Framework
    ''' <summary>
    ''' The example automatically tests all all node types for serialization.
    ''' </summary>
    Public Class NDomSerializationTestExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' 
        ''' </summary>
        Public Sub New()
        End Sub
        ''' <summary>
        ''' 
        ''' </summary>
        Shared Sub New()
            NDomSerializationTestExampleSchema = NSchema.Create(GetType(NDomSerializationTestExample), NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            m_TextBox = New NTextBox()
            m_TextBox.Multiline = True
            m_TextBox.VScrollMode = ENScrollMode.WhenNeeded

            Return m_TextBox
        End Function
        Protected Overrides Function CreateExampleControls() As NWidget
            Dim stack As NStackPanel = New NStackPanel()

            Dim testBinarySerializationButton As NButton = New NButton("Test Binary Serialization")
            testBinarySerializationButton.Tag = ENPersistencyFormat.Binary
            testBinarySerializationButton.MouseDown += AddressOf OnTestSerializationButtonMouseDown
            testBinarySerializationButton.Click += AddressOf OnTestSerializationButtonClick
            stack.Add(testBinarySerializationButton)

            Dim testXmlSerializationButton As NButton = New NButton("Test XML Serialization")
            testXmlSerializationButton.Tag = ENPersistencyFormat.Xml
            testXmlSerializationButton.MouseDown += AddressOf OnTestSerializationButtonMouseDown
            testXmlSerializationButton.Click += AddressOf OnTestSerializationButtonClick
            stack.Add(testXmlSerializationButton)

            Dim clearLogButton As NButton = New NButton("Clear Log")
            clearLogButton.Click += New [Function](Of NEventArgs)(AddressOf OnClearLogButtonClick)
            stack.Add(clearLogButton)

            Return stack
        End Function
        Protected Overrides Function GetExampleDescription() As String
            Return "<p>The example performs automatic serialization test to all NNode derived objects in the Nevron.Nov.Presentation assembly.</p>"
        End Function

#End Region

#Region "Event Handlers"

        Private Sub OnTestSerializationButtonMouseDown(ByVal arg As NMouseButtonEventArgs)
            ' Set Wait cursor
            m_TextBox.DisplayWindow.Cursor = New NCursor(ENPredefinedCursor.Wait)
        End Sub
        Private Sub OnTestSerializationButtonClick(ByVal arg As NEventArgs)
            Dim persistencyFormat As ENPersistencyFormat = arg.TargetNode.Tag
            Dim stopwatch As NStopwatch
            Try
                Dim nodeType = GetType(NNode)
                Dim types As Type() = nodeType.Assembly.GetTypes()
                Dim nodeCount = 0, successfullySerialized = 0

                stopwatch = NStopwatch.StartNew()
                Dim output As StringBuilder = New StringBuilder()
                Dim i = 0, count = types.Length

                While i < count
                    Dim type = types(i)

                    ' not a NNode type, abstract or generic => skip
                    If Not nodeType.IsAssignableFrom(type) OrElse type.IsAbstract OrElse type.IsGenericType Then Continue While

                    Dim node As NNode
                    Try
                        nodeCount += 1
                        Dim typeInstance As NNode = Activator.CreateInstance(type)

                        ' Serialize
                        Dim memoryStream As MemoryStream = New MemoryStream()
                        Dim serializer As NDomNodeSerializer = New NDomNodeSerializer()
                        serializer.SerializeDefaultValues = True
                        serializer.SaveToStream(New NNode() {typeInstance}, memoryStream, persistencyFormat)

                        ' Deserialize to check if the serialization has succeeded
                        Dim deserializer As NDomNodeDeserializer = New NDomNodeDeserializer()
                        memoryStream = New MemoryStream(memoryStream.ToArray())
                        node = deserializer.LoadFromStream(memoryStream, persistencyFormat)(0)

                        output.AppendLine("Sucessfully serialized node type [" & type.Name & "].")
                        successfullySerialized += 1
                    Catch ex As Exception
                        output.AppendLine("Failed to serialize node type [" & type.Name & "]. Exception was [" & ex.Message & "]")
                    End Try

                    i += 1
                End While

                stopwatch.Stop()

                output.AppendLine("==================================================")
                output.AppendLine("Nodes serialized: " & successfullySerialized.ToString() & " of " & nodeCount.ToString())
                output.AppendLine("Time elapsed: " & stopwatch.ElapsedMilliseconds.ToString() & " ms")

                m_TextBox.Text = output.ToString()
                m_TextBox.SetCaretPos(New NTextPosition(m_TextBox.Text.Length, False))
                m_TextBox.EnsureCaretVisible()
            Catch ex As Exception
                NDebug.WriteLine(ex.Message)
            End Try

            ' Restore the default cursor
            Me.DisplayWindow.Cursor = Nothing
        End Sub
        Private Sub OnClearLogButtonClick(ByVal arg As NEventArgs)
            m_TextBox.Text = String.Empty
        End Sub

#End Region

#Region "Fields"

        Private m_TextBox As NTextBox

#End Region

#Region "Schema"

        ''' <summary>
        ''' Schema associated with NDomSerializationTestExample.
        ''' </summary>
        Public Shared ReadOnly NDomSerializationTestExampleSchema As NSchema

#End Region
    End Class
End Namespace

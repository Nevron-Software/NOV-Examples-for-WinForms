Imports System
Imports System.IO

Imports Nevron.Nov.Compression
Imports Nevron.Nov.Dom
Imports Nevron.Nov.Graphics
Imports Nevron.Nov.Layout
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.Framework
    Public Class NZipDecompressionExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' Default constructor.
        ''' </summary>
        Public Sub New()
        End Sub

        ''' <summary>
        ''' Static constructor.
        ''' </summary>
        Shared Sub New()
            NZipDecompressionExampleSchema = NSchema.Create(GetType(NZipDecompressionExample), NExampleBase.NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            m_HeaderLabel = New NLabel("File: CSharph.zip")

            m_TreeView = New NTreeView()
            m_TreeView.MinWidth = 300

            Dim pairBox As NPairBox = New NPairBox(m_HeaderLabel, m_TreeView, ENPairBoxRelation.Box1AboveBox2)
            pairBox.HorizontalPlacement = ENHorizontalPlacement.Left
            pairBox.Spacing = NDesign.VerticalSpacing

            Dim sourceCodeStream As Stream = NResources.RBIN_SourceCode_CSharp_zip.Stream
            DecompressZip(sourceCodeStream)

            Return pairBox
        End Function
        Protected Overrides Function CreateExampleControls() As NWidget
            Dim openFileButton As NButton = New NButton("Open ZIP Archive")
            openFileButton.Click += AddressOf OnOpenFileButtonClick
            openFileButton.VerticalPlacement = ENVerticalPlacement.Top

            Return openFileButton
        End Function
        Protected Overrides Function GetExampleDescription() As String
            Return "
<p>
	This example demonstrates how to work with ZIP archives. By default the example extracts the file names
	of the source code files of all NOV examples. Using the <b>Open ZIP Archive</b> button you can see the
	contents of another ZIP file.
</p>
" End Function

#End Region

#Region "Implementation"

        Private Sub DecompressZip(ByVal stream As Stream)
            m_TreeView.SelectedItem = Nothing
            m_TreeView.Items.Clear()

            Dim decompressor As ZipDecompressor = New ZipDecompressor(m_TreeView)
            NCompression.DecompressZip(stream, decompressor)
        End Sub

#End Region

#Region "Event Handlers"

        Private Sub OnOpenFileButtonClick(ByVal arg As NEventArgs)
            Dim openFileDialog As NOpenFileDialog = New NOpenFileDialog()
            openFileDialog.FileTypes = New NFileDialogFileType() {New NFileDialogFileType("ZIP Archives", "zip")}

            openFileDialog.Closed += AddressOf OnOpenFileDialogClosed
            openFileDialog.RequestShow()
        End Sub
        Private Sub OnOpenFileDialogClosed(ByVal arg As NOpenFileDialogResult)
            If arg.Result IsNot ENCommonDialogResult.OK OrElse arg.Files.Length <> 1 Then Return

            Dim file = arg.Files(0)
            file.OpenReadAsync().[Then](Sub(ByVal stream As Stream)
                                            Using stream
                                                DecompressZip(stream)
                                            End Using

                                            m_HeaderLabel.Text = "File: " & file.Path
                                        End Sub, Sub(ByVal ex As Exception) NMessageBox.ShowError(ex.Message, "Error"))
        End Sub

#End Region

#Region "Fields"

        Private m_HeaderLabel As NLabel
        Private m_TreeView As NTreeView

#End Region

#Region "Schema"

        ''' <summary>
        ''' Schema associated with NZipDecompressionExample.
        ''' </summary>
        Public Shared ReadOnly NZipDecompressionExampleSchema As NSchema

#End Region

#Region "Nested Types"

        Private Class ZipDecompressor
            Implements INZipDecompressor
            Public Sub New(ByVal treeView As NTreeView)
                m_TreeView = treeView
            End Sub

            Public Function Filter(ByVal item As NZipItem) As Boolean Implements INZipDecompressor.Filter
                Return True
            End Function
            Public Sub OnItemDecompressed(ByVal item As NZipItem) Implements INZipDecompressor.OnItemDecompressed
                Dim partNames = item.Name.Split(PathDelimitersCharArray, StringSplitOptions.RemoveEmptyEntries)

                ' Add the folders to the tree view
                Dim items As NTreeViewItemCollection = m_TreeView.Items
                Dim i = 0, partNameCount = partNames.Length - 1

                While i < partNameCount
                    Dim partName = partNames(i)
                    Dim treeViewItem = GetItemByName(items, partName)
                    If treeViewItem Is Nothing Then
                        ' An item with the current entry name does not exist, so create it
                        treeViewItem = AddFolder(items, partName)
                    End If

                    items = treeViewItem.Items
                    i += 1
                End While

                ' Add the file
                AddFile(items, partNames(partNames.Length - 1))
            End Sub

            Private Shared Function GetItemByName(ByVal items As NTreeViewItemCollection, ByVal name As String) As NTreeViewItem
                Dim i = 0, count = items.Count

                While i < count
                    Dim item = items(i)
                    Dim itemName = CStr(item.Tag)
                    If Equals(itemName, name) Then Return item
                    i += 1
                End While

                Return Nothing
            End Function
            Private Shared Function CreateItem(ByVal image As NImage, ByVal name As String) As NTreeViewItem
                Dim pairBox As NPairBox = New NPairBox(image, name)
                pairBox.Box2.VerticalPlacement = ENVerticalPlacement.Center
                pairBox.Spacing = NDesign.HorizontalSpacing

                Dim item As NTreeViewItem = New NTreeViewItem(pairBox)
                item.Tag = name
                Return item
            End Function
            Private Shared Function AddFolder(ByVal items As NTreeViewItemCollection, ByVal name As String) As NTreeViewItem
                ' Find the place for the folder item
                Dim i As Integer
                For i = items.Count - 1 To 0 Step -1
                    If items(i).Items.Count > 0 Then
                        ' This is not a leaf node, which means we have reached the last folder in the given list of items
                        Exit For
                    End If
                Next

                ' Insert the folder item
                Dim item = CreateItem(NResources.Image__16x16_Folders_png, name)
                items.Insert(i + 1, item)
                Return item
            End Function
            Private Shared Function AddFile(ByVal items As NTreeViewItemCollection, ByVal name As String) As NTreeViewItem
                Dim item = CreateItem(NResources.Image__16x16_Contacts_png, name)
                items.Add(item)
                Return item
            End Function

            Private m_TreeView As NTreeView
            Private Shared ReadOnly PathDelimitersCharArray As Char() = New Char() {"\"c, "/"c}
        End Class

#End Region
    End Class
End Namespace

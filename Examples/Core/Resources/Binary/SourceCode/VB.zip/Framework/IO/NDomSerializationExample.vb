Imports System
Imports System.IO
Imports Nevron.Nov.Dom
Imports Nevron.Nov.Examples.Text
Imports Nevron.Nov.Serialization
Imports Nevron.Nov.Text
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.Framework
    Friend Class NTestNode
        Inherits NNode
        Public Sub New()
        End Sub

        Shared Sub New()
            NTestNodeSchema = NSchema.Create(GetType(NTestNode), NNodeSchema)

            ExtendedPropertyEx = NProperty.CreateExtended(NTestNodeSchema, "Extended", NDomType.Boolean, True)
        End Sub

        Public Shared ReadOnly ExtendedPropertyEx As NProperty
        Public Shared NTestNodeSchema As NSchema
    End Class
    ''' <summary>
    ''' The example demonstrates how to modify the table borders, spacing etc.
    ''' </summary>
    Public Class NDomSerializationExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' 
        ''' </summary>
        Public Sub New()
        End Sub
        ''' <summary>
        ''' 
        ''' </summary>
        Shared Sub New()
            NDomSerializationExampleSchema = NSchema.Create(GetType(NDomSerializationExample), NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            ' Create the rich text
            Dim richTextWithRibbon As NRichTextViewWithRibbon = New NRichTextViewWithRibbon()
            m_RichText = richTextWithRibbon.View
            m_RichText.AcceptsTab = True
            m_RichText.Content.Sections.Clear()

            ' Populate the rich text
            PopulateRichText()

            Return richTextWithRibbon
        End Function
        Protected Overrides Function CreateExampleControls() As NWidget
            Dim stack As NStackPanel = New NStackPanel()

            Dim saveStateButton As NButton = New NButton("Save")
            saveStateButton.Click += New [Function](Of NEventArgs)(AddressOf OnSaveStateButtonClick)
            stack.Add(saveStateButton)

            m_LoadStateButton = New NButton("Load")
            m_LoadStateButton.Enabled = False
            m_LoadStateButton.Click += New [Function](Of NEventArgs)(AddressOf OnLoadStateButtonClick)
            stack.Add(m_LoadStateButton)

            Return stack
        End Function
        Protected Overrides Function GetExampleDescription() As String
            Return "
<p>This example demonstrates how to use DOM serialization in order to serialize / deserialize NOV NNode derived objects.</p>
<p>Press the Save button on the right to save the contents of the document and load to restore the contents to the last saved one.</p>" End Function

        Private Sub PopulateRichText()
            Dim section As NSection = New NSection()
            m_RichText.Content.Sections.Add(section)

            section.Blocks.Add(New NParagraph("Type some text here..."))
        End Sub

#End Region

#Region "Event Handlers"

        Private Sub OnSaveStateButtonClick(ByVal arg1 As NEventArgs)
            Try
                m_MemoryStream = New MemoryStream()

                Dim serializer As NDomNodeSerializer = New NDomNodeSerializer()

                Dim testNode As NTestNode = New NTestNode()

                testNode.SetValue(NTestNode.ExtendedPropertyEx, False)
                serializer.SaveToStream(New NNode() {testNode}, m_MemoryStream, ENPersistencyFormat.Binary)

                '				serializer.SaveToStream(new NNode[] { m_RichText.Content }, m_MemoryStream, ENPersistencyFormat.Binary);

                m_LoadStateButton.Enabled = True
            Catch ex As Exception
                NDebug.WriteLine(ex.Message)
            End Try
        End Sub
        Private Sub OnLoadStateButtonClick(ByVal arg1 As NEventArgs)
            If m_MemoryStream Is Nothing Then Return

            m_MemoryStream.Seek(0, SeekOrigin.Begin)

            Try
                Dim deserializer As NDomNodeDeserializer = New NDomNodeDeserializer()

                ' 				NDocumentBlock root = (NDocumentBlock)deserializer.LoadFromStream(m_MemoryStream, ENPersistencyFormat.Binary)[0];
                ' 
                ' 				if (root != null)
                ' 				{
                ' 					m_RichText.Document = new NRichTextDocument(root);
                ' 				}
                Dim root = CType(deserializer.LoadFromStream(m_MemoryStream, ENPersistencyFormat.Binary)(0), NTestNode)
            Catch ex As Exception
                NDebug.WriteLine(ex.Message)
            End Try
        End Sub
        Private Sub OnLoadDocumentButtonClick(ByVal args As NEventArgs)

        End Sub

#End Region

#Region "Fields"

        Private m_RichText As NRichTextView
        Private m_LoadStateButton As NButton
        Private m_MemoryStream As MemoryStream

#End Region

#Region "Schema"

        Public Shared ReadOnly NDomSerializationExampleSchema As NSchema

#End Region
    End Class
End Namespace

Imports System.IO
Imports System.Text

Imports Nevron.Nov.DataStructures
Imports Nevron.Nov.Dom
Imports Nevron.Nov.Graphics
Imports Nevron.Nov.Layout
Imports Nevron.Nov.Text
Imports Nevron.Nov.UI
Imports Nevron.Nov.Xml

Namespace Nevron.Nov.Examples.Framework
    Public Class NXmlSerializingExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' Default constructor.
        ''' </summary>
        Public Sub New()
        End Sub

        ''' <summary>
        ''' Static constructor.
        ''' </summary>
        Shared Sub New()
            NXmlSerializingExampleSchema = NSchema.Create(GetType(NXmlSerializingExample), NExampleBase.NExampleBaseSchema)
        End Sub

#End Region

#Region "Properties"

        Private ReadOnly Property DocumentItem As NTreeViewItem
            Get
                Return m_TreeView.Items(0)
            End Get
        End Property

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            Dim splitter As NSplitter = New NSplitter()
            splitter.SplitMode = ENSplitterSplitMode.Proportional
            splitter.SplitFactor = 0.5

            ' Create the "Dom Tree" group box
            m_TreeView = CreateTreeView()
            Me.m_TreeView.SelectedPathChanged += AddressOf OnTreeViewSelectedPathChanged

            Dim toolBar As NToolBar = New NToolBar()
            m_AddChildItemButton = CreateButton(NResources.Image_Add_png, "Add Child Item")
            Me.m_AddChildItemButton.Click += AddressOf OnAddChildItemButtonClick
            toolBar.Items.Add(m_AddChildItemButton)

            m_RemoveSelectedItemButton = CreateButton(NResources.Image_Delete_png, "Remove Selected Item")
            Me.m_RemoveSelectedItemButton.Click += AddressOf OnRemoveSelectedItemButtonClick
            toolBar.Items.Add(m_RemoveSelectedItemButton)

            toolBar.Items.Add(New NCommandBarSeparator())

            m_AddAttributeButton = CreateButton(NResources.Image_Add_png, "Add Attribute")
            Me.m_AddAttributeButton.Click += AddressOf OnAddAttributeButtonClick
            toolBar.Items.Add(m_AddAttributeButton)

            m_RemoveAttributeButton = CreateButton(NResources.Image_Delete_png, "Remove Attribute")
            Me.m_RemoveAttributeButton.Click += AddressOf OnRemoveAttributeButtonClick
            toolBar.Items.Add(m_RemoveAttributeButton)

            toolBar.Items.Add(New NCommandBarSeparator())

            m_SerializeButton = CreateButton(NResources.Image__16x16_Contacts_png, "Serialize")
            m_SerializeButton.Enabled = True
            Me.m_SerializeButton.Click += AddressOf OnSerializeButtonClick
            toolBar.Items.Add(m_SerializeButton)

            Dim pairBox As NPairBox = New NPairBox(m_TreeView, toolBar, ENPairBoxRelation.Box1AboveBox2)
            pairBox.FillMode = ENStackFillMode.First
            pairBox.FitMode = ENStackFitMode.First
            pairBox.Spacing = NDesign.VerticalSpacing
            splitter.Pane1.Content = pairBox

            ' Create the "XML output" group box
            m_XmlTextBox = New NTextBox()
            m_XmlTextBox.AcceptsEnter = True
            m_XmlTextBox.AcceptsTab = True
            m_XmlTextBox.Multiline = True
            m_XmlTextBox.WordWrap = False
            m_XmlTextBox.VScrollMode = ENScrollMode.WhenNeeded
            m_XmlTextBox.HScrollMode = ENScrollMode.WhenNeeded
            splitter.Pane2.Content = m_XmlTextBox

            ' Select the "Document" tree view item
            m_TreeView.SelectedItem = DocumentItem

            Return splitter
        End Function
        Protected Overrides Function CreateExampleControls() As NWidget
            Return Nothing
        End Function
        Protected Overrides Function GetExampleDescription() As String
            Return "
<p>
	This example demonstrates how to create and serialize XML documents with Nevron Open Vision. Use the buttons below the tree
	view to create a DOM tree and when ready click the <b>Serialize</b> button to construct a XML document from it and serialize
	it to the text box on the right.
</p>
" End Function

#End Region

#Region "Event Handlers"

        Private Sub OnAddChildItemButtonClick(ByVal arg As NEventArgs)
            Dim dialog = NApplication.CreateTopLevelWindow(NWindow.GetFocusedWindowIfNull(DisplayWindow))
            dialog.SetupDialogWindow("Enter element's name", False)

            Dim textBox As NTextBox = New NTextBox()
            Dim buttonStrip As NButtonStrip = New NButtonStrip()
            buttonStrip.AddOKCancelButtons()

            Dim pairBox As NPairBox = New NPairBox(textBox, buttonStrip, ENPairBoxRelation.Box1AboveBox2)
            pairBox.Spacing = NDesign.VerticalSpacing
            dialog.Content = pairBox

            dialog.Opened += Sub(ByVal args As NEventArgs) textBox.Focus()

            dialog.Closed += Sub(ByVal args As NEventArgs)
                                 If dialog.Result Is ENWindowResult.OK Then
                                     ' Add an item with the specified name
                                     m_TreeView.SelectedItem.Items.Add(CreateTreeViewItem(textBox.Text))
                                     m_TreeView.SelectedItem.Expanded = True

                                     If m_SerializeButton.Enabled = False Then
                                         m_SerializeButton.Enabled = True
                                     End If
                                 End If
                             End Sub

            dialog.Open()
        End Sub
        Private Sub OnRemoveSelectedItemButtonClick(ByVal arg As NEventArgs)
            NMessageBox.Show(NLoc.Get("Remove the selected tree view item"), NLoc.Get("Question"), ENMessageBoxButtons.YesNo, ENMessageBoxIcon.Question).Then(Sub(ByVal result As ENWindowResult)


                                                                                                                                                                  If result Is ENWindowResult.Yes Then
                                                                                                                                                                      Dim item = m_TreeView.SelectedItem
                                                                                                                                                                      Dim parentItem = item.ParentItem
                                                                                                                                                                      m_TreeView.SelectedItem = Nothing
                                                                                                                                                                      parentItem.Items.Remove(item)
                                                                                                                                                                      m_TreeView.SelectedItem = parentItem

                                                                                                                                                                      If DocumentItem.Items.Count = 0 Then
                                                                                                                                                                          m_SerializeButton.Enabled = False
                                                                                                                                                                      End If
                                                                                                                                                                  End If
                                                                                                                                                              End Sub)
        End Sub
        Private Sub OnAddAttributeButtonClick(ByVal arg As NEventArgs)
            Dim dialog As NTopLevelWindow = NApplication.CreateTopLevelWindow()
            dialog.SetupDialogWindow("Enter attribute's name and value", False)

            Dim table As NTableFlowPanel = New NTableFlowPanel()
            table.Direction = ENHVDirection.LeftToRight
            table.ColFillMode = ENStackFillMode.Last
            table.ColFitMode = ENStackFitMode.Last
            table.MaxOrdinal = 2

            Dim nameLabel As NLabel = New NLabel("Name:")
            table.Add(nameLabel)

            Dim nameTextBox As NTextBox = New NTextBox()
            table.Add(nameTextBox)

            Dim valueLabel As NLabel = New NLabel("Value:")
            table.Add(valueLabel)

            Dim valueTextBox As NTextBox = New NTextBox()
            table.Add(valueTextBox)

            table.Add(New NWidget())

            Dim buttonStrip As NButtonStrip = New NButtonStrip()
            buttonStrip.AddOKCancelButtons()
            table.Add(buttonStrip)

            dialog.Content = table

            dialog.Opened += Sub(ByVal args As NEventArgs) nameTextBox.Focus()

            dialog.Closed += Sub(ByVal args As NEventArgs)
                                 If dialog.Result Is ENWindowResult.OK Then
                                     Dim elementInfo = CType(m_TreeView.SelectedItem.Tag, NElementInfo)
                                     elementInfo.Attributes.Set(nameTextBox.Text, valueTextBox.Text)
                                     UpdateTreeViewItemText(m_TreeView.SelectedItem)

                                     If m_RemoveAttributeButton.Enabled = False Then
                                         m_RemoveAttributeButton.Enabled = True
                                     End If
                                 End If
                             End Sub

            dialog.Open()

        End Sub
        Private Sub OnRemoveAttributeButtonClick(ByVal arg As NEventArgs)
            Dim dialog As NTopLevelWindow = NApplication.CreateTopLevelWindow()
            dialog.SetupDialogWindow("Select an Attribute to Remove", False)

            Dim listBox As NListBox = New NListBox()
            Dim elementInfo = CType(m_TreeView.SelectedItem.Tag, NElementInfo)
            Dim iter As INIterator(Of NKeyValuePair(Of String, String)) = elementInfo.Attributes.GetIterator()

            While iter.MoveNext()
                listBox.Items.Add(New NListBoxItem(iter.Current.Key))
            End While

            Dim buttonStrip As NButtonStrip = New NButtonStrip()
            buttonStrip.AddOKCancelButtons()

            Dim pairBox As NPairBox = New NPairBox(listBox, buttonStrip, ENPairBoxRelation.Box1AboveBox2)
            pairBox.Spacing = NDesign.VerticalSpacing
            dialog.Content = pairBox

            dialog.Opened += Sub(ByVal args As NEventArgs) listBox.Focus()

            dialog.Closed += Sub(ByVal args As NEventArgs)
                                 If dialog.Result Is ENWindowResult.OK Then
                                     ' Remove the selected attribute
                                     Dim selectedItem = listBox.Selection.FirstSelected
                                     If selectedItem IsNot Nothing Then
                                         Dim name = CType(selectedItem.Content, NLabel).Text
                                         elementInfo.Attributes.Remove(name)
                                         UpdateTreeViewItemText(m_TreeView.SelectedItem)

                                         If elementInfo.Attributes.Count = 0 Then
                                             m_RemoveAttributeButton.Enabled = False
                                         End If
                                     End If
                                 End If
                             End Sub

            dialog.Open()
        End Sub
        Private Sub OnSerializeButtonClick(ByVal arg As NEventArgs)
            ' Create the XML document
            Dim document As NXmlDocument = New NXmlDocument()
            Dim documentItem = Me.DocumentItem
            Dim i = 0, childCount = documentItem.Items.Count

            While i < childCount
                document.AddChild(SerializeTreeViewItem(documentItem.Items(i)))
                i += 1
            End While

            ' Serialize the document to the XML text box
            Using stream As MemoryStream = New MemoryStream()
                ' Serialize the document to a memory stream
                document.SaveToStream(stream, NEncoding.UTF8)

                ' Populate the XML text box from the memory stream
                Dim data As Byte() = stream.ToArray()
                m_XmlTextBox.Text = NEncoding.UTF8.GetString(data)
            End Using
        End Sub
        Private Sub OnTreeViewSelectedPathChanged(ByVal arg As NValueChangeEventArgs)
            Dim selectItem = m_TreeView.SelectedItem
            If selectItem Is Nothing Then
                m_AddChildItemButton.Enabled = False
                m_RemoveSelectedItemButton.Enabled = False
                m_AddAttributeButton.Enabled = False
                m_RemoveAttributeButton.Enabled = False
                Return
            End If

            m_AddChildItemButton.Enabled = True
            m_RemoveSelectedItemButton.Enabled = selectItem IsNot DocumentItem

            Dim elementInfo As NElementInfo = TryCast(selectItem.Tag, NElementInfo)
            m_AddAttributeButton.Enabled = elementInfo IsNot Nothing
            m_RemoveAttributeButton.Enabled = elementInfo IsNot Nothing AndAlso elementInfo.Attributes.Count > 0
        End Sub

#End Region

#Region "Fields"

        Private m_TreeView As NTreeView
        Private m_XmlTextBox As NTextBox

        Private m_AddChildItemButton As NButton
        Private m_RemoveSelectedItemButton As NButton
        Private m_AddAttributeButton As NButton
        Private m_RemoveAttributeButton As NButton
        Private m_SerializeButton As NButton

#End Region

#Region "Schema"

        ''' <summary>
        ''' Schema associated with NXmlSerializingExample.
        ''' </summary>
        Public Shared ReadOnly NXmlSerializingExampleSchema As NSchema

#End Region

#Region "Static Methods"

        Private Shared Function CreateButton(ByVal image As NImage, ByVal text As String) As NButton
            Dim pairBox As NPairBox = New NPairBox(image, text)
            pairBox.Box1.VerticalPlacement = ENVerticalPlacement.Center
            pairBox.Box2.VerticalPlacement = ENVerticalPlacement.Center
            pairBox.Spacing = NDesign.VerticalSpacing

            Dim button As NButton = New NButton(pairBox)
            button.Enabled = False
            Return button
        End Function
        Private Shared Function CreateTreeViewItem(ByVal name As String) As NTreeViewItem
            Return CreateTreeViewItem(name, Nothing)
        End Function
        Private Shared Function CreateTreeViewItem(ByVal name As String, ByVal value As String) As NTreeViewItem
            Dim item As NTreeViewItem = New NTreeViewItem(name)
            item.Tag = New NElementInfo(name)
            If Not Equals(value, Nothing) Then
                item.Items.Add(New NTreeViewItem(value))
            End If

            Return item
        End Function
        Private Shared Function SerializeTreeViewItem(ByVal item As NTreeViewItem) As NXmlNode
            Dim elementInfo = CType(item.Tag, NElementInfo)
            If elementInfo Is Nothing Then
                Dim text = CType(item.Header.Content, NLabel).Text
                Return New NXmlTextNode(ENXmlNodeType.Text, text)
            End If

            ' Create an XML element for the current tree view item
            Dim element As NXmlElement = New NXmlElement(elementInfo.Name)
            If elementInfo.Attributes.Count > 0 Then
                ' Set the element's attributes
                Dim iter As INIterator(Of NKeyValuePair(Of String, String)) = elementInfo.Attributes.GetIterator()
                While iter.MoveNext()
                    element.SetAttribute(iter.Current.Key, iter.Current.Value)
                End While
            End If

            ' Loop through the item's children
            Dim i = 0, childCount = item.Items.Count

            While i < childCount
                element.AddChild(SerializeTreeViewItem(item.Items(i)))
                i += 1
            End While

            Return element
        End Function
        Private Shared Sub UpdateTreeViewItemText(ByVal item As NTreeViewItem)
            Dim elementInfo As NElementInfo = TryCast(item.Tag, NElementInfo)
            If elementInfo Is Nothing Then Return

            Dim text = elementInfo.Name
            If elementInfo.Attributes.Count > 0 Then
                ' Iterate through the attributes and append them to the text
                Dim sb As StringBuilder = New StringBuilder(text)
                Dim iter As INIterator(Of NKeyValuePair(Of String, String)) = elementInfo.Attributes.GetIterator()
                While iter.MoveNext()
                    sb.Append(" ")
                    sb.Append(iter.Current.Key)
                    sb.Append("=""")
                    sb.Append(iter.Current.Value)
                    sb.Append("""")
                End While

                text = sb.ToString()
            End If

            ' Update the text of the given tree view item
            CType(item.Header.Content, NLabel).Text = text
        End Sub
        Private Shared Function CreateTreeView() As NTreeView
            Dim treeView As NTreeView = New NTreeView()

            Dim root = CreateTreeViewItem("Document")
            root.Expanded = True
            treeView.Items.Add(root)

            Dim book1 = CreateTreeViewItem("book")
            book1.Expanded = True
            book1.Items.Add(CreateTreeViewItem("Author", "Gambardella, Matthew"))
            book1.Items.Add(CreateTreeViewItem("Title", "XML Developer's Guide"))
            root.Items.Add(book1)

            Dim book2 = CreateTreeViewItem("book")
            book2.Expanded = True
            book2.Items.Add(CreateTreeViewItem("Author", "O'Brien, Tim"))
            book2.Items.Add(CreateTreeViewItem("Title", "MSXML3: A Comprehensive Guide"))
            root.Items.Add(book2)

            Return treeView
        End Function

#End Region

#Region "Nested Types"

        Private Class NElementInfo
            Public Sub New(ByVal name As String)
                Me.Name = name
                Attributes = New NMap(Of String, String)()
            End Sub

            Public Name As String
            Public Attributes As NMap(Of String, String)
        End Class

#End Region
    End Class
End Namespace

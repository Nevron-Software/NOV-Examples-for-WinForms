Imports System
Imports System.IO
Imports System.Text
Imports Nevron.Nov.DataStructures
Imports Nevron.Nov.Dom
Imports Nevron.Nov.IO
Imports Nevron.Nov.Layout
Imports Nevron.Nov.UI
Imports Nevron.Nov.Xml

Namespace Nevron.Nov.Examples.Framework
    Public Class NXmlParsingExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' Default constructor.
        ''' </summary>
        Public Sub New()
        End Sub

        ''' <summary>
        ''' Static constructor.
        ''' </summary>
        Shared Sub New()
            NXmlParsingExampleSchema = NSchema.Create(GetType(NXmlParsingExample), NExampleBase.NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            Dim splitter As NSplitter = New NSplitter()
            splitter.SplitMode = ENSplitterSplitMode.Proportional
            splitter.SplitFactor = 0.5

            ' Create the "XML content" group box
            Dim stack As NStackPanel = New NStackPanel()
            stack.FitMode = ENStackFitMode.First
            stack.FillMode = ENStackFillMode.First
            stack.VerticalSpacing = NDesign.VerticalSpacing
            m_XmlTextBox = New NTextBox()
            m_XmlTextBox.AcceptsEnter = True
            m_XmlTextBox.AcceptsTab = True
            m_XmlTextBox.Multiline = True
            m_XmlTextBox.WordWrap = False
            m_XmlTextBox.VScrollMode = ENScrollMode.WhenNeeded
            m_XmlTextBox.HScrollMode = ENScrollMode.WhenNeeded
            m_XmlTextBox.Text = SampleXml
            stack.Add(m_XmlTextBox)
            Dim parseButton As NButton = New NButton("Parse")
            parseButton.Content.HorizontalPlacement = ENHorizontalPlacement.Center
            AddHandler parseButton.Click, AddressOf OnParseButtonClick
            stack.Add(parseButton)
            splitter.Pane1.Content = New NGroupBox("XML Content", stack)

            ' Create the "DOM tree" group box
            m_DomTree = New NTreeView()
            splitter.Pane2.Content = New NGroupBox("DOM Tree", m_DomTree)
            Return splitter
        End Function

        Protected Overrides Function CreateExampleControls() As NWidget
            Dim openFileButton As NButton = New NButton("Open File")
            AddHandler openFileButton.Click, AddressOf OnOpenFileButtonClick
            openFileButton.VerticalPlacement = ENVerticalPlacement.Top
            Return openFileButton
        End Function

        Protected Overrides Function GetExampleDescription() As String
            Return "
<p>
	This example demonstrates the XML parsing engine provided by Nevron Open Vision. Edit the XML content and when ready click
	the <b>Parse</b> button to trigger the parsing of the XML content. You will see the resulting DOM tree on the right. You
	can also load a XML file for parsing by clicking the <b>Open File</b> button on the right.
</p>
"
        End Function

#End Region

#Region "Implementation - Parsing"

        Private Sub Parse(ByVal data As Object)
            ' Parse the content of the text box
            Dim document As NXmlDocument = Nothing

            If TypeOf data Is String Then
                ' Method 1 - use a parser and a listener
                Dim listener As NXmlDocumentParserListener = New NXmlDocumentParserListener()
                Dim parser As NXmlParser = New NXmlParser(listener)
                parser.Parse(CStr(data).ToCharArray())
                document = listener.Document
            ElseIf TypeOf data Is Stream Then
                ' Method 2 - call the static Load method of the XML document class
                document = NXmlDocument.LoadFromStream(CType(data, Stream))
            Else
                Throw New ArgumentException("Unsupported data type", "data")
            End If

            ' Populate the DOM tree view
            m_DomTree.SelectedItem = Nothing
            m_DomTree.Items.Clear()
            m_DomTree.Items.Add(CreateTreeViewItem(document))

            ' Expand all items up to the second level
            ExpandTreeViewItems(m_DomTree.Items(0), 2, 1)
        End Sub

#End Region

#Region "Event Handlers"

        Private Sub OnParseButtonClick(ByVal arg As NEventArgs)
            Parse(m_XmlTextBox.Text)
        End Sub

        Private Sub OnOpenFileButtonClick(ByVal arg As NEventArgs)
            Dim openFileDialog As NOpenFileDialog = New NOpenFileDialog()
            openFileDialog.FileTypes = New NFileDialogFileType() {New NFileDialogFileType("Xml Files (*.xml)", "xml")}
            AddHandler openFileDialog.Closed, AddressOf OnOpenFileDialogClosed
            openFileDialog.RequestShow()
        End Sub

        Private Sub OnOpenFileDialogClosed(ByVal arg As NOpenFileDialogResult)
            If arg.Result <> ENCommonDialogResult.OK Then Return
            arg.Files(0).OpenRead().Then(Sub(ByVal stream As Stream)
                                             Using stream
                                                 m_XmlTextBox.Text = NStreamHelpers.ReadToEndAsString(stream)
                                                 stream.Position = 0
                                                 Parse(stream)
                                             End Using
                                         End Sub, Sub(ByVal ex) NMessageBox.ShowError(ex.Message, "Error"))
        End Sub

#End Region

#Region "Fields"

        Private m_XmlTextBox As NTextBox
        Private m_DomTree As NTreeView

#End Region

#Region "Schema"

        ''' <summary>
        ''' Schema associated with NXmlParsingExample.
        ''' </summary>
        Public Shared ReadOnly NXmlParsingExampleSchema As NSchema

#End Region

#Region "Static Methods"

        Private Shared Function CreateTreeViewItem(ByVal node As NXmlNode) As NTreeViewItem
            ' Create a tree view item for the current XML node
            Dim item As NTreeViewItem

            Select Case node.NodeType
                Case ENXmlNodeType.CDATA, ENXmlNodeType.Comment, ENXmlNodeType.Document
                    item = New NTreeViewItem(node.Name)
                Case ENXmlNodeType.Declaration, ENXmlNodeType.Element
                    Dim text = node.Name
                    Dim element = CType(node, NXmlElement)
                    Dim attributesIter As INIterator(Of NKeyValuePair(Of String, String)) = element.GetAttributesIterator()

                    If attributesIter IsNot Nothing Then
                        ' Append the element attributes
                        Dim sb As StringBuilder = New StringBuilder(text)

                        While attributesIter.MoveNext()
                            sb.Append(" ")
                            sb.Append(attributesIter.Current.Key)
                            sb.Append("=""")
                            sb.Append(attributesIter.Current.Value)
                            sb.Append("""")
                        End While

                        text = sb.ToString()
                    End If

                    item = New NTreeViewItem(text)
                Case ENXmlNodeType.Text
                    item = New NTreeViewItem("Text: """ & CType(node, NXmlTextNode).Text & """")
                Case Else
                    Throw New Exception("New ENXmlNodeType?")
            End Select

            ' Traverse the node's children and create a child item for each of them
            Dim iter As INIterator(Of NXmlNode) = node.GetChildNodesIterator()

            If iter IsNot Nothing Then
                While iter.MoveNext()
                    Dim childItem = CreateTreeViewItem(iter.Current)
                    item.Items.Add(childItem)
                End While
            End If

            ' Return the created tree view item
            Return item
        End Function

        Private Shared Sub ExpandTreeViewItems(ByVal item As NTreeViewItem, ByVal levelsToExand As Integer, ByVal currentLevel As Integer)
            ' Expand the current item
            item.Expanded = True

            ' If the desired number of levels has been expanded, quit
            If currentLevel = levelsToExand Then Return

            ' Expand the child items of the current item
            currentLevel += 1
            Dim i = 0, count = item.Items.Count

            While i < count
                ExpandTreeViewItems(item.Items(i), levelsToExand, currentLevel)
                i += 1
            End While
        End Sub

#End Region

#Region "Constants"

        Private Const SampleXml As String = "
<?xml version=""1.0""?>
<catalog>
   <book id=""bk101"">
      <author>Gambardella, Matthew</author>
      <title>XML Developer's Guide</title>
      <genre>Computer</genre>
      <price>44.95</price>
      <publish_date>2000-10-01</publish_date>
      <description>An in-depth look at creating applications 
      with XML.</description>
   </book>
   <book id=""bk102"">
      <author>Ralls, Kim</author>
      <title>Midnight Rain</title>
      <genre>Fantasy</genre>
      <price>5.95</price>
      <publish_date>2000-12-16</publish_date>
      <description>A former architect battles corporate zombies, 
      an evil sorceress, and her own childhood to become queen 
      of the world.</description>
   </book>
   <book id=""bk103"">
      <author>Corets, Eva</author>
      <title>Maeve Ascendant</title>
      <genre>Fantasy</genre>
      <price>5.95</price>
      <publish_date>2000-11-17</publish_date>
      <description>After the collapse of a nanotechnology 
      society in England, the young survivors lay the 
      foundation for a new society.</description>
   </book>
   <book id=""bk104"">
      <author>Corets, Eva</author>
      <title>Oberon's Legacy</title>
      <genre>Fantasy</genre>
      <price>5.95</price>
      <publish_date>2001-03-10</publish_date>
      <description>In post-apocalypse England, the mysterious 
      agent known only as Oberon helps to create a new life 
      for the inhabitants of London. Sequel to Maeve 
      Ascendant.</description>
   </book>
   <book id=""bk105"">
      <author>Corets, Eva</author>
      <title>The Sundered Grail</title>
      <genre>Fantasy</genre>
      <price>5.95</price>
      <publish_date>2001-09-10</publish_date>
      <description>The two daughters of Maeve, half-sisters, 
      battle one another for control of England. Sequel to 
      Oberon's Legacy.</description>
   </book>
   <book id=""bk106"">
      <author>Randall, Cynthia</author>
      <title>Lover Birds</title>
      <genre>Romance</genre>
      <price>4.95</price>
      <publish_date>2000-09-02</publish_date>
      <description>When Carla meets Paul at an ornithology 
      conference, tempers fly as feathers get ruffled.</description>
   </book>
   <book id=""bk107"">
      <author>Thurman, Paula</author>
      <title>Splish Splash</title>
      <genre>Romance</genre>
      <price>4.95</price>
      <publish_date>2000-11-02</publish_date>
      <description>A deep sea diver finds true love twenty 
      thousand leagues beneath the sea.</description>
   </book>
   <book id=""bk108"">
      <author>Knorr, Stefan</author>
      <title>Creepy Crawlies</title>
      <genre>Horror</genre>
      <price>4.95</price>
      <publish_date>2000-12-06</publish_date>
      <description>An anthology of horror stories about roaches,
      centipedes, scorpions  and other insects.</description>
   </book>
   <book id=""bk109"">
      <author>Kress, Peter</author>
      <title>Paradox Lost</title>
      <genre>Science Fiction</genre>
      <price>6.95</price>
      <publish_date>2000-11-02</publish_date>
      <description>After an inadvertant trip through a Heisenberg
      Uncertainty Device, James Salway discovers the problems 
      of being quantum.</description>
   </book>
   <book id=""bk110"">
      <author>O'Brien, Tim</author>
      <title>Microsoft .NET: The Programming Bible</title>
      <genre>Computer</genre>
      <price>36.95</price>
      <publish_date>2000-12-09</publish_date>
      <description>Microsoft's .NET initiative is explored in 
      detail in this deep programmer's reference.</description>
   </book>
   <book id=""bk111"">
      <author>O'Brien, Tim</author>
      <title>MSXML3: A Comprehensive Guide</title>
      <genre>Computer</genre>
      <price>36.95</price>
      <publish_date>2000-12-01</publish_date>
      <description>The Microsoft MSXML3 parser is covered in 
      detail, with attention to XML DOM interfaces, XSLT processing, 
      SAX and more.</description>
   </book>
   <book id=""bk112"">
      <author>Galos, Mike</author>
      <title>Visual Studio 7: A Comprehensive Guide</title>
      <genre>Computer</genre>
      <price>49.95</price>
      <publish_date>2001-04-16</publish_date>
      <description>Microsoft Visual Studio 7 is explored in depth,
      looking at how Visual Basic, Visual C++, C#, and ASP+ are 
      integrated into a comprehensive development 
      environment.</description>
   </book>
</catalog>
"

#End Region
    End Class
End Namespace

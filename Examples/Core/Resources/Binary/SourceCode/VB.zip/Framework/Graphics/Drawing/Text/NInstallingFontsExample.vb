Imports Nevron.Nov.Dom
Imports Nevron.Nov.Graphics
Imports Nevron.Nov.Layout
Imports Nevron.Nov.UI
Imports System.Text
Imports Nevron.Nov.TrueType

Namespace Nevron.Nov.Examples.Framework
    ''' <summary>
    ''' The example demonstrates how to paint text at location
    ''' </summary>
    Public Class NInstallingFontsExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' Default constructor.
        ''' </summary>
        Public Sub New()
        End Sub
        ''' <summary>
        ''' Static constructor.
        ''' </summary>
        Shared Sub New()
            NInstallingFontsExampleSchema = NSchema.Create(GetType(NInstallingFontsExample), NExampleBase.NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            Dim font As NOTResourceInstalledFont = NResources.Font_LiberationMonoBold_ttf
            Dim descriptor = font.InstalledFonts(0).Descriptor
            m_FontDescriptor = New NFontDescriptor(descriptor.m_FamilyName, descriptor.m_FontVariant)
            NApplication.FontService.InstalledFontsMap.InstallFont(font)

            ' Create a table panel to hold the canvases and the labels
            Dim stack As NStackPanel = New NStackPanel()
            stack.FillMode = ENStackFillMode.Last
            stack.FitMode = ENStackFitMode.Last
            Dim canvas As NCanvas = New NCanvas()
            stack.Add(canvas)
            AddHandler canvas.PrePaint, New [Function](Of NCanvasPaintEventArgs)(AddressOf OnCanvasPrePaint)
            canvas.BackgroundFill = New NColorFill(NColor.White)
            Return stack
        End Function

        Protected Overrides Function CreateExampleControls() As NWidget
            Return Nothing
        End Function

        Protected Overrides Function GetExampleDescription() As String
            Return "
<p>
The example demonstrates how to install fonts.
</p>
"
        End Function

#End Region

#Region "Event Handlers"

        ''' <summary>
        ''' 
        ''' </summary>
        ''' <paramname="args"></param>
        Private Sub OnCanvasPrePaint(ByVal args As NCanvasPaintEventArgs)
            Dim canvas As NCanvas = TryCast(args.TargetNode, NCanvas)
            If canvas Is Nothing Then Return
            Dim paintVisitor = args.PaintVisitor
            Dim contentEge As NRectangle = canvas.GetContentEdge()

            ' create the text bounds
            Dim width = contentEge.Width * 0.5
            Dim height = contentEge.Height * 0.5
            Dim center = contentEge.Center
            Dim textBounds As NRectangle = New NRectangle(center.X - width / 2.0, center.Y - height / 2.0, width, height)

            ' create the settings
            Dim settings As NPaintTextRectSettings = New NPaintTextRectSettings()
            settings.SingleLine = False
            settings.WrapMode = ENTextWrapMode.WordWrap
            settings.HorzAlign = ENTextHorzAlign.Center
            settings.VertAlign = ENTextVertAlign.Center

            ' create the text
            Dim builder As StringBuilder = New StringBuilder()
            builder.AppendLine("This text is displayed using Liberation Fonts!")
            builder.AppendLine("distributed under the SIL Open Font License (OFL)")

            ' paint the bounding box
            paintVisitor.ClearStyles()
            paintVisitor.SetFill(NColor.LightBlue)
            paintVisitor.PaintRectangle(textBounds)

            ' init font and fill
            paintVisitor.SetFill(NColor.Black)
            Dim fontStyle = NFontFaceDescriptor.FontVariantToFontStyle(m_FontDescriptor.FontVariant)
            paintVisitor.SetFont(New NFont(m_FontDescriptor.FamilyName, 10, fontStyle))

            ' paint the text
            paintVisitor.PaintString(textBounds, builder.ToString(), settings)
        End Sub

#End Region

#Region "Fonts"

        Private m_FontDescriptor As NFontDescriptor

#End Region

#Region "Schema"

        ''' <summary>
        ''' Schema associated with NInstallingFontsExample.
        ''' </summary>
        Public Shared ReadOnly NInstallingFontsExampleSchema As NSchema

#End Region
    End Class
End Namespace

Imports Nevron.Nov.Dom
Imports Nevron.Nov.UI
Imports Nevron.Nov.Layout
Imports Nevron.Nov.Graphics
Imports Nevron.Nov.DataStructures
Imports System.IO

Namespace Nevron.Nov.Examples.Framework
    ''' <summary>
    ''' The BMP images displayed in this example are created by Jason Summers (jason1@pobox.com).
    ''' For more information: http://entropymine.com/jason/bmpsuite/
    ''' </summary>
    Public Class NBmpDecoderExample
        Inherits NExampleBase
#Region "Constructors"

        Public Sub New()
        End Sub

        Shared Sub New()
            NBmpDecoderExampleSchema = NSchema.Create(GetType(NBmpDecoderExample), NExampleBase.NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            Dim colHeadings = New String() {"Image", "Description", "Decoded with NOV Decoders", "Decoded with Native Decoders"}
            Dim colCount = colHeadings.Length
            Dim table As NTableFlowPanel = New NTableFlowPanel()
            table.HorizontalPlacement = ENHorizontalPlacement.Left
            table.VerticalPlacement = ENVerticalPlacement.Top
            table.Padding = New NMargins(30)
            table.HorizontalSpacing = 30
            table.VerticalSpacing = 30
            table.MaxOrdinal = colCount
            Dim imageNames = GetImageNames("BmpSuite", "bmp")
            Dim descriptions = NImageDecodingExampleHelper.LoadDescriptions(NResources.String_BmpSuite_txt)

            For i = 0 To colCount - 1
                Dim label As NLabel = New NLabel(colHeadings(i))
                label.Font = New NFont(NFontDescriptor.DefaultSansFamilyName, 9, ENFontStyle.Bold)
                table.Add(label)
            Next

            Dim rowCount = imageNames.Count

            For i = 0 To rowCount - 1
                Dim resourceName = imageNames(i)
                Dim description = GetImageDescription(descriptions, resourceName)
                Dim nameLabel As NLabel = New NLabel(resourceName)
                nameLabel.MaxWidth = 200
                Dim descriptionLabel As NLabel = New NLabel(description)
                descriptionLabel.MaxWidth = 200
                descriptionLabel.TextWrapMode = ENTextWrapMode.WordWrap
                Dim novImage = LoadImage(resourceName, ENCodecPreference.OnlyNOV)
                Dim novImageBox As NImageBox = New NImageBox(novImage)
                novImageBox.ImageMapping = New NAlignTextureMapping(ENHorizontalAlignment.Center, ENVerticalAlignment.Center)
                Dim nativeImage = LoadImage(resourceName, ENCodecPreference.PreferNative)
                Dim nativeImageBox As NImageBox = New NImageBox(nativeImage)
                nativeImageBox.ImageMapping = New NAlignTextureMapping(ENHorizontalAlignment.Center, ENVerticalAlignment.Center)
                table.Add(nameLabel)
                table.Add(descriptionLabel)
                table.Add(novImageBox)
                table.Add(nativeImageBox)
            Next

            ' The table must be scrollable
            Dim scroll As NScrollContent = New NScrollContent()
            scroll.Content = table
            Return scroll
        End Function

        Protected Overrides Function CreateExampleControls() As NWidget
            Return Nothing
        End Function

        Protected Overrides Function GetExampleDescription() As String
            Return "
<p>
	This example demonstrates NOV's BMP image decoding capabilities.
</p>
"
        End Function

#End Region

#Region "Schema"

        Public Shared ReadOnly NBmpDecoderExampleSchema As NSchema

#End Region
    End Class

    Friend Module NImageDecodingExampleHelper
        Friend Function GetImageNames(ByVal suiteName As String, ByVal extension As String) As NList(Of String)
            Dim names As String() = NResources.Instance.GetResourceNames()
            Dim resources As NList(Of String) = New NList(Of String)()
            Dim i = 0, count = names.Length

            While i < count

                If names(i).EndsWith(extension) AndAlso names(i).Contains(suiteName) Then
                    resources.Add(names(i))
                End If

                i += 1
            End While

            Return resources
        End Function

        Friend Function LoadDescriptions(ByVal descriptionTextFileContent As String) As NMap(Of String, String)
            Dim descriptions As NMap(Of String, String) = New NMap(Of String, String)()

            Using reader As StringReader = New StringReader(descriptionTextFileContent)
                Dim line As String

                While Not Equals((CSharpImpl.__Assign(line, reader.ReadLine())), Nothing)
                    Dim dashIndex = line.IndexOf("-", 0)

                    If dashIndex > 0 Then
                        Dim name As String = line.Remove(dashIndex).Trim()
                        Dim description As String = line.Remove(0, dashIndex + 1).Trim()
                        descriptions.Add(name, description)
                    End If
                End While
            End Using

            Return descriptions
        End Function

        Friend Function ResourceNameToFileName(ByVal resourceName As String) As String
            Dim index = resourceName.LastIndexOf("_"c)
            index = resourceName.LastIndexOf("_"c, index - 1)
            Return resourceName.Substring(index + 1).Replace("_"c, "."c).ToLower()
        End Function

        Friend Function GetImageDescription(ByVal descriptions As NMap(Of String, String), ByVal resourceName As String) As String
            Dim desc As String
            If descriptions.TryGet(ResourceNameToFileName(resourceName), desc) Then Return desc
            Return String.Empty
        End Function

        Friend Function LoadImage(ByVal resourceName As String, ByVal decoderPref As ENCodecPreference) As NImage
            Dim resource As NEmbeddedResource = NResources.Instance.GetResource(resourceName)
            Dim imageData As NImageData = New NImageData(resource.Data)

            Try
                Dim raster = imageData.Decode(decoderPref)
                Return New NImage(raster)
            Catch
                Return NResources.Image_ErrorImage_png
            End Try
        End Function

        Private Class CSharpImpl
            <Obsolete("Please refactor calling code to use normal Visual Basic assignment")>
            Shared Function __Assign(Of T)(ByRef target As T, value As T) As T
                target = value
                Return value
            End Function
        End Class
    End Module
End Namespace

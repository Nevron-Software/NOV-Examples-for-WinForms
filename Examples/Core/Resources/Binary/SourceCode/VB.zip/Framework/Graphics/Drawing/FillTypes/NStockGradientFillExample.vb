Imports System
Imports Nevron.Nov.Dom
Imports Nevron.Nov.Graphics
Imports Nevron.Nov.Layout
Imports Nevron.Nov.UI
Imports Nevron.Nov.DataStructures
Imports System.Runtime.InteropServices

Namespace Nevron.Nov.Examples.Framework
    Public Class NStockGradientFillExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' Default constructor.
        ''' </summary>
        Public Sub New()
        End Sub
        ''' <summary>
        ''' Static constructor.
        ''' </summary>
        Shared Sub New()
            NStockGradientFillExampleSchema = NSchema.Create(GetType(NStockGradientFillExample), NExampleBase.NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            ' Create the gradient fills
            Dim fills As NFill()
            Dim texts As String()
            Dim columnCount = CreateFillsAndDescriptions(fills, texts)

            ' Create a table panel to hold the canvases and the labels
            m_Table = New NTableFlowPanel()
            m_Table.HorizontalPlacement = ENHorizontalPlacement.Left
            m_Table.VerticalPlacement = ENVerticalPlacement.Top
            m_Table.Padding = New NMargins(30)
            m_Table.HorizontalSpacing = 30
            m_Table.VerticalSpacing = 30
            m_Table.MaxOrdinal = columnCount

            For i = 0 To fills.Length - 1
                Dim stack As NStackPanel = New NStackPanel()
                m_Table.Add(stack)
                stack.Direction = ENHVDirection.TopToBottom
                stack.FillMode = ENStackFillMode.First
                stack.FitMode = ENStackFitMode.First

                ' Create a widget with the proper filling
                Dim canvas As NCanvas = New NCanvas()
                canvas.PreferredSize = New NSize(defaultCanvasWidth, defaultCanvasHeight)
                canvas.Tag = fills(i)
                stack.Add(canvas)
                AddHandler canvas.PrePaint, New [Function](Of NCanvasPaintEventArgs)(AddressOf OnCanvasPrePaint)

                ' Create a label with the corresponding name
                Dim label As NLabel = New NLabel(texts(i))
                stack.Add(label)
                label.HorizontalPlacement = ENHorizontalPlacement.Center
            Next

            ' The table must be scrollable
            Dim scroll As NScrollContent = New NScrollContent()
            scroll.Content = m_Table
            Return scroll
        End Function

        Protected Overrides Function CreateExampleControls() As NWidget
            Dim colorBox1 As NColorBox = New NColorBox()
            colorBox1.SelectedColor = defaultBeginColor
            AddHandler colorBox1.SelectedColorChanged, New [Function](Of NValueChangeEventArgs)(AddressOf OnColorBoxSelectedColorChanged)
            colorBox1.Tag = NStockGradientFill.BeginColorProperty
            Dim colorBox2 As NColorBox = New NColorBox()
            colorBox2.SelectedColor = defaultEndColor
            AddHandler colorBox2.SelectedColorChanged, New [Function](Of NValueChangeEventArgs)(AddressOf OnColorBoxSelectedColorChanged)
            colorBox2.Tag = NStockGradientFill.EndColorProperty

            ' Canvas width editor
            m_CanvasWidthUpDown = New NNumericUpDown()
            m_CanvasWidthUpDown.Minimum = 100
            m_CanvasWidthUpDown.Maximum = 300
            m_CanvasWidthUpDown.Value = defaultCanvasWidth
            m_CanvasWidthUpDown.Step = 1
            m_CanvasWidthUpDown.DecimalPlaces = 0
            AddHandler m_CanvasWidthUpDown.ValueChanged, New [Function](Of NValueChangeEventArgs)(AddressOf OnNumericUpDownValueChanged)

            ' Canvas height editor
            m_CanvasHeightUpDown = New NNumericUpDown()
            m_CanvasHeightUpDown.Minimum = 100
            m_CanvasHeightUpDown.Maximum = 300
            m_CanvasHeightUpDown.Value = defaultCanvasHeight
            m_CanvasHeightUpDown.Step = 1
            m_CanvasHeightUpDown.DecimalPlaces = 0
            AddHandler m_CanvasHeightUpDown.ValueChanged, New [Function](Of NValueChangeEventArgs)(AddressOf OnNumericUpDownValueChanged)

            ' create a stack and put the controls in it
            Dim stack As NStackPanel = New NStackPanel()
            stack.Add(NPairBox.Create("Begin Color:", colorBox1))
            stack.Add(NPairBox.Create("End Color:", colorBox2))
            stack.Add(NPairBox.Create("Canvas Width:", m_CanvasWidthUpDown))
            stack.Add(NPairBox.Create("Canvas Height:", m_CanvasHeightUpDown))
            Return New NUniSizeBoxGroup(stack)
        End Function

        Protected Overrides Function GetExampleDescription() As String
            Return "
<p>
	This example shows the gradient fillings supported by NOV. Use the controls to the right to specify the begin and end colors of the gradients.
</p>
"
        End Function

#End Region

#Region "Event Handlers"

        Private Sub OnCanvasPrePaint(ByVal args As NCanvasPaintEventArgs)
            Dim canvas As NCanvas = TryCast(args.TargetNode, NCanvas)
            If canvas Is Nothing Then Return
            Dim fill = CType(canvas.Tag, NFill)
            args.PaintVisitor.ClearStyles()
            args.PaintVisitor.SetFill(fill)
            args.PaintVisitor.PaintRectangle(0, 0, canvas.Width, canvas.Height)
        End Sub

        Private Sub OnColorBoxSelectedColorChanged(ByVal args As NValueChangeEventArgs)
            If m_Table Is Nothing Then Return
            Dim color As NColor = args.NewValue
            Dim colorBox = CType(args.TargetNode, NColorBox)
            Dim [property] = CType(colorBox.Tag, NProperty)
            Dim iterator As INIterator(Of NNode) = m_Table.GetSubtreeIterator(ENTreeTraversalOrder.DepthFirstPreOrder, New NInstanceOfSchemaFilter(NCanvas.NCanvasSchema))

            While iterator.MoveNext()
                Dim canvas = CType(iterator.Current, NCanvas)

                ' update the gradient color that corresponds to the changed color box
                CType(canvas.Tag, NStockGradientFill).SetValue([property], color)

                ' Invalidate the canvas
                canvas.InvalidateDisplay()
            End While
        End Sub

        Private Sub OnNumericUpDownValueChanged(ByVal args As NValueChangeEventArgs)
            If m_Table Is Nothing Then Return
            Dim width = m_CanvasWidthUpDown.Value
            Dim height = m_CanvasHeightUpDown.Value

            ' Resize the canvases
            Dim iterator As INIterator(Of NNode) = m_Table.GetSubtreeIterator(ENTreeTraversalOrder.DepthFirstPreOrder, New NInstanceOfSchemaFilter(NCanvas.NCanvasSchema))

            While iterator.MoveNext()
                Dim canvas = CType(iterator.Current, NCanvas)
                CType(canvas.ParentNode, NWidget).PreferredWidth = width
                canvas.PreferredHeight = height
            End While
        End Sub

#End Region

#Region "Implementation"

        Private Function CreateFillsAndDescriptions(<Out> ByRef fills As NFill(), <Out> ByRef texts As String()) As Integer
            Dim gradientStyles As Array = NEnum.GetValues(GetType(ENGradientStyle))
            Dim gradientVariants As Array = NEnum.GetValues(GetType(ENGradientVariant))
            Dim styleCount = gradientStyles.Length
            Dim variantCount = gradientVariants.Length
            Dim count = styleCount * variantCount
            Dim index = 0
            fills = New NFill(count - 1) {}
            texts = New String(count - 1) {}

            ' Create the gradient fills
            For i = 0 To variantCount - 1
                Dim [variant] As ENGradientVariant = gradientVariants.GetValue(i)

                For j = 0 To styleCount - 1
                    Dim style As ENGradientStyle = gradientStyles.GetValue(j)
                    fills(index) = New NStockGradientFill(style, [variant], defaultBeginColor, defaultEndColor)
                    texts(index) = style.ToString() & " " & [variant].ToString()
                    index += 1
                Next
            Next

            Return styleCount
        End Function

#End Region

#Region "Fields"

        Private m_Table As NTableFlowPanel
        Private m_CanvasWidthUpDown As NNumericUpDown
        Private m_CanvasHeightUpDown As NNumericUpDown

#End Region

#Region "Constants"

        Const defaultCanvasWidth As Integer = 160
        Const defaultCanvasHeight As Integer = 100
        Private Shared ReadOnly defaultBeginColor As NColor = NColor.Lavender
        Private Shared ReadOnly defaultEndColor As NColor = NColor.Indigo

#End Region

#Region "Schema"

        ''' <summary>
        ''' Schema associated with NStockGradientFillExample.
        ''' </summary>
        Public Shared ReadOnly NStockGradientFillExampleSchema As NSchema

#End Region
    End Class
End Namespace

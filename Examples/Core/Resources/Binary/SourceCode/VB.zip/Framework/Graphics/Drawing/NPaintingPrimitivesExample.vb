Imports System
Imports Nevron.Nov.Dom
Imports Nevron.Nov.Graphics
Imports Nevron.Nov.Layout
Imports Nevron.Nov.UI
Imports Nevron.Nov.DataStructures

Namespace Nevron.Nov.Examples.Framework
    Public Class NPaintingPrimitivesExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' Default constructor.
        ''' </summary>
        Public Sub New()
        End Sub
        ''' <summary>
        ''' Static constructor.
        ''' </summary>
        Shared Sub New()
            NPaintingPrimitivesExampleSchema = NSchema.Create(GetType(NPaintingPrimitivesExample), NExampleBase.NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            Dim names = New String() {"Line", "Polyline", "Rectangle", "Ellipse", "Triangle", "Quad", "Polygon", "Graphics Path"}

            Dim delegates As PaintPrimitiveDelegate() = New PaintPrimitiveDelegate() {New PaintPrimitiveDelegate(AddressOf PaintLine), New PaintPrimitiveDelegate(AddressOf PaintPolyline), New PaintPrimitiveDelegate(AddressOf PaintRectangle), New PaintPrimitiveDelegate(AddressOf PaintEllipse), New PaintPrimitiveDelegate(AddressOf PaintTriangle), New PaintPrimitiveDelegate(AddressOf PaintQuadrangle), New PaintPrimitiveDelegate(AddressOf PaintPolygon), New PaintPrimitiveDelegate(AddressOf PaintPath)}

            Dim count = delegates.Length

            ' Create a table panel to hold the canvases and the labels
            m_Table = New NTableFlowPanel()
            m_Table.HorizontalPlacement = ENHorizontalPlacement.Left
            m_Table.VerticalPlacement = ENVerticalPlacement.Top
            m_Table.Padding = New NMargins(30)
            m_Table.HorizontalSpacing = 30
            m_Table.VerticalSpacing = 30
            m_Table.MaxOrdinal = 4

            For i = 0 To count - 1
                Dim stack As NStackPanel = New NStackPanel()
                m_Table.Add(stack)
                stack.VerticalSpacing = 5

                ' Create a canvas to draw in
                Dim canvas As NCanvas = New NCanvas()
                canvas.PreferredSize = New NSize(DefaultCanvasWidth, DefaultCanvasHeight)
                canvas.Tag = delegates(i)
                canvas.PrePaint += New [Function](Of NCanvasPaintEventArgs)(AddressOf OnCanvasPrePaint)
                canvas.BackgroundFill = New NColorFill(NColor.LightBlue)
                stack.Add(canvas)

                ' Create a label for the geometry primitive's name
                Dim label As NLabel = New NLabel(names(i))
                label.HorizontalPlacement = ENHorizontalPlacement.Center
                stack.Add(label)
            Next

            ' The table must be scrollable
            Dim scroll As NScrollContent = New NScrollContent()
            scroll.Content = m_Table
            Return scroll
        End Function
        Protected Overrides Function CreateExampleControls() As NWidget
            ' Fill
            m_FillSplitButton = New NFillSplitButton()
            Me.m_FillSplitButton.SelectedValueChanged += AddressOf OnFillSplitButtonSelectedValueChanged

            ' Stroke color
            m_StrokeColorBox = New NColorBox()
            m_StrokeColorBox.SelectedColor = m_Stroke.Color
            Me.m_StrokeColorBox.SelectedColorChanged += AddressOf OnStrokeColorBoxSelectedColorChanged

            ' Stroke width
            m_StrokeWidthCombo = New NComboBox()
            For i = 0 To 5
                m_StrokeWidthCombo.Items.Add(New NComboBoxItem(i.ToString()))
            Next
            m_StrokeWidthCombo.SelectedIndex = 1
            Me.m_StrokeWidthCombo.SelectedIndexChanged += AddressOf OnStrokeWidthComboSelectedIndexChanged

            ' Canvas width editor
            m_CanvasWidthUpDown = New NNumericUpDown()
            m_CanvasWidthUpDown.Minimum = 100
            m_CanvasWidthUpDown.Maximum = 350
            m_CanvasWidthUpDown.Value = DefaultCanvasWidth
            m_CanvasWidthUpDown.Step = 1
            m_CanvasWidthUpDown.DecimalPlaces = 0
            Me.m_CanvasWidthUpDown.ValueChanged += AddressOf OnNumericUpDownValueChanged

            ' Canvas height editor
            m_CanvasHeightUpDown = New NNumericUpDown()
            m_CanvasHeightUpDown.Minimum = 100
            m_CanvasHeightUpDown.Maximum = 350
            m_CanvasHeightUpDown.Value = DefaultCanvasHeight
            m_CanvasHeightUpDown.Step = 1
            m_CanvasHeightUpDown.DecimalPlaces = 0
            Me.m_CanvasHeightUpDown.ValueChanged += AddressOf OnNumericUpDownValueChanged

            Dim stack As NStackPanel = New NStackPanel()
            stack.FillMode = ENStackFillMode.None
            stack.FitMode = ENStackFitMode.None
            stack.Add(NPairBox.Create("Fill:", m_FillSplitButton))
            stack.Add(NPairBox.Create("Stroke Color:", m_StrokeColorBox))
            stack.Add(NPairBox.Create("Stroke Width:", m_StrokeWidthCombo))
            stack.Add(NPairBox.Create("Canvas Width:", m_CanvasWidthUpDown))
            stack.Add(NPairBox.Create("Canvas Height:", m_CanvasHeightUpDown))

            Return New NUniSizeBoxGroup(stack)
        End Function

        Protected Overrides Function GetExampleDescription() As String
            Return "
<p>
	This example demonstrates the primitive painting capabilities of the NOV graphics.
</p>
" End Function

#End Region

#Region "Event Handlers"

        Private Sub OnCanvasPrePaint(ByVal args As NCanvasPaintEventArgs)
            Dim canvas As NCanvas = TryCast(args.TargetNode, NCanvas)
            If canvas Is Nothing Then Return

            Dim paintDelegate As PaintPrimitiveDelegate = TryCast(canvas.Tag, PaintPrimitiveDelegate)
            If paintDelegate Is Nothing Then Throw New Exception("The canvas has no assigned paint delegate.")

            args.PaintVisitor.ClearStyles()
            args.PaintVisitor.SetStroke(m_Stroke)
            args.PaintVisitor.SetFill(m_Fill)

            paintDelegate(args.PaintVisitor, canvas.Width, canvas.Height)
        End Sub
        Private Sub OnNumericUpDownValueChanged(ByVal args As NValueChangeEventArgs)
            If m_Table Is Nothing Then Return

            Dim width = m_CanvasWidthUpDown.Value
            Dim height = m_CanvasHeightUpDown.Value

            ' Resize the canvases
            Dim iterator As INIterator(Of NNode) = m_Table.GetSubtreeIterator(ENTreeTraversalOrder.DepthFirstPreOrder, New NInstanceOfSchemaFilter(NCanvas.NCanvasSchema))

            While iterator.MoveNext()
                Dim canvas = CType(iterator.Current, NCanvas)

                CType(canvas.ParentNode, NWidget).PreferredWidth = width
                canvas.PreferredHeight = height
            End While
        End Sub
        Private Sub OnFillSplitButtonSelectedValueChanged(ByVal arg As NValueChangeEventArgs)
            Dim selectedFill As NAutomaticValue(Of NFill) = arg.NewValue
            m_Fill = If(selectedFill.Automatic, Nothing, selectedFill.Value)

            InvalidateCanvases()
        End Sub
        Private Sub OnStrokeColorBoxSelectedColorChanged(ByVal arg As NValueChangeEventArgs)
            m_Stroke.Color = m_StrokeColorBox.SelectedColor

            InvalidateCanvases()
        End Sub
        Private Sub OnStrokeWidthComboSelectedIndexChanged(ByVal arg As NValueChangeEventArgs)
            m_Stroke.Width = m_StrokeWidthCombo.SelectedIndex

            InvalidateCanvases()
        End Sub

#End Region

#Region "Implementation"

        Private Sub InvalidateCanvases()
            If m_Table Is Nothing Then Return

            Dim iterator As INIterator(Of NNode) = m_Table.GetSubtreeIterator(ENTreeTraversalOrder.DepthFirstPreOrder, New NInstanceOfSchemaFilter(NCanvas.NCanvasSchema))

            While iterator.MoveNext()
                Dim canvas = CType(iterator.Current, NCanvas)
                canvas.InvalidateDisplay()
            End While
        End Sub

#End Region

#Region "Fields"

        Private m_Table As NTableFlowPanel
        Private m_CanvasWidthUpDown As NNumericUpDown
        Private m_CanvasHeightUpDown As NNumericUpDown
        Private m_FillSplitButton As NFillSplitButton
        Private m_StrokeColorBox As NColorBox
        Private m_StrokeWidthCombo As NComboBox

        Private m_Stroke As NStroke = New NStroke()
        Private m_Fill As NFill

#End Region

#Region "Schema"

        ''' <summary>
        ''' Schema associated with NPaintingPrimitivesExample.
        ''' </summary>
        Public Shared ReadOnly NPaintingPrimitivesExampleSchema As NSchema

#End Region

#Region "Static Methods"

        Private Shared Sub PaintLine(ByVal paintVisitor As NPaintVisitor, ByVal w As Double, ByVal h As Double)
            paintVisitor.PaintLine(0.2 * w, 0.1 * h, 0.9 * w, 0.8 * h)
            paintVisitor.PaintLine(0.1 * w, 0.4 * h, 0.8 * w, 0.9 * h)
        End Sub
        Private Shared Sub PaintPolyline(ByVal paintVisitor As NPaintVisitor, ByVal w As Double, ByVal h As Double)
            Dim polyline As NPolyline = New NPolyline(5)
            polyline.Add(0.1 * w, 0.1 * h)
            polyline.Add(0.4 * w, 0.2 * h)
            polyline.Add(0.2 * w, 0.5 * h)
            polyline.Add(0.3 * w, 0.8 * h)
            polyline.Add(0.9 * w, 0.9 * h)
            paintVisitor.PaintPolyline(polyline)
        End Sub
        Private Shared Sub PaintRectangle(ByVal paintVisitor As NPaintVisitor, ByVal w As Double, ByVal h As Double)
            paintVisitor.PaintRectangle(0.05 * w, 0.25 * h, 0.9 * w, 0.5 * h)
        End Sub
        Private Shared Sub PaintEllipse(ByVal paintVisitor As NPaintVisitor, ByVal w As Double, ByVal h As Double)
            paintVisitor.PaintEllipse(0.05 * w, 0.25 * h, 0.9 * w, 0.5 * h)
        End Sub
        Private Shared Sub PaintTriangle(ByVal paintVisitor As NPaintVisitor, ByVal w As Double, ByVal h As Double)
            Dim p1 As NPoint = New NPoint(0.5 * w, 0.1 * h)
            Dim p2 As NPoint = New NPoint(0.9 * w, 0.9 * h)
            Dim p3 As NPoint = New NPoint(0.1 * w, 0.8 * h)

            paintVisitor.PaintTriangle(p1, p2, p3)
        End Sub
        Private Shared Sub PaintQuadrangle(ByVal paintVisitor As NPaintVisitor, ByVal w As Double, ByVal h As Double)
            Dim p1 As NPoint = New NPoint(0.2 * w, 0.1 * h)
            Dim p2 As NPoint = New NPoint(0.6 * w, 0.1 * h)
            Dim p3 As NPoint = New NPoint(0.9 * w, 0.9 * h)
            Dim p4 As NPoint = New NPoint(0.1 * w, 0.6 * h)

            paintVisitor.PaintQuadrangle(p1, p2, p3, p4)
        End Sub
        Private Shared Sub PaintPolygon(ByVal paintVisitor As NPaintVisitor, ByVal w As Double, ByVal h As Double)
            Dim polygon As NPolygon = New NPolygon(6)
            polygon.Add(0.3 * w, 0.1 * h)
            polygon.Add(0.7 * w, 0.1 * h)
            polygon.Add(0.5 * w, 0.4 * h)
            polygon.Add(0.9 * w, 0.9 * h)
            polygon.Add(0.2 * w, 0.8 * h)
            polygon.Add(0.1 * w, 0.4 * h)

            paintVisitor.PaintPolygon(polygon, ENFillRule.EvenOdd)
        End Sub
        Private Shared Sub PaintPath(ByVal paintVisitor As NPaintVisitor, ByVal w As Double, ByVal h As Double)
            Dim path As NGraphicsPath = New NGraphicsPath()
            path.StartFigure(0.1 * w, 0.1 * h)
            path.LineTo(0.7 * w, 0.2 * h)
            path.CubicBezierTo(0.9 * w, 0.9 * h, 1 * w, 0.4 * h, 0.5 * w, 0.7 * h)
            path.LineTo(0.2 * w, 0.8 * h)
            path.CubicBezierTo(0.1 * w, 0.1 * h, 0.3 * w, 0.7 * h, 0.4 * w, 0.6 * h)
            path.CloseFigure()

            paintVisitor.PaintPath(path)
        End Sub

#End Region

#Region "Constants"

        Private Const DefaultCanvasWidth As Integer = 220
        Private Const DefaultCanvasHeight As Integer = 220

#End Region

#Region "Nested Types"

        Friend Delegate Sub PaintPrimitiveDelegate(ByVal paintVisitor As NPaintVisitor, ByVal w As Double, ByVal h As Double)

#End Region
    End Class
End Namespace

Imports Nevron.Nov.DataStructures
Imports Nevron.Nov.Dom
Imports Nevron.Nov.Graphics
Imports Nevron.Nov.Layout
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.Framework
    Public Class NRadialGradientFillExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' Default constructor.
        ''' </summary>
        Public Sub New()
        End Sub
        ''' <summary>
        ''' Static constructor.
        ''' </summary>
        Shared Sub New()
            NRadialGradientFillExampleSchema = NSchema.Create(GetType(NRadialGradientFillExample), NExampleBase.NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            ' Create a table panel to hold the canvases and the labels
            m_Table = New NTableFlowPanel()
            m_Table.HorizontalPlacement = ENHorizontalPlacement.Left
            m_Table.VerticalPlacement = ENVerticalPlacement.Top
            m_Table.Padding = New NMargins(30)
            m_Table.HorizontalSpacing = 30
            m_Table.VerticalSpacing = 30
            m_Table.MaxOrdinal = 2
            Dim texts = New String() {"Two Gradient Stops (Stretch Mapping)", "Two Gradient Stops (ZoomToFill Mapping)", "Five Gradient Stops (Stretch Mapping)", "Five Gradient Stops (ZoomToFill Mapping)", "Shifted Gradient Center (Stretch Mapping)", "Shifted Gradient Center (ZoomToFill Mapping)", "Shifted Gradient Focus (Stretch Mapping)", "Shifted Gradient Focus (ZoomToFill Mapping)"}
            Dim fills As NRadialGradientFill() = New NRadialGradientFill() {TwoGradientStops_Stretch(), TwoGradientStops_Zoom(), FiveGradientStops_Stretch(), FiveGradientStops_Zoom(), ShiftedCenter_Stretch(), ShiftedCenter_Zoom(), ShiftedFocus_Stretch(), ShiftedFocus_Zoom()}

            ' Add a canvas for each demonstrated gradient
            For i = 0 To fills.Length - 1
                Dim stack As NStackPanel = New NStackPanel()
                m_Table.Add(stack)
                stack.Direction = ENHVDirection.TopToBottom
                stack.FillMode = ENStackFillMode.First
                stack.FitMode = ENStackFitMode.First

                ' Create a widget with the proper filling
                Dim canvas As NCanvas = New NCanvas()
                canvas.PreferredSize = New NSize(defaultCanvasWidth, defaultCanvasHeight)
                canvas.Tag = fills(i)
                stack.Add(canvas)
                AddHandler canvas.PrePaint, New [Function](Of NCanvasPaintEventArgs)(AddressOf OnCanvasPrePaint)

                ' Create a label with the corresponding name
                Dim label As NLabel = New NLabel(texts(i))
                stack.Add(label)
                label.HorizontalPlacement = ENHorizontalPlacement.Center
            Next

            ' The table must be scrollable
            Dim scroll As NScrollContent = New NScrollContent()
            scroll.Content = m_Table
            Return scroll
        End Function

        Protected Overrides Function CreateExampleControls() As NWidget
            ' Canvas width editor
            m_CanvasWidthUpDown = New NNumericUpDown()
            m_CanvasWidthUpDown.Minimum = 100
            m_CanvasWidthUpDown.Maximum = 350
            m_CanvasWidthUpDown.Value = defaultCanvasWidth
            m_CanvasWidthUpDown.Step = 1
            m_CanvasWidthUpDown.DecimalPlaces = 0
            AddHandler m_CanvasWidthUpDown.ValueChanged, New [Function](Of NValueChangeEventArgs)(AddressOf OnNumericUpDownValueChanged)

            ' Canvas height editor
            m_CanvasHeightUpDown = New NNumericUpDown()
            m_CanvasHeightUpDown.Minimum = 100
            m_CanvasHeightUpDown.Maximum = 350
            m_CanvasHeightUpDown.Value = defaultCanvasHeight
            m_CanvasHeightUpDown.Step = 1
            m_CanvasHeightUpDown.DecimalPlaces = 0
            AddHandler m_CanvasHeightUpDown.ValueChanged, New [Function](Of NValueChangeEventArgs)(AddressOf OnNumericUpDownValueChanged)
            Dim stack As NStackPanel = New NStackPanel()
            stack.FillMode = ENStackFillMode.None
            stack.FitMode = ENStackFitMode.None
            stack.Add(NPairBox.Create("Canvas Width:", m_CanvasWidthUpDown))
            stack.Add(NPairBox.Create("Canvas Height:", m_CanvasHeightUpDown))
            Return New NUniSizeBoxGroup(stack)
        End Function

        Protected Overrides Function GetExampleDescription() As String
            Return "
<p>
	This example demonstrates NOV's radial gradient fillings.
</p>
"
        End Function

#End Region

#Region "Event Handlers"

        Private Sub OnCanvasPrePaint(ByVal args As NCanvasPaintEventArgs)
            Dim canvas As NCanvas = TryCast(args.TargetNode, NCanvas)
            If canvas Is Nothing Then Return
            Dim fill = CType(canvas.Tag, NFill)
            args.PaintVisitor.ClearStyles()
            args.PaintVisitor.SetFill(fill)
            args.PaintVisitor.PaintRectangle(0, 0, canvas.Width, canvas.Height)
        End Sub

        Private Sub OnNumericUpDownValueChanged(ByVal args As NValueChangeEventArgs)
            If m_Table Is Nothing Then Return
            Dim width = m_CanvasWidthUpDown.Value
            Dim height = m_CanvasHeightUpDown.Value

            ' Resize the canvases
            Dim iterator As INIterator(Of NNode) = m_Table.GetSubtreeIterator(ENTreeTraversalOrder.DepthFirstPreOrder, New NInstanceOfSchemaFilter(NCanvas.NCanvasSchema))

            While iterator.MoveNext()
                Dim canvas = CType(iterator.Current, NCanvas)
                CType(canvas.ParentNode, NWidget).PreferredWidth = width
                canvas.PreferredHeight = height
            End While
        End Sub

#End Region

#Region "Implementation"

        Private Function TwoGradientStops_Stretch() As NRadialGradientFill
            Dim rgf As NRadialGradientFill = New NRadialGradientFill()
            rgf.GradientStops.Add(New NGradientStop(0, NColor.AliceBlue))
            rgf.GradientStops.Add(New NGradientStop(1, NColor.DarkSlateBlue))
            Return rgf
        End Function

        Private Function TwoGradientStops_Zoom() As NRadialGradientFill
            Dim rgf As NRadialGradientFill = New NRadialGradientFill()
            rgf.GradientStops.Add(New NGradientStop(0, NColor.AliceBlue))
            rgf.GradientStops.Add(New NGradientStop(1, NColor.DarkSlateBlue))
            ' rgf.TextureMapping = new NFitAndAlignTextureMapping();
            Return rgf
        End Function

        Private Function FiveGradientStops_Stretch() As NRadialGradientFill
            Dim rgf As NRadialGradientFill = New NRadialGradientFill()
            rgf.GradientStops.Add(New NGradientStop(0.00F, NColor.Red))
            rgf.GradientStops.Add(New NGradientStop(0.25F, NColor.Yellow))
            rgf.GradientStops.Add(New NGradientStop(0.50F, NColor.LimeGreen))
            rgf.GradientStops.Add(New NGradientStop(0.75F, NColor.MediumBlue))
            rgf.GradientStops.Add(New NGradientStop(1.00F, NColor.DarkViolet))
            Return rgf
        End Function

        Private Function FiveGradientStops_Zoom() As NRadialGradientFill
            Dim rgf As NRadialGradientFill = New NRadialGradientFill()
            rgf.GradientStops.Add(New NGradientStop(0.00F, NColor.Red))
            rgf.GradientStops.Add(New NGradientStop(0.25F, NColor.Yellow))
            rgf.GradientStops.Add(New NGradientStop(0.50F, NColor.LimeGreen))
            rgf.GradientStops.Add(New NGradientStop(0.75F, NColor.MediumBlue))
            rgf.GradientStops.Add(New NGradientStop(1.00F, NColor.DarkViolet))
            ' FIX: Gradient Transform
            ' rgf.MappingMode = ENGradientMappingMode.ZoomToFill;
            Return rgf
        End Function

        Private Function ShiftedCenter_Stretch() As NRadialGradientFill
            Dim rgf As NRadialGradientFill = New NRadialGradientFill()
            rgf.GradientStops.Add(New NGradientStop(0.0F, NColor.Crimson))
            rgf.GradientStops.Add(New NGradientStop(0.5F, NColor.Goldenrod))
            rgf.GradientStops.Add(New NGradientStop(0.6F, NColor.Indigo))
            rgf.GradientStops.Add(New NGradientStop(1.0F, NColor.Thistle))

            ' The center coordinates are specified with values between 0 and 1
            ' FIX: Radial Gradient
            ' rgf.CenterFactorX = 0.0f;
            ' rgf.CenterFactorY = 1.0f;

            Return rgf
        End Function

        Private Function ShiftedCenter_Zoom() As NRadialGradientFill
            Dim rgf As NRadialGradientFill = New NRadialGradientFill()
            rgf.GradientStops.Add(New NGradientStop(0.0F, NColor.Crimson))
            rgf.GradientStops.Add(New NGradientStop(0.5F, NColor.Goldenrod))
            rgf.GradientStops.Add(New NGradientStop(0.6F, NColor.Indigo))
            rgf.GradientStops.Add(New NGradientStop(1.0F, NColor.Thistle))

            ' FIX: Gradient Transform
            ' rgf.MappingMode = ENGradientMappingMode.ZoomToFill;

            ' The center coordinates are specified with values between 0 and 1
            ' FIX: Radial Gradient
            ' rgf.CenterFactorX = 0.0f;
            ' rgf.CenterFactorY = 1.0f;

            Return rgf
        End Function

        Private Function ShiftedFocus_Stretch() As NRadialGradientFill
            Dim rgf As NRadialGradientFill = New NRadialGradientFill()
            rgf.GradientStops.Add(New NGradientStop(0.0F, NColor.White))
            rgf.GradientStops.Add(New NGradientStop(0.4F, NColor.Red))
            rgf.GradientStops.Add(New NGradientStop(1.0F, NColor.Black))
            rgf.FocusFactorX = -0.6F
            rgf.FocusFactorY = -0.6F
            Return rgf
        End Function

        Private Function ShiftedFocus_Zoom() As NRadialGradientFill
            Dim rgf As NRadialGradientFill = New NRadialGradientFill()
            rgf.GradientStops.Add(New NGradientStop(0.0F, NColor.White))
            rgf.GradientStops.Add(New NGradientStop(0.4F, NColor.Red))
            rgf.GradientStops.Add(New NGradientStop(1.0F, NColor.Black))
            rgf.FocusFactorX = -0.6F
            rgf.FocusFactorY = -0.6F
            ' FIX: Radial Gradient
            ' rgf.MappingMode = ENGradientMappingMode.ZoomToFill;
            Return rgf
        End Function

#End Region

#Region "Fields"

        Private m_Table As NTableFlowPanel
        Private m_CanvasWidthUpDown As NNumericUpDown
        Private m_CanvasHeightUpDown As NNumericUpDown

#End Region

#Region "Constants"

        Const defaultCanvasWidth As Integer = 220
        Const defaultCanvasHeight As Integer = 136

#End Region

#Region "Schema"

        ''' <summary>
        ''' Schema associated with NRadialGradientFillExample.
        ''' </summary>
        Public Shared ReadOnly NRadialGradientFillExampleSchema As NSchema

#End Region
    End Class
End Namespace

Imports Nevron.Nov.Dom
Imports Nevron.Nov.Graphics
Imports Nevron.Nov.Layout
Imports Nevron.Nov.UI
Imports System.Runtime.InteropServices

Namespace Nevron.Nov.Examples.Framework
    Public Class NCustomTextureMappingExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' Default constructor.
        ''' </summary>
        Public Sub New()
        End Sub
        ''' <summary>
        ''' Static constructor.
        ''' </summary>
        Shared Sub New()
            NCustomTextureMappingExampleSchema = NSchema.Create(GetType(NCustomTextureMappingExample), NExampleBase.NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            m_PathAngle = 0
            m_PathPositionX = 200
            m_PathPositionY = 100
            m_Stroke = New NStroke(1, NColor.Red)

            ' create an image fill using an embedded image
            m_ImageFill = New NImageFill(NResources.Image_Artistic_Plane_png)

            ' create a custom texture mapping and assign it to the image fill
            m_MyTextureMapping = New MyTextureMapping()
            m_MyTextureMapping.TextureAngle = 45
            m_MyTextureMapping.PinPoint = New NPoint(m_PathPositionX, m_PathPositionY)
            m_ImageFill.TextureMapping = m_MyTextureMapping
            m_Canvas = New NCanvas()
            m_Canvas.PreferredSize = New NSize(800, 600)
            m_Canvas.BackgroundFill = New NColorFill(New NColor(220, 220, 200))
            m_Canvas.HorizontalPlacement = ENHorizontalPlacement.Center
            m_Canvas.VerticalPlacement = ENVerticalPlacement.Center
            AddHandler m_Canvas.PrePaint, New [Function](Of NCanvasPaintEventArgs)(AddressOf OnCanvasPrePaint)
            Dim scroll As NScrollContent = New NScrollContent()
            scroll.Content = m_Canvas
            scroll.NoScrollHAlign = ENNoScrollHAlign.Center
            scroll.NoScrollVAlign = ENNoScrollVAlign.Center
            Return scroll
        End Function

        Protected Overrides Function CreateExampleControls() As NWidget
            ' path rotation angle editor
            m_PathAngleSpin = New NNumericUpDown()
            m_PathAngleSpin.Minimum = 0
            m_PathAngleSpin.Maximum = 360
            m_PathAngleSpin.Value = m_PathAngle
            m_PathAngleSpin.Step = 1
            m_PathAngleSpin.DecimalPlaces = 1
            AddHandler m_PathAngleSpin.ValueChanged, New [Function](Of NValueChangeEventArgs)(AddressOf OnNumericUpDownValueChanged)

            ' path rotation angle editor
            m_TextureAngleSpin = New NNumericUpDown()
            m_TextureAngleSpin.Minimum = 0
            m_TextureAngleSpin.Maximum = 360
            m_TextureAngleSpin.Value = m_MyTextureMapping.TextureAngle
            m_TextureAngleSpin.Step = 1
            m_TextureAngleSpin.DecimalPlaces = 1
            AddHandler m_TextureAngleSpin.ValueChanged, New [Function](Of NValueChangeEventArgs)(AddressOf OnNumericUpDownValueChanged)

            ' X position editor
            m_XPositionSpin = New NNumericUpDown()
            m_XPositionSpin.Minimum = 0
            m_XPositionSpin.Maximum = 800
            m_XPositionSpin.Value = m_PathPositionX
            m_XPositionSpin.Step = 1
            m_XPositionSpin.DecimalPlaces = 1
            AddHandler m_XPositionSpin.ValueChanged, New [Function](Of NValueChangeEventArgs)(AddressOf OnNumericUpDownValueChanged)

            ' Y position editor
            m_YPositionSpin = New NNumericUpDown()
            m_YPositionSpin.Minimum = 0
            m_YPositionSpin.Maximum = 600
            m_YPositionSpin.Value = m_PathPositionY
            m_YPositionSpin.Step = 1
            m_YPositionSpin.DecimalPlaces = 1
            AddHandler m_YPositionSpin.ValueChanged, New [Function](Of NValueChangeEventArgs)(AddressOf OnNumericUpDownValueChanged)
            Dim stack As NStackPanel = New NStackPanel()
            stack.FillMode = ENStackFillMode.None
            stack.FitMode = ENStackFitMode.None
            stack.Add(NPairBox.Create("Path Angle (degrees):", m_PathAngleSpin))
            stack.Add(NPairBox.Create("Texture Angle (degrees):", m_TextureAngleSpin))
            stack.Add(NPairBox.Create("X Position:", m_XPositionSpin))
            stack.Add(NPairBox.Create("Y Position:", m_YPositionSpin))
            Return New NUniSizeBoxGroup(stack)
        End Function

        Protected Overrides Function GetExampleDescription() As String
            Return "
<p>
	In cases when the built-in texture mappings do not fit your requirements you can implement and use your own texture mapping types.
	The custom texture mapping presented in this example demonstrates how the texture can be rotated independently of the textured shape.
	Use the controls to the right to set the rotation angles of the shape and the texture.
</p>
"
        End Function

#End Region

#Region "Event Handlers"

        Private Sub OnCanvasPrePaint(ByVal args As NCanvasPaintEventArgs)
            Dim canvas As NCanvas = TryCast(args.TargetNode, NCanvas)
            If canvas Is Nothing Then Return

            ' Create a transform matrix for the graphics path
            Dim matrix = NMatrix.CreateRotationMatrix(m_PathAngle * NAngle.Degree2Rad, NPoint.Zero)
            matrix.Translate(m_PathPositionX, m_PathPositionY)

            ' Create a graphics path containing a rectangle and transform it
            Dim path As NGraphicsPath = New NGraphicsPath()
            path.AddRectangle(0, 0, RectWidth, RectHeight)
            path.Transform(matrix)

            ' Paint the graphics path
            Dim pv = args.PaintVisitor
            pv.SetStroke(m_Stroke)
            pv.SetFill(m_ImageFill)
            pv.PaintPath(path)

            ' Paint a border around the canvas
            pv.ClearFill()
            pv.SetStroke(NColor.Black, 1)
            pv.PaintRectangle(0, 0, canvas.Width, canvas.Height)
        End Sub

        Private Sub OnNumericUpDownValueChanged(ByVal args As NValueChangeEventArgs)
            m_PathAngle = m_PathAngleSpin.Value
            m_PathPositionX = m_XPositionSpin.Value
            m_PathPositionY = m_YPositionSpin.Value
            m_MyTextureMapping.PinPoint = New NPoint(m_PathPositionX, m_PathPositionY)
            m_MyTextureMapping.TextureAngle = m_TextureAngleSpin.Value
            m_Canvas.InvalidateDisplay()
        End Sub

#End Region

#Region "Constants"

        Friend Const RectWidth As Double = 300
        Friend Const RectHeight As Double = 240

#End Region

#Region "Fields"

        Private m_Canvas As NCanvas
        Private m_Stroke As NStroke
        Private m_ImageFill As NImageFill
        Private m_MyTextureMapping As MyTextureMapping
        Private m_TextureAngleSpin As NNumericUpDown
        Private m_PathAngleSpin As NNumericUpDown
        Private m_XPositionSpin As NNumericUpDown
        Private m_YPositionSpin As NNumericUpDown
        Private m_PathAngle As Double
        Private m_PathPositionX As Double
        Private m_PathPositionY As Double

#End Region

#Region "Schema"

        Public Shared ReadOnly NCustomTextureMappingExampleSchema As NSchema

#End Region
    End Class

    Public Class MyTextureMapping
        Inherits NTextureMapping
#Region "Constructors"

        ''' <summary>
        ''' Default constructor
        ''' </summary>
        Public Sub New()
        End Sub
        ''' <summary>
        ''' Static constructor
        ''' </summary>
        Shared Sub New()
            MyTextureMappingSchema = NSchema.Create(GetType(MyTextureMapping), NCustomTextureMapping.NCustomTextureMappingSchema)
            TextureAngleProperty = MyTextureMappingSchema.AddSlot("TextureAngle", NDomType.Double, 0.0R)
            PinPointProperty = MyTextureMappingSchema.AddSlot("PinPoint", NDomType.NPoint, NPoint.Zero)
        End Sub

#End Region

#Region "Properties"

        ''' <summary>
        ''' The texture angle (in degrees)
        ''' </summary>
        Public Property TextureAngle As Double
            Get
                Return MyBase.GetValue(TextureAngleProperty)
            End Get
            Set(ByVal value As Double)
                MyBase.SetValue(TextureAngleProperty, value)
            End Set
        End Property
        ''' <summary>
        ''' The point around which the texture is rotated
        ''' </summary>
        Public Property PinPoint As NPoint
            Get
                Return MyBase.GetValue(PinPointProperty)
            End Get
            Set(ByVal value As NPoint)
                MyBase.SetValue(PinPointProperty, value)
            End Set
        End Property

#End Region

#Region "Protected Overrides from NCustomTextureMapping"

        Public Overrides Sub GetTextureMappingInfo(<Out> ByRef tileMode As ENTileMode, <Out> ByRef textureCalibrator As NTextureCalibrator)
            tileMode = ENTileMode.Tile
            textureCalibrator = New MyTextureCalibrator(Me)
        End Sub

#End Region

#Region "Schema"

        ''' <summary>
        ''' Schema associated with MyTextureMapping
        ''' </summary>
        Public Shared ReadOnly MyTextureMappingSchema As NSchema
        ''' <summary>
        ''' Reference to the TextureAngle property
        ''' </summary>
        Public Shared ReadOnly TextureAngleProperty As NProperty
        ''' <summary>
        ''' Reference to the PinPoint property
        ''' </summary>
        Public Shared ReadOnly PinPointProperty As NProperty

#End Region

        Friend Class MyTextureCalibrator
            Inherits NTextureCalibrator

            Public Sub New(ByVal textureMapping As MyTextureMapping)
                m_TextureMapping = textureMapping
            End Sub

            Public Overrides Function Calibrate(ByVal visitor As NPaintVisitor, ByVal imgWidth As Double, ByVal imgHeight As Double, ByVal targetRect As NRectangle) As NMatrix
                ' Initialize the image transform
                Dim matrix = NMatrix.Identity

                ' Scale the image so that it fits 2 times in width and 3 times in height
                matrix.Scale(NCustomTextureMappingExample.RectWidth / (2.0 * imgWidth), NCustomTextureMappingExample.RectHeight / (3.0 * imgHeight))

                ' Rotate the image to the specified angle
                matrix.Rotate(m_TextureMapping.TextureAngle * NAngle.Degree2Rad)

                ' Translate the image to the specfied pin point
                matrix.Translate(m_TextureMapping.PinPoint.X, m_TextureMapping.PinPoint.Y)
                Return matrix
            End Function

            Public Overrides Function DeepClone() As Object
                Return New MyTextureCalibrator(m_TextureMapping)
            End Function

            Private m_TextureMapping As MyTextureMapping
        End Class
    End Class
End Namespace

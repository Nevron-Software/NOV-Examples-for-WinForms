Imports Nevron.Nov.Dom
Imports Nevron.Nov.Graphics
Imports Nevron.Nov.Layout
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.Framework
    ''' <summary>
    ''' The example demonstrates how to paint text at location
    ''' </summary>
    Public Class NMeasureTextExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' Default constructor.
        ''' </summary>
        Public Sub New()
        End Sub
        ''' <summary>
        ''' Static constructor.
        ''' </summary>
        Shared Sub New()
            NMeasureTextExampleSchema = NSchema.Create(GetType(NMeasureTextExample), NExampleBase.NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            ' Create a table panel to hold the canvases and the labels
            Dim stack As NStackPanel = New NStackPanel()
            stack.FillMode = ENStackFillMode.Last
            stack.FitMode = ENStackFitMode.Last
            m_Canvas = New NCanvas()
            stack.Add(m_Canvas)
            AddHandler m_Canvas.PrePaint, New [Function](Of NCanvasPaintEventArgs)(AddressOf OnCanvasPrePaint)
            m_Canvas.BackgroundFill = New NColorFill(NColor.White)
            Return stack
        End Function

        Protected Overrides Function CreateExampleControls() As NWidget
            m_TextBox = New NTextBox()
            m_TextBox.Multiline = True
            m_TextBox.AcceptsEnter = True
            m_TextBox.MinHeight = 200
            m_TextBox.Text = "Type some text to measure"
            AddHandler m_TextBox.TextChanged, New [Function](Of NValueChangeEventArgs)(AddressOf OnTextBoxTextChanged)
            Dim stack As NStackPanel = New NStackPanel()
            stack.Add(New NLabel("Text:"))
            stack.Add(m_TextBox)
            Return stack
        End Function

        Protected Overrides Function GetExampleDescription() As String
            Return "
<p>
The example demonstrates how to measure text. Type some text in the text box on the right. The blue rectangle shows the measured bounds. 
</p>
"
        End Function

#End Region

#Region "Event Handlers"

        ''' <summary>
        ''' 
        ''' </summary>
        ''' <paramname="args"></param>
        Private Sub OnCanvasPrePaint(ByVal args As NCanvasPaintEventArgs)
            Dim canvas As NCanvas = TryCast(args.TargetNode, NCanvas)
            If canvas Is Nothing Then Return
            Dim paintVisitor = args.PaintVisitor
            Dim contentEge As NRectangle = canvas.GetContentEdge()

            ' create the settings
            Dim settings As NPaintTextRectSettings = New NPaintTextRectSettings()
            settings.SingleLine = False
            settings.WrapMode = ENTextWrapMode.WordWrap
            settings.HorzAlign = ENTextHorzAlign.Left
            settings.VertAlign = ENTextVertAlign.Top

            ' create the text
            Dim text = m_TextBox.Text

            ' calculate the text bounds the text bounds
            Dim resolution As Double = canvas.GetResolution()
            Dim font As NFont = New NFont(NFontDescriptor.DefaultSansFamilyName, 10, ENFontStyle.Regular)
            Dim textSize As NSize = font.MeasureString(text.ToCharArray(), resolution, contentEge.Width, settings)
            Dim center = contentEge.Center
            Dim textBounds As NRectangle = New NRectangle(center.X - textSize.Width / 2.0, center.Y - textSize.Height / 2.0, textSize.Width, textSize.Height)

            ' paint the bounding box
            paintVisitor.ClearStyles()
            paintVisitor.SetFill(NColor.LightBlue)
            paintVisitor.PaintRectangle(textBounds)

            ' init font and fill
            paintVisitor.SetFill(NColor.Black)
            paintVisitor.SetFont(font)

            ' paint the text
            paintVisitor.PaintString(textBounds, text.ToCharArray(), settings)
        End Sub

        Private Sub OnTextBoxTextChanged(ByVal arg As NValueChangeEventArgs)
            m_Canvas.InvalidateDisplay()
        End Sub

#End Region

#Region "Fields"

        Private m_Canvas As NCanvas
        Private m_TextBox As NTextBox

#End Region

#Region "Schema"

        ''' <summary>
        ''' Schema associated with NMeasureTextExample.
        ''' </summary>
        Public Shared ReadOnly NMeasureTextExampleSchema As NSchema

#End Region
    End Class
End Namespace

Imports Nevron.Nov.Dom
Imports Nevron.Nov.Graphics
Imports Nevron.Nov.Layout
Imports Nevron.Nov.UI
Imports Nevron.Nov.DataStructures

Namespace Nevron.Nov.Examples.Framework
    Public Class NAdvancedGradientFillExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' Default constructor.
        ''' </summary>
        Public Sub New()
        End Sub
        ''' <summary>
        ''' Static constructor.
        ''' </summary>
        Shared Sub New()
            NAdvancedGradientFillExampleSchema = NSchema.Create(GetType(NAdvancedGradientFillExample), NExampleBase.NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            ' Create a table panel to hold the canvases and the labels
            m_Table = New NTableFlowPanel()
            m_Table.HorizontalPlacement = ENHorizontalPlacement.Left
            m_Table.VerticalPlacement = ENVerticalPlacement.Top
            m_Table.Padding = New NMargins(30)
            m_Table.HorizontalSpacing = 30
            m_Table.VerticalSpacing = 30
            m_Table.MaxOrdinal = 3
            Dim texts = New String() {"Azure", "Flow", "Bulb", "Eclipse", "The Eye", "Medusa", "Kaleidoscope", "Reactor", "Green"}

            ' Create the advanced gradients
            Dim fills = New NAdvancedGradientFill() {AzureLight, Flow, Bulb, Eclipse, TheEye, Medusa, Kaleidoscope, Reactor, Green}

            ' Add a canvas for each demonstrated gradient
            For i = 0 To fills.Length - 1
                Dim stack As NStackPanel = New NStackPanel()
                m_Table.Add(stack)
                stack.Direction = ENHVDirection.TopToBottom
                stack.FillMode = ENStackFillMode.First
                stack.FitMode = ENStackFitMode.First

                ' Create a widget with the proper filling
                Dim canvas As NCanvas = New NCanvas()
                canvas.PreferredSize = New NSize(defaultCanvasWidth, defaultCanvasHeight)
                canvas.Tag = fills(i)
                stack.Add(canvas)
                AddHandler canvas.PrePaint, New [Function](Of NCanvasPaintEventArgs)(AddressOf OnCanvasPrePaint)

                ' Create a label with the corresponding name
                Dim label As NLabel = New NLabel(texts(i))
                stack.Add(label)
                label.HorizontalPlacement = ENHorizontalPlacement.Center
            Next

            ' The table must be scrollable
            Dim scroll As NScrollContent = New NScrollContent()
            scroll.Content = m_Table
            Return scroll
        End Function

        Protected Overrides Function CreateExampleControls() As NWidget
            ' Canvas width editor
            m_CanvasWidthUpDown = New NNumericUpDown()
            m_CanvasWidthUpDown.Minimum = 100
            m_CanvasWidthUpDown.Maximum = 350
            m_CanvasWidthUpDown.Value = defaultCanvasWidth
            m_CanvasWidthUpDown.Step = 1
            m_CanvasWidthUpDown.DecimalPlaces = 0
            AddHandler m_CanvasWidthUpDown.ValueChanged, New [Function](Of NValueChangeEventArgs)(AddressOf OnNumericUpDownValueChanged)

            ' Canvas height editor
            m_CanvasHeightUpDown = New NNumericUpDown()
            m_CanvasHeightUpDown.Minimum = 100
            m_CanvasHeightUpDown.Maximum = 350
            m_CanvasHeightUpDown.Value = defaultCanvasHeight
            m_CanvasHeightUpDown.Step = 1
            m_CanvasHeightUpDown.DecimalPlaces = 0
            AddHandler m_CanvasHeightUpDown.ValueChanged, New [Function](Of NValueChangeEventArgs)(AddressOf OnNumericUpDownValueChanged)
            Dim stack As NStackPanel = New NStackPanel()
            stack.FillMode = ENStackFillMode.None
            stack.FitMode = ENStackFitMode.None
            stack.Add(NPairBox.Create("Canvas Width:", m_CanvasWidthUpDown))
            stack.Add(NPairBox.Create("Canvas Height:", m_CanvasHeightUpDown))
            Return New NUniSizeBoxGroup(stack)
        End Function

        Protected Overrides Function GetExampleDescription() As String
            Return "
<p>
	This example demonstrates how to create and configure advanced gradient fills.
</p>
"
        End Function

#End Region

#Region "Event Handlers"

        Private Sub OnCanvasPrePaint(ByVal args As NCanvasPaintEventArgs)
            Dim canvas As NCanvas = TryCast(args.TargetNode, NCanvas)
            If canvas Is Nothing Then Return
            Dim fill = CType(canvas.Tag, NFill)
            args.PaintVisitor.ClearStyles()
            args.PaintVisitor.SetFill(fill)
            args.PaintVisitor.PaintRectangle(0, 0, canvas.Width, canvas.Height)
        End Sub

        Private Sub OnNumericUpDownValueChanged(ByVal args As NValueChangeEventArgs)
            If m_Table Is Nothing Then Return
            Dim width = m_CanvasWidthUpDown.Value
            Dim height = m_CanvasHeightUpDown.Value

            ' Resize the canvases
            Dim iterator As INIterator(Of NNode) = m_Table.GetSubtreeIterator(ENTreeTraversalOrder.DepthFirstPreOrder, New NInstanceOfSchemaFilter(NCanvas.NCanvasSchema))

            While iterator.MoveNext()
                Dim canvas = CType(iterator.Current, NCanvas)
                CType(canvas.ParentNode, NWidget).PreferredWidth = width
                canvas.PreferredHeight = height
            End While
        End Sub

#End Region

#Region "Implementation"

        Public ReadOnly Property Eclipse As NAdvancedGradientFill
            Get
                Dim ag As NAdvancedGradientFill = New NAdvancedGradientFill()
                ag.BackgroundColor = NColor.MidnightBlue
                ag.Points.Add(New NAdvancedGradientPoint(NColor.Crimson, NAngle.Zero, 0.5F, 0.5F, 0.5F, ENAdvancedGradientPointShape.Circle))
                ag.Points.Add(New NAdvancedGradientPoint(NColor.White, NAngle.Zero, 0.1F, 0.2F, 0.7F, ENAdvancedGradientPointShape.Circle))
                ag.Points.Add(New NAdvancedGradientPoint(NColor.DarkOrchid, NAngle.Zero, 0.9F, 0.9F, 1.0F, ENAdvancedGradientPointShape.Circle))
                Return ag
            End Get
        End Property

        Public ReadOnly Property Green As NAdvancedGradientFill
            Get
                Dim ag As NAdvancedGradientFill = New NAdvancedGradientFill()
                ag.BackgroundColor = NColor.Black
                ag.Points.Add(New NAdvancedGradientPoint(NColor.Green, NAngle.Zero, 0.5F, 0.5F, 0.2F, ENAdvancedGradientPointShape.Line))
                ag.Points.Add(New NAdvancedGradientPoint(NColor.Green, New NAngle(90, NUnit.Degree), 0.5F, 0.5F, 0.2F, ENAdvancedGradientPointShape.Line))
                ag.Points.Add(New NAdvancedGradientPoint(NColor.White, NAngle.Zero, 0.5F, 0.5F, 0.5F, ENAdvancedGradientPointShape.Circle))
                Return ag
            End Get
        End Property

        Public ReadOnly Property Bulb As NAdvancedGradientFill
            Get
                Dim ag As NAdvancedGradientFill = New NAdvancedGradientFill()
                ag.BackgroundColor = NColor.Purple
                ag.Points.Add(New NAdvancedGradientPoint(NColor.Khaki, NAngle.Zero, 0.65F, 0.35F, 0.4F, ENAdvancedGradientPointShape.Circle))
                ag.Points.Add(New NAdvancedGradientPoint(NColor.White, New NAngle(135, NUnit.Degree), 0.5F, 0.5F, 0.7F, ENAdvancedGradientPointShape.Line))
                Return ag
            End Get
        End Property

        Public ReadOnly Property Kaleidoscope As NAdvancedGradientFill
            Get
                Dim ag As NAdvancedGradientFill = New NAdvancedGradientFill()
                ag.BackgroundColor = NColor.DarkSlateBlue
                ag.Points.Add(New NAdvancedGradientPoint(NColor.DarkSlateBlue, NAngle.Zero, 0.5F, 0.5F, 0.3F, ENAdvancedGradientPointShape.Rectangle))
                ag.Points.Add(New NAdvancedGradientPoint(NColor.Cornsilk, New NAngle(45, NUnit.Degree), 0.5F, 0.5F, 0.4F, ENAdvancedGradientPointShape.Rectangle))
                ag.Points.Add(New NAdvancedGradientPoint(NColor.Thistle, NAngle.Zero, 0.1F, 0.1F, 0.3F, ENAdvancedGradientPointShape.Circle))
                ag.Points.Add(New NAdvancedGradientPoint(NColor.Thistle, NAngle.Zero, 0.9F, 0.1F, 0.3F, ENAdvancedGradientPointShape.Circle))
                ag.Points.Add(New NAdvancedGradientPoint(NColor.Thistle, NAngle.Zero, 0.9F, 0.9F, 0.3F, ENAdvancedGradientPointShape.Circle))
                ag.Points.Add(New NAdvancedGradientPoint(NColor.Thistle, NAngle.Zero, 0.1F, 0.9F, 0.3F, ENAdvancedGradientPointShape.Circle))
                Return ag
            End Get
        End Property

        Public ReadOnly Property TheEye As NAdvancedGradientFill
            Get
                Dim ag As NAdvancedGradientFill = New NAdvancedGradientFill()
                ag.BackgroundColor = New NColor(64, 0, 128)
                ag.Points.Add(New NAdvancedGradientPoint(New NColor(128, 128, 255), NAngle.Zero, 0.5F, 0.5F, 0.51F, ENAdvancedGradientPointShape.Circle))
                ag.Points.Add(New NAdvancedGradientPoint(NColor.White, NAngle.Zero, 0.5F, 0.5F, 0.49F, ENAdvancedGradientPointShape.Line))
                ag.Points.Add(New NAdvancedGradientPoint(New NColor(0, 0, 64), NAngle.Zero, 0.5F, 0.5F, 0.23F, ENAdvancedGradientPointShape.Circle))
                ag.Points.Add(New NAdvancedGradientPoint(NColor.Black, NAngle.Zero, 0.5F, 0.5F, 0.13F, ENAdvancedGradientPointShape.Circle))
                Return ag
            End Get
        End Property

        Public ReadOnly Property Medusa As NAdvancedGradientFill
            Get
                Dim ag As NAdvancedGradientFill = New NAdvancedGradientFill()
                ag.BackgroundColor = New NColor(0, 0, 64)
                ag.Points.Add(New NAdvancedGradientPoint(New NColor(0, 128, 255), NAngle.Zero, 0.12F, 0.57F, 0.60F, ENAdvancedGradientPointShape.Circle))
                ag.Points.Add(New NAdvancedGradientPoint(NColor.White, NAngle.Zero, 0.29F, 0.29F, 0.35F, ENAdvancedGradientPointShape.Circle))
                ag.Points.Add(New NAdvancedGradientPoint(New NColor(0, 128, 255), NAngle.Zero, 0.57F, 0.12F, 0.60F, ENAdvancedGradientPointShape.Circle))
                ag.Points.Add(New NAdvancedGradientPoint(New NColor(128, 0, 255), NAngle.Zero, 0.60F, 0.60F, 0.37F, ENAdvancedGradientPointShape.Circle))
                ag.Points.Add(New NAdvancedGradientPoint(NColor.White, NAngle.Zero, 0.84F, 0.84F, 0.50F, ENAdvancedGradientPointShape.Circle))
                Return ag
            End Get
        End Property

        Public ReadOnly Property Reactor As NAdvancedGradientFill
            Get
                Dim ag As NAdvancedGradientFill = New NAdvancedGradientFill()
                ag.BackgroundColor = NColor.Black
                ag.Points.Add(New NAdvancedGradientPoint(New NColor(255, 128, 255), NAngle.Zero, 0.50F, 0.78F, 0.35F, ENAdvancedGradientPointShape.Line))
                ag.Points.Add(New NAdvancedGradientPoint(New NColor(128, 128, 255), NAngle.Zero, 0.50F, 0.22F, 0.35F, ENAdvancedGradientPointShape.Line))
                ag.Points.Add(New NAdvancedGradientPoint(NColor.White, NAngle.Zero, 0.50F, 0.50F, 0.52F, ENAdvancedGradientPointShape.Circle))
                Return ag
            End Get
        End Property

        Public ReadOnly Property Flow As NAdvancedGradientFill
            Get
                Dim ag As NAdvancedGradientFill = New NAdvancedGradientFill()
                ag.BackgroundColor = New NColor(64, 0, 128)
                ag.Points.Add(New NAdvancedGradientPoint(New NColor(255, 255, 128), New NAngle(50, NUnit.Degree), 0.38F, 0.17F, 0.48F, ENAdvancedGradientPointShape.Line))
                ag.Points.Add(New NAdvancedGradientPoint(New NColor(255, 0, 128), NAngle.Zero, 0.58F, 0.74F, 1, ENAdvancedGradientPointShape.Line))
                Return ag
            End Get
        End Property

        Public ReadOnly Property AzureLight As NAdvancedGradientFill
            Get
                Dim ag As NAdvancedGradientFill = New NAdvancedGradientFill()
                ag.BackgroundColor = NColor.White
                ag.Points.Add(New NAdvancedGradientPoint(New NColor(235, 168, 255), NAngle.Zero, 0.87F, 0.29F, 0.92F, ENAdvancedGradientPointShape.Circle))
                ag.Points.Add(New NAdvancedGradientPoint(New NColor(64, 199, 255), NAngle.Zero, 0.53F, 0.82F, 0.81F, ENAdvancedGradientPointShape.Circle))
                ag.Points.Add(New NAdvancedGradientPoint(NColor.White, NAngle.Zero, 0.16F, 0.17F, 1, ENAdvancedGradientPointShape.Circle))
                Return ag
            End Get
        End Property

#End Region

#Region "Fields"

        Private m_Table As NTableFlowPanel
        Private m_CanvasWidthUpDown As NNumericUpDown
        Private m_CanvasHeightUpDown As NNumericUpDown

#End Region

#Region "Constants"

        Const defaultCanvasWidth As Integer = 180
        Const defaultCanvasHeight As Integer = 180

#End Region

#Region "Schema"

        ''' <summary>
        ''' Schema associated with NAdvancedGradientFillExample.
        ''' </summary>
        Public Shared ReadOnly NAdvancedGradientFillExampleSchema As NSchema

#End Region
    End Class
End Namespace

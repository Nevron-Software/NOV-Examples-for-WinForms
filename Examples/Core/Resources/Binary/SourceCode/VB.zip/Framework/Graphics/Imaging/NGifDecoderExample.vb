Imports Nevron.Nov.Dom
Imports Nevron.Nov.UI
Imports Nevron.Nov.Graphics
Imports Nevron.Nov.DataStructures
Imports Nevron.Nov.Layout

Namespace Nevron.Nov.Examples.Framework
    Public Class NGifDecoderExample
        Inherits NExampleBase
#Region "Constructors"

        Public Sub New()
        End Sub

        Shared Sub New()
            NGifDecoderExampleSchema = NSchema.Create(GetType(NGifDecoderExample), NExampleBase.NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            Dim imageNames As NList(Of String) = NImageDecodingExampleHelper.GetImageNames("GifSuite", "gif")
            Dim table As NTableFlowPanel = New NTableFlowPanel()
            table.HorizontalPlacement = ENHorizontalPlacement.Left
            table.VerticalPlacement = ENVerticalPlacement.Top
            table.Padding = New NMargins(30)
            table.HorizontalSpacing = 30
            table.VerticalSpacing = 30
            table.MaxOrdinal = 2
            Dim rowCount = imageNames.Count

            For i = 0 To rowCount - 1
                Dim nameLabel As NLabel = New NLabel(imageNames(i))
                nameLabel.MaxWidth = 200
                Dim imgSrc As NEmbeddedResourceImageSource = New NEmbeddedResourceImageSource(New NEmbeddedResourceRef(NResources.Instance, imageNames(i)))
                imgSrc.AnimateFrames = True
                Dim novImageBox As NImageBox = New NImageBox(New NImage(imgSrc))
                novImageBox.ImageMapping = New NAlignTextureMapping(ENHorizontalAlignment.Center, ENVerticalAlignment.Center)
                table.Add(nameLabel)
                table.Add(novImageBox)
            Next

            ' The table must be scrollable
            Dim scroll As NScrollContent = New NScrollContent()
            scroll.Content = table
            Return scroll
        End Function

        Protected Overrides Function CreateExampleControls() As NWidget
            Return Nothing
        End Function

        Protected Overrides Function GetExampleDescription() As String
            Return "
<p>
	This example demonstrates NOV's GIF image decoding capabilities and the built-in support for animated GIFs.
</p>
"
        End Function

#End Region

#Region "Schema"

        Public Shared ReadOnly NGifDecoderExampleSchema As NSchema

#End Region
    End Class
End Namespace

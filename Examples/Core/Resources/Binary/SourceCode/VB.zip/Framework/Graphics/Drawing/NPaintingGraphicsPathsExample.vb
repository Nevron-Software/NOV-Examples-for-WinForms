Imports Nevron.Nov.DataStructures
Imports Nevron.Nov.Dom
Imports Nevron.Nov.Graphics
Imports Nevron.Nov.Layout
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.Framework
    Public Class NPaintingGraphicsPathsExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' Default constructor.
        ''' </summary>
        Public Sub New()
        End Sub
        ''' <summary>
        ''' Static constructor.
        ''' </summary>
        Shared Sub New()
            NPaintingGraphicsPathsExampleSchema = NSchema.Create(GetType(NPaintingGraphicsPathsExample), NExampleBase.NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            ' Create a table panel to hold the canvases and the labels
            m_Table = New NTableFlowPanel()
            m_Table.HorizontalPlacement = ENHorizontalPlacement.Left
            m_Table.VerticalPlacement = ENVerticalPlacement.Top
            m_Table.Padding = New NMargins(30)
            m_Table.HorizontalSpacing = 30
            m_Table.VerticalSpacing = 30
            m_Table.MaxOrdinal = 4
            Dim names = New String() {"Rectangle", "Rounded Rectangle", "Ellipse", "Ellipse Segment", "Elliptical Arc", "Pie", "Circle", "Circle Segment", "Triangle", "Quad", "Polygon", "Line Segment", "Polyline", "Cubic Bezier", "Nurbs Curve", "Path with Multiple Figures"}
            Dim paths = CreatePaths(DefaultCanvasWidth, DefaultCanvasHeight)
            Dim count = paths.Length

            For i = 0 To count - 1
                Dim stack As NStackPanel = New NStackPanel()
                m_Table.Add(stack)
                stack.VerticalSpacing = 5

                ' Create a canvas to draw the graphics path in
                Dim canvas As NCanvas = New NCanvas()
                canvas.PreferredSize = New NSize(DefaultCanvasWidth, DefaultCanvasHeight)
                canvas.Tag = paths(i)
                AddHandler canvas.PrePaint, New [Function](Of NCanvasPaintEventArgs)(AddressOf OnCanvasPrePaint)
                canvas.BackgroundFill = New NColorFill(NColor.LightGreen)
                stack.Add(canvas)

                ' Create a label for the geometry primitive's name
                Dim label As NLabel = New NLabel(names(i))
                label.HorizontalPlacement = ENHorizontalPlacement.Center
                stack.Add(label)
            Next

            ' The table must be scrollable
            Dim scroll As NScrollContent = New NScrollContent()
            scroll.Content = m_Table
            Return scroll
        End Function

        Protected Overrides Function CreateExampleControls() As NWidget
            ' Fill
            m_FillSplitButton = New NFillSplitButton()
            AddHandler m_FillSplitButton.SelectedValueChanged, AddressOf OnFillSplitButtonSelectedValueChanged

            ' Stroke color
            m_StrokeColorBox = New NColorBox()
            m_StrokeColorBox.SelectedColor = m_Stroke.Color
            AddHandler m_StrokeColorBox.SelectedColorChanged, New [Function](Of NValueChangeEventArgs)(AddressOf OnStrokeColorBoxSelectedColorChanged)

            ' Stroke width
            m_StrokeWidthCombo = New NComboBox()

            For i = 0 To 6 - 1
                m_StrokeWidthCombo.Items.Add(New NComboBoxItem(i.ToString()))
            Next

            m_StrokeWidthCombo.SelectedIndex = 1
            AddHandler m_StrokeWidthCombo.SelectedIndexChanged, New [Function](Of NValueChangeEventArgs)(AddressOf OnStrokeWidthComboSelectedIndexChanged)

            ' Canvas width editor
            m_CanvasWidthUpDown = New NNumericUpDown()
            m_CanvasWidthUpDown.Minimum = 100
            m_CanvasWidthUpDown.Maximum = 350
            m_CanvasWidthUpDown.Value = DefaultCanvasWidth
            m_CanvasWidthUpDown.Step = 1
            m_CanvasWidthUpDown.DecimalPlaces = 0
            AddHandler m_CanvasWidthUpDown.ValueChanged, New [Function](Of NValueChangeEventArgs)(AddressOf OnNumericUpDownValueChanged)

            ' Canvas height editor
            m_CanvasHeightUpDown = New NNumericUpDown()
            m_CanvasHeightUpDown.Minimum = 100
            m_CanvasHeightUpDown.Maximum = 350
            m_CanvasHeightUpDown.Value = DefaultCanvasHeight
            m_CanvasHeightUpDown.Step = 1
            m_CanvasHeightUpDown.DecimalPlaces = 0
            AddHandler m_CanvasHeightUpDown.ValueChanged, New [Function](Of NValueChangeEventArgs)(AddressOf OnNumericUpDownValueChanged)
            Dim stack As NStackPanel = New NStackPanel()
            stack.FillMode = ENStackFillMode.None
            stack.FitMode = ENStackFitMode.None
            stack.Add(NPairBox.Create("Fill:", m_FillSplitButton))
            stack.Add(NPairBox.Create("Stroke Color:", m_StrokeColorBox))
            stack.Add(NPairBox.Create("Stroke Width:", m_StrokeWidthCombo))
            stack.Add(NPairBox.Create("Canvas Width:", m_CanvasWidthUpDown))
            stack.Add(NPairBox.Create("Canvas Height:", m_CanvasHeightUpDown))
            Return New NUniSizeBoxGroup(stack)
        End Function

        Protected Overrides Function GetExampleDescription() As String
            Return "
<p>
	This example demonstrates the graphics path's capabilities for painting of geometric primitives.
	You can use the controls in the right-side panel to change the fill and stroke of the graphics paths.
</p>
"
        End Function

#End Region

#Region "Event Handlers"

        Private Sub OnCanvasPrePaint(ByVal args As NCanvasPaintEventArgs)
            Dim canvas As NCanvas = TryCast(args.TargetNode, NCanvas)
            If canvas Is Nothing Then Return
            Dim path = CType(canvas.Tag, NGraphicsPath)
            args.PaintVisitor.ClearStyles()
            args.PaintVisitor.SetStroke(m_Stroke)
            args.PaintVisitor.SetFill(m_Fill)
            args.PaintVisitor.PaintPath(path, ENFillRule.EvenOdd)
        End Sub

        Private Sub OnNumericUpDownValueChanged(ByVal args As NValueChangeEventArgs)
            If m_Table Is Nothing Then Return
            Dim width = m_CanvasWidthUpDown.Value
            Dim height = m_CanvasHeightUpDown.Value

            ' Recreate all graphics paths
            Dim paths = CreatePaths(width, height)
            Dim index = 0

            ' Resize the canvases
            Dim iterator As INIterator(Of NNode) = m_Table.GetSubtreeIterator(ENTreeTraversalOrder.DepthFirstPreOrder, New NInstanceOfSchemaFilter(NCanvas.NCanvasSchema))

            While iterator.MoveNext()
                Dim canvas = CType(iterator.Current, NCanvas)
                CType(canvas.ParentNode, NWidget).PreferredWidth = width
                canvas.PreferredHeight = height
                canvas.Tag = paths(Math.Min(System.Threading.Interlocked.Increment(index), index - 1))
            End While
        End Sub

        Private Sub OnFillSplitButtonSelectedValueChanged(ByVal arg As NValueChangeEventArgs)
            Dim selectedFill As NAutomaticValue(Of NFill) = arg.NewValue
            m_Fill = If(selectedFill.Automatic, Nothing, selectedFill.Value)
            InvalidateCanvases()
        End Sub

        Private Sub OnStrokeColorBoxSelectedColorChanged(ByVal arg As NValueChangeEventArgs)
            m_Stroke.Color = m_StrokeColorBox.SelectedColor
            InvalidateCanvases()
        End Sub

        Private Sub OnStrokeWidthComboSelectedIndexChanged(ByVal arg As NValueChangeEventArgs)
            m_Stroke.Width = m_StrokeWidthCombo.SelectedIndex
            InvalidateCanvases()
        End Sub

#End Region

#Region "Implementation"

        Private Sub InvalidateCanvases()
            If m_Table Is Nothing Then Return
            Dim iterator As INIterator(Of NNode) = m_Table.GetSubtreeIterator(ENTreeTraversalOrder.DepthFirstPreOrder, New NInstanceOfSchemaFilter(NCanvas.NCanvasSchema))

            While iterator.MoveNext()
                Dim canvas = CType(iterator.Current, NCanvas)
                canvas.InvalidateDisplay()
            End While
        End Sub

        Private Function CreatePaths(ByVal w As Double, ByVal h As Double) As NGraphicsPath()
            Dim paths = New NGraphicsPath() {CreateRectangle(w, h), CreateRoundedRectangle(w, h), CreateEllipse(w, h), CreateEllipseSegment(w, h), CreateEllipticalArc(w, h), CreatePie(w, h), CreateCircle(w, h), CreateCircleSegment(w, h), CreateTriangle(w, h), CreateQuad(w, h), CreatePolygon(w, h), CreateLineSegment(w, h), CreatePolyline(w, h), CreateCubicBezier(w, h), CreateNurbsCurve(w, h), CreatePathWithMultipleFigures(w, h)}
            Return paths
        End Function

#End Region

#Region "Fields"

        Private m_Table As NTableFlowPanel
        Private m_CanvasWidthUpDown As NNumericUpDown
        Private m_CanvasHeightUpDown As NNumericUpDown
        Private m_FillSplitButton As NFillSplitButton
        Private m_StrokeColorBox As NColorBox
        Private m_StrokeWidthCombo As NComboBox
        Private m_Stroke As NStroke = New NStroke()
        Private m_Fill As NFill

#End Region

#Region "Static Methods"

        Private Shared Function CreateRectangle(ByVal w As Double, ByVal h As Double) As NGraphicsPath
            Dim path As NGraphicsPath = New NGraphicsPath()
            path.AddRectangle(0.05 * w, 0.25 * h, 0.9 * w, 0.5 * h)
            Return path
        End Function

        Private Shared Function CreateRoundedRectangle(ByVal w As Double, ByVal h As Double) As NGraphicsPath
            Dim rect As NRectangle = New NRectangle(0.05 * w, 0.25 * h, 0.9 * w, 0.5 * h)
            Dim path As NGraphicsPath = New NGraphicsPath()
            path.AddRoundedRectangle(rect, h * 0.05)
            Return path
        End Function

        Private Shared Function CreateEllipse(ByVal w As Double, ByVal h As Double) As NGraphicsPath
            Dim path As NGraphicsPath = New NGraphicsPath()
            path.AddEllipse(0.05 * w, 0.25 * h, 0.9 * w, 0.5 * h)
            Return path
        End Function

        Private Shared Function CreateEllipseSegment(ByVal w As Double, ByVal h As Double) As NGraphicsPath
            Dim rect As NRectangle = New NRectangle(0.05 * w, 0.25 * h, 0.9 * w, 0.5 * h)
            Dim path As NGraphicsPath = New NGraphicsPath()
            path.AddEllipseSegment(rect, NMath.PI * 0.1, NMath.PI * 1.2)
            Return path
        End Function

        Private Shared Function CreateEllipticalArc(ByVal w As Double, ByVal h As Double) As NGraphicsPath
            Dim start As NPoint = New NPoint(w * 0.3, h * 0.85)
            Dim control As NPoint = New NPoint(w * 0.5, h * 0.15)
            Dim [end] As NPoint = New NPoint(w * 0.8, h * 0.85)
            Dim angle As Double = 1
            Dim ratio = 1.4
            Dim path As NGraphicsPath = New NGraphicsPath()
            path.AddEllipticalArc(start, control, [end], angle, ratio)
            Return path
        End Function

        Private Shared Function CreatePie(ByVal w As Double, ByVal h As Double) As NGraphicsPath
            Dim path As NGraphicsPath = New NGraphicsPath()
            path.AddPie(0.1 * w, 0.1 * h, 0.8 * w, 0.8 * h, 0.25 * NMath.PI, 1.5 * NMath.PI)
            Return path
        End Function

        Private Shared Function CreateCircle(ByVal w As Double, ByVal h As Double) As NGraphicsPath
            Dim radius = 0.4 * NMath.Min(w, h)
            Dim path As NGraphicsPath = New NGraphicsPath()
            path.AddCircle(0.5 * w, 0.5 * h, radius)
            Return path
        End Function

        Private Shared Function CreateCircleSegment(ByVal w As Double, ByVal h As Double) As NGraphicsPath
            Dim radius = 0.4 * NMath.Min(w, h)
            Dim center As NPoint = New NPoint(0.5 * w, 0.5 * h)
            Dim path As NGraphicsPath = New NGraphicsPath()
            path.AddCircleSegment(center, radius, 0.25 * NMath.PI, 1.5 * NMath.PI)
            Return path
        End Function

        Private Shared Function CreateTriangle(ByVal w As Double, ByVal h As Double) As NGraphicsPath
            Dim triangle As NTriangle = New NTriangle()
            triangle.A = New NPoint(0.5 * w, 0.1 * h)
            triangle.B = New NPoint(0.9 * w, 0.9 * h)
            triangle.C = New NPoint(0.1 * w, 0.8 * h)
            Dim path As NGraphicsPath = New NGraphicsPath()
            path.AddTriangle(triangle)
            Return path
        End Function

        Private Shared Function CreateQuad(ByVal w As Double, ByVal h As Double) As NGraphicsPath
            Dim quad As NQuadrangle = New NQuadrangle()
            quad.A = New NPoint(0.2 * w, 0.1 * h)
            quad.B = New NPoint(0.6 * w, 0.1 * h)
            quad.C = New NPoint(0.9 * w, 0.9 * h)
            quad.D = New NPoint(0.1 * w, 0.6 * h)
            Dim path As NGraphicsPath = New NGraphicsPath()
            path.AddQuad(quad)
            Return path
        End Function

        Private Shared Function CreatePolygon(ByVal w As Double, ByVal h As Double) As NGraphicsPath
            Dim polygon As NPolygon = New NPolygon(6)
            polygon.Add(0.3 * w, 0.1 * h)
            polygon.Add(0.7 * w, 0.1 * h)
            polygon.Add(0.5 * w, 0.4 * h)
            polygon.Add(0.9 * w, 0.9 * h)
            polygon.Add(0.2 * w, 0.8 * h)
            polygon.Add(0.1 * w, 0.4 * h)
            Dim path As NGraphicsPath = New NGraphicsPath()
            path.AddPolygon(polygon)
            Return path
        End Function

        Private Shared Function CreateLineSegment(ByVal w As Double, ByVal h As Double) As NGraphicsPath
            Dim path As NGraphicsPath = New NGraphicsPath()
            path.AddLineSegment(0.2 * w, 0.1 * h, 0.9 * w, 0.9 * h)
            Return path
        End Function

        Private Shared Function CreatePolyline(ByVal w As Double, ByVal h As Double) As NGraphicsPath
            Dim points As NPoint() = New NPoint() {New NPoint(0.1 * w, 0.1 * h), New NPoint(0.9 * w, 0.3 * h), New NPoint(0.2 * w, 0.6 * h), New NPoint(0.8 * w, 0.7 * h), New NPoint(0.6 * w, 0.9 * h)}
            Dim path As NGraphicsPath = New NGraphicsPath()
            path.AddPolyline(points)
            Return path
        End Function

        Private Shared Function CreateCubicBezier(ByVal w As Double, ByVal h As Double) As NGraphicsPath
            Dim start As NPoint = New NPoint(0.1 * w, 0.1 * h)
            Dim c1 As NPoint = New NPoint(0.8 * w, 0.0 * h)
            Dim c2 As NPoint = New NPoint(0.5 * w, 1.0 * h)
            Dim [end] As NPoint = New NPoint(0.9 * w, 0.9 * h)
            Dim path As NGraphicsPath = New NGraphicsPath()
            path.AddCubicBezier(start, c1, c2, [end])
            Return path
        End Function

        Private Shared Function CreateNurbsCurve(ByVal w As Double, ByVal h As Double) As NGraphicsPath
            Dim nurbs As NNurbsCurve = New NNurbsCurve(3)
            nurbs.ControlPoints.Add(New NNurbsControlPoint(0.05 * w, 0.50 * h))
            nurbs.ControlPoints.Add(New NNurbsControlPoint(0.20 * w, 0.20 * h))
            nurbs.ControlPoints.Add(New NNurbsControlPoint(0.40 * w, 0.00 * h))
            nurbs.ControlPoints.Add(New NNurbsControlPoint(0.60 * w, 0.50 * h))
            nurbs.ControlPoints.Add(New NNurbsControlPoint(0.60 * w, 0.70 * h))
            nurbs.ControlPoints.Add(New NNurbsControlPoint(0.30 * w, 0.95 * h))
            nurbs.ControlPoints.Add(New NNurbsControlPoint(0.40 * w, 0.50 * h))
            nurbs.ControlPoints.Add(New NNurbsControlPoint(0.90 * w, 0.00 * h))
            nurbs.ControlPoints.Add(New NNurbsControlPoint(0.95 * w, 0.50 * h))
            nurbs.Knots.AddRange(New Double() {0, 0, 0, 0, 1, 2, 3, 4, 5, 6, 6, 6, 6})
            Dim path As NGraphicsPath = New NGraphicsPath()
            path.AddNurbsCurve(nurbs)
            Return path
        End Function

        Private Shared Function CreatePathWithMultipleFigures(ByVal w As Double, ByVal h As Double) As NGraphicsPath
            Dim path As NGraphicsPath = New NGraphicsPath()
            path.StartFigure(0.05 * w, 0.05 * h)
            path.LineTo(0.4 * w, 0.2 * h)
            path.LineTo(0.54 * w, 0.5 * h)
            path.CircularArcTo(New NPoint(0.05 * w, 0.5 * h), 12)
            path.CloseFigure()
            path.StartFigure(0.05 * w, 0.95 * h)
            path.LineTo(0.05 * w, 0.6 * h)
            path.CubicBezierTo(0.6 * w, 0.7 * h, 0.2 * w, 0.1 * h, 0.5 * w, 0.7 * h)
            path.LineTo(0.6 * w, 0.95 * h)
            path.CloseFigure()
            Dim points As NPoint() = New NPoint() {New NPoint(0.95 * w, 0.05 * h), New NPoint(0.95 * w, 0.95 * h), New NPoint(0.65 * w, 0.95 * h), New NPoint(0.65 * w, 0.60 * h)}
            path.StartFigure(0.4 * w, 0.05 * h)
            path.LineTos(points, 0, points.Length)
            path.CloseFigure()
            path.StartFigure(0.7 * w, 0.1 * h)
            path.EllipticalArcTo(New NPoint(0.7 * w, 0.3 * h), New NPoint(0.9 * w, 0.2 * h), 0, 2)
            path.CloseFigure()
            path.StartFigure(0.7 * w, 0.6 * h)
            path.CircularArcTo(New NPoint(0.7 * w, 0.8 * h), 0.2 * w)
            path.CloseFigure()
            Return path
        End Function

#End Region

#Region "Schema"

        ''' <summary>
        ''' Schema associated with NPaintingGraphicsPathsExample.
        ''' </summary>
        Public Shared ReadOnly NPaintingGraphicsPathsExampleSchema As NSchema

#End Region

#Region "Constants"

        Private Const DefaultCanvasWidth As Integer = 220
        Private Const DefaultCanvasHeight As Integer = 220

#End Region
    End Class
End Namespace

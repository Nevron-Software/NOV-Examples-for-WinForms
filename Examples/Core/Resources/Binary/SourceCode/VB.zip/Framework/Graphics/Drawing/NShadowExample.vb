Imports System

Imports Nevron.Nov.DataStructures
Imports Nevron.Nov.Dom
Imports Nevron.Nov.Editors
Imports Nevron.Nov.Graphics
Imports Nevron.Nov.Layout
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.Framework
    Public Class NShadowExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' 
        ''' </summary>
        Public Sub New()
        End Sub
        ''' <summary>
        ''' 
        ''' </summary>
        Shared Sub New()
            NShadowExampleSchema = NSchema.Create(GetType(NShadowExample), NExampleBase.NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            m_Shadow = New NShadow(New NColor(160, 160, 160), 20, 20)

            Dim names = New String() {"Line", "Polyline", "Rectangle", "Ellipse", "Triangle", "Quad", "Polygon", "Graphics Path"}

            Dim delegates As PaintPrimitiveDelegate() = New PaintPrimitiveDelegate() {New PaintPrimitiveDelegate(AddressOf PaintLine), New PaintPrimitiveDelegate(AddressOf PaintPolyline), New PaintPrimitiveDelegate(AddressOf PaintRectangle), New PaintPrimitiveDelegate(AddressOf PaintEllipse), New PaintPrimitiveDelegate(AddressOf PaintTriangle), New PaintPrimitiveDelegate(AddressOf PaintQuadrangle), New PaintPrimitiveDelegate(AddressOf PaintPolygon), New PaintPrimitiveDelegate(AddressOf PaintPath)}

            Dim count = delegates.Length

            ' Create a table panel to hold the canvases and the labels
            m_Table = New NTableFlowPanel()
            m_Table.HorizontalPlacement = ENHorizontalPlacement.Left
            m_Table.VerticalPlacement = ENVerticalPlacement.Top
            m_Table.Padding = New NMargins(30)
            m_Table.HorizontalSpacing = 30
            m_Table.VerticalSpacing = 30
            m_Table.MaxOrdinal = 4

            For i = 0 To count - 1
                Dim stack As NStackPanel = New NStackPanel()
                m_Table.Add(stack)
                stack.VerticalSpacing = 5

                ' Create a canvas to draw in
                Dim canvas As NCanvas = New NCanvas()
                canvas.PreferredSize = New NSize(DefaultCanvasWidth, DefaultCanvasHeight)
                canvas.Tag = delegates(i)
                canvas.BackgroundFill = New NColorFill(NColor.White)
                canvas.PrePaint += New [Function](Of NCanvasPaintEventArgs)(AddressOf OnCanvasPrePaint)
                stack.Add(canvas)

                ' Create a label for the geometry primitive's name
                Dim label As NLabel = New NLabel(names(i))
                label.HorizontalPlacement = ENHorizontalPlacement.Center
                stack.Add(label)
            Next

            ' The table must be scrollable
            Dim scroll As NScrollContent = New NScrollContent()
            scroll.Content = m_Table
            Return scroll
        End Function
        Protected Overrides Function CreateExampleControls() As NWidget
            ' get editors for shadow properties
            Dim editors = NDesigner.GetDesigner(m_Shadow).CreatePropertyEditors(m_Shadow, NShadow.ColorProperty, NShadow.AlignXFactorProperty, NShadow.AlignYFactorProperty, NShadow.OffsetXProperty, NShadow.OffsetYProperty, NShadow.ScaleXProperty, NShadow.ScaleYProperty, NShadow.SkewXProperty, NShadow.SkewYProperty, NShadow.UseFillAndStrokeAlphaProperty, NShadow.ApplyToFillingProperty, NShadow.ApplyToOutlineProperty)

            Dim stack As NStackPanel = New NStackPanel()
            stack.FillMode = ENStackFillMode.None
            stack.FitMode = ENStackFitMode.None

            For i = 0 To editors.Count - 1
                stack.Add(editors(i))
            Next

            m_Shadow.Changed += New [Function](Of NEventArgs)(AddressOf OnEditShadowChanged)

            Return New NUniSizeBoxGroup(stack)
        End Function
        Protected Overrides Function GetExampleDescription() As String
            Return "
<p>
	This example demonstrates the built-in shadows.
	Use the controls to the right to modify various properties of the shadow.
</p>
" End Function

#End Region

#Region "Event Handlers"

        Private Sub OnCanvasPrePaint(ByVal args As NCanvasPaintEventArgs)
            Dim canvas As NCanvas = TryCast(args.TargetNode, NCanvas)
            If canvas Is Nothing Then Return

            Dim paintDelegate As PaintPrimitiveDelegate = TryCast(canvas.Tag, PaintPrimitiveDelegate)
            If paintDelegate Is Nothing Then Throw New Exception("The canvas has no assigned paint delegate.")

            ' Clear all styles and set the shadow
            args.PaintVisitor.ClearStyles()
            args.PaintVisitor.SetShadow(m_Shadow)

            ' Paint the scene for the current canvas
            paintDelegate(args.PaintVisitor, canvas.Width, canvas.Height)

            ' Paint a bounding rectangle for the canvas
            args.PaintVisitor.ClearStyles()
            args.PaintVisitor.SetStroke(NColor.Red, 1)
            args.PaintVisitor.PaintRectangle(0, 0, canvas.Width, canvas.Height)
        End Sub
        Private Sub OnEditShadowChanged(ByVal args As NEventArgs)
            Dim localValueChangeArgs As NValueChangeEventArgs = TryCast(args, NValueChangeEventArgs)

            If localValueChangeArgs IsNot Nothing Then
                InvalidateCanvases()
            End If
        End Sub

#End Region

#Region "Implementation"

        Private Sub InvalidateCanvases()
            If m_Table Is Nothing Then Return

            Dim iterator As INIterator(Of NNode) = m_Table.GetSubtreeIterator(ENTreeTraversalOrder.DepthFirstPreOrder, New NInstanceOfSchemaFilter(NCanvas.NCanvasSchema))

            While iterator.MoveNext()
                Dim canvas = CType(iterator.Current, NCanvas)
                canvas.InvalidateDisplay()
            End While
        End Sub

        Private Sub PaintLine(ByVal paintVisitor As NPaintVisitor, ByVal w As Double, ByVal h As Double)
            paintVisitor.SetStroke(NColor.Black, 2)

            paintVisitor.PaintLine(0.2 * w, 0.8 * h, 0.7 * w, 0.2 * h)
        End Sub
        Private Sub PaintPolyline(ByVal paintVisitor As NPaintVisitor, ByVal w As Double, ByVal h As Double)
            paintVisitor.SetStroke(NColor.Black, 2)

            Dim polyline As NPolyline = New NPolyline(5)
            polyline.Add(0.2 * w, 0.2 * h)
            polyline.Add(0.4 * w, 0.3 * h)
            polyline.Add(0.3 * w, 0.5 * h)
            polyline.Add(0.4 * w, 0.7 * h)
            polyline.Add(0.8 * w, 0.8 * h)
            paintVisitor.PaintPolyline(polyline)
        End Sub
        Private Sub PaintRectangle(ByVal paintVisitor As NPaintVisitor, ByVal w As Double, ByVal h As Double)
            Dim lgf As NLinearGradientFill = New NLinearGradientFill()
            lgf.GradientStops.Add(New NGradientStop(0, NColor.Indigo))
            lgf.GradientStops.Add(New NGradientStop(0.5F, NColor.SlateBlue))
            lgf.GradientStops.Add(New NGradientStop(1, New NColor(NColor.Crimson, 30)))

            paintVisitor.SetStroke(NColor.Black, 1)
            paintVisitor.SetFill(lgf)

            paintVisitor.PaintRectangle(0.2 * w, 0.3 * h, 0.6 * w, 0.4 * h)
        End Sub
        Private Sub PaintEllipse(ByVal paintVisitor As NPaintVisitor, ByVal w As Double, ByVal h As Double)
            Dim rgf As NRadialGradientFill = New NRadialGradientFill()
            rgf.GradientStops.Add(New NGradientStop(0, NColor.Indigo))
            rgf.GradientStops.Add(New NGradientStop(0.6F, NColor.SlateBlue))
            rgf.GradientStops.Add(New NGradientStop(1, New NColor(NColor.Crimson, 30)))

            paintVisitor.SetStroke(NColor.Black, 1)
            paintVisitor.SetFill(rgf)

            paintVisitor.PaintEllipse(0.2 * w, 0.3 * h, 0.6 * w, 0.4 * h)
        End Sub
        Private Sub PaintTriangle(ByVal paintVisitor As NPaintVisitor, ByVal w As Double, ByVal h As Double)
            paintVisitor.SetStroke(NColor.Black, 2)
            paintVisitor.SetFill(NColor.Crimson)

            Dim p1 As NPoint = New NPoint(0.5 * w, 0.2 * h)
            Dim p2 As NPoint = New NPoint(0.8 * w, 0.8 * h)
            Dim p3 As NPoint = New NPoint(0.2 * w, 0.7 * h)

            paintVisitor.PaintTriangle(p1, p2, p3)
        End Sub
        Private Sub PaintQuadrangle(ByVal paintVisitor As NPaintVisitor, ByVal w As Double, ByVal h As Double)
            paintVisitor.SetStroke(NColor.Black, 2)
            paintVisitor.SetFill(New NColor(NColor.Crimson, 128))

            Dim p1 As NPoint = New NPoint(0.3 * w, 0.2 * h)
            Dim p2 As NPoint = New NPoint(0.6 * w, 0.2 * h)
            Dim p3 As NPoint = New NPoint(0.8 * w, 0.8 * h)
            Dim p4 As NPoint = New NPoint(0.2 * w, 0.6 * h)

            paintVisitor.PaintQuadrangle(p1, p2, p3, p4)
        End Sub
        Private Sub PaintPolygon(ByVal paintVisitor As NPaintVisitor, ByVal w As Double, ByVal h As Double)
            paintVisitor.SetStroke(New NColor(0, 0, 0, 160), 6)
            paintVisitor.SetFill(NColor.GreenYellow)

            Dim polygon As NPolygon = New NPolygon(6)
            polygon.Add(0.3 * w, 0.2 * h)
            polygon.Add(0.6 * w, 0.2 * h)
            polygon.Add(0.5 * w, 0.4 * h)
            polygon.Add(0.8 * w, 0.8 * h)
            polygon.Add(0.3 * w, 0.7 * h)
            polygon.Add(0.2 * w, 0.4 * h)

            paintVisitor.PaintPolygon(polygon, ENFillRule.EvenOdd)
        End Sub
        Private Sub PaintPath(ByVal paintVisitor As NPaintVisitor, ByVal w As Double, ByVal h As Double)
            paintVisitor.SetStroke(New NColor(0, 0, 0, 160), 6)
            paintVisitor.SetFill(New NColor(NColor.GreenYellow, 128))

            Dim path As NGraphicsPath = New NGraphicsPath()
            path.StartFigure(0.2 * w, 0.2 * h)
            path.LineTo(0.7 * w, 0.3 * h)
            path.CubicBezierTo(0.8 * w, 0.8 * h, 1 * w, 0.4 * h, 0.5 * w, 0.7 * h)
            path.LineTo(0.3 * w, 0.7 * h)
            path.CubicBezierTo(0.2 * w, 0.2 * h, 0.3 * w, 0.7 * h, 0.4 * w, 0.6 * h)
            path.CloseFigure()

            paintVisitor.PaintPath(path)
        End Sub

#End Region

#Region "Fields"

        Private m_Shadow As NShadow
        Private m_Table As NTableFlowPanel

#End Region

#Region "Constants"

        Private Const DefaultCanvasWidth As Integer = 220
        Private Const DefaultCanvasHeight As Integer = 220

#End Region

#Region "Schema"

        Public Shared ReadOnly NShadowExampleSchema As NSchema

#End Region

#Region "Nested Types"

        Friend Delegate Sub PaintPrimitiveDelegate(ByVal paintVisitor As NPaintVisitor, ByVal w As Double, ByVal h As Double)

#End Region
    End Class
End Namespace

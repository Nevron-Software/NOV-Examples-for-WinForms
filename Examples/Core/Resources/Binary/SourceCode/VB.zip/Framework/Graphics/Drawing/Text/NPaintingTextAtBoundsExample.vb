Imports Nevron.Nov.Dom
Imports Nevron.Nov.Graphics
Imports Nevron.Nov.Layout
Imports Nevron.Nov.UI
Imports System.Text

Namespace Nevron.Nov.Examples.Framework
    ''' <summary>
    ''' The example demonstrates how to paint text at given bounds
    ''' </summary>
    Public Class NPaintingTextAtBoundsExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' Default constructor.
        ''' </summary>
        Public Sub New()
        End Sub
        ''' <summary>
        ''' Static constructor.
        ''' </summary>
        Shared Sub New()
            NPaintingTextAtBoundsExampleSchema = NSchema.Create(GetType(NPaintingTextAtBoundsExample), NExampleBase.NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            m_Canvas = New NCanvas()
            AddHandler m_Canvas.PrePaint, New [Function](Of NCanvasPaintEventArgs)(AddressOf OnCanvasPrePaint)
            m_Canvas.BackgroundFill = New NColorFill(NColor.White)
            Return m_Canvas
        End Function

        Protected Overrides Function CreateExampleControls() As NWidget
            m_WrapModeCombo = New NComboBox()
            m_WrapModeCombo.FillFromEnum(Of ENTextWrapMode)()
            AddHandler m_WrapModeCombo.SelectedIndexChanged, New [Function](Of NValueChangeEventArgs)(AddressOf OnWrapModeComboSelectedIndexChanged)
            m_HorizontalAlignmentCombo = New NComboBox()
            m_HorizontalAlignmentCombo.FillFromEnum(Of ENTextHorzAlign)()
            AddHandler m_HorizontalAlignmentCombo.SelectedIndexChanged, New [Function](Of NValueChangeEventArgs)(AddressOf OnHorizontalAlignmentComboSelectedIndexChanged)
            m_VerticalAlignmentCombo = New NComboBox()
            m_VerticalAlignmentCombo.FillFromEnum(Of ENTextVertAlign)()
            AddHandler m_VerticalAlignmentCombo.SelectedIndexChanged, New [Function](Of NValueChangeEventArgs)(AddressOf OnVerticalAlignmentComboSelectedIndexChanged)
            m_SingleLineCheckBox = New NCheckBox("Single Line")
            AddHandler m_SingleLineCheckBox.CheckedChanged, New [Function](Of NValueChangeEventArgs)(AddressOf OnSingleLineCheckBoxCheckedChanged)
            m_WidthPercentUpDown = New NNumericUpDown()
            m_WidthPercentUpDown.Value = 50
            m_WidthPercentUpDown.Minimum = 0
            m_WidthPercentUpDown.Maximum = 100.0
            AddHandler m_WidthPercentUpDown.ValueChanged, New [Function](Of NValueChangeEventArgs)(AddressOf OnWidthPercentValueChanged)
            m_HeightPercentUpDown = New NNumericUpDown()
            m_HeightPercentUpDown.Value = 50
            m_HeightPercentUpDown.Minimum = 0
            m_HeightPercentUpDown.Maximum = 100.0
            AddHandler m_HeightPercentUpDown.ValueChanged, New [Function](Of NValueChangeEventArgs)(AddressOf OnHeightPercentValueChanged)
            Dim stack As NStackPanel = New NStackPanel()
            stack.FillMode = ENStackFillMode.None
            stack.FitMode = ENStackFitMode.None
            stack.Add(NPairBox.Create("Wrap Mode", m_WrapModeCombo))
            stack.Add(NPairBox.Create("Horizontal Alignment", m_HorizontalAlignmentCombo))
            stack.Add(NPairBox.Create("Vertical Alignment", m_VerticalAlignmentCombo))
            stack.Add(m_SingleLineCheckBox)
            stack.Add(NPairBox.Create("Width Percent:", m_WidthPercentUpDown))
            stack.Add(NPairBox.Create("Height Percent:", m_HeightPercentUpDown))
            Return New NUniSizeBoxGroup(stack)
        End Function

        Protected Overrides Function GetExampleDescription() As String
            Return "
<p>
The example demonstrates how to paint text path. Use the controls to the right to modify different parameters of the rectangular paint text settings.
</p>
"
        End Function

#End Region

#Region "Event Handlers"

        ''' <summary>
        ''' 
        ''' </summary>
        ''' <paramname="args"></param>
        Private Sub OnCanvasPrePaint(ByVal args As NCanvasPaintEventArgs)
            Dim canvas As NCanvas = TryCast(args.TargetNode, NCanvas)
            If canvas Is Nothing Then Return
            Dim paintVisitor = args.PaintVisitor
            Dim contentEge As NRectangle = canvas.GetContentEdge()

            ' create the text bounds
            Dim width = contentEge.Width * m_WidthPercentUpDown.Value / 100.0
            Dim height = contentEge.Height * m_HeightPercentUpDown.Value / 100.0
            Dim center = contentEge.Center
            Dim textBounds As NRectangle = New NRectangle(center.X - width / 2.0, center.Y - height / 2.0, width, height)

            ' create the settings
            Dim settings As NPaintTextRectSettings = New NPaintTextRectSettings()
            settings.SingleLine = m_SingleLineCheckBox.Checked
            settings.WrapMode = CType(m_WrapModeCombo.SelectedIndex, ENTextWrapMode)
            settings.HorzAlign = CType(m_HorizontalAlignmentCombo.SelectedIndex, ENTextHorzAlign)
            settings.VertAlign = CType(m_VerticalAlignmentCombo.SelectedIndex, ENTextVertAlign)

            ' create the text
            Dim builder As StringBuilder = New StringBuilder()
            builder.AppendLine("Paint text at bounds [" & textBounds.X.ToString("0.") & ", " & textBounds.Y.ToString("0.") & "]")
            builder.AppendLine("Horizontal Alignment [" & settings.HorzAlign.ToString() & "]")
            builder.AppendLine("Vertical Alignment [" & settings.VertAlign.ToString() & "]")

            ' paint the bounding box
            paintVisitor.ClearStyles()
            paintVisitor.SetFill(NColor.LightBlue)
            paintVisitor.PaintRectangle(textBounds)

            ' init font and fill
            paintVisitor.SetFill(NColor.Black)
            paintVisitor.SetFont(New NFont(NFontDescriptor.DefaultSansFamilyName, 10))

            ' paint the text
            paintVisitor.PaintString(textBounds, builder.ToString(), settings)
        End Sub

        Private Sub OnWidthPercentValueChanged(ByVal arg As NValueChangeEventArgs)
            m_Canvas.InvalidateDisplay()
        End Sub

        Private Sub OnHeightPercentValueChanged(ByVal arg As NValueChangeEventArgs)
            m_Canvas.InvalidateDisplay()
        End Sub

        Private Sub OnWrapModeComboSelectedIndexChanged(ByVal arg As NValueChangeEventArgs)
            m_Canvas.InvalidateDisplay()
        End Sub

        Private Sub OnSingleLineCheckBoxCheckedChanged(ByVal arg As NValueChangeEventArgs)
            m_Canvas.InvalidateDisplay()
        End Sub

        Private Sub OnVerticalAlignmentComboSelectedIndexChanged(ByVal arg As NValueChangeEventArgs)
            m_Canvas.InvalidateDisplay()
        End Sub

        Private Sub OnHorizontalAlignmentComboSelectedIndexChanged(ByVal arg As NValueChangeEventArgs)
            m_Canvas.InvalidateDisplay()
        End Sub

#End Region

#Region "Fields"

        Private m_WidthPercentUpDown As NNumericUpDown
        Private m_HeightPercentUpDown As NNumericUpDown
        Private m_WrapModeCombo As NComboBox
        Private m_HorizontalAlignmentCombo As NComboBox
        Private m_VerticalAlignmentCombo As NComboBox
        Private m_SingleLineCheckBox As NCheckBox
        Private m_Canvas As NCanvas

#End Region

#Region "Schema"

        ''' <summary>
        ''' Schema associated with NPaintingTextAtBoundsExample.
        ''' </summary>
        Public Shared ReadOnly NPaintingTextAtBoundsExampleSchema As NSchema

#End Region
    End Class
End Namespace

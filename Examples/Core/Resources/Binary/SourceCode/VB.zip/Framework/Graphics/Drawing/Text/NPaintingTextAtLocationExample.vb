Imports Nevron.Nov.Dom
Imports Nevron.Nov.Graphics
Imports Nevron.Nov.Layout
Imports Nevron.Nov.UI
Imports System.Text

Namespace Nevron.Nov.Examples.Framework
    ''' <summary>
    ''' The example demonstrates how to paint text at location
    ''' </summary>
    Public Class NPaintingTextAtLocationExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' Default constructor.
        ''' </summary>
        Public Sub New()
        End Sub
        ''' <summary>
        ''' Static constructor.
        ''' </summary>
        Shared Sub New()
            NPaintingTextAtLocationExampleSchema = NSchema.Create(GetType(NPaintingTextAtLocationExample), NExampleBase.NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            ' Create a table panel to hold the canvases and the labels
            Dim stack As NStackPanel = New NStackPanel()
            stack.FillMode = ENStackFillMode.Last
            stack.FitMode = ENStackFitMode.Last
            m_Canvas = New NCanvas()
            stack.Add(m_Canvas)
            AddHandler m_Canvas.PrePaint, New [Function](Of NCanvasPaintEventArgs)(AddressOf OnCanvasPrePaint)
            m_Canvas.BackgroundFill = New NColorFill(NColor.White)
            Return stack
        End Function

        Protected Overrides Function CreateExampleControls() As NWidget
            m_HorizontalAlignmentCombo = New NComboBox()
            m_HorizontalAlignmentCombo.FillFromEnum(Of ENTextHorzAlign)()
            AddHandler m_HorizontalAlignmentCombo.SelectedIndexChanged, New [Function](Of NValueChangeEventArgs)(AddressOf OnHorizontalAlignmentComboSelectedIndexChanged)
            m_VerticalAlignmentCombo = New NComboBox()
            m_VerticalAlignmentCombo.FillFromEnum(Of ENTextVertAlign)()
            AddHandler m_VerticalAlignmentCombo.SelectedIndexChanged, New [Function](Of NValueChangeEventArgs)(AddressOf OnVerticalAlignmentComboSelectedIndexChanged)
            m_SingleLineCheckBox = New NCheckBox("Single Line")
            AddHandler m_SingleLineCheckBox.CheckedChanged, New [Function](Of NValueChangeEventArgs)(AddressOf OnSingleLineCheckBoxCheckedChanged)
            Dim stack As NStackPanel = New NStackPanel()
            stack.FillMode = ENStackFillMode.None
            stack.FitMode = ENStackFitMode.None
            stack.Add(NPairBox.Create("Horizontal Alignment", m_HorizontalAlignmentCombo))
            stack.Add(NPairBox.Create("Vertical Alignment", m_VerticalAlignmentCombo))
            stack.Add(m_SingleLineCheckBox)
            Return New NUniSizeBoxGroup(stack)
        End Function

        Protected Overrides Function GetExampleDescription() As String
            Return "
<p>
The example demonstrates how to paint text at location. Use the controls to the right to modify different parameters of the point paint text settings.
</p>
"
        End Function

#End Region

#Region "Event Handlers"

        ''' <summary>
        ''' 
        ''' </summary>
        ''' <paramname="args"></param>
        Private Sub OnCanvasPrePaint(ByVal args As NCanvasPaintEventArgs)
            Dim canvas As NCanvas = TryCast(args.TargetNode, NCanvas)
            If canvas Is Nothing Then Return
            Dim paintVisitor = args.PaintVisitor
            Dim settings As NPaintTextPointSettings = New NPaintTextPointSettings()
            settings.SingleLine = m_SingleLineCheckBox.Checked
            settings.VertAlign = CType(m_VerticalAlignmentCombo.SelectedItem.Tag, ENTextVertAlign)
            settings.HorzAlign = CType(m_HorizontalAlignmentCombo.SelectedItem.Tag, ENTextHorzAlign)
            Dim location As NPoint = canvas.GetContentEdge().Center

            ' set styles
            paintVisitor.ClearStyles()
            paintVisitor.SetFont(New NFont(NFontDescriptor.DefaultSansFamilyName, 10))
            paintVisitor.SetFill(NColor.Black)

            ' create text to paint
            Dim builder As StringBuilder = New StringBuilder()
            builder.AppendLine("Paint text at location [" & location.X.ToString("0.") & ", " & location.Y.ToString("0.") & "]")
            builder.AppendLine("Horizontal Alignment [" & settings.HorzAlign.ToString() & "]")
            builder.AppendLine("Vertical Alignment [" & settings.VertAlign.ToString() & "]")

            ' paint string
            paintVisitor.PaintString(location, builder.ToString(), settings)

            ' paint location
            Dim inflate = 5.0
            paintVisitor.SetFill(NColor.Red)
            paintVisitor.PaintRectangle(New NRectangle(location.X - inflate, location.Y - inflate, inflate * 2.0, inflate * 2.0))
        End Sub

        Private Sub OnSingleLineCheckBoxCheckedChanged(ByVal arg As NValueChangeEventArgs)
            m_Canvas.InvalidateDisplay()
        End Sub

        Private Sub OnVerticalAlignmentComboSelectedIndexChanged(ByVal arg As NValueChangeEventArgs)
            m_Canvas.InvalidateDisplay()
        End Sub

        Private Sub OnHorizontalAlignmentComboSelectedIndexChanged(ByVal arg As NValueChangeEventArgs)
            m_Canvas.InvalidateDisplay()
        End Sub

#End Region

#Region "Fields"

        Private m_HorizontalAlignmentCombo As NComboBox
        Private m_VerticalAlignmentCombo As NComboBox
        Private m_SingleLineCheckBox As NCheckBox
        Private m_Canvas As NCanvas

#End Region

#Region "Schema"

        ''' <summary>
        ''' Schema associated with NPaintingTextAtLocationExample.
        ''' </summary>
        Public Shared ReadOnly NPaintingTextAtLocationExampleSchema As NSchema

#End Region
    End Class
End Namespace

Imports Nevron.Nov.DataStructures
Imports Nevron.Nov.Dom
Imports Nevron.Nov.Graphics
Imports Nevron.Nov.Layout
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.Framework
    Public Class NImageFillExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' Default constructor.
        ''' </summary>
        Public Sub New()
        End Sub
        ''' <summary>
        ''' Static constructor.
        ''' </summary>
        Shared Sub New()
            NImageFillExampleSchema = NSchema.Create(GetType(NImageFillExample), NExampleBase.NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            ' Create a table layout panel
            m_Table = New NTableFlowPanel()
            m_Table.HorizontalPlacement = ENHorizontalPlacement.Left
            m_Table.VerticalPlacement = ENVerticalPlacement.Top
            m_Table.Padding = New NMargins(30)
            m_Table.HorizontalSpacing = 30
            m_Table.VerticalSpacing = 30
            m_Table.MaxOrdinal = 4
            Dim names = New String() {"Align", "Fit and Align", "Fixed", "Stretch", "Stretch X, Align Y", "Stretch Y, Align X", "Tile", "Tile, FlipX", "Tile, FlipY", "Tile, FlipXY"}
            Dim mappings As NTextureMapping() = New NTextureMapping() {New NAlignTextureMapping(ENHorizontalAlignment.Left, ENVerticalAlignment.Top), New NFitAndAlignTextureMapping(ENHorizontalAlignment.Center, ENVerticalAlignment.Center), New NFixedTextureMapping(NMultiLength.NewPercentage(10), ENHorizontalAlignment.Left, NMultiLength.NewPercentage(10), ENVerticalAlignment.Top), New NStretchTextureMapping(), New NStretchXAlignYTextureMapping(ENVerticalAlignment.Bottom, ENTileMode.None), New NStretchYAlignXTextureMapping(ENHorizontalAlignment.Right, ENTileMode.None), New NTileTextureMapping(), New NTileTextureMapping(True, False), New NTileTextureMapping(False, True), New NTileTextureMapping(True, True)}

            ' Add widgets with the proper filling and names to the panel
            For i = 0 To mappings.Length - 1
                Dim stack As NStackPanel = New NStackPanel()
                m_Table.Add(stack)
                stack.Direction = ENHVDirection.TopToBottom
                stack.FillMode = ENStackFillMode.First
                stack.FitMode = ENStackFitMode.First

                ' Create a widget with the proper filling
                Dim canvas As NCanvas = New NCanvas()
                canvas.PreferredSize = New NSize(defaultCanvasWidth, defaultCanvasHeight)
                Dim fill As NImageFill = New NImageFill(NResources.Image_Artistic_Plane_png)
                fill.TextureMapping = mappings(i)
                canvas.Tag = fill
                stack.Add(canvas)
                AddHandler canvas.PrePaint, New [Function](Of NCanvasPaintEventArgs)(AddressOf OnCanvasPrePaint)

                ' Create a label with the corresponding name
                Dim label As NLabel = New NLabel(names(i))
                stack.Add(label)
                label.HorizontalPlacement = ENHorizontalPlacement.Center
            Next

            ' The table must be scrollable
            Dim scroll As NScrollContent = New NScrollContent()
            scroll.Content = m_Table
            Return scroll
        End Function

        Protected Overrides Function CreateExampleControls() As NWidget
            ' Canvas width editor
            m_CanvasWidthUpDown = New NNumericUpDown()
            m_CanvasWidthUpDown.Minimum = 60
            m_CanvasWidthUpDown.Maximum = 300
            m_CanvasWidthUpDown.Value = defaultCanvasWidth
            m_CanvasWidthUpDown.Step = 1
            m_CanvasWidthUpDown.DecimalPlaces = 0
            AddHandler m_CanvasWidthUpDown.ValueChanged, New [Function](Of NValueChangeEventArgs)(AddressOf OnNumericUpDownValueChanged)

            ' Canvas height editor
            m_CanvasHeightUpDown = New NNumericUpDown()
            m_CanvasHeightUpDown.Minimum = 60
            m_CanvasHeightUpDown.Maximum = 300
            m_CanvasHeightUpDown.Value = defaultCanvasHeight
            m_CanvasHeightUpDown.Step = 1
            m_CanvasHeightUpDown.DecimalPlaces = 0
            AddHandler m_CanvasHeightUpDown.ValueChanged, New [Function](Of NValueChangeEventArgs)(AddressOf OnNumericUpDownValueChanged)

            ' create a stack and put the controls in it
            Dim stack As NStackPanel = New NStackPanel()
            stack.Add(NPairBox.Create("Canvas Width:", m_CanvasWidthUpDown))
            stack.Add(NPairBox.Create("Canvas Height:", m_CanvasHeightUpDown))
            Return New NUniSizeBoxGroup(stack)
        End Function

        Protected Overrides Function GetExampleDescription() As String
            Return "
<p>
	This example shows the image fillings supported by NOV.
</p>
"
        End Function

#End Region

#Region "Event Handlers"

        Private Sub OnCanvasPrePaint(ByVal args As NCanvasPaintEventArgs)
            Dim canvas As NCanvas = TryCast(args.TargetNode, NCanvas)
            If canvas Is Nothing Then Return
            Dim fill = CType(canvas.Tag, NFill)
            args.PaintVisitor.ClearStyles()
            args.PaintVisitor.SetStroke(NColor.Red, 1)
            args.PaintVisitor.SetFill(fill)
            args.PaintVisitor.PaintRectangle(0, 0, canvas.Width, canvas.Height)
        End Sub

        Private Sub OnColorBoxSelectedColorChanged(ByVal args As NValueChangeEventArgs)
            If m_Table Is Nothing Then Return
            Dim color As NColor = args.NewValue
            Dim colorBox = CType(args.TargetNode, NColorBox)
            Dim [property] = CType(colorBox.Tag, NProperty)
            Dim iterator As INIterator(Of NNode) = m_Table.GetSubtreeIterator(ENTreeTraversalOrder.DepthFirstPreOrder, New NInstanceOfSchemaFilter(NCanvas.NCanvasSchema))

            While iterator.MoveNext()
                Dim canvas = CType(iterator.Current, NCanvas)
                '	((NHatchFill)canvas.Tag).SetValue(property, color);
                canvas.InvalidateDisplay()
            End While
        End Sub

        Private Sub OnNumericUpDownValueChanged(ByVal args As NValueChangeEventArgs)
            If m_Table Is Nothing Then Return
            Dim width = m_CanvasWidthUpDown.Value
            Dim height = m_CanvasHeightUpDown.Value

            ' Resize the canvases
            Dim iterator As INIterator(Of NNode) = m_Table.GetSubtreeIterator(ENTreeTraversalOrder.DepthFirstPreOrder, New NInstanceOfSchemaFilter(NCanvas.NCanvasSchema))

            While iterator.MoveNext()
                Dim canvas = CType(iterator.Current, NCanvas)
                CType(canvas.ParentNode, NWidget).PreferredWidth = width
                canvas.PreferredHeight = height
            End While
        End Sub

#End Region

#Region "Fields"

        Private m_Table As NTableFlowPanel
        Private m_CanvasWidthUpDown As NNumericUpDown
        Private m_CanvasHeightUpDown As NNumericUpDown

#End Region

#Region "Constants"

        Const defaultCanvasWidth As Integer = 240
        Const defaultCanvasHeight As Integer = 240

#End Region

#Region "Schema"

        ''' <summary>
        ''' Schema associated with NImageFillExample.
        ''' </summary>
        Public Shared ReadOnly NImageFillExampleSchema As NSchema

#End Region
    End Class
End Namespace

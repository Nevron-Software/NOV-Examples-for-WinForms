Imports Nevron.Nov.Dom
Imports Nevron.Nov.Graphics
Imports Nevron.Nov.Layout
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.Framework
    Public Class NPaintingImagesExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' Default constructor.
        ''' </summary>
        Public Sub New()
        End Sub
        ''' <summary>
        ''' Static constructor.
        ''' </summary>
        Shared Sub New()
            NPaintingImagesExampleSchema = NSchema.Create(GetType(NPaintingImagesExample), NExampleBase.NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            m_PaintImageInRectangle = False
            m_PosX = 10
            m_PosY = 10
            m_Width = 200
            m_Height = 200
            m_Canvas = New NCanvas()
            m_Canvas.PreferredSize = New NSize(800, 600)
            m_Canvas.BackgroundFill = New NColorFill(New NColor(220, 220, 200))
            m_Canvas.HorizontalPlacement = ENHorizontalPlacement.Center
            m_Canvas.VerticalPlacement = ENVerticalPlacement.Center
            AddHandler m_Canvas.PrePaint, New [Function](Of NCanvasPaintEventArgs)(AddressOf OnCanvasPrePaint)
            Dim scroll As NScrollContent = New NScrollContent()
            scroll.Content = m_Canvas
            scroll.NoScrollHAlign = ENNoScrollHAlign.Center
            scroll.NoScrollVAlign = ENNoScrollVAlign.Center
            Return scroll
        End Function

        Protected Overrides Function CreateExampleControls() As NWidget
            Dim drawAtPointButton As NRadioButton = New NRadioButton("Draw Image at Point")
            Dim drawInRectButton As NRadioButton = New NRadioButton("Draw Image in Rectangle")
            Dim radioStack As NStackPanel = New NStackPanel()
            radioStack.Add(drawAtPointButton)
            radioStack.Add(drawInRectButton)
            m_RadioGroup = New NRadioButtonGroup()
            m_RadioGroup.HorizontalPlacement = ENHorizontalPlacement.Left
            m_RadioGroup.VerticalPlacement = ENVerticalPlacement.Top
            m_RadioGroup.Content = radioStack
            m_RadioGroup.SelectedIndex = If(m_PaintImageInRectangle, 1, 0)
            AddHandler m_RadioGroup.SelectedIndexChanged, New [Function](Of NValueChangeEventArgs)(AddressOf OnValueChanged)

            ' Image X position editor
            m_PositionXUpDown = New NNumericUpDown()
            m_PositionXUpDown.Minimum = 0
            m_PositionXUpDown.Maximum = 800
            m_PositionXUpDown.Value = m_PosX
            m_PositionXUpDown.Step = 1
            m_PositionXUpDown.DecimalPlaces = 0
            AddHandler m_PositionXUpDown.ValueChanged, New [Function](Of NValueChangeEventArgs)(AddressOf OnValueChanged)

            ' Image Y position editor
            m_PositionYUpDown = New NNumericUpDown()
            m_PositionYUpDown.Minimum = 0
            m_PositionYUpDown.Maximum = 600
            m_PositionYUpDown.Value = m_PosY
            m_PositionYUpDown.Step = 1
            m_PositionYUpDown.DecimalPlaces = 0
            AddHandler m_PositionYUpDown.ValueChanged, New [Function](Of NValueChangeEventArgs)(AddressOf OnValueChanged)

            ' Image height editor
            m_WidthUpDown = New NNumericUpDown()
            m_WidthUpDown.Enabled = m_PaintImageInRectangle
            m_WidthUpDown.Minimum = 0
            m_WidthUpDown.Maximum = 400
            m_WidthUpDown.Value = m_Width
            m_WidthUpDown.Step = 1
            m_WidthUpDown.DecimalPlaces = 0
            AddHandler m_WidthUpDown.ValueChanged, New [Function](Of NValueChangeEventArgs)(AddressOf OnValueChanged)

            ' Image height editor
            m_HeightUpDown = New NNumericUpDown()
            m_HeightUpDown.Enabled = m_PaintImageInRectangle
            m_HeightUpDown.Minimum = 0
            m_HeightUpDown.Maximum = 400
            m_HeightUpDown.Value = m_Height
            m_HeightUpDown.Step = 1
            m_HeightUpDown.DecimalPlaces = 0
            AddHandler m_HeightUpDown.ValueChanged, New [Function](Of NValueChangeEventArgs)(AddressOf OnValueChanged)
            Dim stack As NStackPanel = New NStackPanel()
            stack.FillMode = ENStackFillMode.None
            stack.FitMode = ENStackFitMode.None
            stack.Add(m_RadioGroup)
            stack.Add(NPairBox.Create("X Position:", m_PositionXUpDown))
            stack.Add(NPairBox.Create("Y Position:", m_PositionYUpDown))
            stack.Add(NPairBox.Create("Width:", m_WidthUpDown))
            stack.Add(NPairBox.Create("Height:", m_HeightUpDown))
            Return New NUniSizeBoxGroup(stack)
        End Function

        Protected Overrides Function GetExampleDescription() As String
            Return "
<p>
	This example demonstrates the image painting capabilities of the NOV graphics.
</p>
"
        End Function

#End Region

#Region "Event Handlers"

        Private Sub OnCanvasPrePaint(ByVal args As NCanvasPaintEventArgs)
            Dim canvas As NCanvas = TryCast(args.TargetNode, NCanvas)
            If canvas Is Nothing Then Return
            Dim pv = args.PaintVisitor
            pv.ClearStyles()

            If m_PaintImageInRectangle Then
                pv.PaintImage(NResources.Image_JpegSuite_q080_jpg.ImageSource, New NRectangle(m_PosX, m_PosY, m_Width, m_Height))
            Else
                pv.PaintImage(NResources.Image_JpegSuite_q080_jpg.ImageSource, New NPoint(m_PosX, m_PosY))
            End If

            ' paint a border around the canvas
            pv.SetStroke(NColor.Black, 1)
            pv.PaintRectangle(0, 0, canvas.Width, canvas.Height)
        End Sub

        Private Sub OnValueChanged(ByVal args As NValueChangeEventArgs)
            m_PaintImageInRectangle = m_RadioGroup.SelectedIndex = 1
            m_PosX = m_PositionXUpDown.Value
            m_PosY = m_PositionYUpDown.Value
            m_Width = m_WidthUpDown.Value
            m_Height = m_HeightUpDown.Value
            m_WidthUpDown.Enabled = m_PaintImageInRectangle
            m_HeightUpDown.Enabled = m_PaintImageInRectangle
            m_Canvas.InvalidateDisplay()
        End Sub

#End Region

#Region "Fields"

        Private m_Canvas As NCanvas
        Private m_RadioGroup As NRadioButtonGroup
        Private m_PositionXUpDown As NNumericUpDown
        Private m_PositionYUpDown As NNumericUpDown
        Private m_WidthUpDown As NNumericUpDown
        Private m_HeightUpDown As NNumericUpDown
        Private m_PaintImageInRectangle As Boolean
        Private m_PosX As Double
        Private m_PosY As Double
        Private m_Width As Double
        Private m_Height As Double

#End Region

#Region "Schema"

        ''' <summary>
        ''' Schema associated with NPaintingImagesExample.
        ''' </summary>
        Public Shared ReadOnly NPaintingImagesExampleSchema As NSchema

#End Region
    End Class
End Namespace

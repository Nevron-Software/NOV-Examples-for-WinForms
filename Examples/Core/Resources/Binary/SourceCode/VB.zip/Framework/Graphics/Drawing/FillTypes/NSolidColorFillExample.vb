Imports System
Imports Nevron.Nov.Dom
Imports Nevron.Nov.Graphics
Imports Nevron.Nov.Layout
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.Framework
    Public Class NSolidColorFillExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' Default constructor.
        ''' </summary>
        Public Sub New()
        End Sub
        ''' <summary>
        ''' Static constructor.
        ''' </summary>
        Shared Sub New()
            NSolidColorFillExampleSchema = NSchema.Create(GetType(NSolidColorFillExample), NExampleBase.NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            m_Canvas = New NCanvas()
            m_Canvas.PreferredSize = New NSize(W, H)
            m_Canvas.BackgroundFill = New NHatchFill(ENHatchStyle.LargeCheckerBoard, NColor.LightGray, NColor.White)
            AddHandler m_Canvas.PrePaint, New [Function](Of NCanvasPaintEventArgs)(AddressOf OnCanvasPrePaint)
            m_Canvas.HorizontalPlacement = ENHorizontalPlacement.Center
            m_Canvas.VerticalPlacement = ENVerticalPlacement.Center
            Dim scroll As NScrollContent = New NScrollContent()
            scroll.Content = m_Canvas
            scroll.NoScrollHAlign = ENNoScrollHAlign.Center
            scroll.NoScrollVAlign = ENNoScrollVAlign.Center
            Return scroll
        End Function

        Protected Overrides Function CreateExampleControls() As NWidget
            ' Create background color editor
            Dim colorBox As NColorBox = New NColorBox()
            colorBox.SelectedColor = m_ColorFills(0).Color
            AddHandler colorBox.SelectedColorChanged, New [Function](Of NValueChangeEventArgs)(AddressOf OnColorBoxSelectedColorChanged)
            Dim stack As NStackPanel = New NStackPanel()
            stack.Add(NPairBox.Create("Detached Slice's Color:", colorBox))
            Return New NUniSizeBoxGroup(stack)
        End Function

        Protected Overrides Function GetExampleDescription() As String
            Return "
<p>
	This example demonstrates the most common fill type - the solid color fill. A solid color fill paints the interior of a shape or graphics path with a single solid color (opaque or semi-transparent).
	In this example each pie slice is filled with a different solid color fill. You can change the color of the detached pie slice using the color combo box in the upper-right corner.
</p>
"
        End Function

#End Region

#Region "Event Handlers"

        Private Sub OnCanvasPrePaint(ByVal args As NCanvasPaintEventArgs)
            Dim canvas As NCanvas = TryCast(args.TargetNode, NCanvas)
            If canvas Is Nothing Then Return
            Dim pv = args.PaintVisitor
            Dim count = m_Values.Length

            ' calculate total value
            Dim total As Double = 0

            For i = 0 To count - 1
                total += m_Values(i)
            Next

            ' paint the pie slices
            Dim beginAngle As Double = 0
            pv.ClearStyles()

            For i = 0 To count - 1
                Dim sweepAngle = NMath.PI2 * (m_Values(i) / total)
                Dim path As NGraphicsPath = New NGraphicsPath()
                path.AddPie(0.1 * W, 0.1 * H, 0.8 * W, 0.8 * H, beginAngle, sweepAngle)

                If i = 0 Then
                    Const detachment As Double = 20
                    Dim midAngle = beginAngle + sweepAngle / 2
                    Dim dx = Math.Cos(midAngle) * detachment
                    Dim dy = Math.Sin(midAngle) * detachment
                    path.Translate(dx, dy)
                End If

                pv.SetFill(m_ColorFills(i))
                pv.PaintPath(path)
                beginAngle += sweepAngle
            Next

            ' paint a border around the canvas
            pv.ClearFill()
            pv.SetStroke(NColor.Black, 1)
            pv.PaintRectangle(0, 0, canvas.Width, canvas.Height)
        End Sub

        Private Sub OnColorBoxSelectedColorChanged(ByVal args As NValueChangeEventArgs)
            m_ColorFills(0) = New NColorFill(args.NewValue)
            m_Canvas.InvalidateDisplay()
        End Sub

#End Region

#Region "Fields"

        Private m_Canvas As NCanvas
        Private m_ColorFills As NColorFill() = New NColorFill() {New NColorFill(NColor.FromColor(NColor.IndianRed, 0.5F)), New NColorFill(NColor.Peru), New NColorFill(NColor.DarkKhaki), New NColorFill(NColor.OliveDrab), New NColorFill(NColor.DarkSeaGreen), New NColorFill(NColor.MediumSeaGreen), New NColorFill(NColor.SteelBlue), New NColorFill(NColor.SlateBlue), New NColorFill(NColor.MediumOrchid), New NColorFill(NColor.HotPink)} ' semi-transparent
        Private m_Values As Double() = New Double() {40, 20, 15, 19, 27, 29, 21, 32, 19, 14}

#End Region

#Region "Constants"

        Private Const W As Integer = 400
        Private Const H As Integer = 400

#End Region

#Region "Schema"

        ''' <summary>
        ''' Schema associated with NSolidColorFillExample.
        ''' </summary>
        Public Shared ReadOnly NSolidColorFillExampleSchema As NSchema

#End Region
    End Class
End Namespace

Imports System
Imports Nevron.Nov.Dom
Imports Nevron.Nov.Graphics
Imports Nevron.Nov.Layout
Imports Nevron.Nov.UI
Imports Nevron.Nov.DataStructures

Namespace Nevron.Nov.Examples.Framework
    Public Class NPredefinedAdvancedGradientsExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' Default constructor.
        ''' </summary>
        Public Sub New()
        End Sub
        ''' <summary>
        ''' Static constructor.
        ''' </summary>
        Shared Sub New()
            NPredefinedAdvancedGradientsExampleSchema = NSchema.Create(GetType(NPredefinedAdvancedGradientsExample), NExampleBase.NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            ' Create a table panel to hold the canvases and the labels
            m_Table = New NTableFlowPanel()
            m_Table.HorizontalPlacement = ENHorizontalPlacement.Left
            m_Table.VerticalPlacement = ENVerticalPlacement.Top
            m_Table.Padding = New NMargins(30)
            m_Table.HorizontalSpacing = 30
            m_Table.VerticalSpacing = 30
            m_Table.MaxOrdinal = 4
            Dim predefinedGradientSchemes As ENAdvancedGradientColorScheme() = NEnum.GetValues(Of ENAdvancedGradientColorScheme)()

            For i = 0 To predefinedGradientSchemes.Length - 1
                Dim stack As NStackPanel = New NStackPanel()
                m_Table.Add(stack)
                stack.Direction = ENHVDirection.TopToBottom
                stack.FillMode = ENStackFillMode.First
                stack.FitMode = ENStackFitMode.First

                ' Create a widget with the proper filling
                Dim canvas As NCanvas = New NCanvas()
                canvas.PreferredSize = New NSize(defaultCanvasWidth, defaultCanvasHeight)
                canvas.Tag = NAdvancedGradientFill.Create(predefinedGradientSchemes(i), 0)
                stack.Add(canvas)
                AddHandler canvas.PrePaint, New [Function](Of NCanvasPaintEventArgs)(AddressOf OnCanvasPrePaint)

                ' Create a label with the corresponding name
                Dim label As NLabel = New NLabel(predefinedGradientSchemes(i).ToString())
                stack.Add(label)
                label.HorizontalPlacement = ENHorizontalPlacement.Center
            Next

            ' The table must be scrollable
            Dim scroll As NScrollContent = New NScrollContent()
            scroll.Content = m_Table
            Return scroll
        End Function

        Protected Overrides Function CreateExampleControls() As NWidget
            Dim groupBox As NGroupBox = New NGroupBox("Gradients Variant:")
            Dim radioGroup As NRadioButtonGroup = New NRadioButtonGroup()
            groupBox.Content = radioGroup
            Dim radioButtonsStack As NStackPanel = New NStackPanel()
            radioGroup.Content = radioButtonsStack

            For i = 0 To 16 - 1
                Dim radioButton As NRadioButton = New NRadioButton("Variant " & i.ToString())
                radioButtonsStack.Add(radioButton)
            Next

            radioGroup.SelectedIndex = 0
            AddHandler radioGroup.SelectedIndexChanged, New [Function](Of NValueChangeEventArgs)(AddressOf OnRadioGroupSelectedIndexChanged)

            ' Canvas width editor
            m_CanvasWidthUpDown = New NNumericUpDown()
            m_CanvasWidthUpDown.Minimum = 100
            m_CanvasWidthUpDown.Maximum = 350
            m_CanvasWidthUpDown.Value = defaultCanvasWidth
            m_CanvasWidthUpDown.Step = 1
            m_CanvasWidthUpDown.DecimalPlaces = 0
            AddHandler m_CanvasWidthUpDown.ValueChanged, New [Function](Of NValueChangeEventArgs)(AddressOf OnNumericUpDownValueChanged)

            ' Canvas height editor
            m_CanvasHeightUpDown = New NNumericUpDown()
            m_CanvasHeightUpDown.Minimum = 100
            m_CanvasHeightUpDown.Maximum = 350
            m_CanvasHeightUpDown.Value = defaultCanvasHeight
            m_CanvasHeightUpDown.Step = 1
            m_CanvasHeightUpDown.DecimalPlaces = 0
            AddHandler m_CanvasHeightUpDown.ValueChanged, New [Function](Of NValueChangeEventArgs)(AddressOf OnNumericUpDownValueChanged)
            Dim stack As NStackPanel = New NStackPanel()
            stack.FillMode = ENStackFillMode.None
            stack.FitMode = ENStackFitMode.None
            stack.Add(groupBox)
            stack.Add(NPairBox.Create("Canvas Width:", m_CanvasWidthUpDown))
            stack.Add(NPairBox.Create("Canvas Height:", m_CanvasHeightUpDown))
            Return New NUniSizeBoxGroup(stack)
        End Function

        Protected Overrides Function GetExampleDescription() As String
            Return "
<p>
	This example demonstrates the predefined advanced gradient fills provided by NOV. Use the radio buttons on the right to select
	the gradient variant.
</p>
"
        End Function

#End Region

#Region "Event Handlers"

        Private Sub OnCanvasPrePaint(ByVal args As NCanvasPaintEventArgs)
            Dim canvas As NCanvas = TryCast(args.TargetNode, NCanvas)
            If canvas Is Nothing Then Return
            Dim fill = CType(canvas.Tag, NFill)
            args.PaintVisitor.ClearStyles()
            args.PaintVisitor.SetFill(fill)
            args.PaintVisitor.PaintRectangle(0, 0, canvas.Width, canvas.Height)
        End Sub

        Private Sub OnRadioGroupSelectedIndexChanged(ByVal args As NValueChangeEventArgs)
            If m_Table Is Nothing Then Return
            Dim predefinedGradientSchemes As ENAdvancedGradientColorScheme() = NEnum.GetValues(Of ENAdvancedGradientColorScheme)()
            Dim iterator As INIterator(Of NNode) = m_Table.GetSubtreeIterator(ENTreeTraversalOrder.DepthFirstPreOrder, New NInstanceOfSchemaFilter(NCanvas.NCanvasSchema))
            Dim gradientVariant As Integer = args.NewValue
            Dim schemeIndex = 0

            While iterator.MoveNext()
                Dim canvas = CType(iterator.Current, NCanvas)
                canvas.Tag = NAdvancedGradientFill.Create(predefinedGradientSchemes(Math.Min(System.Threading.Interlocked.Increment(schemeIndex), schemeIndex - 1)), gradientVariant)
                canvas.InvalidateDisplay()
            End While
        End Sub

        Private Sub OnNumericUpDownValueChanged(ByVal args As NValueChangeEventArgs)
            If m_Table Is Nothing Then Return
            Dim width = m_CanvasWidthUpDown.Value
            Dim height = m_CanvasHeightUpDown.Value

            ' Resize the canvases
            Dim iterator As INIterator(Of NNode) = m_Table.GetSubtreeIterator(ENTreeTraversalOrder.DepthFirstPreOrder, New NInstanceOfSchemaFilter(NCanvas.NCanvasSchema))

            While iterator.MoveNext()
                Dim canvas = CType(iterator.Current, NCanvas)
                CType(canvas.ParentNode, NWidget).PreferredWidth = width
                canvas.PreferredHeight = height
            End While
        End Sub

#End Region

#Region "Fields"

        Private m_Table As NTableFlowPanel
        Private m_CanvasWidthUpDown As NNumericUpDown
        Private m_CanvasHeightUpDown As NNumericUpDown

#End Region

#Region "Constants"

        Const defaultCanvasWidth As Integer = 220
        Const defaultCanvasHeight As Integer = 136

#End Region

#Region "Schema"

        ''' <summary>
        ''' Schema associated with NPredefinedAdvancedGradientsExample.
        ''' </summary>
        Public Shared ReadOnly NPredefinedAdvancedGradientsExampleSchema As NSchema

#End Region
    End Class
End Namespace

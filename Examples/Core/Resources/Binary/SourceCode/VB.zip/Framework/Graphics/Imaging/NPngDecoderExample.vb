Imports Nevron.Nov.Dom
Imports Nevron.Nov.UI
Imports Nevron.Nov.DataStructures
Imports Nevron.Nov.Graphics
Imports Nevron.Nov.Layout

Namespace Nevron.Nov.Examples.Framework
    ''' <summary>
    ''' The PNG images displayed in this example are created by Willem van Schaik (willem@schaik.com).
    ''' For more information: http://schaik.com/
    ''' </summary>
    Public Class NPngDecoderExample
        Inherits NExampleBase
#Region "Constructors"

        Public Sub New()
        End Sub

        Shared Sub New()
            NPngDecoderExampleSchema = NSchema.Create(GetType(NPngDecoderExample), NExampleBase.NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            Dim colHeadings = New String() {"Image", "Description", "Decoded with NOV Decoders", "Decoded with Native Decoders"}
            Dim colCount = colHeadings.Length
            Dim table As NTableFlowPanel = New NTableFlowPanel()
            table.HorizontalPlacement = ENHorizontalPlacement.Left
            table.VerticalPlacement = ENVerticalPlacement.Top
            table.Padding = New NMargins(30)
            table.HorizontalSpacing = 30
            table.VerticalSpacing = 30
            table.MaxOrdinal = colCount
            Dim imageNames As NList(Of String) = NImageDecodingExampleHelper.GetImageNames("PngSuite", "png")
            Dim descriptions As NMap(Of String, String) = NImageDecodingExampleHelper.LoadDescriptions(NResources.String_PngSuite_txt)

            For i = 0 To colCount - 1
                Dim label As NLabel = New NLabel(colHeadings(i))
                label.Font = New NFont(NFontDescriptor.DefaultSansFamilyName, 9, ENFontStyle.Bold)
                table.Add(label)
            Next

            Dim rowCount = imageNames.Count

            For i = 0 To rowCount - 1
                Dim resourceName = imageNames(i)
                Dim description As String = NImageDecodingExampleHelper.GetImageDescription(descriptions, resourceName)
                Dim nameLabel As NLabel = New NLabel(resourceName)
                nameLabel.MaxWidth = 200
                Dim descriptionLabel As NLabel = New NLabel(description)
                descriptionLabel.MaxWidth = 200
                descriptionLabel.TextWrapMode = ENTextWrapMode.WordWrap
                Dim novImage As NImage = NImageDecodingExampleHelper.LoadImage(resourceName, ENCodecPreference.OnlyNOV)
                Dim novImageBox As NImageBox = New NImageBox(novImage)
                novImageBox.ImageMapping = New NAlignTextureMapping(ENHorizontalAlignment.Center, ENVerticalAlignment.Center)
                Dim nativeImage As NImage = NImageDecodingExampleHelper.LoadImage(resourceName, ENCodecPreference.PreferNative)
                Dim nativeImageBox As NImageBox = New NImageBox(nativeImage)
                nativeImageBox.ImageMapping = New NAlignTextureMapping(ENHorizontalAlignment.Center, ENVerticalAlignment.Center)
                table.Add(nameLabel)
                table.Add(descriptionLabel)
                table.Add(novImageBox)
                table.Add(nativeImageBox)
            Next

            ' The table must be scrollable
            Dim scroll As NScrollContent = New NScrollContent()
            scroll.Content = table
            Return scroll
        End Function

        Protected Overrides Function CreateExampleControls() As NWidget
            Return Nothing
        End Function

        Protected Overrides Function GetExampleDescription() As String
            Return "
<p>
	This example demonstrates NOV's PNG image decoding capabilities.
</p>
"
        End Function

#End Region

#Region "Schema"

        Public Shared ReadOnly NPngDecoderExampleSchema As NSchema

#End Region
    End Class
End Namespace

Imports Nevron.Nov.Dom
Imports Nevron.Nov.Graphics
Imports Nevron.Nov.Layout
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.Framework
    Public Class NApngDecoderExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' Default constructor.
        ''' </summary>
        Public Sub New()
        End Sub

        ''' <summary>
        ''' Static constructor.
        ''' </summary>
        Shared Sub New()
            NApngDecoderExampleSchema = NSchema.Create(GetType(NApngDecoderExample), NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            Dim stack As NStackPanel = New NStackPanel()
            stack.HorizontalPlacement = ENHorizontalPlacement.Left
            Dim bouncingBeachBall = AnimateImage(NResources.Image_AnimatedPNGs_BouncingBeachBall_png)
            stack.Add(NPairBox.Create("Bouncing beach ball:", New NImageBox(bouncingBeachBall)))
            Dim smiley = AnimateImage(NResources.Image_AnimatedPNGs_Smiley_png)
            stack.Add(NPairBox.Create("Smiley:", New NImageBox(smiley)))
            Return New NUniSizeBoxGroup(stack)
        End Function

        Protected Overrides Function CreateExampleControls() As NWidget
            Return Nothing
        End Function

        Protected Overrides Function GetExampleDescription() As String
            Return "
<p>
	This example demonstrates NOV's animated PNG (APNG) image decoding capabilities and the built-in support for animated PNGs.
</p>
"
        End Function

#End Region

#Region "Implementation"

        Private Function AnimateImage(ByVal image As NImage) As NImage
            Dim encodedImageSource = CType(image.ImageSource, NEncodedImageSource)
            encodedImageSource.AnimateFrames = True
            Return image
        End Function

#End Region

#Region "Schema"

        ''' <summary>
        ''' Schema associated with NApngDecoderExample.
        ''' </summary>
        Public Shared ReadOnly NApngDecoderExampleSchema As NSchema

#End Region
    End Class
End Namespace

Imports Nevron.Nov.Chart
Imports Nevron.Nov.Dom
Imports Nevron.Nov.Graphics
Imports Nevron.Nov.UI
Imports System.Runtime.InteropServices

Namespace Nevron.Nov.Examples.Gauge
    ''' <summary>
    ''' This example demonstrates how to use state indicators in combination with other gauges
    ''' </summary>
    Public Class NCarDashboardExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' 
        ''' </summary>
        Public Sub New()
        End Sub
        ''' <summary>
        ''' 
        ''' </summary>
        Shared Sub New()
            NCarDashboardExampleSchema = NSchema.Create(GetType(NCarDashboardExample), NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        ''' <summary>
        ''' 
        ''' </summary>
        ''' <returns></returns>
        Protected Overrides Function CreateExampleContent() As NWidget
            Dim stack As NStackPanel = New NStackPanel()

            Dim controlStack As NStackPanel = New NStackPanel()
            controlStack.Direction = Layout.ENHVDirection.LeftToRight
            controlStack.HorizontalPlacement = Layout.ENHorizontalPlacement.Left
            controlStack.VerticalPlacement = Layout.ENVerticalPlacement.Top

            controlStack.Add(CreateGaugePanel("km/h", New NRange(0, 260), New NRange(200, 220), m_SpeedIndicator, m_SpeedLedDisplay, m_SpeedStateIndicator))
            controlStack.Add(CreateGaugePanel("rpm", New NRange(0, 7000), New NRange(5000, 7000), m_RpmIndicator, m_RpmLedDisplay, m_RpmStateIndicator))

            stack.Add(controlStack)

            Return stack
        End Function
        ''' <summary>
        ''' 
        ''' </summary>
        ''' <returns></returns>
        Protected Overrides Function CreateExampleControls() As NWidget
            Dim stack As NStackPanel = New NStackPanel()

            m_AccelerationScrollBar = New NHScrollBar()
            m_AccelerationScrollBar.Minimum = -100
            m_AccelerationScrollBar.Maximum = 100
            m_AccelerationScrollBar.Value = 0
            stack.Add(NPairBox.Create("Acceleration: ", m_AccelerationScrollBar))

            m_Timer = New NTimer()
            Me.m_Timer.Tick += AddressOf OnTimerTick
            m_Timer.Start()

            Return stack
        End Function
        ''' <summary>
        ''' 
        ''' </summary>
        ''' <returns></returns>
        Protected Overrides Function GetExampleDescription() As String
            Return "<p>The example demonstrates how to use state indicators in combination with other controls. Move the accelerator scrollbar on the right to see the effect of the speed / rpm entering into the red axis range.</p>"
        End Function

#End Region

#Region "Event Handlers"

#End Region

#Region "Implementation"

        ''' <summary>
        ''' Called when the example is unloaded
        ''' </summary>
        Protected Overrides Sub OnUnregistered()
            MyBase.OnUnregistered()

            ' stop the update timer
            m_Timer.Stop()
            m_Timer = Nothing
        End Sub
        ''' <summary>
        ''' 
        ''' </summary>
        ''' <paramname="text"></param>
        ''' <paramname="needleValueIndicator"></param>
        ''' <paramname="numericLedDisplay"></param>
        ''' <paramname="stateIndicator"></param>
        ''' <returns></returns>
        Private Shared Function CreateGaugePanel(ByVal text As String, ByVal axisRange As NRange, ByVal redRange As NRange, <Out> ByRef needleValueIndicator As NNeedleValueIndicator, <Out> ByRef numericLedDisplay As NNumericLedDisplay, <Out> ByRef stateIndicator As NStateIndicator) As NUserPanel
            Dim userPanel As NUserPanel = New NUserPanel()
            userPanel.PreferredSize = defaultRadialGaugeSize

            Dim radialGauge As NRadialGauge = New NRadialGauge()
            userPanel.Add(radialGauge)

            ' create the radial gauge
            radialGauge.CapEffect = New NGlassCapEffect()
            radialGauge.SetFx(NBoxElement.WidthProperty, "$Parent.Width")
            radialGauge.SetFx(NBoxElement.HeightProperty, "$Parent.Height")

            radialGauge.PreferredSize = defaultRadialGaugeSize
            radialGauge.Dial = New NDial(ENDialShape.Circle, New NEdgeDialRim())
            radialGauge.Dial.BackgroundFill = CreateAdvancedGradient()

            ' configure axis
            Dim axis As NGaugeAxis = New NGaugeAxis()
            axis.Anchor = New NDockGaugeAxisAnchor(ENGaugeAxisDockZone.Top, True, 0, 100)
            radialGauge.Axes.Add(axis)
            axis.Range = axisRange

            Dim scale = CType(axis.Scale, NStandardScale)
            ConfigureScale(scale, redRange)
            radialGauge.Indicators.Add(CreateRangeIndicator(redRange.Begin))

            needleValueIndicator = New NNeedleValueIndicator()
            needleValueIndicator.Value = 0
            needleValueIndicator.Fill = New NStockGradientFill(ENGradientStyle.Horizontal, ENGradientVariant.Variant1, NColor.White, NColor.Red)
            needleValueIndicator.Stroke.Color = NColor.Red
            needleValueIndicator.PaintOrder = ENIndicatorPaintOrder.PostPaint
            radialGauge.Indicators.Add(needleValueIndicator)

            radialGauge.BeginAngle = New NAngle(-240, NUnit.Degree)
            radialGauge.SweepAngle = New NAngle(300, NUnit.Degree)

            Dim radialGaugeContentPanel As NUserPanel = New NUserPanel()
            radialGaugeContentPanel.SetFx(NBoxElement.WidthProperty, "$Parent.Width")
            radialGaugeContentPanel.SetFx(NBoxElement.HeightProperty, "$Parent.Height")
            radialGauge.Content = radialGaugeContentPanel

            ' configure led display
            numericLedDisplay = New NNumericLedDisplay()
            radialGaugeContentPanel.Add(numericLedDisplay)
            numericLedDisplay.PreferredSize = New NSize(150, 120)
            numericLedDisplay.Value = 0.0
            numericLedDisplay.CellCountMode = ENDisplayCellCountMode.Fixed
            numericLedDisplay.CellCount = 7
            numericLedDisplay.BackgroundFill = New NColorFill(NColor.Black)

            numericLedDisplay.Border = NBorder.CreateSunken3DBorder(New NUIThemeColorMap(ENUIThemeScheme.WindowsClassic))
            numericLedDisplay.BorderThickness = New NMargins(2)
            numericLedDisplay.Padding = New NMargins(2)
            numericLedDisplay.CapEffect = New NGelCapEffect()

            numericLedDisplay.SetFx(NBoxElement.XProperty, "$Parent.Width / 2 - (Width / 2)")
            numericLedDisplay.SetFx(NBoxElement.YProperty, "$Parent.Height / 2 + 10")
            numericLedDisplay.SetFx(NBoxElement.WidthProperty, "$Parent.Width / 2")
            numericLedDisplay.SetFx(NBoxElement.HeightProperty, "$Parent.Height/ 10")

            ' configure state indicator
            stateIndicator = New NStateIndicator()
            radialGaugeContentPanel.Add(stateIndicator)
            stateIndicator.SetFx(NBoxElement.XProperty, "$Parent.Width / 2 - (Width / 2)")
            stateIndicator.SetFx(NBoxElement.YProperty, "$Parent.Height * 3/ 4")
            stateIndicator.SetFx(NBoxElement.WidthProperty, "10")
            stateIndicator.SetFx(NBoxElement.HeightProperty, "10")
            stateIndicator.States.Add(New NIndicatorState(New NRange(axisRange.Begin, redRange.Begin), ENSymbolShape.Ellipse, stateIndicatorSize, New NColorFill(NColor.LimeGreen), Nothing))
            stateIndicator.States.Add(New NIndicatorState(redRange, ENSymbolShape.Ellipse, stateIndicatorSize, New NColorFill(NColor.OrangeRed), Nothing))

            ' add labels
            Dim label As NLabel = New NLabel(text)
            userPanel.Add(label)
            label.Font = New NFont("Times New Roman", 20, ENFontStyle.Italic)
            label.TextFill = New NColorFill(NColor.White)

            label.SetFx(NBoxElement.XProperty, "$Parent.Width / 2 - (Width / 2)")
            label.SetFx(NBoxElement.YProperty, "$Parent.Height / 2 + 50")

            Return userPanel
        End Function
        ''' <summary>
        ''' 
        ''' </summary>
        ''' <returns></returns>
        Private Shared Function CreateAdvancedGradient() As NFill
            Dim agfs As NAdvancedGradientFill = New NAdvancedGradientFill()

            agfs.BackgroundColor = NColor.FromRGB(234, 234, 234)

            Dim point1 As NAdvancedGradientPoint = New NAdvancedGradientPoint()
            point1.PositionX = 0.5F
            point1.PositionY = 0.5F
            point1.Color = NColor.FromRGB(51, 51, 51)
            point1.Intensity = 0.7F
            agfs.Points.Add(point1)

            Dim point2 As NAdvancedGradientPoint = New NAdvancedGradientPoint()
            point2.PositionX = 0.5F
            point2.PositionY = 0.5F
            point2.Color = NColor.FromRGB(41, 41, 41)
            point2.Intensity = 0.5F
            agfs.Points.Add(point2)

            Return agfs
        End Function
        ''' <summary>
        ''' 
        ''' </summary>
        ''' <paramname="scale"></param>
        ''' <paramname="redRange"></param>
        Private Shared Sub ConfigureScale(ByVal scale As NStandardScale, ByVal redRange As NRange)
            scale.SetPredefinedScale(ENPredefinedScaleStyle.PresentationNoStroke)
            scale.Labels.Style.TextStyle.Font = New NFont("Arial", 11, ENFontStyle.Bold)
            scale.Labels.Style.TextStyle.Fill = New NColorFill(NColor.White)
            scale.Labels.Style.Angle = New NScaleLabelAngle(ENScaleLabelAngleMode.Scale, 0)
            scale.MinorTickCount = 1
            scale.Ruler.Stroke.Width = 0
            scale.Ruler.Fill = New NColorFill(NColor.FromColor(NColor.SlateGray, 125))

            Dim scaleSection As NScaleSection = New NScaleSection()
            scaleSection.Range = redRange
            scaleSection.MajorTickFill = New NColorFill(NColor.Red)
            scaleSection.MinorTickFill = New NColorFill(NColor.Red)

            Dim labelStyle As NTextStyle = New NTextStyle()
            labelStyle.Fill = New NStockGradientFill(NColor.Red, NColor.DarkRed)
            labelStyle.Font = New NFont("Arial", 11, ENFontStyle.Bold)
            scaleSection.LabelTextStyle = labelStyle

            scale.Sections.Add(scaleSection)
        End Sub
        ''' <summary>
        ''' 
        ''' </summary>
        ''' <paramname="minValue"></param>
        ''' <returns></returns>
        Private Shared Function CreateRangeIndicator(ByVal minValue As Double) As NRangeIndicator
            Dim rangeIndicator As NRangeIndicator = New NRangeIndicator()

            rangeIndicator.Value = minValue
            rangeIndicator.OriginMode = ENRangeIndicatorOriginMode.ScaleMax
            rangeIndicator.Fill = New NColorFill(NColor.Red)
            rangeIndicator.Stroke.Width = 0
            rangeIndicator.BeginWidth = 2
            rangeIndicator.EndWidth = 10

            Return rangeIndicator
        End Function
        ''' <summary>
        ''' 
        ''' </summary>
        ''' <returns></returns>
        Private Function GetSpeedFromRotation() As Double
            Select Case m_Gear
                Case 1
                    Return m_Rpm * 0.005
                Case 2
                    Return m_Rpm * 0.01
                Case 3
                    Return m_Rpm * 0.015
                Case 4
                    Return m_Rpm * 0.02
                Case 5
                    Return m_Rpm * 0.034
            End Select

            Return 0
        End Function

        Private Function GetRotationFromSpeed() As Double
            Select Case m_Gear
                Case 1
                    Return m_Speed / 0.005
                Case 2
                    Return m_Speed / 0.01
                Case 3
                    Return m_Speed / 0.015
                Case 4
                    Return m_Speed / 0.02
                Case 5
                    Return m_Speed / 0.034
            End Select

            Return 0
        End Function

        Private Sub OnTimerTick()
            m_Rpm += m_AccelerationScrollBar.Value

            If m_Rpm < 0 Then
                m_Rpm = 0
            ElseIf m_Rpm > 7000 Then
                m_Rpm = 7000
            End If

            m_Speed = GetSpeedFromRotation()
            m_SpeedIndicator.Value = m_Speed
            m_SpeedLedDisplay.Value = m_Speed
            m_SpeedStateIndicator.Value = m_Speed

            ' change gear
            If m_Rpm < 1000 Then
                m_Gear -= 1
            ElseIf m_Rpm > 3500 Then
                m_Gear += 1
            End If

            If m_Gear < 1 Then m_Gear = 1
            If m_Gear > 5 Then m_Gear = 5

            m_Rpm = GetRotationFromSpeed()
            m_RpmIndicator.Value = m_Rpm
            m_RpmLedDisplay.Value = m_Rpm
            m_RpmStateIndicator.Value = m_Rpm
        End Sub

#End Region

#Region "Fields"

        Private m_Rpm As Double
        Private m_Speed As Double
        Private m_Gear As Integer

        Private m_Timer As NTimer
        Private m_AccelerationScrollBar As NHScrollBar

        Private m_RpmIndicator As NNeedleValueIndicator
        Private m_SpeedIndicator As NNeedleValueIndicator

        Private m_RpmLedDisplay As NNumericLedDisplay
        Private m_SpeedLedDisplay As NNumericLedDisplay

        Private m_RpmStateIndicator As NStateIndicator
        Private m_SpeedStateIndicator As NStateIndicator

#End Region

#Region "Schema"

        Public Shared ReadOnly NCarDashboardExampleSchema As NSchema

#End Region

#Region "Constants"

        Private Shared ReadOnly defaultRadialGaugeSize As NSize = New NSize(300, 300)
        Private Shared ReadOnly stateIndicatorSize As NSize = New NSize(10, 10)

#End Region
    End Class
End Namespace

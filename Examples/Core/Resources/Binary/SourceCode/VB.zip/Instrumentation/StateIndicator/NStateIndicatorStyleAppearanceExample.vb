Imports Nevron.Nov.Chart
Imports Nevron.Nov.Dom
Imports Nevron.Nov.Graphics
Imports Nevron.Nov.Layout
Imports Nevron.Nov.UI
Imports System

Namespace Nevron.Nov.Examples.Gauge
    ''' <summary>
    ''' This example demonstrates various styles and appearance properties of state indicator
    ''' </summary>
    Public Class NStateIndicatorStyleAppearanceExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' 
        ''' </summary>
        Public Sub New()
        End Sub
        ''' <summary>
        ''' 
        ''' </summary>
        Shared Sub New()
            NStateIndicatorStyleAppearanceExampleSchema = NSchema.Create(GetType(NStateIndicatorStyleAppearanceExample), NExampleBaseSchema)

        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            Dim stack As NStackPanel = New NStackPanel()
            stack.HorizontalPlacement = ENHorizontalPlacement.Left

            Dim controlStack As NStackPanel = New NStackPanel()
            stack.Add(controlStack)

            ' create the radial gauge
            m_RadialGauge = New NRadialGauge()
            m_RadialGauge.PreferredSize = defaultRadialGaugeSize
            m_RadialGauge.Dial = New NDial(ENDialShape.Circle, New NEdgeDialRim())
            m_RadialGauge.NeedleCap.Visible = True
            m_RadialGauge.SweepAngle = New NAngle(270, NUnit.Degree)
            m_RadialGauge.BeginAngle = New NAngle(-225, NUnit.Degree)

            Dim advancedGradient As NAdvancedGradientFill = New NAdvancedGradientFill()
            advancedGradient.BackgroundColor = NColor.RoyalBlue
            advancedGradient.Points.Add(New NAdvancedGradientPoint(NColor.SteelBlue, New NAngle(10, NUnit.Degree), 0.1F, 0, 1.0F, ENAdvancedGradientPointShape.Circle))
            m_RadialGauge.Dial.BackgroundFill = advancedGradient
            m_RadialGauge.CapEffect = New NGlassCapEffect(ENCapEffectShape.Ellipse)

            controlStack.Add(m_RadialGauge)

            ' configure scale
            Dim axis As NGaugeAxis = New NGaugeAxis()
            m_RadialGauge.Axes.Add(axis)
            axis.Range = New NRange(20, 100)

            ' add Scale
            m_Scale = CType(axis.Scale, NStandardScale)
            m_Scale.SetPredefinedScale(ENPredefinedScaleStyle.Standard)
            m_Scale.Labels.Style.TextStyle.Font = New NFont("Arimo", 10, ENFontStyle.Bold)
            m_Scale.Labels.Style.TextStyle.Fill = New NColorFill(NColor.White)
            m_Scale.MajorTickMode = ENMajorTickMode.AutoMaxCount
            m_Scale.MinorTickCount = 5

            ' add range indicator
            Dim rangeIndicator As NRangeIndicator = New NRangeIndicator()
            rangeIndicator.Value = 80
            rangeIndicator.Palette = New NThreeColorPalette(NColor.Orange, NColor.Red, NColor.Yellow, 80.0)
            rangeIndicator.OriginMode = ENRangeIndicatorOriginMode.ScaleMax
            rangeIndicator.Stroke.Width = 0
            rangeIndicator.OffsetFromScale = 3
            rangeIndicator.BeginWidth = 15
            rangeIndicator.EndWidth = 25

            m_RadialGauge.Indicators.Add(rangeIndicator)

            ' add radial gauge indicators
            m_ValueIndicator = New NNeedleValueIndicator()
            m_ValueIndicator.Fill = New NStockGradientFill(ENGradientStyle.Horizontal, ENGradientVariant.Variant1, NColor.White, NColor.Silver)
            m_ValueIndicator.Width = 7
            m_ValueIndicator.OffsetFromScale = -10

            m_RadialGauge.Indicators.Add(m_ValueIndicator)

            'add state indicator
            Dim userPanel1 As NUserPanel = New NUserPanel()

            m_StateIndicator = New NStateIndicator()
            userPanel1.Add(m_StateIndicator)

            m_RadialGauge.Content = userPanel1

            m_StateIndicator.SetFx(XProperty, "$Parent.Width / 2 - (Width / 2)")
            m_StateIndicator.SetFx(YProperty, "$Parent.Height * 3/ 4")
            m_StateIndicator.SetFx(WidthProperty, "20")
            m_StateIndicator.SetFx(HeightProperty, "20")

            m_StateIndicator.BackgroundFill = New NColorFill(NColor.Transparent)
            m_StateIndicator.States.Add(New NIndicatorState(New NRange(0, 100), ENSymbolShape.Ellipse, New NSize(10, 10), New NColorFill(NColor.Silver), Nothing))


            ' timer 
            m_DataFeedTimer = New NTimer()
            m_DataFeedTimer.Tick += New [Function](AddressOf OnDataFeedTimerTick)
            m_DataFeedTimer.Start()

            Return stack
        End Function

        Protected Overrides Function CreateExampleControls() As NWidget
            Dim stack As NStackPanel = New NStackPanel()

            ' Dash/Border properties group
            Dim dashGroupBox As NGroupBox = New NGroupBox("Dash Properties")
            stack.Add(dashGroupBox)

            Dim dashPropertiesGroupBoxGroupBoxContent As NStackPanel = New NStackPanel()
            dashGroupBox.Content = New NUniSizeBoxGroup(dashPropertiesGroupBoxGroupBoxContent)

            ' create a hatch fill properties group
            Dim fillPropertiesGroupBox As NGroupBox = New NGroupBox("Fill Properties")
            stack.Add(fillPropertiesGroupBox)

            Dim fillPropertiesGroupBoxGroupBoxContent As NStackPanel = New NStackPanel()
            fillPropertiesGroupBox.Content = New NUniSizeBoxGroup(fillPropertiesGroupBoxGroupBoxContent)

            ' create a combo box for state indicator style  
            m_StateIndicatorStyleComboBox = New NComboBox()
            m_StateIndicatorStyleComboBox.FillFromEnum(Of ENSymbolShape)()
            'm_StateIndicatorStyleComboBox.Items.Add(new NComboBoxItem("Rectangular Led"));
            'm_StateIndicatorStyleComboBox.Items.Add(new NComboBoxItem("Circular Led"));
            'm_StateIndicatorStyleComboBox.Items.Add(new NComboBoxItem("Rounded Led"));
            'm_StateIndicatorStyleComboBox.Items.Add(new NComboBoxItem("Text"));
            m_StateIndicatorStyleComboBox.SelectedIndexChanged += New [Function](Of NValueChangeEventArgs)(AddressOf OnStateIndicatorStyleComboBoxSelectedIndexChanged)
            stack.Add(New NPairBox("Indicator Style:", m_StateIndicatorStyleComboBox, True))

            ' create a combo box for  indicator fill color
            m_StateIndicatorFillComboBox = New NComboBox()
            m_StateIndicatorFillComboBox.Items.Add(New NComboBoxItem("Red"))
            m_StateIndicatorFillComboBox.Items.Add(New NComboBoxItem("Lime"))
            m_StateIndicatorFillComboBox.Items.Add(New NComboBoxItem("Aqua"))
            m_StateIndicatorFillComboBox.Items.Add(New NComboBoxItem("Yellow"))
            m_StateIndicatorFillComboBox.SelectedIndex = 0
            m_StateIndicatorFillComboBox.SelectedIndexChanged += New [Function](Of NValueChangeEventArgs)(AddressOf OnStateIndicatorFillComboBoxSelectedIndexChanged)
            fillPropertiesGroupBoxGroupBoxContent.Add(New NPairBox("Fill Color: ", m_StateIndicatorFillComboBox, True))


            '  create a combo box for fill hatch style
            m_StateIndicatorHatchFillComboBox = New NComboBox()
            m_StateIndicatorHatchFillComboBox.FillFromEnum(Of ENHatchStyle)()
            m_StateIndicatorHatchFillComboBox.SelectedIndex = m_StateIndicatorHatchFillComboBox.SelectedIndex
            m_StateIndicatorHatchFillComboBox.SelectedIndexChanged += New [Function](Of NValueChangeEventArgs)(AddressOf OnStateIndicatorHatchFillComboBoxSelectedIndexChanged)
            fillPropertiesGroupBoxGroupBoxContent.Add(New NPairBox("Fill Hatch Style: ", m_DashStyleComboBox, True))

            'TODO: create indicator fill foreground color - hatch style 
            'TODO: create indicator fill background color - hatch style 

            ' create a combo box for stroke dash style
            m_DashStyleComboBox = New NComboBox()
            m_DashStyleComboBox.FillFromEnum(Of ENDashStyle)()
            m_DashStyleComboBox.SelectedIndex = 0 ' set default value
            Me.m_DashStyleComboBox.SelectedIndexChanged += AddressOf OnStrokeDashStyleComboBoxSelectedIndexChanged
            dashPropertiesGroupBoxGroupBoxContent.Add(New NPairBox("Dash Style: ", m_DashStyleComboBox, True))

            ' create a combo box for stroke dash color 
            m_DashColorComboBox = New NComboBox()
            m_DashColorComboBox.Items.Add(New NComboBoxItem("Black"))
            m_DashColorComboBox.Items.Add(New NComboBoxItem("Gray"))
            m_DashColorComboBox.Items.Add(New NComboBoxItem("Green"))
            m_DashColorComboBox.Items.Add(New NComboBoxItem("White"))
            m_DashColorComboBox.Items.Add(New NComboBoxItem("Blue"))
            m_DashColorComboBox.SelectedIndex = 0
            m_StateIndicatorFillComboBox.SelectedIndexChanged += New [Function](Of NValueChangeEventArgs)(AddressOf OnDashColorComboBoxSelectedIndexChanged)
            dashPropertiesGroupBoxGroupBoxContent.Add(New NPairBox("Dash Color: ", m_DashColorComboBox, True))

            ' create a numeric up-down for dash width 
            m_DashWidthUpDown = New NNumericUpDown()
            m_DashWidthUpDown.Value = 0
            m_DashWidthUpDown.ValueChanged += New [Function](Of NValueChangeEventArgs)(AddressOf OnUpDownWidthChanged)
            m_DashWidthUpDown.Value = Math.Min(Math.Max(m_DashWidthUpDown.Value, 0), 5)
            dashPropertiesGroupBoxGroupBoxContent.Add(New NPairBox("Dash Width: ", m_DashWidthUpDown, True))

            Return stack
        End Function

        Protected Overrides Function GetExampleDescription() As String
            Return "<p> This sample demostrates various styles and appearance properties of state indicators. 
                         The state indicator, located at the bottom center of the above gauge, changes tate when its value is between 80 and 100. 
                         The state indicator is considered inactive outside of this range. </p>" End Function

#End Region

#Region "Event Handlers"

        Private Sub OnDataFeedTimerTick()
            ' update the value indicator
            m_FirstIndicatorAngle += 0.02
            Dim value = 50.0 - Math.Cos(m_FirstIndicatorAngle) * 50.0
            m_ValueIndicator.Value = value
        End Sub

        Private Sub OnStateIndicatorStyleComboBoxSelectedIndexChanged(ByVal arg As NValueChangeEventArgs)
            ' Get the selected symbol shape from the combo box
            Dim symbolShape As ENSymbolShape = arg.NewValue

            ' Create a new state with the selected symbol shape
            Dim indicatorState As NIndicatorState = New NIndicatorState(New NRange(0, 100), symbolShape, New NSize(10, 10), New NColorFill(NColor.Red), Nothing)

            ' Set the state of the state indicator
            m_StateIndicator.States.Clear()
            m_StateIndicator.States.Add(indicatorState)

            ''' Get the selected symbol shape from the combo box
            'ENSymbolShape symbolShape = (ENSymbolShape)arg.NewValue;

            ''' Create a new symbol with the selected shape and the existing size
            'NSymbol symbol = NSymbol.Create(symbolShape, new NSize(10, 10), m_StateIndicator.States[0].Symbol.Fill, m_StateIndicator.States[0].Symbol.Stroke);

            ''' Update the symbol of the existing state
            'm_StateIndicator.States[0].Symbol = symbol;
        End Sub

        Private Sub OnStateIndicatorFillComboBoxSelectedIndexChanged(ByVal arg As NValueChangeEventArgs)
            Dim color = NColor.Silver

            If m_RadialGauge.Indicators(0).Value <= 80 Then
                color = NColor.Silver
            Else
                Select Case m_StateIndicatorFillComboBox.SelectedIndex
                    Case 0
                        color = NColor.Red

                    Case 1
                        color = NColor.Lime

                    Case 2
                        color = NColor.Aqua

                    Case 3
                        color = NColor.Yellow
                End Select
            End If

            Dim colorFill As NColorFill = New NColorFill(color)

            ' Get the selected symbol shape from the combo box
            Dim symbolShape As ENSymbolShape = m_StateIndicatorStyleComboBox.SelectedIndex

            ' Create a new state with the selected symbol shape and color

            ' Set the state of the state indicator
            m_StateIndicator.States.Clear()
            '  m_StateIndicator.States.Add(indicatorState);

        End Sub

        Private Sub OnStateIndicatorHatchFillComboBoxSelectedIndexChanged(ByVal arg As NValueChangeEventArgs)
            ' Get the selected symbol shape from the combo box
            Dim hatchStyle As ENHatchStyle = arg.NewValue

        End Sub

        Private Sub OnStrokeDashStyleComboBoxSelectedIndexChanged(ByVal arg As NValueChangeEventArgs)
            ' get the selected stroke dash style from the combo box
            Dim dashStyle As ENDashStyle = arg.NewValue

            ' set the stroke dash style of the state indicator border
        End Sub

        Private Sub OnDashColorComboBoxSelectedIndexChanged(ByVal arg As NValueChangeEventArgs)
            Dim color As NColor

            Select Case m_DashColorComboBox.SelectedIndex
                Case 0
                    color = NColor.Black

                Case 1
                    color = NColor.Gray

                Case 2
                    color = NColor.Green

                Case 3
                    color = NColor.White

                Case 4
                    color = NColor.Red

                Case 5
                    color = NColor.Blue
            End Select
        End Sub

        Private Sub OnUpDownWidthChanged(ByVal arg As NValueChangeEventArgs)
            Dim value As Integer = m_DashWidthUpDown.Value

            ' Set the dash width of the stroke
            'm_StateIndicator.Stroke.DashStyle = ENDashStyle.DashDot;
            'm_StateIndicator.Stroke.Width = value;

        End Sub

#End Region

#Region "Implementation"

#End Region

#Region "Fields"

        Private m_RadialGauge As NRadialGauge
        Private m_Scale As NStandardScale
        Private m_ValueIndicator As NNeedleValueIndicator
        Private m_StateIndicator As NStateIndicator

        Private m_StateIndicatorStyleComboBox As NComboBox
        Private m_StateIndicatorFillComboBox As NComboBox
        Private m_StateIndicatorHatchFillComboBox As NComboBox
        Private m_DashStyleComboBox As NComboBox
        Private m_DashColorComboBox As NComboBox

        Private m_DashWidthUpDown As NNumericUpDown

        Private m_DataFeedTimer As NTimer
        Private m_FirstIndicatorAngle As Double

#End Region

#Region "Schema"

        Public Shared ReadOnly NStateIndicatorStyleAppearanceExampleSchema As NSchema

#End Region

#Region "Static Methods"

#End Region

#Region "Constants"

        Private Shared ReadOnly defaultRadialGaugeSize As NSize = New NSize(300, 300)

#End Region
    End Class
End Namespace

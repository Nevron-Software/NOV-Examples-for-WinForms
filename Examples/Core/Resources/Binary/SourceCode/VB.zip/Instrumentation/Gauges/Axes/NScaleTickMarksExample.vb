Imports Nevron.Nov.Chart
Imports Nevron.Nov.Dom
Imports Nevron.Nov.Editors
Imports Nevron.Nov.Graphics
Imports Nevron.Nov.Layout
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.Gauge
    ''' <summary>
    ''' This example demonstrates properties relating to the major and minor tick marks
    ''' </summary>
    Public Class NScaleTickMarksExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' 
        ''' </summary>
        Public Sub New()
        End Sub
        ''' <summary>
        ''' 
        ''' </summary>
        Shared Sub New()
            NScaleTickMarksExampleSchema = NSchema.Create(GetType(NScaleTickMarksExample), NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            Dim stack As NStackPanel = New NStackPanel()

            Dim controlStack As NStackPanel = New NStackPanel()
            controlStack.Direction = ENHVDirection.LeftToRight
            stack.Add(controlStack)

            ' create the radial gauge
            m_RadialGauge = New NRadialGauge()
            controlStack.Add(m_RadialGauge)

            m_RadialGauge.CapEffect = New NGlassCapEffect()
            m_RadialGauge.Dial = New NDial(ENDialShape.Circle, New NEdgeDialRim())
            m_RadialGauge.PreferredSize = defaultRadialGaugeSize
            m_RadialGauge.SweepAngle = New NAngle(280, NUnit.Degree)
            m_RadialGauge.BeginAngle = New NAngle(120, NUnit.Degree)

            Dim gradientFill As NAdvancedGradientFill = New NAdvancedGradientFill()
            gradientFill.BackgroundColor = NColor.DarkBlue
            gradientFill.Points.Add(New NAdvancedGradientPoint(NColor.DeepSkyBlue, New NAngle(10, NUnit.Degree), 0.1F, 0, 1.0F, ENAdvancedGradientPointShape.Circle))
            m_RadialGauge.Dial.BackgroundFill = gradientFill
            m_RadialGauge.CapEffect = New NGlassCapEffect(ENCapEffectShape.Ellipse)

            m_RadialGauge.Dial.BackgroundFill = gradientFill
            m_RadialGauge.CapEffect = New NGlassCapEffect(ENCapEffectShape.Region)

            ' add axis 
            Dim axis As NGaugeAxis = New NGaugeAxis()
            m_RadialGauge.Axes.Clear()
            m_RadialGauge.Axes.Add(axis)

            ' add scale
            m_Scale = CType(axis.Scale, NStandardScale)
            m_Scale.SetPredefinedScale(ENPredefinedScaleStyle.PresentationNoStroke)
            m_Scale.Ruler.Fill = New NColorFill(NColor.FromColor(NColor.Transparent, 0.3F))
            m_Scale.Labels.Style.TextStyle.Font = New NFont("Microsoft Sans Serif", 8, ENFontStyle.Bold)
            m_Scale.Labels.Style.TextStyle.Fill = New NColorFill(NColor.DarkOrange)
            m_Scale.MajorTickMode = ENMajorTickMode.AutoMaxCount
            m_Scale.OuterMinorTicks.Visible = True
            m_Scale.MinorTickCount = 5

            ' add needle indicators
            Dim needle As NNeedleValueIndicator = New NNeedleValueIndicator(60)
            needle.OffsetOriginMode = ENIndicatorOffsetOriginMode.ScaleMiddle
            needle.OffsetFromScale = 15
            m_RadialGauge.Indicators.Add(needle)

            Return stack
        End Function
        Protected Overrides Function CreateExampleControls() As NWidget
            Dim stack As NStackPanel = New NStackPanel()

            Dim propertyStack As NStackPanel = New NStackPanel()
            stack.Add(New NUniSizeBoxGroup(propertyStack))

            ' major tick properties
            Dim majorTicksGroupBox As NGroupBox = New NGroupBox("Major Ticks")
            propertyStack.Add(majorTicksGroupBox)

            Dim majorTicksGroupBoxGroupBoxContent As NStackPanel = New NStackPanel()
            majorTicksGroupBox.Content = New NUniSizeBoxGroup(majorTicksGroupBoxGroupBoxContent)

            ' minor tick properties
            Dim minorTicksGroupBox As NGroupBox = New NGroupBox("Minor Ticks")
            propertyStack.Add(minorTicksGroupBox)

            Dim minorTicksGroupBoxContent As NStackPanel = New NStackPanel()
            minorTicksGroupBox.Content = New NUniSizeBoxGroup(minorTicksGroupBoxContent)

            '  major tick visability checkbox 
            m_OuterMajorTicksVisibility = New NCheckBox("Major Tick Visible")
            m_OuterMajorTicksVisibility.Checked = True
            m_OuterMajorTicksVisibility.CheckedChanged += New [Function](Of NValueChangeEventArgs)(AddressOf OnOuterMajorTicksVisibilityCheckedChanged)
            majorTicksGroupBoxGroupBoxContent.Add(m_OuterMajorTicksVisibility)

            ' major ticks placement
            m_MajorTickPlacmentComboBox = New NComboBox()
            m_MajorTickPlacmentComboBox.FillFromEnum(Of ENTicksPlacement)()
            m_MajorTickPlacmentComboBox.SelectedIndex = m_MajorTickPlacmentComboBox.SelectedIndex
            m_MajorTickPlacmentComboBox.SelectedIndexChanged += New [Function](Of NValueChangeEventArgs)(AddressOf OnMajorTickPlacementComboBoxSelectedIndexChanged)
            majorTicksGroupBoxGroupBoxContent.Add(New NPairBox("Placement: ", m_MajorTickPlacmentComboBox, True))

            '  major ticks shape 
            m_MajorTickShapeComboBox = New NComboBox()
            m_MajorTickShapeComboBox.FillFromEnum(Of ENScaleValueMarkerShape)()
            m_MajorTickShapeComboBox.SelectedIndexChanged += New [Function](Of NValueChangeEventArgs)(AddressOf OnMajorTickShapeComboBoxSelectedIndexChanged)
            majorTicksGroupBoxGroupBoxContent.Add(New NPairBox("Shape: ", m_MajorTickShapeComboBox, True))

            ' major ticks fill color button
            m_MajorTicksFillColorButton = New NButton("Major Ticks Fill Color")
            m_MajorTicksFillColorButton.Click += New [Function](Of NEventArgs)(AddressOf OnOuterMajorTickFillButtonClick)
            majorTicksGroupBoxGroupBoxContent.Add(m_MajorTicksFillColorButton)

            ' major ticks width 
            m_MajorTicksWidthUpDown = New NNumericUpDown()
            m_MajorTicksWidthUpDown.ValueChanged += New [Function](Of NValueChangeEventArgs)(AddressOf OnUpDownMajorTickWidthChanged)
            m_MajorTicksWidthUpDown.Value = 5
            'm_MajorTicksWidthUpDown.Value = Math.Min(Math.Max(m_MajorTicksWidthUpDown.Value, 2), 20);
            majorTicksGroupBoxGroupBoxContent.Add(New NPairBox("Width:", m_MajorTicksWidthUpDown, True))

            ' major ticks length
            m_MajorTicskLengthUpDown = New NNumericUpDown()
            m_MajorTicksWidthUpDown.Value = 3
            m_MajorTicskLengthUpDown.ValueChanged += New [Function](Of NValueChangeEventArgs)(AddressOf OnUpDownMajorTickLengthChanged)
            majorTicksGroupBoxGroupBoxContent.Add(New NPairBox("Length:", m_MajorTicskLengthUpDown, True))

            ' minor ticks visible check box
            m_MinorTicksVisability = New NCheckBox("Minor Tick Visible")
            m_MinorTicksVisability.Checked = True
            m_MinorTicksVisability.CheckedChanged += New [Function](Of NValueChangeEventArgs)(AddressOf OnMinorTicksVisibilityCheckedChanged)
            minorTicksGroupBoxContent.Add(m_MinorTicksVisability)

            ' minor ticks placement
            m_MinorTickPlacmentComboBox = New NComboBox()
            m_MinorTickPlacmentComboBox.FillFromEnum(Of ENTicksPlacement)()
            m_MinorTickPlacmentComboBox.SelectedIndex = m_MinorTickPlacmentComboBox.SelectedIndex
            m_MinorTickPlacmentComboBox.SelectedIndexChanged += New [Function](Of NValueChangeEventArgs)(AddressOf OnMinorTickPlacementComboBoxSelectedIndexChanged)
            minorTicksGroupBoxContent.Add(New NPairBox("Placement: ", m_MinorTickPlacmentComboBox, True))

            ' minor ticks Shape 
            m_MinorTickShapeComboBox = New NComboBox()
            m_MinorTickShapeComboBox.FillFromEnum(Of ENScaleValueMarkerShape)()
            m_MinorTickShapeComboBox.SelectedIndex = m_MinorTickShapeComboBox.SelectedIndex
            m_MinorTickShapeComboBox.SelectedIndexChanged += New [Function](Of NValueChangeEventArgs)(AddressOf OnMinorTickShapeComboBoxSelectedIndexChanged)
            minorTicksGroupBoxContent.Add(New NPairBox("Shape: ", m_MinorTickShapeComboBox, True))

            ' minor ticks Fill
            m_MinorTicksFillColorButton = New NButton("Minor Ticks Fill Color")
            m_MinorTicksFillColorButton.Click += New [Function](Of NEventArgs)(AddressOf OnMinorTickFillButtonClick)
            minorTicksGroupBoxContent.Add(m_MinorTicksFillColorButton)

            ' minor tick width 
            m_MinorTicskWidthUpDown = New NNumericUpDown()
            m_MinorTicskWidthUpDown.Value = 3
            m_MinorTicskWidthUpDown.ValueChanged += New [Function](Of NValueChangeEventArgs)(AddressOf OnUpDownMinorTickWidthChanged)
            '  m_MinorTicskWidthUpDown.Value = Math.Min(Math.Max(m_MinorTicskWidthUpDown.Value, 2), 20);
            minorTicksGroupBoxContent.Add(New NPairBox("Width:", m_MinorTicskWidthUpDown, True))

            Return stack
        End Function


        Protected Overrides Function GetExampleDescription() As String
            Return "<p>Major tick marks are the primary indicators of a gauge. 
                 Minor tick marks are secondary indicators displayed in between the major tick marks.</p>" End Function

#End Region

#Region "Implementation"

#End Region

#Region "Event Handlers"
        Private Sub OnOuterMajorTicksVisibilityCheckedChanged(ByVal arg As NValueChangeEventArgs)
            Dim checkedValue = m_OuterMajorTicksVisibility.Checked

            m_Scale.OuterMajorTicks.Visible = checkedValue

            m_MajorTickShapeComboBox.Enabled = checkedValue
            m_MajorTicksFillColorButton.Enabled = checkedValue
            m_MajorTicksWidthUpDown.Enabled = checkedValue
            m_MajorTicskLengthUpDown.Enabled = checkedValue
            m_MajorTickPlacmentComboBox.Enabled = checkedValue
        End Sub

        Private Sub OnMajorTickPlacementComboBoxSelectedIndexChanged(ByVal arg As NValueChangeEventArgs)
            Dim selectedPlacement As ENTicksPlacement = m_MajorTickPlacmentComboBox.SelectedIndex

        End Sub
        Private Sub OnMajorTickShapeComboBoxSelectedIndexChanged(ByVal arg As NValueChangeEventArgs)
            m_Scale.OuterMajorTicks.Shape = CType(m_MajorTickShapeComboBox.SelectedIndex, ENScaleValueMarkerShape)
        End Sub
        Private Sub OnOuterMajorTickFillButtonClick(ByVal arg As NEventArgs)
            Call NEditorWindow.CreateForType(CType(m_Scale.OuterMajorTicks.Fill.DeepClone(), NFill), Nothing, m_Scale.OuterMajorTicks.DisplayWindow, False, New [Function](Of T)(AddressOf OnOuterMajorTicksFillEdited)).Open()
        End Sub

        Private Sub OnOuterMajorTicksFillEdited(ByVal fill As NFill)
            m_Scale.OuterMajorTicks.Fill = CType((fill.DeepClone()), NFill)
        End Sub

        Private Sub OnUpDownMajorTickWidthChanged(ByVal arg As NValueChangeEventArgs)
            Dim majorTickWidth As Double = arg.NewValue

            If majorTickWidth >= 2 AndAlso majorTickWidth <= 20 Then
                m_Scale.OuterMajorTicks.Width = majorTickWidth
            Else
                ' Revert the value change
                m_MajorTicksWidthUpDown.Value = m_Scale.OuterMajorTicks.Width
            End If
        End Sub

        Private Sub OnUpDownMajorTickLengthChanged(ByVal arg As NValueChangeEventArgs)
            Dim majorTickLength As Double = arg.NewValue

            If majorTickLength >= 2 AndAlso majorTickLength <= 20 Then
                m_Scale.OuterMajorTicks.Length = majorTickLength
            Else
                m_MajorTicskLengthUpDown.Value = m_Scale.OuterMajorTicks.Length
            End If
        End Sub

        Private Sub OnMinorTicksVisibilityCheckedChanged(ByVal arg As NValueChangeEventArgs)
            Dim checkedValue = m_MinorTicksVisability.Checked

            m_Scale.OuterMinorTicks.Visible = checkedValue

            m_MinorTickShapeComboBox.Enabled = checkedValue
            m_MinorTicksFillColorButton.Enabled = checkedValue
            m_MinorTicskWidthUpDown.Enabled = checkedValue
            m_MajorTickPlacmentComboBox.Enabled = checkedValue
        End Sub

        Private Sub OnUpDownMinorTickWidthChanged(ByVal arg As NValueChangeEventArgs)
            Dim minorTickWidth As Double = arg.NewValue

            If minorTickWidth >= 2 AndAlso minorTickWidth <= 20 Then
                m_Scale.OuterMinorTicks.Width = minorTickWidth
            Else
                ' Revert the value change
                m_MinorTicskWidthUpDown.Value = m_Scale.OuterMinorTicks.Width
            End If
        End Sub
        Private Sub OnMinorTickPlacementComboBoxSelectedIndexChanged(ByVal arg As NValueChangeEventArgs)
            Dim selectedPlacement As ENTicksPlacement = m_MinorTickPlacmentComboBox.SelectedIndex
        End Sub
        Private Sub OnMinorTickShapeComboBoxSelectedIndexChanged(ByVal arg As NValueChangeEventArgs)
            m_Scale.OuterMinorTicks.Shape = CType(m_MinorTickShapeComboBox.SelectedIndex, ENScaleValueMarkerShape)

        End Sub
        Private Sub OnMinorTickFillButtonClick(ByVal arg As NEventArgs)
            Call NEditorWindow.CreateForType(CType(m_Scale.OuterMajorTicks.Fill.DeepClone(), NFill), Nothing, m_Scale.OuterMajorTicks.DisplayWindow, False, New [Function](Of T)(AddressOf OnMinorTicksFillEdited)).Open()
        End Sub
        Private Sub OnMinorTicksFillEdited(ByVal fill As NFill)
            m_Scale.OuterMinorTicks.Fill = CType((fill.DeepClone()), NFill)
        End Sub

#End Region

#Region "Fields"

        Private m_RadialGauge As NRadialGauge
        Private m_Scale As NStandardScale

        Private m_OuterMajorTicksVisibility As NCheckBox
        Private m_MinorTicksVisability As NCheckBox

        Private m_MajorTickShapeComboBox As NComboBox
        Private m_MajorTickPlacmentComboBox As NComboBox
        Private m_MinorTickPlacmentComboBox As NComboBox
        Private m_MinorTickShapeComboBox As NComboBox

        Private m_MajorTicksWidthUpDown As NNumericUpDown
        Private m_MajorTicskLengthUpDown As NNumericUpDown
        Private m_MinorTicskWidthUpDown As NNumericUpDown

        Private m_MajorTicksFillColorButton As NButton
        Private m_MinorTicksFillColorButton As NButton

#End Region

#Region "Schema"

        Public Shared ReadOnly NScaleTickMarksExampleSchema As NSchema

#End Region

#Region "Static Methods"


#End Region

#Region "Constants"

        Private Shared ReadOnly defaultRadialGaugeSize As NSize = New NSize(300, 300)
#End Region
    End Class
End Namespace

Imports System

Imports Nevron.Nov.Chart
Imports Nevron.Nov.Dom
Imports Nevron.Nov.Graphics
Imports Nevron.Nov.Layout
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.Gauge
    ''' <summary>
    ''' This example demonstrates how to associate a palette with an indicator
    ''' </summary>
    Public Class NIndicatorPaletteExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' 
        ''' </summary>
        Public Sub New()
        End Sub
        ''' <summary>
        ''' 
        ''' </summary>
        Shared Sub New()
            NIndicatorPaletteExampleSchema = NSchema.Create(GetType(NIndicatorPaletteExample), NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            Dim stack As NStackPanel = New NStackPanel()
            stack.HorizontalPlacement = ENHorizontalPlacement.Left

            m_AxisRange = New NRange(80, 130)
            Dim indicatorCount = 4
            m_IndicatorPhase = New Double(indicatorCount - 1) {}

            ' create gauges
            CreateLinearGauge()
            CreateRadialGauge()

            ' add to stack
            stack.Add(m_LinearGauge)
            stack.Add(m_RadialGauge)

            ' add axes
            m_LinearGauge.Axes.Add(CreateGaugeAxis())
            m_RadialGauge.Axes.Add(CreateGaugeAxis())

            Dim offset As Double = 10

            ' now add two indicators
            For i = 0 To indicatorCount - 1
                m_IndicatorPhase(i) = i * 30

                m_LinearGauge.Indicators.Add(CreateRangeIndicator(offset))
                offset += 20
            Next

            m_RadialGauge.Indicators.Add(CreateRangeIndicator(0))

            stack.Registered += AddressOf OnStackRegistered
            stack.Unregistered += AddressOf OnStackUnregistered

            Return stack
        End Function
        Protected Overrides Function CreateExampleControls() As NWidget
            Dim stack As NStackPanel = New NStackPanel()

            Dim propertyStack As NStackPanel = New NStackPanel()
            stack.Add(New NUniSizeBoxGroup(propertyStack))

            Dim toggleTimerButton As NButton = New NButton("Stop Timer")
            toggleTimerButton.Click += AddressOf OnToggleTimerButtonClick
            toggleTimerButton.Tag = 0
            stack.Add(toggleTimerButton)

            Dim rangeIndicatorShapeCombo As NComboBox = New NComboBox()
            rangeIndicatorShapeCombo.FillFromEnum(Of ENRangeIndicatorShape)()
            rangeIndicatorShapeCombo.SelectedIndexChanged += AddressOf OnRangeIndicatorShapeComboSelectedIndexChanged
            rangeIndicatorShapeCombo.SelectedIndex = CInt(ENRangeIndicatorShape.Bar)
            stack.Add(NPairBox.Create("Shape:", rangeIndicatorShapeCombo))

            Dim paletteColorModeCombo As NComboBox = New NComboBox()
            paletteColorModeCombo.FillFromEnum(Of ENPaletteColorMode)()
            paletteColorModeCombo.SelectedIndexChanged += AddressOf OnPaletteColorModeComboSelectedIndexChanged
            paletteColorModeCombo.SelectedIndex = CInt(ENPaletteColorMode.Spread)
            stack.Add(NPairBox.Create("Palette Color Mode:", paletteColorModeCombo))

            Dim orientationCombo As NComboBox = New NComboBox()
            orientationCombo.FillFromEnum(Of ENLinearGaugeOrientation)()
            orientationCombo.SelectedIndexChanged += AddressOf OnOrientationComboSelectedIndexChanged
            orientationCombo.SelectedIndex = CInt(ENLinearGaugeOrientation.Vertical)
            stack.Add(NPairBox.Create("Orientation", orientationCombo))

            Dim beginAngleUpDown As NNumericUpDown = New NNumericUpDown()
            beginAngleUpDown.Value = m_RadialGauge.BeginAngle.Value
            beginAngleUpDown.ValueChanged += AddressOf OnBeginAngleUpDownValueChanged
            stack.Add(NPairBox.Create("Begin Angle:", beginAngleUpDown))

            Dim sweepAngleUpDown As NNumericUpDown = New NNumericUpDown()
            sweepAngleUpDown.Value = m_RadialGauge.BeginAngle.Value
            sweepAngleUpDown.ValueChanged += AddressOf OnSweepAngleUpDownValueChanged
            stack.Add(NPairBox.Create("Sweep Angle:", sweepAngleUpDown))

            Dim invertScaleCheckBox As NCheckBox = New NCheckBox("Invert Scale")
            invertScaleCheckBox.CheckedChanged += AddressOf OnInvertScaleCheckBoxCheckedChanged
            invertScaleCheckBox.Checked = False
            stack.Add(invertScaleCheckBox)

            Dim smoothPaletteCheckBox As NCheckBox = New NCheckBox("Smooth Palette")
            smoothPaletteCheckBox.CheckedChanged += AddressOf OnSmoothPaletteCheckBoxCheckedChanged
            smoothPaletteCheckBox.Checked = True
            stack.Add(smoothPaletteCheckBox)

            Return stack
        End Function
        Protected Overrides Function GetExampleDescription() As String
            Return "<p>This example demonstrates how to associate a palette with an indicator.</p>"
        End Function

#End Region

#Region "Implementation"

        Private Sub CreateRadialGauge()
            m_RadialGauge = New NRadialGauge()

            m_RadialGauge.PreferredSize = defaultRadialGaugeSize
            m_RadialGauge.CapEffect = New NGelCapEffect()
            m_RadialGauge.Border = CreateBorder()
            m_RadialGauge.BorderThickness = New NMargins(6)
            m_RadialGauge.BackgroundFill = New NStockGradientFill(NColor.DarkGray, NColor.Black)
            m_RadialGauge.NeedleCap.Visible = False
            m_RadialGauge.PreferredWidth = 200
            m_RadialGauge.PreferredHeight = 200
            m_RadialGauge.Padding = New NMargins(5)
        End Sub

        Private Sub CreateLinearGauge()
            m_LinearGauge = New NLinearGauge()
            m_LinearGauge.Orientation = ENLinearGaugeOrientation.Vertical
            m_LinearGauge.PreferredWidth = 200
            m_LinearGauge.PreferredHeight = 300
            m_LinearGauge.CapEffect = New NGlassCapEffect()
            m_LinearGauge.Border = CreateBorder()
            m_LinearGauge.Padding = New NMargins(20)
            m_LinearGauge.BorderThickness = New NMargins(6)
            m_LinearGauge.BackgroundFill = New NStockGradientFill(NColor.DarkGray, NColor.Black)

            m_LinearGauge.Axes.Clear()
        End Sub

        Private Function CreateGaugeAxis() As NGaugeAxis
            Dim axis As NGaugeAxis = New NGaugeAxis()
            axis.Range = m_AxisRange
            axis.Anchor = New NDockGaugeAxisAnchor(ENGaugeAxisDockZone.Top, True, ENScaleOrientation.Left, 0, 100)
            axis.Scale.SetColor(NColor.White)
            CType(axis.Scale, NLinearScale).Labels.Style.TextStyle.Font.Style = ENFontStyle.Bold
            Return axis
        End Function

        Private Function CreateRangeIndicator(ByVal offsetFromScale As Double) As NRangeIndicator
            Dim rangeIndicator As NRangeIndicator = New NRangeIndicator()
            rangeIndicator.Value = 0
            rangeIndicator.Stroke = Nothing
            rangeIndicator.OffsetFromScale = offsetFromScale
            rangeIndicator.BeginWidth = 10
            rangeIndicator.EndWidth = 10

            rangeIndicator.BeginWidth = 10
            rangeIndicator.EndWidth = 10

            ' assign palette to the indicator
            Dim palette As NColorValuePalette = New NColorValuePalette(New NColorValuePair() {New NColorValuePair(80, NColor.Green), New NColorValuePair(100, NColor.Yellow), New NColorValuePair(120, NColor.Red)})
            rangeIndicator.Palette = palette

            Return rangeIndicator
        End Function

#End Region

#Region "Event Handlers"

        Private Sub OnStackRegistered(ByVal arg As NEventArgs)
            m_Timer = New NTimer()
            Me.m_Timer.Tick += AddressOf OnTimerTick
            m_Timer.Start()
        End Sub
        Private Sub OnStackUnregistered(ByVal arg As NEventArgs)
            m_Timer.Stop()
            Me.m_Timer.Tick -= AddressOf OnTimerTick
            m_Timer = Nothing
        End Sub

        Private Sub OnSweepAngleUpDownValueChanged(ByVal arg As NValueChangeEventArgs)
            m_RadialGauge.SweepAngle = New NAngle(CType(arg.TargetNode, NNumericUpDown).Value)
        End Sub

        Private Sub OnBeginAngleUpDownValueChanged(ByVal arg As NValueChangeEventArgs)
            m_RadialGauge.BeginAngle = New NAngle(CType(arg.TargetNode, NNumericUpDown).Value)
        End Sub

        Private Sub OnInvertScaleCheckBoxCheckedChanged(ByVal arg As NValueChangeEventArgs)
            m_LinearGauge.Axes(0).Scale.Invert = CType(arg.TargetNode, NCheckBox).Checked
            m_RadialGauge.Axes(0).Scale.Invert = CType(arg.TargetNode, NCheckBox).Checked
        End Sub

        Private Sub OnPaletteColorModeComboSelectedIndexChanged(ByVal arg As NValueChangeEventArgs)
            Dim paletteColorMode As ENPaletteColorMode = CType(arg.TargetNode, NComboBox).SelectedIndex

            For i = 0 To m_LinearGauge.Indicators.Count - 1
                CType(m_LinearGauge.Indicators(i), NRangeIndicator).PaletteColorMode = paletteColorMode
            Next

            CType(m_RadialGauge.Indicators(0), NRangeIndicator).PaletteColorMode = paletteColorMode
        End Sub

        Private Sub OnOrientationComboSelectedIndexChanged(ByVal arg As NValueChangeEventArgs)
            m_LinearGauge.Orientation = CType(CType(arg.TargetNode, NComboBox).SelectedIndex, ENLinearGaugeOrientation)

            Select Case m_LinearGauge.Orientation
                Case ENLinearGaugeOrientation.Horizontal
                    m_LinearGauge.PreferredWidth = 300
                    m_LinearGauge.PreferredHeight = 200
                Case ENLinearGaugeOrientation.Vertical
                    m_LinearGauge.PreferredWidth = 200
                    m_LinearGauge.PreferredHeight = 300
            End Select
        End Sub

        Private Sub OnRangeIndicatorShapeComboSelectedIndexChanged(ByVal arg As NValueChangeEventArgs)
            Dim shape As ENRangeIndicatorShape = CType(arg.TargetNode, NComboBox).SelectedIndex

            For i = 0 To m_LinearGauge.Indicators.Count - 1
                CType(m_LinearGauge.Indicators(i), NRangeIndicator).Shape = shape
            Next

            CType(m_RadialGauge.Indicators(0), NRangeIndicator).Shape = shape
        End Sub

        Private Sub OnToggleTimerButtonClick(ByVal arg As NEventArgs)
            Dim button = CType(arg.TargetNode, NButton)
            If CInt(button.Tag) = 0 Then
                m_Timer.Stop()

                button.Content = New NLabel("Start Timer")
                button.Tag = 1
            Else
                m_Timer.Start()
                button.Content = New NLabel("Stop Timer")
                button.Tag = 0
            End If
        End Sub

        Private Sub OnTimerTick()
            Dim random As Random = New Random()

            For i = 0 To m_LinearGauge.Indicators.Count - 1
                Dim value As Double = (m_AxisRange.Begin + m_AxisRange.End) / 2.0 + Math.Sin(m_IndicatorPhase(i) * NAngle.Degree2Rad) * m_AxisRange.GetLength() / 2 + random.Next(20)
                value = m_AxisRange.GetValueInRange(value)

                CType(m_LinearGauge.Indicators(i), NRangeIndicator).Value = value
                m_IndicatorPhase(i) += 10
            Next

            CType(m_RadialGauge.Indicators(0), NRangeIndicator).Value = CType(m_LinearGauge.Indicators(0), NRangeIndicator).Value
        End Sub

        Private Sub OnSmoothPaletteCheckBoxCheckedChanged(ByVal arg As NValueChangeEventArgs)
            Dim smoothPalette = CType(arg.TargetNode, NCheckBox).Checked

            For i = 0 To m_LinearGauge.Indicators.Count - 1
                m_LinearGauge.Indicators(i).Palette.InterpolateColors = smoothPalette
            Next

            m_RadialGauge.Indicators(0).Palette.InterpolateColors = smoothPalette
        End Sub

#End Region

#Region "Fields"

        Private m_LinearGauge As NLinearGauge
        Private m_RadialGauge As NRadialGauge
        Private m_Timer As NTimer
        Private m_IndicatorPhase As Double()
        Private m_AxisRange As NRange

#End Region

#Region "Schema"

        Public Shared ReadOnly NIndicatorPaletteExampleSchema As NSchema

#End Region

#Region "Static Methods"

        Private Shared Function CreateBorder() As NBorder
            Return NBorder.CreateThreeColorBorder(NColor.LightGray, NColor.White, NColor.DarkGray, 10, 10)
        End Function

#End Region

#Region "Constants"

        Private Shared ReadOnly defaultRadialGaugeSize As NSize = New NSize(300, 300)

#End Region
    End Class
End Namespace

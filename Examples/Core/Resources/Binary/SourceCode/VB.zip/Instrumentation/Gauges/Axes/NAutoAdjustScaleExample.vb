Imports Nevron.Nov.Chart
Imports Nevron.Nov.Dom
Imports Nevron.Nov.Graphics
Imports Nevron.Nov.UI
Imports System

Namespace Nevron.Nov.Examples.Gauge
    ''' <summary>
    ''' This example demonstrates how to control the size of the gauge axes
    ''' </summary>
    Public Class NAutoAdjustScaleExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' 
        ''' </summary>
        Public Sub New()

        End Sub
        ''' <summary>
        ''' 
        ''' </summary>

        Shared Sub New()
            NAutoAdjustScaleExampleSchema = NSchema.Create(GetType(NAutoAdjustScaleExample), NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"
        Protected Overrides Function CreateExampleContent() As NWidget
            Dim stack As NStackPanel = New NStackPanel()

            Dim controlStack As NStackPanel = New NStackPanel()
            stack.Add(controlStack)

            ' create the radial gauge
            m_RadialGauge = New NRadialGauge()
            m_RadialGauge.PreferredSize = defaultRadialGaugeSize
            controlStack.Add(m_RadialGauge)

            m_RadialGauge.Dial = New NDial(ENDialShape.Circle, New NEdgeDialRim())
            m_RadialGauge.Dial.BackgroundFill = New NStockGradientFill(NColor.Black, NColor.Gray)

            Dim gelEffect As NGelCapEffect = New NGelCapEffect(ENCapEffectShape.Ellipse)
            gelEffect.Margins = New NMargins(0, 0, 0, 0.5)

            m_RadialGauge.Axes.Clear()

            ' create the radial gauge
            m_RadialGauge.SweepAngle = New NAngle(180, NUnit.Degree)
            m_RadialGauge.BeginAngle = New NAngle(32, NUnit.Degree)

            ' create the first axis
            Dim axis1 As NGaugeAxis = New NGaugeAxis()
            axis1.Anchor = New NDockGaugeAxisAnchor(ENGaugeAxisDockZone.Top, True, 30, 180)

            m_RadialGauge.Axes.Add(axis1)

            'Cache the initial begin and end
            m_CurBegin = m_RadialGauge.Axes(CInt(0)).Range.Begin
            m_CurEnd = m_RadialGauge.Axes(CInt(0)).Range.End

            m_InitBegin = m_CurBegin
            m_InitEnd = m_CurEnd

            ' scale 
            m_Scale = CType(axis1.Scale, NStandardScale)
            m_Scale.SetPredefinedScale(ENPredefinedScaleStyle.PresentationNoStroke)
            m_Scale.MajorTickMode = ENMajorTickMode.AutoMaxCount
            m_Scale.MaxTickCount = 9
            m_Scale.MinorTickCount = 3
            m_Scale.Ruler.Fill = New NColorFill(NColor.FromColor(NColor.White, 0.4F))
            m_Scale.OuterMajorTicks.Fill = New NColorFill(NColor.Orange)
            m_Scale.Labels.Style.TextStyle.Font = New NFont("Arimo", 12, ENFontStyle.Bold)
            m_Scale.Labels.Style.TextStyle.Fill = New NColorFill(NColor.White)
            m_Scale.Labels.Style.Angle = New NScaleLabelAngle(ENScaleLabelAngleMode.Scale, 0)
            m_Scale.ViewRangeInflateMode = ENScaleViewRangeInflateMode.None

            ' Value Indicator
            m_NeedleValueIndicator = New NNeedleValueIndicator()
            m_NeedleValueIndicator.Fill = New NStockGradientFill(ENGradientStyle.Horizontal, ENGradientVariant.Variant1, NColor.White, NColor.Red)
            m_NeedleValueIndicator.Stroke.Color = NColor.Red
            m_NeedleValueIndicator.OffsetFromScale = 2
            m_NeedleValueIndicator.Shape = ENNeedleShape.Triangle
            m_RadialGauge.SweepAngle = New NAngle(360, NUnit.Degree)

            m_RadialGauge.Indicators.Add(m_NeedleValueIndicator)

            ' Timer
            m_Timer = New NTimer()
            m_Timer.Interval = 200
            m_Timer.Tick += New [Function](AddressOf OnTimerTick)
            m_Timer.Start()

            m_Range = 100

            ' radio buttons
            m_StepAndRotateScaleRadioButton = New NRadioButton("Step and Rotate Scale")
            m_ContinuouslyRotateRadioButton = New NRadioButton("Continuously Rotate")
            m_ContinuouslyRotateRadioButton.Checked = True

            Return stack
        End Function
        ''' <summary>
        ''' 
        ''' </summary>
        ''' <returns></returns>
        Protected Overrides Function CreateExampleControls() As NWidget
            Dim stack As NStackPanel = New NStackPanel()

            Dim dynamicScaleRotationStylesGroup As NRadioButtonGroup = New NRadioButtonGroup(stack)
            dynamicScaleRotationStylesGroup.SelectedIndex = 0

            stack.Add(m_StepAndRotateScaleRadioButton)
            stack.Add(m_ContinuouslyRotateRadioButton)

            Return dynamicScaleRotationStylesGroup
        End Function
        ''' <summary>
        ''' 
        ''' </summary>
        ''' <returns></returns>
        Protected Overrides Function GetExampleDescription() As String
            Return "<p> </p>"
        End Function

#End Region

#Region "Event Handlers        "

        Private Sub OnTimerTick()
            If m_ContinuouslyRotateRadioButton.Checked Then
                ' code to execute when the "Continuously Rotate" radio button is selected
                'Continuously change the scale minimum.                
                Dim val As Double = ChangeRange()

                Dim axis = m_RadialGauge.Axes(0)
                axis.Range = New NRange(val, val + 100)

                m_NeedleValueIndicator.Value = (axis.Range.End + axis.Range.Begin) / 2

            ElseIf m_StepAndRotateScaleRadioButton.Checked Then
                ' TODO: 
                SetNeedleValueWithinRange(m_CurBegin, m_CurEnd)
            End If
        End Sub

        Private Function ChangeRange() As Double
            If m_Increase Then
                m_Range += 1
            Else
                m_Range -= 1
            End If

            If m_Range >= 80 Then m_Increase = False

            If m_Range <= 20 Then m_Increase = True

            Return m_Range
        End Function

        ''' <summary>
        ''' Randomly adjust the axis range with range of 50 and step 20.
        ''' </summary>
        Private Sub AdjustRandomRange(ByVal forwrad As Boolean)
            ' move the range depending on forward parameter
            If forwrad Then
                m_CurBegin += 2
                m_CurEnd += 2
            Else
                m_CurBegin -= 2
                m_CurEnd -= 2
            End If

            ' if range is moving forward and current begin is increased with 30 reset the range and change the direction.
            If forwrad AndAlso m_CurEnd - 30 = m_InitEnd OrElse Not forwrad AndAlso m_CurBegin + 30 = m_InitBegin OrElse m_CurBegin = 0 OrElse m_CurBegin = 200 Then
                m_InitEnd = m_CurEnd
                m_InitBegin = m_CurBegin
                m_Direction *= -1
            End If

            m_RadialGauge.Axes(0).Range = New NRange(m_CurBegin, m_CurEnd)
        End Sub


        ''' <summary>
        ''' The m_StepCounter tracks  how many steps the needle has taken, and the m_StepThreshold  
        ''' determines how many steps should be taken before the range is adjusted. 
        ''' </summary>
        ''' <paramname="m_CurBegin"></param>
        ''' <paramname="m_CurEnd"></param>
        Private Sub SetNeedleValueWithinRange(ByVal m_CurBegin As Double, ByVal m_CurEnd As Double)
            m_FirstIndicatorAngle += Math.PI / 180
            Dim needleValue = 20 + Math.Sin(m_FirstIndicatorAngle) + (20 + rand.Next(50))
            m_NeedleValueIndicator.EnableDampening = True
            m_NeedleValueIndicator.Value = needleValue

            ' m_StepCounter++;

            'if (m_StepCounter >= m_StepThreshold)
            '{
            '    AdjustRandomRange();
            '    m_StepCounter = 0;
            '}

            Dim direction = If(m_Direction = 1, True, False)

            If m_MoveRange Then AdjustRandomRange(direction)

            ' 
            If direction AndAlso needleValue > m_CurEnd - 30 OrElse Not direction AndAlso needleValue < m_CurBegin + 30 Then
                m_MoveRange = True
            Else
                m_MoveRange = False
            End If

            'if (needleValue > m_CurEnd)
            '{
            '    m_StepCounter++;

            '    if (m_StepCounter >= m_StepThreshold)
            '    {
            '        m_CurBegin += 2;
            '        m_CurEnd += 2;
            '        m_RadialGauge.Axes[0].Range = new NRange(m_CurBegin, m_CurEnd);
            '        m_StepCounter = 0;
            '    }
            '}
            'else if (needleValue < m_CurBegin)
            '{
            '    m_StepCounter++;
            '    if (m_StepCounter >= m_StepThreshold)
            '    {
            '        m_CurBegin -= 2;
            '        m_CurEnd -= 2;
            '        m_RadialGauge.Axes[0].Range = new NRange(m_CurBegin, m_CurEnd);
            '        m_StepCounter = 0;
            '    }
            '}

            '     Debug.WriteLine("Step Count " + m_StepCounter, "needle Value " + needleValue + "range begin " + m_CurBegin + "range end " + m_CurEnd);

        End Sub

#End Region

#Region "Fields"

        Private m_RadialGauge As NRadialGauge
        Private m_NeedleValueIndicator As NNeedleValueIndicator
        Private m_Scale As NStandardScale

        Private m_Timer As NTimer
        Private m_StepAndRotateScaleRadioButton As NRadioButton
        Private m_ContinuouslyRotateRadioButton As NRadioButton

#End Region

#Region "Schema"

        Public Shared ReadOnly NAutoAdjustScaleExampleSchema As NSchema

#End Region

#Region "Constants"

        Private Shared ReadOnly defaultRadialGaugeSize As NSize = New NSize(300, 300)
        Private rand As Random = New Random()
        Private m_CurBegin As Double
        Private m_CurEnd As Double

        Private m_InitBegin As Double
        Private m_InitEnd As Double

        Private m_Range As Double
        Private m_FirstIndicatorAngle As Double
        Const c_ScaleRange As Double = 50
        Const c_RotateIncrement As Double = 2
        Private m_Increase As Boolean = True
        Private m_Direction As Integer = 1

        Private m_MoveRange As Boolean = False
#End Region
    End Class
End Namespace

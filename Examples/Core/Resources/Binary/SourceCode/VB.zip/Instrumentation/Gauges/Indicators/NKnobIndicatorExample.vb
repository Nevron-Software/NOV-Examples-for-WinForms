Imports Nevron.Nov.Chart
Imports Nevron.Nov.Dom
Imports Nevron.Nov.Graphics
Imports Nevron.Nov.Layout
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.Gauge
    ''' <summary>
    ''' This example demonstrates how to add create a knob indicator
    ''' </summary>
    Public Class NKnobIndicatorExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' 
        ''' </summary>
        Public Sub New()
        End Sub
        ''' <summary>
        ''' 
        ''' </summary>
        Shared Sub New()
            NKnobIndicatorExampleSchema = NSchema.Create(GetType(NKnobIndicatorExample), NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            Dim stack As NStackPanel = New NStackPanel()
            stack.HorizontalPlacement = ENHorizontalPlacement.Left
            Dim controlStack As NStackPanel = New NStackPanel()
            stack.Add(controlStack)

            ' create the radial gauge
            m_RadialGauge = New NRadialGauge()

            '			radialGauge.PreferredSize = new NSize(0, 50);
            '			radialGauge.ContentAlignment = ContentAlignment.MiddleCenter;
            m_RadialGauge.SweepAngle = New NAngle(270, NUnit.Degree)
            m_RadialGauge.BeginAngle = New NAngle(-225, NUnit.Degree)
            m_RadialGauge.NeedleCap.Visible = False
            m_RadialGauge.PreferredSize = defaultRadialGaugeSize

            ' configure scale
            Dim axis As NGaugeAxis = New NGaugeAxis()
            m_RadialGauge.Axes.Add(axis)
            Dim scale = CType(axis.Scale, NStandardScale)
            scale.SetPredefinedScale(ENPredefinedScaleStyle.PresentationNoStroke)
            scale.Labels.Style.TextStyle.Font = New NFont("Arimo", 12.0, ENFontStyle.Italic)
            scale.Labels.Style.TextStyle.Fill = New NColorFill(NColor.Black)
            scale.Labels.Style.Angle = New NScaleLabelAngle(ENScaleLabelAngleMode.Scale, 0.0)
            scale.MinorTickCount = 4
            scale.Ruler.Stroke.Width = 0
            scale.Ruler.Fill = New NColorFill(NColor.DarkGray)

            ' create the knob indicator
            m_KnobIndicator = New NKnobIndicator()
            m_KnobIndicator.OffsetFromScale = -3
            m_KnobIndicator.AllowDragging = True

            ' apply fill style to the marker
            Dim advancedGradientFill As NAdvancedGradientFill = New NAdvancedGradientFill()
            advancedGradientFill.BackgroundColor = NColor.Red
            advancedGradientFill.Points.Add(New NAdvancedGradientPoint(NColor.White, New NAngle(20, NUnit.Degree), 20, 0, 100, ENAdvancedGradientPointShape.Circle))
            m_KnobIndicator.Fill = advancedGradientFill
            AddHandler m_KnobIndicator.ValueChanged, New [Function](Of NValueChangeEventArgs)(AddressOf OnKnobValueChanged)
            m_RadialGauge.Indicators.Add(m_KnobIndicator)

            ' create the numeric display
            m_NumericDisplay = New NNumericLedDisplay()
            m_NumericDisplay.PreferredSize = New NSize(0, 60)
            m_NumericDisplay.BackgroundFill = New NColorFill(NColor.Black)
            m_NumericDisplay.Border = NBorder.CreateSunken3DBorder(New NUIThemeColorMap(ENUIThemeScheme.WindowsClassic))
            m_NumericDisplay.BorderThickness = New NMargins(6)
            m_NumericDisplay.ContentAlignment = ENContentAlignment.MiddleCenter
            m_NumericDisplay.Margins = New NMargins(5)
            m_NumericDisplay.Padding = New NMargins(5)
            m_NumericDisplay.CapEffect = New NGelCapEffect()
            controlStack.Add(m_RadialGauge)
            controlStack.Add(m_NumericDisplay)
            Return stack
        End Function

        Protected Overrides Function CreateExampleControls() As NWidget
            Dim stack As NStackPanel = New NStackPanel()
            Dim propertyStack As NStackPanel = New NStackPanel()
            stack.Add(New NUniSizeBoxGroup(propertyStack))

            ' marker properties
            Dim markerGroupBox As NGroupBox = New NGroupBox("Marker")
            propertyStack.Add(markerGroupBox)
            Dim markerGroupBoxContent As NStackPanel = New NStackPanel()
            markerGroupBox.Content = New NUniSizeBoxGroup(markerGroupBoxContent)

            ' fill the marker shape combo
            m_MarkerShapeComboBox = New NComboBox()
            m_MarkerShapeComboBox.FillFromEnum(Of ENScaleValueMarkerShape)()
            m_MarkerShapeComboBox.SelectedIndex = m_KnobIndicator.Shape
            AddHandler m_MarkerShapeComboBox.SelectedIndexChanged, New [Function](Of NValueChangeEventArgs)(AddressOf OnKnobAppearanceChanged)
            markerGroupBoxContent.Add(New NPairBox("Shape:", m_MarkerShapeComboBox, True))
            m_MarkerOffsetUpDown = New NNumericUpDown()
            m_MarkerOffsetUpDown.Value = m_KnobIndicator.OffsetFromScale
            AddHandler m_MarkerOffsetUpDown.ValueChanged, New [Function](Of NValueChangeEventArgs)(AddressOf OnKnobAppearanceChanged)
            markerGroupBoxContent.Add(New NPairBox("Offset:", m_MarkerOffsetUpDown, True))
            m_MarkerPaintOrderComboBox = New NComboBox()
            m_MarkerPaintOrderComboBox.FillFromEnum(Of ENKnobMarkerPaintOrder)()
            m_MarkerPaintOrderComboBox.SelectedIndex = m_KnobIndicator.MarkerPaintOrder
            AddHandler m_MarkerPaintOrderComboBox.SelectedIndexChanged, New [Function](Of NValueChangeEventArgs)(AddressOf OnKnobAppearanceChanged)
            markerGroupBoxContent.Add(New NPairBox("Paint Order:", m_MarkerPaintOrderComboBox, True))

            ' outer rim properties
            Dim outerRimGroupBox As NGroupBox = New NGroupBox("Outer Rim")
            propertyStack.Add(outerRimGroupBox)
            Dim outerRimGroupBoxContent As NStackPanel = New NStackPanel()
            outerRimGroupBox.Content = New NUniSizeBoxGroup(outerRimGroupBoxContent)
            m_OuterRimPatternComboBox = New NComboBox()
            m_OuterRimPatternComboBox.FillFromEnum(Of ENCircularRimPattern)()
            m_OuterRimPatternComboBox.SelectedIndex = m_KnobIndicator.OuterRim.Pattern
            AddHandler m_OuterRimPatternComboBox.SelectedIndexChanged, New [Function](Of NValueChangeEventArgs)(AddressOf OnKnobAppearanceChanged)
            outerRimGroupBoxContent.Add(New NPairBox("Pattern", m_OuterRimPatternComboBox, True))
            m_OuterRimPatternRepeatCountUpDown = New NNumericUpDown()
            m_OuterRimPatternRepeatCountUpDown.Value = m_KnobIndicator.OuterRim.PatternRepeatCount
            AddHandler m_OuterRimPatternRepeatCountUpDown.ValueChanged, New [Function](Of NValueChangeEventArgs)(AddressOf OnKnobAppearanceChanged)
            outerRimGroupBoxContent.Add(New NPairBox("Repeat Count:", m_OuterRimPatternRepeatCountUpDown, True))
            m_OuterRimRadiusOffsetUpDown = New NNumericUpDown()
            m_OuterRimRadiusOffsetUpDown.Value = m_KnobIndicator.OuterRim.Offset
            AddHandler m_OuterRimRadiusOffsetUpDown.ValueChanged, New [Function](Of NValueChangeEventArgs)(AddressOf OnKnobAppearanceChanged)
            outerRimGroupBoxContent.Add(New NPairBox("Radius Offset:", m_OuterRimRadiusOffsetUpDown, True))

            ' inner rim properties
            Dim innerRimGroupBox As NGroupBox = New NGroupBox("Inner Rim")
            propertyStack.Add(innerRimGroupBox)
            Dim innerRimGroupBoxContent As NStackPanel = New NStackPanel()
            innerRimGroupBox.Content = New NUniSizeBoxGroup(innerRimGroupBoxContent)
            m_InnerRimPatternComboBox = New NComboBox()
            m_InnerRimPatternComboBox.FillFromEnum(Of ENCircularRimPattern)()
            m_InnerRimPatternComboBox.SelectedIndex = m_KnobIndicator.InnerRim.Pattern
            AddHandler m_InnerRimPatternComboBox.SelectedIndexChanged, New [Function](Of NValueChangeEventArgs)(AddressOf OnKnobAppearanceChanged)
            innerRimGroupBoxContent.Add(New NPairBox("Pattern", m_InnerRimPatternComboBox, True))
            m_InnerRimPatternRepeatCountUpDown = New NNumericUpDown()
            m_InnerRimPatternRepeatCountUpDown.Value = m_KnobIndicator.InnerRim.PatternRepeatCount
            AddHandler m_InnerRimPatternRepeatCountUpDown.ValueChanged, New [Function](Of NValueChangeEventArgs)(AddressOf OnKnobAppearanceChanged)
            innerRimGroupBoxContent.Add(New NPairBox("Repeat Count:", m_InnerRimPatternRepeatCountUpDown, True))
            m_InnerRimRadiusOffsetUpDown = New NNumericUpDown()
            m_InnerRimRadiusOffsetUpDown.Value = m_KnobIndicator.InnerRim.Offset
            AddHandler m_InnerRimRadiusOffsetUpDown.ValueChanged, New [Function](Of NValueChangeEventArgs)(AddressOf OnKnobAppearanceChanged)
            innerRimGroupBoxContent.Add(New NPairBox("Radius Offset:", m_InnerRimRadiusOffsetUpDown, True))
            Return stack
        End Function

        Protected Overrides Function GetExampleDescription() As String
            Return "<p>The example demonstrates the properties of the knob indicator.</p>"
        End Function

#End Region

#Region "Implementation"

#End Region

#Region "Event Handlers"

        Private Sub OnKnobValueChanged(ByVal arg As NValueChangeEventArgs)
            If m_RadialGauge Is Nothing Then Return
            m_NumericDisplay.Value = m_RadialGauge.Indicators(0).Value
        End Sub

        Private Sub OnKnobAppearanceChanged(ByVal arg As NValueChangeEventArgs)
            ' update the knob marker shape
            m_KnobIndicator.Shape = CType(m_MarkerShapeComboBox.SelectedIndex, ENScaleValueMarkerShape)
            m_KnobIndicator.OffsetFromScale = m_MarkerOffsetUpDown.Value
            m_KnobIndicator.MarkerPaintOrder = CType(m_MarkerPaintOrderComboBox.SelectedIndex, ENKnobMarkerPaintOrder)

            ' update the outer rim style
            m_KnobIndicator.OuterRim.Pattern = CType(m_OuterRimPatternComboBox.SelectedIndex, ENCircularRimPattern)
            m_KnobIndicator.OuterRim.PatternRepeatCount = CInt(m_OuterRimPatternRepeatCountUpDown.Value)
            m_KnobIndicator.OuterRim.Offset = m_OuterRimRadiusOffsetUpDown.Value

            ' update the inner rim style
            m_KnobIndicator.InnerRim.Pattern = CType(m_InnerRimPatternComboBox.SelectedIndex, ENCircularRimPattern)
            m_KnobIndicator.InnerRim.PatternRepeatCount = CInt(m_InnerRimPatternRepeatCountUpDown.Value)
            m_KnobIndicator.InnerRim.Offset = m_InnerRimRadiusOffsetUpDown.Value
        End Sub

#End Region

#Region "Fields"

        Private m_RadialGauge As NRadialGauge
        Private m_NumericDisplay As NNumericLedDisplay
        Private m_KnobIndicator As NKnobIndicator
        Private m_MarkerOffsetUpDown As NNumericUpDown
        Private m_MarkerPaintOrderComboBox As NComboBox
        Private m_MarkerShapeComboBox As NComboBox
        Private m_OuterRimPatternComboBox As NComboBox
        Private m_OuterRimPatternRepeatCountUpDown As NNumericUpDown
        Private m_OuterRimRadiusOffsetUpDown As NNumericUpDown
        Private m_InnerRimRadiusOffsetUpDown As NNumericUpDown
        Private m_InnerRimPatternRepeatCountUpDown As NNumericUpDown
        Private m_InnerRimPatternComboBox As NComboBox

#End Region

#Region "Schema"

        Public Shared ReadOnly NKnobIndicatorExampleSchema As NSchema

#End Region

#Region "Constants"

        Private Shared ReadOnly defaultRadialGaugeSize As NSize = New NSize(300, 300)

#End Region
    End Class
End Namespace

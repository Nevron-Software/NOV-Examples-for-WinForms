Imports Nevron.Nov.Chart
Imports Nevron.Nov.Dom
Imports Nevron.Nov.Graphics
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.Gauge
    ''' <summary>
    ''' This example demonstrates how to control the size of the gauge axes
    ''' </summary>
    Public Class NAxisDockingExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' 
        ''' </summary>
        Public Sub New()
        End Sub
        ''' <summary>
        ''' 
        ''' </summary>
        Shared Sub New()
            NAxisDockingExampleSchema = NSchema.Create(GetType(NAxisDockingExample), NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        ''' <summary>
        ''' 
        ''' </summary>
        ''' <returns></returns>
        Protected Overrides Function CreateExampleContent() As NWidget
            Dim stack As NStackPanel = New NStackPanel()
            Dim controlStack As NStackPanel = New NStackPanel()
            controlStack.Padding = New NMargins(20)
            stack.Add(controlStack)
            m_LinearGauge = New NLinearGauge()
            m_LinearGauge.Padding = New NMargins(30)
            m_LinearGauge.PreferredSize = defaultLinearHorizontalGaugeSize
            controlStack.Add(m_LinearGauge)
            Dim axis As NGaugeAxis = New NGaugeAxis()
            m_LinearGauge.Axes.Add(axis)
            axis.Anchor = New NDockGaugeAxisAnchor(ENGaugeAxisDockZone.Top, True, ENScaleOrientation.Left, 0, 100)
            axis = New NGaugeAxis()
            m_LinearGauge.Axes.Add(axis)
            axis.Anchor = New NDockGaugeAxisAnchor(ENGaugeAxisDockZone.Top, True, ENScaleOrientation.Left, 0, 50)

            ' create the radial gauge
            m_RadialGauge = New NRadialGauge()
            m_RadialGauge.PreferredSize = defaultRadialGaugeSize
            m_RadialGauge.NeedleCap.Visible = False
            controlStack.Add(m_RadialGauge)

            ' create the radial gauge
            m_RadialGauge.SweepAngle = New NAngle(270, NUnit.Degree)
            m_RadialGauge.BeginAngle = New NAngle(-90, NUnit.Degree)
            m_RadialGauge.PreferredHeight = 400

            ' configure the axis
            axis = New NGaugeAxis()
            m_RadialGauge.Axes.Add(axis)
            axis.Range = New NRange(0, 100)
            axis.Anchor = New NDockGaugeAxisAnchor(ENGaugeAxisDockZone.Top, True, ENScaleOrientation.Left, 0.0F, 100.0F)

            ' configure the axis
            axis = New NGaugeAxis()
            m_RadialGauge.Axes.Add(axis)
            axis.Range = New NRange(0, 100)
            axis.Anchor = New NDockGaugeAxisAnchor(ENGaugeAxisDockZone.Top, True, ENScaleOrientation.Left, 0.0F, 50.0F)
            Dim indicator As NNeedleValueIndicator = New NNeedleValueIndicator()
            indicator.ScaleAxis = axis
            indicator.OffsetFromScale = 20
            m_RadialGauge.Indicators.Add(indicator)
            Dim markerValueIndicator As NMarkerValueIndicator = New NMarkerValueIndicator(10)
            markerValueIndicator.Shape = ENScaleValueMarkerShape.Bar
            m_RadialGauge.Indicators.Add(New NMarkerValueIndicator(10))
            m_RadialGauge.Indicators.Add(New NMarkerValueIndicator(90))
            Dim needle As NNeedleValueIndicator = New NNeedleValueIndicator()
            needle.Value = 10
            needle.Shape = ENNeedleShape.Needle4
            needle.Fill = New NColorFill(NColor.DarkGreen)
            needle.Stroke = New NStroke(NColor.DarkGreen)

            '			radialGauge.Indicators.Add(needle);

            markerValueIndicator.Width = 20
            markerValueIndicator.Height = 20
            markerValueIndicator.Fill = New NColorFill(NColor.DarkGreen)
            markerValueIndicator.Stroke = New NStroke(1.0, NColor.DarkGreen)
            Return stack
        End Function
        ''' <summary>
        ''' 
        ''' </summary>
        ''' <returns></returns>
        Protected Overrides Function CreateExampleControls() As NWidget
            Dim stack As NStackPanel = New NStackPanel()
            Dim propertyStack As NStackPanel = New NStackPanel()
            stack.Add(New NUniSizeBoxGroup(propertyStack))
            Return stack
        End Function

        Protected Overrides Function GetExampleDescription() As String
            Return "<p>The example demonstrates how to control the gauge axis position using gauge axis dock anchors.</p>"
        End Function

#End Region

#Region "Fields"

        Private m_RadialGauge As NRadialGauge
        Private m_LinearGauge As NLinearGauge

#End Region

#Region "Schema"

        Public Shared ReadOnly NAxisDockingExampleSchema As NSchema

#End Region

#Region "Constants"

        Private Shared ReadOnly defaultLinearHorizontalGaugeSize As NSize = New NSize(300, 100)
        Private Shared ReadOnly defaultRadialGaugeSize As NSize = New NSize(300, 300)

#End Region
    End Class
End Namespace

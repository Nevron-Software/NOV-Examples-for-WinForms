Imports System
Imports Nevron.Nov.Chart
Imports Nevron.Nov.Dom
Imports Nevron.Nov.Graphics
Imports Nevron.Nov.Layout
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.Gauge
    ''' <summary>
    ''' This example demonstrates how to control the paint order of gauge indicators
    ''' </summary>
    Public Class NIndicatorPaintOrderExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' 	Initializer constructor
        ''' </summary>
        Public Sub New()
        End Sub
        ''' <summary>
        ''' Static constructor
        ''' </summary>
        Shared Sub New()
            NIndicatorPaintOrderExampleSchema = NSchema.Create(GetType(NIndicatorPaintOrderExample), NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            Dim stack As NStackPanel = New NStackPanel()
            stack.HorizontalPlacement = ENHorizontalPlacement.Left
            Dim controlStack As NStackPanel = New NStackPanel()
            stack.Add(controlStack)

            ' create the radial gauge
            m_RadialGauge = New NRadialGauge()
            m_RadialGauge.SweepAngle = New NAngle(270, NUnit.Degree)
            m_RadialGauge.BeginAngle = New NAngle(-225, NUnit.Degree)
            m_RadialGauge.PreferredSize = defaultRadialGaugeSize
            m_RadialGauge.CapEffect = New NGlassCapEffect()
            m_RadialGauge.Dial = New NDial(ENDialShape.CutCircle, New NEdgeDialRim())
            m_RadialGauge.Dial.BackgroundFill = New NStockGradientFill(NColor.DarkGray, NColor.Black)

            ' configure scale
            Dim axis As NGaugeAxis = New NGaugeAxis()
            m_RadialGauge.Axes.Add(axis)
            Dim scale = CType(axis.Scale, NLinearScale)
            scale.SetPredefinedScale(ENPredefinedScaleStyle.Presentation)
            scale.Labels.Style.TextStyle.Font = New NFont("Arimo", 10, ENFontStyle.Bold)
            scale.Labels.Style.TextStyle.Fill = New NColorFill(NColor.White)
            scale.Labels.Style.Angle = New NScaleLabelAngle(ENScaleLabelAngleMode.Scale, 90.0)
            scale.MinorTickCount = 4
            scale.Ruler.Stroke.Width = 0
            scale.Ruler.Fill = New NColorFill(NColor.DarkGray)

            ' add radial gauge indicators
            m_ValueIndicator = New NNeedleValueIndicator()
            m_ValueIndicator.Fill = New NStockGradientFill(ENGradientStyle.Horizontal, ENGradientVariant.Variant1, NColor.White, NColor.Red)
            m_ValueIndicator.Stroke.Color = NColor.Red
            m_ValueIndicator.Width = 15
            m_ValueIndicator.OffsetFromScale = -10
            m_RadialGauge.Indicators.Add(m_ValueIndicator)
            Dim verticalStack As NStackPanel = New NStackPanel()
            verticalStack.Direction = ENHVDirection.TopToBottom
            verticalStack.Padding = New NMargins(80, 200, 80, 0)
            m_NumericLedDisplay = New NNumericLedDisplay()
            m_NumericLedDisplay.Value = 0.0
            m_NumericLedDisplay.CellCountMode = ENDisplayCellCountMode.Fixed
            m_NumericLedDisplay.CellCount = 7
            m_NumericLedDisplay.BackgroundFill = New NColorFill(NColor.Black)
            m_NumericLedDisplay.Border = NBorder.CreateSunken3DBorder(New NUIThemeColorMap(ENUIThemeScheme.WindowsClassic))
            m_NumericLedDisplay.BorderThickness = New NMargins(6)
            m_NumericLedDisplay.Margins = New NMargins(5)
            m_NumericLedDisplay.Padding = New NMargins(5)
            Dim gelCap As NGelCapEffect = New NGelCapEffect()
            gelCap.Shape = ENCapEffectShape.RoundedRect
            m_NumericLedDisplay.CapEffect = gelCap
            m_NumericLedDisplay.PreferredHeight = 60
            verticalStack.Add(m_NumericLedDisplay)
            m_RadialGauge.Content = verticalStack

            ' add radial gauge
            controlStack.Add(m_RadialGauge)
            m_DataFeedTimer = New NTimer()
            AddHandler m_DataFeedTimer.Tick, New [Function](AddressOf OnDataFeedTimerTick)
            m_DataFeedTimer.Start()
            Return stack
        End Function

        ''' <summary>
        ''' 
        ''' </summary>
        Protected Overrides Sub OnUnregistered()
            MyBase.OnUnregistered()
            m_DataFeedTimer.Stop()
        End Sub

        Protected Overrides Function CreateExampleControls() As NWidget
            Dim stack As NStackPanel = New NStackPanel()
            Dim propertyStack As NStackPanel = New NStackPanel()
            stack.Add(New NUniSizeBoxGroup(propertyStack))
            propertyStack.Add(New NLabel("Paint Order:"))
            m_PaintOrderComboBox = New NComboBox()
            propertyStack.Add(m_PaintOrderComboBox)
            m_PaintOrderComboBox.FillFromEnum(Of ENIndicatorPaintOrder)()
            AddHandler m_PaintOrderComboBox.SelectedIndexChanged, New [Function](Of NValueChangeEventArgs)(AddressOf OnPaintOrderComboBoxSelectedIndexChanged)
            m_PaintOrderComboBox.SelectedIndex = ENIndicatorPaintOrder.AfterScale
            Return stack
        End Function

        Protected Overrides Function GetExampleDescription() As String
            Return "<p>This example demonstrates how to control the paint order of gauge indicators.</p>"
        End Function


#End Region

#Region "Event Handlers"

        ''' <summary>
        ''' 
        ''' </summary>
        ''' <paramname="arg"></param>
        Private Sub OnPaintOrderComboBoxSelectedIndexChanged(ByVal arg As NValueChangeEventArgs)
            ' set the paint order
            m_ValueIndicator.PaintOrder = CType(m_PaintOrderComboBox.SelectedIndex, ENIndicatorPaintOrder)
        End Sub
        ''' <summary>
        ''' 
        ''' </summary>
        Private Sub OnDataFeedTimerTick()
            ' update the indicator and the numeric led display
            m_FirstIndicatorAngle += 0.02
            Dim value = 50.0 - Math.Cos(m_FirstIndicatorAngle) * 50.0
            m_ValueIndicator.Value = value
            m_NumericLedDisplay.Value = value
        End Sub

#End Region

#Region "Fields"

        Private m_RadialGauge As NRadialGauge
        Private m_ValueIndicator As NNeedleValueIndicator
        Private m_NumericLedDisplay As NNumericLedDisplay
        Private m_DataFeedTimer As NTimer
        Private m_FirstIndicatorAngle As Double
        Private m_PaintOrderComboBox As NComboBox

#End Region

#Region "Schema"

        Public Shared ReadOnly NIndicatorPaintOrderExampleSchema As NSchema

#End Region

#Region "Constants"

        Private Shared ReadOnly defaultRadialGaugeSize As NSize = New NSize(300, 300)

#End Region
    End Class
End Namespace

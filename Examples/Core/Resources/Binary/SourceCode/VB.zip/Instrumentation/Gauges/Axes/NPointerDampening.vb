Imports Nevron.Nov.Chart
Imports Nevron.Nov.Dom
Imports Nevron.Nov.Graphics
Imports Nevron.Nov.UI
Imports System

Namespace Nevron.Nov.Examples.Gauge
    ''' <summary>
    ''' This example demonstrates dampening of a pointer, which simulates a fluid-filled gauge.
    ''' </summary>
    Public Class NPointerDampeningExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' 
        ''' </summary>
        Public Sub New()

        End Sub
        ''' <summary>
        ''' 
        ''' </summary>

        Shared Sub New()
            NPointerDampeningExampleSchema = NSchema.Create(GetType(NPointerDampeningExample), NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            Dim stack As NStackPanel = New NStackPanel()

            Dim controlStack As NStackPanel = New NStackPanel()
            stack.Add(controlStack)

            ' create the radial gauge
            m_RadialGauge = New NRadialGauge()

            m_RadialGauge.PreferredSize = defaultRadialGaugeSize
            m_RadialGauge.Dial = New NDial(ENDialShape.RoundedOutline, New NEdgeDialRim())
            m_RadialGauge.Dial.CornerRounding = 23
            m_RadialGauge.Dial.BackgroundFill = New NStockGradientFill(NColor.Black, NColor.WhiteSmoke)

            m_RadialGauge.SweepAngle = New NAngle(60, NUnit.Degree)
            m_RadialGauge.BeginAngle = New NAngle(240, NUnit.Degree)

            controlStack.Add(m_RadialGauge)

            ' create the first axis
            Dim axis1 As NGaugeAxis = New NGaugeAxis()
            axis1.Anchor = New NDockGaugeAxisAnchor(ENGaugeAxisDockZone.Top, True, 0, 100)

            m_RadialGauge.Axes.Add(axis1)

            ' Scale 
            Dim scale1 = CType(axis1.Scale, NStandardScale)
            scale1.SetPredefinedScale(ENPredefinedScaleStyle.PresentationNoStroke)
            scale1.MinorTickCount = 10
            scale1.Ruler.Fill = New NColorFill(NColor.FromColor(NColor.DarkGray, 5.0F))
            scale1.OuterMajorTicks.Fill = New NColorFill(NColor.OrangeRed)
            scale1.Labels.Style.TextStyle.Font = New NFont("Arial", 12, ENFontStyle.Regular)
            scale1.Labels.Style.TextStyle.Fill = New NColorFill(NColor.White)
            scale1.Labels.Style.Angle = New NScaleLabelAngle(ENScaleLabelAngleMode.Scale, 0)

            ' needle value indicator1
            m_NeedleValueIndicator = New NNeedleValueIndicator()
            m_NeedleValueIndicator.Value = 20
            m_NeedleValueIndicator.Fill = New NStockGradientFill(ENGradientStyle.Horizontal, ENGradientVariant.Variant1, NColor.White, NColor.Red)
            m_NeedleValueIndicator.Stroke.Color = NColor.Red
            m_NeedleValueIndicator.ScaleAxis = axis1
            m_NeedleValueIndicator.OffsetFromScale = 2
            m_NeedleValueIndicator.EnableDampening = True

            m_RadialGauge.Indicators.Add(m_NeedleValueIndicator)

            ' marker value indicator 
            m_MarkerValueIndicator = New NMarkerValueIndicator()
            m_MarkerValueIndicator.EnableDampening = True
            m_MarkerValueIndicator.Value = 20

            ' range value indicator 
            m_RangeValueIndicator = New NRangeIndicator()
            m_RangeValueIndicator.EnableDampening = True
            m_RangeValueIndicator.Value = 20

            ' Timer
            m_Timer = New NTimer()
            m_Timer.Interval = 1000
            m_Timer.Tick += New [Function](AddressOf OnTimerTick)
            m_Timer.Start()
            Return stack
        End Function

        Protected Overrides Function CreateExampleControls() As NWidget
            Dim stack As NStackPanel = New NStackPanel()

            Dim propertyStack As NStackPanel = New NStackPanel()
            stack.Add(New NUniSizeBoxGroup(propertyStack))

            ' pointer properties group
            Dim controlsGroupBox As NGroupBox = New NGroupBox("Controls")
            propertyStack.Add(controlsGroupBox)
            Dim controlsGroupBoxContent As NStackPanel = New NStackPanel()
            controlsGroupBox.Content = New NUniSizeBoxGroup(controlsGroupBoxContent)

            Dim toggleTimerButton As NButton = New NButton("Stop Timer")
            toggleTimerButton.Click += AddressOf OnToggleTimerButtonClick
            toggleTimerButton.Tag = 0
            stack.Add(toggleTimerButton)

            ' enable dampening checkbox
            m_EnableDampeningCheckBox = New NCheckBox("Enable Value Dampening")
            m_EnableDampeningCheckBox.CheckedChanged += New [Function](Of NValueChangeEventArgs)(AddressOf OnEnableDampeningCheckBoxCheckedChanged)
            m_EnableDampeningCheckBox.Checked = True
            propertyStack.Add(m_EnableDampeningCheckBox)

            ' dampening steps up and down value 
            m_DampeningStepsUpDown = New NNumericUpDown()
            m_DampeningStepsUpDown.Minimum = 1
            m_DampeningStepsUpDown.Maximum = 100
            m_DampeningStepsUpDown.ValueChanged += New [Function](Of NValueChangeEventArgs)(AddressOf UpdateDampeingStepsUpAndDown)
            m_DampeningStepsUpDown.Value = 20
            propertyStack.Add(New NPairBox("Steps: ", m_DampeningStepsUpDown, True))

            ' dampening interval up and down value 
            m_DampeningIntervalUpDown = New NNumericUpDown()
            m_DampeningIntervalUpDown.Minimum = 1
            m_DampeningIntervalUpDown.ValueChanged += New [Function](Of NValueChangeEventArgs)(AddressOf UpdateDampeingIntervalUpAndDown)
            m_DampeningIntervalUpDown.Value = 50
            propertyStack.Add(New NPairBox("Interval: ", m_DampeningIntervalUpDown, True))

            ' value indicator combo box
            m_ValueIndicatorTypeComboBox = New NComboBox()
            m_ValueIndicatorTypeComboBox.Items.Add(New NComboBoxItem("Needle"))
            m_ValueIndicatorTypeComboBox.Items.Add(New NComboBoxItem("Marker"))
            m_ValueIndicatorTypeComboBox.Items.Add(New NComboBoxItem("Bar"))
            m_ValueIndicatorTypeComboBox.SelectedIndexChanged += New [Function](Of NValueChangeEventArgs)(AddressOf OnValueIndicatorComboBoxIndexChanged)
            m_ValueIndicatorTypeComboBox.SelectedIndex = 0
            controlsGroupBoxContent.Add(New NPairBox("Marker Pointer Scale:", m_ValueIndicatorTypeComboBox, True))

            Return stack
        End Function

        Protected Overrides Function GetExampleDescription() As String
            Return "<p>This example demonstrates how to enable the value dampening feature of the gauge indicators. When enabled the value dampening will smooths the transition of indicators when their value changes.
          Use the controls on the right side to modify various parameters of the dampening effect.  </p>" End Function

#End Region

#Region "Event Handlers "

        ''' <summary>
        ''' 
        ''' </summary>
        ''' <paramname="arg"></param>
        Private Sub OnValueIndicatorComboBoxIndexChanged(ByVal arg As NValueChangeEventArgs)
            m_RadialGauge.Indicators.Clear()

            Select Case arg.NewValue
                Case 0
                    m_RadialGauge.Indicators.Add(m_NeedleValueIndicator)
                Case 1
                    m_RadialGauge.Indicators.Add(m_MarkerValueIndicator)
                Case 2
                    m_RadialGauge.Indicators.Add(m_RangeValueIndicator)
            End Select
        End Sub
        ''' <summary>
        ''' 
        ''' </summary>
        ''' <paramname="arg"></param>
        Private Sub UpdateDampeingIntervalUpAndDown(ByVal arg As NValueChangeEventArgs)
            SetValueIndicator(NIndicator.DampeningIntervalProperty, CInt(m_DampeningIntervalUpDown.Value))
        End Sub
        ''' <summary>
        ''' 
        ''' </summary>
        ''' <paramname="arg"></param>
        Private Sub UpdateDampeingStepsUpAndDown(ByVal arg As NValueChangeEventArgs)
            SetValueIndicator(NIndicator.DampeningStepsProperty, CInt(m_DampeningStepsUpDown.Value))
        End Sub
        ''' <summary>
        '''  Set whether dampening is on or off.
        ''' </summary>
        ''' <paramname="arg"></param>
        Private Sub OnEnableDampeningCheckBoxCheckedChanged(ByVal arg As NValueChangeEventArgs)
            Dim enableDampening As Boolean = arg.NewValue

            m_NeedleValueIndicator.EnableDampening = enableDampening
            m_MarkerValueIndicator.EnableDampening = enableDampening
            m_RangeValueIndicator.EnableDampening = enableDampening
        End Sub
        ''' <summary>
        ''' Handles timer's click as evaluating random value and set it on the indicators. 
        ''' </summary>
        Private Sub OnTimerTick()
            m_Angle += Math.PI / 180.0
            Dim value = 50 + Math.Sin(m_Angle) * (20 + rand.Next(30))

            SetValueIndicator(NIndicator.ValueProperty, value)
        End Sub
        ''' <summary>
        ''' Set the value of specified properties of the indicators
        ''' </summary>
        ''' <paramname="indicatorProperty"></param>
        ''' <paramname="value"></param>
        Private Sub SetValueIndicator(ByVal indicatorProperty As NProperty, ByVal value As Double)
            Dim stringValue As String = value.ToString()

            m_NeedleValueIndicator.SetFx(indicatorProperty, stringValue)
            m_MarkerValueIndicator.SetFx(indicatorProperty, stringValue)
            m_RangeValueIndicator.SetFx(indicatorProperty, stringValue)
        End Sub
        ''' <summary>
        ''' 
        ''' </summary>
        ''' <paramname="arg"></param>
        Private Sub OnToggleTimerButtonClick(ByVal arg As NEventArgs)
            Dim button = CType(arg.TargetNode, NButton)
            If CInt(button.Tag) = 0 Then
                m_Timer.Stop()

                button.Content = New NLabel("Start Timer")
                button.Tag = 1
            Else
                m_Timer.Start()

                button.Content = New NLabel("Stop Timer")
                button.Tag = 0
            End If
        End Sub

#End Region

#Region "Implementation"

#End Region

#Region "Fields"

        Private m_RadialGauge As NRadialGauge
        Private m_NeedleValueIndicator As NNeedleValueIndicator
        Private m_MarkerValueIndicator As NMarkerValueIndicator
        Private m_RangeValueIndicator As NRangeIndicator

        Private m_ValueIndicatorTypeComboBox As NComboBox
        Private m_DampeningStepsUpDown As NNumericUpDown
        Private m_DampeningIntervalUpDown As NNumericUpDown
        Private m_EnableDampeningCheckBox As NCheckBox

        Private m_Timer As NTimer

        Private m_Angle As Double
        Private rand As Random = New Random()
#End Region

#Region "Schema"

        Public Shared ReadOnly NPointerDampeningExampleSchema As NSchema

#End Region

#Region "Constants"

        Private Shared ReadOnly defaultRadialGaugeSize As NSize = New NSize(300, 300)

#End Region
    End Class
End Namespace

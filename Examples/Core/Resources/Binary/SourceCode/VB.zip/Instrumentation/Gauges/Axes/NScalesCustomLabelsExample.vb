Imports Nevron.Nov.Chart
Imports Nevron.Nov.Dom
Imports Nevron.Nov.Graphics
Imports Nevron.Nov.UI
Imports System

Namespace Nevron.Nov.Examples.Gauge
    ''' <summary>
    ''' This example demonstrates how to add a custom labels to a scale.
    ''' </summary>
    Public Class NScalesCustomLabelsExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' 
        ''' </summary>
        Public Sub New()
        End Sub
        ''' <summary>
        ''' 
        ''' </summary>
        Shared Sub New()
            NScalesCustomLabelsExampleSchema = NSchema.Create(GetType(NScalesCustomLabelsExample), NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        ''' <summary>
        ''' 
        ''' </summary>
        ''' <returns></returns>
        Protected Overrides Function CreateExampleContent() As NWidget
            Dim stack As NStackPanel = New NStackPanel()

            Dim controlStack As NStackPanel = New NStackPanel()
            controlStack.Padding = New NMargins(20)
            stack.Add(controlStack)

            ' create the radial gauge
            m_RadialGauge = New NRadialGauge()
            m_RadialGauge.PreferredSize = defaultRadialGaugeSize
            m_RadialGauge.Dial = New NDial(ENDialShape.CutCircle, New NEdgeDialRim())
            m_RadialGauge.NeedleCap.Visible = False
            controlStack.Add(m_RadialGauge)

            ' add axis 
            Dim axis As NGaugeAxis = New NGaugeAxis()
            m_RadialGauge.Axes.Clear()
            m_RadialGauge.Axes.Add(axis)
            axis.Range = New NRange(0, 20)
            axis.Anchor = New NDockGaugeAxisAnchor(ENGaugeAxisDockZone.Top, True, ENScaleOrientation.Left, 2F, 98F)

            ' scale
            m_RadialGauge.SweepAngle = New NAngle(180, NUnit.Degree)
            m_RadialGauge.BeginAngle = New NAngle(-180, NUnit.Degree)

            ' needle value 
            m_NeedleIndicator = New NNeedleValueIndicator()
            m_NeedleIndicator.ScaleAxis = axis
            m_NeedleIndicator.Width = 12
            m_NeedleIndicator.Fill = New NColorFill(NColor.Red)
            m_NeedleIndicator.OffsetFromScale = 15
            m_RadialGauge.Indicators.Add(m_NeedleIndicator)

            ' Timer
            m_Timer = New NTimer()
            m_Timer.Interval = 800
            m_Timer.Tick += New [Function](AddressOf OnTimerTick)
            m_Timer.Start()

            Return stack
        End Function


        ''' <summary>
        ''' 
        ''' </summary>
        ''' <returns></returns>
        Protected Overrides Function CreateExampleControls() As NWidget
            Dim stack As NStackPanel = New NStackPanel()

            Dim propertyStack As NStackPanel = New NStackPanel()
            stack.Add(New NUniSizeBoxGroup(propertyStack))

            m_LabelsTypeRadioGroup = New NRadioButtonGroup()
            Me.m_LabelsTypeRadioGroup.SelectedIndexChanged += AddressOf OnLabelsTypeRadioGroupIndexChanged

            Dim radioStack As NStackPanel = New NStackPanel()
            m_LabelsTypeRadioGroup.Content = radioStack

            radioStack.Add(New NRadioButton("Standart Labels"))
            radioStack.Add(New NRadioButton("Custom Labels"))
            radioStack.Add(New NRadioButton("Both"))

            m_LabelsTypeRadioGroup.SelectedIndex = 0

            CType(radioStack(0), NRadioButton).Checked = True
            stack.Add(m_LabelsTypeRadioGroup)

            Return stack
        End Function

        Protected Overrides Function GetExampleDescription() As String
            Return "<p>This example demonstrates how to use a minimum scale pin to define a pointer's off position.</p>"
        End Function

#End Region

#Region "Event Handlers"

        Private Sub OnLabelsTypeRadioGroupIndexChanged(ByVal arg As NValueChangeEventArgs)
            Dim selectedIndex = m_LabelsTypeRadioGroup.SelectedIndex

            ' scale
            Dim scale As NLinearScale = New NLinearScale()
            m_RadialGauge.Axes(0).Scale = scale

            scale.SetPredefinedScale(ENPredefinedScaleStyle.Presentation)
            scale.Labels.Style.TextStyle.Font = New NFont("Microsoft Sans Serif", 15, ENFontStyle.Bold)
            scale.Labels.Style.TextStyle.Fill = New NColorFill(NColor.Black)

            scale.MajorTickMode = ENMajorTickMode.AutoMaxCount
            scale.OuterMinorTicks.Visible = True
            scale.OuterMajorTicks.Width = 7
            scale.OuterMajorTicks.Fill = New NColorFill(NColor.Black)
            scale.MinorTickCount = 3
            scale.OuterMinorTicks.Fill = New NColorFill(NColor.Gray)

            scale.Title.Text = "GAS"
            scale.Title.TextStyle = New NTextStyle(NColor.Red)
            scale.Title.RulerAlignment = ENHorizontalAlignment.Center
            scale.Title.ContentAlignment = ENContentAlignment.BottomCenter

            Select Case selectedIndex
                Case 0 ' Standard labels

                Case 1 ' Custom labels
                    scale.Labels.Visible = False
                    scale.CreateNewLevelForCustomLabels = True
                    AddCustomLabels(scale)

                Case 2 ' Both
                    ' add custom labels
                    scale.CreateNewLevelForCustomLabels = False
                    AddCustomLabels(scale)
            End Select
        End Sub
        ''' <summary>
        ''' Timer tick event
        ''' </summary>
        Private Sub OnTimerTick()
            ' update the indicator 
            m_FirstIndicatorAngle += 0.02
            Dim value = 50.0 - Math.Cos(m_FirstIndicatorAngle) * 50.0
            m_NeedleIndicator.Value = value
        End Sub

#End Region

#Region "Implementation"

        ''' <summary>
        ''' Adds custom labels to the scle
        ''' </summary>
        ''' <paramname="scale"></param>
        Private Sub AddCustomLabels(ByVal scale As NLinearScale)
            scale.CustomLabelOverlapResolveLayouts = New NDomArray(Of ENLevelLabelsLayout)(New ENLevelLabelsLayout() {ENLevelLabelsLayout.RemoveOverlap, ENLevelLabelsLayout.AutoScale})

            scale.CustomLabels.Add(CreateCustomLabel(0, "E"))
            scale.CustomLabels.Add(CreateCustomLabel(10, "1/2"))
            scale.CustomLabels.Add(CreateCustomLabel(20, "F"))
        End Sub
        ''' <summary>
        ''' Creates a custom label give the specified value and text
        ''' </summary>
        ''' <paramname="value"></param>
        ''' <paramname="text"></param>
        ''' <returns></returns>
        Private Function CreateCustomLabel(ByVal value As Double, ByVal text As String) As NCustomValueLabel
            Dim label As NCustomValueLabel = New NCustomValueLabel(value, text)

            label.LabelStyle.ZOrder = 1
            label.LabelStyle.TextStyle.Font = New NFont("Microsoft Sans Serif", 15, ENFontStyle.Bold)
            label.LabelStyle.TextStyle.Fill = New NColorFill(NColor.Black)

            Return label
        End Function

#End Region

#Region "Fields"

        Private m_RadialGauge As NRadialGauge
        Private m_NeedleIndicator As NNeedleValueIndicator

        Private m_LabelsTypeRadioGroup As NRadioButtonGroup

        Private m_Timer As NTimer
        Private m_FirstIndicatorAngle As Double

#End Region

#Region "Schema"

        Public Shared ReadOnly NScalesCustomLabelsExampleSchema As NSchema

#End Region

#Region "Constants"

        Private Shared ReadOnly defaultRadialGaugeSize As NSize = New NSize(300, 300)

#End Region
    End Class
End Namespace

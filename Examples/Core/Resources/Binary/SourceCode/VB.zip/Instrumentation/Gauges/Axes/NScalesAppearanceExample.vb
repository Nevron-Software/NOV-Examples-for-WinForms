Imports Nevron.Nov.Chart
Imports Nevron.Nov.Dom
Imports Nevron.Nov.Editors
Imports Nevron.Nov.Graphics
Imports Nevron.Nov.Layout
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.Gauge
    ''' <summary>
    ''' This example demonstrates variuos appearance-related properties of the scale bar.
    ''' </summary>
    Public Class NScalesAppearanceExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' 
        ''' </summary>
        Public Sub New()
        End Sub
        ''' <summary>
        ''' 
        ''' </summary>
        Shared Sub New()
            NScalesAppearanceExampleSchema = NSchema.Create(GetType(NScalesAppearanceExample), NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            Dim stack As NStackPanel = New NStackPanel()

            Dim controlStack As NStackPanel = New NStackPanel()
            controlStack.Direction = ENHVDirection.LeftToRight
            stack.Add(controlStack)

            ' create the radial gauge
            m_RadialGauge = New NRadialGauge()
            m_RadialGauge.Dial = New NDial(ENDialShape.Circle, New NEdgeDialRim())
            m_RadialGauge.PreferredSize = defaultRadialGaugeSize

            m_RadialGauge.SweepAngle = New NAngle(280, NUnit.Degree)
            m_RadialGauge.BeginAngle = New NAngle(120, NUnit.Degree)

            controlStack.Add(m_RadialGauge)

            m_RadialGauge.SweepAngle = New NAngle(310, NUnit.Degree)
            m_RadialGauge.BeginAngle = New NAngle(-240, NUnit.Degree)

            ' configure the axis
            Dim axis As NGaugeAxis = New NGaugeAxis()
            axis.Anchor.ScaleOrientation = ENScaleOrientation.Right
            axis.Range = New NRange(0, 100)
            axis.Anchor = New NDockGaugeAxisAnchor(ENGaugeAxisDockZone.Top, True, ENScaleOrientation.Right, 0.0F, 100.0F)

            m_RadialGauge.Axes.Add(axis)

            ' create scale 
            m_Scale = CType(axis.Scale, NStandardScale)
            m_Scale.SetPredefinedScale(ENPredefinedScaleStyle.PresentationNoStroke)
            m_Scale.Labels.OverlapResolveLayouts = New NDomArray(Of ENLevelLabelsLayout)()
            m_Scale.MinorTickCount = 3
            m_Scale.Ruler.Fill = New NColorFill(NColor.FromColor(NColor.Transparent, 0.4F))
            m_Scale.OuterMajorTicks.Fill = New NColorFill(NColor.Black)
            m_Scale.Labels.Style.TextStyle.Font = New NFont("Arimo", 12, ENFontStyle.Bold)
            m_Scale.Labels.Style.TextStyle.Fill = New NColorFill(NColor.Black)
            m_Scale.MajorTickMode = ENMajorTickMode.AutoMaxCount
            m_Scale.OuterMajorTicks.Fill = New NColorFill(NColor.Red)
            m_Scale.OuterMinorTicks.Shape = ENScaleValueMarkerShape.Line
            m_Scale.OuterMajorTicks.Shape = ENScaleValueMarkerShape.Star

            ' Value indicator - Needle 
            m_NeedleIndicator = New NNeedleValueIndicator(60)
            m_NeedleIndicator.OffsetOriginMode = ENIndicatorOffsetOriginMode.ScaleMiddle
            m_NeedleIndicator.Value = 79
            m_NeedleIndicator.Fill = New NStockGradientFill(ENGradientStyle.Horizontal, ENGradientVariant.Variant1, NColor.White, NColor.Red)
            m_NeedleIndicator.OffsetFromScale = 15.0
            m_NeedleIndicator.Stroke.Color = NColor.Red

            m_RadialGauge.Indicators.Add(m_NeedleIndicator)

            Return stack
        End Function

        Protected Overrides Function CreateExampleControls() As NWidget
            Dim stack As NStackPanel = New NStackPanel()

            Dim propertyStack As NStackPanel = New NStackPanel()
            stack.Add(New NUniSizeBoxGroup(propertyStack))

            ' major tick properties
            Dim majorTicksGroupBox As NGroupBox = New NGroupBox("Major Ticks")
            propertyStack.Add(majorTicksGroupBox)

            Dim majorTicksGroupBoxGroupBoxContent As NStackPanel = New NStackPanel()
            majorTicksGroupBox.Content = New NUniSizeBoxGroup(majorTicksGroupBoxGroupBoxContent)

            ' minor tick properties
            Dim minorTicksGroupBox As NGroupBox = New NGroupBox("Minor Ticks")
            propertyStack.Add(minorTicksGroupBox)

            Dim minorTicksGroupBoxContent As NStackPanel = New NStackPanel()
            minorTicksGroupBox.Content = New NUniSizeBoxGroup(minorTicksGroupBoxContent)

            ' Scale Ruler Color Fill 
            m_ScaleFillButton = New NButton("Scale Fill Style")
            m_ScaleFillButton.Click += New [Function](Of NEventArgs)(AddressOf OnScaleFillButtonClick)
            propertyStack.Add(m_ScaleFillButton)

            ' Load Predifined Scale Type 
            m_ScaleTypeComboBox = New NComboBox()
            m_ScaleTypeComboBox.FillFromEnum(Of ENPredefinedScaleStyle)()
            m_ScaleTypeComboBox.SelectedIndex = m_ScaleTypeComboBox.SelectedIndex
            m_ScaleTypeComboBox.SelectedIndexChanged += New [Function](Of NValueChangeEventArgs)(AddressOf OnScaleStyleComboBoxSelectedIndexChanged)
            propertyStack.Add(New NPairBox("Load Predifined Scale Style:", m_ScaleTypeComboBox, True))

            ' Change Major Tick Mode
            m_MajorTickModeComboBox = New NComboBox()
            m_MajorTickModeComboBox.FillFromEnum(Of ENMajorTickMode)()
            m_MajorTickModeComboBox.SelectedIndex = m_MajorTickModeComboBox.SelectedIndex
            m_MajorTickModeComboBox.SelectedIndexChanged += New [Function](Of NValueChangeEventArgs)(AddressOf OnMajorTickModeComboBoxSelectedIndexChanged)
            majorTicksGroupBoxGroupBoxContent.Add(New NPairBox("Change Major Tick Mode:", m_MajorTickModeComboBox, True))

            ' Change Major Tick Shape 
            m_MajorTickShapeComboBox = New NComboBox()
            m_MajorTickShapeComboBox.FillFromEnum(Of ENScaleValueMarkerShape)()
            m_MajorTickShapeComboBox.SelectedIndex = m_MajorTickShapeComboBox.SelectedIndex
            m_MajorTickShapeComboBox.SelectedIndexChanged += New [Function](Of NValueChangeEventArgs)(AddressOf OnMajorTickShapeComboBoxSelectedIndexChanged)
            majorTicksGroupBoxGroupBoxContent.Add(New NPairBox("Change Major Tick Shape:", m_MajorTickShapeComboBox, True))

            '  Outer Major Ticks Fill
            m_OuterMajorTicksFillButton = New NButton("Outer Major Ticks Fill")
            m_OuterMajorTicksFillButton.Click += New [Function](Of NEventArgs)(AddressOf OnOuterMajorTickFillButtonClick)
            majorTicksGroupBoxGroupBoxContent.Add(m_OuterMajorTicksFillButton)

            ' Change Major Tick Shape 
            m_MinorTickShapeComboBox = New NComboBox()
            m_MinorTickShapeComboBox.FillFromEnum(Of ENScaleValueMarkerShape)()
            m_MinorTickShapeComboBox.SelectedIndex = m_MajorTickShapeComboBox.SelectedIndex
            m_MinorTickShapeComboBox.SelectedIndexChanged += New [Function](Of NValueChangeEventArgs)(AddressOf OnMinorTickShapeComboBoxSelectedIndexChanged)
            minorTicksGroupBoxContent.Add(New NPairBox("Change Minor Tick Shape:", m_MinorTickShapeComboBox, True))

            ' Change Minor Tick Mode 
            m_MinorTickModeComboBox = New NComboBox()
            m_MinorTickModeComboBox.FillFromEnum(Of ENMajorTickMode)()
            m_MinorTickModeComboBox.SelectedIndex = m_MinorTickModeComboBox.SelectedIndex
            m_MinorTickModeComboBox.SelectedIndexChanged += New [Function](Of NValueChangeEventArgs)(AddressOf OnMinorTickModeComboBoxSelectedIndexChanged)
            minorTicksGroupBoxContent.Add(New NPairBox("Change Minor Tick Mode:", m_MinorTickModeComboBox, True))

            ' Minor Tick Color Fill 
            m_MinorTickButton = New NButton("Minor Tick Fill Style")
            m_MinorTickButton.Click += New [Function](Of NEventArgs)(AddressOf OnMinorTickFillButtonClick)
            minorTicksGroupBoxContent.Add(m_MinorTickButton)

            Return stack
        End Function

        Protected Overrides Function GetExampleDescription() As String
            Return "<p>The example demonstrates various appearance-related properties of the scale bar.</p>"
        End Function

#End Region

#Region "Event Handlers"
        Private Sub OnScaleFillButtonClick(ByVal arg As NEventArgs)
            Call NEditorWindow.CreateForType(CType(m_Scale.Ruler.Fill.DeepClone(), NFill), Nothing, m_Scale.Ruler.DisplayWindow, False, New [Function](Of T)(AddressOf OnColorFillEdited)).Open()
        End Sub
        Private Sub OnColorFillEdited(ByVal fill As NFill)
            m_Scale.Ruler.Fill = CType((fill.DeepClone()), NFill)
        End Sub
        Private Sub OnScaleStyleComboBoxSelectedIndexChanged(ByVal arg As NValueChangeEventArgs)
            m_Scale.SetPredefinedScale(CType(m_ScaleTypeComboBox.SelectedIndex, ENPredefinedScaleStyle))

            m_MajorTickModeComboBox.SelectedIndex = m_Scale.MajorTickMode
            m_MinorTickModeComboBox.SelectedIndex = m_Scale.MajorTickMode

            m_MajorTickShapeComboBox.SelectedIndex = m_Scale.OuterMajorTicks.Shape
            m_MinorTickShapeComboBox.SelectedIndex = m_Scale.OuterMinorTicks.Shape
        End Sub
        Private Sub OnMajorTickModeComboBoxSelectedIndexChanged(ByVal arg As NValueChangeEventArgs)
            m_Scale.MajorTickMode = CType(m_MajorTickModeComboBox.SelectedIndex, ENMajorTickMode)
        End Sub
        Private Sub OnMinorTickModeComboBoxSelectedIndexChanged(ByVal arg As NValueChangeEventArgs)
            m_Scale.MajorTickMode = CType(m_MinorTickModeComboBox.SelectedIndex, ENMajorTickMode)
        End Sub
        Private Sub OnMinorTickFillButtonClick(ByVal arg As NEventArgs)
            Call NEditorWindow.CreateForType(CType(m_Scale.OuterMinorTicks.Fill.DeepClone(), NFill), Nothing, m_Scale.OuterMinorTicks.DisplayWindow, False, New [Function](Of T)(AddressOf OnOuterMinorTicksFillEdited)).Open()
        End Sub
        Private Sub OnOuterMinorTicksFillEdited(ByVal fill As NFill)
            m_Scale.OuterMinorTicks.Fill = CType((fill.DeepClone()), NFill)
        End Sub
        Private Sub OnOuterMajorTickFillButtonClick(ByVal arg As NEventArgs)
            Call NEditorWindow.CreateForType(CType(m_Scale.OuterMajorTicks.Fill.DeepClone(), NFill), Nothing, m_Scale.OuterMajorTicks.DisplayWindow, False, New [Function](Of T)(AddressOf OnOuterMajorTicksFillEdited)).Open()
        End Sub
        Private Sub OnOuterMajorTicksFillEdited(ByVal fill As NFill)
            m_Scale.OuterMajorTicks.Fill = CType((fill.DeepClone()), NFill)
        End Sub
        Private Sub OnMinorTickShapeComboBoxSelectedIndexChanged(ByVal arg As NValueChangeEventArgs)
            m_Scale.OuterMinorTicks.Shape = CType(m_MinorTickShapeComboBox.SelectedIndex, ENScaleValueMarkerShape)
        End Sub
        Private Sub OnMajorTickShapeComboBoxSelectedIndexChanged(ByVal arg As NValueChangeEventArgs)
            m_Scale.OuterMajorTicks.Shape = CType(m_MajorTickShapeComboBox.SelectedIndex, ENScaleValueMarkerShape)
        End Sub

#End Region

#Region "Implementation"

#End Region

#Region "Fields"

        Private m_RadialGauge As NRadialGauge
        Private m_Scale As NStandardScale
        Private m_NeedleIndicator As NNeedleValueIndicator

        Private m_ScaleTypeComboBox As NComboBox
        Private m_MajorTickModeComboBox As NComboBox
        Private m_MinorTickModeComboBox As NComboBox
        Private m_MinorTickShapeComboBox As NComboBox
        Private m_MajorTickShapeComboBox As NComboBox

        Private m_MinorTickButton As NButton
        Private m_OuterMajorTicksFillButton As NButton
        Private m_ScaleFillButton As NButton

#End Region

#Region "Schema"

        Public Shared ReadOnly NScalesAppearanceExampleSchema As NSchema

#End Region

#Region "Static Methods"

#End Region

#Region "Constants"
        Private Shared ReadOnly defaultRadialGaugeSize As NSize = New NSize(300, 300)
#End Region
    End Class
End Namespace

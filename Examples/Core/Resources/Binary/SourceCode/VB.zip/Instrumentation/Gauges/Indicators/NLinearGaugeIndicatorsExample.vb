Imports Nevron.Nov.Chart
Imports Nevron.Nov.Dom
Imports Nevron.Nov.Graphics
Imports Nevron.Nov.Layout
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.Gauge
    ''' <summary>
    ''' This example demonstrates how to add indicators to a linear gauge 
    ''' </summary>
    Public Class NLinearGaugeIndicatorsExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' 
        ''' </summary>
        Public Sub New()
        End Sub
        ''' <summary>
        ''' 
        ''' </summary>
        Shared Sub New()
            NLinearGaugeIndicatorsExampleSchema = NSchema.Create(GetType(NLinearGaugeIndicatorsExample), NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            Dim stack As NStackPanel = New NStackPanel()
            stack.HorizontalPlacement = ENHorizontalPlacement.Left

            ' create a linear gauge
            m_LinearGauge = New NLinearGauge()
            stack.Add(m_LinearGauge)
            m_LinearGauge.CapEffect = New NGelCapEffect()
            m_LinearGauge.Border = CreateBorder()
            m_LinearGauge.Padding = New NMargins(20)
            m_LinearGauge.BorderThickness = New NMargins(6)
            m_LinearGauge.BackgroundFill = New NStockGradientFill(NColor.Gray, NColor.Black)
            m_LinearGauge.PreferredSize = New NSize(400, 150)
            m_LinearGauge.Axes.Clear()
            Dim celsiusRange As NRange = New NRange(-40.0, 60.0)

            ' add celsius and farenheit axes
            Dim celsiusAxis As NGaugeAxis = New NGaugeAxis()
            celsiusAxis.Range = celsiusRange
            celsiusAxis.Anchor = New NModelGaugeAxisAnchor(-5, ENVerticalAlignment.Center, ENScaleOrientation.Left, 0.0F, 100.0F)
            m_LinearGauge.Axes.Add(celsiusAxis)
            Dim farenheitAxis As NGaugeAxis = New NGaugeAxis()
            farenheitAxis.Range = New NRange(CelsiusToFarenheit(celsiusRange.Begin), CelsiusToFarenheit(celsiusRange.End))
            farenheitAxis.Anchor = New NModelGaugeAxisAnchor(5, ENVerticalAlignment.Center, ENScaleOrientation.Right, 0.0F, 100.0F)
            m_LinearGauge.Axes.Add(farenheitAxis)

            ' configure the scales
            Dim celsiusScale = CType(celsiusAxis.Scale, NLinearScale)
            ConfigureScale(celsiusScale, "°C")
            celsiusScale.Sections.Add(CreateSection(NColor.Red, NColor.Red, New NRange(40, 60)))
            celsiusScale.Sections.Add(CreateSection(NColor.Blue, NColor.SkyBlue, New NRange(-40, -20)))
            Dim farenheitScale = CType(farenheitAxis.Scale, NLinearScale)
            ConfigureScale(farenheitScale, "°F")
            farenheitScale.Sections.Add(CreateSection(NColor.Red, NColor.Red, New NRange(CelsiusToFarenheit(40), CelsiusToFarenheit(60))))
            farenheitScale.Sections.Add(CreateSection(NColor.Blue, NColor.SkyBlue, New NRange(CelsiusToFarenheit(-40), CelsiusToFarenheit(-20))))

            ' now add two indicators
            m_Indicator1 = New NRangeIndicator()
            m_Indicator1.Value = 10
            m_Indicator1.Stroke.Color = NColor.DarkBlue
            m_Indicator1.Fill = New NStockGradientFill(ENGradientStyle.Vertical, ENGradientVariant.Variant1, NColor.LightBlue, NColor.Blue)
            m_Indicator1.BeginWidth = 10
            m_Indicator1.EndWidth = 10
            m_LinearGauge.Indicators.Add(m_Indicator1)
            m_Indicator2 = New NMarkerValueIndicator()
            m_Indicator2.Value = 33
            '			m_Indicator2.ShapFillStyle = new NStockGradientFill(ENGradientStyle.Horizontal, ENGradientVariant.Variant1, NColor.White, NColor.Red);
            '			m_Indicator2.Shape.StrokeStyle.Color = Color.DarkRed;
            m_LinearGauge.Indicators.Add(m_Indicator2)
            Return stack
        End Function

        Protected Overrides Function CreateExampleControls() As NWidget
            Dim stack As NStackPanel = New NStackPanel()
            Dim propertyStack As NStackPanel = New NStackPanel()
            stack.Add(New NUniSizeBoxGroup(propertyStack))
            m_RangeIndicatorValueUpDown = New NNumericUpDown()
            propertyStack.Add(New NPairBox("Range Indicator Value:", m_RangeIndicatorValueUpDown, True))
            m_RangeIndicatorValueUpDown.Value = m_Indicator1.Value
            AddHandler m_RangeIndicatorValueUpDown.ValueChanged, New [Function](Of NValueChangeEventArgs)(AddressOf OnRangeIndicatorValueUpDownValueChanged)
            m_RangeIndicatorOriginModeComboBox = New NComboBox()
            propertyStack.Add(New NPairBox("Range Indicator Origin Mode:", m_RangeIndicatorOriginModeComboBox, True))
            m_RangeIndicatorOriginModeComboBox.FillFromEnum(Of ENRangeIndicatorOriginMode)()
            m_RangeIndicatorOriginModeComboBox.SelectedIndex = ENRangeIndicatorOriginMode.ScaleMin
            AddHandler m_RangeIndicatorOriginModeComboBox.SelectedIndexChanged, New [Function](Of NValueChangeEventArgs)(AddressOf OnRangeIndicatorOriginModeComboBoxSelectedIndexChanged)
            m_RangeIndicatorOriginUpDown = New NNumericUpDown()
            m_RangeIndicatorOriginUpDown.Value = 0.0
            m_RangeIndicatorOriginUpDown.Enabled = False
            propertyStack.Add(New NPairBox("Range Indicator Origin:", m_RangeIndicatorOriginUpDown, True))
            AddHandler m_RangeIndicatorOriginUpDown.ValueChanged, New [Function](Of NValueChangeEventArgs)(AddressOf OnRangeIndicatorOriginUpDownValueChanged)
            m_ValueIndicatorUpDown = New NNumericUpDown()
            propertyStack.Add(New NPairBox("Value Indicator Value:", m_ValueIndicatorUpDown, True))
            m_ValueIndicatorUpDown.Value = m_Indicator2.Value
            AddHandler m_ValueIndicatorUpDown.ValueChanged, New [Function](Of NValueChangeEventArgs)(AddressOf OnValueIndicatorUpDownValueChanged)
            m_ValueIndicatorShapeComboBox = New NComboBox()
            propertyStack.Add(New NPairBox("Value Indicator Shape", m_ValueIndicatorShapeComboBox, True))
            m_ValueIndicatorShapeComboBox.FillFromEnum(Of ENScaleValueMarkerShape)()
            m_ValueIndicatorShapeComboBox.SelectedIndex = m_Indicator2.Shape
            AddHandler m_ValueIndicatorShapeComboBox.SelectedIndexChanged, New [Function](Of NValueChangeEventArgs)(AddressOf OnValueIndicatorShapeComboBoxSelectedIndexChanged)
            m_GaugeOrientationCombo = New NComboBox()
            propertyStack.Add(New NPairBox("Gauge Orientation:", m_GaugeOrientationCombo, True))
            m_GaugeOrientationCombo.FillFromEnum(Of ENLinearGaugeOrientation)()
            m_GaugeOrientationCombo.SelectedIndex = ENLinearGaugeOrientation.Horizontal
            AddHandler m_GaugeOrientationCombo.SelectedIndexChanged, New [Function](Of NValueChangeEventArgs)(AddressOf OnGaugeOrientationComboSelectedIndexChanged)
            m_MarkerWidthUpDown = New NNumericUpDown()
            propertyStack.Add(New NPairBox("Marker Width:", m_MarkerWidthUpDown, True))
            m_MarkerWidthUpDown.Value = m_Indicator2.Width
            m_MarkerHeightUpDown = New NNumericUpDown()
            propertyStack.Add(New NPairBox("Marker Height:", m_MarkerHeightUpDown, True))
            m_MarkerHeightUpDown.Value = m_Indicator2.Height
            Return stack
        End Function

        Protected Overrides Function GetExampleDescription() As String
            Return "<p>The example demonstrates how to create range and marker gauge indicators.</p>"
        End Function

#End Region

#Region "Implementation"

        Private Function CreateSection(ByVal tickColor As NColor, ByVal labelColor As NColor, ByVal range As NRange) As NScaleSection
            Dim scaleSection As NScaleSection = New NScaleSection()
            scaleSection.Range = range
            scaleSection.MajorTickFill = New NColorFill(tickColor)
            Dim labelStyle As NTextStyle = New NTextStyle()
            labelStyle.Fill = New NColorFill(labelColor)
            labelStyle.Font = New NFont("Arimo", 12, ENFontStyle.Bold)
            scaleSection.LabelTextStyle = labelStyle
            Return scaleSection
        End Function

        Private Sub ConfigureScale(ByVal scale As NLinearScale, ByVal text As String)
            scale.SetPredefinedScale(ENPredefinedScaleStyle.PresentationNoStroke)
            scale.Labels.Style.TextStyle.Font = New NFont("Arimo", 12.0, ENFontStyle.Bold)
            scale.Labels.Style.TextStyle.Fill = New NColorFill(NColor.White)
            scale.Labels.Style.Angle = New NScaleLabelAngle(ENScaleLabelAngleMode.Scale, 90)
            scale.MinorTickCount = 4
            scale.Ruler.Stroke.Width = 0
            scale.Ruler.Fill = New NColorFill(NColor.FromColor(NColor.DarkGray, 0.4F))
            scale.Title.RulerAlignment = ENHorizontalAlignment.Left
            scale.Title.Text = text
            scale.Title.Angle = New NScaleLabelAngle(ENScaleLabelAngleMode.View, 0)
            scale.Title.Offset = 0.0
            scale.Title.TextStyle.Font.Size = 12
            scale.Title.TextStyle.Font.Style = ENFontStyle.Bold
            scale.Title.TextStyle.Fill = New NStockGradientFill(NColor.White, NColor.LightBlue)
            scale.InflateViewRangeBegin = False
            scale.InflateViewRangeEnd = False
        End Sub

        Private Shared Function FarenheitToCelsius(ByVal farenheit As Double) As Double
            Return (farenheit - 32.0) * 5.0 / 9.0
        End Function

        Private Shared Function CelsiusToFarenheit(ByVal celsius As Double) As Double
            Return celsius * 9.0 / 5.0 + 32.0F
        End Function

#End Region

#Region "Event Handlers"

        Private Sub OnRangeIndicatorOriginModeComboBoxSelectedIndexChanged(ByVal arg As NValueChangeEventArgs)
            m_Indicator1.OriginMode = CType(m_RangeIndicatorOriginModeComboBox.SelectedIndex, ENRangeIndicatorOriginMode)

            If m_Indicator1.OriginMode <> ENRangeIndicatorOriginMode.Custom Then
                m_RangeIndicatorOriginUpDown.Enabled = False
            Else
                m_RangeIndicatorOriginUpDown.Enabled = True
            End If
        End Sub

        Private Sub OnGaugeOrientationComboSelectedIndexChanged(ByVal arg As NValueChangeEventArgs)
            m_LinearGauge.Orientation = CType(m_GaugeOrientationCombo.SelectedIndex, ENLinearGaugeOrientation)

            If m_LinearGauge.Orientation = ENLinearGaugeOrientation.Horizontal Then
                m_LinearGauge.PreferredSize = New NSize(400, 150)
                m_LinearGauge.Padding = New NMargins(20, 0, 10, 0)
            Else
                m_LinearGauge.PreferredSize = New NSize(150, 400)
                m_LinearGauge.Padding = New NMargins(0, 10, 0, 20)
            End If
        End Sub

        Private Sub OnValueIndicatorUpDownValueChanged(ByVal arg As NValueChangeEventArgs)
            m_Indicator2.Value = m_ValueIndicatorUpDown.Value
        End Sub

        Private Sub OnRangeIndicatorValueUpDownValueChanged(ByVal arg As NValueChangeEventArgs)
            m_Indicator1.Value = m_RangeIndicatorValueUpDown.Value
        End Sub

        Private Sub OnRangeIndicatorOriginUpDownValueChanged(ByVal arg As NValueChangeEventArgs)
            m_Indicator1.Origin = m_RangeIndicatorOriginUpDown.Value
        End Sub

        Private Sub OnValueIndicatorShapeComboBoxSelectedIndexChanged(ByVal arg As NValueChangeEventArgs)
            m_Indicator2.Shape = CType(m_ValueIndicatorShapeComboBox.SelectedIndex, ENScaleValueMarkerShape)
        End Sub

        Private Sub ShowMarkerEditorButton_Click(ByVal sender As Object, ByVal e As EventArgs)
        End Sub

        Private Sub MarkerWidthUpDown_ValueChanged(ByVal sender As Object, ByVal e As EventArgs)
            m_Indicator2.Width = m_MarkerWidthUpDown.Value
        End Sub

        Private Sub MarkerHeightUpDown_ValueChanged(ByVal sender As Object, ByVal e As EventArgs)
            m_Indicator2.Height = m_MarkerHeightUpDown.Value
        End Sub

#End Region

#Region "Fields"

        Private m_LinearGauge As NLinearGauge
        Private m_Indicator1 As NRangeIndicator
        Private m_Indicator2 As NMarkerValueIndicator
        Private m_RangeIndicatorValueUpDown As NNumericUpDown
        Private m_RangeIndicatorOriginUpDown As NNumericUpDown
        Private m_ValueIndicatorUpDown As NNumericUpDown
        Private m_RangeIndicatorOriginModeComboBox As NComboBox
        Private m_ValueIndicatorShapeComboBox As NComboBox
        Private m_GaugeOrientationCombo As NComboBox
        Private m_MarkerWidthUpDown As NNumericUpDown
        Private m_MarkerHeightUpDown As NNumericUpDown

#End Region

#Region "Schema"

        Public Shared ReadOnly NLinearGaugeIndicatorsExampleSchema As NSchema

#End Region

#Region "Static Methods"

        Protected Function CreateBorder() As NBorder
            Return NBorder.CreateThreeColorBorder(NColor.LightGray, NColor.White, NColor.DarkGray, 10, 10)
        End Function

#End Region
    End Class
End Namespace

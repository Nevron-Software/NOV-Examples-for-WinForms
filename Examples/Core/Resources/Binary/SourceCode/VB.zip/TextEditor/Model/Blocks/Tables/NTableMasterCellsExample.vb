Imports Nevron.Nov.Dom
Imports Nevron.Nov.Graphics
Imports Nevron.Nov.Text
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.Text
    ''' <summary>
    ''' The example demonstrates how to programmatically create paragraphs with differnt inline formatting
    ''' </summary>
    Public Class NTableMasterCellsExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' 
        ''' </summary>
        Public Sub New()
        End Sub
        ''' <summary>
        ''' 
        ''' </summary>
        Shared Sub New()
            NTableMasterCellsExampleSchema = NSchema.Create(GetType(NTableMasterCellsExample), NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            ' Create the rich text
            Dim richTextWithRibbon As NRichTextViewWithRibbon = New NRichTextViewWithRibbon()
            m_RichText = richTextWithRibbon.View
            m_RichText.AcceptsTab = True
            m_RichText.Content.Sections.Clear()

            ' Populate the rich text
            PopulateRichText()
            Return richTextWithRibbon
        End Function

        Protected Overrides Function CreateExampleControls() As NWidget
            Return Nothing
        End Function

        Protected Overrides Function GetExampleDescription() As String
            Return "
<p>
	This example demonstrates how to programmatically create row and column master cells.
</p>
"
        End Function

        Private Sub PopulateRichText()
            Dim section As NSection = New NSection()
            m_RichText.Content.Sections.Add(section)
            section.Blocks.Add(GetDescriptionBlock("Table Master Cells Example", "This example shows how to programmatically create and add master cells.", 1))

            ' first create the table
            Dim table As NTable = New NTable(5, 5)
            table.AllowSpacingBetweenCells = False

            For row = 0 To table.Rows.Count - 1

                For col = 0 To table.Columns.Count - 1
                    Dim paragraph As NParagraph = New NParagraph("Normal Cell")
                    Dim tableCell = table.Rows(row).Cells(col)
                    tableCell.BorderThickness = New NMargins(1)
                    tableCell.Border = NBorder.CreateFilledBorder(NColor.Black)

                    ' by default cells contain a single paragraph
                    tableCell.Blocks.Clear()
                    tableCell.Blocks.Add(paragraph)
                Next
            Next

            ' set cell [0, 2] to be column master
            Dim colMasterCell = table.Rows(0).Cells(2)
            colMasterCell.ColSpan = 2
            colMasterCell.BackgroundFill = New NColorFill(ENNamedColor.LightSkyBlue)
            colMasterCell.Blocks.Clear()
            colMasterCell.Blocks.Add(New NParagraph("Column Master Cell"))

            ' set cell [1, 0] to be row master
            Dim rowMasterCell = table.Rows(1).Cells(0)
            rowMasterCell.RowSpan = 2
            rowMasterCell.BackgroundFill = New NColorFill(ENNamedColor.LightSteelBlue)
            rowMasterCell.Blocks.Clear()
            rowMasterCell.Blocks.Add(New NParagraph("Row Master Cell"))

            ' set cell [2, 2] to be column and row master
            Dim rowColMasterCell = table.Rows(2).Cells(2)
            rowColMasterCell.ColSpan = 2
            rowColMasterCell.RowSpan = 2
            rowColMasterCell.BackgroundFill = New NColorFill(ENNamedColor.MediumTurquoise)
            rowColMasterCell.Blocks.Clear()
            rowColMasterCell.Blocks.Add(New NParagraph("Row\Col Master Cell"))
            section.Blocks.Add(table)
        End Sub

#End Region

#Region "Fields"

        Private m_RichText As NRichTextView

#End Region

#Region "Schema"

        Public Shared ReadOnly NTableMasterCellsExampleSchema As NSchema

#End Region


#Region "Static Methods"

        Private Shared Function GetDescriptionParagraph(ByVal text As String) As NParagraph
            Return New NParagraph(text)
        End Function

        Private Shared Function GetTitleParagraphNoBorder(ByVal text As String, ByVal level As Integer) As NParagraph
            Dim fontSize As Double = 10
            Dim fontStyle = ENFontStyle.Regular

            Select Case level
                Case 1
                    fontSize = 16
                    fontStyle = ENFontStyle.Bold
                Case 2
                    fontSize = 10
                    fontStyle = ENFontStyle.Bold
            End Select

            Dim paragraph As NParagraph = New NParagraph()
            paragraph.HorizontalAlignment = ENAlign.Left
            paragraph.FontSize = fontSize
            paragraph.FontStyle = fontStyle
            Dim textInline As NTextInline = New NTextInline(text)
            textInline.FontStyle = fontStyle
            textInline.FontSize = fontSize
            paragraph.Inlines.Add(textInline)
            Return paragraph
        End Function
        ''' <summary>
        ''' Gets a paragraph with title formatting
        ''' </summary>
        ''' <paramname="text"></param>
        ''' <returns></returns>
        Private Shared Function GetDescriptionBlock(ByVal title As String, ByVal description As String, ByVal level As Integer) As NGroupBlock
            Dim color = NColor.Black
            Dim paragraph = GetTitleParagraphNoBorder(title, level)
            Dim groupBlock As NGroupBlock = New NGroupBlock()
            groupBlock.ClearMode = ENClearMode.All
            groupBlock.Blocks.Add(paragraph)
            groupBlock.Blocks.Add(GetDescriptionParagraph(description))
            groupBlock.Border = CreateLeftTagBorder(color)
            groupBlock.BorderThickness = defaultBorderThickness
            Return groupBlock
        End Function
        ''' <summary>
        ''' Creates a left tag border with the specified border
        ''' </summary>
        ''' <paramname="color"></param>
        ''' <returns></returns>
        Private Shared Function CreateLeftTagBorder(ByVal color As NColor) As NBorder
            Dim border As NBorder = New NBorder()
            border.LeftSide = New NBorderSide()
            border.LeftSide.Fill = New NColorFill(color)
            Return border
        End Function

#End Region

#Region "Constants"

        Private Shared ReadOnly defaultBorderThickness As NMargins = New NMargins(5.0, 0.0, 0.0, 0.0)

#End Region
    End Class
End Namespace

Imports Nevron.Nov.Barcode
Imports Nevron.Nov.Dom
Imports Nevron.Nov.Graphics
Imports Nevron.Nov.Text
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.Text
    Public Class NBarcodesInRichTextExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' Default constructor.
        ''' </summary>
        Public Sub New()
        End Sub

        ''' <summary>
        ''' Static constructor.
        ''' </summary>
        Shared Sub New()
            NBarcodesInRichTextExampleSchema = NSchema.Create(GetType(NBarcodesInRichTextExample), NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            ' Create the rich text
            Dim richTextWithRibbon As NRichTextViewWithRibbon = New NRichTextViewWithRibbon()
            m_RichText = richTextWithRibbon.View
            m_RichText.AcceptsTab = True
            m_RichText.Content.Sections.Clear()

            ' Populate the rich text
            PopulateRichText()
            Return richTextWithRibbon
        End Function

        Protected Overrides Function CreateExampleControls() As NWidget
            Return Nothing
        End Function

        Protected Overrides Function GetExampleDescription() As String
            Return "
<p>
	This example demonstrates how to embed barcodes in rich text documents as widget inlines.
	If you right click the barcode widget you will be able to edit its content and appearance
	through the ""Edit Barcode..."" option.
</p>
"
        End Function

        Private Sub PopulateRichText()
            Dim documentBlock = m_RichText.Content
            documentBlock.Layout = ENTextLayout.Print
            Dim section As NSection = New NSection()
            documentBlock.Sections.Add(section)
            section.Blocks.Add(GetDescriptionBlock("Barcode Widget Inlines", "Nevron Open Vision lets you easily insert barcodes in text documents as widget inlines.", 1))

            ' Create a table
            Dim table As NTable = New NTable(2, 2)
            section.Blocks.Add(table)

            ' Create a linear barcode
            Dim linearBarcode As NLinearBarcode = New NLinearBarcode(ENLinearBarcodeSymbology.EAN13, "0123456789012")
            Dim widgetInline As NWidgetInline = New NWidgetInline(linearBarcode)

            ' Create a paragraph to host the linear barcode widget inline
            Dim cell = table.Rows(0).Cells(0)
            cell.HorizontalAlignment = ENAlign.Center
            Dim paragraph = CType(cell.Blocks(0), NParagraph)
            paragraph.Inlines.Add(widgetInline)

            ' Create a paragraph to the right with some text
            cell = table.Rows(0).Cells(1)
            paragraph = CType(cell.Blocks(0), NParagraph)
            paragraph.Inlines.Add(New NTextInline("The linear barcode to the left uses the EAN13 symbology."))

            ' Create a QR code widget inline
            Dim qrCode As NMatrixBarcode = New NMatrixBarcode(ENMatrixBarcodeSymbology.QrCode, "https://www.nevron.com")
            widgetInline = New NWidgetInline(qrCode)

            ' Create a paragraph to host the QR code widget inline
            cell = table.Rows(1).Cells(0)
            cell.HorizontalAlignment = ENAlign.Center
            paragraph = CType(cell.Blocks(0), NParagraph)
            paragraph.Inlines.Add(widgetInline)

            ' Create a paragraph to the right with some text
            cell = table.Rows(1).Cells(1)
            paragraph = CType(cell.Blocks(0), NParagraph)
            paragraph.Inlines.Add(New NTextInline("The QR code to the left contains a link to "))
            paragraph.Inlines.Add(New NHyperlinkInline("https://www.nevron.com", "https://www.nevron.com"))
            paragraph.Inlines.Add(New NTextInline("."))
        End Sub

#End Region

#Region "Fields"

        Private m_RichText As NRichTextView

#End Region

#Region "Schema"

        ''' <summary>
        ''' Schema associated with NBarcodesInRichTextExample.
        ''' </summary>
        Public Shared ReadOnly NBarcodesInRichTextExampleSchema As NSchema

#End Region


#Region "Static Methods"

        Private Shared Function GetDescriptionParagraph(ByVal text As String) As NParagraph
            Return New NParagraph(text)
        End Function

        Private Shared Function GetTitleParagraphNoBorder(ByVal text As String, ByVal level As Integer) As NParagraph
            Dim fontSize As Double = 10
            Dim fontStyle = ENFontStyle.Regular

            Select Case level
                Case 1
                    fontSize = 16
                    fontStyle = ENFontStyle.Bold
                Case 2
                    fontSize = 10
                    fontStyle = ENFontStyle.Bold
            End Select

            Dim paragraph As NParagraph = New NParagraph()
            paragraph.HorizontalAlignment = ENAlign.Left
            paragraph.FontSize = fontSize
            paragraph.FontStyle = fontStyle
            Dim textInline As NTextInline = New NTextInline(text)
            textInline.FontStyle = fontStyle
            textInline.FontSize = fontSize
            paragraph.Inlines.Add(textInline)
            Return paragraph
        End Function
        ''' <summary>
        ''' Gets a paragraph with title formatting
        ''' </summary>
        ''' <paramname="text"></param>
        ''' <returns></returns>
        Private Shared Function GetTitleParagraph(ByVal text As String, ByVal level As Integer) As NParagraph
            Dim color = NColor.Black
            Dim paragraph = GetTitleParagraphNoBorder(text, level)
            paragraph.HorizontalAlignment = ENAlign.Left
            paragraph.Border = CreateLeftTagBorder(color)
            paragraph.BorderThickness = defaultBorderThickness
            Return paragraph
        End Function

        Private Shared Function GetNoteBlock(ByVal text As String, ByVal level As Integer) As NGroupBlock
            Dim color = NColor.Red
            Dim paragraph = GetTitleParagraphNoBorder("Note", level)
            Dim groupBlock As NGroupBlock = New NGroupBlock()
            groupBlock.ClearMode = ENClearMode.All
            groupBlock.Blocks.Add(paragraph)
            groupBlock.Blocks.Add(GetDescriptionParagraph(text))
            groupBlock.Border = CreateLeftTagBorder(color)
            groupBlock.BorderThickness = defaultBorderThickness
            Return groupBlock
        End Function

        Private Shared Function GetDescriptionBlock(ByVal title As String, ByVal description As String, ByVal level As Integer) As NGroupBlock
            Dim color = NColor.Black
            Dim paragraph = GetTitleParagraphNoBorder(title, level)
            Dim groupBlock As NGroupBlock = New NGroupBlock()
            groupBlock.ClearMode = ENClearMode.All
            groupBlock.Blocks.Add(paragraph)
            groupBlock.Blocks.Add(GetDescriptionParagraph(description))
            groupBlock.Border = CreateLeftTagBorder(color)
            groupBlock.BorderThickness = defaultBorderThickness
            Return groupBlock
        End Function
        ''' <summary>
        ''' Creates a left tag border with the specified border
        ''' </summary>
        ''' <paramname="color"></param>
        ''' <returns></returns>
        Private Shared Function CreateLeftTagBorder(ByVal color As NColor) As NBorder
            Dim border As NBorder = New NBorder()
            border.LeftSide = New NBorderSide()
            border.LeftSide.Fill = New NColorFill(color)
            Return border
        End Function

        Private Shared Function GetLoremIpsumParagraph() As NParagraph
            Return New NParagraph("Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vestibulum placerat in tortor nec tincidunt. Sed sagittis in sem ac auctor. Donec scelerisque molestie eros, a dictum leo fringilla eu. Vivamus porta urna non ullamcorper commodo. Nulla posuere sodales pellentesque. Donec a erat et tortor viverra euismod non et erat. Donec dictum ante eu mauris porta, eget suscipit mi ultrices. Nunc convallis adipiscing ligula, non pharetra dolor egestas at. Etiam in condimentum sapien. Praesent sagittis pulvinar metus, a posuere mauris aliquam eget.")
        End Function

#End Region

#Region "Constants"

        Private Shared ReadOnly defaultBorderThickness As NMargins = New NMargins(5.0, 0.0, 0.0, 0.0)

#End Region
    End Class
End Namespace

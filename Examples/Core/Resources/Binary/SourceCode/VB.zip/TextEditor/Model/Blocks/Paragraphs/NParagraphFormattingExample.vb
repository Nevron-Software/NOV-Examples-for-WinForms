Imports System.Text
Imports Nevron.Nov.Dom
Imports Nevron.Nov.Graphics
Imports Nevron.Nov.Text
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.Text
    ''' <summary>
    ''' The example demonstrates how to programmatically create paragraphs with differnt formatting
    ''' </summary>
    Public Class NParagraphFormattingExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' 
        ''' </summary>
        Public Sub New()
        End Sub
        ''' <summary>
        ''' 
        ''' </summary>
        Shared Sub New()
            NParagraphFormattingExampleSchema = NSchema.Create(GetType(NParagraphFormattingExample), NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            ' Create the rich text
            Dim richTextWithRibbon As NRichTextViewWithRibbon = New NRichTextViewWithRibbon()
            m_RichText = richTextWithRibbon.View
            m_RichText.AcceptsTab = True
            m_RichText.Content.Sections.Clear()

            ' Populate the rich text
            PopulateRichText()
            Return richTextWithRibbon
        End Function

        Protected Overrides Function CreateExampleControls() As NWidget
            Return Nothing
        End Function

        Protected Overrides Function GetExampleDescription() As String
            Return "
<p>
	This example demonstrates how to use different paragraph formatting properties.
</p>
"
        End Function

        Private Sub PopulateRichText()
            Dim section As NSection = New NSection()
            m_RichText.Content.Sections.Add(section)

            ' paragraphs with different horizontal alignment
            section.Blocks.Add(GetDescriptionBlock("Paragraph Formatting Example", "The following examples show different paragraph formatting properties.", 1))
            section.Blocks.Add(GetTitleParagraph("Paragraphs with different horizontal alignment", 2))
            Dim paragraph As NParagraph

            For i = 0 To 4 - 1
                paragraph = New NParagraph()

                Select Case i
                    Case 0
                        paragraph.HorizontalAlignment = ENAlign.Left
                        paragraph.Inlines.Add(New NTextInline(GetAlignedParagraphText("left")))
                    Case 1
                        paragraph.HorizontalAlignment = ENAlign.Center
                        paragraph.Inlines.Add(New NTextInline(GetAlignedParagraphText("center")))
                    Case 2
                        paragraph.HorizontalAlignment = ENAlign.Right
                        paragraph.Inlines.Add(New NTextInline(GetAlignedParagraphText("right")))
                    Case 3
                        paragraph.HorizontalAlignment = ENAlign.Justify
                        paragraph.Inlines.Add(New NTextInline(GetAlignedParagraphText("justify")))
                End Select

                section.Blocks.Add(paragraph)
            Next

            section.Blocks.Add(GetTitleParagraph("Paragraphs with Margins, Padding and Borders", 2))

            If True Then
                ' borders
                paragraph = New NParagraph()
                paragraph.BorderThickness = New NMargins(2, 2, 2, 2)
                paragraph.Border = NBorder.CreateFilledBorder(NColor.Red)
                paragraph.PreferredWidth = NMultiLength.NewPercentage(50)
                paragraph.Margins = New NMargins(5, 5, 5, 5)
                paragraph.Padding = New NMargins(5, 5, 5, 5)
                paragraph.PreferredWidth = NMultiLength.NewFixed(300)
                paragraph.PreferredHeight = NMultiLength.NewFixed(100)
                Dim textInline1 As NTextInline = New NTextInline("Paragraphs can have border, margins and padding as well as preffered size")
                paragraph.Inlines.Add(textInline1)
                section.Blocks.Add(paragraph)
            End If

            ' First line indent and hanging indent
            section.Blocks.Add(GetTitleParagraph("Paragraph with First Line Indent and Hanging Indent", 2))
            Dim paragraphWithIndents As NParagraph = New NParagraph(GetRepeatingText("First line indent -10dip, hanging indent 15dip.", 5))
            paragraphWithIndents.FirstLineIndent = -10
            paragraphWithIndents.HangingIndent = 15
            section.Blocks.Add(paragraphWithIndents)

            ' First line indent and hanging indent
            section.Blocks.Add(GetTitleParagraph("Line Spacing", 2))
            Dim paragraphWithMultipleLineSpacing As NParagraph = New NParagraph(GetRepeatingText("Line space is two times bigger than normal", 10))
            paragraphWithMultipleLineSpacing.LineHeightMode = ENLineHeightMode.Multiple
            paragraphWithMultipleLineSpacing.LineHeightFactor = 2.0
            section.Blocks.Add(paragraphWithMultipleLineSpacing)
            Dim paragraphWithAtLeastLineSpacing As NParagraph = New NParagraph(GetRepeatingText("Line space is at least 20 dips.", 10))
            paragraphWithAtLeastLineSpacing.LineHeightMode = ENLineHeightMode.AtLeast
            paragraphWithAtLeastLineSpacing.LineHeight = 20.0
            section.Blocks.Add(paragraphWithAtLeastLineSpacing)
            Dim paragraphWithExactLineSpacing As NParagraph = New NParagraph(GetRepeatingText("Line space is exactly 20 dips.", 10))
            paragraphWithExactLineSpacing.LineHeightMode = ENLineHeightMode.Exactly
            paragraphWithExactLineSpacing.LineHeight = 20.0
            section.Blocks.Add(paragraphWithExactLineSpacing)

            ' BIDI formatting
            section.Blocks.Add(GetTitleParagraph("Paragraphs with BIDI text", 2))
            paragraph = New NParagraph()
            Dim latinText1 As NTextInline = New NTextInline("This is some text in English. Followed by Arabic:")
            Dim arabicText As NTextInline = New NTextInline("أساسًا، تتعامل الحواسيب فقط مع الأرقام، وتقوم بتخزين الأحرف والمحارف الأخرى بعد أن تُعطي رقما معينا لكل واحد منها. وقبل اختراع ")
            Dim latinText2 As NTextInline = New NTextInline("This is some text in English.")
            paragraph.Inlines.Add(latinText1)
            paragraph.Inlines.Add(arabicText)
            paragraph.Inlines.Add(latinText2)
            section.Blocks.Add(paragraph)
        End Sub

#End Region

#Region "Implementation"

        ''' <summary>
        ''' Gets dummy text for aligned paragraphs
        ''' </summary>
        ''' <paramname="alignment"></param>
        ''' <returns></returns>
        Private Shared Function GetAlignedParagraphText(ByVal alignment As String) As String
            Dim text = String.Empty

            For i = 0 To 10 - 1

                If text.Length > 0 Then
                    text += " "
                End If

                text += "This is a " & alignment & " aligned paragraph."
            Next

            Return text
        End Function

#End Region

#Region "Fields"

        Private m_RichText As NRichTextView

#End Region

#Region "Schema"

        Public Shared ReadOnly NParagraphFormattingExampleSchema As NSchema

#End Region

#Region "Static Methods"

        Private Shared Function GetDescriptionParagraph(ByVal text As String) As NParagraph
            Return New NParagraph(text)
        End Function

        Private Shared Function GetTitleParagraphNoBorder(ByVal text As String, ByVal level As Integer) As NParagraph
            Dim fontSize As Double = 10
            Dim fontStyle = ENFontStyle.Regular

            Select Case level
                Case 1
                    fontSize = 16
                    fontStyle = ENFontStyle.Bold
                Case 2
                    fontSize = 10
                    fontStyle = ENFontStyle.Bold
            End Select

            Dim paragraph As NParagraph = New NParagraph()
            paragraph.HorizontalAlignment = ENAlign.Left
            paragraph.FontSize = fontSize
            paragraph.FontStyle = fontStyle
            Dim textInline As NTextInline = New NTextInline(text)
            textInline.FontStyle = fontStyle
            textInline.FontSize = fontSize
            paragraph.Inlines.Add(textInline)
            Return paragraph
        End Function
        ''' <summary>
        ''' Gets a paragraph with title formatting
        ''' </summary>
        ''' <paramname="text"></param>
        ''' <returns></returns>
        Private Shared Function GetTitleParagraph(ByVal text As String, ByVal level As Integer) As NParagraph
            Dim color = NColor.Black
            Dim paragraph = GetTitleParagraphNoBorder(text, level)
            paragraph.HorizontalAlignment = ENAlign.Left
            paragraph.Border = CreateLeftTagBorder(color)
            paragraph.BorderThickness = defaultBorderThickness
            Return paragraph
        End Function

        Private Shared Function GetDescriptionBlock(ByVal title As String, ByVal description As String, ByVal level As Integer) As NGroupBlock
            Dim color = NColor.Black
            Dim paragraph = GetTitleParagraphNoBorder(title, level)
            Dim groupBlock As NGroupBlock = New NGroupBlock()
            groupBlock.ClearMode = ENClearMode.All
            groupBlock.Blocks.Add(paragraph)
            groupBlock.Blocks.Add(GetDescriptionParagraph(description))
            groupBlock.Border = CreateLeftTagBorder(color)
            groupBlock.BorderThickness = defaultBorderThickness
            Return groupBlock
        End Function
        ''' <summary>
        ''' Creates a left tag border with the specified border
        ''' </summary>
        ''' <paramname="color"></param>
        ''' <returns></returns>
        Private Shared Function CreateLeftTagBorder(ByVal color As NColor) As NBorder
            Dim border As NBorder = New NBorder()
            border.LeftSide = New NBorderSide()
            border.LeftSide.Fill = New NColorFill(color)
            Return border
        End Function
        ''' <summary>
        ''' Gets the specified text repeated
        ''' </summary>
        ''' <paramname="text"></param>
        ''' <paramname="count"></param>
        ''' <returns></returns>
        Private Shared Function GetRepeatingText(ByVal text As String, ByVal count As Integer) As String
            Dim builder As StringBuilder = New StringBuilder()

            For i = 0 To count - 1

                If builder.Length > 0 Then
                    builder.Append(" ")
                End If

                builder.Append(text)
            Next

            Return builder.ToString()
        End Function

#End Region

#Region "Constants"

        Private Shared ReadOnly defaultBorderThickness As NMargins = New NMargins(5.0, 0.0, 0.0, 0.0)

#End Region
    End Class
End Namespace

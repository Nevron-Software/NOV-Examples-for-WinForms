Imports Nevron.Nov.Dom
Imports Nevron.Nov.Graphics
Imports Nevron.Nov.Text
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.Text
    ''' <summary>
    ''' The example demonstrates how to programmatically create inline elements with different formatting
    ''' </summary>
    Public Class NInlineFormattingExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' 
        ''' </summary>
        Public Sub New()
        End Sub
        ''' <summary>
        ''' 
        ''' </summary>
        Shared Sub New()
            NInlineFormattingExampleSchema = NSchema.Create(GetType(NInlineFormattingExample), NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            ' Create the rich text
            Dim richTextWithRibbon As NRichTextViewWithRibbon = New NRichTextViewWithRibbon()
            m_RichText = richTextWithRibbon.View
            m_RichText.AcceptsTab = True
            m_RichText.Content.Sections.Clear()

            ' Populate the rich text
            PopulateRichText()
            Return richTextWithRibbon
        End Function

        Protected Overrides Function CreateExampleControls() As NWidget
            Return Nothing
        End Function

        Protected Overrides Function GetExampleDescription() As String
            Return "
<p>
	This example demonstrates how to text style and appearance settings of inline elements as well as how to add line breaks and tabs to paragraphs.
</p>
"
        End Function

        Private Sub PopulateRichText()
            Dim section As NSection = New NSection()
            m_RichText.Content.Sections.Add(section)
            section.Blocks.Add(GetDescriptionBlock("Inline Formatting", "The example shows how to add inlines with different formatting to a paragraph.", 1))

            If True Then
                ' font style control
                Dim paragraph As NParagraph = New NParagraph()
                Dim textInline1 As NTextInline = New NTextInline("This paragraph contains text inlines with altered ")
                paragraph.Inlines.Add(textInline1)
                Dim textInline2 As NTextInline = New NTextInline("Font Name, ")
                textInline2.FontName = "Tahoma"
                paragraph.Inlines.Add(textInline2)
                Dim textInline3 As NTextInline = New NTextInline("Font Size, ")
                textInline3.FontSize = 14
                paragraph.Inlines.Add(textInline3)
                Dim textInline4 As NTextInline = New NTextInline("Font Style (Bold), ")
                textInline4.FontStyle = textInline4.FontStyle Or ENFontStyle.Bold
                paragraph.Inlines.Add(textInline4)
                Dim textInline5 As NTextInline = New NTextInline("Font Style (Italic), ")
                textInline5.FontStyle = textInline5.FontStyle Or ENFontStyle.Italic
                paragraph.Inlines.Add(textInline5)
                Dim textInline6 As NTextInline = New NTextInline("Font Style (Underline), ")
                textInline6.FontStyle = textInline6.FontStyle Or ENFontStyle.Underline
                paragraph.Inlines.Add(textInline6)
                Dim textInline7 As NTextInline = New NTextInline("Font Style (StrikeTrough) ")
                textInline7.FontStyle = textInline7.FontStyle Or ENFontStyle.Strikethrough
                paragraph.Inlines.Add(textInline7)
                Dim textInline8 As NTextInline = New NTextInline(", and Font Style All.")
                textInline8.FontStyle = ENFontStyle.Bold Or ENFontStyle.Italic Or ENFontStyle.Underline Or ENFontStyle.Strikethrough
                paragraph.Inlines.Add(textInline8)
                section.Blocks.Add(paragraph)
            End If

            If True Then
                ' appearance control
                Dim paragraph As NParagraph = New NParagraph()
                Dim textInline1 As NTextInline = New NTextInline("Each text inline element can contain text with different fill and background. ")
                paragraph.Inlines.Add(textInline1)
                Dim textInline2 As NTextInline = New NTextInline("Fill (Red), Background Fill Inherit. ")
                textInline2.Fill = New NColorFill(ENNamedColor.Red)
                paragraph.Inlines.Add(textInline2)
                Dim textInline3 As NTextInline = New NTextInline("Fill inherit, Background Fill (Green).")
                textInline3.BackgroundFill = New NColorFill(ENNamedColor.Green)
                paragraph.Inlines.Add(textInline3)
                section.Blocks.Add(paragraph)
            End If

            If True Then
                ' line breaks
                ' appearance control
                Dim paragraph As NParagraph = New NParagraph()
                Dim textInline1 As NTextInline = New NTextInline("Line breaks allow you to break...")
                paragraph.Inlines.Add(textInline1)
                Dim lineBreak As NLineBreakInline = New NLineBreakInline()
                paragraph.Inlines.Add(lineBreak)
                Dim textInline2 As NTextInline = New NTextInline("the current line in the paragraph.")
                paragraph.Inlines.Add(textInline2)
                section.Blocks.Add(paragraph)
            End If

            If True Then
                ' tabs
                Dim paragraph As NParagraph = New NParagraph()
                Dim tabInline As NTabInline = New NTabInline()
                paragraph.Inlines.Add(tabInline)
                Dim textInline1 As NTextInline = New NTextInline("(Tabs) are not supported by HTML, however, they are essential when importing text documents.")
                paragraph.Inlines.Add(textInline1)
                section.Blocks.Add(paragraph)
            End If
        End Sub

#End Region

#Region "Fields"

        Private m_RichText As NRichTextView

#End Region

#Region "Schema"

        Public Shared ReadOnly NInlineFormattingExampleSchema As NSchema

#End Region

#Region "Static Methods"

        Private Shared Function GetDescriptionParagraph(ByVal text As String) As NParagraph
            Return New NParagraph(text)
        End Function

        Private Shared Function GetTitleParagraphNoBorder(ByVal text As String, ByVal level As Integer) As NParagraph
            Dim fontSize As Double = 10
            Dim fontStyle = ENFontStyle.Regular

            Select Case level
                Case 1
                    fontSize = 16
                    fontStyle = ENFontStyle.Bold
                Case 2
                    fontSize = 10
                    fontStyle = ENFontStyle.Bold
            End Select

            Dim paragraph As NParagraph = New NParagraph()
            paragraph.HorizontalAlignment = ENAlign.Left
            paragraph.FontSize = fontSize
            paragraph.FontStyle = fontStyle
            Dim textInline As NTextInline = New NTextInline(text)
            textInline.FontStyle = fontStyle
            textInline.FontSize = fontSize
            paragraph.Inlines.Add(textInline)
            Return paragraph
        End Function

        Private Shared Function GetDescriptionBlock(ByVal title As String, ByVal description As String, ByVal level As Integer) As NGroupBlock
            Dim color = NColor.Black
            Dim paragraph = GetTitleParagraphNoBorder(title, level)
            Dim groupBlock As NGroupBlock = New NGroupBlock()
            groupBlock.ClearMode = ENClearMode.All
            groupBlock.Blocks.Add(paragraph)
            groupBlock.Blocks.Add(GetDescriptionParagraph(description))
            groupBlock.Border = CreateLeftTagBorder(color)
            groupBlock.BorderThickness = defaultBorderThickness
            Return groupBlock
        End Function
        ''' <summary>
        ''' Creates a left tag border with the specified border
        ''' </summary>
        ''' <paramname="color"></param>
        ''' <returns></returns>
        Private Shared Function CreateLeftTagBorder(ByVal color As NColor) As NBorder
            Dim border As NBorder = New NBorder()
            border.LeftSide = New NBorderSide()
            border.LeftSide.Fill = New NColorFill(color)
            Return border
        End Function

#End Region

#Region "Constants"

        Private Shared ReadOnly defaultBorderThickness As NMargins = New NMargins(5.0, 0.0, 0.0, 0.0)

#End Region
    End Class
End Namespace

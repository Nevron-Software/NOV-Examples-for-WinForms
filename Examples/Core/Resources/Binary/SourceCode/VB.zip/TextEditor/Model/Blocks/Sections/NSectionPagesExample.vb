Imports Nevron.Nov.Dom
Imports Nevron.Nov.Graphics
Imports Nevron.Nov.Text
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.Text
    ''' <summary>
    ''' The example demonstrates how to programmatically create paragraphs with differnt formatting
    ''' </summary>
    Public Class NSectionPagesExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' 
        ''' </summary>
        Public Sub New()
        End Sub
        ''' <summary>
        ''' 
        ''' </summary>
        Shared Sub New()
            NSectionPagesExampleSchema = NSchema.Create(GetType(NSectionPagesExample), NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            ' Create the rich text
            Dim richTextWithRibbon As NRichTextViewWithRibbon = New NRichTextViewWithRibbon()
            m_RichText = richTextWithRibbon.View
            m_RichText.AcceptsTab = True
            m_RichText.Content.Sections.Clear()

            ' Populate the rich text
            PopulateRichText()
            Return richTextWithRibbon
        End Function

        Protected Overrides Function CreateExampleControls() As NWidget
            Return Nothing
        End Function

        Protected Overrides Function GetExampleDescription() As String
            Return "
<p>
	This example demonstrates how to set different page properties, like page size, page orientation, and page border.
</p>
"
        End Function

        Private Sub PopulateRichText()
            m_RichText.Content.Layout = ENTextLayout.Print
            m_RichText.Content.ZoomFactor = 0.5

            For sectionIndex = 0 To 4 - 1
                Dim section As NSection = New NSection()
                section.Margins = NMargins.Zero
                section.Padding = NMargins.Zero
                Dim sectionText = String.Empty

                Select Case sectionIndex
                    Case 0
                        sectionText = "Paper size A4."
                        section.PageSize = New NPaperSize(ENPaperKind.A4)
                        section.BreakType = ENSectionBreakType.NextPage
                        section.Blocks.Add(GetDescriptionBlock("Section Pages", "This example shows how to set different page properties, like page size, page orientation, and page border", 1))
                    Case 1
                        sectionText = "Paper size A5."
                        section.PageSize = New NPaperSize(ENPaperKind.A5)
                        section.BreakType = ENSectionBreakType.NextPage
                    Case 2
                        sectionText = "Paper size A4, paper orientation portrait."
                        section.PageOrientation = ENPageOrientation.Landscape
                        section.PageSize = New NPaperSize(ENPaperKind.A4)
                        section.BreakType = ENSectionBreakType.NextPage
                    Case 3
                        sectionText = "Paper size A4, page border solid 10dip."
                        section.PageBorder = NBorder.CreateFilledBorder(NColor.Black)
                        section.PageBorderThickness = New NMargins(10)
                        section.PageSize = New NPaperSize(ENPaperKind.A4)
                        section.BreakType = ENSectionBreakType.NextPage
                End Select

                m_RichText.Content.Sections.Add(section)

                ' add some content
                Dim paragraph As NParagraph = New NParagraph(sectionText)
                section.Blocks.Add(paragraph)
            Next
        End Sub

#End Region

#Region "Implementation"

        Private Function CreateHeaderFooter(ByVal text As String) As NHeaderFooter
            Dim headerFooter As NHeaderFooter = New NHeaderFooter()
            Dim paragraph As NParagraph = New NParagraph()
            paragraph.Inlines.Add(New NTextInline(text))
            paragraph.Inlines.Add(New NTextInline("Page "))
            paragraph.Inlines.Add(New NFieldInline(ENNumericFieldName.PageNumber))
            paragraph.Inlines.Add(New NTextInline(" of "))
            paragraph.Inlines.Add(New NFieldInline(ENNumericFieldName.PageCount))
            headerFooter.Blocks.Add(paragraph)
            Return headerFooter
        End Function

#End Region

#Region "Fields"

        Private m_RichText As NRichTextView

#End Region

#Region "Schema"

        Public Shared ReadOnly NSectionPagesExampleSchema As NSchema

#End Region

#Region "Static Methods"

        Private Shared Function GetDescriptionParagraph(ByVal text As String) As NParagraph
            Return New NParagraph(text)
        End Function

        Private Shared Function GetTitleParagraphNoBorder(ByVal text As String, ByVal level As Integer) As NParagraph
            Dim fontSize As Double = 10
            Dim fontStyle = ENFontStyle.Regular

            Select Case level
                Case 1
                    fontSize = 16
                    fontStyle = ENFontStyle.Bold
                Case 2
                    fontSize = 10
                    fontStyle = ENFontStyle.Bold
            End Select

            Dim paragraph As NParagraph = New NParagraph()
            paragraph.HorizontalAlignment = ENAlign.Left
            paragraph.FontSize = fontSize
            paragraph.FontStyle = fontStyle
            Dim textInline As NTextInline = New NTextInline(text)
            textInline.FontStyle = fontStyle
            textInline.FontSize = fontSize
            paragraph.Inlines.Add(textInline)
            Return paragraph
        End Function

        Private Shared Function GetDescriptionBlock(ByVal title As String, ByVal description As String, ByVal level As Integer) As NGroupBlock
            Dim color = NColor.Black
            Dim paragraph = GetTitleParagraphNoBorder(title, level)
            Dim groupBlock As NGroupBlock = New NGroupBlock()
            groupBlock.ClearMode = ENClearMode.All
            groupBlock.Blocks.Add(paragraph)
            groupBlock.Blocks.Add(GetDescriptionParagraph(description))
            groupBlock.Border = CreateLeftTagBorder(color)
            groupBlock.BorderThickness = defaultBorderThickness
            Return groupBlock
        End Function
        ''' <summary>
        ''' Creates a left tag border with the specified border
        ''' </summary>
        ''' <paramname="color"></param>
        ''' <returns></returns>
        Private Shared Function CreateLeftTagBorder(ByVal color As NColor) As NBorder
            Dim border As NBorder = New NBorder()
            border.LeftSide = New NBorderSide()
            border.LeftSide.Fill = New NColorFill(color)
            Return border
        End Function

#End Region

#Region "Constants"

        Private Shared ReadOnly defaultBorderThickness As NMargins = New NMargins(5.0, 0.0, 0.0, 0.0)

#End Region
    End Class
End Namespace

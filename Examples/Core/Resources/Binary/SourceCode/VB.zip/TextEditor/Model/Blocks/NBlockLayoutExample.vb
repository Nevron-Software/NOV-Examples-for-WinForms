Imports Nevron.Nov.Dom
Imports Nevron.Nov.Text
Imports Nevron.Nov.UI
Imports Nevron.Nov.Graphics
Imports System.Text

Namespace Nevron.Nov.Examples.Text
    ''' <summary>
    ''' The example demonstrates how to programmatically create paragraphs with differnt inline formatting
    ''' </summary>
    Public Class NBlockLayoutExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' 
        ''' </summary>
        Public Sub New()
        End Sub
        ''' <summary>
        ''' 
        ''' </summary>
        Shared Sub New()
            NBlockLayoutExampleSchema = NSchema.Create(GetType(NBlockLayoutExample), NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            ' Create the rich text
            Dim richTextWithRibbon As NRichTextViewWithRibbon = New NRichTextViewWithRibbon()
            m_RichText = richTextWithRibbon.View
            m_RichText.AcceptsTab = True
            m_RichText.Content.Sections.Clear()

            ' Populate the rich text
            PopulateRichText()
            Return richTextWithRibbon
        End Function

        Protected Overrides Function CreateExampleControls() As NWidget
            Return Nothing
        End Function

        Protected Overrides Function GetExampleDescription() As String
            Return "<p>This example demonstrates how to use margins, padding and borders as well as how to create floating blocks.</p>"
        End Function

        Private Sub PopulateRichText()
            Dim section As NSection = New NSection()
            m_RichText.Content.Sections.Add(section)
            section.Blocks.Add(GetDescriptionBlock("Block Layout", "Every block in the document follows the HTML block formatting model", 1))
            section.Blocks.Add(GetDescriptionBlock("Block Margins, Padding, and Border Thickness", "Every block in the document has margins, border thickness, and padding.", 2))
            section.Blocks.Add(CreateSampleParagraph1())
            section.Blocks.Add(CreateSampleParagraph1())
            section.Blocks.Add(GetNoteBlock("The distance between the above two paragraphs is 10 dips as the margins collapse", 2))
            section.Blocks.Add(GetDescriptionBlock("Floating blocks", "Floating blocks can be positioned on the left of right of the the parent containing block", 2))
            section.Blocks.Add(CreateFloatingParagraph(ENFloatMode.Left))
            section.Blocks.Add(CreateNormalParagraph())
            section.Blocks.Add(CreateNormalParagraph())
            section.Blocks.Add(CreateFloatingParagraph(ENFloatMode.Right))
            section.Blocks.Add(CreateNormalParagraph())
            section.Blocks.Add(CreateNormalParagraph())
            section.Blocks.Add(GetDescriptionBlock("Clear Mode", "Clear mode allows you to position blocks at a space not occupied by other blocks", 2))
            section.Blocks.Add(CreateFloatingParagraph(ENFloatMode.Left))
            section.Blocks.Add(CreateNormalParagraph())
            Dim paragraph As NParagraph = CreateNormalParagraph()
            paragraph.ClearMode = ENClearMode.Left
            section.Blocks.Add(paragraph)
            section.Blocks.Add(GetNoteBlock("The second paragraph has ClearMode set to the left and is not obscured by the floating block.", 2))
        End Sub

#End Region

#Region "Fields"

        Private m_RichText As NRichTextView

#End Region

#Region "Schema"

        Public Shared ReadOnly NBlockLayoutExampleSchema As NSchema

#End Region

#Region "Static Methods"

        Private Shared Function CreateFloatingParagraph(ByVal floatMode As ENFloatMode) As NParagraph
            Dim paragraph As NParagraph = New NParagraph(floatMode.ToString() & " flow paragraph.")
            paragraph.FloatMode = floatMode
            paragraph.PreferredWidth = New NMultiLength(ENMultiLengthUnit.Dip, 100)
            paragraph.PreferredHeight = New NMultiLength(ENMultiLengthUnit.Dip, 100)
            paragraph.BorderThickness = New NMargins(1)
            paragraph.Border = NBorder.CreateFilledBorder(NColor.Black)
            Return paragraph
        End Function

        Private Shared Function CreateNormalParagraph() As NParagraph
            Return New NParagraph(GetRepeatingText("Normal flow paragraph.", 10))
        End Function

        Private Shared Function CreateSampleParagraph1() As NParagraph
            Dim paragraph As NParagraph = New NParagraph("This paragraph has margins, border thickness, and padding of 10dips.")
            paragraph.Margins = New NMargins(10)
            paragraph.BorderThickness = New NMargins(10)
            paragraph.Padding = New NMargins(10)
            paragraph.Border = NBorder.CreateFilledBorder(NColor.Red)
            paragraph.BackgroundFill = New NStockGradientFill(NColor.White, NColor.LightYellow)
            Return paragraph
        End Function

        Private Shared Function GetDescriptionParagraph(ByVal text As String) As NParagraph
            Return New NParagraph(text)
        End Function

        Private Shared Function GetTitleParagraphNoBorder(ByVal text As String, ByVal level As Integer) As NParagraph
            Dim fontSize As Double = 10
            Dim fontStyle = ENFontStyle.Regular

            Select Case level
                Case 1
                    fontSize = 16
                    fontStyle = ENFontStyle.Bold
                Case 2
                    fontSize = 10
                    fontStyle = ENFontStyle.Bold
            End Select

            Dim paragraph As NParagraph = New NParagraph()
            paragraph.HorizontalAlignment = ENAlign.Left
            paragraph.FontSize = fontSize
            paragraph.FontStyle = fontStyle
            Dim textInline As NTextInline = New NTextInline(text)
            textInline.FontStyle = fontStyle
            textInline.FontSize = fontSize
            paragraph.Inlines.Add(textInline)
            Return paragraph
        End Function
        ''' <summary>
        ''' Gets a paragraph with title formatting
        ''' </summary>
        ''' <paramname="text"></param>
        ''' <returns></returns>
        Private Shared Function GetTitleParagraph(ByVal text As String, ByVal level As Integer) As NParagraph
            Dim color = NColor.Black
            Dim paragraph = GetTitleParagraphNoBorder(text, level)
            paragraph.HorizontalAlignment = ENAlign.Left
            paragraph.Border = CreateLeftTagBorder(color)
            paragraph.BorderThickness = defaultBorderThickness
            Return paragraph
        End Function

        Private Shared Function GetNoteBlock(ByVal text As String, ByVal level As Integer) As NGroupBlock
            Dim color = NColor.Red
            Dim paragraph = GetTitleParagraphNoBorder("Note", level)
            Dim groupBlock As NGroupBlock = New NGroupBlock()
            groupBlock.ClearMode = ENClearMode.All
            groupBlock.Blocks.Add(paragraph)
            groupBlock.Blocks.Add(GetDescriptionParagraph(text))
            groupBlock.Border = CreateLeftTagBorder(color)
            groupBlock.BorderThickness = defaultBorderThickness
            Return groupBlock
        End Function

        Private Shared Function GetDescriptionBlock(ByVal title As String, ByVal description As String, ByVal level As Integer) As NGroupBlock
            Dim color = NColor.Black
            Dim paragraph = GetTitleParagraphNoBorder(title, level)
            Dim groupBlock As NGroupBlock = New NGroupBlock()
            groupBlock.ClearMode = ENClearMode.All
            groupBlock.Blocks.Add(paragraph)
            groupBlock.Blocks.Add(GetDescriptionParagraph(description))
            groupBlock.Border = CreateLeftTagBorder(color)
            groupBlock.BorderThickness = defaultBorderThickness
            Return groupBlock
        End Function
        ''' <summary>
        ''' Creates a left tag border with the specified border
        ''' </summary>
        ''' <paramname="color"></param>
        ''' <returns></returns>
        Private Shared Function CreateLeftTagBorder(ByVal color As NColor) As NBorder
            Dim border As NBorder = New NBorder()
            border.LeftSide = New NBorderSide()
            border.LeftSide.Fill = New NColorFill(color)
            Return border
        End Function

        Private Shared Function GetLoremIpsumParagraph() As NParagraph
            Return New NParagraph("Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vestibulum placerat in tortor nec tincidunt. Sed sagittis in sem ac auctor. Donec scelerisque molestie eros, a dictum leo fringilla eu. Vivamus porta urna non ullamcorper commodo. Nulla posuere sodales pellentesque. Donec a erat et tortor viverra euismod non et erat. Donec dictum ante eu mauris porta, eget suscipit mi ultrices. Nunc convallis adipiscing ligula, non pharetra dolor egestas at. Etiam in condimentum sapien. Praesent sagittis pulvinar metus, a posuere mauris aliquam eget.")
        End Function
        ''' <summary>
        ''' Gets the specified text repeated
        ''' </summary>
        ''' <paramname="text"></param>
        ''' <paramname="count"></param>
        ''' <returns></returns>
        Private Shared Function GetRepeatingText(ByVal text As String, ByVal count As Integer) As String
            Dim builder As StringBuilder = New StringBuilder()

            For i = 0 To count - 1

                If builder.Length > 0 Then
                    builder.Append(" ")
                End If

                builder.Append(text)
            Next

            Return builder.ToString()
        End Function

#End Region

#Region "Constants"

        Private Shared ReadOnly defaultBorderThickness As NMargins = New NMargins(5.0, 0.0, 0.0, 0.0)

#End Region
    End Class
End Namespace

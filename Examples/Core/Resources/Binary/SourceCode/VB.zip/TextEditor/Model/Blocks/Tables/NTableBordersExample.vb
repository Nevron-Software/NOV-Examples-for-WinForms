Imports Nevron.Nov.Dom
Imports Nevron.Nov.Text
Imports Nevron.Nov.UI
Imports Nevron.Nov.Graphics

Namespace Nevron.Nov.Examples.Text
    ''' <summary>
    ''' The example demonstrates how to modify the table borders, spacing etc.
    ''' </summary>
    Public Class NTableBordersExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' 
        ''' </summary>
        Public Sub New()
        End Sub
        ''' <summary>
        ''' 
        ''' </summary>
        Shared Sub New()
            NTableBordersExampleSchema = NSchema.Create(GetType(NTableBordersExample), NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            ' Create the rich text
            Dim richTextWithRibbon As NRichTextViewWithRibbon = New NRichTextViewWithRibbon()
            m_RichText = richTextWithRibbon.View
            m_RichText.AcceptsTab = True
            m_RichText.Content.Sections.Clear()

            ' Populate the rich text
            PopulateRichText()
            Return richTextWithRibbon
        End Function

        Protected Overrides Function CreateExampleControls() As NWidget
            Return Nothing
        End Function

        Protected Overrides Function GetExampleDescription() As String
            Return "
<p>
	This example demonstrates how table borders behave when the table allows or not table cells spacing.
</p>
"
        End Function

        Private Sub PopulateRichText()
            Dim section As NSection = New NSection()
            m_RichText.Content.Sections.Add(section)

            If True Then
                section.Blocks.Add(GetDescriptionBlock("Table Borders Example", "This example shows how table borders behave when the table allows or does not table cell spacing.", 1))

                ' first create the table
                Dim table = CreateTable(2, 3)
                table.AllowSpacingBetweenCells = True
                table.TableCellHorizontalSpacing = 3
                table.TableCellVerticalSpacing = 3

                For col = 0 To table.Columns.Count - 1

                    For row = 0 To table.Rows.Count - 1
                        Dim cell = table.Rows(row).Cells(col)

                        Select Case col Mod 3
                            Case 0
                                cell.Border = NBorder.CreateFilledBorder(NColor.Red)
                                cell.Margins = New NMargins(3)
                                cell.Padding = New NMargins(3)
                                cell.BorderThickness = New NMargins(1)
                            Case 1
                                cell.Border = NBorder.CreateFilledBorder(NColor.Green)
                                cell.Margins = New NMargins(5)
                                cell.Padding = New NMargins(5)
                                cell.BorderThickness = New NMargins(3)
                            Case 2
                                cell.Border = NBorder.CreateFilledBorder(NColor.Blue)
                                cell.Margins = New NMargins(7)
                                cell.Padding = New NMargins(7)
                                cell.BorderThickness = New NMargins(2)
                        End Select
                    Next
                Next

                table.Border = NBorder.CreateFilledBorder(NColor.Red)
                table.BorderThickness = New NMargins(2, 2, 2, 2)
                section.Blocks.Add(table)
                section.Blocks.Add(New NParagraph("This is a 2x3 table, with borders in collapsed table border mode:"))

                ' first create the table
                table = CreateTable(2, 3)
                table.AllowSpacingBetweenCells = False

                For col = 0 To table.Columns.Count - 1

                    For row = 0 To table.Rows.Count - 1
                        Dim cell = table.Rows(row).Cells(col)

                        Select Case col Mod 3
                            Case 0
                                cell.Border = NBorder.CreateFilledBorder(NColor.Red)
                                cell.Margins = New NMargins(3)
                                cell.Padding = New NMargins(3)
                                cell.BorderThickness = New NMargins(1)
                            Case 1
                                cell.Border = NBorder.CreateFilledBorder(NColor.Green)
                                cell.Margins = New NMargins(5)
                                cell.Padding = New NMargins(5)
                                cell.BorderThickness = New NMargins(3)
                            Case 2
                                cell.Border = NBorder.CreateFilledBorder(NColor.Blue)
                                cell.Margins = New NMargins(7)
                                cell.Padding = New NMargins(7)
                                cell.BorderThickness = New NMargins(2)
                        End Select
                    Next
                Next

                table.Border = NBorder.CreateFilledBorder(NColor.Red)
                section.Blocks.Add(table)
            End If
        End Sub

#End Region

#Region "Fields"

        Private m_RichText As NRichTextView

#End Region

#Region "Schema"

        Public Shared ReadOnly NTableBordersExampleSchema As NSchema

#End Region

#Region "Static Methods"

        Private Shared Function CreateTable(ByVal rowCount As Integer, ByVal colCount As Integer) As NTable
            ' first create the table
            Dim table As NTable = New NTable(rowCount, colCount)
            table.AllowSpacingBetweenCells = True
            table.TableCellHorizontalSpacing = 3
            table.TableCellVerticalSpacing = 3

            For col = 0 To table.Columns.Count - 1
                ' set table column preferred width
                Dim headerText = String.Empty

                Select Case col
                    Case 0 ' Fixed column
                        table.Columns(col).PreferredWidth = New NMultiLength(ENMultiLengthUnit.Dip, 80)
                        headerText = "Fixed [80dips]"
                    Case 1 ' Auto
                        headerText = "Automatic"
                    Case 2 ' Percentage
                        table.Columns(col).PreferredWidth = New NMultiLength(ENMultiLengthUnit.Percentage, 20)
                        headerText = "Percentage [20%]"
                    Case 3 ' Fixed
                        table.Columns(col).PreferredWidth = New NMultiLength(ENMultiLengthUnit.Dip, 160)
                        headerText = "Fixed [160dips]"
                    Case 4 ' Percentage
                        table.Columns(col).PreferredWidth = New NMultiLength(ENMultiLengthUnit.Percentage, 30)
                        headerText = "Percentage [30%]"
                End Select

                For row = 0 To table.Rows.Count - 1
                    Dim paragraph As NParagraph

                    If row = 0 Then
                        paragraph = New NParagraph(headerText)
                    Else
                        paragraph = New NParagraph("Cell")
                    End If

                    Dim cell = table.Rows(row).Cells(col)
                    cell.Blocks.Clear()
                    cell.Blocks.Add(paragraph)
                Next
            Next

            Return table
        End Function

        Private Shared Function GetDescriptionParagraph(ByVal text As String) As NParagraph
            Return New NParagraph(text)
        End Function

        Private Shared Function GetTitleParagraphNoBorder(ByVal text As String, ByVal level As Integer) As NParagraph
            Dim fontSize As Double = 10
            Dim fontStyle = ENFontStyle.Regular

            Select Case level
                Case 1
                    fontSize = 16
                    fontStyle = ENFontStyle.Bold
                Case 2
                    fontSize = 10
                    fontStyle = ENFontStyle.Bold
            End Select

            Dim paragraph As NParagraph = New NParagraph()
            paragraph.HorizontalAlignment = ENAlign.Left
            paragraph.FontSize = fontSize
            paragraph.FontStyle = fontStyle
            Dim textInline As NTextInline = New NTextInline(text)
            textInline.FontStyle = fontStyle
            textInline.FontSize = fontSize
            paragraph.Inlines.Add(textInline)
            Return paragraph
        End Function

        Private Shared Function GetDescriptionBlock(ByVal title As String, ByVal description As String, ByVal level As Integer) As NGroupBlock
            Dim color = NColor.Black
            Dim paragraph = GetTitleParagraphNoBorder(title, level)
            Dim groupBlock As NGroupBlock = New NGroupBlock()
            groupBlock.ClearMode = ENClearMode.All
            groupBlock.Blocks.Add(paragraph)
            groupBlock.Blocks.Add(GetDescriptionParagraph(description))
            groupBlock.Border = CreateLeftTagBorder(color)
            groupBlock.BorderThickness = defaultBorderThickness
            Return groupBlock
        End Function
        ''' <summary>
        ''' Creates a left tag border with the specified border
        ''' </summary>
        ''' <paramname="color"></param>
        ''' <returns></returns>
        Private Shared Function CreateLeftTagBorder(ByVal color As NColor) As NBorder
            Dim border As NBorder = New NBorder()
            border.LeftSide = New NBorderSide()
            border.LeftSide.Fill = New NColorFill(color)
            Return border
        End Function

#End Region

#Region "Constants"

        Private Shared ReadOnly defaultBorderThickness As NMargins = New NMargins(5.0, 0.0, 0.0, 0.0)

#End Region
    End Class
End Namespace

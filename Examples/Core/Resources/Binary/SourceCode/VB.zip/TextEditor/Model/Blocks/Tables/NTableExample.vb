Imports Nevron.Nov.Dom
Imports Nevron.Nov.Graphics
Imports Nevron.Nov.Text
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.Text
    ''' <summary>
    ''' This example demonstrates how to programmatically create tables.
    ''' </summary>
    Public Class NTableExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' 
        ''' </summary>
        Public Sub New()
        End Sub
        ''' <summary>
        ''' 
        ''' </summary>
        Shared Sub New()
            NTableExampleSchema = NSchema.Create(GetType(NTableExample), NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            ' Create the rich text
            Dim richTextWithRibbon As NRichTextViewWithRibbon = New NRichTextViewWithRibbon()
            m_RichText = richTextWithRibbon.View
            m_RichText.AcceptsTab = True
            m_RichText.Content.Sections.Clear()

            ' Populate the rich text
            PopulateRichText()
            Return richTextWithRibbon
        End Function

        Protected Overrides Function CreateExampleControls() As NWidget
            Return Nothing
        End Function

        Protected Overrides Function GetExampleDescription() As String
            Return "<p>This example demonstrates how to programmatically create tables.</p>"
        End Function

        Private Sub PopulateRichText()
            Dim section As NSection = New NSection()
            m_RichText.Content.Sections.Add(section)
            section.Blocks.Add(GetDescriptionBlock("Table example", "This example shows how to programmatically create and add a table to the text control.", 1))
            Dim p = GetTitleParagraph("Table with cell spacing.", 2)
            section.Blocks.Add(p)
            Dim tableWithCellSpacing As NTable = CreateTable()
            tableWithCellSpacing.AllowSpacingBetweenCells = True
            section.Blocks.Add(tableWithCellSpacing)
            section.Blocks.Add(GetTitleParagraph("Table without cell spacing.", 2))
            Dim tableWithoutCellSpacing As NTable = CreateTable()
            tableWithoutCellSpacing.AllowSpacingBetweenCells = False
            section.Blocks.Add(tableWithoutCellSpacing)
        End Sub

#End Region

#Region "Implementation"

        Private Function CreateTable() As NTable
            Dim table As NTable = New NTable()
            Dim rowCount = 3
            Dim colCount = 3

            ' first create the columns
            For i = 0 To colCount - 1
                table.Columns.Add(New NTableColumn())
            Next

            ' then add rows with cells count matching the number of columns
            For row = 0 To rowCount - 1
                Dim tableRow As NTableRow = New NTableRow()
                table.Rows.Add(tableRow)

                For col = 0 To colCount - 1
                    Dim tableCell As NTableCell = New NTableCell()
                    tableRow.Cells.Add(tableCell)
                    tableCell.Margins = New NMargins(4)
                    tableCell.Border = NBorder.CreateFilledBorder(NColor.Black)
                    tableCell.BorderThickness = New NMargins(1)
                    Dim paragraph As NParagraph = New NParagraph("This is a table cell [" & row.ToString() & ", " & col.ToString() & "]")
                    tableCell.Blocks.Add(paragraph)
                Next
            Next

            Return table
        End Function

#End Region

#Region "Fields"

        Private m_RichText As NRichTextView

#End Region

#Region "Schema"

        Public Shared ReadOnly NTableExampleSchema As NSchema

#End Region


#Region "Static Methods"

        Private Shared Function GetDescriptionParagraph(ByVal text As String) As NParagraph
            Return New NParagraph(text)
        End Function

        Private Shared Function GetTitleParagraphNoBorder(ByVal text As String, ByVal level As Integer) As NParagraph
            Dim fontSize As Double = 10
            Dim fontStyle = ENFontStyle.Regular

            Select Case level
                Case 1
                    fontSize = 16
                    fontStyle = ENFontStyle.Bold
                Case 2
                    fontSize = 10
                    fontStyle = ENFontStyle.Bold
            End Select

            Dim paragraph As NParagraph = New NParagraph()
            paragraph.HorizontalAlignment = ENAlign.Left
            paragraph.FontSize = fontSize
            paragraph.FontStyle = fontStyle
            Dim textInline As NTextInline = New NTextInline(text)
            textInline.FontStyle = fontStyle
            textInline.FontSize = fontSize
            paragraph.Inlines.Add(textInline)
            Return paragraph
        End Function
        ''' <summary>
        ''' Gets a paragraph with title formatting
        ''' </summary>
        ''' <paramname="text"></param>
        ''' <returns></returns>
        Private Shared Function GetTitleParagraph(ByVal text As String, ByVal level As Integer) As NParagraph
            Dim color = NColor.Black
            Dim paragraph = GetTitleParagraphNoBorder(text, level)
            paragraph.HorizontalAlignment = ENAlign.Left
            paragraph.Border = CreateLeftTagBorder(color)
            paragraph.BorderThickness = defaultBorderThickness
            Return paragraph
        End Function

        Private Shared Function GetDescriptionBlock(ByVal title As String, ByVal description As String, ByVal level As Integer) As NGroupBlock
            Dim color = NColor.Black
            Dim paragraph = GetTitleParagraphNoBorder(title, level)
            Dim groupBlock As NGroupBlock = New NGroupBlock()
            groupBlock.ClearMode = ENClearMode.All
            groupBlock.Blocks.Add(paragraph)
            groupBlock.Blocks.Add(GetDescriptionParagraph(description))
            groupBlock.Border = CreateLeftTagBorder(color)
            groupBlock.BorderThickness = defaultBorderThickness
            Return groupBlock
        End Function
        ''' <summary>
        ''' Creates a left tag border with the specified border
        ''' </summary>
        ''' <paramname="color"></param>
        ''' <returns></returns>
        Private Shared Function CreateLeftTagBorder(ByVal color As NColor) As NBorder
            Dim border As NBorder = New NBorder()
            border.LeftSide = New NBorderSide()
            border.LeftSide.Fill = New NColorFill(color)
            Return border
        End Function

#End Region

#Region "Constants"

        Private Shared ReadOnly defaultBorderThickness As NMargins = New NMargins(5.0, 0.0, 0.0, 0.0)

#End Region
    End Class
End Namespace

Imports Nevron.Nov.Dom
Imports Nevron.Nov.Graphics
Imports Nevron.Nov.Text
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.Text
    ''' <summary>
    ''' The example demonstrates how to programmatically create paragraphs with differnt inline formatting
    ''' </summary>
    Public Class NBulletListsExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' 
        ''' </summary>
        Public Sub New()
        End Sub
        ''' <summary>
        ''' 
        ''' </summary>
        Shared Sub New()
            NBulletListsExampleSchema = NSchema.Create(GetType(NBulletListsExample), NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            ' Create the rich text
            Dim richTextWithRibbon As NRichTextViewWithRibbon = New NRichTextViewWithRibbon()
            m_RichText = richTextWithRibbon.View
            m_RichText.AcceptsTab = True
            m_RichText.Content.Sections.Clear()

            ' Populate the rich text
            PopulateRichText()
            Return richTextWithRibbon
        End Function

        Protected Overrides Function CreateExampleControls() As NWidget
            Return Nothing
        End Function

        Protected Overrides Function GetExampleDescription() As String
            Return "
<p>
	This example demonstrates how to set different bullet list templates to bullet lists as well as how to create nested (multilevel) bullet lists.
</p>
"
        End Function

        Private Sub PopulateRichText()
            Dim section As NSection = New NSection()
            m_RichText.Content.Sections.Add(section)
            section.Blocks.Add(GetDescriptionBlock("Bullet Lists", "Bullet lists allow you to apply automatic numbering on paragraphs or groups of blocks.", 1))
            section.Blocks.Add(GetDescriptionBlock("Simple bullet list", "Following is a bullet list with default formatting.", 2))
            CreateSampleBulletList(section, ENBulletListTemplateType.Bullet, 3, "Bullet List Item")

            ' setting bullet list template type
            If True Then
                section.Blocks.Add(GetDescriptionBlock("Bullet Lists with Different Template", "Following are bullet lists with different formatting", 2))
                Dim values As ENBulletListTemplateType() = NEnum.GetValues(Of ENBulletListTemplateType)()
                Dim names As String() = NEnum.GetNames(Of ENBulletListTemplateType)()

                For i = 0 To values.Length - 1 - 1
                    CreateSampleBulletList(section, values(i), 3, names(i) & " bullet list item ")
                Next
            End If

            ' nested bullet lists
            If True Then
                section.Blocks.Add(GetDescriptionBlock("Bullet List Levels", "Following is an example of bullet list levels", 2))
                Dim bulletList As NBulletList = New NBulletList(ENBulletListTemplateType.Decimal)
                m_RichText.Content.BulletLists.Add(bulletList)

                For i = 0 To 3 - 1
                    Dim par1 As NParagraph = New NParagraph("Bullet List Item" & i.ToString())
                    par1.SetBulletList(bulletList, 0)
                    section.Blocks.Add(par1)

                    For j = 0 To 2 - 1
                        Dim par2 As NParagraph = New NParagraph("Nested Bullet List Item" & i.ToString())
                        par2.SetBulletList(bulletList, 1)
                        par2.MarginLeft = 20
                        section.Blocks.Add(par2)
                    Next
                Next
            End If
        End Sub

#End Region

#Region "Implementation"

        Private Sub CreateSampleBulletList(ByVal section As NSection, ByVal bulletListType As ENBulletListTemplateType, ByVal items As Integer, ByVal itemText As String)
            Dim bulletList As NBulletList = New NBulletList(bulletListType)
            m_RichText.Content.BulletLists.Add(bulletList)

            For i = 0 To items - 1
                Dim par As NParagraph = New NParagraph(itemText & i.ToString())
                par.SetBulletList(bulletList, 0)
                section.Blocks.Add(par)
            Next
        End Sub

#End Region

#Region "Fields"

        Private m_RichText As NRichTextView

#End Region

#Region "Schema"

        Public Shared ReadOnly NBulletListsExampleSchema As NSchema

#End Region

#Region "Static Methods"

        Private Shared Function GetDescriptionParagraph(ByVal text As String) As NParagraph
            Return New NParagraph(text)
        End Function

        Private Shared Function GetTitleParagraphNoBorder(ByVal text As String, ByVal level As Integer) As NParagraph
            Dim fontSize As Double = 10
            Dim fontStyle = ENFontStyle.Regular

            Select Case level
                Case 1
                    fontSize = 16
                    fontStyle = ENFontStyle.Bold
                Case 2
                    fontSize = 10
                    fontStyle = ENFontStyle.Bold
            End Select

            Dim paragraph As NParagraph = New NParagraph()
            paragraph.HorizontalAlignment = ENAlign.Left
            paragraph.FontSize = fontSize
            paragraph.FontStyle = fontStyle
            Dim textInline As NTextInline = New NTextInline(text)
            textInline.FontStyle = fontStyle
            textInline.FontSize = fontSize
            paragraph.Inlines.Add(textInline)
            Return paragraph
        End Function

        Private Shared Function GetDescriptionBlock(ByVal title As String, ByVal description As String, ByVal level As Integer) As NGroupBlock
            Dim color = NColor.Black
            Dim paragraph = GetTitleParagraphNoBorder(title, level)
            Dim groupBlock As NGroupBlock = New NGroupBlock()
            groupBlock.ClearMode = ENClearMode.All
            groupBlock.Blocks.Add(paragraph)
            groupBlock.Blocks.Add(GetDescriptionParagraph(description))
            groupBlock.Border = CreateLeftTagBorder(color)
            groupBlock.BorderThickness = defaultBorderThickness
            Return groupBlock
        End Function
        ''' <summary>
        ''' Creates a left tag border with the specified border
        ''' </summary>
        ''' <paramname="color"></param>
        ''' <returns></returns>
        Private Shared Function CreateLeftTagBorder(ByVal color As NColor) As NBorder
            Dim border As NBorder = New NBorder()
            border.LeftSide = New NBorderSide()
            border.LeftSide.Fill = New NColorFill(color)
            Return border
        End Function

#End Region

#Region "Constants"

        Private Shared ReadOnly defaultBorderThickness As NMargins = New NMargins(5.0, 0.0, 0.0, 0.0)

#End Region
    End Class
End Namespace

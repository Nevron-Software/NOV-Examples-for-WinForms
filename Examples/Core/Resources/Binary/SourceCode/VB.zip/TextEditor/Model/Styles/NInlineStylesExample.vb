Imports Nevron.Nov.Dom
Imports Nevron.Nov.Graphics
Imports Nevron.Nov.Text
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.Text
    Public Class NInlineStylesExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' Default constructor.
        ''' </summary>
        Public Sub New()
        End Sub

        ''' <summary>
        ''' Static constructor.
        ''' </summary>
        Shared Sub New()
            NInlineStylesExampleSchema = NSchema.Create(GetType(NInlineStylesExample), NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            ' Create the rich text
            Dim richTextWithRibbon As NRichTextViewWithRibbon = New NRichTextViewWithRibbon()
            m_RichText = richTextWithRibbon.View
            m_RichText.AcceptsTab = True
            m_RichText.Content.Sections.Clear()

            ' Populate the rich text
            PopulateRichText()
            Return richTextWithRibbon
        End Function

        Protected Overrides Function CreateExampleControls() As NWidget
            Return Nothing
        End Function

        Protected Overrides Function GetExampleDescription() As String
            Return "<p>This example demonstrates how to create and apply inline styles.</p>"
        End Function

        Private Sub PopulateRichText()
            Dim documentBlock = m_RichText.Content
            Dim section As NSection = New NSection()
            documentBlock.Sections.Add(section)
            Dim paragraph As NParagraph = New NParagraph()
            section.Blocks.Add(paragraph)

            ' Create the first inline
            Dim inline1 As NTextInline = New NTextInline("This is the first inline. ")
            paragraph.Inlines.Add(inline1)

            ' Create and apply an inline style
            Dim style1 As NInlineStyle = New NInlineStyle("MyRedStyle")
            style1.Rule = New NInlineRule(NColor.Red)
            style1.Rule.FontStyle = ENFontStyle.Bold
            style1.Apply(inline1)

            ' Create the second inline
            Dim inline2 As NTextInline = New NTextInline("This is the second inline.")
            paragraph.Inlines.Add(inline2)

            ' Create and apply an inline style
            Dim style2 As NInlineStyle = New NInlineStyle("MyBlueStyle")
            style2.Rule = New NInlineRule(NColor.Blue)
            style2.Rule.FontStyle = ENFontStyle.Italic
            style2.Apply(inline2)
        End Sub

#End Region

#Region "Fields"

        Private m_RichText As NRichTextView

#End Region

#Region "Schema"

        ''' <summary>
        ''' Schema associated with NInlineStylesExample.
        ''' </summary>
        Public Shared ReadOnly NInlineStylesExampleSchema As NSchema

#End Region
    End Class
End Namespace

Imports Nevron.Nov.Dom
Imports Nevron.Nov.Text
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.Text
    Public Class NTableOfContentsExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' Default constructor.
        ''' </summary>
        Public Sub New()
        End Sub

        ''' <summary>
        ''' Static constructor.
        ''' </summary>
        Shared Sub New()
            NTableOfContentsExampleSchema = NSchema.Create(GetType(NTableOfContentsExample), NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            ' Create the rich text
            Dim richTextWithRibbon As NRichTextViewWithRibbon = New NRichTextViewWithRibbon()
            m_RichText = richTextWithRibbon.View
            m_RichText.AcceptsTab = True
            m_RichText.Content.Sections.Clear()

            ' Populate the rich text
            PopulateRichText()
            Return richTextWithRibbon
        End Function

        Protected Overrides Function CreateExampleControls() As NWidget
            Return Nothing
        End Function

        Protected Overrides Function GetExampleDescription() As String
            Return "
<p>This example demonstrates how to programmatically create and add a table of contents block to a document.</p>
"
        End Function

        Private Sub PopulateRichText()
            ' Get references to the heading styles
            Dim documentBlock = m_RichText.Content
            Dim heading1Style = documentBlock.Styles.FindStyleByTypeAndId(ENRichTextStyleType.Paragraph, "Heading1")
            Dim heading2Style = documentBlock.Styles.FindStyleByTypeAndId(ENRichTextStyleType.Paragraph, "Heading2")
            Dim section As NSection = New NSection()
            m_RichText.Content.Sections.Add(section)

            ' Add a table of contents block
            Dim tableOfContents As NTableOfContentsBlock = New NTableOfContentsBlock()
            section.Blocks.Add(tableOfContents)

            ' Create chapter 1
            Dim paragraph As NParagraph = New NParagraph("Chapter 1")
            section.Blocks.Add(paragraph)
            heading1Style.Apply(paragraph)
            paragraph = New NParagraph("Topic 1.1")
            section.Blocks.Add(paragraph)
            heading2Style.Apply(paragraph)
            AddParagraphs(section, "This is a sample paragraph from the first topic of chapter one.", 20)
            paragraph = New NParagraph("Topic 1.2")
            section.Blocks.Add(paragraph)
            heading2Style.Apply(paragraph)
            AddParagraphs(section, "This is a sample paragraph from the second topic of chapter one.", 20)

            ' Create chapter 2
            paragraph = New NParagraph("Chapter 2")
            section.Blocks.Add(paragraph)
            heading1Style.Apply(paragraph)
            paragraph = New NParagraph("Topic 2.1")
            section.Blocks.Add(paragraph)
            heading2Style.Apply(paragraph)
            AddParagraphs(section, "This is a sample paragraph from the first topic of chapter two.", 20)
            paragraph = New NParagraph("Topic 2.2")
            section.Blocks.Add(paragraph)
            heading2Style.Apply(paragraph)
            AddParagraphs(section, "This is a sample paragraph from the second topic of chapter two.", 20)

            ' Update the table of contents
            m_RichText.Document.Evaluate()
            tableOfContents.Update()
        End Sub

#End Region

#Region "Implementation"

        Private Sub AddParagraphs(ByVal section As NSection, ByVal text As String, ByVal count As Integer)
            ' Duplicate the given text 5 times
            text = String.Join(" ", New String() {text, text, text, text, text})

            ' Create the given number of paragraphs with the text
            For i = 0 To count - 1
                section.Blocks.Add(New NParagraph(text))
            Next
        End Sub

#End Region

#Region "Fields"

        Private m_RichText As NRichTextView

#End Region

#Region "Schema"

        ''' <summary>
        ''' Schema associated with NTableOfContentsExample.
        ''' </summary>
        Public Shared ReadOnly NTableOfContentsExampleSchema As NSchema

#End Region
    End Class
End Namespace

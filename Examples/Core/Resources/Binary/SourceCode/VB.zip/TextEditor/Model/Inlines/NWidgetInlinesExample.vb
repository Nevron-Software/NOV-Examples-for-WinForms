Imports Nevron.Nov.Dom
Imports Nevron.Nov.Graphics
Imports Nevron.Nov.Text
Imports Nevron.Nov.UI
Imports Nevron.Nov.DataStructures

Namespace Nevron.Nov.Examples.Text
    ''' <summary>
    ''' The example demonstrates how to programmatically create inline elements with different formatting
    ''' </summary>
    Public Class NWidgetInlinesExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' 
        ''' </summary>
        Public Sub New()
        End Sub
        ''' <summary>
        ''' 
        ''' </summary>
        Shared Sub New()
            NWidgetInlinesExampleSchema = NSchema.Create(GetType(NWidgetInlinesExample), NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            ' Create the rich text
            Dim richTextWithRibbon As NRichTextViewWithRibbon = New NRichTextViewWithRibbon()
            m_RichText = richTextWithRibbon.View
            m_RichText.AcceptsTab = True
            m_RichText.Content.Sections.Clear()

            ' Populate the rich text
            PopulateRichText()
            Return richTextWithRibbon
        End Function

        Protected Overrides Function CreateExampleControls() As NWidget
            Return Nothing
        End Function

        Protected Overrides Function GetExampleDescription() As String
            Return "
<p>This example demonstrates how to use widgets in order to create ""HTML like"" interfaces. The example also demonstrates how to use style sheets.</p>
<p>Press the ""Show Prev Book"" and ""Show Next Buttons"" buttons to browse through the available books.</p>
<p>Press the ""Add to Cart"" button to add the currently selected book to the shopping cart.</p>
<p>Press the ""Delete"" button to remove a book from the shopping cart.</p>
<p>Use the combo box to select the quantity of books to purchase.</p>
"
        End Function

        Private Sub PopulateRichText()
            m_Books = New NBookInfoList()
            m_CurrentBookIndex = 0
            Dim section As NSection = New NSection()
            m_RichText.Content.Sections.Add(section)
            m_RichText.Document.StyleSheets.Add(CreateShoppingCartStyleSheet())

            If True Then
                Dim navigationTable As NTable = New NTable(1, 2)
                Dim cell0 = navigationTable.Rows(0).Cells(0)
                Dim showPrevBookButton As NButton = New NButton("Show Prev Book")
                AddHandler showPrevBookButton.Click, New [Function](Of NEventArgs)(AddressOf OnShowPrevBookButtonClick)
                cell0.Blocks.Clear()
                cell0.Blocks.Add(CreateWidgetParagraph(showPrevBookButton))
                Dim cell1 = navigationTable.Rows(0).Cells(1)
                Dim showNextBookButton As NButton = New NButton("Show Next Book")
                AddHandler showNextBookButton.Click, New [Function](Of NEventArgs)(AddressOf OnShowNextBookButtonClick)
                cell1.Blocks.Clear()
                cell1.Blocks.Add(CreateWidgetParagraph(showNextBookButton))
                section.Blocks.Add(navigationTable)
            End If

            m_BookInfoPlaceHolder = New NGroupBlock()
            section.Blocks.Add(m_BookInfoPlaceHolder)

            If True Then
                m_BookInfoPlaceHolder.Blocks.Add(CreateBookContent(m_Books(0)))
            End If

            If True Then
                m_ShoppingCartPlaceHolder = New NGroupBlock()
                AddEmptyShoppingCartText()
                section.Blocks.Add(m_ShoppingCartPlaceHolder)
            End If
        End Sub

#End Region

#Region "Implementation"

        ''' <summary>
        ''' 
        ''' </summary>
        Private Sub AddEmptyShoppingCartText()
            m_ShoppingCartPlaceHolder.Blocks.Clear()
            m_ShoppingCartPlaceHolder.Blocks.Add(New NParagraph("Shopping Cart Is Empty"))
        End Sub
        ''' <summary>
        ''' Creates a style sheet for the shopping cart table
        ''' </summary>
        ''' <returns></returns>
        Private Function CreateShoppingCartStyleSheet() As NStyleSheet
            Dim styleSheet As NStyleSheet = New NStyleSheet()
            Dim rule As NRule = New NRule()

            For i = 0 To 3 - 1
                Dim sb As NSelectorBuilder = rule.GetSelectorBuilder()
                sb.Start()
                sb.Type(NTableCell.NTableCellSchema)

                ' in case of the first or last row selector -> must not be last cell
                If i = 0 OrElse i = 2 Then
                    sb.StartInvertedConditions()
                    sb.LastChild()
                    sb.EndInvertedConditions()
                End If

                ' descendant of table row
                sb.DescendantOf()
                sb.Type(NTableRow.NTableRowSchema)

                Select Case i
                    Case 0
                        ' descendant of first row
                        sb.FirstChild()
                    Case 1
                        ' middle cells
                        sb.StartInvertedConditions()
                        sb.FirstChild()
                        sb.LastChild()
                        sb.EndInvertedConditions()
                    Case 2
                        ' descendant of last row
                        sb.LastChild()
                End Select

                ' descendant of table
                sb.DescendantOf()
                sb.Type(NTable.NTableSchema)
                sb.ValueEquals(NNode.TagProperty, "ShoppingCart")
                sb.End()
            Next

            rule.Declarations.Add(New NValueDeclaration(Of NMargins)(NTextElement.BorderThicknessProperty, New NMargins(1)))
            rule.Declarations.Add(New NValueDeclaration(Of NBorder)(NTextElement.BorderProperty, NBorder.CreateFilledBorder(NColor.Black)))
            styleSheet.Add(rule)
            Return styleSheet
        End Function
        ''' <summary>
        ''' Creates a table based on the book info
        ''' </summary>
        ''' <paramname="bookInfo"></param>
        ''' <returns></returns>
        Private Function CreateBookContent(ByVal bookInfo As NBookInfo) As NBlock
            Dim table As NTable = New NTable(4, 2)

            ' Create the image
            Dim imageTableCell = table.Rows(0).Cells(0)
            imageTableCell.RowSpan = Integer.MaxValue
            imageTableCell.Blocks.Clear()
            imageTableCell.Blocks.Add(CreateImageParagraph(bookInfo.Image))
            Dim titleTableCell = table.Rows(0).Cells(1)
            titleTableCell.Blocks.Clear()
            titleTableCell.Blocks.Add(CreateTitleParagraph(bookInfo.Name))
            Dim descriptionTableCell = table.Rows(1).Cells(1)
            descriptionTableCell.Blocks.Clear()
            descriptionTableCell.Blocks.Add(CreateDescriptionParagraph(bookInfo.Description))
            Dim authorTableCell = table.Rows(2).Cells(1)
            authorTableCell.Blocks.Clear()
            authorTableCell.Blocks.Add(CreateAuthorParagraph(bookInfo.Author))
            Dim addToCartTableCell = table.Rows(3).Cells(1)
            addToCartTableCell.RowSpan = Integer.MaxValue
            addToCartTableCell.Blocks.Clear()
            Dim addToCartButton As NButton = New NButton("Add To Cart")
            AddHandler addToCartButton.Click, New [Function](Of NEventArgs)(AddressOf OnAddTableRow)
            addToCartTableCell.VerticalAlignment = ENVAlign.Bottom
            addToCartTableCell.Blocks.Add(CreateWidgetParagraph(addToCartButton))
            Return table
        End Function
        ''' <summary>
        ''' Loads the current book info in the book place holder group
        ''' </summary>
        Private Sub LoadBookInfo()
            m_BookInfoPlaceHolder.Blocks.Clear()
            m_BookInfoPlaceHolder.Blocks.Add(CreateBookContent(m_Books(m_CurrentBookIndex)))
        End Sub
        ''' <summary>
        ''' Creates the author paragraph
        ''' </summary>
        ''' <paramname="author"></param>
        ''' <returns></returns>
        Private Function CreateAuthorParagraph(ByVal author As String) As NParagraph
            Return New NParagraph("Author: " & author)
        End Function
        ''' <summary>
        ''' Creates teh description paragraph
        ''' </summary>
        ''' <paramname="title"></param>
        ''' <returns></returns>
        Private Function CreateDescriptionParagraph(ByVal title As String) As NParagraph
            Dim paragraph As NParagraph = New NParagraph(title)
            paragraph.BackgroundFill = New NColorFill(NColor.WhiteSmoke)
            Return paragraph
        End Function
        ''' <summary>
        ''' Creates the title paragraph
        ''' </summary>
        ''' <paramname="title"></param>
        ''' <returns></returns>
        Private Function CreateTitleParagraph(ByVal title As String) As NParagraph
            Dim paragraph As NParagraph = New NParagraph(title)
            paragraph.FontSize = 18
            paragraph.Fill = New NColorFill(NColor.RoyalBlue)
            Return paragraph
        End Function
        ''' <summary>
        ''' Creates the book image paragraph
        ''' </summary>
        ''' <paramname="image"></param>
        ''' <returns></returns>
        Private Function CreateImageParagraph(ByVal image As NImage) As NParagraph
            Dim paragraph As NParagraph = New NParagraph()
            Dim inline As NImageInline = New NImageInline()
            inline.Image = CType(image.DeepClone(), NImage)
            inline.PreferredWidth = New NMultiLength(ENMultiLengthUnit.Dip, 200)
            inline.PreferredHeight = New NMultiLength(ENMultiLengthUnit.Dip, 280)
            paragraph.Inlines.Add(inline)
            Return paragraph
        End Function
        ''' <summary>
        ''' Creates a paragraph that contains a widget
        ''' </summary>
        ''' <paramname="widget"></param>
        ''' <returns></returns>
        Private Function CreateWidgetParagraph(ByVal widget As NWidget) As NParagraph
            Dim paragraph As NParagraph = New NParagraph()
            Dim inline As NWidgetInline = New NWidgetInline()
            inline.Content = widget
            paragraph.Inlines.Add(inline)
            Return paragraph
        End Function
        ''' <summary>
        ''' Creates a combo that shows the 
        ''' </summary>
        ''' <returns></returns>
        Private Function CreateQuantityCombo() As NComboBox
            Dim combo As NComboBox = New NComboBox()

            For i = 0 To 9 - 1
                combo.Items.Add(New NComboBoxItem((i + 1).ToString()))
            Next

            combo.SelectedIndex = 0
            AddHandler combo.SelectedIndexChanged, New [Function](Of NValueChangeEventArgs)(AddressOf OnQuantityComboSelectedIndexChanged)
            Return combo
        End Function
        ''' <summary>
        ''' Adds a book row to the shopping cart
        ''' </summary>
        Private Sub AddBookRow()
            Dim bookInfo = m_Books(m_CurrentBookIndex)
            Dim bookRow As NTableRow = New NTableRow()
            bookRow.Tag = bookInfo
            Dim nameCell As NTableCell = New NTableCell()
            nameCell.Blocks.Add(New NParagraph(bookInfo.Name))
            bookRow.Cells.Add(nameCell)
            Dim quantityCell As NTableCell = New NTableCell()
            quantityCell.Blocks.Add(CreateWidgetParagraph(CreateQuantityCombo()))
            bookRow.Cells.Add(quantityCell)
            Dim priceCell As NTableCell = New NTableCell()
            priceCell.Blocks.Add(New NParagraph(bookInfo.Price.ToString()))
            bookRow.Cells.Add(priceCell)
            Dim totalCell As NTableCell = New NTableCell()
            totalCell.Blocks.Add(New NParagraph())
            bookRow.Cells.Add(totalCell)
            Dim deleteCell As NTableCell = New NTableCell()
            Dim deleteRowButton As NButton = New NButton("Delete")
            AddHandler deleteRowButton.Click, New [Function](Of NEventArgs)(AddressOf OnDeleteRowButtonClick)
            deleteCell.Blocks.Add(CreateWidgetParagraph(deleteRowButton))
            bookRow.Cells.Add(deleteCell)
            m_CartTable.Rows.Insert(m_CartTable.Rows.Count - 1, bookRow)
        End Sub
        ''' <summary>
        ''' Adds a total row to the shopping cart
        ''' </summary>
        Private Sub AddTotalRow()
            Dim totalRow As NTableRow = m_CartTable.Rows.CreateNewRow()
            Dim totalCell = totalRow.Cells(0)
            totalCell.Blocks.Clear()
            totalCell.ColSpan = 3
            totalCell.Blocks.Add(New NParagraph("Grand Total:"))
            m_CartTable.Rows.Add(totalRow)
        End Sub
        ''' <summary>
        ''' Updates the total values in the shopping cart
        ''' </summary>
        Private Sub UpdateTotals()
            If m_CartTable Is Nothing OrElse m_CartTable.Columns.Count <> 5 Then Return
            Dim grandTotal As Double = 0

            ' sum all book info price * quantity
            For i = 0 To m_CartTable.Rows.Count - 1
                Dim row = m_CartTable.Rows(i)
                Dim bookInfo As NBookInfo = TryCast(row.Tag, NBookInfo)

                If bookInfo IsNot Nothing Then
                    Dim blocks = row.Cells(1).Blocks
                    Dim combo As NComboBox = CType(blocks.GetFirstDescendant(New NInstanceOfSchemaFilter(NComboBox.NComboBoxSchema)), NComboBox)

                    If combo IsNot Nothing Then
                        Dim total = (combo.SelectedIndex + 1) * bookInfo.Price
                        row.Cells(3).Blocks.Clear()
                        row.Cells(3).Blocks.Add(New NParagraph(total.ToString()))
                        grandTotal += total
                    End If
                End If
            Next

            Dim grandTotalCell = m_CartTable.Rows(m_CartTable.Rows.Count - 1).Cells(3)
            grandTotalCell.Blocks.Clear()
            grandTotalCell.Blocks.Add(New NParagraph(grandTotal.ToString()))
        End Sub

#End Region

#Region "Event Handlers"

        ''' <summary>
        ''' Called when a new row must be added to the shopping cart
        ''' </summary>
        ''' <paramname="arg"></param>
        Private Sub OnAddTableRow(ByVal arg As NEventArgs)
            If m_CartTable Is Nothing Then
                m_CartTable = New NTable(1, 5)
                m_CartTable.Tag = "ShoppingCart"
                m_CartTable.AllowSpacingBetweenCells = False
                m_ShoppingCartPlaceHolder.Blocks.Clear()
                m_ShoppingCartPlaceHolder.Blocks.Add(m_CartTable)
                Dim nameCell = m_CartTable.Rows(0).Cells(0)
                nameCell.Blocks.Clear()
                nameCell.Blocks.Add(New NParagraph("Name"))
                Dim quantity = m_CartTable.Rows(0).Cells(1)
                quantity.Blocks.Clear()
                quantity.Blocks.Add(New NParagraph("Quantity"))
                Dim priceCell = m_CartTable.Rows(0).Cells(2)
                priceCell.Blocks.Clear()
                priceCell.Blocks.Add(New NParagraph("Price"))
                Dim totalCell = m_CartTable.Rows(0).Cells(3)
                totalCell.Blocks.Clear()
                totalCell.Blocks.Add(New NParagraph("Total"))
                Dim deleteCell = m_CartTable.Rows(0).Cells(4)
                deleteCell.Blocks.Clear()
                AddTotalRow()
            End If

            AddBookRow()
            UpdateTotals()
        End Sub
        ''' <summary>
        ''' Called when a row must be deleted from the shopping cart
        ''' </summary>
        ''' <paramname="arg"></param>
        Private Sub OnDeleteRowButtonClick(ByVal arg As NEventArgs)
            Dim tableRow = CType(arg.TargetNode.GetFirstAncestor(NTableRow.NTableRowSchema), NTableRow)
            m_CartTable.Rows.Remove(tableRow)

            If m_CartTable.Rows.Count = 2 Then
                m_CartTable.Rows.RemoveAt(m_CartTable.Rows.Count - 1)
                m_CartTable = Nothing
                AddEmptyShoppingCartText()
            End If

            UpdateTotals()
        End Sub
        ''' <summary>
        ''' Called when the quantity combo for a row has changed
        ''' </summary>
        ''' <paramname="arg"></param>
        Private Sub OnQuantityComboSelectedIndexChanged(ByVal arg As NEventArgs)
            UpdateTotals()
        End Sub
        ''' <summary>
        ''' Called to load the next book in the list
        ''' </summary>
        ''' <paramname="arg"></param>
        Private Sub OnShowNextBookButtonClick(ByVal arg As NEventArgs)
            If m_CurrentBookIndex >= m_Books.Count - 1 Then
                Return
            End If

            m_CurrentBookIndex += 1
            LoadBookInfo()
        End Sub
        ''' <summary>
        ''' Called to load the prev book in the list
        ''' </summary>
        ''' <paramname="arg"></param>
        Private Sub OnShowPrevBookButtonClick(ByVal arg As NEventArgs)
            If m_CurrentBookIndex <= 0 Then
                Return
            End If

            m_CurrentBookIndex -= 1
            LoadBookInfo()
        End Sub

#End Region

#Region "Fields"

        Private m_RichText As NRichTextView
        Private m_Books As NBookInfoList
        Private m_BookInfoPlaceHolder As NGroupBlock
        Private m_ShoppingCartPlaceHolder As NGroupBlock
        Private m_CartTable As NTable
        Private m_CurrentBookIndex As Integer

#End Region

#Region "Schema"

        Public Shared ReadOnly NWidgetInlinesExampleSchema As NSchema

#End Region

#Region "Nested Types"

        Private Class NBookInfo
            Implements INDeeplyCloneable
#Region "Constructors"

            ''' <summary>
            ''' Initializer contructor
            ''' </summary>
            ''' <paramname="name"></param>
            ''' <paramname="author"></param>
            ''' <paramname="description"></param>
            ''' <paramname="image"></param>
            ''' <paramname="price"></param>
            Public Sub New(ByVal name As String, ByVal author As String, ByVal description As String, ByVal image As NImage, ByVal price As Double)
                Me.Name = name
                Me.Author = author
                Me.Description = description
                Me.Image = image
                Me.Price = price
            End Sub
            ''' <summary>
            ''' Copy constructor
            ''' </summary>
            ''' <paramname="bookInfo"></param>
            Public Sub New(ByVal bookInfo As NBookInfo)
                Name = bookInfo.Name
                Author = bookInfo.Author
                Description = bookInfo.Description
                Image = CType(bookInfo.Image.DeepClone(), NImage)
                Price = bookInfo.Price
            End Sub

#End Region

#Region "Fields"

            Public ReadOnly Name As String
            Public ReadOnly Author As String
            Public ReadOnly Description As String
            Public ReadOnly Image As NImage
            Public ReadOnly Price As Double

#End Region

#Region "INDeeplyCloneable"

            Public Function DeepClone() As Object Implements INDeeplyCloneable.DeepClone
                Return New NBookInfo(Me)
            End Function

#End Region
        End Class

        Private Class NBookInfoList
            Inherits NList(Of NBookInfo)

            Public Sub New()
                MyBase.Add(New NBookInfo("The Name Of The Wind", "Patrick Rothfuss", "This is the riveting first-person narrative of Kvothe, a young man who grows to be one of the most notorious magicians his world has ever seen. From his childhood in a troupe of traveling players, to years spent as a near-feral orphan in a crime-riddled city, to his daringly brazen yet successful bid to enter a legendary school of magic, The Name of the Wind is a masterpiece that transports readers into the body and mind of a wizard.", NResources.Image_Books_NameOfTheWind_jpg, 12.90))
                MyBase.Add(New NBookInfo("Lord of Ohe Rings", "J.R.R. Tolkien", "In ancient times the Rings of Power were crafted by the Elven-smiths, and Sauron, the Dark Lord, forged the One Ring, filling it with his own power so that he could rule all others. But the One Ring was taken from him, and though he sought it throughout Middle-earth, it remained lost to him. After many ages it fell by chance into the hands of the hobbit Bilbo Baggins.", NResources.Image_Books_LordOfTheRings_jpg, 13.99))
                MyBase.Add(New NBookInfo("A Game Of Thrones", "George R.R. Martin", "Long ago, in a time forgotten, a preternatural event threw the seasons out of balance. In a land where summers can last decades and winters a lifetime, trouble is brewing. The cold is returning, and in the frozen wastes to the north of Winterfell, sinister and supernatural forces are massing beyond the kingdom’s protective Wall. At the center of the conflict lie the Starks of Winterfell, a family as harsh and unyielding as the land they were born to.", NResources.Image_Books_AGameOfThrones_jpg, 12.79))
                MyBase.Add(New NBookInfo("The Way Of Kings", "Brandon Sanderson", "Roshar is a world of stone and storms. Uncanny tempests of incredible power sweep across the rocky terrain so frequently that they have shaped ecology and civilization alike. Animals hide in shells, trees pull in branches, and grass retracts into the soilless ground. Cities are built only where the topography offers shelter.", NResources.Image_Books_TheWayOfKings_jpg, 7.38))
                MyBase.Add(New NBookInfo("Mistborn", "Brandon Sanderson", "For a thousand years the ash fell and no flowers bloomed. For a thousand years the Skaa slaved in misery and lived in fear. For a thousand years the Lord Ruler, the 'Sliver of Infinity' reigned with absolute power and ultimate terror, divinely invincible. Then, when hope was so long lost that not even its memory remained, a terribly scarred, heart-broken half-Skaa rediscovered it in the depths of the Lord Ruler’s most hellish prison. Kelsier 'snapped' and found in himself the powers of a Mistborn. A brilliant thief and natural leader, he turned his talents to the ultimate caper, with the Lord Ruler himself as the mark. ", NResources.Image_Books_Mistborn_jpg, 6.38))
            End Sub
        End Class

#End Region
    End Class
End Namespace

Imports Nevron.Nov.Dom
Imports Nevron.Nov.Graphics
Imports Nevron.Nov.Text
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.Text
    ''' <summary>
    ''' The example demonstrates how to programmatically create paragraphs with differnt inline formatting
    ''' </summary>
    Public Class NBlockSizeExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' 
        ''' </summary>
        Public Sub New()
        End Sub
        ''' <summary>
        ''' 
        ''' </summary>
        Shared Sub New()
            NBlockSizeExampleSchema = NSchema.Create(GetType(NBlockSizeExample), NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            ' Create the rich text
            Dim richTextWithRibbon As NRichTextViewWithRibbon = New NRichTextViewWithRibbon()
            m_RichText = richTextWithRibbon.View
            m_RichText.AcceptsTab = True
            m_RichText.Content.Sections.Clear()

            ' Populate the rich text
            PopulateRichText()
            Return richTextWithRibbon
        End Function

        Protected Overrides Function CreateExampleControls() As NWidget
            Return Nothing
        End Function

        Protected Overrides Function GetExampleDescription() As String
            Return "
<p>
	This example demonstrates how to control the size of text blocks using the preferred, minimum and maximum width and height properties of each block element.
</p>
"
        End Function

        Private Sub PopulateRichText()
            Dim section As NSection = New NSection()
            m_RichText.Content.Sections.Add(section)
            section.Blocks.Add(GetDescriptionBlock("Block Size", "Every block in the document can have a specified Preferred, Minimum and Maximum size.", 1))
            section.Blocks.Add(GetDescriptionBlock("Preferred Width and Height", "The following paragraph has specified Preferred Width and Height.", 2))
            Dim paragraph1 As NParagraph = New NParagraph("Paragraph with Preferred Width 50% and Preferred Height of 200dips.")
            paragraph1.BackgroundFill = New NColorFill(NColor.LightGray)
            paragraph1.PreferredWidth = New NMultiLength(ENMultiLengthUnit.Percentage, 50)
            paragraph1.PreferredHeight = New NMultiLength(ENMultiLengthUnit.Dip, 200)
            section.Blocks.Add(paragraph1)
            section.Blocks.Add(GetDescriptionBlock("Minimum and Maximum Width and Height", "The following paragraph has specified Minimum and Maximum Width.", 2))
            Dim paragraph2 As NParagraph = New NParagraph("Paragraph with Preferred Width 50% and Preferred Height of 200dips and Minimum Width of 200 dips and Maximum Width 300 dips.")
            paragraph2.BackgroundFill = New NColorFill(NColor.LightGray)
            paragraph2.PreferredWidth = New NMultiLength(ENMultiLengthUnit.Percentage, 50)
            paragraph2.PreferredHeight = New NMultiLength(ENMultiLengthUnit.Dip, 200)
            paragraph2.MinWidth = New NMultiLength(ENMultiLengthUnit.Dip, 200)
            paragraph2.MaxWidth = New NMultiLength(ENMultiLengthUnit.Dip, 300)
            paragraph2.WrapDesiredWidth = False
            paragraph2.WrapMinWidth = False
            section.Blocks.Add(paragraph2)
            section.Blocks.Add(GetDescriptionBlock("Desired Width Wrapping", "The following paragraph has disabled desired width wrapping, resulting in a paragraph that does not introduce any hard line breaks.", 2))
            Dim paragraph3 As NParagraph = New NParagraph("Paragraph with WrapDesiredWidth set to false. Note that the paragraph will not introduce any hard breaks. The content of this paragraph is intentionally made long to illustrate this feature.")
            paragraph3.BackgroundFill = New NColorFill(NColor.LightGray)
            paragraph3.WrapDesiredWidth = False
            paragraph3.WrapMinWidth = False
            section.Blocks.Add(paragraph3)
        End Sub

#End Region

#Region "Fields"

        Private m_RichText As NRichTextView

#End Region

#Region "Schema"

        Public Shared ReadOnly NBlockSizeExampleSchema As NSchema

#End Region

#Region "Static Methods"

        Private Shared Function GetDescriptionParagraph(ByVal text As String) As NParagraph
            Return New NParagraph(text)
        End Function

        Private Shared Function GetTitleParagraphNoBorder(ByVal text As String, ByVal level As Integer) As NParagraph
            Dim fontSize As Double = 10
            Dim fontStyle = ENFontStyle.Regular

            Select Case level
                Case 1
                    fontSize = 16
                    fontStyle = ENFontStyle.Bold
                Case 2
                    fontSize = 10
                    fontStyle = ENFontStyle.Bold
            End Select

            Dim paragraph As NParagraph = New NParagraph()
            paragraph.HorizontalAlignment = ENAlign.Left
            paragraph.FontSize = fontSize
            paragraph.FontStyle = fontStyle
            Dim textInline As NTextInline = New NTextInline(text)
            textInline.FontStyle = fontStyle
            textInline.FontSize = fontSize
            paragraph.Inlines.Add(textInline)
            Return paragraph
        End Function

        Private Shared Function GetDescriptionBlock(ByVal title As String, ByVal description As String, ByVal level As Integer) As NGroupBlock
            Dim color = NColor.Black
            Dim paragraph = GetTitleParagraphNoBorder(title, level)
            Dim groupBlock As NGroupBlock = New NGroupBlock()
            groupBlock.ClearMode = ENClearMode.All
            groupBlock.Blocks.Add(paragraph)
            groupBlock.Blocks.Add(GetDescriptionParagraph(description))
            groupBlock.Border = CreateLeftTagBorder(color)
            groupBlock.BorderThickness = defaultBorderThickness
            Return groupBlock
        End Function
        ''' <summary>
        ''' Creates a left tag border with the specified border
        ''' </summary>
        ''' <paramname="color"></param>
        ''' <returns></returns>
        Private Shared Function CreateLeftTagBorder(ByVal color As NColor) As NBorder
            Dim border As NBorder = New NBorder()
            border.LeftSide = New NBorderSide()
            border.LeftSide.Fill = New NColorFill(color)
            Return border
        End Function

#End Region

#Region "Constants"

        Private Shared ReadOnly defaultBorderThickness As NMargins = New NMargins(5.0, 0.0, 0.0, 0.0)

#End Region
    End Class
End Namespace

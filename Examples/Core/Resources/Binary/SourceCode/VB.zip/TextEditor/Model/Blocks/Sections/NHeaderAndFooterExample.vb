Imports System.Text
Imports Nevron.Nov.Dom
Imports Nevron.Nov.Graphics
Imports Nevron.Nov.Text
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.Text
    ''' <summary>
    ''' The example demonstrates how to programmatically create paragraphs with differnt formatting
    ''' </summary>
    Public Class NHeaderAndFooterExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' 
        ''' </summary>
        Public Sub New()
        End Sub
        ''' <summary>
        ''' 
        ''' </summary>
        Shared Sub New()
            NHeaderAndFooterExampleSchema = NSchema.Create(GetType(NHeaderAndFooterExample), NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            ' Create the rich text
            Dim richTextWithRibbon As NRichTextViewWithRibbon = New NRichTextViewWithRibbon()
            m_RichText = richTextWithRibbon.View
            m_RichText.AcceptsTab = True
            m_RichText.Content.Sections.Clear()

            ' Populate the rich text
            PopulateRichText()
            Return richTextWithRibbon
        End Function

        Protected Overrides Function CreateExampleControls() As NWidget
            Return Nothing
        End Function

        Protected Overrides Function GetExampleDescription() As String
            Return "
<p>
	This example demonstrates how create sections with different header and footer. Each section has three different properties for header and footer that allow you to specify distinct header and footer for first, left and right pages.
</p>
"
        End Function

        Private Sub PopulateRichText()
            m_RichText.Content.Layout = ENTextLayout.Print

            For sectionIndex = 0 To 3 - 1
                Dim section As NSection = New NSection()
                Dim color = NColor.Empty
                Dim sectionText = String.Empty

                Select Case sectionIndex
                    Case 0
                        sectionText = "Red Section (uniform header and footer)."
                        color = NColor.Red
                        section.Blocks.Add(GetDescriptionBlock("Section Headers and Footers", "This example shows how to create sections with different header and footer settings.", 1))
                        section.DifferentFirstHeaderAndFooter = False
                        section.DifferentLeftRightHeadersAndFooters = False
                        Dim header = CreateHeaderFooter("Uniform Header.")
                        header.BackgroundFill = New NColorFill(color)
                        section.Header = header
                        Dim footer = CreateHeaderFooter("Uniform Footer.")
                        footer.BackgroundFill = New NColorFill(color)
                        section.Footer = footer
                    Case 1
                        sectionText = "Green Section (different first header and footer)."
                        color = NColor.Green
                        section.BreakType = ENSectionBreakType.NextPage
                        section.DifferentFirstHeaderAndFooter = True
                        section.DifferentLeftRightHeadersAndFooters = False
                        Dim headerFirst = CreateHeaderFooter("First Page Header.")
                        headerFirst.BackgroundFill = New NColorFill(color)
                        section.HeaderFirst = headerFirst
                        Dim footerFirst = CreateHeaderFooter("First Page Footer.")
                        footerFirst.BackgroundFill = New NColorFill(color)
                        section.FooterFirst = footerFirst
                    Case 2
                        sectionText = "Blue Section (different left and right page header and footer)."
                        color = NColor.Blue
                        section.BreakType = ENSectionBreakType.NextPage
                        section.DifferentFirstHeaderAndFooter = False
                        section.DifferentLeftRightHeadersAndFooters = True
                        Dim headerLeft = CreateHeaderFooter("Left Page Header.")
                        headerLeft.BackgroundFill = New NColorFill(color)
                        section.HeaderLeft = headerLeft
                        Dim headerRight = CreateHeaderFooter("Right Page Header.")
                        headerRight.BackgroundFill = New NColorFill(color)
                        section.HeaderRight = headerRight
                        Dim footerLeft = CreateHeaderFooter("Left Page Footer.")
                        footerLeft.BackgroundFill = New NColorFill(color)
                        section.FooterLeft = footerLeft
                        Dim footerRight = CreateHeaderFooter("Right Page Footer.")
                        footerRight.BackgroundFill = New NColorFill(color)
                        section.FooterRight = footerRight
                End Select

                m_RichText.Content.Sections.Add(section)

                ' add some section contentparagraphs with some simple text
                For i = 0 To 20 - 1
                    Dim paragraph As NParagraph = New NParagraph()
                    Dim textInline As NTextInline = New NTextInline(GetRepeatingText(sectionText, 5))
                    textInline.Fill = New NColorFill(color)
                    paragraph.Inlines.Add(textInline)
                    section.Blocks.Add(paragraph)
                Next
            Next
        End Sub

#End Region

#Region "Implementation"

        Private Function CreateHeaderFooter(ByVal text As String) As NHeaderFooter
            Dim headerFooter As NHeaderFooter = New NHeaderFooter()
            Dim paragraph As NParagraph = New NParagraph()
            paragraph.Inlines.Add(New NTextInline(text))
            paragraph.Inlines.Add(New NTextInline(". Page "))
            paragraph.Inlines.Add(New NFieldInline(ENNumericFieldName.PageNumber))
            paragraph.Inlines.Add(New NTextInline(" of "))
            paragraph.Inlines.Add(New NFieldInline(ENNumericFieldName.PageCount))
            headerFooter.Blocks.Add(paragraph)
            Return headerFooter
        End Function

#End Region

#Region "Fields"

        Private m_RichText As NRichTextView

#End Region

#Region "Schema"

        Public Shared ReadOnly NHeaderAndFooterExampleSchema As NSchema

#End Region

#Region "Static Methods"

        Private Shared Function GetDescriptionParagraph(ByVal text As String) As NParagraph
            Return New NParagraph(text)
        End Function

        Private Shared Function GetTitleParagraphNoBorder(ByVal text As String, ByVal level As Integer) As NParagraph
            Dim fontSize As Double = 10
            Dim fontStyle = ENFontStyle.Regular

            Select Case level
                Case 1
                    fontSize = 16
                    fontStyle = ENFontStyle.Bold
                Case 2
                    fontSize = 10
                    fontStyle = ENFontStyle.Bold
            End Select

            Dim paragraph As NParagraph = New NParagraph()
            paragraph.HorizontalAlignment = ENAlign.Left
            paragraph.FontSize = fontSize
            paragraph.FontStyle = fontStyle
            Dim textInline As NTextInline = New NTextInline(text)
            textInline.FontStyle = fontStyle
            textInline.FontSize = fontSize
            paragraph.Inlines.Add(textInline)
            Return paragraph
        End Function
        ''' <summary>
        ''' Gets a paragraph with title formatting
        ''' </summary>
        ''' <paramname="text"></param>
        ''' <returns></returns>
        Private Shared Function GetTitleParagraph(ByVal text As String, ByVal level As Integer) As NParagraph
            Dim color = NColor.Black
            Dim paragraph = GetTitleParagraphNoBorder(text, level)
            paragraph.HorizontalAlignment = ENAlign.Left
            paragraph.Border = CreateLeftTagBorder(color)
            paragraph.BorderThickness = defaultBorderThickness
            Return paragraph
        End Function

        Private Shared Function GetNoteBlock(ByVal text As String, ByVal level As Integer) As NGroupBlock
            Dim color = NColor.Red
            Dim paragraph = GetTitleParagraphNoBorder("Note", level)
            Dim groupBlock As NGroupBlock = New NGroupBlock()
            groupBlock.ClearMode = ENClearMode.All
            groupBlock.Blocks.Add(paragraph)
            groupBlock.Blocks.Add(GetDescriptionParagraph(text))
            groupBlock.Border = CreateLeftTagBorder(color)
            groupBlock.BorderThickness = defaultBorderThickness
            Return groupBlock
        End Function

        Private Shared Function GetDescriptionBlock(ByVal title As String, ByVal description As String, ByVal level As Integer) As NGroupBlock
            Dim color = NColor.Black
            Dim paragraph = GetTitleParagraphNoBorder(title, level)
            Dim groupBlock As NGroupBlock = New NGroupBlock()
            groupBlock.ClearMode = ENClearMode.All
            groupBlock.Blocks.Add(paragraph)
            groupBlock.Blocks.Add(GetDescriptionParagraph(description))
            groupBlock.Border = CreateLeftTagBorder(color)
            groupBlock.BorderThickness = defaultBorderThickness
            Return groupBlock
        End Function
        ''' <summary>
        ''' Creates a left tag border with the specified border
        ''' </summary>
        ''' <paramname="color"></param>
        ''' <returns></returns>
        Private Shared Function CreateLeftTagBorder(ByVal color As NColor) As NBorder
            Dim border As NBorder = New NBorder()
            border.LeftSide = New NBorderSide()
            border.LeftSide.Fill = New NColorFill(color)
            Return border
        End Function

        Private Shared Function GetLoremIpsumParagraph() As NParagraph
            Return New NParagraph("Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vestibulum placerat in tortor nec tincidunt. Sed sagittis in sem ac auctor. Donec scelerisque molestie eros, a dictum leo fringilla eu. Vivamus porta urna non ullamcorper commodo. Nulla posuere sodales pellentesque. Donec a erat et tortor viverra euismod non et erat. Donec dictum ante eu mauris porta, eget suscipit mi ultrices. Nunc convallis adipiscing ligula, non pharetra dolor egestas at. Etiam in condimentum sapien. Praesent sagittis pulvinar metus, a posuere mauris aliquam eget.")
        End Function
        ''' <summary>
        ''' Gets the specified text repeated
        ''' </summary>
        ''' <paramname="text"></param>
        ''' <paramname="count"></param>
        ''' <returns></returns>
        Private Shared Function GetRepeatingText(ByVal text As String, ByVal count As Integer) As String
            Dim builder As StringBuilder = New StringBuilder()

            For i = 0 To count - 1

                If builder.Length > 0 Then
                    builder.Append(" ")
                End If

                builder.Append(text)
            Next

            Return builder.ToString()
        End Function

#End Region

#Region "Constants"

        Private Shared ReadOnly defaultBorderThickness As NMargins = New NMargins(5.0, 0.0, 0.0, 0.0)

#End Region

    End Class
End Namespace

Imports Nevron.Nov.Dom
Imports Nevron.Nov.Graphics
Imports Nevron.Nov.Text
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.Text
    ''' <summary>
    ''' The example demonstrates how to programmatically create paragraphs with differnt formatting
    ''' </summary>
    Public Class NPageBreaksExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' 
        ''' </summary>
        Public Sub New()
        End Sub
        ''' <summary>
        ''' 
        ''' </summary>
        Shared Sub New()
            NPageBreaksExampleSchema = NSchema.Create(GetType(NPageBreaksExample), NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            ' Create the rich text
            Dim richTextWithRibbon As NRichTextViewWithRibbon = New NRichTextViewWithRibbon()
            m_RichText = richTextWithRibbon.View
            m_RichText.AcceptsTab = True
            m_RichText.Content.Sections.Clear()

            ' Populate the rich text
            PopulateRichText()
            Return richTextWithRibbon
        End Function

        Protected Overrides Function CreateExampleControls() As NWidget
            Return Nothing
        End Function
        ''' <summary>
        ''' 
        ''' </summary>
        ''' <returns></returns>
        Protected Overrides Function GetExampleDescription() As String
            Return "
<p>
	This example demonstrates how to programmatically add page breaks inlines to paragraphs.
</p>
"
        End Function

        Private Sub PopulateRichText()
            Dim section As NSection = New NSection()
            m_RichText.Content.Sections.Add(section)
            m_RichText.Content.Layout = ENTextLayout.Print
            section.Blocks.Add(GetDescriptionBlock("Page Breaks", "The example shows how to add page break inlines.", 1))

            ' paragraphs with different horizontal alignment
            section.Blocks.Add(GetTitleParagraph("Paragraphs can contain explicit page breaks", 2))

            For i = 0 To 23 - 1

                If i Mod 10 = 0 Then
                    section.Blocks.Add(GetParagraphWithPageBreak())
                Else
                    section.Blocks.Add(GetParagraphWithoutPageBreak())
                End If
            Next

            section.Blocks.Add(GetTitleParagraph("Tables can also contain page breaks", 2))
            Dim table As NTable = New NTable(3, 3)

            For row = 0 To table.Rows.Count - 1

                For col = 0 To table.Columns.Count - 1
                    ' by default cells contain a single paragraph
                    table.Rows(row).Cells(col).Blocks.Clear()
                    table.Rows(row).Cells(col).Blocks.Add(GetParagraphWithoutPageBreak())
                Next
            Next

            table.Rows(1).Cells(1).Blocks.Clear()
            table.Rows(1).Cells(1).Blocks.Add(GetParagraphWithPageBreak())
            section.Blocks.Add(table)
        End Sub

#End Region

#Region "Implementation"

        ''' <summary>
        ''' Gets a paragraph without an explicit page break
        ''' </summary>
        ''' <paramname="alignment"></param>
        ''' <returns></returns>
        Private Shared Function GetParagraphWithoutPageBreak() As NParagraph
            Dim text = String.Empty

            For i = 0 To 10 - 1

                If text.Length > 0 Then
                    text += " "
                End If

                text += "This is a paragraph without an explicit page break."
            Next

            Return New NParagraph(text)
        End Function
        ''' <summary>
        ''' Gets a paragraph with an explicit page break
        ''' </summary>
        ''' <paramname="alignment"></param>
        ''' <returns></returns>
        Private Shared Function GetParagraphWithPageBreak() As NParagraph
            Dim text = String.Empty
            Dim paragraph As NParagraph = New NParagraph()

            For i = 0 To 5 - 1

                If text.Length > 0 Then
                    text += " "
                End If

                text += "This is a paragraph with an explicit page break."
            Next

            paragraph.Inlines.Add(New NTextInline(text))
            Dim inline As NTextInline = New NTextInline("Page break appears here!")
            inline.FontStyle = inline.FontStyle Or ENFontStyle.Bold
            paragraph.Inlines.Add(inline)
            paragraph.Inlines.Add(New NPageBreakInline())
            paragraph.Inlines.Add(New NTextInline(text))
            Return paragraph
        End Function

#End Region

#Region "Fields"

        Private m_RichText As NRichTextView

#End Region

#Region "Schema"

        Public Shared ReadOnly NPageBreaksExampleSchema As NSchema

#End Region

#Region "Static Methods"

        Private Shared Function GetDescriptionParagraph(ByVal text As String) As NParagraph
            Return New NParagraph(text)
        End Function

        Private Shared Function GetTitleParagraphNoBorder(ByVal text As String, ByVal level As Integer) As NParagraph
            Dim fontSize As Double = 10
            Dim fontStyle = ENFontStyle.Regular

            Select Case level
                Case 1
                    fontSize = 16
                    fontStyle = ENFontStyle.Bold
                Case 2
                    fontSize = 10
                    fontStyle = ENFontStyle.Bold
            End Select

            Dim paragraph As NParagraph = New NParagraph()
            paragraph.HorizontalAlignment = ENAlign.Left
            paragraph.FontSize = fontSize
            paragraph.FontStyle = fontStyle
            Dim textInline As NTextInline = New NTextInline(text)
            textInline.FontStyle = fontStyle
            textInline.FontSize = fontSize
            paragraph.Inlines.Add(textInline)
            Return paragraph
        End Function
        ''' <summary>
        ''' Gets a paragraph with title formatting
        ''' </summary>
        ''' <paramname="text"></param>
        ''' <returns></returns>
        Private Shared Function GetTitleParagraph(ByVal text As String, ByVal level As Integer) As NParagraph
            Dim color = NColor.Black
            Dim paragraph = GetTitleParagraphNoBorder(text, level)
            paragraph.HorizontalAlignment = ENAlign.Left
            paragraph.Border = CreateLeftTagBorder(color)
            paragraph.BorderThickness = defaultBorderThickness
            Return paragraph
        End Function

        Private Shared Function GetDescriptionBlock(ByVal title As String, ByVal description As String, ByVal level As Integer) As NGroupBlock
            Dim color = NColor.Black
            Dim paragraph = GetTitleParagraphNoBorder(title, level)
            Dim groupBlock As NGroupBlock = New NGroupBlock()
            groupBlock.ClearMode = ENClearMode.All
            groupBlock.Blocks.Add(paragraph)
            groupBlock.Blocks.Add(GetDescriptionParagraph(description))
            groupBlock.Border = CreateLeftTagBorder(color)
            groupBlock.BorderThickness = defaultBorderThickness
            Return groupBlock
        End Function
        ''' <summary>
        ''' Creates a left tag border with the specified border
        ''' </summary>
        ''' <paramname="color"></param>
        ''' <returns></returns>
        Private Shared Function CreateLeftTagBorder(ByVal color As NColor) As NBorder
            Dim border As NBorder = New NBorder()
            border.LeftSide = New NBorderSide()
            border.LeftSide.Fill = New NColorFill(color)
            Return border
        End Function

#End Region

#Region "Constants"

        Private Shared ReadOnly defaultBorderThickness As NMargins = New NMargins(5.0, 0.0, 0.0, 0.0)

#End Region
    End Class
End Namespace

Imports Nevron.Nov.Dom
Imports Nevron.Nov.Text
Imports Nevron.Nov.UI
Imports Nevron.Nov.Graphics

Namespace Nevron.Nov.Examples.Text
    ''' <summary>
    ''' The example demonstrates how to programmatically create paragraphs with differnt inline formatting
    ''' </summary>
    Public Class NTableColumnTypesExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' 
        ''' </summary>
        Public Sub New()
        End Sub
        ''' <summary>
        ''' 
        ''' </summary>
        Shared Sub New()
            NTableColumnTypesExampleSchema = NSchema.Create(GetType(NTableColumnTypesExample), NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            ' Create the rich text
            Dim richTextWithRibbon As NRichTextViewWithRibbon = New NRichTextViewWithRibbon()
            m_RichText = richTextWithRibbon.View
            m_RichText.AcceptsTab = True
            m_RichText.Content.Sections.Clear()

            ' Populate the rich text
            PopulateRichText()
            Return richTextWithRibbon
        End Function

        Protected Overrides Function CreateExampleControls() As NWidget
            Return Nothing
        End Function

        Protected Overrides Function GetExampleDescription() As String
            Return "<p>This example demonstrates how to set the table column preferred width.</p>"
        End Function

        Private Sub PopulateRichText()
            Dim section As NSection = New NSection()
            m_RichText.Content.Sections.Add(section)
            section.Blocks.Add(GetDescriptionBlock("Table Column Types Example", "This example shows how to set the table column's preferred width.", 1))

            If True Then
                ' create the table
                Dim table As NTable = New NTable()
                table.AllowSpacingBetweenCells = False
                Dim columnCount = 5
                Dim rowCount = 5

                For row = 0 To rowCount - 1
                    Dim tableRow As NTableRow = New NTableRow()
                    table.Rows.Add(tableRow)

                    For col = 0 To columnCount - 1
                        Dim paragraph As NParagraph

                        If row = 0 Then
                            ' set table column preferred width
                            Dim headerText = String.Empty
                            Dim tableColumn As NTableColumn = New NTableColumn()

                            If col Mod 2 = 0 Then
                                tableColumn.BackgroundFill = New NColorFill(NColor.LightGray)
                            Else
                                tableColumn.BackgroundFill = New NColorFill(NColor.Beige)
                            End If

                            Select Case col
                                Case 0 ' Fixed column
                                    tableColumn.PreferredWidth = New NMultiLength(ENMultiLengthUnit.Dip, 80)
                                    headerText = "Fixed [80dips]"
                                Case 1 ' Auto
                                    headerText = "Automatic"
                                Case 2 ' Percentage
                                    tableColumn.PreferredWidth = New NMultiLength(ENMultiLengthUnit.Percentage, 20)
                                    headerText = "Percentage [20%]"
                                Case 3 ' Fixed
                                    tableColumn.PreferredWidth = New NMultiLength(ENMultiLengthUnit.Dip, 160)
                                    headerText = "Fixed [160dips]"
                                Case 4 ' Percentage
                                    tableColumn.PreferredWidth = New NMultiLength(ENMultiLengthUnit.Percentage, 30)
                                    headerText = "Percentage [30%]"
                            End Select

                            table.Columns.Add(tableColumn)
                            paragraph = New NParagraph(headerText)
                        Else
                            paragraph = New NParagraph("Cell")
                        End If

                        ' by default cells contain a single paragraph
                        Dim tableCell As NTableCell = New NTableCell()
                        tableCell.Border = NBorder.CreateFilledBorder(NColor.Black)
                        tableCell.BorderThickness = New NMargins(1)
                        tableCell.Blocks.Add(paragraph)
                        tableRow.Cells.Add(tableCell)
                    Next
                Next

                section.Blocks.Add(table)
            End If
        End Sub

#End Region

#Region "Fields"

        Private m_RichText As NRichTextView

#End Region

#Region "Schema"

        Public Shared ReadOnly NTableColumnTypesExampleSchema As NSchema

#End Region

#Region "Static Methods"

        Private Shared Function GetDescriptionParagraph(ByVal text As String) As NParagraph
            Return New NParagraph(text)
        End Function

        Private Shared Function GetTitleParagraphNoBorder(ByVal text As String, ByVal level As Integer) As NParagraph
            Dim fontSize As Double = 10
            Dim fontStyle = ENFontStyle.Regular

            Select Case level
                Case 1
                    fontSize = 16
                    fontStyle = ENFontStyle.Bold
                Case 2
                    fontSize = 10
                    fontStyle = ENFontStyle.Bold
            End Select

            Dim paragraph As NParagraph = New NParagraph()
            paragraph.HorizontalAlignment = ENAlign.Left
            paragraph.FontSize = fontSize
            paragraph.FontStyle = fontStyle
            Dim textInline As NTextInline = New NTextInline(text)
            textInline.FontStyle = fontStyle
            textInline.FontSize = fontSize
            paragraph.Inlines.Add(textInline)
            Return paragraph
        End Function

        Private Shared Function GetDescriptionBlock(ByVal title As String, ByVal description As String, ByVal level As Integer) As NGroupBlock
            Dim color = NColor.Black
            Dim paragraph = GetTitleParagraphNoBorder(title, level)
            Dim groupBlock As NGroupBlock = New NGroupBlock()
            groupBlock.ClearMode = ENClearMode.All
            groupBlock.Blocks.Add(paragraph)
            groupBlock.Blocks.Add(GetDescriptionParagraph(description))
            groupBlock.Border = CreateLeftTagBorder(color)
            groupBlock.BorderThickness = defaultBorderThickness
            Return groupBlock
        End Function
        ''' <summary>
        ''' Creates a left tag border with the specified border
        ''' </summary>
        ''' <paramname="color"></param>
        ''' <returns></returns>
        Private Shared Function CreateLeftTagBorder(ByVal color As NColor) As NBorder
            Dim border As NBorder = New NBorder()
            border.LeftSide = New NBorderSide()
            border.LeftSide.Fill = New NColorFill(color)
            Return border
        End Function

#End Region

#Region "Constants"

        Private Shared ReadOnly defaultBorderThickness As NMargins = New NMargins(5.0, 0.0, 0.0, 0.0)

#End Region
    End Class
End Namespace

Imports System.Text
Imports Nevron.Nov.DataStructures
Imports Nevron.Nov.Dom
Imports Nevron.Nov.Graphics
Imports Nevron.Nov.Layout
Imports Nevron.Nov.Text
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.Text
    Public Class NSpellCheckExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' Default constructor.
        ''' </summary>
        Public Sub New()
        End Sub
        ''' <summary>
        ''' Static constructor.
        ''' </summary>
        Shared Sub New()
            NSpellCheckExampleSchema = NSchema.Create(GetType(NSpellCheckExample), NExampleBase.NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            Dim stack As NStackPanel = New NStackPanel()
            stack.FillMode = ENStackFillMode.Last
            stack.FitMode = ENStackFitMode.Last
            stack.VerticalSpacing = 10
            m_RichTextView = New NRichTextView()
            m_RichTextView.Content.Sections.Clear()
            Dim section As NSection = New NSection()
            m_RichTextView.Content.Sections.Add(section)
            stack.Add(m_RichTextView)
            section.Blocks.Add(New NParagraph(Text1))
            section.Blocks.Add(New NParagraph(Text2))
            Return stack
        End Function

        Protected Overrides Function CreateExampleControls() As NWidget
            Dim stack As NStackPanel = New NStackPanel()
            Dim spellCheckButton As NToggleButton = New NToggleButton("Enable Spell Checking")
            AddHandler spellCheckButton.CheckedChanged, AddressOf OnSpellCheckButtonCheckedChanged
            stack.Add(spellCheckButton)
            Dim suggetsionsButton As NButton = New NButton("Get Suggestions")
            AddHandler suggetsionsButton.Click, AddressOf OnSuggetsionsButtonClick
            stack.Add(suggetsionsButton)
            Return stack
        End Function

        Protected Overrides Function GetExampleDescription() As String
            Return "<p>The example demonstrates the built in spell checker functionality.</p>"
        End Function

#End Region

#Region "Event Handlers"

        Private Sub OnSpellCheckButtonCheckedChanged(ByVal arg As NValueChangeEventArgs)
            m_RichTextView.SpellChecker.Enabled = CBool(arg.NewValue)
        End Sub

        Private Sub OnSuggetsionsButtonClick(ByVal args As NEventArgs)
            Dim paragraphs As NList(Of NParagraph) = m_RichTextView.Selection.GetSelectedParagraphs()
            If paragraphs.Count = 0 Then Return
            Dim paragraph = paragraphs(0)

            ' Determine the current word
            Dim words As NList(Of NRangeI) = paragraph.GetWordRanges()
            Dim index = m_RichTextView.EditingRoot.Selection.Position.InsertIndex - paragraph.Range.Begin
            Dim hasWord = False
            Dim wordRange = NRangeI.Zero

            For i = 0 To words.Count - 1

                If words(i).Contains(index) Then
                    hasWord = True
                    wordRange = words(i)
                End If
            Next

            If Not hasWord Then
                NMessageBox.Show(m_RichTextView.DisplayWindow, "You should click in a word first", "Warning", ENMessageBoxButtons.OK, ENMessageBoxIcon.Warning)
                Return
            End If

            Dim word As Char() = paragraph.Text.Substring(wordRange.Begin, wordRange.GetLength() + 1).ToCharArray()
            Dim title As String = "Suggestions for '" & New String(word) & "'"
            Dim content As String

            If m_RichTextView.SpellChecker.IsCorrect(word, 0, word.Length - 1) = False Then
                Dim suggestions = m_RichTextView.SpellChecker.GetSuggestions(word, 0, word.Length - 1)
                Dim sb As StringBuilder = New StringBuilder()

                While suggestions.MoveNext()

                    If sb.Length > 0 Then
                        sb.Append(vbLf)
                    End If

                    sb.Append(suggestions.Current)
                End While

                content = sb.ToString()
            Else
                content = "The word is correct."
            End If

            NMessageBox.Show(m_RichTextView.DisplayWindow, content, title, ENMessageBoxButtons.OK)
        End Sub

#End Region

#Region "Fields"

        Private m_RichTextView As NRichTextView

#End Region

#Region "Schema"

        ''' <summary>
        ''' Schema associated with NSpellCheckExample.
        ''' </summary>
        Public Shared ReadOnly NSpellCheckExampleSchema As NSchema

#End Region

#Region "Constants"

        Private Const Text1 As String = "Nevron Softuare is a globl leader in component based data vizualization technology " & "for a divrese range of Microsoft centric platforms. Built with perfectin, usability and enterprize level featurs " & "in mind, our components deliverr advanced digital dachboards and diagrams that are not to be matched."
        Private Const Text2 As String = "Tuday Nevron components are used by many Fortune 500 companis and thousands of developers " & "and IT profesionals worldwide."
        Private Const BytesInMB As Long = 1024 * 1024

#End Region
    End Class
End Namespace

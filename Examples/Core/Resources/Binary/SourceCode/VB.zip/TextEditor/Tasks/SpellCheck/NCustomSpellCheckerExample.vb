Imports Nevron.Nov.DataStructures
Imports Nevron.Nov.Dom
Imports Nevron.Nov.Graphics
Imports Nevron.Nov.Layout
Imports Nevron.Nov.Text
Imports Nevron.Nov.Text.SpellCheck
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.Text
    Public Class NCustomSpellCheckerExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' Default constructor.
        ''' </summary>
        Public Sub New()
        End Sub
        ''' <summary>
        ''' Static constructor.
        ''' </summary>
        Shared Sub New()
            NCustomSpellCheckerExampleSchema = NSchema.Create(GetType(NCustomSpellCheckerExample), NExampleBase.NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            Dim stack As NStackPanel = New NStackPanel()
            stack.FillMode = ENStackFillMode.Last
            stack.FitMode = ENStackFitMode.Last
            stack.VerticalSpacing = 10
            m_RichTextView = New NRichTextView()
            m_RichTextView.Content.Sections.Clear()
            Dim section As NSection = New NSection()
            m_RichTextView.Content.Sections.Add(section)
            stack.Add(m_RichTextView)
            section.Blocks.Add(New NParagraph(Text1))
            section.Blocks.Add(New NParagraph(Text2))
            m_RichTextView.SpellChecker = New CustomSpellchecker()

            ' the following code shows how to disable the mini toolbar and leave only the text proofing context menu builder
            m_RichTextView.ContextMenuBuilder.Groups.Clear()
            m_RichTextView.ContextMenuBuilder.ShowMiniToolbar = False
            m_RichTextView.ContextMenuBuilder.Groups.Add(New Nov.Text.UI.NProofingMenuGroup())
            Return stack
        End Function

        Protected Overrides Function CreateExampleControls() As NWidget
            Dim stack As NStackPanel = New NStackPanel()
            Dim spellCheckButton As NToggleButton = New NToggleButton("Enable Spell Checking")
            AddHandler spellCheckButton.CheckedChanged, AddressOf OnSpellCheckButtonCheckedChanged
            stack.Add(spellCheckButton)
            spellCheckButton.Checked = True
            Return stack
        End Function

        Protected Overrides Function GetExampleDescription() As String
            Return "<p>The example demonstrates how to implement custom spell check functionality. In this example the custom spellchecker searched for the word ""Nevron"" and when it finds it will underline it. This functionality also works when you type text in the editor.</p>"
        End Function

#End Region

#Region "Event Handlers"

        Private Sub OnSpellCheckButtonCheckedChanged(ByVal arg As NValueChangeEventArgs)
            m_RichTextView.SpellChecker.Enabled = CBool(arg.NewValue)
        End Sub

#End Region

#Region "Fields"

        Private m_RichTextView As NRichTextView

#End Region

#Region "Schema"

        ''' <summary>
        ''' Schema associated with NCustomSpellCheckerExample.
        ''' </summary>
        Public Shared ReadOnly NCustomSpellCheckerExampleSchema As NSchema

#End Region

#Region "Constants"

        Private Const Text1 As String = "Nevron Softuare is a globl leader in component based data vizualization technology " & "for a divrese range of Microsoft centric platforms. Built with perfectin, usability and enterprize level featurs " & "in mind, our components deliverr advanced digital dachboards and diagrams that are not to be matched."
        Private Const Text2 As String = "Tuday Nevron components are used by many Fortune 500 companis and thousands of developers " & "and IT profesionals worldwide."
        Private Const BytesInMB As Long = 1024 * 1024

#End Region

#Region "Nested Types"

        ''' <summary>
        ''' Sample class that shows how to implement a custom spell checker
        ''' </summary>
        Private Class CustomSpellchecker
            Inherits NSpellChecker
            ''' <summary>
            ''' Default constructor (mandatory for all NOV DOM objects)
            ''' </summary>
            Public Sub New()
            End Sub
            ''' <summary>
            ''' Static constructor (mandatory for all NOV DOM objects)
            ''' </summary>
            Shared Sub New()
                CustomSpellcheckerSchema = NSchema.Create(GetType(CustomSpellchecker), NSpellCheckerSchema)
            End Sub
            ''' <summary>
            ''' Gets a list of misspelled word ranges
            ''' </summary>
            ''' <paramname="chars"></param>
            ''' <paramname="protectWordRange">when set to true the spellchecker must check the words that intersect the specified range as the user may be currently typing there.</param>
            ''' <paramname="protectedWordRange">the protected word range</param>
            ''' <returns></returns>
            Public Overrides Function GetMisspelledWordRanges(ByVal chars As Char(), ByVal protectWordRange As Boolean, ByVal protectedWordRange As NRangeI) As NList(Of NRangeI)
                Dim text As String = New String(chars)
                Dim invalidWord = "Nevron"
                Dim index = 0
                Dim misspelledWordRanges As NList(Of NRangeI) = New NList(Of NRangeI)()

                While CSharpImpl.__Assign(index, text.IndexOf(invalidWord, index)) <> -1
                    Dim currentRange As NRangeI = New NRangeI(index, index + invalidWord.Length - 1)
                    ' skip the currently protected spellcheck word, because the user is currently typing in there
                    If Not protectWordRange OrElse Not protectedWordRange.Equals(currentRange) Then
                        misspelledWordRanges.Add(currentRange)
                    End If

                    index += invalidWord.Length
                End While

                Return misspelledWordRanges
            End Function

            Public Overrides Function GetSuggestions(ByVal chars As Char(), ByVal beginIndex As Integer, ByVal endIndex As Integer) As INIterator(Of Char())
                Return MyBase.GetSuggestions(chars, beginIndex, endIndex)
            End Function

            Private Shared ReadOnly CustomSpellcheckerSchema As NSchema

            Private Class CSharpImpl
                <Obsolete("Please refactor calling code to use normal Visual Basic assignment")>
                Shared Function __Assign(Of T)(ByRef target As T, value As T) As T
                    target = value
                    Return value
                End Function
            End Class
        End Class
    End Class

#End Region
End Namespace

Imports System.Globalization
Imports System.IO
Imports Nevron.Nov.Dom
Imports Nevron.Nov.Graphics
Imports Nevron.Nov.IO
Imports Nevron.Nov.Text
Imports Nevron.Nov.Text.Data
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.Text
    ''' <summary>
    ''' Demonstrates how to use the mail merge functionality of the Nevron Rich Text control.
    ''' </summary>
    Public Class NMailMergeExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' Default constructor.
        ''' </summary>
        Public Sub New()
        End Sub
        ''' <summary>
        ''' Static constructor.
        ''' </summary>
        Shared Sub New()
            NMailMergeExampleSchema = NSchema.Create(GetType(NMailMergeExample), NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            ' Create the rich text
            Dim richTextWithRibbon As NRichTextViewWithRibbon = New NRichTextViewWithRibbon()
            m_RichText = richTextWithRibbon.View
            m_RichText.AcceptsTab = True
            m_RichText.Content.Sections.Clear()

            ' Populate the rich text
            PopulateRichText()
            Return richTextWithRibbon
        End Function

        Protected Overrides Function CreateExampleControls() As NWidget
            Dim stack As NStackPanel = New NStackPanel()

            If NApplication.IntegrationPlatform <> ENIntegrationPlatform.Silverlight Then
                Dim mergeAndSaveToFolderButton As NButton = New NButton("Merge & Save to Folder")
                AddHandler mergeAndSaveToFolderButton.Click, AddressOf OnMergeAndSaveToFolderButtonClick
                stack.Add(mergeAndSaveToFolderButton)
            End If

            Return stack
        End Function

        Protected Overrides Function GetExampleDescription() As String
            Dim previewMailMergeUri = NDataUri.FromImage(NResources.Image_Documentation_PreviewResults_png)
            Return "
<p>
	This example demonstrates how to use the mail merge functionality of the Nevron Rich Text control.
</p>
<p>
	Click the <b>Preview Mail Merge</b> button (&nbsp;<img src=""" & previewMailMergeUri.ToString() & """ />&nbsp;) from the <b>Mailings</b> ribbon tab to see the values for the currently selected
    mail merge record. When ready click the <b>Merge & Save</b> button to save all merged documents to a file.
</p>
<p>
	The <b>Merge & Save</b> button saves each of the individual documents result of the mail
	merge operation to a folder.	
</p>
"
        End Function

        Private Sub PopulateRichText()
            ' Create some text
            Dim documentBlock = m_RichText.Content
            documentBlock.Layout = ENTextLayout.Print
            Dim section As NSection = New NSection()
            documentBlock.Sections.Add(section)
            Dim paragraph As NParagraph = New NParagraph()
            paragraph.Inlines.Add(CreateMailMergeField(New NGreetingLineFieldValue()))
            section.Blocks.Add(paragraph)
            paragraph = New NParagraph()
            paragraph.Inlines.Add(New NTextInline("We would like to offer you a unique software component that will help you leverage multiple platforms with single code base. We believe that as a "))
            paragraph.Inlines.Add(CreateMailMergeField(New NMailMergeSourceFieldValue("Title")))
            paragraph.Inlines.Add(New NTextInline(" in your company you will be very interested in this solution. If that's the case do not hesitate to contact us in order to arrange a meeting in "))
            paragraph.Inlines.Add(CreateMailMergeField(New NMailMergePredefinedFieldValue(ENMailMergeDataField.City)))
            paragraph.Inlines.Add(New NTextInline("."))
            section.Blocks.Add(paragraph)
            paragraph = New NParagraph()
            paragraph.Inlines.Add(New NTextInline("Best Regards,"))
            paragraph.Inlines.Add(New NLineBreakInline())
            paragraph.Inlines.Add(New NTextInline("Nevron Software"))
            paragraph.Inlines.Add(New NLineBreakInline())
            paragraph.Inlines.Add(New NHyperlinkInline("www.nevron.com", "https://www.nevron.com"))
            section.Blocks.Add(paragraph)

            ' Load a mail merge data source from resource
            Dim stream = NResources.Instance.GetResourceStream("RSTR_Employees_csv")
            Dim dataSource As NMailMergeDataSource = NDataSourceFormat.Csv.LoadFromStream(stream, New NDataSourceLoadSettings(Nothing, Nothing, True))

            ' Create the field mappings
            Dim fieldMap As NMailMergeFieldMap = New NMailMergeFieldMap()
            fieldMap.Set(ENMailMergeDataField.CourtesyTitle, "TitleOfCourtesy")
            fieldMap.Set(ENMailMergeDataField.FirstName, "FirstName")
            fieldMap.Set(ENMailMergeDataField.LastName, "LastName")
            fieldMap.Set(ENMailMergeDataField.City, "City")
            dataSource.FieldMap = fieldMap
            documentBlock.MailMerge.DataSource = dataSource
        End Sub

#End Region

#Region "Implementation"

        Private Sub MergeAndSaveToFolder(ByVal targetPath As String)
            Dim folder = NApplication.FileSystemService.GetFolder(targetPath)

            If folder Is Nothing Then
                NMessageBox.Show("The entered target path does not exist", "Error", ENMessageBoxButtons.OK, ENMessageBoxIcon.Error)
                Return
            End If

            ' Clone the rich text view
            Dim clonedRichTextView As NRichTextView = CType(m_RichText.DeepClone(), NRichTextView)

            ' Switch the mail merge of the cloned rich text view to preview mode
            Dim mailMerge = clonedRichTextView.Content.MailMerge
            mailMerge.PreviewMailMerge = True

            ' Loop through all mail merge records to save individual documents to file
            For i = 0 To mailMerge.DataRecordCount - 1
                ' Move to the next data source record
                mailMerge.CurrentDataRecordIndex = i

                ' Save the merged document to file
                Dim fileName = "Document" & i.ToString(CultureInfo.InvariantCulture) & ".docx"
                clonedRichTextView.SaveToFile(NPath.Combine(targetPath, fileName))
            Next

            NMessageBox.Show("Merged documents saved to """ & targetPath & """.", "Mail Merge Complete", ENMessageBoxButtons.OK, ENMessageBoxIcon.Information)
        End Sub

#End Region

#Region "Event Handlers"

        Private Sub OnMergeAndSaveToFolderButtonClick(ByVal arg As NEventArgs)
            Dim textBox As NTextBox = New NTextBox()
            Dim buttonStrip As NButtonStrip = New NButtonStrip()
            buttonStrip.AddOKCancelButtons()
            Dim pairBox As NPairBox = New NPairBox(textBox, buttonStrip, ENPairBoxRelation.Box1AboveBox2)
            Dim dialog As NTopLevelWindow = NApplication.CreateTopLevelWindow()
            dialog.SetupDialogWindow("Enter Folder Path", False)
            dialog.Content = pairBox
            AddHandler dialog.Closed, AddressOf OnEnterFolderDialogClosed
            dialog.Open()
        End Sub

        Private Sub OnEnterFolderDialogClosed(ByVal arg As NEventArgs)
            Dim dialog = CType(arg.TargetNode, NTopLevelWindow)

            If dialog.Result = ENWindowResult.OK Then
                Dim textBox = CType(dialog.Content.GetFirstDescendant(NTextBox.NTextBoxSchema), NTextBox)
                MergeAndSaveToFolder(textBox.Text)
            End If
        End Sub

#End Region

#Region "Fields"

        Private m_RichText As NRichTextView

#End Region

#Region "Schema"

        ''' <summary>
        ''' Schema associated with NMailMergeExample.
        ''' </summary>
        Public Shared ReadOnly NMailMergeExampleSchema As NSchema

#End Region

#Region "Static Methods"

        Private Shared Function CreateMailMergeField(ByVal value As NMailMergeFieldValue) As NFieldInline
            Dim fieldInline As NFieldInline = New NFieldInline(value)
            fieldInline.FontStyle = ENFontStyle.Bold
            Return fieldInline
        End Function

#End Region
    End Class
End Namespace

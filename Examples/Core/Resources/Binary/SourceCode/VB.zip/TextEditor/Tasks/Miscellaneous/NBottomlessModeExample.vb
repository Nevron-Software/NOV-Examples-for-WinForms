Imports Nevron.Nov.Dom
Imports Nevron.Nov.Graphics
Imports Nevron.Nov.Layout
Imports Nevron.Nov.Text
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.Text
    ''' <summary>
    ''' The example demonstrates how to programmatically a sample report.
    ''' </summary>
    Public Class NBottomlessModeExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' 
        ''' </summary>
        Public Sub New()
        End Sub
        ''' <summary>
        ''' 
        ''' </summary>
        Shared Sub New()
            NBottomlessModeExampleSchema = NSchema.Create(GetType(NBottomlessModeExample), NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            ' Create the rich text
            m_RichText = New NRichTextView()
            m_RichText.AcceptsTab = True
            m_RichText.Content.Sections.Clear()
            Dim section As NSection = New NSection()
            section.Blocks.Add(New NParagraph("Type some content here"))
            m_RichText.Content.Sections.Add(section)
            m_RichText.Content.Layout = ENTextLayout.Web
            m_RichText.VScrollMode = ENScrollMode.Never
            m_RichText.HScrollMode = ENScrollMode.Never
            m_RichText.HRuler.Visibility = ENVisibility.Hidden
            m_RichText.VRuler.Visibility = ENVisibility.Hidden
            m_RichText.PreferredWidth = Double.NaN
            m_RichText.PreferredHeight = Double.NaN
            m_RichText.Border = NBorder.CreateFilledBorder(NColor.Black)
            m_RichText.BorderThickness = New NMargins(1)
            m_RichText.HorizontalPlacement = ENHorizontalPlacement.Fit
            m_RichText.VerticalPlacement = ENVerticalPlacement.Top
            Return m_RichText
        End Function

        Protected Overrides Function CreateExampleControls() As NWidget
            Return Nothing
        End Function

        Protected Overrides Function GetExampleDescription() As String
            Return "<p>The example demonstrates how to create a bottomless text control.</p>"
        End Function

#End Region

#Region "Fields"

        Private m_RichText As NRichTextView

#End Region

#Region "Schema"

        Public Shared ReadOnly NBottomlessModeExampleSchema As NSchema

#End Region
    End Class
End Namespace

Imports Nevron.Nov.Dom
Imports Nevron.Nov.Graphics
Imports Nevron.Nov.Layout
Imports Nevron.Nov.Text
Imports Nevron.Nov.Text.UI
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.Text
    Public Class NRibbonAndCommandBarsExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' Default constructor.
        ''' </summary>
        Public Sub New()
        End Sub

        ''' <summary>
        ''' Static constructor.
        ''' </summary>
        Shared Sub New()
            NRibbonAndCommandBarsExampleSchema = NSchema.Create(GetType(NRibbonAndCommandBarsExample), NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            m_RichText = New NRichTextView()
            m_RichText.AcceptsTab = True
            m_RichText.Content.Sections.Clear()

            ' Populate the rich text
            PopulateRichText()

            ' Create and execute a ribbon UI builder
            m_RibbonBuilder = New NRichTextRibbonBuilder()
            Return m_RibbonBuilder.CreateUI(m_RichText)
        End Function

        Protected Overrides Function CreateExampleControls() As NWidget
            ' Switch UI button
            Dim switchUIButton As NButton = New NButton(SwitchToCommandBars)
            switchUIButton.VerticalPlacement = ENVerticalPlacement.Top
            AddHandler switchUIButton.Click, AddressOf OnSwitchUIButtonClick
            Return switchUIButton
        End Function

        Protected Overrides Function GetExampleDescription() As String
            Return "<p>This example demonstrates how to switch the NOV Rich Text commanding interface between ribbon and command bars.</p>"
        End Function

        Private Sub PopulateRichText()
            Dim section As NSection = New NSection()
            m_RichText.Content.Sections.Add(section)
            section.Blocks.Add(GetDescriptionBlock("Rich Text Ribbon and Command Bars", "This example demonstrates how to customize the NOV rich text ribbon.", 1))
        End Sub

#End Region

#Region "Implementation"

        Private Sub SetUI(ByVal oldUiHolder As NCommandUIHolder, ByVal widget As NWidget)
            If TypeOf oldUiHolder.ParentNode Is NTabPage Then
                CType(oldUiHolder.ParentNode, NTabPage).Content = widget
            ElseIf TypeOf oldUiHolder.ParentNode Is NPairBox Then
                CType(oldUiHolder.ParentNode, NPairBox).Box1 = widget
            End If
        End Sub

#End Region

#Region "Event Handlers"

        Private Sub OnSwitchUIButtonClick(ByVal arg As NEventArgs)
            Dim switchUIButton = CType(arg.TargetNode, NButton)
            Dim label = CType(switchUIButton.Content, NLabel)

            ' Remove the rich text view from its parent
            Dim uiHolder As NCommandUIHolder = m_RichText.GetFirstAncestor(Of NCommandUIHolder)()
            m_RichText.ParentNode.RemoveChild(m_RichText)

            If Equals(label.Text, SwitchToRibbon) Then
                ' We are in "Command Bars" mode, so switch to "Ribbon"
                label.Text = SwitchToCommandBars

                ' Create the ribbon
                SetUI(uiHolder, m_RibbonBuilder.CreateUI(m_RichText))
            Else
                ' We are in "Ribbon" mode, so switch to "Command Bars"
                label.Text = SwitchToRibbon

                ' Create the command bars
                If m_CommandBarBuilder Is Nothing Then
                    m_CommandBarBuilder = New NRichTextCommandBarBuilder()
                End If

                SetUI(uiHolder, m_CommandBarBuilder.CreateUI(m_RichText))
            End If
        End Sub

#End Region

#Region "Fields"

        Private m_RichText As NRichTextView
        Private m_RibbonBuilder As NRichTextRibbonBuilder
        Private m_CommandBarBuilder As NRichTextCommandBarBuilder

#End Region

#Region "Schema"

        ''' <summary>
        ''' Schema associated with NRibbonAndCommandBarsExample.
        ''' </summary>
        Public Shared ReadOnly NRibbonAndCommandBarsExampleSchema As NSchema

#End Region

#Region "Static Methods"

        Private Shared Function GetDescriptionParagraph(ByVal text As String) As NParagraph
            Return New NParagraph(text)
        End Function

        Private Shared Function GetTitleParagraphNoBorder(ByVal text As String, ByVal level As Integer) As NParagraph
            Dim fontSize As Double = 10
            Dim fontStyle = ENFontStyle.Regular

            Select Case level
                Case 1
                    fontSize = 16
                    fontStyle = ENFontStyle.Bold
                Case 2
                    fontSize = 10
                    fontStyle = ENFontStyle.Bold
            End Select

            Dim paragraph As NParagraph = New NParagraph()
            paragraph.HorizontalAlignment = ENAlign.Left
            paragraph.FontSize = fontSize
            paragraph.FontStyle = fontStyle
            Dim textInline As NTextInline = New NTextInline(text)
            textInline.FontStyle = fontStyle
            textInline.FontSize = fontSize
            paragraph.Inlines.Add(textInline)
            Return paragraph
        End Function

        Private Shared Function GetDescriptionBlock(ByVal title As String, ByVal description As String, ByVal level As Integer) As NGroupBlock
            Dim color = NColor.Black
            Dim paragraph = GetTitleParagraphNoBorder(title, level)
            Dim groupBlock As NGroupBlock = New NGroupBlock()
            groupBlock.ClearMode = ENClearMode.All
            groupBlock.Blocks.Add(paragraph)
            groupBlock.Blocks.Add(GetDescriptionParagraph(description))
            groupBlock.Border = CreateLeftTagBorder(color)
            groupBlock.BorderThickness = DefaultBorderThickness
            Return groupBlock
        End Function
        ''' <summary>
        ''' Creates a left tag border with the specified border
        ''' </summary>
        ''' <paramname="color"></param>
        ''' <returns></returns>
        Private Shared Function CreateLeftTagBorder(ByVal color As NColor) As NBorder
            Dim border As NBorder = New NBorder()
            border.LeftSide = New NBorderSide()
            border.LeftSide.Fill = New NColorFill(color)
            Return border
        End Function

#End Region

#Region "Constants"

        Private Const SwitchToCommandBars As String = "Switch to Command Bars"
        Private Const SwitchToRibbon As String = "Switch to Ribbon"
        Private Shared ReadOnly DefaultBorderThickness As NMargins = New NMargins(5.0, 0.0, 0.0, 0.0)

#End Region
    End Class
End Namespace

Imports Nevron.Nov.DataStructures
Imports Nevron.Nov.Dom
Imports Nevron.Nov.Graphics
Imports Nevron.Nov.Text
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.Text
    ''' <summary>
    ''' The example demonstrates how to programmatically a sample report.
    ''' </summary>
    Public Class NSelectionChangedExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' 
        ''' </summary>
        Public Sub New()
        End Sub
        ''' <summary>
        ''' 
        ''' </summary>
        Shared Sub New()
            NSelectionChangedExampleSchema = NSchema.Create(GetType(NSelectionChangedExample), NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            ' Create the rich text
            m_RichText = New NRichTextView()
            m_RichText.AcceptsTab = True
            m_RichText.Content.Sections.Clear()
            Dim section As NSection = New NSection()
            section.Blocks.Add(New NParagraph("The example demonstrates how to track the selection changed event."))
            section.Blocks.Add(New NParagraph("It also shows how to identify different text elements depending on the current selection."))
            section.Blocks.Add(New NParagraph("Move the selection and the control will highlight the currently selected words as well as blocks inside the text document."))
            Dim paragraph As NParagraph = New NParagraph()
            paragraph.Inlines.Add(New NTextInline("You can also detect the inline elements "))
            Dim inline1 As NTextInline = New NTextInline("that have different")
            paragraph.Inlines.Add(inline1)
            Dim inline2 As NTextInline = New NTextInline(" Font Style")
            inline2.FontStyle = ENFontStyle.Bold
            paragraph.Inlines.Add(inline2)
            Dim inline3 As NTextInline = New NTextInline(" Font Size")
            inline3.FontSize = 14
            paragraph.Inlines.Add(inline3)
            Dim inline4 As NTextInline = New NTextInline(" and / or other attributes")
            inline4.FontStyle = ENFontStyle.Italic Or ENFontStyle.Underline
            paragraph.Inlines.Add(inline4)
            section.Blocks.Add(paragraph)
            m_RichText.Content.Sections.Add(section)
            m_RichText.Content.Layout = ENTextLayout.Web
            AddHandler m_RichText.Selection.SelectionChanged, AddressOf Selection_SelectionChanged
            Return m_RichText
        End Function

        Private Sub Selection_SelectionChanged(ByVal arg As NEventArgs)
            ClearHighlights()

            ' highlight selected blocks
            Dim selectedBlocks As NList(Of NBlock) = m_RichText.Selection.GetSelectedBlocks()

            For i = 0 To selectedBlocks.Count - 1
                selectedBlocks(i).BackgroundFill = New NColorFill(NColor.LightBlue)
            Next

            Dim selectedInlines = m_RichText.Selection.GetSelectedInlines(False)

            For i = 0 To selectedInlines.Count - 1
                selectedInlines(i).HighlightFill = New NColorFill(NColor.FromColor(NColor.Yellow, 125))
            Next
        End Sub

        Protected Overrides Function CreateExampleControls() As NWidget
            Return Nothing
        End Function

        Protected Overrides Function GetExampleDescription() As String
            Return "<p>The example demonstrates how to track the selection changed event as well as how to query the selection object.</p>"
        End Function

#End Region

#Region "Implementation"

        Private Sub ClearHighlights()
            Dim blocks = m_RichText.Document.GetDescendants(NBlock.NBlockSchema)

            For i = 0 To blocks.Count - 1
                CType(blocks(i), NBlock).BackgroundFill = Nothing
            Next

            Dim inlines = m_RichText.Document.GetDescendants(NInline.NInlineSchema)

            For i = 0 To inlines.Count - 1
                CType(inlines(i), NInline).HighlightFill = Nothing
            Next
        End Sub

#End Region

#Region "Fields"

        Private m_RichText As NRichTextView

#End Region

#Region "Schema"

        Public Shared ReadOnly NSelectionChangedExampleSchema As NSchema

#End Region
    End Class
End Namespace

Imports Nevron.Nov.Dom
Imports Nevron.Nov.Graphics
Imports Nevron.Nov.Text
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.Text
    ''' <summary>
    ''' The example demonstrates how to programmatically create paragraphs with different inline formatting.
    ''' </summary>
    Public Class NFindAndReplaceExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' 
        ''' </summary>
        Public Sub New()
        End Sub
        ''' <summary>
        ''' 
        ''' </summary>
        Shared Sub New()
            NFindAndReplaceExampleSchema = NSchema.Create(GetType(NFindAndReplaceExample), NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            ' Create the rich text
            Dim richTextWithRibbon As NRichTextViewWithRibbon = New NRichTextViewWithRibbon()
            m_RichText = richTextWithRibbon.View
            m_RichText.AcceptsTab = True
            m_RichText.Content.Sections.Clear()

            ' Populate the rich text
            PopulateRichText()
            Return richTextWithRibbon
        End Function

        Protected Overrides Function CreateExampleControls() As NWidget
            Dim stack As NStackPanel = New NStackPanel()
            m_FindTextBox = New NTextBox()
            m_FindTextBox.Text = "princess"
            stack.Add(New NPairBox(New NLabel("Find:"), m_FindTextBox, ENPairBoxRelation.Box1AboveBox2))
            m_ReplaceTextBox = New NTextBox()
            m_ReplaceTextBox.Text = "queen"
            stack.Add(New NPairBox(New NLabel("Replace:"), m_ReplaceTextBox, ENPairBoxRelation.Box1AboveBox2))
            Dim findAllButton As NButton = New NButton("Find All")
            AddHandler findAllButton.Click, New [Function](Of NEventArgs)(AddressOf OnFindAllButtonClick)
            stack.Add(findAllButton)
            Dim replaceAllButton As NButton = New NButton("Replace All")
            AddHandler replaceAllButton.Click, New [Function](Of NEventArgs)(AddressOf OnReplaceAllButtonClick)
            stack.Add(replaceAllButton)
            Dim clearHighlightButton As NButton = New NButton("Clear Highlight")
            AddHandler clearHighlightButton.Click, New [Function](Of NEventArgs)(AddressOf OnClearHighlightButtonClick)
            stack.Add(clearHighlightButton)
            Return stack
        End Function

        Protected Overrides Function GetExampleDescription() As String
            Return "
<p>This example demonstrates how to find and replace text.</p>
<p>Press the ""Find All"" button to highlight all occurrences of ""Find"".</p>
<p>Press the ""Replace All"" button to replace and highlight all occurrences of ""Find"" with ""Replace""</p>
<p>Press the ""Clear Highlight"" button to clear all highlighting</p>
"
        End Function

        Private Sub PopulateRichText()
            Dim section As NSection = New NSection()
            m_RichText.Content.Sections.Add(section)
            section.Blocks.Add(GetDescriptionBlock("Find and Replace Text", "The example demonstrates how to work find and replace text.", 1))

            For i = 0 To 10 - 1
                section.Blocks.Add(New NParagraph("Now it so happened that on one occasion the princess's golden ball did not fall into the little hand which she was holding up for it, but on to the ground beyond, and rolled straight into the water.  She followed it with her eyes, but it vanished, and the well was deep, so deep that the bottom could not be seen.  At this she began to cry, and cried louder and louder, and could not be comforted.  And as she thus lamented someone said to her, ""What ails you?  You weep so that even a stone would show pity."""))
            Next
        End Sub

#End Region

#Region "Event Handlers"

        ''' <summary>
        ''' Called when the user presses the find all button
        ''' </summary>
        ''' <paramname="arg"></param>
        Private Sub OnFindAllButtonClick(ByVal arg As NEventArgs)
            ' init find settings
            Dim settings As NFindSettings = New NFindSettings()
            settings.FindWhat = m_FindTextBox.Text
            settings.SearchDirection = ENSearchDirection.Forward

            ' loop through all occurances
            Dim textRange = NRangeI.Zero

            While m_RichText.EditingRoot.FindNext(settings, textRange)
                m_RichText.Selection.SelectRange(textRange)
                m_RichText.Selection.SetHighlightFillToSelectedInlines(New NColorFill(ENNamedColor.Red))
            End While

            ' move caret to beginning of document
            m_RichText.Selection.MoveCaret(ENCaretMoveDirection.DocumentBegin, False)
        End Sub
        ''' <summary>
        ''' Called when the user presses the replace all button
        ''' </summary>
        ''' <paramname="arg"></param>
        Private Sub OnReplaceAllButtonClick(ByVal arg As NEventArgs)
            ' init find settings
            Dim settings As NFindSettings = New NFindSettings()
            settings.FindWhat = m_FindTextBox.Text
            settings.SearchDirection = ENSearchDirection.Forward

            ' find all occurances 
            Dim textRange = NRangeI.Zero
            Dim selection = m_RichText.EditingRoot.Selection

            While m_RichText.EditingRoot.FindNext(settings, textRange)
                ' replace dog with cat
                selection.SelectRange(textRange)
                selection.InsertText(m_ReplaceTextBox.Text)

                If m_ReplaceTextBox.Text.Length > 0 Then
                    selection.SelectRange(New NRangeI(textRange.Begin, textRange.Begin + m_ReplaceTextBox.Text.Length - 1))
                    selection.SetHighlightFillToSelectedInlines(New NColorFill(ENNamedColor.LimeGreen))
                End If
            End While

            ' move caret to beginning of document
            selection.MoveCaret(ENCaretMoveDirection.DocumentBegin, False)
        End Sub
        ''' <summary>
        ''' Called when the user presses clear highlight button
        ''' </summary>
        ''' <paramname="arg"></param>
        Private Sub OnClearHighlightButtonClick(ByVal arg As NEventArgs)
            CType(m_RichText.EditingRoot, NBlock).VisitRanges(Sub(ByVal range)
                                                                  Dim inline As NInline = TryCast(range, NInline)

                                                                  If inline IsNot Nothing Then
                                                                      inline.ClearLocalValue(NTextElement.HighlightFillProperty)
                                                                  End If
                                                              End Sub)
        End Sub

#End Region

#Region "Fields"

        Private m_RichText As NRichTextView
        Private m_FindTextBox As NTextBox
        Private m_ReplaceTextBox As NTextBox

#End Region

#Region "Schema"

        Public Shared ReadOnly NFindAndReplaceExampleSchema As NSchema

#End Region

#Region "Static Methods"

        Private Shared Function GetDescriptionParagraph(ByVal text As String) As NParagraph
            Return New NParagraph(text)
        End Function

        Private Shared Function GetTitleParagraphNoBorder(ByVal text As String, ByVal level As Integer) As NParagraph
            Dim fontSize As Double = 10
            Dim fontStyle = ENFontStyle.Regular

            Select Case level
                Case 1
                    fontSize = 16
                    fontStyle = ENFontStyle.Bold
                Case 2
                    fontSize = 10
                    fontStyle = ENFontStyle.Bold
            End Select

            Dim paragraph As NParagraph = New NParagraph()
            paragraph.HorizontalAlignment = ENAlign.Left
            paragraph.FontSize = fontSize
            paragraph.FontStyle = fontStyle
            Dim textInline As NTextInline = New NTextInline(text)
            textInline.FontStyle = fontStyle
            textInline.FontSize = fontSize
            paragraph.Inlines.Add(textInline)
            Return paragraph
        End Function

        Private Shared Function GetDescriptionBlock(ByVal title As String, ByVal description As String, ByVal level As Integer) As NGroupBlock
            Dim color = NColor.Black
            Dim paragraph = GetTitleParagraphNoBorder(title, level)
            Dim groupBlock As NGroupBlock = New NGroupBlock()
            groupBlock.ClearMode = ENClearMode.All
            groupBlock.Blocks.Add(paragraph)
            groupBlock.Blocks.Add(GetDescriptionParagraph(description))
            groupBlock.Border = CreateLeftTagBorder(color)
            groupBlock.BorderThickness = defaultBorderThickness
            Return groupBlock
        End Function
        ''' <summary>
        ''' Creates a left tag border with the specified border
        ''' </summary>
        ''' <paramname="color"></param>
        ''' <returns></returns>
        Private Shared Function CreateLeftTagBorder(ByVal color As NColor) As NBorder
            Dim border As NBorder = New NBorder()
            border.LeftSide = New NBorderSide()
            border.LeftSide.Fill = New NColorFill(color)
            Return border
        End Function

#End Region

#Region "Constants"

        Private Shared ReadOnly defaultBorderThickness As NMargins = New NMargins(5.0, 0.0, 0.0, 0.0)

#End Region
    End Class
End Namespace

Imports Nevron.Nov.Dom
Imports Nevron.Nov.Text
Imports Nevron.Nov.Text.Formats
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.Text
    Public Class NPdfExportExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' Default constructor.
        ''' </summary>
        Public Sub New()
        End Sub

        ''' <summary>
        ''' Static constructor.
        ''' </summary>
        Shared Sub New()
            NPdfExportExampleSchema = NSchema.Create(GetType(NPdfExportExample), NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            ' Create the rich text
            Dim richTextWithRibbon As NRichTextViewWithRibbon = New NRichTextViewWithRibbon()
            m_RichText = richTextWithRibbon.View
            m_RichText.AcceptsTab = True
            m_RichText.Content.Sections.Clear()

            ' Populate the rich text
            PopulateRichText()
            Return richTextWithRibbon
        End Function

        Protected Overrides Function CreateExampleControls() As NWidget
            Dim stack As NStackPanel = New NStackPanel()
            Dim exportToPdfButton As NButton = New NButton("Export to PDF...")
            AddHandler exportToPdfButton.Click, AddressOf OnExportToPdfButtonClick
            stack.Add(exportToPdfButton)
            Return stack
        End Function

        Protected Overrides Function GetExampleDescription() As String
            Return "
<p>
	This example demonstrates how to export a Nevron Rich Text document to PDF.
</p>
"
        End Function

        Private Sub PopulateRichText()
            ' Load a document from resource
            m_RichText.LoadFromResource(NResources.RBIN_DOCX_ComplexDocument_docx)
        End Sub

#End Region

#Region "Event Handlers"

        Private Sub OnExportToPdfButtonClick(ByVal arg As NEventArgs)
            Dim pdfFormat As NPdfTextFormat = New NPdfTextFormat()

            ' Create and show a save file dialog
            Dim saveDialog As NSaveFileDialog = New NSaveFileDialog()
            saveDialog.Title = "Export to PDF"
            saveDialog.DefaultFileName = "Document1.pdf"
            saveDialog.FileTypes = New NFileDialogFileType() {New NFileDialogFileType(pdfFormat)}
            AddHandler saveDialog.Closed, AddressOf OnSaveDialogClosed
            saveDialog.RequestShow()
        End Sub

        Private Sub OnSaveDialogClosed(ByVal arg As NSaveFileDialogResult)
            If arg.Result = ENCommonDialogResult.OK Then
                m_RichText.SaveToFile(arg.File)
            End If
        End Sub

#End Region

#Region "Fields"

        Private m_RichText As NRichTextView

#End Region

#Region "Schema"

        ''' <summary>
        ''' Schema associated with NPdfExportExample.
        ''' </summary>
        Public Shared ReadOnly NPdfExportExampleSchema As NSchema

#End Region
    End Class
End Namespace

Imports Nevron.Nov.Dom
Imports Nevron.Nov.Text
Imports Nevron.Nov.Text.Formats
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.Text
    Public Class NEpubExportExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' Default constructor.
        ''' </summary>
        Public Sub New()
        End Sub

        ''' <summary>
        ''' Static constructor.
        ''' </summary>
        Shared Sub New()
            NEpubExportExampleSchema = NSchema.Create(GetType(NEpubExportExample), NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            ' Create the rich text
            Dim richTextWithRibbon As NRichTextViewWithRibbon = New NRichTextViewWithRibbon()
            m_RichText = richTextWithRibbon.View
            m_RichText.AcceptsTab = True
            m_RichText.Content.Sections.Clear()

            ' Populate the rich text
            PopulateRichText()

            Return richTextWithRibbon
        End Function
        Protected Overrides Function CreateExampleControls() As NWidget
            Dim stack As NStackPanel = New NStackPanel()

            Dim exportToEpubButton As NButton = New NButton("Export to EPUB...")
            exportToEpubButton.Click += AddressOf OnExportToEpubButtonClick
            stack.Add(exportToEpubButton)

            Return stack
        End Function
        Protected Overrides Function GetExampleDescription() As String
            Return "
<p>
	This example demonstrates how to import Electronic Publications (EPUB files) in Nevron Rich Text Editor.
</p>
" End Function

        Private Sub PopulateRichText()
            Dim documentBlock = m_RichText.Content
            Dim heading1Style = documentBlock.Styles.FindStyleByTypeAndId(ENRichTextStyleType.Paragraph, "Heading1")

            ' Add chapter 1
            Dim section As NSection = New NSection()
            documentBlock.Sections.Add(section)

            Dim paragraph As NParagraph = New NParagraph("Chapter 1: EPUB Import")
            section.Blocks.Add(paragraph)
            heading1Style.Apply(paragraph)

            paragraph = New NParagraph("NOV Rich Text Editor lets you import Electronic Publications. " & "Thus you can use it to read e-books on your PC or MAC.")
            section.Blocks.Add(paragraph)

            paragraph = New NParagraph("You can also use it to import and edit existing Electronic Publications and books.")
            section.Blocks.Add(paragraph)

            ' Add chapter 2
            section = New NSection()
            section.BreakType = ENSectionBreakType.NextPage
            documentBlock.Sections.Add(section)

            paragraph = New NParagraph("Chapter 2: EPUB Export")
            section.Blocks.Add(paragraph)
            heading1Style.Apply(paragraph)

            paragraph = New NParagraph("NOV Rich Text Editor lets you export a rich text document to an Electronic Publication. " & "Thus you can use it to create e-books on your PC or MAC.")
            section.Blocks.Add(paragraph)

            paragraph = New NParagraph("You can also use it to import and edit existing Electronic Publications and books.")
            section.Blocks.Add(paragraph)
        End Sub

#End Region

#Region "Event Handlers"

        Private Sub OnExportToEpubButtonClick(ByVal arg As NEventArgs)
            ' Create and show a save file dialog
            Dim saveDialog As NSaveFileDialog = New NSaveFileDialog()
            saveDialog.Title = "Export to EPUB"
            saveDialog.DefaultFileName = "MyBook.epub"
            saveDialog.FileTypes = New NFileDialogFileType() {New NFileDialogFileType(NTextFormat.Epub)}

            saveDialog.Closed += AddressOf OnSaveDialogClosed
            saveDialog.RequestShow()
        End Sub
        Private Sub OnSaveDialogClosed(ByVal arg As NSaveFileDialogResult)
            If arg.Result Is ENCommonDialogResult.OK Then
                m_RichText.SaveToFileAsync(arg.File)
            End If
        End Sub

#End Region

#Region "Fields"

        Private m_RichText As NRichTextView

#End Region

#Region "Schema"

        ''' <summary>
        ''' Schema associated with NEpubExportExample.
        ''' </summary>
        Public Shared ReadOnly NEpubExportExampleSchema As NSchema

#End Region
    End Class
End Namespace

Imports System
Imports System.IO
Imports Nevron.Nov.Dom
Imports Nevron.Nov.Layout
Imports Nevron.Nov.Text
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.Text
    Public Class NDocxImportExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' Default constructor.
        ''' </summary>
        Public Sub New()
        End Sub

        ''' <summary>
        ''' Static constructor.
        ''' </summary>
        Shared Sub New()
            NDocxImportExampleSchema = NSchema.Create(GetType(NDocxImportExample), NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            ' Create the rich text
            Dim richTextWithRibbon As NRichTextViewWithRibbon = New NRichTextViewWithRibbon()
            m_RichText = richTextWithRibbon.View
            m_RichText.AcceptsTab = True
            m_RichText.Content.Sections.Clear()
            Return richTextWithRibbon
        End Function

        Protected Overrides Function CreateExampleControls() As NWidget
            Dim predefinedDocumentGroupBox As NGroupBox = CreatePredefinedDocumentGroupBox()
            predefinedDocumentGroupBox.VerticalPlacement = ENVerticalPlacement.Top
            Return predefinedDocumentGroupBox
        End Function

        Protected Overrides Function GetExampleDescription() As String
            Return "<p>The example demonstrates the DOCX import capabilities of Nevron Text control.</p>"
        End Function

#End Region

#Region "Implementation"

        Private Function CreatePredefinedDocumentGroupBox() As NGroupBox
            Const DocxSuffix = "_docx"
            Dim testListBox As NListBox = New NListBox()
            Dim resourceName As String() = NResources.Instance.GetResourceNames()
            Dim i = 0, count = resourceName.Length

            While i < count
                Dim resName = resourceName(i)

                If resName.EndsWith(DocxSuffix, StringComparison.Ordinal) Then
                    ' The current resource is a DOCX document, so add it to the list box
                    Dim testName = resName.Substring(0, resName.Length - DocxSuffix.Length)
                    testName = testName.Substring(testName.LastIndexOf("_"c) + 1)
                    Dim item As NListBoxItem = New NListBoxItem(NStringHelpers.InsertSpacesBeforeUppersAndDigits(testName))
                    item.Tag = resName
                    testListBox.Items.Add(item)
                End If

                i += 1
            End While

            AddHandler testListBox.Selection.Selected, AddressOf OnListBoxItemSelected
            testListBox.Selection.SingleSelect(testListBox.Items(1))
            Return New NGroupBox("Predefined DOCX documents", testListBox)
        End Function

#End Region

#Region "Event Handlers"

        Private Sub OnListBoxItemSelected(ByVal arg1 As NSelectEventArgs(Of NListBoxItem))
            If arg1.TargetNode Is Nothing Then Return

            ' Determine the full name of the selected resource
            Dim resName = CStr(arg1.Item.Tag)

            ' Read the stream
            Using stream = NResources.Instance.GetResourceStream(resName)
                m_RichText.LoadFromStream(stream)
            End Using
        End Sub

#End Region

#Region "Fields"

        Private m_RichText As NRichTextView

#End Region

#Region "Schema"

        ''' <summary>
        ''' Schema associated with NDocxImportExample.
        ''' </summary>
        Public Shared ReadOnly NDocxImportExampleSchema As NSchema

#End Region
    End Class
End Namespace

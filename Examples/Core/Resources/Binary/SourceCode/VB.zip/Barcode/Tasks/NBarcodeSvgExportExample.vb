Imports System
Imports System.IO
Imports Nevron.Nov.Barcode
Imports Nevron.Nov.Dom
Imports Nevron.Nov.Editors
Imports Nevron.Nov.Layout
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.Barcode
    Public Class NBarcodeSvgExportExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' Default constructor.
        ''' </summary>
        Public Sub New()
        End Sub

        ''' <summary>
        ''' Static constructor.
        ''' </summary>
        Shared Sub New()
            NBarcodeSvgExportExampleSchema = NSchema.Create(GetType(NBarcodeSvgExportExample), NExampleBase.NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            m_Barcode = New NMatrixBarcode(ENMatrixBarcodeSymbology.QrCode, "Nevron Software" & Environment.NewLine & Environment.NewLine & "https://www.nevron.com")
            m_Barcode.HorizontalPlacement = ENHorizontalPlacement.Center
            m_Barcode.VerticalPlacement = ENVerticalPlacement.Center
            Return m_Barcode
        End Function

        Protected Overrides Function CreateExampleControls() As NWidget
            Dim stack As NStackPanel = New NStackPanel()

            ' Create the property editors
            Dim editors = NDesigner.GetDesigner(m_Barcode).CreatePropertyEditors(m_Barcode, NBoxElement.BackgroundFillProperty, NBoxElement.TextFillProperty, NMatrixBarcode.ErrorCorrectionProperty, NBarcode.SizeModeProperty, NBarcode.ScaleProperty, NBarcode.TextProperty)
            Dim i = 0, count = editors.Count

            While i < count
                stack.Add(editors(i))
                i += 1
            End While

            Dim exportToSvgButton As NButton = New NButton("Export to SVG...")
            AddHandler exportToSvgButton.Click, AddressOf OnExportToSvgButtonClick
            stack.Add(exportToSvgButton)
            Return New NUniSizeBoxGroup(stack)
        End Function

        Protected Overrides Function GetExampleDescription() As String
            Return "
<p>
	This example demonstrates how to export barcodes to SVG. Enter some text in the text box on the right
	and click the <b>Export to SVG...</b> button.
</p>
"
        End Function

#End Region

#Region "Event Handlers"

        Private Sub OnExportToSvgButtonClick(ByVal arg As NEventArgs)
            Dim exportToSvgDialog As NSaveFileDialog = New NSaveFileDialog()
            exportToSvgDialog.FileTypes = New NFileDialogFileType() {New NFileDialogFileType("SVG Files", "svg")}
            AddHandler exportToSvgDialog.Closed, AddressOf OnExportToSvgDialogClosed
            exportToSvgDialog.RequestShow()
        End Sub

        Private Sub OnExportToSvgDialogClosed(ByVal arg As NSaveFileDialogResult)
            If arg.Result <> ENCommonDialogResult.OK Then Return

            ' Generate an SVG document from the barcode
            Dim svgExporter As NContinuousMediaDocument(Of NBarcode) = New NContinuousMediaDocument(Of NBarcode)(m_Barcode)
            Dim svgDocument = svgExporter.CreateSvg(m_Barcode, 0)

            ' Save the SVG document to a file
            arg.File.Create().Then(Sub(ByVal stream As Stream)
                                       Using stream
                                           svgDocument.SaveToStream(stream)
                                       End Using
                                   End Sub)
        End Sub

#End Region

#Region "Fields"

        Private m_Barcode As NBarcode

#End Region

#Region "Schema"

        ''' <summary>
        ''' Schema associated with NBarcodeSvgExportExample.
        ''' </summary>
        Public Shared ReadOnly NBarcodeSvgExportExampleSchema As NSchema

#End Region
    End Class
End Namespace

Imports System
Imports Nevron.Nov.Dom
Imports Nevron.Nov.Schedule
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.Schedule
    Public Class NRecurrenceStressTestExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' Default constructor.
        ''' </summary>
        Public Sub New()
        End Sub

        ''' <summary>
        ''' Static constructor.
        ''' </summary>
        Shared Sub New()
            NRecurrenceStressTestExampleSchema = NSchema.Create(GetType(NRecurrenceStressTestExample), NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            ' Create a simple schedule
            Dim scheduleViewWithRibbon As NScheduleViewWithRibbon = New NScheduleViewWithRibbon()
            m_ScheduleView = scheduleViewWithRibbon.View
            m_ScheduleView.Document.PauseHistoryService()

            Try
                InitSchedule(m_ScheduleView.Content)
            Finally
                m_ScheduleView.Document.ResumeHistoryService()
            End Try

            ' Return the commanding widget
            Return scheduleViewWithRibbon
        End Function

        Protected Overrides Function CreateExampleControls() As NWidget
            Return Nothing
        End Function

        Protected Overrides Function GetExampleDescription() As String
            Return "
<p>
    This example demonstrates how NOV Schedule deals with a large number of occurrences of recurring appointments.
</p>
"
        End Function

#End Region

#Region "Implementation"

        Private Sub InitSchedule(ByVal schedule As NSchedule)
            Dim today = Date.Today
            Dim startDate As Date = New DateTime(today.Year, 1, 1)

            ' Create an appointment which occurs per 3 hours
            Dim appointment As NAppointment = New NAppointment("Meeting", today, today.AddHours(2))
            Dim rule As NRecurrenceHourlyRule = New NRecurrenceHourlyRule()
            rule.StartDate = startDate
            rule.Interval = 3
            appointment.RecurrenceRule = rule
            schedule.Appointments.Add(appointment)

            ' Create an appointment which occurs every hour and categorize it
            appointment = New NAppointment("Talking", today, today.AddHours(0.5))
            rule = New NRecurrenceHourlyRule()
            rule.StartDate = startDate
            rule.Interval = 1
            appointment.RecurrenceRule = rule
            appointment.Category = "Red"
            schedule.Appointments.Add(appointment)

            ' Swicth schedule to week view mode
            schedule.ViewMode = ENScheduleViewMode.Week
        End Sub

#End Region

#Region "Fields"

        Private m_ScheduleView As NScheduleView

#End Region

#Region "Schema"

        ''' <summary>
        ''' Schema associated with NRecurrenceStressTestExample.
        ''' </summary>
        Public Shared ReadOnly NRecurrenceStressTestExampleSchema As NSchema

#End Region
    End Class
End Namespace

Imports System
Imports Nevron.Nov.Dom
Imports Nevron.Nov.Schedule
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.Schedule
    Public Class NNotificationsExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' Default constructor.
        ''' </summary>
        Public Sub New()
        End Sub

        ''' <summary>
        ''' Static constructor.
        ''' </summary>
        Shared Sub New()
            NNotificationsExampleSchema = NSchema.Create(GetType(NNotificationsExample), NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            ' Create a simple schedule
            Dim scheduleViewWithRibbon As NScheduleViewWithRibbon = New NScheduleViewWithRibbon()
            m_ScheduleView = scheduleViewWithRibbon.View
            m_ScheduleView.Document.PauseHistoryService()

            Try
                InitSchedule(m_ScheduleView.Content)
            Finally
                m_ScheduleView.Document.ResumeHistoryService()
            End Try

            ' Return the commanding widget
            Return scheduleViewWithRibbon
        End Function

        Protected Overrides Function CreateExampleControls() As NWidget
            Return Nothing
        End Function

        Protected Overrides Function GetExampleDescription() As String
            Return "
<p>
    This example demonstrates how to assign notifications to appointments and how to configure NOV Schedule to
	show notification messages.
</p>
"
        End Function

#End Region

#Region "Implementation"

        Private Sub InitSchedule(ByVal schedule As NSchedule)
            schedule.ViewMode = ENScheduleViewMode.Day

            ' Create an old appointment
            Dim oldStart = Date.Now.AddHours(-3)
            Dim oldAppointment As NAppointment = New NAppointment("Old Meeting", oldStart, oldStart.AddHours(2))
            oldAppointment.Notification = TimeSpan.Zero
            schedule.Appointments.Add(oldAppointment)

            ' Create an appointment and assign a notification 10 minutes before its start
            Dim newStart = Date.Now.AddMinutes(10)
            Dim newAppointment As NAppointment = New NAppointment("New Meeting", newStart, newStart.AddHours(2))
            newAppointment.Notification = TimeSpan.FromMinutes(10)
            schedule.Appointments.Add(newAppointment)

            ' Scroll the schedule to the current hour
            schedule.ScrollToTime(TimeSpan.FromHours(Math.Floor(CDbl(oldStart.Hour))))

            ' Configure the schedule view to check for pending notifications every 60 seconds
            m_ScheduleView.NotificationCheckInterval = 60
        End Sub

#End Region

#Region "Fields"

        Private m_ScheduleView As NScheduleView

#End Region

#Region "Schema"

        ''' <summary>
        ''' Schema associated with NNotificationsExample.
        ''' </summary>
        Public Shared ReadOnly NNotificationsExampleSchema As NSchema

#End Region
    End Class
End Namespace

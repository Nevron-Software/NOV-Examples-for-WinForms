Imports Nevron.Nov.Dom
Imports Nevron.Nov.Editors
Imports Nevron.Nov.Schedule
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.Schedule
    Public Class NToolsExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' Default constructor.
        ''' </summary>
        Public Sub New()
        End Sub

        ''' <summary>
        ''' Static constructor.
        ''' </summary>
        Shared Sub New()
            NToolsExampleSchema = NSchema.Create(GetType(NToolsExample), NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            ' Create a simple schedule
            Dim scheduleViewWithRibbon As NScheduleViewWithRibbon = New NScheduleViewWithRibbon()
            m_ScheduleView = scheduleViewWithRibbon.View
            m_ScheduleView.Document.PauseHistoryService()

            Try
                InitSchedule(m_ScheduleView.Content)
            Finally
                m_ScheduleView.Document.ResumeHistoryService()
            End Try

            ' Return the commanding widget
            Return scheduleViewWithRibbon
        End Function

        Protected Overrides Function CreateExampleControls() As NWidget
            Dim stack As NStackPanel = New NStackPanel()

            ' Add a check box for each tool of the schedule view
            Dim toolsStack As NStackPanel = New NStackPanel()

            For i = 0 To m_ScheduleView.Interactor.Count - 1
                Dim tool = m_ScheduleView.Interactor(i)
                Dim checkBox As NCheckBox = New NCheckBox(tool.ToString(), tool.Enabled)
                checkBox.Tag = tool
                AddHandler checkBox.CheckedChanged, AddressOf OnCheckBoxCheckedChanged
                toolsStack.Add(checkBox)
            Next

            stack.Add(New NGroupBox("Tools", toolsStack))

            ' Add a setting for the mouse button event of the Click Select tool
            Dim clickSelectStack As NStackPanel = New NStackPanel()
            Dim clickSelectTool = CType(m_ScheduleView.Interactor.GetTool(NScheduleClickSelectTool.NScheduleClickSelectToolSchema), NScheduleClickSelectTool)
            clickSelectStack.Add(NDesigner.GetDesigner(clickSelectTool).CreatePropertyEditor(clickSelectTool, NScheduleClickTool.MouseButtonEventProperty))
            stack.Add(New NGroupBox("Click Select Tool", clickSelectStack))
            Return stack
        End Function

        Protected Overrides Function GetExampleDescription() As String
            Return "
<p>
    This example demonstrates how to configure, enable and disable schedule view tools.
	Use the widgets on the right to control the tools of the schedule view.
</p>
"
        End Function

#End Region

#Region "Implementation"

        Private Sub InitSchedule(ByVal schedule As NSchedule)
            Dim today = Date.Today
            schedule.ViewMode = ENScheduleViewMode.Day
            schedule.Appointments.Add(New NAppointment("Travel to Work", today.AddHours(6.5), today.AddHours(7.5)))
            schedule.Appointments.Add(New NAppointment("Meeting with John", today.AddHours(8), today.AddHours(10)))
            schedule.Appointments.Add(New NAppointment("Conference", today.AddHours(10.5), today.AddHours(11.5)))
            schedule.Appointments.Add(New NAppointment("Lunch", today.AddHours(12), today.AddHours(14)))
            schedule.Appointments.Add(New NAppointment("News Reading", today.AddHours(12.5), today.AddHours(13.5)))
            schedule.Appointments.Add(New NAppointment("Video Presentation", today.AddHours(14.5), today.AddHours(15.5)))
            schedule.Appointments.Add(New NAppointment("Web Meeting", today.AddHours(16), today.AddHours(17)))
            schedule.Appointments.Add(New NAppointment("Travel back home", today.AddHours(17.5), today.AddHours(19)))
            schedule.Appointments.Add(New NAppointment("Family Dinner", today.AddHours(20), today.AddHours(21)))
        End Sub

#End Region

#Region "Event Handlers"

        Private Sub OnCheckBoxCheckedChanged(ByVal arg As NValueChangeEventArgs)
            ' Enable/Disable the tool based on the new value of the check box's Check property
            Dim tool = CType(arg.CurrentTargetNode.Tag, NTool)
            tool.Enabled = CBool(arg.NewValue)
        End Sub

#End Region

#Region "Fields"

        Private m_ScheduleView As NScheduleView

#End Region

#Region "Schema"

        ''' <summary>
        ''' Schema associated with NToolsExample.
        ''' </summary>
        Public Shared ReadOnly NToolsExampleSchema As NSchema

#End Region
    End Class
End Namespace

Imports System

Imports Nevron.Nov.Dom
Imports Nevron.Nov.Schedule
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.Schedule
    Public Class NOccurrencesModificationExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' Default constructor.
        ''' </summary>
        Public Sub New()
        End Sub

        ''' <summary>
        ''' Static constructor.
        ''' </summary>
        Shared Sub New()
            NOccurrencesModificationExampleSchema = NSchema.Create(GetType(NOccurrencesModificationExample), NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            ' Create a simple schedule
            Dim scheduleViewWithRibbon As NScheduleViewWithRibbon = New NScheduleViewWithRibbon()
            m_ScheduleView = scheduleViewWithRibbon.View

            m_ScheduleView.Document.PauseHistoryService()
            Try
                InitSchedule(m_ScheduleView.Content)
            Finally
                m_ScheduleView.Document.ResumeHistoryService()
            End Try

            ' Return the commanding widget
            Return scheduleViewWithRibbon
        End Function
        Protected Overrides Function CreateExampleControls() As NWidget
            Return Nothing
        End Function
        Protected Overrides Function GetExampleDescription() As String
            Return "
<p>
    This example demonstrates how to create recurring appointments, i.e. appointments, which occur multiple
	times. Recurring appointments are created in the same way as ordinary appointments with the only difference
	that they have a recurrence rule assigned to their <b>RecurrenceRule</b> property and can be easily
	recognized by the circular arrows symbol at their top left corner.
</p>
<p>
	This examples also shows how to change the properties or delete an occurrence of a recurring appointment.
	By default occurrences of recurring appointments inherit the property values of the recurring appointment,
	but you can easily change any of these properties for a specific occurrence. All changes to such occurrences
	are remembered, so even if you move to the previous or the next range of the schedule, when you get back
	to the current range, you'll be able to see all these changes again.
</p>
" End Function

#End Region

#Region "Implementation"

        Private Sub InitSchedule(ByVal schedule As NSchedule)
            Dim today = Date.Today

            ' Create a recurring appointment, which occurs every day
            Dim appointment As NAppointment = New NAppointment("Appointment", today.AddHours(12), today.AddHours(14))
            Dim rule As NRecurrenceDailyRule = New NRecurrenceDailyRule()
            rule.StartDate = New DateTime(2015, 1, 1)
            appointment.RecurrenceRule = rule

            ' Add the recurring appointment to the schedule
            schedule.Appointments.Add(appointment)

            ' Change the time of the first appointment in the current week
            Dim appChild = appointment.Occurrences(0)
            appChild.Start = appChild.Start.AddHours(-2)
            appChild.End = appChild.End.AddHours(-2)

            ' Change the subject of the second appointment
            appChild = appointment.Occurrences(1)
            appChild.Subject = "Custom Subject"

            ' Change the category of the third appointment
            appChild = appointment.Occurrences(2)
            appChild.Category = "Red"

            ' Delete the fourth appointment
            appointment.Occurrences.RemoveAt(3)
        End Sub

#End Region

#Region "Fields"

        Private m_ScheduleView As NScheduleView

#End Region

#Region "Schema"

        ''' <summary>
        ''' Schema associated with NOccurrencesModificationExample.
        ''' </summary>
        Public Shared ReadOnly NOccurrencesModificationExampleSchema As NSchema

#End Region
    End Class
End Namespace

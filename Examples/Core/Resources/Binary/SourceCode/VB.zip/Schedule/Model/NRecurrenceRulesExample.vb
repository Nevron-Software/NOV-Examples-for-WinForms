Imports System

Imports Nevron.Nov.Dom
Imports Nevron.Nov.Schedule
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.Schedule
    Public Class NRecurrenceRulesExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' Default constructor.
        ''' </summary>
        Public Sub New()
        End Sub

        ''' <summary>
        ''' Static constructor.
        ''' </summary>
        Shared Sub New()
            NRecurrenceRulesExampleSchema = NSchema.Create(GetType(NRecurrenceRulesExample), NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            ' Create a simple schedule
            Dim scheduleViewWithRibbon As NScheduleViewWithRibbon = New NScheduleViewWithRibbon()
            m_ScheduleView = scheduleViewWithRibbon.View

            m_ScheduleView.Document.PauseHistoryService()
            Try
                InitSchedule(m_ScheduleView.Content)
            Finally
                m_ScheduleView.Document.ResumeHistoryService()
            End Try

            ' Return the commanding widget
            Return scheduleViewWithRibbon
        End Function
        Protected Overrides Function CreateExampleControls() As NWidget
            Dim stack As NStackPanel = New NStackPanel()

            stack.Add(New NRadioButton("No recurrence"))
            stack.Add(New NRadioButton("Every 3 hours"))
            stack.Add(New NRadioButton("Every day"))
            stack.Add(New NRadioButton("Every week on Monday and Friday"))
            stack.Add(New NRadioButton("The third day of every other month"))
            stack.Add(New NRadioButton("The last Sunday of every month"))
            stack.Add(New NRadioButton("May 7 and July 7 of every year"))
            stack.Add(New NRadioButton("The first Monday and Tuesday of" & vbLf & "May, June and August"))
            stack.Add(New NRadioButton("Every second day for 1 month from today"))
            stack.Add(New NRadioButton("Every day for 5 occurrences from today"))

            Dim group As NRadioButtonGroup = New NRadioButtonGroup(stack)
            group.SelectedIndex = 2
            group.SelectedIndexChanged += AddressOf OnRadioGroupSelectedIndexChanged
            Return group
        End Function
        Protected Overrides Function GetExampleDescription() As String
            Return "
<p>
    This example demonstrates how to create recurring appointments, i.e. appointments, which occur multiple
	times. Recurring appointments are created in the same way as ordinary appointments with the only difference
	that they have a recurrence rule assigned to their <b>RecurrenceRule</b> property. This recurring rule
	defines when the appointment occurs. Recurring appointments can be easily recognized by the circular arrows
	symbol at their top left corner.
</p>
" End Function

#End Region

#Region "Implementation"

        Private Sub InitSchedule(ByVal schedule As NSchedule)
            Dim today = Date.Today

            Dim appointment As NAppointment = New NAppointment("Appoinment", today.AddHours(12), today.AddHours(14))
            appointment.RecurrenceRule = CreateDailyRule()
            schedule.Appointments.Add(appointment)
        End Sub

        Private Function CreateHourlyRule() As NRecurrenceHourlyRule
            ' Create a rule, which occurs every 3 hours
            Dim rule As NRecurrenceHourlyRule = New NRecurrenceHourlyRule()
            rule.StartDate = RuleStart
            rule.Interval = 3
            Return rule
        End Function
        Private Function CreateDailyRule() As NRecurrenceDailyRule
            ' Create a rule, which occurs every day
            Dim rule As NRecurrenceDailyRule = New NRecurrenceDailyRule()
            rule.StartDate = RuleStart
            Return rule
        End Function
        Private Function CreateWeeklyRule() As NRecurrenceWeeklyRule
            ' Create a rule, which occurs every week on Monday and Friday
            Dim rule As NRecurrenceWeeklyRule = New NRecurrenceWeeklyRule(ENDayOfWeek.Monday Or ENDayOfWeek.Friday)
            rule.StartDate = RuleStart
            Return rule
        End Function
        Private Function CreateAbsoluteMonthlyRule() As NRecurrenceMonthlyRule
            ' Create a rule, which occurs on the third day of every other month
            ' Use negative values for the last days of the month, for example -1 refers to the last day of the month
            Dim rule As NRecurrenceMonthlyRule = New NRecurrenceMonthlyRule(3)
            rule.StartDate = RuleStart
            rule.Interval = 2
            Return rule
        End Function
        Private Function CreateRelativeMonthlyRule() As NRecurrenceMonthlyRule
            ' Create a rule, which occurs on the last Sunday of every month
            Dim rule As NRecurrenceMonthlyRule = New NRecurrenceMonthlyRule(ENDayOrdinal.Last, ENDayOfWeek.Sunday)
            rule.StartDate = RuleStart
            Return rule
        End Function
        Private Function CreateAbsoluteYearlyRule() As NRecurrenceYearlyRule
            ' Create a rule, which occurs on every May 7 and July 7, every year
            Dim rule As NRecurrenceYearlyRule = New NRecurrenceYearlyRule(7, ENMonth.May Or ENMonth.July)
            rule.StartDate = RuleStart
            Return rule
        End Function
        Private Function CreateRelativeYearlyRule() As NRecurrenceYearlyRule
            ' Create a rule, which occurs on the first Monday and Tuesday of May, June and August
            Dim rule As NRecurrenceYearlyRule = New NRecurrenceYearlyRule(ENDayOrdinal.First, ENDayOfWeek.Monday Or ENDayOfWeek.Tuesday, ENMonth.May Or ENMonth.June Or ENMonth.August)
            rule.StartDate = RuleStart
            Return rule
        End Function
        Private Function CreateDailyRuleForOneMonth() As NRecurrenceDailyRule
            Dim rule As NRecurrenceDailyRule = New NRecurrenceDailyRule()
            rule.EndMode = ENRecurrenceEndMode.ByDate
            rule.EndDate = Date.Today.AddMonths(1)
            rule.Interval = 2

            Return rule
        End Function
        Private Function CreateDailyRuleForFiveOccurrences() As NRecurrenceDailyRule
            Dim rule As NRecurrenceDailyRule = New NRecurrenceDailyRule()
            rule.EndMode = ENRecurrenceEndMode.AfterOccurrences
            rule.MaxOccurrences = 5

            Return rule
        End Function

#End Region

#Region "Event Handlers"

        Private Sub OnRadioGroupSelectedIndexChanged(ByVal arg As NValueChangeEventArgs)
            Dim schedule = m_ScheduleView.Content
            Dim appointment = CType(schedule.Appointments(0), NAppointment)

            Dim selectedIndex As Integer = arg.NewValue
            Select Case selectedIndex
                Case 0
                    appointment.RecurrenceRule = Nothing
                    schedule.ViewMode = ENScheduleViewMode.Week
                Case 1
                    appointment.RecurrenceRule = CreateHourlyRule()
                    schedule.ViewMode = ENScheduleViewMode.Week
                Case 2
                    appointment.RecurrenceRule = CreateDailyRule()
                    schedule.ViewMode = ENScheduleViewMode.Week
                Case 3
                    appointment.RecurrenceRule = CreateWeeklyRule()
                    schedule.ViewMode = ENScheduleViewMode.Week
                Case 4
                    appointment.RecurrenceRule = CreateAbsoluteMonthlyRule()
                    schedule.ViewMode = ENScheduleViewMode.Month
                Case 5
                    appointment.RecurrenceRule = CreateRelativeMonthlyRule()
                    schedule.ViewMode = ENScheduleViewMode.Month
                Case 6
                    appointment.RecurrenceRule = CreateAbsoluteYearlyRule()
                    schedule.ViewMode = ENScheduleViewMode.Month
                Case 7
                    appointment.RecurrenceRule = CreateRelativeYearlyRule()
                    schedule.ViewMode = ENScheduleViewMode.Month
                Case 8
                    appointment.RecurrenceRule = CreateDailyRuleForOneMonth()
                    schedule.ViewMode = ENScheduleViewMode.Month
                Case 9
                    appointment.RecurrenceRule = CreateDailyRuleForFiveOccurrences()
                    schedule.ViewMode = ENScheduleViewMode.Month
            End Select
        End Sub

#End Region

#Region "Fields"

        Private m_ScheduleView As NScheduleView

#End Region

#Region "Schema"

        ''' <summary>
        ''' Schema associated with NRecurrenceRulesExample.
        ''' </summary>
        Public Shared ReadOnly NRecurrenceRulesExampleSchema As NSchema

#End Region

#Region "Constants"

        ' The start date of the recurrence rules. By default rules start from the current day (today),
        ' so if you want to change that, you should set their Start property to another date.
        Private Shared ReadOnly RuleStart As Date = New DateTime(2015, 1, 1)

#End Region
    End Class
End Namespace

Imports Nevron.Nov.Dom
Imports Nevron.Nov.Editors
Imports Nevron.Nov.Schedule
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.Schedule
    Public Class NCurrentTimeIndicatorExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' Default constructor.
        ''' </summary>
        Public Sub New()
        End Sub

        ''' <summary>
        ''' Static constructor.
        ''' </summary>
        Shared Sub New()
            NCurrentTimeIndicatorExampleSchema = NSchema.Create(GetType(NCurrentTimeIndicatorExample), NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            ' Create a simple schedule
            Dim scheduleViewWithRibbon As NScheduleViewWithRibbon = New NScheduleViewWithRibbon()
            m_ScheduleView = scheduleViewWithRibbon.View
            m_ScheduleView.Document.PauseHistoryService()

            Try
                InitSchedule(m_ScheduleView.Content)
            Finally
                m_ScheduleView.Document.ResumeHistoryService()
            End Try

            ' Return the commanding widget
            Return scheduleViewWithRibbon
        End Function

        Protected Overrides Function CreateExampleControls() As NWidget
            Dim timeIndicator = m_ScheduleView.Content.CurrentTimeIndicator
            Dim propertyEditors = NDesigner.GetDesigner(timeIndicator).CreatePropertyEditors(timeIndicator, NScheduleTimeIndicator.VisibleProperty, NScheduleTimeIndicator.FillProperty, NScheduleTimeIndicator.ThicknessProperty)
            Dim stack As NStackPanel = New NStackPanel()

            For i = 0 To propertyEditors.Count - 1
                stack.Add(propertyEditors(i))
            Next

            Return New NUniSizeBoxGroup(stack)
        End Function

        Protected Overrides Function GetExampleDescription() As String
            Return "
<p>
    This example demonstrates how to show and configure the current time indicator. This is done via the following properties
	of the schedule's <b>CurrentTimeIndicator</b>:
</p>
<ul>
	<li><b>Visible</b> - determines whether to show the time indicator.</li>
	<li><b>Fill</b> - determines the fill style of the time indicator. For best results, set it to a semi-transparent color fill,
		for example - new NColorFill(new NColor(192, 0, 0, 160)).</li>
	<li><b>Thickness</b> - determines the thickness of the time indicator in DIPs. By default set to 2.</li>
</ul>
"
        End Function

#End Region

#Region "Implementation"

        Private Sub InitSchedule(ByVal schedule As NSchedule)
            Dim today = Date.Today
            schedule.ViewMode = ENScheduleViewMode.Day

            ' Add some appointments
            schedule.Appointments.Add(New NAppointment("Travel to Work", today.AddHours(6.5), today.AddHours(7.5)))
            schedule.Appointments.Add(New NAppointment("Meeting with John", today.AddHours(8), today.AddHours(10)))
            schedule.Appointments.Add(New NAppointment("Conference", today.AddHours(10.5), today.AddHours(11.5)))
            schedule.Appointments.Add(New NAppointment("Lunch", today.AddHours(12), today.AddHours(14)))
            schedule.Appointments.Add(New NAppointment("News Reading", today.AddHours(12.5), today.AddHours(13.5)))
            schedule.Appointments.Add(New NAppointment("Video Presentation", today.AddHours(14.5), today.AddHours(15.5)))
            schedule.Appointments.Add(New NAppointment("Web Meeting", today.AddHours(16), today.AddHours(17)))
            schedule.Appointments.Add(New NAppointment("Travel back home", today.AddHours(17.5), today.AddHours(19)))
            schedule.Appointments.Add(New NAppointment("Family Dinner", today.AddHours(20), today.AddHours(21)))

            ' Show current time indicator
            schedule.CurrentTimeIndicator.Visible = True
        End Sub

#End Region

#Region "Fields"

        Private m_ScheduleView As NScheduleView

#End Region

#Region "Schema"

        ''' <summary>
        ''' Schema associated with NCurrentTimeIndicatorExample.
        ''' </summary>
        Public Shared ReadOnly NCurrentTimeIndicatorExampleSchema As NSchema

#End Region
    End Class
End Namespace

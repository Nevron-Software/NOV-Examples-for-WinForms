Imports Nevron.Nov.Dom
Imports Nevron.Nov.Schedule
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.Schedule
    Public Class NGroupingExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' Default constructor.
        ''' </summary>
        Public Sub New()
        End Sub

        ''' <summary>
        ''' Static constructor.
        ''' </summary>
        Shared Sub New()
            NGroupingExampleSchema = NSchema.Create(GetType(NGroupingExample), NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            ' Create a simple schedule
            Dim scheduleViewWithRibbon As NScheduleViewWithRibbon = New NScheduleViewWithRibbon()
            m_ScheduleView = scheduleViewWithRibbon.View

            m_ScheduleView.Document.PauseHistoryService()
            Try
                InitSchedule(m_ScheduleView.Content)
            Finally
                m_ScheduleView.Document.ResumeHistoryService()
            End Try

            ' Return the commanding widget
            Return scheduleViewWithRibbon
        End Function
        Protected Overrides Function CreateExampleControls() As NWidget
            Dim stack As NStackPanel = New NStackPanel()

            stack.Add(New NRadioButton("Time grouping first"))
            stack.Add(New NRadioButton("Group grouping first"))

            Dim groupingOrderGroup As NRadioButtonGroup = New NRadioButtonGroup(stack)
            groupingOrderGroup.SelectedIndexChanged += AddressOf OnRadioGroupSelectedIndexChanged
            groupingOrderGroup.SelectedIndex = 0

            Return groupingOrderGroup
        End Function
        Protected Overrides Function GetExampleDescription() As String
            Return "
<p>
    This example demonstrates how to create schedule groups, how to associate a group to appointments and
	how to apply grouping to schedule view modes. Each view mode (except for ""Timeline"") has a default
	date related grouping, so you can either add a new grouping or insert it before the default one. This
	will affect the order in which the groupings are applied. Use the radio button on the right to control
	the grouping order.
</p>
" End Function

#End Region

#Region "Implementation"

        Private Sub InitSchedule(ByVal schedule As NSchedule)
            Const ActivityGroup = "Activity"
            Const Work = "Work"
            Const Rest = "Rest"
            Const Travel = "Travel"

            schedule.ViewMode = ENScheduleViewMode.Day

            ' Add a schedule group
            schedule.Groups.Add(New NScheduleGroup(ActivityGroup, New String() {Work, Rest, Travel}))

            ' Add a grouping to each of the view modes
            schedule.DayViewMode.Groupings.Add(New NGroupGrouping(ActivityGroup))
            schedule.WeekViewMode.Groupings.Add(New NGroupGrouping(ActivityGroup))
            schedule.MonthViewMode.Groupings.Add(New NGroupGrouping(ActivityGroup))
            schedule.TimelineViewMode.Groupings.Add(New NGroupGrouping(ActivityGroup))

            ' Create the appointments
            Dim today = Date.Today
            schedule.Appointments.Add(CreateAppointment("Travel to Work", today.AddHours(6.5), today.AddHours(7.5), Travel))
            schedule.Appointments.Add(CreateAppointment("Meeting with John", today.AddHours(8), today.AddHours(10), Work))
            schedule.Appointments.Add(CreateAppointment("Conference", today.AddHours(10.5), today.AddHours(11.5), Work))
            schedule.Appointments.Add(CreateAppointment("Lunch", today.AddHours(12), today.AddHours(14), Rest))
            schedule.Appointments.Add(CreateAppointment("News Reading", today.AddHours(12.5), today.AddHours(13.5), Rest))
            schedule.Appointments.Add(CreateAppointment("Video Presentation", today.AddHours(14.5), today.AddHours(15.5), Work))
            schedule.Appointments.Add(CreateAppointment("Web Meeting", today.AddHours(16), today.AddHours(17), Work))
            schedule.Appointments.Add(CreateAppointment("Travel back home", today.AddHours(17.5), today.AddHours(19), Travel))
            schedule.Appointments.Add(CreateAppointment("Family Dinner", today.AddHours(20), today.AddHours(21), Rest))
        End Sub
        Private Function CreateAppointment(ByVal subject As String, ByVal start As Date, ByVal [end] As Date, ByVal groupItem As String) As NAppointment
            Dim appointment As NAppointment = New NAppointment(subject, start, [end])
            appointment.Groups = New NAppointmentGroupCollection()
            appointment.Groups.Add(New NAppointmentGroup("Activity", groupItem))
            Return appointment
        End Function
        Private Sub SwapGroupings(ByVal viewMode As NViewMode)
            Dim grouping1 = viewMode.Groupings(0)
            Dim grouping2 = viewMode.Groupings(1)

            viewMode.Groupings.Clear()
            viewMode.Groupings.Add(grouping2)
            viewMode.Groupings.Add(grouping1)
        End Sub

#End Region

#Region "Event Handlers"

        Private Sub OnRadioGroupSelectedIndexChanged(ByVal arg As NValueChangeEventArgs)
            Dim selectedIndex As Integer = arg.NewValue
            Dim schedule = m_ScheduleView.Content

            If selectedIndex = 0 Then
                ' Time grouping should be first
                If TypeOf schedule.DayViewMode.Groupings(0) Is NGroupGrouping Then
                    SwapGroupings(schedule.DayViewMode)
                    SwapGroupings(schedule.WeekViewMode)
                    SwapGroupings(schedule.MonthViewMode)
                End If
            Else
                ' Schedule group grouping should be first
                If TypeOf schedule.DayViewMode.Groupings(0) Is NDateRangeGrouping Then
                    SwapGroupings(schedule.DayViewMode)
                    SwapGroupings(schedule.WeekViewMode)
                    SwapGroupings(schedule.MonthViewMode)
                End If
            End If
        End Sub

#End Region

#Region "Fields"

        Private m_ScheduleView As NScheduleView

#End Region

#Region "Schema"

        ''' <summary>
        ''' Schema associated with NGroupingExample.
        ''' </summary>
        Public Shared ReadOnly NGroupingExampleSchema As NSchema

#End Region
    End Class
End Namespace

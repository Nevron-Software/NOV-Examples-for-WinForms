Imports Nevron.Nov.Dom
Imports Nevron.Nov.Schedule
Imports Nevron.Nov.Schedule.Commands
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.Schedule
    Public Class NContextMenuCustomizationExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' Default constructor.
        ''' </summary>
        Public Sub New()
        End Sub

        ''' <summary>
        ''' Static constructor.
        ''' </summary>
        Shared Sub New()
            NContextMenuCustomizationExampleSchema = NSchema.Create(GetType(NContextMenuCustomizationExample), NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            ' Create a simple schedule
            Dim scheduleViewWithRibbon As NScheduleViewWithRibbon = New NScheduleViewWithRibbon()
            m_ScheduleView = scheduleViewWithRibbon.View
            m_ScheduleView.Document.PauseHistoryService()

            Try
                InitSchedule(m_ScheduleView.Content)
            Finally
                m_ScheduleView.Document.ResumeHistoryService()
            End Try

            ' Add the custom command action to the schedule view's commander
            m_ScheduleView.Commander.Add(New CustomCommandAction())

            ' Change the context menu factory to the custom one
            m_ScheduleView.ContextMenu = New CustomContextMenu()

            ' Return the commanding widget
            Return scheduleViewWithRibbon
        End Function

        Protected Overrides Function CreateExampleControls() As NWidget
            Return Nothing
        End Function

        Protected Overrides Function GetExampleDescription() As String
            Return "
<p>This example demonstrates how to customize the NOV schedule context menu. A custom command is added
at the end of the context menu.</p>
"
        End Function

#End Region

#Region "Implementation"

        Private Sub InitSchedule(ByVal schedule As NSchedule)
            Dim start = Date.Now

            ' Create an appointment
            Dim appointment As NAppointment = New NAppointment("Meeting", start, start.AddHours(2))
            schedule.Appointments.Add(appointment)
            schedule.ScrollToTime(start.TimeOfDay)
        End Sub

#End Region

#Region "Fields"

        Private m_ScheduleView As NScheduleView

#End Region

#Region "Schema"

        ''' <summary>
        ''' Schema associated with NContextMenuCustomizationExample.
        ''' </summary>
        Public Shared ReadOnly NContextMenuCustomizationExampleSchema As NSchema

#End Region

#Region "Constants"

        Public Shared ReadOnly CustomCommand As NCommand = NCommand.Create(GetType(NContextMenuCustomizationExample), "CustomCommand", "Custom Command")

#End Region

#Region "Nested Types"

        Public Class CustomContextMenu
            Inherits NScheduleContextMenu
            ''' <summary>
            ''' Default constructor.
            ''' </summary>
            Public Sub New()
            End Sub
            ''' <summary>
            ''' Static constructor.
            ''' </summary>
            Shared Sub New()
                CustomContextMenuSchema = NSchema.Create(GetType(CustomContextMenu), NScheduleContextMenuSchema)
            End Sub

            Protected Overrides Sub CreateCustomCommands(ByVal menu As NMenu)
                MyBase.CreateCustomCommands(menu)

                ' Create a context menu builder
                Dim builder As NContextMenuBuilder = New NContextMenuBuilder()

                ' Add a custom command
                builder.AddMenuItem(menu, NResources.Image_Ribbon_16x16_smiley_png, CustomCommand)
            End Sub

            ''' <summary>
            ''' Schema associated with CustomContextMenu.
            ''' </summary>
            Public Shared ReadOnly CustomContextMenuSchema As NSchema
        End Class

        Public Class CustomCommandAction
            Inherits NScheduleCommandAction
#Region "Constructors"

            ''' <summary>
            ''' Default constructor.
            ''' </summary>
            Public Sub New()
            End Sub

            ''' <summary>
            ''' Static constructor.
            ''' </summary>
            Shared Sub New()
                CustomCommandActionSchema = NSchema.Create(GetType(CustomCommandAction), NScheduleCommandActionSchema)
            End Sub

#End Region

#Region "Public Overrides"

            ''' <summary>
            ''' Gets the command associated with this command action.
            ''' </summary>
            ''' <returns></returns>
            Public Overrides Function GetCommand() As NCommand
                Return CustomCommand
            End Function
            ''' <summary>
            ''' Executes the command action.
            ''' </summary>
            ''' <paramname="target"></param>
            ''' <paramname="parameter"></param>
            Public Overrides Sub Execute(ByVal target As NNode, ByVal parameter As Object)
                Dim scheduleView = GetScheduleView(target)
                NMessageBox.Show("Schedule Custom Command executed!", "Custom Command", ENMessageBoxButtons.OK, ENMessageBoxIcon.Information)
            End Sub

#End Region

#Region "Schema"

            ''' <summary>
            ''' Schema associated with CustomCommandAction.
            ''' </summary>
            Public Shared ReadOnly CustomCommandActionSchema As NSchema

#End Region
        End Class

#End Region
    End Class
End Namespace

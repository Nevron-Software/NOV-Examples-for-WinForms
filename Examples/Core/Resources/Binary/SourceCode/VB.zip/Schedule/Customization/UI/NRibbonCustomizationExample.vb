Imports Nevron.Nov.Dom
Imports Nevron.Nov.Schedule
Imports Nevron.Nov.Schedule.Commands
Imports Nevron.Nov.Schedule.UI
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.Schedule
    Public Class NRibbonCustomizationExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' Default constructor.
        ''' </summary>
        Public Sub New()
        End Sub

        ''' <summary>
        ''' Static constructor.
        ''' </summary>
        Shared Sub New()
            NRibbonCustomizationExampleSchema = NSchema.Create(GetType(NRibbonCustomizationExample), NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            ' Create a simple schedule
            m_ScheduleView = New NScheduleView()
            m_ScheduleView.Document.PauseHistoryService()

            Try
                InitSchedule(m_ScheduleView.Content)
            Finally
                m_ScheduleView.Document.ResumeHistoryService()
            End Try

            ' Add the custom command action to the schedule view's commander
            m_ScheduleView.Commander.Add(New CustomCommandAction())

            ' Create and configure a ribbon UI builder
            Dim ribbonBuilder As NScheduleRibbonBuilder = New NScheduleRibbonBuilder()

            ' Rename the "Home" ribbon tab page
            Dim homeTabBuilder = ribbonBuilder.TabPageBuilders(NScheduleRibbonBuilder.TabPageHomeName)
            homeTabBuilder.Name = "Start"

            ' Rename the "Font" ribbon group of the "Home" tab page
            Dim fontGroupBuilder = homeTabBuilder.RibbonGroupBuilders(NHomeTabPageBuilder.GroupViewName)
            fontGroupBuilder.Name = "Look"

            ' Remove the "Editing" ribbon group from the "Home" tab page
            homeTabBuilder.RibbonGroupBuilders.Remove(NHomeTabPageBuilder.GroupEditingName)

            ' Insert the custom ribbon group at the beginning of the home tab page
            homeTabBuilder.RibbonGroupBuilders.Insert(0, New CustomRibbonGroupBuilder())
            Return ribbonBuilder.CreateUI(m_ScheduleView)
        End Function

        Protected Overrides Function CreateExampleControls() As NWidget
            Return Nothing
        End Function

        Protected Overrides Function GetExampleDescription() As String
            Return "
<p>This example demonstrates how to customize the NOV schedule ribbon.</p>
"
        End Function

#End Region

#Region "Implementation"

        Private Sub InitSchedule(ByVal schedule As NSchedule)
            Dim start = Date.Now

            ' Create an appointment
            Dim appointment As NAppointment = New NAppointment("Meeting", start, start.AddHours(2))
            schedule.Appointments.Add(appointment)
            schedule.ScrollToTime(start.TimeOfDay)
        End Sub

#End Region

#Region "Fields"

        Private m_ScheduleView As NScheduleView

#End Region

#Region "Schema"

        ''' <summary>
        ''' Schema associated with NRibbonCustomizationExample.
        ''' </summary>
        Public Shared ReadOnly NRibbonCustomizationExampleSchema As NSchema

#End Region

#Region "Constants"

        Public Shared ReadOnly CustomCommand As NCommand = NCommand.Create(GetType(NRibbonCustomizationExample), "CustomCommand", "Custom Command")

#End Region

#Region "Nested Types"

        Public Class CustomRibbonGroupBuilder
            Inherits NRibbonGroupBuilder

            Public Sub New()
                MyBase.New("Custom Group", NResources.Image_Ribbon_16x16_smiley_png)
            End Sub

            Protected Overrides Sub AddRibbonGroupItems(ByVal items As NRibbonGroupItemCollection)
                ' Add the "Add Appointment" command
                items.Add(MyBase.CreateRibbonButton(NResources.Image_Ribbon_32x32_AddAppointment_png, NResources.Image_Edit_AddAppointment_png, NScheduleView.AddAppointmentCommand))

                ' Add the custom command
                items.Add(CreateRibbonButton(NResources.Image_Ribbon_32x32_smiley_png, NResources.Image_Ribbon_16x16_smiley_png, CustomCommand))
            End Sub
        End Class

        Public Class CustomCommandAction
            Inherits NScheduleCommandAction
#Region "Constructors"

            ''' <summary>
            ''' Default constructor.
            ''' </summary>
            Public Sub New()
            End Sub

            ''' <summary>
            ''' Static constructor.
            ''' </summary>
            Shared Sub New()
                CustomCommandActionSchema = NSchema.Create(GetType(CustomCommandAction), NScheduleCommandActionSchema)
            End Sub

#End Region

#Region "Public Overrides"

            ''' <summary>
            ''' Gets the command associated with this command action.
            ''' </summary>
            ''' <returns></returns>
            Public Overrides Function GetCommand() As NCommand
                Return CustomCommand
            End Function
            ''' <summary>
            ''' Executes the command action.
            ''' </summary>
            ''' <paramname="target"></param>
            ''' <paramname="parameter"></param>
            Public Overrides Sub Execute(ByVal target As NNode, ByVal parameter As Object)
                Dim scheduleView = GetScheduleView(target)
                NMessageBox.Show("Schedule Custom Command executed!", "Custom Command", ENMessageBoxButtons.OK, ENMessageBoxIcon.Information)
            End Sub

#End Region

#Region "Schema"

            ''' <summary>
            ''' Schema associated with CustomCommandAction.
            ''' </summary>
            Public Shared ReadOnly CustomCommandActionSchema As NSchema

#End Region
        End Class

#End Region
    End Class
End Namespace


Imports Nevron.Nov.Dom
Imports Nevron.Nov.Editors
Imports Nevron.Nov.Graphics
Imports Nevron.Nov.Layout
Imports Nevron.Nov.Schedule
Imports Nevron.Nov.Schedule.Commands
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.Schedule
    Public Class NAppointmentEditorCustomizationExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' Default constructor.
        ''' </summary>
        Public Sub New()
        End Sub

        ''' <summary>
        ''' Static constructor.
        ''' </summary>
        Shared Sub New()
            NAppointmentEditorCustomizationExampleSchema = NSchema.Create(GetType(NAppointmentEditorCustomizationExample), NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            ' Create a simple schedule
            Dim scheduleViewWithRibbon As NScheduleViewWithRibbon = New NScheduleViewWithRibbon()
            m_ScheduleView = scheduleViewWithRibbon.View

            m_ScheduleView.Document.PauseHistoryService()
            Try
                InitSchedule(m_ScheduleView.Content)
            Finally
                m_ScheduleView.Document.ResumeHistoryService()
            End Try

            ' Return the commanding widget
            Return scheduleViewWithRibbon
        End Function
        Protected Overrides Function CreateExampleControls() As NWidget
            Return Nothing
        End Function
        Protected Overrides Function GetExampleDescription() As String
            Return "
<p>This example demonstrates how to replace the appointment edit dialog with a custom one.</p>
" End Function

#End Region

#Region "Implementation"

        Private Sub InitSchedule(ByVal schedule As NSchedule)
            Dim start = Date.Now

            ' Replace the default Add Appointment command action with a custom one
            Dim addAppointmentCommandAction = m_ScheduleView.Commander.GetCommandAction(NScheduleView.AddAppointmentCommand)
            m_ScheduleView.Commander.Remove(addAppointmentCommandAction)
            m_ScheduleView.Commander.Add(New CustomAddAppointmentCommandAction())

            ' Replace the default Appointment Edit tool with a custom one
            Dim appointmentEditTool = m_ScheduleView.Interactor.GetTool(NAppointmentEditTool.NAppointmentEditToolSchema)
            Dim index = m_ScheduleView.Interactor.IndexOf(appointmentEditTool)
            m_ScheduleView.Interactor.RemoveAt(index)

            Dim customEditAppointmentTool As NTool = New CustomAppointmentEditTool()
            customEditAppointmentTool.Enabled = True
            m_ScheduleView.Interactor.Insert(index, customEditAppointmentTool)

            ' Create some custom appointments
            Dim appointmentWithLocation As AppointmentWithLocation = New AppointmentWithLocation("Appointment with Location", start, start.AddHours(2))
            appointmentWithLocation.Location = "New York"
            schedule.Appointments.Add(appointmentWithLocation)

            Dim appointmentWithImage As AppointmentWithImage = New AppointmentWithImage("Appointment with Image", start.AddHours(3), start.AddHours(5))
            appointmentWithImage.Image = NResources.Image_MobileComputers_UMPC_jpg
            appointmentWithImage.Category = NLoc.Get("Orange")
            schedule.Appointments.Add(appointmentWithImage)

            schedule.ScrollToTime(start.TimeOfDay)
        End Sub

#End Region

#Region "Fields"

        Private m_ScheduleView As NScheduleView

#End Region

#Region "Schema"

        ''' <summary>
        ''' Schema associated with NAppointmentEditorCustomizationExample.
        ''' </summary>
        Public Shared ReadOnly NAppointmentEditorCustomizationExampleSchema As NSchema

#End Region

#Region "Nested Types"

        ''' <summary>
        ''' A custom appointment class.
        ''' </summary>
        Public Class AppointmentWithLocation
            Inherits NAppointment
#Region "Constructors"

            ''' <summary>
            ''' Default constructor.
            ''' </summary>
            Public Sub New()
            End Sub
            ''' <summary>
            ''' Initializing constructor.
            ''' </summary>
            ''' <paramname="subject"></param>
            ''' <paramname="start"></param>
            ''' <paramname="end"></param>
            Public Sub New(ByVal subject As String, ByVal start As Date, ByVal [end] As Date)
                MyBase.New(subject, start, [end])
            End Sub

            ''' <summary>
            ''' Static constructor.
            ''' </summary>
            Shared Sub New()
                CustomAppointmentSchema = NSchema.Create(GetType(AppointmentWithLocation), NAppointmentSchema)

                ' Properties
                LocationProperty = CustomAppointmentSchema.AddSlot("Location", NDomType.String, defaultLocation)

                ' Designer
                Call CustomAppointmentSchema.SetMetaUnit(New NDesignerMetaUnit(GetType(CustomAppointmentDesigner)))
            End Sub

#End Region

#Region "Properties"

            ''' <summary>
            ''' Gets/Sets the location of the appointment.
            ''' </summary>
            Public Property Location As String
                Get
                    Return CStr(GetValue(LocationProperty))
                End Get
                Set(ByVal value As String)
                    SetValue(LocationProperty, value)
                End Set
            End Property

#End Region

#Region "Schema"

            ''' <summary>
            ''' Schema associated with CustomAppointment.
            ''' </summary>
            Public Shared ReadOnly CustomAppointmentSchema As NSchema
            ''' <summary>
            ''' Reference to the Location property.
            ''' </summary>
            Public Shared ReadOnly LocationProperty As NProperty

#End Region

#Region "Default Values"

            Private Const defaultLocation As String = Nothing

#End Region

#Region "Nested Types - Designer"

            Public Class CustomAppointmentDesigner
                Inherits NAppointmentDesigner
                Protected Overrides Sub ConfigureGeneralCategory()
                    MyBase.ConfigureGeneralCategory()

                    MyBase.SetPropertyBrowsable(LocationProperty, True)
                End Sub
            End Class

#End Region
        End Class

        ''' <summary>
        ''' A custom appointment class.
        ''' </summary>
        Public Class AppointmentWithImage
            Inherits NAppointmentBase
#Region "Constructors"

            ''' <summary>
            ''' Default constructor.
            ''' </summary>
            Public Sub New()
            End Sub
            ''' <summary>
            ''' Initializing constructor.
            ''' </summary>
            ''' <paramname="subject"></param>
            ''' <paramname="start"></param>
            ''' <paramname="end"></param>
            Public Sub New(ByVal subject As String, ByVal start As Date, ByVal [end] As Date)
                MyBase.New(subject, start, [end])
            End Sub

            ''' <summary>
            ''' Static constructor.
            ''' </summary>
            Shared Sub New()
                AppointmentWithImageSchema = NSchema.Create(GetType(AppointmentWithImage), NAppointmentBaseSchema)

                ' Properties
                ImageProperty = AppointmentWithImageSchema.AddSlot("Image", GetType(NImage), defaultImage)
            End Sub

#End Region

#Region "Properties"

            ''' <summary>
            ''' Gets/Sets the image for this appointment.
            ''' </summary>
            Public Property Image As NImage
                Get
                    Return GetValue(ImageProperty)
                End Get
                Set(ByVal value As NImage)
                    SetValue(ImageProperty, value)
                End Set
            End Property

#End Region

#Region "Public Overrides - Edit Dialog"

            ''' <summary>
            ''' Creates a custom appointment edit dialog.
            ''' </summary>
            ''' <returns></returns>
            Public Overrides Function CreateEditDialog() As NTopLevelWindow
                Dim schedule = CType(GetFirstAncestor(NSchedule.NScheduleSchema), NSchedule)
                Dim window = If(schedule IsNot Nothing, schedule.DisplayWindow, Nothing)

                ' Create a dialog window
                Dim dialog = NApplication.CreateTopLevelWindow(NWindow.GetFocusedWindowIfNull(window))
                dialog.SetupDialogWindow("Appointment with Image Editor", True)

                Dim stack As NStackPanel = New NStackPanel()
                stack.FillMode = ENStackFillMode.Last
                stack.FitMode = ENStackFitMode.Last

                ' Add an image box with the image
                Dim imageBox As NImageBox = New NImageBox(NSystem.SafeDeepClone(Image))
                stack.Add(imageBox)

                ' Add property editors for some of the appointment properties
                Dim designer = NDesigner.GetDesigner(Me)
                Dim editors = designer.CreatePropertyEditors(Me, SubjectProperty, StartProperty, EndProperty)

                For i = 0 To editors.Count - 1
                    stack.Add(editors(i))
                Next

                ' Add a button strip with OK and Cancel buttons
                Dim buttonStrip As NButtonStrip = New NButtonStrip()
                buttonStrip.AddOKCancelButtons()
                stack.Add(buttonStrip)

                dialog.Content = New NUniSizeBoxGroup(stack)

                Return dialog
            End Function

#End Region

#Region "Schema"

            ''' <summary>
            ''' Schema associated with AppointmentWithImage.
            ''' </summary>
            Public Shared ReadOnly AppointmentWithImageSchema As NSchema
            ''' <summary>
            ''' Reference to the Image property.
            ''' </summary>
            Public Shared ReadOnly ImageProperty As NProperty

#End Region

#Region "Default Values"

            Private Const defaultImage As NImage = Nothing

#End Region
        End Class

        Public Class CustomAddAppointmentCommandAction
            Inherits NAddAppointmentCommandAction
#Region "Constructors"

            ''' <summary>
            ''' Default constructor.
            ''' </summary>
            Public Sub New()
            End Sub

            ''' <summary>
            ''' Static constructor.
            ''' </summary>
            Shared Sub New()
                CustomAddAppointmentCommandActionSchema = NSchema.Create(GetType(CustomAddAppointmentCommandAction), NAddAppointmentCommandActionSchema)
            End Sub

#End Region

#Region "Protected Overrides"

            Protected Overrides Function CreateAppointmentForGridCell(ByVal gridCell As NScheduleGridCell) As NAppointmentBase
                Dim appointment As AppointmentWithImage = New AppointmentWithImage(Nothing, gridCell.StartTime, gridCell.EndTime)
                appointment.Image = NResources.Image_Artistic_Plane_png

                Return appointment
            End Function

#End Region

#Region "Schema"

            ''' <summary>
            ''' Schema associated with CustomAddAppointmentCommandAction.
            ''' </summary>
            Public Shared ReadOnly CustomAddAppointmentCommandActionSchema As NSchema

#End Region
        End Class

        Public Class CustomAppointmentEditTool
            Inherits NAppointmentEditTool
#Region "Constructors"

            ''' <summary>
            ''' Default constructor.
            ''' </summary>
            Public Sub New()
            End Sub

            ''' <summary>
            ''' Static constructor.
            ''' </summary>
            Shared Sub New()
                CustomAppointmentEditToolSchema = NSchema.Create(GetType(CustomAppointmentEditTool), NAppointmentEditToolSchema)
            End Sub

#End Region

#Region "Protected Overrides"

            Protected Overrides Function CreateAppointmentForGridCell(ByVal gridCell As NScheduleGridCell) As NAppointmentBase
                Dim appointment As AppointmentWithImage = New AppointmentWithImage(Nothing, gridCell.StartTime, gridCell.EndTime)
                appointment.Image = NResources.Image_Artistic_Plane_png

                Return appointment
            End Function

#End Region

#Region "Schema"

            ''' <summary>
            ''' Schema associated with CustomAppointmentEditTool.
            ''' </summary>
            Public Shared ReadOnly CustomAppointmentEditToolSchema As NSchema

#End Region
        End Class

#End Region
    End Class
End Namespace

Imports Nevron.Nov.Dom
Imports Nevron.Nov.Graphics
Imports Nevron.Nov.Layout
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.UI
    Public Class NBackgroundsExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' Default constructor.
        ''' </summary>
        Public Sub New()
        End Sub
        ''' <summary>
        ''' Static constructor.
        ''' </summary>
        Shared Sub New()
            NBackgroundsExampleSchema = NSchema.Create(GetType(NBackgroundsExample), NExampleBase.NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            ' Create a table layout panel
            Dim table As NTableFlowPanel = New NTableFlowPanel()
            table.MaxOrdinal = 3
            table.HorizontalSpacing = 10
            table.VerticalSpacing = 10
            table.ColFillMode = ENStackFillMode.Equal
            table.ColFitMode = ENStackFitMode.Equal
            table.RowFitMode = ENStackFitMode.Equal
            table.RowFillMode = ENStackFillMode.Equal
            table.UniformWidths = ENUniformSize.Max
            table.UniformHeights = ENUniformSize.Max

            ' Create widgets to demonstrate the different background types
            table.Add(CreateWidget("Solid Background", New NColorFill(NColor.PapayaWhip)))
            table.Add(CreateWidget("Hatch Background", New NHatchFill(ENHatchStyle.Cross, NColor.Red, NColor.PapayaWhip)))
            table.Add(CreateWidget("Gradient Background", New NStockGradientFill(ENGradientStyle.FromCenter, ENGradientVariant.Variant1, NColor.Red, NColor.PapayaWhip)))
            table.Add(CreateWidget("Predefined Advanced Gradient", NAdvancedGradientFill.Create(ENAdvancedGradientColorScheme.Fire1, 5)))
            Dim agFill As NAdvancedGradientFill = New NAdvancedGradientFill()
            agFill.BackgroundColor = NColor.Black
            agFill.Points.Add(New NAdvancedGradientPoint(NColor.Green, NAngle.Zero, 0.5F, 0.5F, 0.2F, ENAdvancedGradientPointShape.Line))
            agFill.Points.Add(New NAdvancedGradientPoint(NColor.Green, New NAngle(90, NUnit.Degree), 0.5F, 0.5F, 0.2F, ENAdvancedGradientPointShape.Line))
            agFill.Points.Add(New NAdvancedGradientPoint(NColor.White, NAngle.Zero, 0.5F, 0.5F, 0.5F, ENAdvancedGradientPointShape.Circle))
            table.Add(CreateWidget("Custom Advanced Gradient", agFill))
            Dim imageFill As NImageFill = New NImageFill(NResources.Image__24x24_Shortcuts_png)
            imageFill.TextureMapping = New NAlignTextureMapping()
            table.Add(CreateWidget("Normal Image Background", imageFill))
            imageFill = New NImageFill(NResources.Image__24x24_Shortcuts_png)
            imageFill.TextureMapping = New NAlignTextureMapping()
            table.Add(CreateWidget("Fit Image Background", imageFill))
            imageFill = New NImageFill(NResources.Image__24x24_Shortcuts_png)
            imageFill.TextureMapping = New NStretchTextureMapping()
            table.Add(CreateWidget("Stretched Image Background", imageFill))
            imageFill = New NImageFill(NResources.Image__24x24_Shortcuts_png)
            imageFill.TextureMapping = New NTileTextureMapping()
            table.Add(CreateWidget("Tiled Image Background", imageFill))
            Return table
        End Function

        Protected Overrides Function CreateExampleControls() As NWidget
            Return Nothing
        End Function

        Protected Overrides Function GetExampleDescription() As String
            Return "
<p>
	This example demonstrates how to create different types of backgrounds and apply them to widgets.
</p>
"
        End Function

#End Region

#Region "Implementation"

        Private Function CreateWidget(ByVal text As String, ByVal backgroundFill As NFill) As NWidget
            Dim stack As NStackPanel = New NStackPanel()
            stack.FitMode = ENStackFitMode.First
            stack.FillMode = ENStackFillMode.First
            Dim widget As NWidget = New NWidget()
            widget.BackgroundFill = backgroundFill
            stack.Add(widget)
            Dim label As NLabel = New NLabel(text)
            label.HorizontalPlacement = ENHorizontalPlacement.Center
            stack.Add(label)
            Return stack
        End Function

#End Region

#Region "Schema"

        ''' <summary>
        ''' Schema associated with NBackgroundsExample.
        ''' </summary>
        Public Shared ReadOnly NBackgroundsExampleSchema As NSchema

#End Region
    End Class
End Namespace

Imports System
Imports Nevron.Nov.Dom
Imports Nevron.Nov.Graphics
Imports Nevron.Nov.Layout
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.UI
    Public Class NBorderWallExample
        Inherits NExampleBase
#Region "Constructors"

        Public Sub New()
        End Sub

        Shared Sub New()
            NBorderWallExampleSchema = NSchema.Create(GetType(NBorderWallExample), NExampleBase.NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            ' create a tab control for the different border walls
            Dim tab As NTab = New NTab()
            Dim boxBorderPage As NTabPage = New NTabPage("Box Border")
            tab.TabPages.Add(boxBorderPage)
            Dim crossBorderPage As NTabPage = New NTabPage("Cross Border")
            tab.TabPages.Add(crossBorderPage)
            Dim openBorderPage As NTabPage = New NTabPage("Opened Border")
            tab.TabPages.Add(openBorderPage)

            ' create the three elements that demonstrate the border walls
            m_BoxBorderElement = New NCustomBorderWallWidget()
            boxBorderPage.Content = m_BoxBorderElement
            m_BoxBorderElement.BorderWallType = ENCustomBorderWallType.Rectangle
            m_CrossBorderElement = New NCustomBorderWallWidget()
            crossBorderPage.Content = m_CrossBorderElement
            m_CrossBorderElement.BorderWallType = ENCustomBorderWallType.Cross
            m_OpenedBorderElement = New NCustomBorderWallWidget()
            openBorderPage.Content = m_OpenedBorderElement
            m_OpenedBorderElement.BorderWallType = ENCustomBorderWallType.Opened

            ' init the custom border elements
            Dim elements As NCustomBorderWallWidget() = GetCustomBorderElements()
            Dim colors As NUIThemeColorMap = New NUIThemeColorMap(ENUIThemeScheme.WindowsClassic)

            For i = 0 To elements.Length - 1
                elements(i).BorderThickness = New NMargins(2)
                elements(i).Border = NBorder.CreateRaised3DBorder(colors)
                elements(i).Margins = New NMargins(10)
            Next

            Return tab
        End Function

        Protected Overrides Function CreateExampleControls() As NWidget
            Dim stack As NStackPanel = New NStackPanel()

            ' create the predefined borders combo and populate it
            stack.Add(CreateLabel("Apply Predefined Border:"))
            m_PredefinedBorderCombo = New NComboBox()
            stack.Add(m_PredefinedBorderCombo)
            m_PredefinedBorderCombo.Items.Add(New NComboBoxItem("3D Raised Border"))
            m_PredefinedBorderCombo.Items.Add(New NComboBoxItem("3D Sunken Border"))
            m_PredefinedBorderCombo.Items.Add(New NComboBoxItem("Filled Border"))
            m_PredefinedBorderCombo.Items.Add(New NComboBoxItem("Filled Border with Outlines"))
            m_PredefinedBorderCombo.SelectedIndex = 0
            AddHandler m_PredefinedBorderCombo.SelectedIndexChanged, New [Function](Of NValueChangeEventArgs)(AddressOf OnPredefinedBorderComboSelectedIndexChanged)

            ' create the combos for the border thickness
            stack.Add(CreateLabel("Border Thickness:"))
            m_BorderThicknessCombo = CreateBorderSideThicknessCombo()
            stack.Add(m_BorderThicknessCombo)
            stack.Add(CreateLabel("Left Side Thickness:"))
            m_LeftSideThicknessCombo = CreateBorderSideThicknessCombo()
            stack.Add(m_LeftSideThicknessCombo)
            stack.Add(CreateLabel("Right Side Thickness:"))
            m_RightSideThicknessCombo = CreateBorderSideThicknessCombo()
            stack.Add(m_RightSideThicknessCombo)
            stack.Add(CreateLabel("Top Side Thickness:"))
            m_TopSideThicknessCombo = CreateBorderSideThicknessCombo()
            stack.Add(m_TopSideThicknessCombo)
            stack.Add(CreateLabel("Bottom Side Thickness:"))
            m_BottomSideThicknessCombo = CreateBorderSideThicknessCombo()
            stack.Add(m_BottomSideThicknessCombo)
            stack.Add(CreateLabel("Inner Corner Radius:"))
            m_InnerRadiusCombo = CreateCornerRadiusCombo()
            stack.Add(m_InnerRadiusCombo)
            stack.Add(CreateLabel("Outer Corner Radius:"))
            m_OuterRadiusCombo = CreateCornerRadiusCombo()
            stack.Add(m_OuterRadiusCombo)
            Return stack
        End Function

        Protected Overrides Function GetExampleDescription() As String
            Return "
<p>
This example demonstrates how to create different types of borders and apply them to widgets. 
It also demonstrates how to override the border wall of a widget and provide a custom one.
Using the controls to the right	you can change the type and appearance of the generated borders.
</p>
"
        End Function

#End Region

#Region "Event Handlers"

        Private Sub OnPredefinedBorderComboSelectedIndexChanged(ByVal args As NValueChangeEventArgs)
            If m_PredefinedBorderCombo.SelectedIndex = -1 Then Return
            Dim innerRadius As Double = m_InnerRadiusCombo.SelectedIndex
            Dim outerRadius As Double = m_OuterRadiusCombo.SelectedIndex

            ' apply a predefined border
            Dim elements As NCustomBorderWallWidget() = GetCustomBorderElements()

            For i = 0 To elements.Length - 1
                Dim border As NBorder = Nothing

                Select Case m_PredefinedBorderCombo.SelectedIndex
                    Case 0 ' 3D Raised Border
                        border = NBorder.CreateRaised3DBorder(New NUIThemeColorMap(ENUIThemeScheme.WindowsClassic))
                    Case 1 ' 3D Sunken Border
                        border = NBorder.CreateSunken3DBorder(New NUIThemeColorMap(ENUIThemeScheme.WindowsClassic))
                    Case 2 ' Filled Border
                        border = NBorder.CreateFilledBorder(NColor.Red)
                    Case 3 ' Filled Border with Outlines
                        border = NBorder.CreateFilledBorder(New NColorFill(NColor.Blue), New NStroke(1, NColor.Black), New NStroke(1, NColor.Black))
                End Select

                border.SetRadiuses(innerRadius, outerRadius)
                elements(i).Border = border
            Next
        End Sub

        Private Sub OnSideThicknessComboSelectedIndexChanged(ByVal args As NValueChangeEventArgs)
            Dim combo As NComboBox = TryCast(args.TargetNode, NComboBox)
            Dim sideThickness As Double = combo.SelectedIndex
            Dim bt = m_BoxBorderElement.BorderThickness

            If combo Is m_BorderThicknessCombo Then
                bt = New NMargins(sideThickness)
            ElseIf combo Is m_LeftSideThicknessCombo Then
                bt.Left = sideThickness
            ElseIf combo Is m_RightSideThicknessCombo Then
                bt.Right = sideThickness
            ElseIf combo Is m_TopSideThicknessCombo Then
                bt.Top = sideThickness
            ElseIf combo Is m_BottomSideThicknessCombo Then
                bt.Bottom = sideThickness
            End If

            Dim elements As NCustomBorderWallWidget() = GetCustomBorderElements()

            For i = 0 To elements.Length - 1
                elements(i).BorderThickness = bt
            Next
        End Sub

        Private Sub OnCornerRadiusComboSelectedIndexChanged(ByVal args As NValueChangeEventArgs)
            OnPredefinedBorderComboSelectedIndexChanged(Nothing)
        End Sub

#End Region

#Region "Implementation"

        Private Function CreateLabel(ByVal text As String) As NLabel
            Dim label As NLabel = New NLabel(text)
            label.HorizontalPlacement = ENHorizontalPlacement.Left
            Return label
        End Function

        Private Function CreateBorderSideThicknessCombo() As NComboBox
            Dim combo As NComboBox = New NComboBox()

            For i = 0 To 30 - 1
                combo.Items.Add(New NComboBoxItem(i.ToString() & " dip"))
            Next

            combo.SelectedIndex = 2
            AddHandler combo.SelectedIndexChanged, New [Function](Of NValueChangeEventArgs)(AddressOf OnSideThicknessComboSelectedIndexChanged)
            Return combo
        End Function

        Private Function CreateCornerRadiusCombo() As NComboBox
            Dim combo As NComboBox = New NComboBox()

            For i = 0 To 30 - 1
                combo.Items.Add(New NComboBoxItem(i.ToString() & " dip"))
            Next

            combo.SelectedIndex = 0
            AddHandler combo.SelectedIndexChanged, New [Function](Of NValueChangeEventArgs)(AddressOf OnCornerRadiusComboSelectedIndexChanged)
            Return combo
        End Function

        Private Function GetCustomBorderElements() As NCustomBorderWallWidget()
            Return New NCustomBorderWallWidget() {m_BoxBorderElement, m_CrossBorderElement, m_OpenedBorderElement}
        End Function

#End Region

#Region "Fields"

        Private m_BoxBorderElement As NCustomBorderWallWidget
        Private m_CrossBorderElement As NCustomBorderWallWidget
        Private m_OpenedBorderElement As NCustomBorderWallWidget
        Private m_PredefinedBorderCombo As NComboBox
        Private m_BorderThicknessCombo As NComboBox
        Private m_LeftSideThicknessCombo As NComboBox
        Private m_RightSideThicknessCombo As NComboBox
        Private m_TopSideThicknessCombo As NComboBox
        Private m_BottomSideThicknessCombo As NComboBox
        Private m_InnerRadiusCombo As NComboBox
        Private m_OuterRadiusCombo As NComboBox

#End Region

#Region "Schema"

        Public Shared ReadOnly NBorderWallExampleSchema As NSchema

#End Region

#Region "Nested Types"

        ''' <summary>
        ''' Enumerates the demonstrated border walls
        ''' </summary>
        Public Enum ENCustomBorderWallType
            Rectangle
            Cross
            Opened
        End Enum
        ''' <summary>
        ''' A widget that overrides the default border wall of widgets 
        ''' to demonstrate all possible corners and to demonstrate opened walls.
        ''' </summary>
        Public Class NCustomBorderWallWidget
            Inherits NWidget
#Region "Constructors"

            Public Sub New()
            End Sub

            Shared Sub New()
                NCustomBorderWallWidgetSchema = NSchema.Create(GetType(NCustomBorderWallWidget), NWidgetSchema)
                BorderWallTypeProperty = NCustomBorderWallWidgetSchema.AddSlot("BorderWallType", NDomType.FromType(GetType(ENCustomBorderWallType)), ENCustomBorderWallType.Rectangle)
            End Sub

#End Region

#Region "Properties"

            Public Property BorderWallType As ENCustomBorderWallType
                Get
                    Return GetValue(BorderWallTypeProperty)
                End Get
                Set(ByVal value As ENCustomBorderWallType)
                    SetValue(BorderWallTypeProperty, value)
                End Set
            End Property

#End Region

#Region "Protected Overrides - Border Wall"

            Protected Overrides Function CreateBorderWall() As NBorderWall
                Select Case BorderWallType
                    Case ENCustomBorderWallType.Rectangle
                        Return MyBase.CreateBorderWall()
                    Case ENCustomBorderWallType.Cross
                        Return CreateCrossBorderWall()
                    Case ENCustomBorderWallType.Opened
                        Return CreateOpenedBorderWall()
                    Case Else
                        Throw New Exception("New ENCustomBorderWallType?")
                End Select
            End Function

#End Region

#Region "Implementation - Border Wall"

            Private Function CreateCrossBorderWall() As NBorderWall
                Dim r0 As NRectangle = GetContentEdge()
                Dim bt = BorderThickness
                bt.Left = Math.Min(bt.Left, r0.Width / 6)
                bt.Right = Math.Min(bt.Right, r0.Width / 6)
                bt.Top = Math.Min(bt.Top, r0.Height / 6)
                bt.Bottom = Math.Min(bt.Bottom, r0.Height / 6)
                Dim r1 = bt.GetInnerRect(r0)
                Dim r2 = NRectangle.FromLTRB(r1.X + r1.Width / 3 - bt.Left / 2, r1.Y + r1.Height / 3 - bt.Top / 2, r1.Right - r1.Width / 3 + bt.Right / 2, r1.Bottom - r1.Height / 3 + bt.Bottom / 2)
                Dim r3 = bt.GetInnerRect(r2)
                Dim x0 = r0.X
                Dim x1 = r1.X
                Dim x2 = r2.X
                Dim x3 = r3.X
                Dim x4 = r3.Right
                Dim x5 = r2.Right
                Dim x6 = r1.Right
                Dim x7 = r0.Right
                Dim y0 = r0.Y
                Dim y1 = r1.Y
                Dim y2 = r2.Y
                Dim y3 = r3.Y
                Dim y4 = r3.Bottom
                Dim y5 = r2.Bottom
                Dim y6 = r1.Bottom
                Dim y7 = r0.Bottom
                Dim wall As NBorderWall = New NBorderWall(True)
                wall.AddLeftTopCorner(New NRectangle(x2, y0, bt.Left, bt.Top))
                wall.AddTopSide(New NRectangle(x3, y0, x4 - x3, bt.Top))
                wall.AddTopRightCorner(New NRectangle(x4, y0, bt.Right, bt.Top))
                wall.AddRightSide(New NRectangle(x4, y1, bt.Right, y2 - y1))
                wall.AddRightTopCorner(New NRectangle(x4, y2, bt.Right, bt.Top))
                wall.AddTopSide(New NRectangle(x5, y2, x6 - x5, bt.Top))
                wall.AddTopRightCorner(New NRectangle(x6, y2, bt.Right, bt.Top))
                wall.AddRightSide(New NRectangle(x6, y3, bt.Right, y4 - y3))
                wall.AddRightBottomCorner(New NRectangle(x6, y4, bt.Right, bt.Bottom))
                wall.AddBottomSide(New NRectangle(x5, y4, x6 - x5, bt.Bottom))
                wall.AddBottomRightCorner(New NRectangle(x4, y4, bt.Right, bt.Bottom))
                wall.AddRightSide(New NRectangle(x4, y5, bt.Right, y6 - y5))
                wall.AddRightBottomCorner(New NRectangle(x4, y6, bt.Right, bt.Bottom))
                wall.AddBottomSide(New NRectangle(x3, y6, x4 - x3, bt.Bottom))
                wall.AddBottomLeftCorner(New NRectangle(x2, y6, bt.Left, bt.Bottom))
                wall.AddLeftSide(New NRectangle(x2, y5, bt.Left, y6 - y5))
                wall.AddLeftBottomCorner(New NRectangle(x2, y4, bt.Left, bt.Bottom))
                wall.AddBottomSide(New NRectangle(x1, y4, x2 - x1, bt.Bottom))
                wall.AddBottomLeftCorner(New NRectangle(x0, y4, bt.Left, bt.Bottom))
                wall.AddLeftSide(New NRectangle(x0, y3, bt.Left, y4 - y3))
                wall.AddLeftTopCorner(New NRectangle(x0, y2, bt.Left, bt.Top))
                wall.AddTopSide(New NRectangle(x1, y2, x2 - x1, bt.Top))
                wall.AddTopLeftCorner(New NRectangle(x2, y2, bt.Left, bt.Top))
                wall.AddLeftSide(New NRectangle(x2, y1, bt.Left, y2 - y1))
                Return wall
            End Function

            Private Function CreateOpenedBorderWall() As NBorderWall
                Dim outer As NRectangle = GetBorderEdge()
                Dim inner As NRectangle = GetContentEdge()
                Dim wall As NBorderWall = New NBorderWall(False)
                Dim leftSide = inner.X - outer.X
                Dim topSide = inner.Y - outer.Y
                Dim rightSide = outer.Right - inner.Right
                Dim bottomSide = outer.Bottom - inner.Bottom
                Dim topClipStart = inner.X + inner.Width / 3
                Dim topClipEnd = inner.Right - inner.Width / 3
                wall.AddTopSide(New NRectangle(topClipEnd, outer.Y, inner.Right - topClipEnd, topSide))
                wall.AddTopRightCorner(New NRectangle(inner.Right, outer.Y, rightSide, topSide))
                wall.AddRightSide(New NRectangle(inner.Right, inner.Y, rightSide, inner.Height))
                wall.AddRightBottomCorner(New NRectangle(inner.Right, inner.Bottom, rightSide, bottomSide))
                wall.AddBottomSide(New NRectangle(inner.X, inner.Bottom, inner.Width, bottomSide))
                wall.AddBottomLeftCorner(New NRectangle(outer.X, inner.Bottom, leftSide, bottomSide))
                wall.AddLeftSide(New NRectangle(outer.X, inner.Y, leftSide, inner.Height))
                wall.AddLeftTopCorner(New NRectangle(outer.X, outer.Y, leftSide, topSide))
                wall.AddTopSide(New NRectangle(inner.X, outer.Y, topClipStart - inner.X, topSide))
                Return wall
            End Function

#End Region

#Region "Schema"

            Public Shared ReadOnly NCustomBorderWallWidgetSchema As NSchema
            Public Shared ReadOnly BorderWallTypeProperty As NProperty

#End Region
        End Class

#End Region
    End Class
End Namespace

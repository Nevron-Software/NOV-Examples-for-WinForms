Imports Nevron.Nov.Dom
Imports Nevron.Nov.Graphics
Imports Nevron.Nov.Layout
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.UI
    Public Class NBordersExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' Default constructor.
        ''' </summary>
        Public Sub New()
        End Sub
        ''' <summary>
        ''' Static constructor.
        ''' </summary>
        Shared Sub New()
            NBordersExampleSchema = NSchema.Create(GetType(NBordersExample), NExampleBase.NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            ' Create a table layout panel
            Dim table As NTableFlowPanel = New NTableFlowPanel()
            table.Padding = New NMargins(10)
            table.BackgroundFill = New NColorFill(NColor.White)
            table.MaxOrdinal = 3
            table.HorizontalSpacing = 10
            table.VerticalSpacing = 10
            table.ColFillMode = ENStackFillMode.Equal
            table.ColFitMode = ENStackFitMode.Equal
            table.RowFitMode = ENStackFitMode.Equal
            table.RowFillMode = ENStackFillMode.None
            table.UniformWidths = ENUniformSize.Max
            table.UniformHeights = ENUniformSize.Max

            ' add some predefined borders
            ' 3D Borders
            Dim map As NUIThemeColorMap = New NUIThemeColorMap(ENUIThemeScheme.WindowsClassic)
            table.Add(CreateBorderedWidget("3D Border", NBorder.Create3DBorder(NColor.Green.Lighten().Lighten(), NColor.Green.Lighten(), NColor.Green.Darken(), NColor.Green)))
            table.Add(CreateBorderedWidget("Raised Border (using Theme Colors)", NBorder.CreateRaised3DBorder(map)))
            table.Add(CreateBorderedWidget("Sunken Border (using Theme Colors)", NBorder.CreateSunken3DBorder(map)))

            ' Filled Borders
            table.Add(CreateBorderedWidget("Solid Color", NBorder.CreateFilledBorder(NColor.Red)))
            table.Add(CreateBorderedWidget("Solid Color With Rounded Corners", NBorder.CreateFilledBorder(NColor.Blue, 10, 13)))
            table.Add(CreateBorderedWidget("Gradient Filling With Outline", NBorder.CreateFilledBorder(NFill.CreatePredefined(ENPredefinedFillPattern.GradientVertical, NColor.Red, NColor.Blue), New NStroke(1, NColor.Green), New NStroke(1, NColor.Green))))

            ' Outer Outline Borders
            table.Add(CreateBorderedWidget("Outer Outline Border", NBorder.CreateOuterOutlineBorder(New NStroke(1, NColor.Red, ENDashStyle.Dash))))
            table.Add(CreateBorderedWidget("Outer Outline Border with Rounding", NBorder.CreateOuterOutlineBorder(New NStroke(1, NColor.Red, ENDashStyle.Dash), 10)))
            table.Add(CreateBorderedWidget("Outer Outline Border", NBorder.CreateOuterOutlineBorder(New NStroke(1, NColor.Red, ENDashStyle.Dash))))
            table.Add(CreateBorderedWidget("Outer Outline Border with Rounding", NBorder.CreateOuterOutlineBorder(New NStroke(1, NColor.Red, ENDashStyle.Dash), 10)))

            ' Inner Outline Borders
            table.Add(CreateBorderedWidget("Inner Outline Border", NBorder.CreateInnerOutlineBorder(New NStroke(1, NColor.Red, ENDashStyle.Dash))))
            table.Add(CreateBorderedWidget("Inner Outline Border with Rounding", NBorder.CreateInnerOutlineBorder(New NStroke(1, NColor.Green, ENDashStyle.Dash), 10)))
            table.Add(CreateBorderedWidget("Inner Outline Border", NBorder.CreateInnerOutlineBorder(New NStroke(1, NColor.Green, ENDashStyle.Dash))))
            table.Add(CreateBorderedWidget("Inner Outline Border with Rounding", NBorder.CreateInnerOutlineBorder(New NStroke(1, NColor.Green, ENDashStyle.Dash), 10)))

            ' Double border
            table.Add(CreateBorderedWidget("Double Border", NBorder.CreateDoubleBorder(NColor.Blue)))
            table.Add(CreateBorderedWidget("Double Border with Two Colors", NBorder.CreateDoubleBorder(NColor.Blue, NColor.Red)))
            table.Add(CreateBorderedWidget("Double Border with Two Colors and Rounding", NBorder.CreateDoubleBorder(NColor.Blue, NColor.Red, 10, 12)))

            ' Two color borders
            table.Add(CreateBorderedWidget("Two Colors Border", NBorder.CreateTwoColorBorder(NColor.Blue, NColor.Red)))
            table.Add(CreateBorderedWidget("Two Colors Border with Rounding", NBorder.CreateTwoColorBorder(NColor.Blue, NColor.Red, 10, 12)))

            ' Three color borders
            table.Add(CreateBorderedWidget("Three Colors Border", NBorder.CreateThreeColorBorder(NColor.Red, NColor.Green, NColor.Blue)))
            table.Add(CreateBorderedWidget("Three Colors Border with Rounding", NBorder.CreateThreeColorBorder(NColor.Red, NColor.Green, NColor.Blue, 10, 12)))
            Return table
        End Function

        Protected Overrides Function CreateExampleControls() As NWidget
            Return Nothing
        End Function

        Protected Overrides Function GetExampleDescription() As String
            Return "
<p>
	This example demonstrates some of the static methods of NBorder that help you quickly create commonly used types of borders.
</p>
"
        End Function

#End Region

#Region "Implementation"

        ''' <summary>
        ''' Creates a simple label that demonstrates the specified border.
        ''' </summary>
        ''' <paramname="text"></param>
        ''' <paramname="border"></param>
        ''' <returns></returns>
        Private Function CreateBorderedWidget(ByVal text As String, ByVal border As NBorder) As NWidget
            Dim label As NLabel = New NLabel(text)
            label.HorizontalPlacement = ENHorizontalPlacement.Fit
            label.VerticalPlacement = ENVerticalPlacement.Fit
            label.Padding = New NMargins(10)
            label.Border = border
            label.BorderThickness = New NMargins(5)
            Return label
        End Function

#End Region

#Region "Schema"

        ''' <summary>
        ''' Schema associated with NBordersExample.
        ''' </summary>
        Public Shared ReadOnly NBordersExampleSchema As NSchema

#End Region
    End Class
End Namespace

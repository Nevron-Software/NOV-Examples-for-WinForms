Imports Nevron.Nov.Dom
Imports Nevron.Nov.Layout
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.UI
    Public Class NPageSizeAndOrientationFirstLookExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' Default constructor.
        ''' </summary>
        Public Sub New()
        End Sub
        ''' <summary>
        ''' Static constructor.
        ''' </summary>
        Shared Sub New()
            NPageSizeAndOrientationFirstLookExampleSchema = NSchema.Create(GetType(NPageSizeAndOrientationFirstLookExample), NExampleBase.NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            ' create the host
            Dim stack As NStackPanel = New NStackPanel()
            stack.HorizontalPlacement = ENHorizontalPlacement.Left
            stack.VerticalPlacement = ENVerticalPlacement.Top
            stack.VerticalSpacing = 5

            ' Page size button
            m_PageSizeDD = New NPageSizeDropDown()
            m_PageSizeDD.HorizontalPlacement = ENHorizontalPlacement.Left
            AddHandler m_PageSizeDD.SelectedPageSizeChanged, AddressOf OnPageSizeDDSelectedPageSizeChanged
            stack.Add(m_PageSizeDD)

            ' Page orientation button
            m_PageOrientationDD = New NPageOrientationDropDown()
            AddHandler m_PageOrientationDD.SelectedPageOrientationChanged, AddressOf OnPageOrientationDDSelectedPageOrientationChanged
            stack.Add(m_PageOrientationDD)
            Return stack
        End Function

        Protected Overrides Function CreateExampleControls() As NWidget
            Dim stack As NStackPanel = New NStackPanel()
            stack.FillMode = ENStackFillMode.Last
            stack.FitMode = ENStackFitMode.Last
            Dim lookComboBox As NComboBox = New NComboBox()
            lookComboBox.FillFromEnum(Of ENExtendedLook)()
            AddHandler lookComboBox.SelectedIndexChanged, AddressOf OnLookComboBoxSelectedIndexChanged
            stack.Add(NPairBox.Create("Look:", lookComboBox))

            ' Add the events log
            m_EventsLog = New NExampleEventsLog()
            stack.Add(m_EventsLog)
            Return stack
        End Function

        Protected Overrides Function GetExampleDescription() As String
            Return "<p>This example demonstrates the Page Size selection drop down.</p>"
        End Function

#End Region

#Region "Event Handlers"

        Private Sub OnPageOrientationDDSelectedPageOrientationChanged(ByVal arg As NValueChangeEventArgs)
            m_EventsLog.LogEvent("Selected page orientation changed to: " & m_PageOrientationDD.SelectedPageOrientation.ToString())
        End Sub

        Private Sub OnPageSizeDDSelectedPageSizeChanged(ByVal arg As NValueChangeEventArgs)
            m_EventsLog.LogEvent("Selected page size changed to: " & m_PageSizeDD.SelectedPageSize.ToString())
        End Sub

        Private Sub OnLookComboBoxSelectedIndexChanged(ByVal arg As NValueChangeEventArgs)
            Dim look As ENExtendedLook = arg.NewValue
            NStylePropertyEx.SetExtendedLook(m_PageSizeDD, look)
            NStylePropertyEx.SetExtendedLook(m_PageOrientationDD, look)
        End Sub

#End Region

#Region "Fields"

        Private m_PageSizeDD As NPageSizeDropDown
        Private m_PageOrientationDD As NPageOrientationDropDown
        Private m_EventsLog As NExampleEventsLog

#End Region

#Region "Schema"

        ''' <summary>
        ''' Schema associated with NPageSizeAndOrientationFirstLookExample.
        ''' </summary>
        Public Shared ReadOnly NPageSizeAndOrientationFirstLookExampleSchema As NSchema

#End Region
    End Class
End Namespace

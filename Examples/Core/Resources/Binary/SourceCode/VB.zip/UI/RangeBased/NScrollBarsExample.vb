Imports Nevron.Nov.Dom
Imports Nevron.Nov.Editors
Imports Nevron.Nov.Layout
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.UI
    Public Class NScrollBarsExample
        Inherits NExampleBase
#Region "Constructors"

        Public Sub New()
        End Sub

        Shared Sub New()
            NScrollBarsExampleSchema = NSchema.Create(GetType(NScrollBarsExample), NExampleBase.NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            ' create the root tab
            Dim stack As NStackPanel = New NStackPanel()
            stack.FillMode = ENStackFillMode.Last
            stack.FitMode = ENStackFitMode.Last

            ' create the HScrollBar
            m_HScrollBar = New NHScrollBar()
            m_HScrollBar.VerticalPlacement = ENVerticalPlacement.Top
            AddHandler m_HScrollBar.StartScrolling, New [Function](Of NEventArgs)(AddressOf OnScrollBarStartScrolling)
            AddHandler m_HScrollBar.ValueChanged, New [Function](Of NValueChangeEventArgs)(AddressOf OnScrollBarValueChanged)
            AddHandler m_HScrollBar.EndScrolling, New [Function](Of NEventArgs)(AddressOf OnScrollBarEndScrolling)
            stack.Add(New NGroupBox("Horizontal", m_HScrollBar))

            ' create the VScrollBar
            m_VScrollBar = New NVScrollBar()
            m_VScrollBar.HorizontalPlacement = ENHorizontalPlacement.Left
            AddHandler m_VScrollBar.StartScrolling, New [Function](Of NEventArgs)(AddressOf OnScrollBarStartScrolling)
            AddHandler m_VScrollBar.ValueChanged, New [Function](Of NValueChangeEventArgs)(AddressOf OnScrollBarValueChanged)
            AddHandler m_VScrollBar.EndScrolling, New [Function](Of NEventArgs)(AddressOf OnScrollBarEndScrolling)
            stack.Add(New NGroupBox("Vertical", m_VScrollBar))
            Return stack
        End Function

        Protected Overrides Function CreateExampleControls() As NWidget
            Dim stack As NStackPanel = New NStackPanel()
            stack.FillMode = ENStackFillMode.Last
            stack.FitMode = ENStackFitMode.Last

            ' Create a tab
            Dim tab As NTab = New NTab()
            stack.Add(tab)
            Dim properties = New NProperty() {NInputElement.EnabledProperty, NRangeBase.ValueProperty, NScrollBar.SmallChangeProperty, NScrollBar.LargeChangeProperty, NScrollBar.SnappingStepProperty, NRangeBase.MinimumProperty, NRangeBase.MaximumProperty}

            ' Create the Horizontal scrollbar properties
            Dim hsbStack As NStackPanel = New NStackPanel()
            Dim editors = NDesigner.GetDesigner(m_HScrollBar).CreatePropertyEditors(m_HScrollBar, properties)

            For i = 0 To editors.Count - 1
                hsbStack.Add(editors(i))
            Next

            tab.TabPages.Add(New NTabPage("Horizontal", hsbStack))

            ' Create the Vertical scrollbar properties
            Dim vsbStack As NStackPanel = New NStackPanel()
            editors = NDesigner.GetDesigner(m_VScrollBar).CreatePropertyEditors(m_VScrollBar, properties)

            For i = 0 To editors.Count - 1
                vsbStack.Add(editors(i))
            Next

            tab.TabPages.Add(New NTabPage("Vertical", vsbStack))

            ' Add events log
            m_EventsLog = New NExampleEventsLog()
            stack.Add(m_EventsLog)
            Return New NUniSizeBoxGroup(stack)
        End Function

        Protected Overrides Function GetExampleDescription() As String
            Return "
<p>
	This example demonstrates how to create and use scrollbars. Scrollbars are range based widgets, which come in handy
	when you need to display large content in a limited area on screen. The scrollbars let the user change the currently
	visible part of this large content by dragging a thumb or clicking on an arrow button. The scrollbars can be horizontal
	and vertical and expose a set of properties, which you can use to control their appearance and behavior.
</p>
"
        End Function

#End Region

#Region "Event Handlers"

        Private Sub OnScrollBarStartScrolling(ByVal arg1 As NEventArgs)
            m_EventsLog.LogEvent("Start Scrolling")
        End Sub

        Private Sub OnScrollBarEndScrolling(ByVal arg1 As NEventArgs)
            m_EventsLog.LogEvent("End Scrolling")
        End Sub

        Private Sub OnScrollBarValueChanged(ByVal args As NValueChangeEventArgs)
            m_EventsLog.LogEvent("Value: " & args.NewValue.ToString())
        End Sub

#End Region

#Region "Fields"

        Private m_EventsLog As NExampleEventsLog
        Private m_HScrollBar As NHScrollBar
        Private m_VScrollBar As NVScrollBar

#End Region

#Region "Schema"

        ''' <summary>
        ''' Schema associated with NScrollBarsExample.
        ''' </summary>
        Public Shared ReadOnly NScrollBarsExampleSchema As NSchema

#End Region
    End Class
End Namespace

Imports Nevron.Nov.Editors
Imports Nevron.Nov.Dom
Imports Nevron.Nov.Layout
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.UI
    Public Class NNumericUpDownExample
        Inherits NExampleBase
#Region "Constructors"

        Public Sub New()
        End Sub
        Shared Sub New()
            NNumericUpDownExampleSchema = NSchema.Create(GetType(NNumericUpDownExample), NExampleBase.NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            Dim stack As NStackPanel = New NStackPanel()

            m_NumericUpDown = New NNumericUpDown()
            m_NumericUpDown.HorizontalPlacement = ENHorizontalPlacement.Left
            m_NumericUpDown.Minimum = 0
            m_NumericUpDown.Maximum = 100
            m_NumericUpDown.Value = 50
            m_NumericUpDown.Step = 1
            m_NumericUpDown.DecimalPlaces = 2
            m_NumericUpDown.ValueChanged += New [Function](Of NValueChangeEventArgs)(AddressOf OnValueChanged)

            stack.Add(m_NumericUpDown)
            Return stack
        End Function
        Protected Overrides Function CreateExampleControls() As NWidget
            Dim editors = NDesigner.GetDesigner(m_NumericUpDown).CreatePropertyEditors(m_NumericUpDown, NInputElement.EnabledProperty, NRangeBase.ValueProperty, NRangeBase.MinimumProperty, NRangeBase.MaximumProperty, NNumericUpDown.StepProperty, NNumericUpDown.DecimalPlacesProperty, NNumericUpDown.WheelIncDecModeProperty, NNumericUpDown.TextSelectionModeProperty)

            Dim stack As NStackPanel = New NStackPanel()
            stack.FillMode = ENStackFillMode.Last
            stack.FitMode = ENStackFitMode.Last

            For i = 0 To editors.Count - 1
                stack.Add(editors(i))
            Next

            m_EventsLog = New NExampleEventsLog()
            stack.Add(m_EventsLog)

            Return New NUniSizeBoxGroup(stack)
        End Function
        Protected Overrides Function GetExampleDescription() As String
            Return "
<p>
	This example demonstrates how to create and use numeric up downs. The numeric up down widget
	consists of a text box and a spinner with up and down buttons. The text box shows and also
	can be used to edit the current numeric value and accepts only digits and the decimal separator.
	The current value is stored in the <b>Value</b> property. The <b>Step</b> property defines how
	much to increase/decrease the current value when the user clicks on the increase/decrease spinner
	button or presses the up/down key from the keyboard while the numeric up down text box is focused.
	The <b>TextSelectionMode</b> controls how the text selection mode is changed when the user presses 
	the numeric up-down spin buttons.
</p>
" End Function

#End Region

#Region "Event Handlers"

        Private Sub OnValueChanged(ByVal args As NValueChangeEventArgs)
            m_EventsLog.LogEvent("New value: " & args.NewValue.ToString())
        End Sub

#End Region

#Region "Fields"

        Private m_NumericUpDown As NNumericUpDown
        Private m_EventsLog As NExampleEventsLog

#End Region

#Region "Schema"

        Public Shared ReadOnly NNumericUpDownExampleSchema As NSchema

#End Region
    End Class
End Namespace

Imports Nevron.Nov.Dom
Imports Nevron.Nov.Layout
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.UI
    Public Class NMeasureUpDownExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' Default constructor.
        ''' </summary>
        Public Sub New()
        End Sub
        ''' <summary>
        ''' Static constructor.
        ''' </summary>
        Shared Sub New()
            NMeasureUpDownExampleSchema = NSchema.Create(GetType(NMeasureUpDownExample), NExampleBase.NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            m_StackPanel = New NStackPanel()
            m_StackPanel.HorizontalPlacement = ENHorizontalPlacement.Left
            m_StackPanel.VerticalSpacing = 5
            m_StackPanel.Add(CreatePairBox("Angle:", NUnit.Radian, NUnit.Degree, NUnit.Grad))
            m_StackPanel.Add(CreatePairBox("SI Length:", NUnit.Millimeter, NUnit.Centimeter, NUnit.Meter, NUnit.Kilometer))
            m_StackPanel.Add(CreatePairBox("Imperial Length:", NUnit.Inch, NUnit.Foot, NUnit.Yard, NUnit.Mile))
            m_StackPanel.Add(CreatePairBox("Mixed Length:", NUnit.Millimeter, NUnit.Centimeter, NUnit.Meter, NUnit.Kilometer, NUnit.Inch, NUnit.Foot, NUnit.Yard, NUnit.Mile))
            m_StackPanel.Add(CreatePairBox("Graphics Length:", NUnit.Millimeter, NUnit.Inch, NUnit.DIP, NUnit.Point))
            Return New NUniSizeBoxGroup(m_StackPanel)
        End Function

        Protected Overrides Function CreateExampleControls() As NWidget
            Dim stack As NStackPanel = New NStackPanel()
            stack.FillMode = ENStackFillMode.Last
            stack.FitMode = ENStackFitMode.Last
            Dim enabledCheckBox As NCheckBox = New NCheckBox("Enabled", True)
            enabledCheckBox.HorizontalPlacement = ENHorizontalPlacement.Left
            enabledCheckBox.VerticalPlacement = ENVerticalPlacement.Top
            AddHandler enabledCheckBox.CheckedChanged, New [Function](Of NValueChangeEventArgs)(AddressOf OnEnabledCheckBoxCheckedChanged)
            stack.Add(enabledCheckBox)
            m_EventsLog = New NExampleEventsLog()
            stack.Add(m_EventsLog)
            Return stack
        End Function

        Protected Overrides Function GetExampleDescription() As String
            Return "
<p>
	This example demonstrates how to create and use measure up downs. The measure up down extends the functionality
	of the numeric up down by adding a combo box for selecting a unit. If the units can be converted to each other,
	when the user selects a new unit from the unit combo box, the value will be automatically converted. The <b>Unit</b>
	property determines the currently selected measurement unit.
</p>
"
        End Function

#End Region

#Region "Implementation"

        Private Function CreatePairBox(ByVal text As String, ParamArray units As NUnit()) As NPairBox
            Dim label As NLabel = New NLabel(text)
            label.HorizontalPlacement = ENHorizontalPlacement.Right
            label.VerticalPlacement = ENVerticalPlacement.Center
            Dim measureUpDown As NMeasureUpDown = New NMeasureUpDown(units)
            measureUpDown.Minimum = Double.MinValue
            measureUpDown.Maximum = Double.MaxValue
            measureUpDown.Value = 1
            measureUpDown.DecimalPlaces = 3
            measureUpDown.UnitComboBox.PreferredWidth = 40
            AddHandler measureUpDown.ValueChanged, AddressOf OnMeasureUpDownValueChanged
            Dim pairBox As NPairBox = New NPairBox(label, measureUpDown, True)
            pairBox.Spacing = 3
            Return pairBox
        End Function

#End Region

#Region "Event Handlers"

        Private Sub OnMeasureUpDownValueChanged(ByVal args As NValueChangeEventArgs)
            Dim measureUpDown = CType(args.TargetNode, NMeasureUpDown)
            Dim value As Double = args.NewValue
            Dim unit = measureUpDown.SelectedUnit
            Dim unitString As String = unit.ToString()

            If value <> 1 Then
                ' Make the unit string plural
                If unit = NUnit.Inch Then
                    unitString = "inches"
                ElseIf unit = NUnit.Foot Then
                    unitString = "feet"
                Else
                    unitString += "s"
                End If
            End If

            ' Log the event
            m_EventsLog.LogEvent("New value: " & value.ToString() & " " & unitString)
        End Sub

        Private Sub OnEnabledCheckBoxCheckedChanged(ByVal args As NValueChangeEventArgs)
            m_StackPanel.Enabled = CBool(args.NewValue)
        End Sub

#End Region

#Region "Fields"

        Private m_StackPanel As NStackPanel
        Private m_EventsLog As NExampleEventsLog

#End Region

#Region "Schema"

        ''' <summary>
        ''' Schema associated with NMeasureUpDownExample.
        ''' </summary>
        Public Shared ReadOnly NMeasureUpDownExampleSchema As NSchema

#End Region

    End Class
End Namespace

Imports Nevron.Nov.Dom
Imports Nevron.Nov.Editors
Imports Nevron.Nov.Layout
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.UI
    Public Class NSliderExample
        Inherits NExampleBase
#Region "Constructors"

        Public Sub New()
        End Sub

        Shared Sub New()
            NSliderExampleSchema = NSchema.Create(GetType(NSliderExample), NExampleBase.NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            Dim stack As NStackPanel = New NStackPanel()
            Dim gbh As NGroupBox = New NGroupBox("Horizontal")
            stack.Add(gbh)
            m_HSlider = New NSlider()
            gbh.Content = m_HSlider
            m_HSlider.HorizontalPlacement = ENHorizontalPlacement.Left
            m_HSlider.PreferredWidth = 300
            AddHandler m_HSlider.ValueChanged, New [Function](Of NValueChangeEventArgs)(AddressOf OnSliderValueChanged)
            Dim gbv As NGroupBox = New NGroupBox("Vertical")
            stack.Add(gbv)
            m_VSlider = New NSlider()
            gbv.Content = m_VSlider
            m_VSlider.Orientation = ENHVOrientation.Vertical
            m_VSlider.PreferredHeight = 300
            m_VSlider.HorizontalPlacement = ENHorizontalPlacement.Left
            AddHandler m_VSlider.ValueChanged, New [Function](Of NValueChangeEventArgs)(AddressOf OnSliderValueChanged)
            Return stack
        End Function

        Protected Overrides Function CreateExampleControls() As NWidget
            Dim stack As NStackPanel = New NStackPanel()
            stack.FillMode = ENStackFillMode.Last
            stack.FitMode = ENStackFitMode.Last

            ' Create a tab
            Dim tab As NTab = New NTab()
            stack.Add(tab)
            Dim properties = New NProperty() {NInputElement.EnabledProperty, NRangeBase.ValueProperty, NSlider.LargeChangeProperty, NSlider.SnappingStepProperty, NRangeBase.MinimumProperty, NRangeBase.MaximumProperty, NSlider.TicksPlacementProperty, NSlider.TicksIntervalProperty, NSlider.TicksLengthProperty}

            ' Create the Horizontal slider properties
            Dim hsbStack As NStackPanel = New NStackPanel()
            Dim editors = NDesigner.GetDesigner(m_HSlider).CreatePropertyEditors(m_HSlider, properties)

            For i = 0 To editors.Count - 1
                hsbStack.Add(editors(i))
            Next

            tab.TabPages.Add(New NTabPage("Horizontal", hsbStack))

            ' Create the Vertical slider properties
            Dim vsbStack As NStackPanel = New NStackPanel()
            editors = NDesigner.GetDesigner(m_VSlider).CreatePropertyEditors(m_VSlider, properties)

            For i = 0 To editors.Count - 1
                vsbStack.Add(editors(i))
            Next

            tab.TabPages.Add(New NTabPage("Vertical", vsbStack))

            ' Add events log
            m_EventsLog = New NExampleEventsLog()
            stack.Add(m_EventsLog)
            Return New NUniSizeBoxGroup(stack)
        End Function

        Protected Overrides Function GetExampleDescription() As String
            Return "
<p>
	This example demonstrates how to create and use sliders. The slider is a widget that
	lets the user select a distinct value in a given range by dragging a thumb. You can
	specify whether the slider is horizontally or vertically oriented through its
	<b>Orientation</b> property. To control the tick visibility and placement use the
	<b>TicksLength</b>, <b>TicksInterval</b> and <b>TicksPlacement</b> properties.
</p>
"
        End Function

#End Region

#Region "Event Handlers"

        Private Sub OnSliderValueChanged(ByVal args As NValueChangeEventArgs)
            Dim text = If(args.TargetNode Is m_HSlider, "Horizontal: ", "Vertical: ")
            text += args.NewValue.ToString()
            m_EventsLog.LogEvent(text)
        End Sub

#End Region

#Region "Fields"

        Private m_HSlider As NSlider
        Private m_VSlider As NSlider
        Private m_EventsLog As NExampleEventsLog

#End Region

#Region "Schema"

        Public Shared ReadOnly NSliderExampleSchema As NSchema

#End Region
    End Class
End Namespace

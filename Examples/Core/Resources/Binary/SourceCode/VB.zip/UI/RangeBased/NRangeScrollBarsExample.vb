Imports Nevron.Nov.Dom
Imports Nevron.Nov.Editors
Imports Nevron.Nov.Layout
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.UI
    Public Class NRangeScrollBarsExample
        Inherits NExampleBase
#Region "Constructors"

        Public Sub New()
        End Sub

        Shared Sub New()
            NRangeScrollBarsExampleSchema = NSchema.Create(GetType(NRangeScrollBarsExample), NExampleBase.NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            ' Create a stack for the scroll bars
            Dim stack As NStackPanel = New NStackPanel()
            stack.FillMode = ENStackFillMode.Last
            stack.FitMode = ENStackFitMode.Last

            ' Create the HScrollBar
            m_HScrollBar = New NHRangeScrollBar()
            m_HScrollBar.BeginValue = 20
            m_HScrollBar.EndValue = 40
            m_HScrollBar.VerticalPlacement = ENVerticalPlacement.Top
            Me.m_HScrollBar.BeginValueChanged += AddressOf OnScrollBarValueChanged
            Me.m_HScrollBar.EndValueChanged += AddressOf OnScrollBarValueChanged
            stack.Add(New NGroupBox("Horizontal", m_HScrollBar))

            ' Create the VScrollBar
            m_VScrollBar = New NVRangeScrollBar()
            m_VScrollBar.BeginValue = 20
            m_VScrollBar.EndValue = 40
            m_VScrollBar.HorizontalPlacement = ENHorizontalPlacement.Left
            Me.m_VScrollBar.BeginValueChanged += AddressOf OnScrollBarValueChanged
            Me.m_VScrollBar.EndValueChanged += AddressOf OnScrollBarValueChanged
            stack.Add(New NGroupBox("Vertical", m_VScrollBar))

            Return stack
        End Function
        Protected Overrides Function CreateExampleControls() As NWidget
            Dim stack As NStackPanel = New NStackPanel()
            stack.FillMode = ENStackFillMode.Last
            stack.FitMode = ENStackFitMode.Last

            ' Create a tab
            Dim tab As NTab = New NTab()
            stack.Add(tab)

            ' Create the Horizontal scrollbar properties
            Dim hsbStack As NStackPanel = New NStackPanel()
            Dim editors = NDesigner.GetDesigner(m_HScrollBar).CreatePropertyEditors(m_HScrollBar, NInputElement.EnabledProperty, NHRangeScrollBar.BeginValueProperty, NHRangeScrollBar.EndValueProperty, NHRangeScrollBar.SmallChangeProperty, NHRangeScrollBar.SnappingStepProperty, NRangeBase.MinimumProperty, NRangeBase.MaximumProperty)

            For i = 0 To editors.Count - 1
                hsbStack.Add(editors(i))
            Next

            tab.TabPages.Add(New NTabPage("Horizontal", hsbStack))

            ' Create the Vertical scrollbar properties
            Dim vsbStack As NStackPanel = New NStackPanel()
            editors = NDesigner.GetDesigner(m_VScrollBar).CreatePropertyEditors(m_VScrollBar, NInputElement.EnabledProperty, NVRangeScrollBar.BeginValueProperty, NVRangeScrollBar.EndValueProperty, NVRangeScrollBar.SmallChangeProperty, NVRangeScrollBar.SnappingStepProperty, NRangeBase.MinimumProperty, NRangeBase.MaximumProperty)

            For i = 0 To editors.Count - 1
                vsbStack.Add(editors(i))
            Next

            tab.TabPages.Add(New NTabPage("Vertical", vsbStack))

            ' Add events log
            m_EventsLog = New NExampleEventsLog()
            stack.Add(m_EventsLog)

            Return New NUniSizeBoxGroup(stack)
        End Function
        Protected Overrides Function GetExampleDescription() As String
            Return "
<p>
	This example demonstrates how to create and use range scroll bars. Range scroll bars are range based widgets, which
	are used for selecting a range defined by a begin and an end value. They can be horizontal and vertical and expose
	a set of properties, which you can use to control their appearance and behavior.
</p>
" End Function

#End Region

#Region "Event Handlers"

        Private Sub OnScrollBarValueChanged(ByVal args As NValueChangeEventArgs)
            Dim text As String
            If args.TargetNode Is m_HScrollBar Then
                text = "Horizontal Range: " & m_HScrollBar.BeginValue.ToString("0.###") & " - " & m_HScrollBar.EndValue.ToString("0.###")
            Else
                text = "Vertical Range: " & m_VScrollBar.BeginValue.ToString("0.###") & " - " & m_VScrollBar.EndValue.ToString("0.###")
            End If

            m_EventsLog.LogEvent(text)
        End Sub

#End Region

#Region "Fields"

        Private m_EventsLog As NExampleEventsLog
        Private m_HScrollBar As NHRangeScrollBar
        Private m_VScrollBar As NVRangeScrollBar

#End Region

#Region "Schema"

        ''' <summary>
        ''' Schema associated with NRangeScrollBarsExample.
        ''' </summary>
        Public Shared ReadOnly NRangeScrollBarsExampleSchema As NSchema

#End Region
    End Class
End Namespace

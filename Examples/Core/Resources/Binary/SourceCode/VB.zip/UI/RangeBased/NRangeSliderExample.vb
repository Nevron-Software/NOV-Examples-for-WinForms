Imports Nevron.Nov.Dom
Imports Nevron.Nov.Editors
Imports Nevron.Nov.Layout
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.UI
    Public Class NRangeSliderExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' Default constructor.
        ''' </summary>
        Public Sub New()
        End Sub

        ''' <summary>
        ''' Static constructor.
        ''' </summary>
        Shared Sub New()
            NRangeSliderExampleSchema = NSchema.Create(GetType(NRangeSliderExample), NExampleBase.NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            Dim stack As NStackPanel = New NStackPanel()
            m_HSlider = New NRangeSlider()
            m_HSlider.BeginValue = 20
            m_HSlider.EndValue = 40
            m_HSlider.HorizontalPlacement = ENHorizontalPlacement.Left
            m_HSlider.PreferredWidth = 300
            AddHandler m_HSlider.BeginValueChanged, New [Function](Of NValueChangeEventArgs)(AddressOf OnSliderValueChanged)
            AddHandler m_HSlider.EndValueChanged, New [Function](Of NValueChangeEventArgs)(AddressOf OnSliderValueChanged)
            stack.Add(New NGroupBox("Horizontal", m_HSlider))
            m_VSlider = New NRangeSlider()
            m_VSlider.BeginValue = 20
            m_VSlider.EndValue = 40
            m_VSlider.Orientation = ENHVOrientation.Vertical
            m_VSlider.PreferredHeight = 300
            m_VSlider.HorizontalPlacement = ENHorizontalPlacement.Left
            AddHandler m_VSlider.BeginValueChanged, New [Function](Of NValueChangeEventArgs)(AddressOf OnSliderValueChanged)
            AddHandler m_VSlider.EndValueChanged, New [Function](Of NValueChangeEventArgs)(AddressOf OnSliderValueChanged)
            stack.Add(New NGroupBox("Vertical", m_VSlider))
            Return stack
        End Function

        Protected Overrides Function CreateExampleControls() As NWidget
            Dim stack As NStackPanel = New NStackPanel()
            stack.FillMode = ENStackFillMode.Last
            stack.FitMode = ENStackFitMode.Last

            ' Create a tab
            Dim tab As NTab = New NTab()
            stack.Add(tab)
            Dim properties = New NProperty() {NInputElement.EnabledProperty, NRangeSlider.BeginValueProperty, NRangeSlider.EndValueProperty, NRangeSlider.LargeChangeProperty, NRangeSlider.SnappingStepProperty, NRangeBase.MinimumProperty, NRangeBase.MaximumProperty, NSlider.TicksPlacementProperty, NSlider.TicksIntervalProperty, NSlider.TicksLengthProperty}

            ' Create the Horizontal slider properties
            Dim hsbStack As NStackPanel = New NStackPanel()
            Dim editors = NDesigner.GetDesigner(m_HSlider).CreatePropertyEditors(m_HSlider, properties)

            For i = 0 To editors.Count - 1
                hsbStack.Add(editors(i))
            Next

            tab.TabPages.Add(New NTabPage("Horzontal", hsbStack))

            ' Create the Vertical slider properties
            Dim vsbStack As NStackPanel = New NStackPanel()
            editors = NDesigner.GetDesigner(m_VSlider).CreatePropertyEditors(m_VSlider, properties)

            For i = 0 To editors.Count - 1
                vsbStack.Add(editors(i))
            Next

            tab.TabPages.Add(New NTabPage("Vertical", vsbStack))

            ' Add events log
            m_EventsLog = New NExampleEventsLog()
            stack.Add(m_EventsLog)
            Return New NUniSizeBoxGroup(stack)
        End Function

        Protected Overrides Function GetExampleDescription() As String
            Return "
<p>
	This example demonstrates how to create and use range sliders. The range slider is a widget that
	lets the user select a range defined by a begin and end value in a given range by dragging thumbs.
	You can specify whether the slider is horizontally or vertically oriented through its
	<b>Orientation</b> property. To control the tick visibility and placement use the
	<b>TicksLength</b>, <b>TicksInterval</b> and <b>TicksPlacement</b> properties.
</p>
"
        End Function

#End Region

#Region "Event Handlers"

        Private Sub OnSliderValueChanged(ByVal args As NValueChangeEventArgs)
            Dim slider = CType(args.TargetNode, NRangeSlider)
            Dim text = If(slider Is m_HSlider, "Horizontal Range: ", "Vertical Range: ")
            text += slider.BeginValue.ToString("0.###") & " - " & slider.EndValue.ToString("0.###")
            m_EventsLog.LogEvent(text)
        End Sub

#End Region

#Region "Fields"

        Private m_HSlider As NRangeSlider
        Private m_VSlider As NRangeSlider
        Private m_EventsLog As NExampleEventsLog

#End Region

#Region "Schema"

        ''' <summary>
        ''' Schema associated with NRangeSliderExample.
        ''' </summary>
        Public Shared ReadOnly NRangeSliderExampleSchema As NSchema

#End Region
    End Class
End Namespace

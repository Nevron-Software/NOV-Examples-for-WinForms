Imports System
Imports System.Globalization

Imports Nevron.Nov.Dom
Imports Nevron.Nov.Graphics
Imports Nevron.Nov.Layout
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.UI
    Public Class NPredefinedSymbolsExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' Default constructor.
        ''' </summary>
        Public Sub New()
        End Sub

        ''' <summary>
        ''' Static constructor.
        ''' </summary>
        Shared Sub New()
            NPredefinedSymbolsExampleSchema = NSchema.Create(GetType(NPredefinedSymbolsExample), NExampleBase.NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            m_SymbolsTable = New NTableFlowPanel()
            m_SymbolsTable.BackgroundFill = New NColorFill(NColor.White)
            m_SymbolsTable.HorizontalSpacing = NDesign.HorizontalSpacing * 3
            m_SymbolsTable.VerticalSpacing = NDesign.VerticalSpacing * 3
            m_SymbolsTable.Direction = ENHVDirection.LeftToRight
            m_SymbolsTable.MaxOrdinal = 4
            m_SymbolsTable.Padding = New NMargins(NDesign.HorizontalSpacing, NDesign.VerticalSpacing, NDesign.HorizontalSpacing * 6, NDesign.VerticalSpacing)

            RecreateSymbols()

            Dim scrollContent As NScrollContent = New NScrollContent(m_SymbolsTable)
            scrollContent.HorizontalPlacement = ENHorizontalPlacement.Left
            Return scrollContent
        End Function
        Protected Overrides Function CreateExampleControls() As NWidget
            Dim stack As NStackPanel = New NStackPanel()

            ' Create the color box
            m_ColorBox = New NColorBox()
            m_ColorBox.SelectedColor = DefaultSymbolColor
            Me.m_ColorBox.SelectedColorChanged += AddressOf OnColorBoxSelectedColorChanged
            stack.Add(NPairBox.Create("Color:", m_ColorBox))

            ' Create the size radio button group
            Dim radioStack As NStackPanel = New NStackPanel()
            Dim size = InitialSize
            For i = 0 To 3
                Dim sizeStr = size.ToString(CultureInfo.InvariantCulture)
                Dim radioButton As NRadioButton = New NRadioButton(sizeStr & "x" & sizeStr)
                radioStack.Add(radioButton)
                size *= 2
            Next

            m_RadioGroup = New NRadioButtonGroup(radioStack)
            m_RadioGroup.SelectedIndex = 0
            Me.m_RadioGroup.SelectedIndexChanged += AddressOf OnRadioGroupSelectedIndexChanged
            Dim pairBox = NPairBox.Create("Size:", m_RadioGroup)
            pairBox.Box1.VerticalPlacement = ENVerticalPlacement.Top
            stack.Add(pairBox)

            Return New NUniSizeBoxGroup(stack)
        End Function

        Protected Overrides Function GetExampleDescription() As String
            Dim symbolCount As Integer = NEnum.GetValues(Of ENSymbolShape)().Length
            Dim symbolCountStr = symbolCount.ToString(CultureInfo.InvariantCulture)

            Return "
<p>
	Nevron Open Vision provides support for drawing of vector based shapes called symbols. The advantage of such vector
	based shapes over regular raster images is that they do not blur and look nice at any size. This example demonstrates
	how to create and use predefined symbols. Nevron Open Vision currently provides support for <b>" & symbolCountStr & "
	predefined symbols</b>. Use the radio buttons on the right to see the symbols at different sizes.
</p>
" End Function

#End Region

#Region "Implementation"

        Private Sub RecreateSymbols()
            Dim color = If(m_ColorBox IsNot Nothing, m_ColorBox.SelectedColor, DefaultSymbolColor)
            Dim length = InitialSize * Math.Pow(2, If(m_RadioGroup IsNot Nothing, m_RadioGroup.SelectedIndex, 0))
            Dim size As NSize = New NSize(length, length)

            m_SymbolsTable.Clear()

            Dim symbolShapes As ENSymbolShape() = NEnum.GetValues(Of ENSymbolShape)()
            Dim count As Integer = symbolShapes.Length / 2 + symbolShapes.Length Mod 2
            For i = 0 To count - 1
                ' Add a symbol box to the first column
                Dim column1Index = i
                AddSymbolBox(symbolShapes(column1Index), size, color)

                ' Add a symbol box to the second column
                Dim column2Index = count + i
                If column2Index < symbolShapes.Length Then
                    Dim symbolBox = AddSymbolBox(symbolShapes(column2Index), size, color)
                    symbolBox.Margins = New NMargins(NDesign.HorizontalSpacing * 10, 0, 0, 0)
                End If
            Next
        End Sub
        Private Function AddSymbolBox(ByVal symbolShape As ENSymbolShape, ByVal size As NSize, ByVal color As NColor) As NSymbolBox
            Dim symbol = NSymbol.Create(symbolShape, size, color)
            Dim symbolBox As NSymbolBox = New NSymbolBox(symbol)
            m_SymbolsTable.Add(symbolBox)

            Dim label As NLabel = New NLabel(NStringHelpers.InsertSpacesBeforeUppersAndDigits(symbolShape.ToString()))
            label.VerticalPlacement = ENVerticalPlacement.Center
            m_SymbolsTable.Add(label)

            Return symbolBox
        End Function

#End Region

#Region "Event Handlers"

        Private Sub OnColorBoxSelectedColorChanged(ByVal arg As NValueChangeEventArgs)
            RecreateSymbols()
        End Sub
        Private Sub OnRadioGroupSelectedIndexChanged(ByVal arg As NValueChangeEventArgs)
            RecreateSymbols()
        End Sub

#End Region

#Region "Fields"

        Private m_SymbolsTable As NTableFlowPanel
        Private m_ColorBox As NColorBox
        Private m_RadioGroup As NRadioButtonGroup

#End Region

#Region "Schema"

        ''' <summary>
        ''' Schema associated with NPredefinedSymbolsExample.
        ''' </summary>
        Public Shared ReadOnly NPredefinedSymbolsExampleSchema As NSchema

#End Region

#Region "Constants"

        Private Const InitialSize As Double = 16
        Private Shared ReadOnly DefaultSymbolColor As NColor = NColor.MediumBlue

#End Region
    End Class
End Namespace

Imports System
Imports Nevron.Nov.Editors
Imports Nevron.Nov.Dom
Imports Nevron.Nov.Graphics
Imports Nevron.Nov.UI
Imports Nevron.Nov.Layout

Namespace Nevron.Nov.Examples.UI
    Public Class NFlexBoxPanelExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' Default constructor.
        ''' </summary>
        Public Sub New()
        End Sub
        ''' <summary>
        ''' Static constructor.
        ''' </summary>
        Shared Sub New()
            NFlexBoxPanelExampleSchema = NSchema.Create(GetType(NFlexBoxPanelExample), NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            Dim labelPadding As NMargins = New NMargins(2)
            m_FlexBoxPanel = New NFlexBoxPanel()
            m_FlexBoxPanel.HorizontalPlacement = ENHorizontalPlacement.Left
            m_FlexBoxPanel.VerticalPlacement = ENVerticalPlacement.Top
            m_FlexBoxPanel.PreferredHeight = 200

            ' Set the Grow and Shrink extended properties of the first label explicitly
            Dim label1 As NLabel = New NLabel("Label 1 - Grow: 1, Shrink: 1")
            label1.BackgroundFill = New NColorFill(NColor.Gold)
            label1.Padding = labelPadding
            NFlexBoxLayout.SetGrow(label1, 1)
            NFlexBoxLayout.SetShrink(label1, 1)
            m_FlexBoxPanel.Add(label1)

            ' Pass the values of the Grow and Shrink extended properties of the second label
            ' to the Add method of the panel
            Dim label2 As NLabel = New NLabel("Label 2 - Grow: 3, Shrink: 3")
            label2.BackgroundFill = New NColorFill(NColor.Orange)
            label2.Padding = labelPadding
            m_FlexBoxPanel.Add(label2, 3, 3)

            ' The third label will have the default values for Grow and Shrink - 0
            Dim label3 As NLabel = New NLabel("Label 3 - Grow: 0, Shrink: 0")
            label3.BackgroundFill = New NColorFill(NColor.Red)
            label3.Padding = labelPadding
            m_FlexBoxPanel.Add(label3)
            Return m_FlexBoxPanel
        End Function

        Protected Overrides Function CreateExampleControls() As NWidget
            Dim stack As NStackPanel = New NStackPanel()

            ' properties stack
            Dim editors = NDesigner.GetDesigner(m_FlexBoxPanel).CreatePropertyEditors(m_FlexBoxPanel, NInputElement.EnabledProperty, NWidget.HorizontalPlacementProperty, NWidget.VerticalPlacementProperty, NFlexBoxPanel.DirectionProperty, NFlexBoxPanel.VerticalSpacingProperty, NFlexBoxPanel.HorizontalSpacingProperty, NFlexBoxPanel.UniformWidthsProperty, NFlexBoxPanel.UniformHeightsProperty)
            Dim propertiesStack As NStackPanel = New NStackPanel()

            For i = 0 To editors.Count - 1
                propertiesStack.Add(editors(i))
            Next

            stack.Add(New NGroupBox("Properties", New NUniSizeBoxGroup(propertiesStack)))

            ' items stack
            Dim itemsStack As NStackPanel = New NStackPanel()
            m_GrowUpDown = New NNumericUpDown(0, 100, 0)
            itemsStack.Add(NPairBox.Create("Grow Factor: ", m_GrowUpDown))
            m_ShrinkUpDown = New NNumericUpDown(0, 100, 0)
            itemsStack.Add(NPairBox.Create("Shrink Factor: ", m_ShrinkUpDown))
            Dim addSmallItemButton As NButton = New NButton("Add Small Item")
            AddHandler addSmallItemButton.Click, New [Function](Of NEventArgs)(AddressOf OnAddSmallItemButtonClick)
            itemsStack.Add(addSmallItemButton)
            Dim addLargeItemButton As NButton = New NButton("Add Large Item")
            AddHandler addLargeItemButton.Click, New [Function](Of NEventArgs)(AddressOf OnAddLargeItemButtonClick)
            itemsStack.Add(addLargeItemButton)
            Dim addRandomItemButton As NButton = New NButton("Add Random Item")
            AddHandler addRandomItemButton.Click, New [Function](Of NEventArgs)(AddressOf OnAddRandomItemButtonClick)
            itemsStack.Add(addRandomItemButton)
            Dim removeAllItemsButton As NButton = New NButton("Remove All Items")
            AddHandler removeAllItemsButton.Click, New [Function](Of NEventArgs)(AddressOf OnRemoveAllItemsButtonClick)
            itemsStack.Add(removeAllItemsButton)
            stack.Add(New NGroupBox("Items", New NUniSizeBoxGroup(itemsStack)))
            Return stack
        End Function

        Protected Overrides Function GetExampleDescription() As String
            Return "
<p>
	This example demonstrates how to create a flexbox layout panel and add widgets to it.
	You can control the parameters of the layout algorithm using the controls on the right.
	The Grow and Shrink factors of the widgets determine the portion of area to use for growing/shrinking.
	They are by default set to 0, which means that the widget will not grow or shrink.
</p>
<p>
	To test how the Grow and Shrink factors affect the layout, click the <b>Remove All Items</b> button
	on the right, then set Grow and Shrink factor and click any of the <b>Add ... Item</b> buttons.
	Then update the Grow and Shrink factor if you want, click any of the <b>Add ... Item</b> buttons again and so on.
</p>
"
        End Function

#End Region

#Region "Implementation"

        Private Sub SetGrowAndShrink(ByVal widget As NWidget)
            Dim grow = m_GrowUpDown.Value

            If grow <> 0 Then
                NFlexBoxLayout.SetGrow(widget, grow)
            End If

            Dim shrink = m_ShrinkUpDown.Value

            If shrink <> 0 Then
                NFlexBoxLayout.SetShrink(widget, shrink)
            End If
        End Sub

#End Region

#Region "Event Handlers"

        Private Sub OnAddSmallItemButtonClick(ByVal args As NEventArgs)
            Dim item As NButton = New NButton("Small " & m_FlexBoxPanel.Count.ToString())
            item.MinSize = New NSize(5, 5)
            item.PreferredSize = New NSize(25, 25)
            SetGrowAndShrink(item)
            m_FlexBoxPanel.Add(item)
        End Sub

        Private Sub OnAddLargeItemButtonClick(ByVal args As NEventArgs)
            Dim item As NButton = New NButton("Large " & m_FlexBoxPanel.Count.ToString())
            item.MinSize = New NSize(20, 20)
            item.PreferredSize = New NSize(60, 60)
            SetGrowAndShrink(item)
            m_FlexBoxPanel.Add(item)
        End Sub

        Private Sub OnAddRandomItemButtonClick(ByVal args As NEventArgs)
            Dim range = 30
            Dim rnd As Random = New Random()
            Dim item As NButton = New NButton("Random " & m_FlexBoxPanel.Count.ToString())
            item.MinSize = New NSize(rnd.Next(range), rnd.Next(range))
            item.PreferredSize = New NSize(rnd.Next(range) + range, rnd.Next(range) + range)
            SetGrowAndShrink(item)
            m_FlexBoxPanel.Add(item)
        End Sub

        Private Sub OnRemoveAllItemsButtonClick(ByVal args As NEventArgs)
            m_FlexBoxPanel.Clear()
        End Sub

#End Region

#Region "Fields"

        Private m_FlexBoxPanel As NFlexBoxPanel
        Private m_GrowUpDown As NNumericUpDown
        Private m_ShrinkUpDown As NNumericUpDown

#End Region

#Region "Schema"

        Public Shared ReadOnly NFlexBoxPanelExampleSchema As NSchema

#End Region
    End Class
End Namespace

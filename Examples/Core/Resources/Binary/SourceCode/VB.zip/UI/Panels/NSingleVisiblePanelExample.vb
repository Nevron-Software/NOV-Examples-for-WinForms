Imports Nevron.Nov.DataStructures
Imports Nevron.Nov.Editors
Imports Nevron.Nov.Dom
Imports Nevron.Nov.Graphics
Imports Nevron.Nov.Layout
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.UI
    Public Class NSingleVisiblePanelExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' Default constructor.
        ''' </summary>
        Public Sub New()
        End Sub
        ''' <summary>
        ''' Static constructor.
        ''' </summary>
        Shared Sub New()
            NSingleVisiblePanelExampleSchema = NSchema.Create(GetType(NSingleVisiblePanelExample), NExampleBase.NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            m_SingleVisiblePanel = New NSingleVisiblePanel()
            m_SingleVisiblePanel.HorizontalPlacement = ENHorizontalPlacement.Left
            m_SingleVisiblePanel.VerticalPlacement = ENVerticalPlacement.Top
            m_SingleVisiblePanel.PreferredWidth = 400
            m_SingleVisiblePanel.SetBorder(1, NColor.Red)

            Dim mainStack As NStackPanel = New NStackPanel()
            m_SingleVisiblePanel.Add(mainStack)

            mainStack.Add(CreateHeaderLabel("Mobile Computers"))

            Dim i = 0, count = MobileComputers.Length

            While i < count
                Dim info = MobileComputers(i)

                ' Create the topic's button
                Dim button As NButton = New NButton(info.Name)
                button.Tag = i + 1
                mainStack.Add(button)

                ' Create and add the topic's content
                m_SingleVisiblePanel.Add(CreateComputerInfoWidget(info))
                i += 1
            End While

            m_SingleVisiblePanel.VisibleIndexChanged += New [Function](Of NValueChangeEventArgs)(AddressOf OnVisibleIndexValueChanged)
            m_SingleVisiblePanel.AddEventHandler(NButtonBase.ClickEvent, New NEventHandler(Of NEventArgs)(New [Function](Of NEventArgs)(AddressOf OnButtonClicked)))

            Return m_SingleVisiblePanel
        End Function
        Protected Overrides Function CreateExampleControls() As NWidget
            Dim stack As NStackPanel = New NStackPanel()
            stack.FillMode = ENStackFillMode.Last
            stack.FitMode = ENStackFitMode.Last

            ' Add the properties group box
            Dim editors As NList(Of NPropertyEditor) = New NList(Of NPropertyEditor)(NDesigner.GetDesigner(m_SingleVisiblePanel).CreatePropertyEditors(m_SingleVisiblePanel, NInputElement.EnabledProperty, NSingleVisiblePanel.SizeToVisibleProperty, NSingleVisiblePanel.VisibleIndexProperty))

            Dim propertiesStack As NStackPanel = New NStackPanel()
            Dim i = 0, count = editors.Count

            While i < count
                stack.Add(editors(i))
                i += 1
            End While

            Dim propertiesGroupBox As NGroupBox = New NGroupBox("Properties", New NUniSizeBoxGroup(propertiesStack))
            stack.Add(propertiesGroupBox)

            ' Add an events log
            m_EventsLog = New NExampleEventsLog()
            stack.Add(m_EventsLog)

            Return stack
        End Function
        Protected Overrides Function GetExampleDescription() As String
            Return "
<p>
	This example demonstrates how to create a single visible panel and add some widgets to it.
	The single visible panel is a panel in which only a single child element can be visible.
	The currently visible child element can be controlled through the <b>VisibleIndex</b> or the
	<b>VisibleElement</b> property. The <b>SizeToVisible</b> property determines whether the panel
	should be sized to the visible element or to all contained elements.  
</p>
" End Function

#End Region

#Region "Implementation"

        Private Function CreateHeaderLabel(ByVal text As String) As NLabel
            Dim label As NLabel = New NLabel(text)
            label.TextFill = New NColorFill(NColor.Blue)
            label.Font = New NFont(NFontDescriptor.DefaultSansFamilyName, 16)
            label.HorizontalPlacement = ENHorizontalPlacement.Center
            Return label
        End Function
        Private Function CreateComputerInfoWidget(ByVal info As NMobileCopmuterInfo) As NWidget
            Dim stack As NStackPanel = New NStackPanel()

            stack.Add(CreateHeaderLabel(info.Name))

            ' Create a pair box with the image and the description
            Dim descriptionLabel As NLabel = New NLabel(info.Description)
            descriptionLabel.TextWrapMode = ENTextWrapMode.WordWrap

            Dim pairBox As NPairBox = New NPairBox(info.Image, descriptionLabel)
            pairBox.Box1.Border = NBorder.CreateFilledBorder(NColor.Black)
            pairBox.Box1.BorderThickness = New NMargins(1)
            pairBox.Spacing = 5
            stack.Add(pairBox)

            Dim backButton As NButton = New NButton("Back")
            backButton.Content.HorizontalPlacement = ENHorizontalPlacement.Center
            backButton.Tag = 0
            stack.Add(backButton)

            Return stack
        End Function

#End Region

#Region "Event Handlers"

        ''' <summary>
        ''' 
        ''' </summary>
        ''' <paramname="args"></param>
        Private Sub OnVisibleIndexValueChanged(ByVal args As NValueChangeEventArgs)
            m_EventsLog.LogEvent("Visible child index: " & args.NewValue.ToString())
        End Sub
        ''' <summary>
        ''' Handler for NButtonBase.Click event.
        ''' </summary>
        ''' <paramname="args"></param>
        Private Sub OnButtonClicked(ByVal args As NEventArgs)
            If args.Cancel OrElse Not (TypeOf args.TargetNode Is NButton) OrElse Not (TypeOf args.TargetNode.Tag Is Integer) Then Return

            Dim singleVisiblePanel = CType(args.CurrentTargetNode, NSingleVisiblePanel)
            Dim button = CType(args.TargetNode, NButton)
            singleVisiblePanel.VisibleIndex = CInt(button.Tag)
        End Sub

#End Region

#Region "Fields"

        Private m_SingleVisiblePanel As NSingleVisiblePanel
        Private m_EventsLog As NExampleEventsLog

#End Region

#Region "Schema"

        ''' <summary>
        ''' Schema associated with NSingleVisiblePanelExample.
        ''' </summary>
        Public Shared ReadOnly NSingleVisiblePanelExampleSchema As NSchema

#End Region

#Region "Constants"

        Private Shared ReadOnly MobileComputers As NMobileCopmuterInfo() = New NMobileCopmuterInfo() {New NMobileCopmuterInfo("Laptop", NResources.Image_MobileComputers_Laptop_jpg, "A laptop, also called a notebook, is a personal computer for mobile use. A laptop integrates most of the typical components of a desktop computer, including a display, a keyboard, a pointing device (a touchpad, also known as a trackpad, and/or a pointing stick) and speakers into a single unit."), New NMobileCopmuterInfo("Netbook", NResources.Image_MobileComputers_Netbook_jpg, "Netbooks are a category of small, lightweight, legacy-free, and inexpensive laptop computers. At their inception in late 2007 as smaller notebooks optimized for low weight and low cost — netbooks omitted certain features (e.g., the optical drive), featured smaller screens and keyboards, and offered reduced computing power when compared to a full-sized laptop."), New NMobileCopmuterInfo("Smartbook", NResources.Image_MobileComputers_Smartbook_jpg, "A smartbook is a class of mobile device that combine certain features of both a smartphone and netbook computer. Smartbooks feature always on, all-day battery life, 3G, or Wi-Fi connectivity and GPS (all typically found in smartphones) in a laptop or tablet-style body with a screen size of 5 to 10 inches and a physical or soft touchscreen keyboard."), New NMobileCopmuterInfo("Tablet", NResources.Image_MobileComputers_Tablet_jpg, "A tablet computer, or simply tablet, is a complete mobile computer, larger than a mobile phone or personal digital assistant, integrated into a flat touch screen and primarily operated by touching the screen. It often uses an onscreen virtual keyboard, a passive stylus pen, or a digital pen, rather than a physical keyboard."), New NMobileCopmuterInfo("Ultra-mobile PC", NResources.Image_MobileComputers_UMPC_jpg, "An ultra-mobile PC (ultra-mobile personal computer or UMPC) is a small form factor version of a pen computer which is smaller than a netbook, has a TFT display measuring about 12.7 to 17.8 cm and is operated using a touch screen or a stylus. Lately ultra-mobile PCs have largely been supplanted by tablets."), New NMobileCopmuterInfo("Ultrabook", NResources.Image_MobileComputers_Ultrabook_jpg, "An Ultrabook is a computer in a category of thin and lightweight ultraportable laptops, defined by a specification from Intel corporation. Ultrabooks combine the power of ordinary laptops and the portability and battery life of netbooks but this comes at a higher price.")}

#End Region

#Region "Nested Types"

        Private Structure NMobileCopmuterInfo
            Public Sub New(ByVal name As String, ByVal image As NImage, ByVal description As String)
                Me.Name = name
                Me.Image = image
                Me.Description = description
            End Sub

            Public Name As String
            Public Image As NImage
            Public Description As String
        End Structure

#End Region
    End Class
End Namespace

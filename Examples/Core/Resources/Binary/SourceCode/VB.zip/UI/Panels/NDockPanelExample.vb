Imports System
Imports Nevron.Nov.Dom
Imports Nevron.Nov.Editors
Imports Nevron.Nov.Graphics
Imports Nevron.Nov.Layout
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.UI
    Public Class NDockPanelExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' Default constructor.
        ''' </summary>
        Public Sub New()
        End Sub
        ''' <summary>
        ''' Static constructor.
        ''' </summary>
        Shared Sub New()
            NDockPanelExampleSchema = NSchema.Create(GetType(NDockPanelExample), NExampleBase.NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            ' Create a dock panel with red border
            m_DockPanel = New NDockPanel()
            m_DockPanel.Border = NBorder.CreateFilledBorder(NColor.Red)
            m_DockPanel.BorderThickness = New NMargins(1)

            ' Create and dock several widgets
            Dim widget = CreateDockedWidget(ENDockArea.Left)
            widget.PreferredSize = New NSize(100, 100)
            m_DockPanel.Add(widget)
            widget = CreateDockedWidget(ENDockArea.Top)
            widget.PreferredSize = New NSize(100, 100)
            m_DockPanel.Add(widget)
            widget = CreateDockedWidget(ENDockArea.Right)
            widget.PreferredSize = New NSize(100, 100)
            m_DockPanel.Add(widget)
            widget = CreateDockedWidget(ENDockArea.Bottom)
            widget.PreferredSize = New NSize(100, 100)
            m_DockPanel.Add(widget)
            widget = CreateDockedWidget(ENDockArea.Center)
            widget.PreferredSize = New NSize(300, 300)
            m_DockPanel.Add(widget)
            Return m_DockPanel
        End Function

        Protected Overrides Function CreateExampleControls() As NWidget
            Dim stack As NStackPanel = New NStackPanel()

            ' properties stack
            Dim editors = NDesigner.GetDesigner(m_DockPanel).CreatePropertyEditors(m_DockPanel, NInputElement.EnabledProperty, NWidget.HorizontalPlacementProperty, NWidget.VerticalPlacementProperty, NDockPanel.VerticalSpacingProperty, NDockPanel.HorizontalSpacingProperty, NDockPanel.UniformWidthsProperty, NDockPanel.UniformHeightsProperty)
            Dim propertiesStack As NStackPanel = New NStackPanel()

            For i = 0 To editors.Count - 1
                propertiesStack.Add(editors(i))
            Next

            stack.Add(New NGroupBox("Properties", New NUniSizeBoxGroup(propertiesStack)))

            ' items stack
            Dim itemsStack As NStackPanel = New NStackPanel()
            m_DockAreaCombo = New NComboBox()
            m_DockAreaCombo.Items.Add(New NComboBoxItem("Left"))
            m_DockAreaCombo.Items.Add(New NComboBoxItem("Top"))
            m_DockAreaCombo.Items.Add(New NComboBoxItem("Right"))
            m_DockAreaCombo.Items.Add(New NComboBoxItem("Bottom"))
            m_DockAreaCombo.Items.Add(New NComboBoxItem("Center"))
            m_DockAreaCombo.SelectedIndex = 1
            Dim dockAreaLabel As NLabel = New NLabel("Dock Area:")
            dockAreaLabel.VerticalPlacement = ENVerticalPlacement.Center
            itemsStack.Add(New NPairBox(dockAreaLabel, m_DockAreaCombo, True))
            Dim addSmallItemButton As NButton = New NButton("Add Small Item")
            AddHandler addSmallItemButton.Click, New [Function](Of NEventArgs)(AddressOf OnAddSmallItemButtonClick)
            itemsStack.Add(addSmallItemButton)
            Dim addLargeItemButton As NButton = New NButton("Add Large Item")
            AddHandler addLargeItemButton.Click, New [Function](Of NEventArgs)(AddressOf OnAddLargeItemButtonClick)
            itemsStack.Add(addLargeItemButton)
            Dim addRandomItemButton As NButton = New NButton("Add Random Item")
            AddHandler addRandomItemButton.Click, New [Function](Of NEventArgs)(AddressOf OnAddRandomItemButtonClick)
            itemsStack.Add(addRandomItemButton)
            Dim removeAllItemsButton As NButton = New NButton("Remove All Items")
            AddHandler removeAllItemsButton.Click, New [Function](Of NEventArgs)(AddressOf OnRemoveAllItemsButtonClick)
            itemsStack.Add(removeAllItemsButton)
            stack.Add(New NGroupBox("Items", itemsStack))
            Return New NUniSizeBoxGroup(stack)
        End Function

        Protected Overrides Function GetExampleDescription() As String
            Return "
<p>
	This example demonstrates how to create a dock layout panel and add
	widgets to it specifying the dock area each widget should be placed in.
</p>
"
        End Function

#End Region

#Region "Implementation"

        ''' <summary>
        ''' Gets the currently selected dock area from the DockAreaCombo.
        ''' </summary>
        ''' <returns></returns>
        Private Function GetCurrentDockArea() As ENDockArea
            Select Case m_DockAreaCombo.SelectedIndex
                Case 0
                    Return ENDockArea.Left
                Case 1
                    Return ENDockArea.Top
                Case 2
                    Return ENDockArea.Right
                Case 3
                    Return ENDockArea.Bottom
                Case 4
                    Return ENDockArea.Center
                Case Else
                    Return ENDockArea.Top
            End Select
        End Function
        ''' <summary>
        ''' Sets the currently selected dock area to the specified widget.
        ''' </summary>
        ''' <paramname="widget"></param>
        Private Sub SetCurrentDockArea(ByVal widget As NWidget)
            SetDockArea(widget, GetCurrentDockArea())
        End Sub
        ''' <summary>
        ''' Sets a custom dock area to the specified widget and colors its background accordingly
        ''' </summary>
        ''' <paramname="widget"></param>
        ''' <paramname="dockArea"></param>
        Private Sub SetDockArea(ByVal widget As NWidget, ByVal dockArea As ENDockArea)
            NDockLayout.SetDockArea(widget, dockArea)

            Select Case dockArea
                Case ENDockArea.Bottom
                    widget.BackgroundFill = New NColorFill(New NColor(0, 162, 232))
                Case ENDockArea.Center
                    widget.BackgroundFill = New NColorFill(New NColor(239, 228, 176))
                Case ENDockArea.Left
                    widget.BackgroundFill = New NColorFill(New NColor(34, 177, 76))
                Case ENDockArea.Right
                    widget.BackgroundFill = New NColorFill(New NColor(163, 73, 164))
                Case ENDockArea.Top
                    widget.BackgroundFill = New NColorFill(New NColor(237, 28, 36))
                Case Else
                    Throw New Exception("New ENDockArea?")
            End Select
        End Sub

        ''' <summary>
        ''' Creates the default docked widget for this example, that is docked to the current dock area.
        ''' </summary>
        ''' <returns></returns>
        Private Function CreateDockedWidget() As NWidget
            Return CreateDockedWidget(GetCurrentDockArea())
        End Function
        ''' <summary>
        ''' Creates the default docked widget for this example, that is docked to the specified area.
        ''' </summary>
        ''' <paramname="dockArea"></param>
        ''' <returns></returns>
        Private Function CreateDockedWidget(ByVal dockArea As ENDockArea) As NWidget
            Dim label As NLabel = New NLabel(dockArea.ToString() & "(" & m_DockPanel.Count.ToString() & ")")
            label.HorizontalPlacement = ENHorizontalPlacement.Center
            label.VerticalPlacement = ENVerticalPlacement.Center
            Dim widget As NWidget = New NContentHolder(label)
            widget.Border = NBorder.CreateFilledBorder(NColor.Black)
            widget.BorderThickness = New NMargins(1)
            SetDockArea(widget, dockArea)
            Return widget
        End Function

#End Region

#Region "Event Handlers"

        Private Sub OnAddSmallItemButtonClick(ByVal args As NEventArgs)
            Dim item As NWidget = CreateDockedWidget()
            item.MinSize = New NSize(20, 20)
            item.PreferredSize = New NSize(60, 60)
            m_DockPanel.Add(item)
        End Sub

        Private Sub OnAddLargeItemButtonClick(ByVal args As NEventArgs)
            Dim item As NWidget = CreateDockedWidget()
            item.MinSize = New NSize(40, 40)
            item.PreferredSize = New NSize(100, 100)
            m_DockPanel.Add(item)
        End Sub

        Private Sub OnAddRandomItemButtonClick(ByVal args As NEventArgs)
            Dim range = 50
            Dim rnd As Random = New Random()
            Dim item As NWidget = CreateDockedWidget()
            item.MinSize = New NSize(rnd.Next(range), rnd.Next(range))
            item.PreferredSize = New NSize(rnd.Next(range) + range, rnd.Next(range) + range)
            m_DockPanel.Add(item)
        End Sub

        Private Sub OnRemoveAllItemsButtonClick(ByVal args As NEventArgs)
            m_DockPanel.Clear()
        End Sub

#End Region

#Region "Fields"

        Private m_DockAreaCombo As NComboBox
        Private m_DockPanel As NDockPanel

#End Region

#Region "Schema"

        ''' <summary>
        ''' Schema associated with NDockPanelExample.
        ''' </summary>
        Public Shared ReadOnly NDockPanelExampleSchema As NSchema

#End Region
    End Class
End Namespace

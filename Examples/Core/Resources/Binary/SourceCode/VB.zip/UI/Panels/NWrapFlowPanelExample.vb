Imports System
Imports Nevron.Nov.Editors
Imports Nevron.Nov.Dom
Imports Nevron.Nov.Graphics
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.UI
    Public Class NWrapFlowPanelExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' Default constructor.
        ''' </summary>
        Public Sub New()
        End Sub
        ''' <summary>
        ''' Static constructor.
        ''' </summary>
        Shared Sub New()
            NWrapFlowPanelExampleSchema = NSchema.Create(GetType(NWrapFlowPanelExample), NExampleBase.NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            m_WrapFlowPanel = New NWrapFlowPanel()
            m_WrapFlowPanel.SetBorder(1, NColor.Red)

            For i = 1 To 16
                m_WrapFlowPanel.Add(New NButton("Button " & i.ToString()))
            Next

            Return m_WrapFlowPanel
        End Function
        Protected Overrides Function CreateExampleControls() As NWidget
            Dim stack As NStackPanel = New NStackPanel()

            Dim editors = NDesigner.GetDesigner(m_WrapFlowPanel).CreatePropertyEditors(m_WrapFlowPanel, NInputElement.EnabledProperty, NWidget.HorizontalPlacementProperty, NWidget.VerticalPlacementProperty, NWrapFlowPanel.DirectionProperty, NWrapFlowPanel.VerticalSpacingProperty, NWrapFlowPanel.HorizontalSpacingProperty, NWrapFlowPanel.LaneFillModeProperty, NWrapFlowPanel.FillModeProperty, NWrapFlowPanel.FitModeProperty, NWrapFlowPanel.InvertedProperty, NWrapFlowPanel.UniformWidthsProperty, NWrapFlowPanel.UniformHeightsProperty)

            Dim propertiesStack As NStackPanel = New NStackPanel()
            For i = 0 To editors.Count - 1
                propertiesStack.Add(editors(i))
            Next

            stack.Add(New NGroupBox("Properties", New NUniSizeBoxGroup(propertiesStack)))

            ' items stack
            Dim itemsStack As NStackPanel = New NStackPanel()

            Dim addSmallItemButton As NButton = New NButton("Add Small Item")
            addSmallItemButton.Click += New [Function](Of NEventArgs)(AddressOf OnAddSmallItemButtonClick)
            itemsStack.Add(addSmallItemButton)

            Dim addLargeItemButton As NButton = New NButton("Add Large Item")
            addLargeItemButton.Click += New [Function](Of NEventArgs)(AddressOf OnAddLargeItemButtonClick)
            itemsStack.Add(addLargeItemButton)

            Dim addRandomItemButton As NButton = New NButton("Add Random Item")
            addRandomItemButton.Click += New [Function](Of NEventArgs)(AddressOf OnAddRandomItemButtonClick)
            itemsStack.Add(addRandomItemButton)

            Dim removeAllItemsButton As NButton = New NButton("Remove All Items")
            removeAllItemsButton.Click += New [Function](Of NEventArgs)(AddressOf OnRemoveAllItemsButtonClick)
            itemsStack.Add(removeAllItemsButton)

            stack.Add(New NGroupBox("Items", itemsStack))

            Return stack
        End Function
        Protected Overrides Function GetExampleDescription() As String
            Return "
<p>
	This example demonstrates how to create a wrap flow layout panel and add
	widgets to it. You can control the parameters of the layout algorithm
	using the controls to the right.
</p>
" End Function

#End Region

#Region "Event Handlers"

        Private Sub OnAddSmallItemButtonClick(ByVal args As NEventArgs)
            Dim item As NButton = New NButton("Small." & m_WrapFlowPanel.Count.ToString())
            item.MinSize = New NSize(5, 5)
            item.PreferredSize = New NSize(25, 25)
            m_WrapFlowPanel.Add(item)
        End Sub
        Private Sub OnAddLargeItemButtonClick(ByVal args As NEventArgs)
            Dim item As NButton = New NButton("Large." & m_WrapFlowPanel.Count.ToString())
            item.MinSize = New NSize(20, 20)
            item.PreferredSize = New NSize(60, 60)
            m_WrapFlowPanel.Add(item)
        End Sub
        Private Sub OnAddRandomItemButtonClick(ByVal args As NEventArgs)
            Dim range = 30
            Dim rnd As Random = New Random()
            Dim item As NButton = New NButton("Random." & m_WrapFlowPanel.Count.ToString())
            item.MinSize = New NSize(rnd.Next(range), rnd.Next(range))
            item.PreferredSize = New NSize(rnd.Next(range) + range, rnd.Next(range) + range)
            m_WrapFlowPanel.Add(item)
        End Sub
        Private Sub OnRemoveAllItemsButtonClick(ByVal args As NEventArgs)
            m_WrapFlowPanel.Clear()
        End Sub

#End Region

#Region "Fields"

        Private m_WrapFlowPanel As NWrapFlowPanel

#End Region

#Region "Schema"

        Public Shared ReadOnly NWrapFlowPanelExampleSchema As NSchema

#End Region
    End Class
End Namespace

Imports Nevron.Nov.Dom
Imports Nevron.Nov.Graphics
Imports Nevron.Nov.Layout
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.UI
    Public Class NDragAndDropExample
        Inherits NExampleBase
#Region "Constructors"

        Public Sub New()
        End Sub

        Shared Sub New()
            NDragAndDropExampleSchema = NSchema.Create(GetType(NDragAndDropExample), NExampleBase.NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            ' sources
            Dim sourcesGroup As NGroupBox = New NGroupBox("Drag Drop Sources")

            If True Then
                Dim sourcesStack As NStackPanel = New NStackPanel()
                sourcesGroup.Content = sourcesStack
                Dim textSource1 = CreateDemoElement("Drag Source Text 1")
                Dim dataObject1 As NDataObject = New NDataObject()
                dataObject1.SetData(NDataFormat.TextFormat, "Text string 1")
                textSource1.Tag = dataObject1
                sourcesStack.Add(textSource1)
                AddHandler textSource1.MouseDown, New [Function](Of NMouseButtonEventArgs)(AddressOf OnSourceMouseDown)
                Dim textSource2 = CreateDemoElement("Drag Source Text 2")
                Dim dataObject2 As NDataObject = New NDataObject()
                dataObject2.SetData(NDataFormat.TextFormat, "Text string 2")
                textSource2.Tag = dataObject2
                sourcesStack.Add(textSource2)
                AddHandler textSource2.MouseDown, New [Function](Of NMouseButtonEventArgs)(AddressOf OnSourceMouseDown)
            End If

            ' targets
            Dim targetsGroup As NGroupBox = New NGroupBox("Drop Targets")

            If True Then
                Dim targetsStack As NStackPanel = New NStackPanel()
                targetsGroup.Content = targetsStack
                Dim dropTextTarget = CreateDemoElement("Drop Text On Me")
                targetsStack.Add(dropTextTarget)
                AddHandler dropTextTarget.DragOver, New [Function](Of NDragActionEventArgs)(AddressOf OnDragOverTextTarget)
                AddHandler dropTextTarget.DragDrop, New [Function](Of NDragActionEventArgs)(AddressOf OnDragDropTextTarget)
            End If

            ' create the source and targets splitter
            Dim splitter As NSplitter = New NSplitter()
            splitter.SplitMode = ENSplitterSplitMode.Proportional
            splitter.SplitFactor = 0.5R
            splitter.Pane1.Content = sourcesGroup
            splitter.Pane2.Content = targetsGroup

            ' create the inspector on the bottom
            Dim inspectorGroup As NGroupBox = New NGroupBox("Data Object Ispector")
            Dim inspector As NListBox = New NListBox()
            inspectorGroup.Content = inspector
            AddHandler inspector.DragEnter, New [Function](Of NDragOverChangeEventArgs)(AddressOf OnInspectorDragEnter)
            AddHandler inspector.DragLeave, New [Function](Of NDragOverChangeEventArgs)(AddressOf OnInspectorDragLeave)
            Dim stack As NStackPanel = New NStackPanel()
            stack.HorizontalPlacement = ENHorizontalPlacement.Fit
            stack.VerticalPlacement = ENVerticalPlacement.Fit
            stack.FillMode = ENStackFillMode.Last
            stack.Add(splitter)
            stack.Add(inspectorGroup)
            Return stack
        End Function

        Protected Overrides Function CreateExampleControls() As NWidget
            Dim tab As NTab = New NTab()
            m_SourceEventsLog = New NExampleEventsLog()
            tab.TabPages.Add(New NTabPage("Source Events", m_SourceEventsLog))
            m_TargetEventsLog = New NExampleEventsLog()
            tab.TabPages.Add(New NTabPage("Target Events", m_TargetEventsLog))
            Return tab
        End Function

        Protected Overrides Function GetExampleDescription() As String
            Return "<p>The example demonstrates how to use Drag and Drop in NOV.</p>"
        End Function

#End Region

#Region "Implementation"

        Private Function CreateTextDragDropSources() As NWidget
            Return Nothing
        End Function

        Private Function CreateImageDragDropSource() As NWidget
            Return Nothing
        End Function

        Private Function CreateDemoElement(ByVal text As String) As NContentHolder
            Dim element As NContentHolder = New NContentHolder(text)
            element.Border = NBorder.CreateFilledBorder(NColor.Black, 2, 5)
            element.BorderThickness = New NMargins(1)
            element.BackgroundFill = New NColorFill(NColor.PapayaWhip)
            element.TextFill = New NColorFill(NColor.Black)
            element.Padding = New NMargins(1)
            Return element
        End Function

#End Region

#Region "Event Handlers"

        Private Sub OnSourceMouseDown(ByVal args As NMouseButtonEventArgs)
            If NDragDrop.CanRequestDragDrop() Then
                Dim dataObject = CType(args.CurrentTargetNode.Tag, NDataObject)
                Dim dropSource As NDragDropSource = New NDragDropSource(ENDragDropEffects.All)
                AddHandler dropSource.DragStarting, New [Function](Of NDragDropSourceEventArgs)(AddressOf OnDropSourceDragStarting)
                AddHandler dropSource.DragEnded, New [Function](Of NDragEndedEventArgs)(AddressOf OnDropSourceDragEnded)
                AddHandler dropSource.QueryDragAction, New [Function](Of NQueryDragActionEventArgs)(AddressOf OnDropSourceQueryDragAction)
                NDragDrop.RequestDragDrop(dropSource, dataObject)
            End If
        End Sub

        Private Sub OnDragOverTextTarget(ByVal args As NDragActionEventArgs)
            ' first you need to check whether the data object is of interest
            If args.DataObject.ContainsData(NDataFormat.TextFormat) Then
                ' if the Ctrl is pressed, you must typically copy the data if you can.
                If NKeyboard.DefaultCommandPressed And (args.AllowedEffect And ENDragDropEffects.Copy) = ENDragDropEffects.Copy Then
                    args.Effect = ENDragDropEffects.Copy
                    Return
                End If

                ' if the Alt is pressed, you must typically link the data if you can.
                If NKeyboard.AltPressed And (args.AllowedEffect And ENDragDropEffects.Link) = ENDragDropEffects.Link Then
                    args.Effect = ENDragDropEffects.Link
                    Return
                End If

                ' by default you need to move data if you can
                If (args.AllowedEffect And ENDragDropEffects.Move) <> ENDragDropEffects.None Then
                    args.Effect = ENDragDropEffects.Move
                    Return
                End If
            End If

            ' the source either did not publish a data object with a format we are interested in,
            ' or we cannot perform the action that is standartly performed for the current keyboard modifies state,
            ' or the source did not allow the action that we can perfrom for the current keyboard modifies state.
            ' in all these cases we set the effect to none.
            args.Effect = ENDragDropEffects.None
            Return
        End Sub

        Private Sub OnDragDropTextTarget(ByVal args As NDragEventArgs)
            Dim data = args.DataObject.GetData(NDataFormat.TextFormat)

            If data IsNot Nothing Then
                Dim contentHolder As NContentHolder = TryCast(args.CurrentTargetNode, NContentHolder)
                contentHolder.Content = New NLabel("Dropped Text:{" & CStr(data) & "}. Drop another text...")
            End If
        End Sub

        Private Sub OnInspectorDragEnter(ByVal args As NDragOverChangeEventArgs)
            Dim formats As NDataFormat() = args.DataObject.GetFormats()
            Dim inspector As NListBox = TryCast(args.CurrentTargetNode, NListBox)
            inspector.Items.Clear()

            For i = 0 To formats.Length - 1
                inspector.Items.Add(New NListBoxItem(formats(i).ToString()))
            Next
        End Sub

        Private Sub OnInspectorDragLeave(ByVal args As NDragOverChangeEventArgs)
            Dim inspector As NListBox = TryCast(args.CurrentTargetNode, NListBox)
            inspector.Items.Clear()
        End Sub

        Private Sub OnDropSourceQueryDragAction(ByVal args As NQueryDragActionEventArgs)
            m_SourceEventsLog.LogEvent("QueryDragAction " & args.Reason.ToString())
        End Sub

        Private Sub OnDropSourceDragStarting(ByVal args As NDragDropSourceEventArgs)
            m_SourceEventsLog.LogEvent("DragStarting")
        End Sub

        Private Sub OnDropSourceDragEnded(ByVal args As NDragEndedEventArgs)
            m_SourceEventsLog.LogEvent("DragEnded. Final Effect was: " & args.FinalEffect.ToString())
        End Sub

#End Region

#Region "Fields"

        Private m_SourceEventsLog As NExampleEventsLog
        Private m_TargetEventsLog As NExampleEventsLog

#End Region

#Region "Schema"

        Public Shared ReadOnly NDragAndDropExampleSchema As NSchema

#End Region
    End Class
End Namespace

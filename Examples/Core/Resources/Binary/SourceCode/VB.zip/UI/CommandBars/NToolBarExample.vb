Imports System

Imports Nevron.Nov.Dom
Imports Nevron.Nov.Graphics
Imports Nevron.Nov.Layout
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.UI
    Public Class NToolBarExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' Default constructor.
        ''' </summary>
        Public Sub New()
        End Sub
        ''' <summary>
        ''' Static constructor.
        ''' </summary>
        Shared Sub New()
            NToolBarExampleSchema = NSchema.Create(GetType(NToolBarExample), NExampleBase.NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            m_ToolBar = New NToolBar()
            m_ToolBar.Text = "My Toolbar"
            m_ToolBar.VerticalPlacement = ENVerticalPlacement.Top

            Return m_ToolBar
        End Function
        Protected Overrides Function CreateExampleControls() As NWidget
            Dim stack As NStackPanel = New NStackPanel()
            stack.FillMode = ENStackFillMode.Last
            stack.FitMode = ENStackFitMode.Last

            ' Create the tool bar button type radio group
            Dim buttonTypeStack As NStackPanel = New NStackPanel()

            Dim buttonTypes As ENToolBarButtonType() = NEnum.GetValues(Of ENToolBarButtonType)()
            Dim i = 0, count = buttonTypes.Length

            While i < count
                ' Get the current button type and its string representation
                Dim buttonType = buttonTypes(i)
                Dim text As String = NStringHelpers.InsertSpacesBeforeUppersAndDigits(buttonType.ToString())

                ' Create a radio button for the current button type
                Dim radioButton As NRadioButton = New NRadioButton(text)
                buttonTypeStack.Add(radioButton)
                i += 1
            End While

            Dim buttonTypeGroup As NRadioButtonGroup = New NRadioButtonGroup(buttonTypeStack)
            buttonTypeGroup.SelectedIndexChanged += AddressOf OnButtonTypeGroupSelectedIndexChanged
            buttonTypeGroup.SelectedIndex = 2
            stack.Add(New NGroupBox("Button Type", buttonTypeGroup))

            ' Create the events log
            m_EventsLog = New NExampleEventsLog()
            stack.Add(m_EventsLog)

            Return stack
        End Function
        Protected Overrides Function GetExampleDescription() As String
            Return "
<p>
	This example demonstrates how to create a toolbar and populate it with buttons, which consist of image and text.
	Using the controls to the right you can change the size and the visibility of the images, which will result in
	recreation of the toolbar buttons.
</p>
" End Function

#End Region

#Region "Implementation"

        Private Function GetSmallImage(ByVal text As String) As NImage
            Dim imageName = "RIMG_ToolBar_16x16_" & text.Replace(" ", String.Empty) & "_png"
            Dim resourceRef As NEmbeddedResourceRef = New NEmbeddedResourceRef(NResources.Instance, imageName)
            Return New NImage(resourceRef)
        End Function
        Private Function GetLargeImage(ByVal text As String) As NImage
            Dim imageName = "RIMG_ToolBar_32x32_" & text.Replace(" ", String.Empty) & "_png"
            Dim resourceRef As NEmbeddedResourceRef = New NEmbeddedResourceRef(NResources.Instance, imageName)
            Return New NImage(resourceRef)
        End Function
        Private Function CreatePairBox(ByVal image As NImage, ByVal text As String) As NPairBox
            Dim pairBox As NPairBox = New NPairBox(image, text)
            pairBox.Box2.VerticalPlacement = ENVerticalPlacement.Center
            pairBox.Spacing = 3
            Return pairBox
        End Function
        Private Function CreateButton(ByVal buttonType As ENToolBarButtonType, ByVal text As String) As NButton
            Dim button As NButton = Nothing
            Dim image As NImage = Nothing

            Select Case buttonType
                Case ENToolBarButtonType.Text
                    button = New NButton(text)
                Case ENToolBarButtonType.SmallIcon
                    image = GetSmallImage(text)
                    button = New NButton(image)
                Case ENToolBarButtonType.SmallIconAndText
                    image = GetSmallImage(text)
                    button = New NButton(CreatePairBox(image, text))
                Case ENToolBarButtonType.LargeIcon
                    image = GetLargeImage(text)
                    button = New NButton(image)
                Case ENToolBarButtonType.LargeIconAndText
                    image = GetLargeImage(text)
                    button = New NButton(CreatePairBox(image, text))
                Case Else
                    Throw New Exception("New ENToolBarButtonType?")
            End Select

            NCommandBar.SetText(button, text)
            NCommandBar.SetImage(button, image)

            button.Click += New [Function](Of NEventArgs)(AddressOf OnToolBarButtonClick)
            Return button
        End Function
        Private Sub RecreateToolBarButtons(ByVal buttonType As ENToolBarButtonType)
            m_ToolBar.Items.Clear()

            Dim i = 0, buttonCount = ButtonTexts.Length

            While i < buttonCount
                Dim buttonText = ButtonTexts(i)
                If Equals(buttonText, Nothing) OrElse buttonText.Length = 0 Then
                    m_ToolBar.Items.Add(New NCommandBarSeparator())
                Else
                    m_ToolBar.Items.Add(CreateButton(buttonType, buttonText))
                End If

                i += 1
            End While

            m_ToolBar.Items.Add(New NMenuDropDown("Test"))
        End Sub

#End Region

#Region "Event Handlers"

        ''' <summary>
        ''' Called when the user has checked a new button type radio button.
        ''' </summary>
        ''' <paramname="arg"></param>
        Private Sub OnButtonTypeGroupSelectedIndexChanged(ByVal arg As NValueChangeEventArgs)
            RecreateToolBarButtons(CInt(arg.NewValue))
        End Sub
        ''' <summary>
        ''' Occurs when the user clicks on a tool bar button.
        ''' </summary>
        ''' <paramname="args"></param>
        Private Sub OnToolBarButtonClick(ByVal args As NEventArgs)
            Dim buttonText = NCommandBar.GetText(CType(args.TargetNode, NButton))
            m_EventsLog.LogEvent("<" & buttonText & "> button clicked")
        End Sub

#End Region

#Region "Fields"

        Private m_ToolBar As NToolBar
        Private m_EventsLog As NExampleEventsLog

#End Region

#Region "Schema"

        ''' <summary>
        ''' Schema associated with NToolBarExample.
        ''' </summary>
        Public Shared ReadOnly NToolBarExampleSchema As NSchema

#End Region

#Region "Constants"

        Private Shared ReadOnly ButtonTexts As String() = New String() {"Open", "Save", "Save As", Nothing, "Print", "Options", Nothing, "Help"}

#End Region

#Region "Nested Types"

        Public Enum ENToolBarButtonType
            Text
            SmallIcon
            SmallIconAndText
            LargeIcon
            LargeIconAndText
        End Enum

#End Region
    End Class
End Namespace

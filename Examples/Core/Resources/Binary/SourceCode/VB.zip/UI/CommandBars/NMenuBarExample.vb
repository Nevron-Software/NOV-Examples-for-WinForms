Imports Nevron.Nov.Dom
Imports Nevron.Nov.Editors
Imports Nevron.Nov.Layout
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.UI
    Public Class NMenuBarExample
        Inherits NExampleBase
#Region "Constructors"

        Public Sub New()
        End Sub
        Shared Sub New()
            NMenuBarExampleSchema = NSchema.Create(GetType(NMenuBarExample), NExampleBase.NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            m_MenuBar = New NMenuBar()
            m_MenuBar.Text = "My Menu"
            m_MenuBar.HorizontalPlacement = ENHorizontalPlacement.Left
            m_MenuBar.VerticalPlacement = ENVerticalPlacement.Top

            m_MenuBar.Items.Add(CreateFileMenuDropDown())
            m_MenuBar.Items.Add(CreateEditMenuDropDown())
            m_MenuBar.Items.Add(CreateViewMenuDropDown())

            m_MenuBar.AddEventHandler(NContentPopupHost.ClickEvent, New NEventHandler(Of NEventArgs)(New [Function](Of NEventArgs)(AddressOf OnMenuItemClicked)))

            Dim stack As NStackPanel = New NStackPanel()
            stack.Direction = ENHVDirection.TopToBottom
            stack.Add(m_MenuBar)

            Return stack
        End Function
        Protected Overrides Function CreateExampleControls() As NWidget
            Dim editors = NDesigner.GetDesigner(m_MenuBar).CreatePropertyEditors(m_MenuBar, NCommandBar.OrientationProperty, NCommandBar.OpenPopupsOnMouseInProperty, NCommandBar.ClosePopupsOnMouseOutProperty)

            Dim stack As NStackPanel = New NStackPanel()
            stack.FillMode = ENStackFillMode.Last
            stack.FitMode = ENStackFitMode.Last

            For i = 0 To editors.Count - 1
                stack.Add(editors(i))
            Next

            m_EventsLog = New NExampleEventsLog()
            stack.Add(m_EventsLog)
            NDebug.WriteLine("Create Menu Example Controls")
            Return New NUniSizeBoxGroup(stack)
        End Function
        Protected Overrides Function GetExampleDescription() As String
            Return "
<p>
	This example demonstrates how to create drop down menus, nested menu items, menu separators and checkable menu items.
	The example also shows how to create a set of menu items, which behaves like a radio button group, i.e. when you click
	on one of the checkable menu items the previously checked one becomes unchecked.
</p>
" End Function

#End Region

#Region "Implementation"

        Private Function CreateFileMenuDropDown() As NMenuDropDown
            Dim fileMenu = CreateMenuDropDown("File")

            Dim newMenuItem As NMenuItem = New NMenuItem("New")
            fileMenu.Items.Add(newMenuItem)
            newMenuItem.Items.Add(New NMenuItem("Project"))
            newMenuItem.Items.Add(New NMenuItem("Web Site"))
            newMenuItem.Items.Add(New NMenuItem("File"))

            Dim openMenuItem As NMenuItem = New NMenuItem(NResources.Image_ToolBar_16x16_Open_png, "Open")
            fileMenu.Items.Add(openMenuItem)
            openMenuItem.Items.Add(New NMenuItem("Project"))
            openMenuItem.Items.Add(New NMenuItem("Web Site"))
            openMenuItem.Items.Add(New NMenuItem("File"))

            fileMenu.Items.Add(New NMenuItem("Save"))
            fileMenu.Items.Add(New NMenuItem("Save As..."))

            fileMenu.Items.Add(New NMenuSeparator())
            fileMenu.Items.Add(New NMenuItem("Exit"))

            Return fileMenu
        End Function
        Private Function CreateEditMenuDropDown() As NMenuDropDown
            Dim editMenu = CreateMenuDropDown("Edit")

            editMenu.Items.Add(New NMenuItem("Undo"))
            editMenu.Items.Add(New NMenuItem("Redo"))
            editMenu.Items.Add(New NMenuSeparator())
            editMenu.Items.Add(New NMenuItem("Cut"))
            editMenu.Items.Add(New NMenuItem("Copy"))
            editMenu.Items.Add(New NMenuItem("Paste"))

            Return editMenu
        End Function
        Private Function CreateViewMenuDropDown() As NMenuDropDown
            Dim viewMenu = CreateMenuDropDown("View")

            m_ViewLayoutMenuItems = New NCheckableMenuItem() {New NCheckableMenuItem(Nothing, "Normal Layout", True), New NCheckableMenuItem("Web Layout"), New NCheckableMenuItem("Print Layout"), New NCheckableMenuItem("Reading Layout")}

            Dim i = 0, count = m_ViewLayoutMenuItems.Length

            While i < count
                Dim viewLayoutMenuItem = m_ViewLayoutMenuItems(i)
                viewLayoutMenuItem.CheckedChanging += New [Function](Of NValueChangeEventArgs)(AddressOf OnViewLayoutMenuItemCheckedChanging)
                viewLayoutMenuItem.CheckedChanged += New [Function](Of NValueChangeEventArgs)(AddressOf OnViewLayoutMenuItemCheckedChanged)
                viewMenu.Items.Add(viewLayoutMenuItem)
                i += 1
            End While

            viewMenu.Items.Add(New NMenuSeparator())
            viewMenu.Items.Add(New NCheckableMenuItem(Nothing, "Task Pane", True))
            viewMenu.Items.Add(New NCheckableMenuItem(Nothing, "Toolbars", False))
            viewMenu.Items.Add(New NCheckableMenuItem(Nothing, "Ruler", True))

            Return viewMenu
        End Function

#End Region

#Region "Protected - Event Handlers"

        Private Sub OnMenuItemClicked(ByVal args As NEventArgs)
            Dim itemBase = CType(args.TargetNode, NMenuPopupHost)
            If TypeOf itemBase.Content Is NLabel Then
                m_EventsLog.LogEvent(CType(itemBase.Content, NLabel).Text & " Clicked")
            Else
                m_EventsLog.LogEvent(itemBase.ToString() & " Clicked")
            End If
        End Sub
        Private Sub OnViewLayoutMenuItemCheckedChanging(ByVal args As NValueChangeEventArgs)
            Dim isChecked As Boolean = args.NewValue
            If isChecked Then Return

            ' Make sure the user is not trying to uncheck the checked item
            Dim item = CType(args.TargetNode, NCheckableMenuItem)
            Dim i = 0, count = m_ViewLayoutMenuItems.Length

            While i < count
                Dim currentItem = m_ViewLayoutMenuItems(i)
                If currentItem IsNot item AndAlso currentItem.Checked Then Return
                i += 1
            End While

            args.Cancel = True
        End Sub
        Private Sub OnViewLayoutMenuItemCheckedChanged(ByVal args As NValueChangeEventArgs)
            Dim isChecked As Boolean = args.NewValue
            If isChecked = False Then Return

            Dim item = CType(args.TargetNode, NCheckableMenuItem)
            Dim i = 0, count = m_ViewLayoutMenuItems.Length

            While i < count
                Dim currentItem = m_ViewLayoutMenuItems(i)
                If currentItem IsNot item AndAlso currentItem.Checked Then
                    ' We've found the previously checked item, so uncheck it
                    currentItem.Checked = False
                    Exit While
                End If

                i += 1
            End While
        End Sub

#End Region

#Region "Fields"

        Private m_MenuBar As NMenuBar
        Private m_EventsLog As NExampleEventsLog
        Private m_ViewLayoutMenuItems As NCheckableMenuItem()

#End Region

#Region "Schema"

        Public Shared ReadOnly NMenuBarExampleSchema As NSchema

#End Region

#Region "Static Methods"

        Private Shared Function CreateMenuDropDown(ByVal text As String) As NMenuDropDown
            Dim menuDropDown As NMenuDropDown = New NMenuDropDown(text)
            NCommandBar.SetText(menuDropDown, text)
            NCommandBar.SetImage(menuDropDown, Nothing)
            Return menuDropDown
        End Function

#End Region
    End Class
End Namespace

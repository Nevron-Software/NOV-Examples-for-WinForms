Imports Nevron.Nov.Dom
Imports Nevron.Nov.Graphics
Imports Nevron.Nov.Layout
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.UI
    Public Class NCommandBarsExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' Default constructor.
        ''' </summary>
        Public Sub New()
        End Sub
        ''' <summary>
        ''' Static constructor.
        ''' </summary>
        Shared Sub New()
            NCommandBarsExampleSchema = NSchema.Create(GetType(NCommandBarsExample), NExampleBase.NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            Dim manager As NCommandBarManager = New NCommandBarManager()

            ' create two lanes
            Dim lane0 As NCommandBarLane = New NCommandBarLane()
            manager.TopDock.Add(lane0)
            Dim lane1 As NCommandBarLane = New NCommandBarLane()
            manager.TopDock.Add(lane1)
            Dim lane2 As NCommandBarLane = New NCommandBarLane()
            manager.TopDock.Add(lane2)
            Dim lane3 As NCommandBarLane = New NCommandBarLane()
            manager.TopDock.Add(lane3)

            ' create a menu bar in the first lane
            Dim menuBar As NMenuBar = New NMenuBar()
            lane0.Add(menuBar)
            menuBar.Items.Add(CreateFileMenu())
            menuBar.Items.Add(CreateEditMenu())
            menuBar.Items.Add(CreateViewMenu())
            menuBar.Text = "Main Menu"

            'Create File toolbar.
            Dim fileToolBar As NToolBar = New NToolBar()
            lane1.Add(fileToolBar)
            fileToolBar.Text = "File"
            AddToolBarItem(fileToolBar, Presentation.NResources.Image_File_New_png, Nothing, "New")
            AddToolBarItem(fileToolBar, Presentation.NResources.Image_File_Open_png, Nothing, "Open")
            fileToolBar.Items.Add(New NCommandBarSeparator())
            AddToolBarItem(fileToolBar, Presentation.NResources.Image_File_Save_png, Nothing, "Save...")
            AddToolBarItem(fileToolBar, Presentation.NResources.Image_File_SaveAs_png, Nothing, "Save As...")

            'Create Edit toolbar.
            Dim editToolBar As NToolBar = New NToolBar()
            lane1.Add(editToolBar)
            editToolBar.Text = "Edit"
            AddToolBarItem(editToolBar, Presentation.NResources.Image_Edit_Undo_png, "Undo")
            AddToolBarItem(editToolBar, Presentation.NResources.Image_Edit_Redo_png, "Redo")
            editToolBar.Items.Add(New NCommandBarSeparator())
            AddToolBarItem(editToolBar, Presentation.NResources.Image_Edit_Copy_png, "Copy")
            AddToolBarItem(editToolBar, Presentation.NResources.Image_Edit_Cut_png, "Cut")
            AddToolBarItem(editToolBar, Presentation.NResources.Image_Edit_Paste_png, "Paste")

            'Create View toolbar.
            Dim viewToolBar As NToolBar = New NToolBar()
            lane1.Add(viewToolBar)
            viewToolBar.Text = "View"

            'Add toggle buttons in a toggle button group which acts like radio buttons.
            AddToggleToolBarItem(viewToolBar, Text.NResources.Image_Layout_Normal_png, "Normal Layout")
            AddToggleToolBarItem(viewToolBar, Text.NResources.Image_Layout_Web_png, "Web Layout")
            AddToggleToolBarItem(viewToolBar, Text.NResources.Image_Layout_Print_png, "Print Layout")
            viewToolBar.Items.Add(New NCommandBarSeparator())
            AddToolBarItem(viewToolBar, Nothing, "Task Pane")
            AddToolBarItem(viewToolBar, Nothing, "Toolbars")
            AddToolBarItem(viewToolBar, Nothing, "Ruller")
            Dim toolbar As NToolBar = New NToolBar()
            lane2.Add(toolbar)
            toolbar.Text = "Toolbar"
            toolbar.Wrappable = True
            Dim colorBoxItem As NColorBox = New NColorBox()
            colorBoxItem.Tooltip = New NTooltip("Select Color")
            NCommandBar.SetText(colorBoxItem, "Select Color")
            toolbar.Items.Add(colorBoxItem)
            Dim splitButton As NMenuSplitButton = New NMenuSplitButton()
            splitButton.ActionButton.Content = NWidget.FromObject("Send/Receive")
            splitButton.Menu.Items.Add(New NMenuItem("Send Receive All"))
            AddHandler splitButton.SelectedIndexChanged, AddressOf OnSplitButtonSelectedIndexChanged
            splitButton.Menu.Items.Add(New NMenuItem("Send All"))
            splitButton.Menu.Items.Add(New NMenuItem("Receive All"))
            toolbar.Items.Add(splitButton)

            'Add toggle button which enable/disables the next fill split button.
            Dim toggleButton As NToggleButton = New NToggleButton("Enable")
            AddHandler toggleButton.CheckedChanged, AddressOf OnToggleButtonCheckedChanged
            toolbar.Items.Add(toggleButton)

            ' Add fill split button
            Dim fillButton As NFillSplitButton = New NFillSplitButton()
            fillButton.Tooltip = New NTooltip("Select Fill")
            fillButton.Enabled = False
            toolbar.Items.Add(fillButton)

            ' Add shadow split button
            Dim shadowButton As NShadowSplitButton = New NShadowSplitButton()
            shadowButton.Tooltip = New NTooltip("Select Shadow")
            toolbar.Items.Add(shadowButton)

            ' Add stroke split button
            Dim strokeButton As NStrokeSplitButton = New NStrokeSplitButton()
            strokeButton.Tooltip = New NTooltip("Select Stroke")
            toolbar.Items.Add(strokeButton)
            manager.Content = New NLabel("Content Goes Here")
            manager.Content.AllowFocus = True
            AddHandler manager.Content.MouseDown, New [Function](Of NMouseButtonEventArgs)(AddressOf OnContentMouseDown)
            manager.Content.Border = NBorder.CreateFilledBorder(NColor.Black)
            manager.Content.BackgroundFill = New NColorFill(NColor.White)
            manager.Content.BorderThickness = New NMargins(1)
            AddHandler manager.Content.GotFocus, New [Function](Of NFocusChangeEventArgs)(AddressOf OnContentGotFocus)
            AddHandler manager.Content.LostFocus, New [Function](Of NFocusChangeEventArgs)(AddressOf OnContentLostFocus)
            Return manager
        End Function

        Protected Overrides Function CreateExampleControls() As NWidget
            Return Nothing
        End Function

        Protected Overrides Function GetExampleDescription() As String
            Return "
<p>
	This example demonstrates how to create and populate various types of command bars such as menu bars and toolbars.
</p>
"
        End Function

#End Region

#Region "Implementation"

        Private Function CreateFileMenu() As NMenuDropDown
            Dim file As NMenuDropDown = New NMenuDropDown("File")
            Dim newMenuItem = CreateMenuItem("New", Presentation.NResources.Image_File_New_png)
            file.Items.Add(newMenuItem)
            newMenuItem.Items.Add(New NMenuItem("Project"))
            newMenuItem.Items.Add(New NMenuItem("Web Site"))
            newMenuItem.Items.Add(New NMenuItem("File"))
            Dim openMenuItem = CreateMenuItem("Open", Presentation.NResources.Image_File_Open_png)
            file.Items.Add(openMenuItem)
            openMenuItem.Items.Add(New NMenuItem("Project"))
            openMenuItem.Items.Add(New NMenuItem("Web Site"))
            openMenuItem.Items.Add(New NMenuItem("File"))
            file.Items.Add(New NMenuSeparator())
            file.Items.Add(CreateMenuItem("Save", Presentation.NResources.Image_File_Save_png))
            file.Items.Add(CreateMenuItem("Save As...", Presentation.NResources.Image_File_SaveAs_png))
            Return file
        End Function

        Private Function CreateEditMenu() As NMenuDropDown
            Dim edit As NMenuDropDown = New NMenuDropDown("Edit")
            edit.Items.Add(CreateMenuItem("Undo", Presentation.NResources.Image_Edit_Undo_png))
            edit.Items.Add(CreateMenuItem("Redo", Presentation.NResources.Image_Edit_Redo_png))
            edit.Items.Add(New NMenuSeparator())
            edit.Items.Add(CreateMenuItem("Cut", Presentation.NResources.Image_Edit_Cut_png))
            edit.Items.Add(CreateMenuItem("Copy", Presentation.NResources.Image_Edit_Copy_png))
            edit.Items.Add(CreateMenuItem("Paste", Presentation.NResources.Image_Edit_Paste_png))
            Return edit
        End Function

        Private Function CreateViewMenu() As NMenuDropDown
            Dim view As NMenuDropDown = New NMenuDropDown("View")
            view.Items.Add(CreateCheckableMenuItem("Normal", Text.NResources.Image_Layout_Normal_png))
            view.Items.Add(CreateCheckableMenuItem("Web Layout", Text.NResources.Image_Layout_Web_png))
            view.Items.Add(CreateCheckableMenuItem("Print Layout", Text.NResources.Image_Layout_Print_png))
            view.Items.Add(New NMenuSeparator())
            view.Items.Add(New NMenuItem("Task Pane"))
            view.Items.Add(New NMenuItem("Toolbars"))
            view.Items.Add(New NMenuItem("Ruler"))
            Return view
        End Function

        Private Sub AddToggleToolBarItem(ByVal toolBar As NToolBar, ByVal image As NImage, ByVal tooltip As String)
            Dim item As NToggleButton = New NToggleButton(image)
            item.Tooltip = New NTooltip(tooltip)
            NCommandBar.SetText(item, tooltip)
            NCommandBar.SetImage(item, image)
            toolBar.Items.Add(item)
        End Sub

        Private Sub AddToolBarItem(ByVal toolBar As NToolBar, ByVal image As NImage)
            AddToolBarItem(toolBar, image, Nothing)
        End Sub

        Private Sub AddToolBarItem(ByVal toolBar As NToolBar, ByVal image As NImage, ByVal text As String)
            AddToolBarItem(toolBar, image, text, text)
        End Sub

        Private Sub AddToolBarItem(ByVal toolBar As NToolBar, ByVal image As NImage, ByVal text As String, ByVal tooltip As String)
            Dim item As NWidget

            If Equals(text, Nothing) Then
                text = String.Empty
            End If

            If image Is Nothing Then
                item = New NButton(text)
            Else
                item = New NButton(NPairBox.Create(image, text))
            End If

            If Not String.IsNullOrEmpty(tooltip) Then
                item.Tooltip = New NTooltip(tooltip)
            End If

            toolBar.Items.Add(item)
            NCommandBar.SetText(item, text)

            If image IsNot Nothing Then
                Call NCommandBar.SetImage(item, CType(image.DeepClone(), NImage))
            End If
        End Sub

        Private Function CreateMenuItem(ByVal text As String, ByVal image As NImage) As NMenuItem
            If image Is Nothing Then
                Return New NMenuItem(text)
            Else
                Dim imageBox As NImageBox = New NImageBox(image)
                imageBox.HorizontalPlacement = ENHorizontalPlacement.Center
                imageBox.VerticalPlacement = ENVerticalPlacement.Center
                Return New NMenuItem(imageBox, text)
            End If
        End Function

        Private Function CreateCheckableMenuItem(ByVal text As String, ByVal image As NImage) As NCheckableMenuItem
            Dim item As NCheckableMenuItem = New NCheckableMenuItem(text)
            AddHandler item.CheckedChanging, AddressOf item_CheckedChanging
            AddHandler item.CheckedChanged, AddressOf item_CheckedChanged

            If image IsNot Nothing Then
                Dim imageBox As NImageBox = New NImageBox(image)
                imageBox.HorizontalPlacement = ENHorizontalPlacement.Center
                imageBox.VerticalPlacement = ENVerticalPlacement.Center
                item.Header = imageBox
                item.Content = New NLabel(text)
            End If

            Return item
        End Function

#End Region

#Region "Event Handlers"

        Private Sub OnContentLostFocus(ByVal args As NFocusChangeEventArgs)
            TryCast(args.TargetNode, NLabel).Border = NBorder.CreateFilledBorder(NColor.Black)
        End Sub

        Private Sub OnContentGotFocus(ByVal args As NFocusChangeEventArgs)
            TryCast(args.TargetNode, NLabel).Border = NBorder.CreateFilledBorder(NColor.Red)
        End Sub

        Private Sub OnContentMouseDown(ByVal args As NMouseButtonEventArgs)
            TryCast(args.TargetNode, NLabel).Focus()
        End Sub

        Private Sub OnSplitButtonSelectedIndexChanged(ByVal arg As NValueChangeEventArgs)
            Dim menuSplitButton = CType(arg.CurrentTargetNode, NMenuSplitButton)
            Dim menuItem = CType(menuSplitButton.Items(menuSplitButton.SelectedIndex), NMenuItem)
            Dim label = CType(menuItem.Content, NLabel)
            menuSplitButton.ActionButton.Content = NWidget.FromObject(label.Text)
        End Sub

        Private Sub OnToggleButtonCheckedChanged(ByVal arg As NValueChangeEventArgs)
            Dim button As NToggleButton = TryCast(arg.CurrentTargetNode, NToggleButton)

            If button Is Nothing Then
                Return
            End If

            'Get the toolbar items collection and enable or disable the next button in the collection
            Dim toolbarItems As NCommandBarItemCollection = TryCast(button.ParentNode, NCommandBarItemCollection)

            If toolbarItems Is Nothing Then
                Return
            End If

            Dim buttonIndex = toolbarItems.IndexOfChild(button)
            Dim fillSplitButton As NFillSplitButton = TryCast(toolbarItems(buttonIndex + 1), NFillSplitButton)

            If fillSplitButton Is Nothing Then
                Return
            End If

            If button.Checked Then
                fillSplitButton.Enabled = True
                CType(button.Content, NLabel).Text = "Disable"
            Else
                fillSplitButton.Enabled = False
                CType(button.Content, NLabel).Text = "Enable"
            End If
        End Sub

        Private Sub item_CheckedChanging(ByVal arg As NValueChangeEventArgs)
            Dim isChecked As Boolean = arg.NewValue
            If isChecked Then Return

            ' Make sure the user is not trying to uncheck the checked item
            Dim item = CType(arg.TargetNode, NCheckableMenuItem)
            Dim items As NMenuItemCollection = TryCast(item.ParentNode, NMenuItemCollection)
            Dim i = 0, count = items.Count

            While i < count
                Dim currentItem As NCheckableMenuItem = TryCast(items(i), NCheckableMenuItem)

                If currentItem Is Nothing Then
                    Continue While
                End If

                If currentItem IsNot item AndAlso currentItem.Checked Then Return
                i += 1
            End While

            arg.Cancel = True
        End Sub

        Private Sub item_CheckedChanged(ByVal arg As NValueChangeEventArgs)
            Dim isChecked As Boolean = arg.NewValue
            If isChecked = False Then Return
            Dim item = CType(arg.TargetNode, NCheckableMenuItem)
            Dim items As NMenuItemCollection = TryCast(item.ParentNode, NMenuItemCollection)
            Dim i = 0, count = items.Count

            While i < count
                Dim currentItem As NCheckableMenuItem = TryCast(items(i), NCheckableMenuItem)

                If currentItem Is Nothing Then
                    Continue While
                End If

                If currentItem IsNot item AndAlso currentItem.Checked Then
                    ' We've found the previously checked item, so uncheck it
                    currentItem.Checked = False
                    Exit While
                End If

                i += 1
            End While
        End Sub
#End Region

#Region "Schema"

        ''' <summary>
        ''' Schema associated with NCommandBarsExample.
        ''' </summary>
        Public Shared ReadOnly NCommandBarsExampleSchema As NSchema

#End Region
    End Class
End Namespace

Imports Nevron.Nov.Dom
Imports Nevron.Nov.Graphics
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.UI
    Public Class NWrappableCommandBarsExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' Default constructor.
        ''' </summary>
        Public Sub New()
        End Sub
        ''' <summary>
        ''' Static constructor.
        ''' </summary>
        Shared Sub New()
            NWrappableCommandBarsExampleSchema = NSchema.Create(GetType(NWrappableCommandBarsExample), NExampleBase.NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            Dim manager As NCommandBarManager = New NCommandBarManager()

            ' create two lanes
            Dim lane0 As NCommandBarLane = New NCommandBarLane()
            manager.TopDock.Add(lane0)

            ' create some toolbars in the second lane
            For i = 0 To 9
                Dim toolBar As NToolBar = New NToolBar()
                lane0.Add(toolBar)
                toolBar.Text = "Bar" & i.ToString()

                For j = 0 To 7
                    Dim name As String = "BTN " & i.ToString() & "." & j.ToString()

                    Dim item As NWidget
                    If j = 2 Then
                        item = New NColorBox()
                    ElseIf j = 3 Then
                        Dim msb As NMenuSplitButton = New NMenuSplitButton()
                        msb.ActionButton.Content = NWidget.FromObject("Send/Receive")
                        msb.Menu.Items.Add(New NMenuItem("Send Receive All"))
                        msb.Menu.Items.Add(New NMenuItem("Send All"))
                        msb.Menu.Items.Add(New NMenuItem("Receive All"))
                        item = msb
                    ElseIf j = 4 Then
                        Dim comboBox As NComboBox = New NComboBox()
                        comboBox.Items.Add(New NComboBoxItem("Item 1"))
                        comboBox.Items.Add(New NComboBoxItem("Item 2"))
                        comboBox.Items.Add(New NComboBoxItem("Item 3"))
                        comboBox.Items.Add(New NComboBoxItem("Item 4"))
                        item = comboBox
                    Else
                        item = New NButton(name)
                    End If

                    NCommandBar.SetText(item, name)
                    toolBar.Items.Add(item)

                    If j = 2 OrElse j = 6 Then
                        toolBar.Items.Add(New NCommandBarSeparator())
                    End If
                Next

                If i = 2 Then
                    toolBar.Wrappable = True
                End If
            Next

            manager.Content = New NLabel("Content Goes Here")
            manager.Content.AllowFocus = True
            manager.Content.MouseDown += New [Function](Of NMouseButtonEventArgs)(AddressOf OnContentMouseDown)
            manager.Content.Border = NBorder.CreateFilledBorder(NColor.Black)
            manager.Content.BackgroundFill = New NColorFill(NColor.White)
            manager.Content.BorderThickness = New NMargins(1)
            manager.Content.GotFocus += New [Function](Of NFocusChangeEventArgs)(AddressOf OnContentGotFocus)
            manager.Content.LostFocus += New [Function](Of NFocusChangeEventArgs)(AddressOf OnContentLostFocus)

            Return manager
        End Function
        Protected Overrides Function CreateExampleControls() As NWidget
            Return Nothing
        End Function
        Protected Overrides Function GetExampleDescription() As String
            Return "
<p>
	This example demonstrates multiline and wrappable toolbars.
</p>
" End Function

#End Region

#Region "Event Handlers"

        Private Sub OnContentLostFocus(ByVal args As NFocusChangeEventArgs)
            TryCast(args.TargetNode, NLabel).Border = NBorder.CreateFilledBorder(NColor.Black)
        End Sub
        Private Sub OnContentGotFocus(ByVal args As NFocusChangeEventArgs)
            TryCast(args.TargetNode, NLabel).Border = NBorder.CreateFilledBorder(NColor.Red)
        End Sub
        Private Sub OnContentMouseDown(ByVal args As NMouseButtonEventArgs)
            TryCast(args.TargetNode, NLabel).Focus()
        End Sub

#End Region

#Region "Schema"

        ''' <summary>
        ''' Schema associated with NWrappableCommandBarsExample.
        ''' </summary>
        Public Shared ReadOnly NWrappableCommandBarsExampleSchema As NSchema

#End Region
    End Class
End Namespace

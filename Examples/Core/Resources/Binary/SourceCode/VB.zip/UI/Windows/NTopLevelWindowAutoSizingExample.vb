Imports Nevron.Nov.Dom
Imports Nevron.Nov.Graphics
Imports Nevron.Nov.Layout
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.UI
    Public Class NTopLevelWindowAutoSizingExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' Default constructor.
        ''' </summary>
        Public Sub New()
        End Sub
        ''' <summary>
        ''' Static constructor.
        ''' </summary>
        Shared Sub New()
            NTopLevelWindowAutoSizingExampleSchema = NSchema.Create(GetType(NTopLevelWindowAutoSizingExample), NExampleBase.NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            Dim stack As NStackPanel = New NStackPanel()

            ' Create the example's content
            Dim openYAutoSizeWindowButton As NButton = New NButton("Open Y auto sizable Window...")
            openYAutoSizeWindowButton.HorizontalPlacement = ENHorizontalPlacement.Left
            openYAutoSizeWindowButton.VerticalPlacement = ENVerticalPlacement.Top
            openYAutoSizeWindowButton.Click += New [Function](Of NEventArgs)(AddressOf OnOpenYAutoSizeWindowButtonClick)
            stack.Add(openYAutoSizeWindowButton)

            Dim openXAutoSizeWindowButton As NButton = New NButton("Open X auto sizable Window...")
            openXAutoSizeWindowButton.HorizontalPlacement = ENHorizontalPlacement.Left
            openXAutoSizeWindowButton.VerticalPlacement = ENVerticalPlacement.Top
            openXAutoSizeWindowButton.Click += New [Function](Of NEventArgs)(AddressOf OnOpenXAutoSizeWindowButtonClick)
            stack.Add(openXAutoSizeWindowButton)

            Dim openAutoSizeWindowButton As NButton = New NButton("Open X and Y auto sizable and auto centered Window...")
            openAutoSizeWindowButton.HorizontalPlacement = ENHorizontalPlacement.Left
            openAutoSizeWindowButton.VerticalPlacement = ENVerticalPlacement.Top
            openAutoSizeWindowButton.Click += New [Function](Of NEventArgs)(AddressOf OnOpenAutoSizeWindowButtonClick)
            stack.Add(openAutoSizeWindowButton)

            Return stack
        End Function
        Protected Overrides Function CreateExampleControls() As NWidget
            Return Nothing
        End Function
        Protected Overrides Function GetExampleDescription() As String
            Return "
<p>
This example demonstrates how to create auto sizable and auto centered windows with expressions.
</p>
" End Function

#End Region

#Region "Event Handlers"

        Private Sub OnOpenXAutoSizeWindowButtonClick(ByVal arg As NEventArgs)
            Dim window As NTopLevelWindow = New NTopLevelWindow()
            window.Modal = True

            ' allow the user to resize the Y window dimension
            window.AllowYResize = True

            ' bind the window Width to the desired width of the window
            Dim bindingFx As NBindingFx = New NBindingFx(window, NBoxElement.DesiredWidthProperty)
            bindingFx.Guard = True
            window.SetFx(NBoxElement.WidthProperty, bindingFx)

            ' create a wrap flow panel with Y direction
            Dim wrapPanel As NWrapFlowPanel = New NWrapFlowPanel()
            wrapPanel.Direction = ENHVDirection.TopToBottom
            window.Content = wrapPanel

            For i = 0 To 9
                wrapPanel.Add(New NButton("Button" & i))
            Next

            ' open the window
            DisplayWindow.Windows.Add(window)
            window.Open()
        End Sub
        Private Sub OnOpenYAutoSizeWindowButtonClick(ByVal arg As NEventArgs)
            Dim window As NTopLevelWindow = New NTopLevelWindow()
            window.Modal = True

            ' allow the user to resize the X window dimension
            window.AllowXResize = True

            ' bind the window Height to the desired height of the window
            Dim bindingFx As NBindingFx = New NBindingFx(window, NBoxElement.DesiredHeightProperty)
            bindingFx.Guard = True
            window.SetFx(NBoxElement.HeightProperty, bindingFx)

            ' create a wrap flow panel (by default flows from left to right)
            Dim wrapPanel As NWrapFlowPanel = New NWrapFlowPanel()
            window.Content = wrapPanel

            For i = 0 To 9
                wrapPanel.Add(New NButton("Button" & i))
            Next

            ' open the window
            DisplayWindow.Windows.Add(window)
            window.Open()
        End Sub
        Private Sub OnOpenAutoSizeWindowButtonClick(ByVal arg As NEventArgs)
            Dim window As NTopLevelWindow = New NTopLevelWindow()
            window.Modal = True

            ' open the window in the center of its parent, 
            window.StartPosition = ENWindowStartPosition.CenterOwnerWindow

            ' implement auto width and height sizing
            If True Then
                ' bind the window Width to the DefaultWidth of the window
                Dim widthBindingFx As NBindingFx = New NBindingFx(window, NBoxElement.DefaultWidthProperty)
                widthBindingFx.Guard = True
                window.SetFx(NBoxElement.WidthProperty, widthBindingFx)

                ' bind the window Height to the DefaultHeight of the window
                Dim heightBindingFx As NBindingFx = New NBindingFx(window, NBoxElement.DesiredHeightProperty)
                heightBindingFx.Guard = True
                window.SetFx(NBoxElement.HeightProperty, heightBindingFx)
            End If

            ' implement auto center 
            If True Then
                ' scratch X and Y define the window center 
                ' they are implemented by simply calculating the center X and Y via formulas
                window.SetFx(NScratchPropertyEx.XPropertyEx, "X+Width/2")
                window.SetFx(NScratchPropertyEx.YPropertyEx, "Y+Height/2")

                ' now that we have an automatic center, we need to write expressions that define the X and Y from that center. 
                ' These are cyclic expressions - CenterX depends on X, and X depends on CenterX.
                ' The expressions that are assigned to X and Y are guarded and permeable. 
                '    guard is needed because X and Y are updated when the user moves the window around.
                '    permeable is needed to allow the X and Y values to change when the user moves the window around.
                ' When the the X and Y values change -> center changes -> X and Y expressions are triggered but they produce the same X and Y results and the cycle ends.
                ' When the Width and Height change -> center changes -> X and Y expression are triggered but they produce the same X and Y results and the cycle ends.
                Dim xfx As NFormulaFx = New NFormulaFx(NScratchPropertyEx.XPropertyEx.Name & "-Width/2")
                xfx.Guard = True
                xfx.Permeable = True
                window.SetFx(NBoxElement.XProperty, xfx)

                Dim yfx As NFormulaFx = New NFormulaFx(NScratchPropertyEx.YPropertyEx.Name & "-Height/2")
                yfx.Guard = True
                yfx.Permeable = True
                window.SetFx(NBoxElement.YProperty, yfx)
            End If

            ' create a dummy tab that sizes to the currently selected page,
            ' and add two pages with different sizes to the tab.
            Dim tab As NTab = New NTab()
            window.Content = tab
            tab.SizeToSelectedPage = True

            Dim page1 As NTabPage = New NTabPage("Small Content")
            Dim btn As NButton = New NButton("I am small")
            page1.Content = btn
            tab.TabPages.Add(page1)

            Dim page2 As NTabPage = New NTabPage("Large Content")
            Dim btn2 As NButton = New NButton("I am LARGE")
            btn2.PreferredSize = New NSize(200, 200)
            page2.Content = btn2
            tab.TabPages.Add(page2)

            ' open the window
            DisplayWindow.Windows.Add(window)
            window.Open()
        End Sub

#End Region

#Region "Schema"

        ''' <summary>
        ''' Schema associated with NTopLevelWindowAutoSizingExample.
        ''' </summary>
        Public Shared ReadOnly NTopLevelWindowAutoSizingExampleSchema As NSchema

#End Region
    End Class
End Namespace

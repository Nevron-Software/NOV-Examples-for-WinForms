Imports Nevron.Nov.Dom
Imports Nevron.Nov.Graphics
Imports Nevron.Nov.Layout
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.UI
    Public Class NProgressWindowExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' Default constructor.
        ''' </summary>
        Public Sub New()
        End Sub

        ''' <summary>
        ''' Static constructor.
        ''' </summary>
        Shared Sub New()
            NProgressWindowExampleSchema = NSchema.Create(GetType(NProgressWindowExample), NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            Dim stack As NStackPanel = New NStackPanel()
            stack.Padding = New NMargins(10)
            stack.HorizontalPlacement = ENHorizontalPlacement.Left
            m_ShowButton = New NButton("Show Window")
            AddHandler m_ShowButton.Click, AddressOf OnShowButtonClick
            stack.Add(m_ShowButton)
            m_CloseButton = New NButton("Close Window")
            m_CloseButton.Enabled = False
            AddHandler m_CloseButton.Click, AddressOf OnCloseButtonClick
            stack.Add(m_CloseButton)
            m_IncreaseProgressButton = New NButton("Increase Progress")
            m_IncreaseProgressButton.Visibility = ENVisibility.Hidden
            AddHandler m_IncreaseProgressButton.Click, AddressOf OnIncreaseProgressButtonClick
            stack.Add(m_IncreaseProgressButton)
            Return stack
        End Function

        Protected Overrides Function CreateExampleControls() As NWidget
            Dim stack As NStackPanel = New NStackPanel()
            m_ProgressHeaderTextBox = New NTextBox("Header Text")
            stack.Add(NPairBox.Create("Header:", m_ProgressHeaderTextBox))
            m_ProgressContentTextBox = New NTextBox("This is the content of the progress window.")
            stack.Add(NPairBox.Create("Content:", m_ProgressContentTextBox))
            m_ProgressFooterTextBox = New NTextBox("Footer Text")
            stack.Add(NPairBox.Create("Footer:", m_ProgressFooterTextBox))
            m_ShowCancelButtonCheckBox = New NCheckBox()
            m_ShowCancelButtonCheckBox.Checked = True
            m_ShowCancelButtonCheckBox.HorizontalPlacement = ENHorizontalPlacement.Left
            stack.Add(NPairBox.Create("Cancel button:", m_ShowCancelButtonCheckBox))
            Return New NUniSizeBoxGroup(stack)
        End Function

        Protected Overrides Function GetExampleDescription() As String
            Return "
<p>This example demonstrates how to create, show and close progress windows. They are typically used to indicate progress
during long-running operations. Click the <b>Show Window</b> button to show a progress window and the <b>Close Window</b>
button to close it. Use the controls on the right to configure the window.</p>"
        End Function

#End Region

#Region "Event Handlers"

        Private Sub OnShowButtonClick(ByVal arg As NEventArgs)
            m_ProgressWindow = NProgressWindow.Create(DisplayWindow, m_ProgressHeaderTextBox.Text)
            m_ProgressWindow.Content = If(String.IsNullOrEmpty(m_ProgressContentTextBox.Text), Nothing, New NLabel(m_ProgressContentTextBox.Text))
            m_ProgressWindow.Footer = If(String.IsNullOrEmpty(m_ProgressFooterTextBox.Text), Nothing, New NLabel(m_ProgressFooterTextBox.Text))

            If m_ShowCancelButtonCheckBox.Checked Then
                m_ProgressWindow.ButtonStrip = New NButtonStrip()
                m_ProgressWindow.ButtonStrip.AddCancelButton()
            End If

            m_ProgressWindow.Open()
            m_CloseButton.Enabled = True
            m_IncreaseProgressButton.Enabled = True
            m_IncreaseProgressButton.Visibility = ENVisibility.Visible
        End Sub

        Private Sub OnCloseButtonClick(ByVal arg As NEventArgs)
            m_ProgressWindow.Close()
            m_CloseButton.Enabled = False
        End Sub

        Private Sub OnIncreaseProgressButtonClick(ByVal arg As NEventArgs)
            m_ProgressWindow.ProgressBar.Value += 10

            If m_ProgressWindow.ProgressBar.Value >= m_ProgressWindow.ProgressBar.Maximum Then
                m_IncreaseProgressButton.Enabled = False
            End If
        End Sub

#End Region

#Region "Fields"

        Private m_ProgressWindow As NProgressWindow
        Private m_ShowButton As NButton
        Private m_CloseButton As NButton
        Private m_IncreaseProgressButton As NButton

        ' Controls
        Private m_ProgressHeaderTextBox As NTextBox
        Private m_ProgressContentTextBox As NTextBox
        Private m_ProgressFooterTextBox As NTextBox
        Private m_ShowCancelButtonCheckBox As NCheckBox

#End Region

#Region "Schema"

        ''' <summary>
        ''' Schema associated with NProgressWindowExample.
        ''' </summary>
        Public Shared ReadOnly NProgressWindowExampleSchema As NSchema

#End Region
    End Class
End Namespace

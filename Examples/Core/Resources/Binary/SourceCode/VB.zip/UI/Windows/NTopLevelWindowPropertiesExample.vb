Imports Nevron.Nov.Dom
Imports Nevron.Nov.Editors
Imports Nevron.Nov.Graphics
Imports Nevron.Nov.Layout
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.UI
    Public Class NTopLevelWindowPropertiesExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' Default constructor.
        ''' </summary>
        Public Sub New()
        End Sub
        ''' <summary>
        ''' Static constructor.
        ''' </summary>
        Shared Sub New()
            NTopLevelWindowPropertiesExampleSchema = NSchema.Create(GetType(NTopLevelWindowPropertiesExample), NExampleBase.NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            ' Create and initialize a top level window
            m_Window = New NTopLevelWindow()
            m_Window.Title = "Top Level Window"
            m_Window.RemoveFromParentOnClose = True
            m_Window.AllowXResize = True
            m_Window.AllowYResize = True
            m_Window.PreferredSize = New NSize(300, 300)
            m_Window.QueryManualStartPosition += New [Function](Of NEventArgs)(AddressOf OnWindowQueryManualStartPosition)
            m_Window.Closed += New [Function](Of NEventArgs)(AddressOf OnWindowClosed)

            ' Create the top level window's content
            Dim stack As NStackPanel = New NStackPanel()
            stack.FitMode = ENStackFitMode.First
            stack.FillMode = ENStackFillMode.First

            Dim label As NLabel = New NLabel("This is a top level window.")
            label.HorizontalPlacement = ENHorizontalPlacement.Center
            label.VerticalPlacement = ENVerticalPlacement.Center
            stack.Add(label)

            Dim closeButton As NButton = New NButton("Close")
            closeButton.HorizontalPlacement = ENHorizontalPlacement.Center
            closeButton.Click += New [Function](Of NEventArgs)(AddressOf OnCloseButtonClick)
            stack.Add(closeButton)
            m_Window.Content = stack

            ' Create example content
            m_SettingsStack = New NStackPanel()
            m_SettingsStack.HorizontalPlacement = ENHorizontalPlacement.Left



            Dim editors = NDesigner.GetDesigner(m_Window).CreatePropertyEditors(m_Window, NTopLevelWindow.TitleProperty, NTopLevelWindow.StartPositionProperty, NBoxElement.XProperty, NBoxElement.YProperty, NStylePropertyEx.ExtendedLookPropertyEx, NTopLevelWindow.ModalProperty, NTopLevelWindow.ShowInTaskbarProperty, NTopLevelWindow.ShowTitleBarProperty, NTopLevelWindow.ShowControlMenuProperty, NTopLevelWindow.ShowControlBoxProperty, NTopLevelWindow.AllowMinimizeProperty, NTopLevelWindow.AllowMaximizeProperty, NTopLevelWindow.AllowXResizeProperty, NTopLevelWindow.AllowYResizeProperty)

            ' Change the text of the extended look property editor
            label = CType(editors(4).GetFirstDescendant(New NInstanceOfSchemaFilter(NLabel.NLabelSchema)), NLabel)
            label.Text = "Extended Look:"

            ' Add the created property editors to the stack
            Dim i = 0, count = editors.Count

            While i < count
                m_SettingsStack.Add(editors(i))
                i += 1
            End While

            ' Create a button that opens the window
            Dim openWindowButton As NButton = New NButton("Open Window...")
            openWindowButton.Content.HorizontalPlacement = ENHorizontalPlacement.Center
            openWindowButton.Click += New [Function](Of NEventArgs)(AddressOf OnOpenWindowButtonClick)
            m_SettingsStack.Add(openWindowButton)

            Return New NUniSizeBoxGroup(m_SettingsStack)
        End Function
        Protected Overrides Function CreateExampleControls() As NWidget
            Return Nothing
        End Function
        Protected Overrides Function GetExampleDescription() As String
            Return "
<p>
	This example demonstrates how to create, configure and open top level windows. Use the controls
	above to configure the properties of the top level window and then click ""Open Window...""
	button to show it.
</p>
" End Function
        Protected Friend Overrides Sub OnClosing()
            MyBase.OnClosing()

            m_Window.Close()
        End Sub

#End Region

#Region "Event Handlers"

        Private Sub OnOpenWindowButtonClick(ByVal args As NEventArgs)
            DisplayWindow.Windows.Add(m_Window)
            m_Window.Open()
            m_SettingsStack.Enabled = False
        End Sub
        Private Sub OnCloseButtonClick(ByVal args As NEventArgs)
            m_Window.Close()
        End Sub
        Private Sub OnWindowQueryManualStartPosition(ByVal args As NEventArgs)
            ' Get the top level window which queries for position
            Dim window = CType(args.TargetNode, NTopLevelWindow)

            ' Set the top level window bounds (in DIPs)
            window.Bounds = New NRectangle(window.X, window.Y, window.DefaultWidth, window.DefaultHeight)
        End Sub
        Private Sub OnWindowClosed(ByVal args As NEventArgs)
            m_SettingsStack.Enabled = True
        End Sub

#End Region

#Region "Fields"

        Private m_Window As NTopLevelWindow
        Private m_SettingsStack As NStackPanel

#End Region

#Region "Schema"

        ''' <summary>
        ''' Schema associated with NTopLevelWindowPropertiesExample.
        ''' </summary>
        Public Shared ReadOnly NTopLevelWindowPropertiesExampleSchema As NSchema

#End Region
    End Class
End Namespace

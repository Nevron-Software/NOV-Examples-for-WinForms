Imports Nevron.Nov.Dom
Imports Nevron.Nov.Graphics
Imports Nevron.Nov.Layout
Imports Nevron.Nov.UI
Imports Nevron.Nov.Editors

Namespace Nevron.Nov.Examples.UI
    Public Class NListBoxFirstLookExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' Default constructor.
        ''' </summary>
        Public Sub New()
        End Sub
        ''' <summary>
        ''' Static constructor.
        ''' </summary>
        Shared Sub New()
            NListBoxFirstLookExampleSchema = NSchema.Create(GetType(NListBoxFirstLookExample), NExampleBase.NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            ' Create a list box
            m_ListBox = New NListBox()
            m_ListBox.HorizontalPlacement = ENHorizontalPlacement.Left
            m_ListBox.PreferredSize = New NSize(200, 400)

            ' Add some items
            For i = 0 To 99
                m_ListBox.Items.Add(New NListBoxItem("Item " & i.ToString()))
            Next

            ' Hook to list box selection events
            m_ListBox.Selection.Selected += New [Function](Of NSelectEventArgs(Of NListBoxItem))(AddressOf OnListBoxItemSelected)
            m_ListBox.Selection.Deselected += New [Function](Of NSelectEventArgs(Of NListBoxItem))(AddressOf OnListBoxItemDeselected)

            Return m_ListBox
        End Function
        Protected Overrides Function CreateExampleControls() As NWidget
            Dim stack As NStackPanel = New NStackPanel()
            stack.FillMode = ENStackFillMode.Last
            stack.FitMode = ENStackFitMode.Last

            ' Create the properties group box
            stack.Add(CreatePropertiesGroupBox())

            ' Create the events log
            m_EventsLog = New NExampleEventsLog()
            stack.Add(m_EventsLog)

            Return stack
        End Function
        Protected Overrides Function GetExampleDescription() As String
            Return "
<p>
	This example demonstrates how to create a simple list box with text only items. You can use the controls
	on the right to modify various properties of the list box.
</p>
" End Function

#End Region

#Region "Implementation"

        Private Function CreatePropertiesGroupBox() As NGroupBox
            Dim propertiesStack As NStackPanel = New NStackPanel()
            Dim editors = NDesigner.GetDesigner(m_ListBox).CreatePropertyEditors(m_ListBox, NInputElement.EnabledProperty, NWidget.HorizontalPlacementProperty, NWidget.VerticalPlacementProperty, NScrollContentBase.HScrollModeProperty, NScrollContentBase.VScrollModeProperty, NScrollContentBase.NoScrollHAlignProperty, NScrollContentBase.NoScrollVAlignProperty, NListBox.IntegralVScrollProperty)

            Dim i = 0, count = editors.Count

            While i < count
                propertiesStack.Add(editors(i))
                i += 1
            End While

            Dim propertiesGroupBox As NGroupBox = New NGroupBox("Properties", New NUniSizeBoxGroup(propertiesStack))
            Return propertiesGroupBox
        End Function

#End Region

#Region "Event Handlers"

        Private Sub OnListBoxItemSelected(ByVal args As NSelectEventArgs(Of NListBoxItem))
            Dim item = args.Item
            Dim index As Integer = item.GetAggregationInfo().Index
            m_EventsLog.LogEvent("Selected Item: " & index.ToString())
        End Sub
        Private Sub OnListBoxItemDeselected(ByVal args As NSelectEventArgs(Of NListBoxItem))
            Dim item = args.Item
            Dim index As Integer = item.GetAggregationInfo().Index
            m_EventsLog.LogEvent("Deselected Item: " & index.ToString())
        End Sub

#End Region

#Region "Fields"

        Private m_ListBox As NListBox
        Private m_EventsLog As NExampleEventsLog

#End Region

#Region "Schema"

        ''' <summary>
        ''' Schema associated with NListBoxFirstLookExample.
        ''' </summary>
        Public Shared ReadOnly NListBoxFirstLookExampleSchema As NSchema

#End Region
    End Class
End Namespace

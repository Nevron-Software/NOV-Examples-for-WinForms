Imports Nevron.Nov.Dom
Imports Nevron.Nov.Editors
Imports Nevron.Nov.Graphics
Imports Nevron.Nov.Layout
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.UI
    Public Class NShadowSplitButtonExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' Default constructor.
        ''' </summary>
        Public Sub New()
        End Sub
        ''' <summary>
        ''' Static constructor.
        ''' </summary>
        Shared Sub New()
            NShadowSplitButtonExampleSchema = NSchema.Create(GetType(NShadowSplitButtonExample), NExampleBase.NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            m_ShadowSplitButton = New NShadowSplitButton()
            m_ShadowSplitButton.HorizontalPlacement = ENHorizontalPlacement.Left
            m_ShadowSplitButton.VerticalPlacement = ENVerticalPlacement.Top
            AddHandler m_ShadowSplitButton.SelectedValueChanged, AddressOf OnShadowSplitButtonSelectedValueChanged
            Return m_ShadowSplitButton
        End Function

        Protected Overrides Function CreateExampleControls() As NWidget
            Dim editors = NDesigner.GetDesigner(m_ShadowSplitButton).CreatePropertyEditors(m_ShadowSplitButton, NInputElement.EnabledProperty, NWidget.HorizontalPlacementProperty, NWidget.VerticalPlacementProperty, NDropDownEdit.DropDownButtonPositionProperty, NShadowSplitButton.HasAutomaticButtonProperty, NShadowSplitButton.HasNoneButtonProperty, NShadowSplitButton.HasMoreOptionsButtonProperty)
            Dim stack As NStackPanel = New NStackPanel()
            stack.FillMode = ENStackFillMode.Last
            stack.FitMode = ENStackFitMode.Last

            For i = 0 To editors.Count - 1
                stack.Add(editors(i))
            Next

            m_EventsLog = New NExampleEventsLog()
            stack.Add(m_EventsLog)
            Return New NUniSizeBoxGroup(stack)
        End Function

        Protected Overrides Function GetExampleDescription() As String
            Return "
<p>
	This example demonstrates how to create and use shadow split buttons. Split buttons are drop down edits,
	whose item slot is filled with an action button, which generates a <b>Click</b> event on behalf of the
	split button. The shadow split button's drop down content provides the user with a convenient way to quickly
	select a shadow.
</p>
"
        End Function

#End Region

#Region "Event Handlers"

        Private Sub OnShadowSplitButtonSelectedValueChanged(ByVal arg As NValueChangeEventArgs)
            Dim selectedValue As NAutomaticValue(Of NShadow) = arg.NewValue
            Dim str As String

            If selectedValue.Automatic Then
                str = "Automatic"
            ElseIf selectedValue.Value Is Nothing Then
                str = "None"
            Else
                str = selectedValue.Value.ToString()
            End If

            m_EventsLog.LogEvent("Selected shadow: " & str)
        End Sub

#End Region

#Region "Fields"

        Private m_EventsLog As NExampleEventsLog
        Private m_ShadowSplitButton As NShadowSplitButton

#End Region

#Region "Schema"

        Public Shared ReadOnly NShadowSplitButtonExampleSchema As NSchema

#End Region
    End Class
End Namespace

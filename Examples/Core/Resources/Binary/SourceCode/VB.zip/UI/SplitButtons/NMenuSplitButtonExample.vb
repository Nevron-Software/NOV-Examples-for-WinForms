Imports Nevron.Nov.Dom
Imports Nevron.Nov.Editors
Imports Nevron.Nov.Graphics
Imports Nevron.Nov.Layout
Imports Nevron.Nov.Text
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.UI
    Public Class NMenuSplitButtonExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' Default constructor.
        ''' </summary>
        Public Sub New()
        End Sub

        ''' <summary>
        ''' Static constructor.
        ''' </summary>
        Shared Sub New()
            NMenuSplitButtonExampleSchema = NSchema.Create(GetType(NMenuSplitButtonExample), NExampleBase.NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            ' Create an array of images to use for the headers of the menu items
            Dim BorderSideImages = New NImage() {NResources.Image_TableBorders_AllBorders_png, NResources.Image_TableBorders_NoBorder_png, NResources.Image_TableBorders_OutsideBorders_png, NResources.Image_TableBorders_InsideBorders_png, NResources.Image_TableBorders_TopBorder_png, NResources.Image_TableBorders_BottomBorder_png, NResources.Image_TableBorders_LeftBorder_png, NResources.Image_TableBorders_RightBorder_png, NResources.Image_TableBorders_InsideHorizontalBorder_png, NResources.Image_TableBorders_InsideVerticalBorder_png}

            ' Create a menu split button
            m_MenuSplitButton = New NMenuSplitButton()
            m_MenuSplitButton.HorizontalPlacement = ENHorizontalPlacement.Left
            m_MenuSplitButton.VerticalPlacement = ENVerticalPlacement.Top

            ' Fill the menu split button drop down menu from an enum and with
            ' the images created above for headers
            m_MenuSplitButton.FillFromEnum(Of ENTableBorders, NImage)(BorderSideImages)

            ' Subscribe to the SelectedIndexChanged and the Click events
            AddHandler m_MenuSplitButton.SelectedIndexChanged, AddressOf OnMenuSplitButtonSelectedIndexChanged
            AddHandler m_MenuSplitButton.Click, AddressOf OnMenuSplitButtonClick
            Return m_MenuSplitButton
        End Function

        Protected Overrides Function CreateExampleControls() As NWidget
            Dim editors = NDesigner.GetDesigner(m_MenuSplitButton).CreatePropertyEditors(m_MenuSplitButton, NInputElement.EnabledProperty, NWidget.HorizontalPlacementProperty, NWidget.VerticalPlacementProperty, NDropDownEdit.DropDownButtonPositionProperty, NMenuSplitButton.SelectedIndexProperty)
            Dim stack As NStackPanel = New NStackPanel()
            stack.FillMode = ENStackFillMode.Last
            stack.FitMode = ENStackFitMode.Last

            For i = 0 To editors.Count - 1
                stack.Add(editors(i))
            Next

            m_EventsLog = New NExampleEventsLog()
            stack.Add(m_EventsLog)
            Return New NUniSizeBoxGroup(stack)
        End Function

        Protected Overrides Function GetExampleDescription() As String
            Return "
<p>
	This example demonstrates how to create and use menu split buttons. Split buttons are drop down edits,
	whose item slot is filled with an action button, which generates a <b>Click</b> event on behalf of the
	split button. The menu split button's drop down content is a menu, which allows the user to quickly
	select an option. This option is then assigned to the action button of the split button and can be
	activated by clicking the action button.
</p>
"
        End Function

#End Region

#Region "Event Handlers"

        Private Sub OnMenuSplitButtonSelectedIndexChanged(ByVal arg As NValueChangeEventArgs)
            ' Get the selected index
            Dim selectedIndex As Integer = arg.NewValue

            If selectedIndex = -1 Then
                m_EventsLog.LogEvent("No item selected")
                Return
            End If

            ' Obtain and show the selected enum value
            Dim splitButton = CType(arg.CurrentTargetNode, NMenuSplitButton)
            Dim selectedSide As ENTableBorders = splitButton.SelectedValue
            m_EventsLog.LogEvent("Selected Index: " & selectedIndex.ToString() & " (" & selectedSide.ToString() & ")")
        End Sub

        Private Sub OnMenuSplitButtonClick(ByVal arg As NEventArgs)
            ' Get the selected index
            Dim splitButton = CType(arg.CurrentTargetNode, NMenuSplitButton)
            Dim selectedIndex = splitButton.SelectedIndex

            If selectedIndex = -1 Then
                m_EventsLog.LogEvent("No item selected")
                Return
            End If

            ' Obtain and show the selected enum value
            Dim selectedSide As ENTableBorders = splitButton.SelectedValue
            m_EventsLog.LogEvent("Action button clicked, index: " & selectedIndex.ToString() & " (" & selectedSide.ToString() & ")")
        End Sub

#End Region

#Region "Fields"

        Private m_EventsLog As NExampleEventsLog
        Private m_MenuSplitButton As NMenuSplitButton

#End Region

#Region "Schema"

        ''' <summary>
        ''' Schema associated with NMenuSplitButtonExample.
        ''' </summary>
        Public Shared ReadOnly NMenuSplitButtonExampleSchema As NSchema

#End Region
    End Class
End Namespace

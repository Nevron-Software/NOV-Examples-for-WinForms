Imports Nevron.Nov.Editors
Imports Nevron.Nov.Dom
Imports Nevron.Nov.Graphics
Imports Nevron.Nov.Layout
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.UI
    Public Class NColorBoxExample
        Inherits NExampleBase
#Region "Constructors"

        Public Sub New()
        End Sub

        Shared Sub New()
            NColorBoxExampleSchema = NSchema.Create(GetType(NColorBoxExample), NExampleBase.NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            m_ColorBox = New NColorBox()
            m_ColorBox.HorizontalPlacement = ENHorizontalPlacement.Left
            m_ColorBox.VerticalPlacement = ENVerticalPlacement.Top
            AddHandler m_ColorBox.SelectedColorChanged, AddressOf OnColorBoxSelectedColorChanged
            Return m_ColorBox
        End Function

        Protected Overrides Function CreateExampleControls() As NWidget
            Dim stack As NStackPanel = New NStackPanel()
            stack.FillMode = ENStackFillMode.Last
            stack.FitMode = ENStackFitMode.Last

            ' create the palette select combo box
            Dim paletteComboBox As NComboBox = New NComboBox()
            paletteComboBox.Items.Add(New NComboBoxItem(ENColorPaletteType.MicrosoftPaint))
            paletteComboBox.Items.Add(New NComboBoxItem(ENColorPaletteType.MicrosoftOffice2003))
            paletteComboBox.Items.Add(New NComboBoxItem(ENColorPaletteType.MicrosoftOffice2007))
            paletteComboBox.Items.Add(New NComboBoxItem(ENColorPaletteType.WebSafe))
            paletteComboBox.SelectedIndex = 2
            AddHandler paletteComboBox.SelectedIndexChanged, New [Function](Of NValueChangeEventArgs)(AddressOf OnPaletteComboBoxSelectedIndexChanged)
            stack.Add(New NPairBox("Palette:", paletteComboBox, True))

            ' add come property editors
            Dim editors = NDesigner.GetDesigner(m_ColorBox).CreatePropertyEditors(m_ColorBox, NInputElement.EnabledProperty, NColorBoxBase.ShowMoreColorsButtonProperty, NColorBoxBase.ShowOpacitySliderInDialogProperty, NColorBoxBase.SelectedColorProperty)

            For i = 0 To editors.Count - 1
                stack.Add(editors(i))
            Next

            ' create the events log
            m_EventsLog = New NExampleEventsLog()
            stack.Add(m_EventsLog)
            Return New NUniSizeBoxGroup(stack)
        End Function

        Protected Overrides Function GetExampleDescription() As String
            Return "
<p>
	This example demonstrates how to create and use a NOV color box (i.e. a drop down palette color picker). 
	The controls on the right let you change the palette of the picker, whether the drop down should have a
	""More Colors..."" button and which is the currently selected color.
</p>
"
        End Function

#End Region

#Region "Event Handlers"

        Private Sub OnPaletteComboBoxSelectedIndexChanged(ByVal args As NValueChangeEventArgs)
            Dim cbPalette = CType(args.TargetNode, NComboBox)

            Select Case cbPalette.SelectedIndex
                Case 0 ' "MS Paint"
                    m_ColorBox.Palette = New NColorPalette(ENColorPaletteType.MicrosoftPaint)
                Case 1 ' "Office 2003":
                    m_ColorBox.Palette = New NColorPalette(ENColorPaletteType.MicrosoftOffice2003)
                Case 2 ' "Office 2007":
                    m_ColorBox.Palette = New NColorPalette(ENColorPaletteType.MicrosoftOffice2007)
                Case 3 ' "Web Safe":
                    m_ColorBox.Palette = New NColorPalette(ENColorPaletteType.WebSafe)
            End Select
        End Sub

        Private Sub OnColorBoxSelectedColorChanged(ByVal args As NValueChangeEventArgs)
            Dim colorBox = CType(args.TargetNode, NColorBox)
            m_EventsLog.LogEvent(NColor.GetNameOrHex(colorBox.SelectedColor))
        End Sub

#End Region

#Region "Fields"

        Private m_ColorBox As NColorBox
        Private m_EventsLog As NExampleEventsLog

#End Region

#Region "Schema"

        Public Shared ReadOnly NColorBoxExampleSchema As NSchema

#End Region
    End Class
End Namespace

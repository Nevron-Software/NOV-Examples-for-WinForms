Imports Nevron.Nov.Dom
Imports Nevron.Nov.Layout
Imports Nevron.Nov.UI
Imports Nevron.Nov.Editors

Namespace Nevron.Nov.Examples.UI
    Public Class NHueColorBarExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' Default constructor.
        ''' </summary>
        Public Sub New()
        End Sub
        ''' <summary>
        ''' Static constructor.
        ''' </summary>
        Shared Sub New()
            NHueColorBarExampleSchema = NSchema.Create(GetType(NHueColorBarExample), NExampleBase.NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            m_HueColorBar = New NHueColorBar()
            m_HueColorBar.HorizontalPlacement = ENHorizontalPlacement.Left
            m_HueColorBar.VerticalPlacement = ENVerticalPlacement.Top
            AddHandler m_HueColorBar.SelectedValueChanged, New [Function](Of NValueChangeEventArgs)(AddressOf OnHueColorBarSelectedValueChanged)
            Return m_HueColorBar
        End Function

        Protected Overrides Function CreateExampleControls() As NWidget
            Dim editors = NDesigner.GetDesigner(m_HueColorBar).CreatePropertyEditors(m_HueColorBar, NColorBar.UpdateWhileDraggingProperty, NColorBar.SelectedValueProperty, NColorBar.OrientationProperty, NColorBar.ValueSelectorExtendPercentProperty)
            Dim stack As NStackPanel = New NStackPanel()
            stack.FillMode = ENStackFillMode.Last
            stack.FitMode = ENStackFitMode.Last
            Dim i = 0, editorsCount = editors.Count

            While i < editorsCount
                stack.Add(editors(i))
                i += 1
            End While

            ' Create an events log
            m_EventsLog = New NExampleEventsLog()
            stack.Add(m_EventsLog)
            Return New NUniSizeBoxGroup(stack)
        End Function

        Protected Overrides Function GetExampleDescription() As String
            Return "
<p>
	This example demonstrates how to create and use a Hue Color Bar. The Hue Color Bar is a color bar that lets the user select
	the hue component of a color. You can control its appearance and behavior using the controls to the right.
</p>
"
        End Function

#End Region

#Region "Event Handlers"

        Private Sub OnHueColorBarSelectedValueChanged(ByVal args As NValueChangeEventArgs)
            m_EventsLog.LogEvent("Selected Hue: " & args.NewValue.ToString())
        End Sub

#End Region

#Region "Fields"

        Private m_HueColorBar As NHueColorBar
        Private m_EventsLog As NExampleEventsLog

#End Region

#Region "Schema"

        ''' <summary>
        ''' Schema associated with NHueColorBarExample.
        ''' </summary>
        Public Shared ReadOnly NHueColorBarExampleSchema As NSchema

#End Region
    End Class
End Namespace

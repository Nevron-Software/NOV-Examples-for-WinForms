Imports Nevron.Nov.Dom
Imports Nevron.Nov.Editors
Imports Nevron.Nov.Layout
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.UI
    Public Class NHexagonColorPickerExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' Default constructor.
        ''' </summary>
        Public Sub New()
        End Sub

        ''' <summary>
        ''' Static constructor.
        ''' </summary>
        Shared Sub New()
            NHexagonColorPickerExampleSchema = NSchema.Create(GetType(NHexagonColorPickerExample), NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            m_HexagonColorPicker = New NHexagonColorPicker()
            m_HexagonColorPicker.HorizontalPlacement = ENHorizontalPlacement.Left
            m_HexagonColorPicker.VerticalPlacement = ENVerticalPlacement.Top
            AddHandler m_HexagonColorPicker.SelectedIndexChanged, AddressOf OnHexagonColorPickerSelectedIndexChanged
            Return m_HexagonColorPicker
        End Function

        Protected Overrides Function CreateExampleControls() As NWidget
            Dim stack As NStackPanel = New NStackPanel()
            stack.FillMode = ENStackFillMode.Last
            stack.FitMode = ENStackFitMode.Last

            ' Add some property editors
            Dim editors = NDesigner.GetDesigner(m_HexagonColorPicker).CreatePropertyEditors(m_HexagonColorPicker, NInputElement.EnabledProperty, NHexagonColorPicker.SelectedIndexProperty, NWidget.HorizontalPlacementProperty, NWidget.VerticalPlacementProperty)

            For i = 0 To editors.Count - 1
                stack.Add(editors(i))
            Next

            ' create the events log
            m_EventsLog = New NExampleEventsLog()
            stack.Add(m_EventsLog)
            Return New NUniSizeBoxGroup(stack)
        End Function

        Protected Overrides Function GetExampleDescription() As String
            Return "
<p>
	This example demonstrates how to create a hexagon color picker. The hexagon color picker is color picker
	that lets the user pick a color from a set of standard colors. The selected color can be get or set
	through the <b>SelectedColor</b> property of the picker.
</p>
<p>
	The desired size of the picker is determined by the desired size of a cell, which is controlled through
	the <b>CellSideLength</b> property. If the picker is larger or smaller than its desired size, its cells
	are scaled automatically to fill the available area.
</p>
"
        End Function

#End Region

#Region "Event Handlers"

        Private Sub OnHexagonColorPickerSelectedIndexChanged(ByVal arg As NValueChangeEventArgs)
            Dim colorPicker = CType(arg.TargetNode, NHexagonColorPicker)
            Dim selectedColor = colorPicker.SelectedColor
            m_EventsLog.LogEvent(selectedColor.GetHEX().ToUpper())
        End Sub

#End Region

#Region "Fields"

        Private m_HexagonColorPicker As NHexagonColorPicker
        Private m_EventsLog As NExampleEventsLog

#End Region

#Region "Schema"

        ''' <summary>
        ''' Schema associated with NHexagonColorPickerExample.
        ''' </summary>
        Public Shared ReadOnly NHexagonColorPickerExampleSchema As NSchema

#End Region
    End Class
End Namespace

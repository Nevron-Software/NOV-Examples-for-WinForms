Imports Nevron.Nov.Editors
Imports Nevron.Nov.Dom
Imports Nevron.Nov.Graphics
Imports Nevron.Nov.Layout
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.UI
    Public Class NSBColorPickerExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' Default constructor.
        ''' </summary>
        Public Sub New()
        End Sub
        ''' <summary>
        ''' Static constructor.
        ''' </summary>
        Shared Sub New()
            NSBColorPickerExampleSchema = NSchema.Create(GetType(NSBColorPickerExample), NExampleBase.NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            ' Create the SB color box
            m_ColorPicker = New NSBColorPicker()
            m_ColorPicker.HorizontalPlacement = ENHorizontalPlacement.Left
            m_ColorPicker.VerticalPlacement = ENVerticalPlacement.Top
            m_ColorPicker.SelectedColorChanged += New [Function](Of NValueChangeEventArgs)(AddressOf OnSelectedColorChanged)

            Return m_ColorPicker
        End Function
        Protected Overrides Function CreateExampleControls() As NWidget
            Dim editors = NDesigner.GetDesigner(m_ColorPicker).CreatePropertyEditors(m_ColorPicker, NSBColorPicker.UpdateWhileDraggingProperty, NSBColorPicker.SelectedColorProperty, NSBColorPicker.SBSelectorRadiusPercentProperty)

            Dim stack As NStackPanel = New NStackPanel()
            stack.FillMode = ENStackFillMode.Last
            stack.FitMode = ENStackFitMode.Last

            For i = 0 To editors.Count - 1
                stack.Add(editors(i))
            Next

            m_EventsLog = New NExampleEventsLog()
            stack.Add(m_EventsLog)

            Return New NUniSizeBoxGroup(stack)
        End Function
        Protected Overrides Function GetExampleDescription() As String
            Return "
<p>
	This example demonstrates how to create a Saturation-Brightness color box. The SB color box lets the user modify
	the saturation and brightness of a color with a specified hue component. The hue component can be controlled through
	the <b>Hue</b> property and the currently selected color is stored in the <b>SelectedColor</b> property.
	The <b>SBSelectorRadiusPercent</b> property determines the size of the circular color selector and the 
	<b>UpdateWhileDragging</b> property specifies whether the selected color should be updated while the user drags
	the color selector or only when the user drops it. You can modify the values of all these properties using the controls
	on the rights.
</p>
" End Function

#End Region

#Region "Event Handlers"

        Private Sub OnSelectedColorChanged(ByVal args As NValueChangeEventArgs)
            Dim selectedColor As NColor = args.NewValue
            m_EventsLog.LogEvent(NColor.GetNameOrHex(selectedColor))
        End Sub

#End Region

#Region "Fields"

        Private m_ColorPicker As NSBColorPicker
        Private m_EventsLog As NExampleEventsLog

#End Region

#Region "Schema"

        ''' <summary>
        ''' Schema associated with NSBColorPickerExample.
        ''' </summary>
        Public Shared ReadOnly NSBColorPickerExampleSchema As NSchema

#End Region
    End Class
End Namespace

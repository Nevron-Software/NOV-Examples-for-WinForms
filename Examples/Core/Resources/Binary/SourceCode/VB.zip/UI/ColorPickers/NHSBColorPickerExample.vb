Imports Nevron.Nov.Editors
Imports Nevron.Nov.Dom
Imports Nevron.Nov.Graphics
Imports Nevron.Nov.Layout
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.UI
    Public Class NHSBColorPickerExample
        Inherits NExampleBase
#Region "Constructors"

        Public Sub New()
        End Sub
        Shared Sub New()
            NHSBColorPickerExampleSchema = NSchema.Create(GetType(NHSBColorPickerExample), NExampleBase.NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            ' Create the HSB color picker
            m_ColorPicker = New NHsbColorPicker()
            m_ColorPicker.HorizontalPlacement = ENHorizontalPlacement.Left
            m_ColorPicker.VerticalPlacement = ENVerticalPlacement.Top
            m_ColorPicker.SelectedColorChanged += New [Function](Of NValueChangeEventArgs)(AddressOf OnSelectedColorChanged)

            Return m_ColorPicker
        End Function
        Protected Overrides Function CreateExampleControls() As NWidget
            Dim editors = NDesigner.GetDesigner(m_ColorPicker).CreatePropertyEditors(m_ColorPicker, NHsbColorPicker.SelectedColorProperty, NHsbColorPicker.HuePositionProperty, NHsbColorPicker.SpacingProperty)

            Dim stack As NStackPanel = New NStackPanel()
            stack.FillMode = ENStackFillMode.Last
            stack.FitMode = ENStackFitMode.Last

            Dim updateWhileDraggingCheckBox As NCheckBox = New NCheckBox("Update While Dragging", True)
            updateWhileDraggingCheckBox.CheckedChanged += AddressOf OnUpdateWhileDraggingCheckBoxCheckedChanged
            stack.Add(updateWhileDraggingCheckBox)

            For i = 0 To editors.Count - 1
                stack.Add(editors(i))
            Next

            m_EventsLog = New NExampleEventsLog()
            stack.Add(m_EventsLog)

            Return New NUniSizeBoxGroup(stack)
        End Function
        Protected Overrides Function GetExampleDescription() As String
            Return "
<p>
	This example demonstrates how to create, configure and use an HSB Box Color Picker. The HSB Box Color Picker consists
	of a hue color bar and a Saturation-Brightness color box. The controls on the right let you change the currently selected
	color, the hue position and the spacing between the SB color box and the hue color bar.
</p>
" End Function

#End Region

#Region "Event Handlers"

        Private Sub OnUpdateWhileDraggingCheckBoxCheckedChanged(ByVal arg1 As NValueChangeEventArgs)
            m_ColorPicker.UpdateWhileDragging = CBool(arg1.NewValue)
        End Sub
        Private Sub OnSelectedColorChanged(ByVal arg1 As NValueChangeEventArgs)
            Dim selectedColor As NColor = arg1.NewValue
            m_EventsLog.LogEvent(NColor.GetNameOrHex(selectedColor))
        End Sub

#End Region

#Region "Fields"

        Private m_ColorPicker As NHsbColorPicker
        Private m_EventsLog As NExampleEventsLog

#End Region

#Region "Schema"

        Public Shared ReadOnly NHSBColorPickerExampleSchema As NSchema

#End Region
    End Class
End Namespace

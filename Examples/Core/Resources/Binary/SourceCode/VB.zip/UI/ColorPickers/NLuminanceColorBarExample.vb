Imports Nevron.Nov.Dom
Imports Nevron.Nov.Layout
Imports Nevron.Nov.UI
Imports Nevron.Nov.Editors

Namespace Nevron.Nov.Examples.UI
    Public Class NLuminanceColorBarExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' Default constructor.
        ''' </summary>
        Public Sub New()
        End Sub
        ''' <summary>
        ''' Static constructor.
        ''' </summary>
        Shared Sub New()
            NLuminanceColorBarExampleSchema = NSchema.Create(GetType(NLuminanceColorBarExample), NExampleBase.NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            m_LuminanceColorBar = New NLuminanceColorBar()
            m_LuminanceColorBar.HorizontalPlacement = ENHorizontalPlacement.Left
            m_LuminanceColorBar.VerticalPlacement = ENVerticalPlacement.Top
            AddHandler m_LuminanceColorBar.SelectedValueChanged, New [Function](Of NValueChangeEventArgs)(AddressOf OnLuminanceColorBarSelectedValueChanged)
            Return m_LuminanceColorBar
        End Function

        Protected Overrides Function CreateExampleControls() As NWidget
            Dim editors = NDesigner.GetDesigner(m_LuminanceColorBar).CreatePropertyEditors(m_LuminanceColorBar, NColorBar.UpdateWhileDraggingProperty, NLuminanceColorBar.BaseColorProperty, NColorBar.SelectedValueProperty, NColorBar.OrientationProperty, NColorBar.ValueSelectorExtendPercentProperty)
            Dim stack As NStackPanel = New NStackPanel()
            stack.FillMode = ENStackFillMode.Last
            stack.FitMode = ENStackFitMode.Last
            Dim i = 0, editorsCount = editors.Count

            While i < editorsCount
                stack.Add(editors(i))
                i += 1
            End While

            ' Modify the properties of the selected value property editor
            Dim selectedValueEditor = CType(editors(2), NSinglePropertyEditor)
            selectedValueEditor.Minimum = 0
            selectedValueEditor.Maximum = 1
            selectedValueEditor.Step = 0.01

            ' Create an events log
            m_EventsLog = New NExampleEventsLog()
            stack.Add(m_EventsLog)
            Return New NUniSizeBoxGroup(stack)
        End Function

        Protected Overrides Function GetExampleDescription() As String
            Return "
<p>
	This example demonstrates how to create a luminance color bar. The luminance color bar allows the user to select darker or lighter variants of a given base color.
	He can modify the luminance of the <b>BaseColor</b> value by dragging a color selector. The currently selected luminance is stored in the
	<b>SelectedValue</b> property and can be in the range [0,1].
</p>
"
        End Function

#End Region

#Region "Event Handlers"

        Private Sub OnLuminanceColorBarSelectedValueChanged(ByVal args As NValueChangeEventArgs)
            m_EventsLog.LogEvent("Selected Luminance: " & args.NewValue.ToString())
        End Sub

#End Region

#Region "Fields"

        Private m_LuminanceColorBar As NLuminanceColorBar
        Private m_EventsLog As NExampleEventsLog

#End Region

#Region "Schema"

        ''' <summary>
        ''' Schema associated with NLuminanceColorBarExample.
        ''' </summary>
        Public Shared ReadOnly NLuminanceColorBarExampleSchema As NSchema

#End Region
    End Class
End Namespace

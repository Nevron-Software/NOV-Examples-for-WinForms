Imports Nevron.Nov.Editors
Imports Nevron.Nov.Dom
Imports Nevron.Nov.Graphics
Imports Nevron.Nov.Layout
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.UI
    Public Class NPaletteColorPickerExample
        Inherits NExampleBase
#Region "Constructors"

        Public Sub New()
        End Sub
        Shared Sub New()
            NPaletteColorPickerExampleSchema = NSchema.Create(GetType(NPaletteColorPickerExample), NExampleBase.NExampleBaseSchema)
        End Sub

#End Region

#Region "Protected Overrides - Examples Content"

        Protected Overrides Function CreateExampleContent() As NWidget
            Dim stack As NStackPanel = New NStackPanel()

            m_PaletteColorPicker = New NPaletteColorPicker()
            m_PaletteColorPicker.HorizontalPlacement = ENHorizontalPlacement.Left
            m_PaletteColorPicker.VerticalPlacement = ENVerticalPlacement.Top
            Me.m_PaletteColorPicker.SelectedIndexChanged += AddressOf OnSelectedIndexChanged
            stack.Add(m_PaletteColorPicker)

            Return stack
        End Function
        Protected Overrides Function CreateExampleControls() As NWidget
            Dim stack As NStackPanel = New NStackPanel()
            stack.FillMode = ENStackFillMode.Last
            stack.FitMode = ENStackFitMode.Last

            ' create the palette select combo box
            Dim paletteComboBox As NComboBox = New NComboBox()
            paletteComboBox.Items.Add(New NComboBoxItem(ENColorPaletteType.MicrosoftPaint))
            paletteComboBox.Items.Add(New NComboBoxItem(ENColorPaletteType.MicrosoftOffice2003))
            paletteComboBox.Items.Add(New NComboBoxItem(ENColorPaletteType.MicrosoftOffice2007))
            paletteComboBox.Items.Add(New NComboBoxItem(ENColorPaletteType.WebSafe))
            paletteComboBox.SelectedIndex = 0
            paletteComboBox.SelectedIndexChanged += AddressOf OnPaletteComboBoxSelectedIndexChanged
            stack.Add(New NPairBox("Palette:", paletteComboBox, True))

            ' add some property editors
            Dim editors = NDesigner.GetDesigner(m_PaletteColorPicker).CreatePropertyEditors(m_PaletteColorPicker, NInputElement.EnabledProperty, NTablePicker.CyclicKeyboardNavigationProperty, NPaletteColorPicker.SelectedIndexProperty)

            For i = 0 To editors.Count - 1
                stack.Add(editors(i))
            Next

            ' create the events log
            m_EventsLog = New NExampleEventsLog()
            stack.Add(m_EventsLog)

            Return New NUniSizeBoxGroup(stack)
        End Function
        Protected Overrides Function GetExampleDescription() As String
            Return "
<p>
	This example demonstrates how to create a palette color picker. The palette color picker is table picker
	that lets the user pick a color from a palette of colors. The palette to use may be passed as a parameter
	to the palette color picker constructor or may be assigned to its <b>Palette</b> property. You can use the
	controls on the right to change the currently used color palette.
</p>
" End Function

#End Region

#Region "Event Handlers"

        Private Sub OnPaletteComboBoxSelectedIndexChanged(ByVal args As NValueChangeEventArgs)
            Dim cbPalette = CType(args.TargetNode, NComboBox)
            Select Case cbPalette.SelectedIndex
                Case 0 ' "MS Paint"
                    m_PaletteColorPicker.Palette = New NColorPalette(ENColorPaletteType.MicrosoftPaint)

                Case 1 ' "Office 2003":
                    m_PaletteColorPicker.Palette = New NColorPalette(ENColorPaletteType.MicrosoftOffice2003)

                Case 2 ' "Office 2007":
                    m_PaletteColorPicker.Palette = New NColorPalette(ENColorPaletteType.MicrosoftOffice2007)

                Case 3 ' "Web Safe":
                    m_PaletteColorPicker.Palette = New NColorPalette(ENColorPaletteType.WebSafe)
            End Select
        End Sub
        Private Sub OnSelectedIndexChanged(ByVal args As NValueChangeEventArgs)
            Dim colorPicker = CType(args.TargetNode, NPaletteColorPicker)
            Dim selectedColor As NColor = colorPicker.SelectedColor
            m_EventsLog.LogEvent(selectedColor.GetHEX().ToUpper())
        End Sub

#End Region

#Region "Fields"

        Private m_PaletteColorPicker As NPaletteColorPicker
        Private m_EventsLog As NExampleEventsLog

#End Region

#Region "Schema"

        Public Shared ReadOnly NPaletteColorPickerExampleSchema As NSchema

#End Region
    End Class
End Namespace

Imports Nevron.Nov.Editors
Imports Nevron.Nov.Dom
Imports Nevron.Nov.Graphics
Imports Nevron.Nov.Layout
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.UI
    Public Class NHSBWheelColorPickerExample
        Inherits NExampleBase
#Region "Constructors"

        Public Sub New()
        End Sub
        Shared Sub New()
            NHSBWheelColorPickerExampleSchema = NSchema.Create(GetType(NHSBWheelColorPickerExample), NExampleBase.NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            ' Create the HSB color picker
            m_ColorPicker = New NHsbWheelColorPicker()
            m_ColorPicker.HorizontalPlacement = ENHorizontalPlacement.Left
            m_ColorPicker.VerticalPlacement = ENVerticalPlacement.Top
            m_ColorPicker.SelectedColorChanged += New [Function](Of NValueChangeEventArgs)(AddressOf OnSelectedColorChanged)

            Return m_ColorPicker
        End Function
        Protected Overrides Function CreateExampleControls() As NWidget
            Dim editors = NDesigner.GetDesigner(m_ColorPicker).CreatePropertyEditors(m_ColorPicker, NHsbWheelColorPicker.UpdateWhileDraggingProperty, NHsbWheelColorPicker.SelectedColorProperty, NHsbWheelColorPicker.HueSelectorSectorAngleProperty, NHsbWheelColorPicker.HueSelectorExtendPercentProperty, NHsbWheelColorPicker.HueWheelWidthPercentProperty, NHsbWheelColorPicker.SBSelectorRadiusPercentProperty, NHsbWheelColorPicker.SBTriangleMarginsPercentProperty)

            Dim stack As NStackPanel = New NStackPanel()
            stack.FillMode = ENStackFillMode.Last
            stack.FitMode = ENStackFitMode.Last

            For i = 0 To editors.Count - 1
                stack.Add(editors(i))
            Next

            m_EventsLog = New NExampleEventsLog()
            stack.Add(m_EventsLog)

            Return New NUniSizeBoxGroup(stack)
        End Function
        Protected Overrides Function GetExampleDescription() As String
            Return "
<p>
	This example demonstrates how to create, configure and use an HSB Wheel Color Picker. The HSB Wheel Color Picker
	is a color picker that consists of a hue color wheel and a Saturation-Brightness triangle. The controls on the right
	let you control the appearance and the behavior of the picker.
</p>
" End Function

#End Region

#Region "Event Handlers"

        Private Sub OnSelectedColorChanged(ByVal args As NValueChangeEventArgs)
            Dim selectedColor As NColor = args.NewValue
            m_EventsLog.LogEvent(NColor.GetNameOrHex(selectedColor))
        End Sub

#End Region

#Region "Fields"

        Private m_ColorPicker As NHsbWheelColorPicker
        Private m_EventsLog As NExampleEventsLog

#End Region

#Region "Schema"

        Public Shared ReadOnly NHSBWheelColorPickerExampleSchema As NSchema

#End Region
    End Class
End Namespace

Imports System
Imports Nevron.Nov.DataStructures
Imports Nevron.Nov.Dom
Imports Nevron.Nov.Graphics
Imports Nevron.Nov.Layout
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.UI
    Public Class NTouchSupportExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' Default constructor.
        ''' </summary>
        Public Sub New()
        End Sub

        ''' <summary>
        ''' Static constructor.
        ''' </summary>
        Shared Sub New()
            NTouchSupportExampleSchema = NSchema.Create(GetType(NTouchSupportExample), NExampleBase.NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            m_Canvas = New NCanvas()
            Me.m_Canvas.PrePaint += AddressOf OnCanvasPrePaint

            ' subscribe for touch events
            Me.m_Canvas.TouchDown += AddressOf OnCanvasTouchDown
            Me.m_Canvas.TouchMove += AddressOf OnCanvasTouchMove
            Me.m_Canvas.TouchUp += AddressOf OnCanvasTouchUp

            ' subscribe for mouse events
            Me.m_Canvas.MouseDown += AddressOf OnCanvasMouseDown
            Me.m_Canvas.MouseUp += AddressOf OnCanvasMouseUp
            Me.m_Canvas.MouseMove += AddressOf OnCanvasMouseMove

            Return m_Canvas
        End Function
        Protected Overrides Function CreateExampleControls() As NWidget
            Dim stack As NStackPanel = New NStackPanel()
            stack.FitMode = ENStackFitMode.Last
            stack.FillMode = ENStackFillMode.Last

            ' capture touch check
            m_CaptureTouchCheck = New NCheckBox("Capture Touch")
            stack.Add(m_CaptureTouchCheck)

            ' handle touch events check
            m_HandleTouchEventsCheck = New NCheckBox("Handle Touch Events")
            stack.Add(m_HandleTouchEventsCheck)

            ' track move events
            m_LogMoveEventsCheck = New NCheckBox("Track Move Events")
            stack.Add(m_LogMoveEventsCheck)

            ' Create clear canvas button
            Dim clearCanvasButton As NButton = New NButton("Clear Canvas")
            clearCanvasButton.Click += AddressOf clearCanvas_Click
            stack.Add(clearCanvasButton)

            ' Create the events log
            m_EventsLog = New NExampleEventsLog()
            stack.Add(m_EventsLog)

            Return stack
        End Function

        Private Sub clearCanvas_Click(ByVal arg As NEventArgs)
            m_TouchPoints.Clear()
            m_Canvas.InvalidateDisplay()
        End Sub
        Protected Overrides Function GetExampleDescription() As String
            Return "
<p>
	Demonstrates the core touch support in NOV. Use your fingers to draw on the canvas and explore the touch events that NOV sends to the application.
    Note that touch input is only available to touch enabled enviroments.
</p>
" End Function

#End Region

#Region "Canvas Event Handlers"

        Private Sub OnCanvasPrePaint(ByVal arg As NCanvasPaintEventArgs)
            For i = 0 To m_TouchPoints.Count - 1
                m_TouchPoints(i).Paint(arg.PaintVisitor)
            Next
        End Sub
        Private Sub OnCanvasTouchUp(ByVal arg As NTouchActionEventArgs)
            AddTouchPoint(arg)
            m_EventsLog.LogEvent("Touch Up")

            If m_HandleTouchEventsCheck.Checked Then
                arg.Cancel = True
            End If
        End Sub
        Private Sub OnCanvasTouchMove(ByVal arg As NTouchActionEventArgs)
            AddTouchPoint(arg)

            If m_LogMoveEventsCheck.Checked Then
                m_EventsLog.LogEvent("Touch Move")
            End If

            If m_HandleTouchEventsCheck.Checked Then
                arg.Cancel = True
            End If
        End Sub

        Private Sub OnCanvasTouchDown(ByVal arg As NTouchActionEventArgs)
            AddTouchPoint(arg)
            m_EventsLog.LogEvent("Touch Down")

            If m_CaptureTouchCheck.Checked Then
                m_Canvas.CaptureTouch(arg.Device)
                m_EventsLog.LogEvent("Captured")
            End If

            If m_HandleTouchEventsCheck.Checked Then
                arg.Cancel = True
            End If
        End Sub

        Private Sub OnCanvasMouseMove(ByVal arg As NMouseEventArgs)
            If m_LogMoveEventsCheck.Checked Then
                m_EventsLog.LogEvent("Mouse Move")
            End If
        End Sub
        Private Sub OnCanvasMouseUp(ByVal arg As NMouseButtonEventArgs)
            m_EventsLog.LogEvent("Mouse Up")
        End Sub
        Private Sub OnCanvasMouseDown(ByVal arg As NMouseButtonEventArgs)
            m_EventsLog.LogEvent("Mouse Down")
        End Sub

        Private Sub AddTouchPoint(ByVal arg As NTouchActionEventArgs)
            m_TouchPoints.Add(New NTouchPoint(arg.TargetPosition, arg.ScreenSize, arg.DeviceState))
            m_Canvas.InvalidateDisplay()
        End Sub

#End Region

#Region "Fields"

        Private m_CaptureTouchCheck As NCheckBox
        Private m_HandleTouchEventsCheck As NCheckBox
        Private m_LogMoveEventsCheck As NCheckBox
        Private m_Canvas As NCanvas
        Private m_EventsLog As NExampleEventsLog
        Private m_TouchPoints As NList(Of NTouchPoint) = New NList(Of NTouchPoint)()

#End Region

#Region "Schema"

        ''' <summary>
        ''' Schema associated with NTouchSupportExample.
        ''' </summary>
        Public Shared ReadOnly NTouchSupportExampleSchema As NSchema

#End Region

#Region "Constants"

        Private Const EnglishLanguageName As String = "English (US)"
        Private Const BulgarianLanguageName As String = "Bulgarian"
        Private Const GermanLanguageName As String = "German"

#End Region

#Region "Nested Types - TouchPoint"

        Public Class NTouchPoint
            Public Sub New(ByVal point As NPoint, ByVal size As NSize, ByVal state As ENTouchDeviceState)
                Me.State = state
                Location = point
                Me.Size = size
            End Sub

            Public Sub Paint(ByVal visitor As NPaintVisitor)
                Dim color As NColor
                Select Case State
                    Case ENTouchDeviceState.Down
                        color = NColor.Blue

                    Case ENTouchDeviceState.Unknown
                        color = NColor.Green

                    Case ENTouchDeviceState.Up
                        color = NColor.Red
                    Case Else
                        Throw New Exception("New ENTouchDeviceState?")
                End Select

                Dim size = Me.Size
                If size.Width = 0 OrElse size.Height = 0 Then
                    size = New NSize(5, 5)
                End If

                visitor.SetStroke(New NStroke(color))
                visitor.PaintEllipse(NRectangle.FromCenterAndSize(Location, size))
            End Sub

            Private Location As NPoint
            Private Size As NSize
            Private State As ENTouchDeviceState
        End Class

#End Region
    End Class
End Namespace

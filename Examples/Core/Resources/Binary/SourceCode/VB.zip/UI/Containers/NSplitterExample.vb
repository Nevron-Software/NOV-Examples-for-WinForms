Imports Nevron.Nov.Dom
Imports Nevron.Nov.Editors
Imports Nevron.Nov.Graphics
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.UI
    Public Class NSplitterExample
        Inherits NExampleBase
#Region "Constructors"

        Public Sub New()
        End Sub
        Shared Sub New()
            NSplitterExampleSchema = NSchema.Create(GetType(NSplitterExample), NExampleBase.NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            ' Create a splitter
            m_Splitter = New NSplitter()

            m_Splitter.Pane1.Content = New NLabel("Pane 1")
            m_Splitter.Pane1.Padding = New NMargins(NDesign.HorizontalSpacing, NDesign.VerticalSpacing)
            m_Splitter.Pane1.BackgroundFill = New NColorFill(NColor.LightGreen)
            m_Splitter.Pane1.Border = NBorder.CreateFilledBorder(NColor.Black)
            m_Splitter.Pane1.BorderThickness = New NMargins(1)

            m_Splitter.Pane2.Content = New NLabel("Pane 2")
            m_Splitter.Pane2.Padding = New NMargins(NDesign.HorizontalSpacing, NDesign.VerticalSpacing)
            m_Splitter.Pane2.BackgroundFill = New NColorFill(NColor.LightBlue)
            m_Splitter.Pane2.Border = NBorder.CreateFilledBorder(NColor.Black)
            m_Splitter.Pane2.BorderThickness = New NMargins(1)

            m_Splitter.ResizeStep = 20

            ' Host it
            Return m_Splitter
        End Function
        Protected Overrides Function CreateExampleControls() As NWidget
            Dim stack As NStackPanel = New NStackPanel()

            ' Create some splitter property editors
            Dim editors = NDesigner.GetDesigner(m_Splitter).CreatePropertyEditors(m_Splitter, NSplitterBase.OrientationProperty, NSplitterBase.ResizeWhileDraggingProperty, NSplitterBase.ResizeStepProperty)

            Dim propertyStack As NStackPanel = New NStackPanel()
            For i = 0 To editors.Count - 1
                propertyStack.Add(editors(i))
            Next

            stack.Add(New NGroupBox("Splitter Properties", propertyStack))

            ' Create splitter thumb property editors
            editors = NDesigner.GetDesigner(m_Splitter.Thumb).CreatePropertyEditors(m_Splitter.Thumb, NSplitterThumb.SplitModeProperty, NSplitterThumb.SplitOffsetProperty, NSplitterThumb.SplitFactorProperty, NSplitterThumb.CollapseModeProperty)

            propertyStack = New NStackPanel()
            For i = 0 To editors.Count - 1
                propertyStack.Add(editors(i))
            Next

            stack.Add(New NGroupBox("Splitter Thumb Properties", propertyStack))

            Return New NUniSizeBoxGroup(stack)
        End Function
        Protected Overrides Function GetExampleDescription() As String
            Return "
<p>
	This example demonstrates how to create and configure a splitter. The splitter is a widget that splits
	its content area into two resizable panes, which can be interactively resized with help of a thumb located
	in the middle. Using the <b>Orientation</b> property you can specify whether the splitter is horizontal or
	vertical. To control how the splitter splits its content area you can use the <b>SplitMode</b> property.
</p>
" End Function

#End Region

#Region "Fields"

        Private m_Splitter As NSplitter

#End Region

#Region "Schema"

        Public Shared ReadOnly NSplitterExampleSchema As NSchema

#End Region
    End Class
End Namespace

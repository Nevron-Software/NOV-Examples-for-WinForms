Imports Nevron.Nov.Dom
Imports Nevron.Nov.Editors
Imports Nevron.Nov.Graphics
Imports Nevron.Nov.Layout
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.UI
    Public Class NScrollContentExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' Default constructor.
        ''' </summary>
        Public Sub New()
            m_ScrollContent = Nothing
        End Sub
        ''' <summary>
        ''' Static constructor.
        ''' </summary>
        Shared Sub New()
            NScrollContentExampleSchema = NSchema.Create(GetType(NScrollContentExample), NExampleBase.NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            m_ScrollContent = New NScrollContent()
            m_ScrollContent.HorizontalPlacement = ENHorizontalPlacement.Left
            m_ScrollContent.VerticalPlacement = ENVerticalPlacement.Top
            m_ScrollContent.SetBorder(1, NColor.Red)
            m_ScrollContent.PreferredSize = New NSize(300, 250)

            ' Create a table with some buttons
            Dim table As NTableFlowPanel = New NTableFlowPanel()
            table.MaxOrdinal = 10
            For i = 1 To 150
                table.Add(New NButton("Button " & i.ToString()))
            Next

            m_ScrollContent.Content = table
            Return m_ScrollContent
        End Function
        Protected Overrides Function CreateExampleControls() As NWidget
            Dim editors = NDesigner.GetDesigner(m_ScrollContent).CreatePropertyEditors(m_ScrollContent, NInputElement.EnabledProperty, NWidget.HorizontalPlacementProperty, NWidget.VerticalPlacementProperty)

            Dim stack As NStackPanel = New NStackPanel()

            Dim i = 0, count = editors.Count

            While i < count
                stack.Add(editors(i))
                i += 1
            End While

            Return New NUniSizeBoxGroup(stack)
        End Function
        Protected Overrides Function GetExampleDescription() As String
            Return "
<p>
	This example demonstrates how to use the scroll content widget. The scroll content is a widget,
	which contains a single other widget, and allows for its scrolling. It measures to fit the
	contained element without scrollbars, but if this is not possible, the scroll content element
	will display scrollbars. The contained element is always sized to its desired size.
</p>
" End Function

#End Region

#Region "Fields"

        Private m_ScrollContent As NScrollContent

#End Region

#Region "Schema"

        ''' <summary>
        ''' Schema associated with NScrollContentExample.
        ''' </summary>
        Public Shared ReadOnly NScrollContentExampleSchema As NSchema

#End Region
    End Class
End Namespace

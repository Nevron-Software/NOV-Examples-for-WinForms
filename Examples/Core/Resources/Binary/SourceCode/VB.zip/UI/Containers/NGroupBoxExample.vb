Imports Nevron.Nov.Dom
Imports Nevron.Nov.Layout
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.UI
    Public Class NGroupBoxExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' Default constructor.
        ''' </summary>
        Public Sub New()
        End Sub
        ''' <summary>
        ''' Static constructor.
        ''' </summary>
        Shared Sub New()
            NGroupBoxExampleSchema = NSchema.Create(GetType(NGroupBoxExample), NExampleBase.NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            m_ContentPanel = New NStackPanel()
            m_ContentPanel.VerticalSpacing = 3

            ' Create the first group box
            Dim groupBox1 As NGroupBox = New NGroupBox("Group Box 1")
            m_ContentPanel.Add(groupBox1)

            Dim button As NButton = New NButton("Button inside group box")
            groupBox1.Content = button

            ' Create the second group box
            Dim groupBox2 As NGroupBox = New NGroupBox("Group Box 2 - Centered Header")
            groupBox2.Header.HorizontalPlacement = ENHorizontalPlacement.Center
            m_ContentPanel.Add(groupBox2)

            Dim stack1 As NStackPanel = New NStackPanel()
            groupBox2.Content = stack1

            stack1.Add(New NLabel("Label 1 in stack"))
            stack1.Add(New NLabel("Label 2 in stack"))
            stack1.Add(New NLabel("Label 3 in stack"))

            ' Create the third group box
            Dim groupBox3 As NGroupBox = New NGroupBox("Group Box 3 - Expandable")
            groupBox3.Expandable = True
            groupBox3.Content = New NImageBox(NResources.Image_Artistic_FishBowl_jpg)
            m_ContentPanel.Add(groupBox3)

            Return m_ContentPanel
        End Function
        Protected Overrides Function CreateExampleControls() As NWidget
            Dim checkBox As NCheckBox = New NCheckBox("Enabled", True)
            checkBox.VerticalPlacement = ENVerticalPlacement.Top
            checkBox.CheckedChanged += New [Function](Of NValueChangeEventArgs)(AddressOf OnEnabledCheckBoxCheckedChanged)

            Return checkBox
        End Function
        Protected Overrides Function GetExampleDescription() As String
            Return "
<p>
	This example demonstrates how to create a group box. The group box is a widget that consists of 2 widgets –
	<b>Header</b> and <b>Content</b>.
</p>
" End Function

#End Region

#Region "Event Handlers"

        Private Sub OnEnabledCheckBoxCheckedChanged(ByVal args As NValueChangeEventArgs)
            m_ContentPanel.Enabled = CBool(args.NewValue)
        End Sub

#End Region

#Region "Fields"

        Private m_ContentPanel As NStackPanel

#End Region

#Region "Schema"

        ''' <summary>
        ''' Schema associated with NGroupBoxExample.
        ''' </summary>
        Public Shared ReadOnly NGroupBoxExampleSchema As NSchema

#End Region
    End Class
End Namespace

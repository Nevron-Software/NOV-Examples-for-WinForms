Imports Nevron.Nov.DataStructures
Imports Nevron.Nov.Dom
Imports Nevron.Nov.Editors
Imports Nevron.Nov.Graphics
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.UI
    Public Class NMultiSplitterExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' Default constructor.
        ''' </summary>
        Public Sub New()
        End Sub

        ''' <summary>
        ''' Static constructor.
        ''' </summary>
        Shared Sub New()
            NMultiSplitterExampleSchema = NSchema.Create(GetType(NMultiSplitterExample), NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            ' Create a multi splitter
            m_MultiSplitter = New NMultiSplitter()

            Dim pane1 As NSplitterPane = New NSplitterPane()
            pane1.Padding = New NMargins(NDesign.HorizontalSpacing, NDesign.VerticalSpacing)
            pane1.BackgroundFill = New NColorFill(NColor.LightGreen)
            pane1.Border = NBorder.CreateFilledBorder(NColor.Black)
            pane1.BorderThickness = New NMargins(1)
            pane1.Content = New NLabel("Pane 1")
            m_MultiSplitter.Widgets.Add(pane1)

            Dim thumb1 As NSplitterThumb = New NSplitterThumb()
            thumb1.CollapseMode = ENSplitterCollapseMode.BothPanes
            m_MultiSplitter.Widgets.Add(thumb1)

            Dim pane2 As NSplitterPane = New NSplitterPane()
            pane2.Padding = New NMargins(NDesign.HorizontalSpacing, NDesign.VerticalSpacing)
            pane2.BackgroundFill = New NColorFill(NColor.LightBlue)
            pane2.Border = NBorder.CreateFilledBorder(NColor.Black)
            pane2.BorderThickness = New NMargins(1)
            pane2.Content = New NLabel("Pane 2")
            m_MultiSplitter.Widgets.Add(pane2)

            Dim thumb2 As NSplitterThumb = New NSplitterThumb()
            thumb2.CollapseMode = ENSplitterCollapseMode.BothPanes
            m_MultiSplitter.Widgets.Add(thumb2)

            Dim pane3 As NSplitterPane = New NSplitterPane()
            pane3.Padding = New NMargins(NDesign.HorizontalSpacing, NDesign.VerticalSpacing)
            pane3.BackgroundFill = New NColorFill(NColor.LightYellow)
            pane3.Border = NBorder.CreateFilledBorder(NColor.Black)
            pane3.BorderThickness = New NMargins(1)
            pane3.Content = New NLabel("Pane 3")
            m_MultiSplitter.Widgets.Add(pane3)

            Return m_MultiSplitter
        End Function
        Protected Overrides Function CreateExampleControls() As NWidget
            Dim stack As NStackPanel = New NStackPanel()

            ' Create multi splitter property editors
            Dim editors = NDesigner.GetDesigner(m_MultiSplitter).CreatePropertyEditors(m_MultiSplitter, NSplitterBase.OrientationProperty, NSplitterBase.ResizeWhileDraggingProperty, NSplitterBase.ResizeStepProperty)

            Dim propertyStack As NStackPanel = New NStackPanel()
            For i = 0 To editors.Count - 1
                propertyStack.Add(editors(i))
            Next

            stack.Add(New NGroupBox("Splitter Properties", propertyStack))

            ' Create splitter thumb property editors
            Dim thumbs As NList(Of NSplitterThumb) = m_MultiSplitter.Widgets.GetChildren(Of NSplitterThumb)()
            For i = 0 To thumbs.Count - 1
                editors = NDesigner.GetDesigner(thumbs(i)).CreatePropertyEditors(thumbs(i), NSplitterThumb.SplitModeProperty, NSplitterThumb.SplitOffsetProperty, NSplitterThumb.SplitFactorProperty, NSplitterThumb.CollapseModeProperty)

                propertyStack = New NStackPanel()
                For j = 0 To editors.Count - 1
                    propertyStack.Add(editors(j))
                Next

                stack.Add(New NGroupBox("Splitter Thumb " & (i + 1).ToString() & " Properties", propertyStack))
            Next

            Return New NUniSizeBoxGroup(stack)
        End Function
        Protected Overrides Function GetExampleDescription() As String
            Return "
<p>
	This example demonstrates how to create and configure a multi splitter. The multi splitter is a widget that
	splits its content area into multiple resizable panes, which can be interactively resized with help of thumbs.
	Using the <b>Orientation</b> property you can specify whether the splitter is horizontal or vertical.
	To control how the splitter splits its content area you can use the <b>SplitMode</b> property.
</p>
" End Function

#End Region

#Region "Fields"

        Private m_MultiSplitter As NMultiSplitter

#End Region

#Region "Schema"

        ''' <summary>
        ''' Schema associated with NMultiSplitterExample.
        ''' </summary>
        Public Shared ReadOnly NMultiSplitterExampleSchema As NSchema

#End Region
    End Class
End Namespace

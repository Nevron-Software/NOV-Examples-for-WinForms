Imports Nevron.Nov.Dom
Imports Nevron.Nov.Editors
Imports Nevron.Nov.Layout
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.UI
    Public Class NTabExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' Default constructor.
        ''' </summary>
        Public Sub New()
        End Sub

        ''' <summary>
        ''' Static constructor.
        ''' </summary>
        Shared Sub New()
            NTabExampleSchema = NSchema.Create(GetType(NTabExample), NExampleBase.NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            ' create a tab
            m_Tab = New NTab()

            m_Tab.TabPages.Add(CreatePage("Page 1", "This is the first tab page."))
            m_Tab.TabPages.Add(CreatePage("Page 2", "This is the second tab page."))
            m_Tab.TabPages.Add(CreatePage("Page 3", "This is the third tab page." & vbLf & "It is the largest both horizontally and vertically."))
            m_Tab.TabPages.Add(CreatePage("Page 4", "This is the fourth tab page."))
            m_Tab.TabPages.Add(CreatePage("Page 5", "This is the fifth tab page."))

            m_Tab.SelectedIndex = 0
            m_Tab.SelectedIndexChanged += New [Function](Of NValueChangeEventArgs)(AddressOf OnTabSelectedIndexChanged)

            ' host it
            Return m_Tab
        End Function
        Protected Overrides Function CreateExampleControls() As NWidget
            Dim editors = NDesigner.GetDesigner(m_Tab).CreatePropertyEditors(m_Tab, NInputElement.EnabledProperty, NTab.SizeToSelectedPageProperty, NTab.CycleTabPagesProperty, NTab.HeadersPositionProperty, NTab.HeadersModeProperty, NTab.HeadersAlignmentProperty, NTab.HeadersSpacingProperty, NWidget.HorizontalPlacementProperty, NWidget.VerticalPlacementProperty)

            Dim stack As NStackPanel = New NStackPanel()
            stack.FillMode = ENStackFillMode.Last
            stack.FitMode = ENStackFitMode.Last

            For i = 0 To editors.Count - 1
                stack.Add(editors(i))
            Next

            ' create the events list box
            m_EventsLog = New NExampleEventsLog()
            stack.Add(m_EventsLog)

            Return New NUniSizeBoxGroup(stack)
        End Function
        Protected Overrides Function GetExampleDescription() As String
            Return "
<p>
	This example demonstrates how to create tab widgets. The tab is a widget that contains tab pages. Their order in the
	<b>TabPages</b> collection of the tab widget reflects the order they appear in the widget. The <b>SelectedIndex</b>
	property stores the index of the currently selected tab page. The <b>HeadersPosition</b> property determines the
	way the tab page headers are position in respect to the tab widget. The possible values are: <b>Left</b>, <b>Top</b>
	(default), <b>Right</b> and <b>Bottom</b>. You can also specify the spacing between the headers. To do so, use the
	<b>HeadersSpacing</b> property. The <b>HeadersAlignment</b> property determines how the tab page headers are aligned
	on the tab widget side they are placed on. The supported values are <b>Near</b> (default), <b>Center</b> and <b>Far</b>. 
	The <b>CycleTablePages</b> instructs the control to cycle pages when the tab has focus and the user presseses the left 
	or right arrow keys.
</p>
" End Function
#End Region

#Region "Implementation"

        Private Function CreatePage(ByVal name As String, ByVal content As String) As NTabPage
            Dim tabPage As NTabPage = New NTabPage(name, content)

            tabPage.Header.Content = NPairBox.Create("Text With Image:", New NImageBox(NResources.Image__16x16_folderDeleted_png))


            Return tabPage
        End Function

#End Region

#Region "Event Handlers"

        Private Sub OnHeadersPositionComboSelectedIndexChanged(ByVal args As NValueChangeEventArgs)
            Dim combo = CType(args.TargetNode, NComboBox)
            Dim headersPosition As ENTabHeadersPosition = args.NewValue
            m_Tab.HeadersPosition = headersPosition
        End Sub
        Private Sub OnHeadersSpacingComboSelectedIndexChanged(ByVal args As NValueChangeEventArgs)
            Dim combo = CType(args.TargetNode, NComboBox)
            m_Tab.HeadersSpacing = combo.SelectedIndex
        End Sub
        Private Sub OnTabSelectedIndexChanged(ByVal args As NValueChangeEventArgs)
            m_EventsLog.LogEvent("Selected Index: " & args.NewValue)
        End Sub

#End Region

#Region "Fields"

        Private m_Tab As NTab
        Private m_EventsLog As NExampleEventsLog

#End Region

#Region "Schema"

        ''' <summary>
        ''' Schema associated with NTabExample.
        ''' </summary>
        Public Shared ReadOnly NTabExampleSchema As NSchema

#End Region
    End Class
End Namespace

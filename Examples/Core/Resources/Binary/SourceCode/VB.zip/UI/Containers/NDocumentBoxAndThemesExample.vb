Imports Nevron.Nov.Dom
Imports Nevron.Nov.Graphics
Imports Nevron.Nov.Layout
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.UI
#Region "Nested Types"

    ''' <summary>
    ''' A custom NOV theme based on the Windows 10 theme.
    ''' </summary>
    Public Class NCustomTheme
        Inherits NWindows10Theme
        ''' <summary>
        ''' Static constructor.
        ''' </summary>
        Shared Sub New()
            NCustomThemeSchema = NSchema.Create(GetType(NCustomTheme), NWindows10ThemeSchema)
        End Sub

        ''' <summary>
        ''' Creates button styles.
        ''' </summary>
        Protected Overrides Sub CreateButtonStyles(ByVal buttonSchema As NSchema)
            ' Change mouse over background fill to orange
            Dim mouseOverState = CType(Skins.Button.GetState(NSkinState.MouseOver), NColorSkinState)
            mouseOverState.BackgroundFill = New NColorFill(NColor.Orange)

            ' Change pressed button border to 3px purple border, background fill to dark red and text fill to white
            Dim pressedState = CType(Skins.Button.GetState(NSkinState.Pressed), NColorSkinState)
            pressedState.SetBorderFill(New NColorFill(NColor.Green))
            pressedState.BorderThickness = New NMargins(3)
            pressedState.BackgroundFill = New NColorFill(NColor.DarkRed)
            pressedState.TextFill = New NColorFill(NColor.White)

            ' Call base to skin the buttons
            MyBase.CreateButtonStyles(buttonSchema)
        End Sub
        ''' <summary>
        ''' Creates flat button styles, which are buttons commonly in ribbon and toolbars.
        ''' </summary>
        Protected Overrides Sub CreateFlatButtonStyles()
            Dim mouseOverState = CType(Skins.FlatButton.GetState(NSkinState.MouseOver), NColorSkinState)
            mouseOverState.BackgroundFill = New NColorFill(NColor.Orange)

            ' Call base to skin flat buttons
            MyBase.CreateFlatButtonStyles()
        End Sub
        ''' <summary>
        ''' Creates the tab styles. Overriden to make the mouse over state orange.
        ''' </summary>
        Protected Overrides Sub CreateTabStyles()
            ' Modify the tab skins
            Dim backgroundColor = NColor.Orange
            Dim tabSkins = New NSkin() {MyBase.TabSkins.Top.FarTabPageHeaderSkin, MyBase.TabSkins.Top.InnerTabPageHeaderSkin, MyBase.TabSkins.Top.NearAndFarTabPageHeaderSkin, MyBase.TabSkins.Top.NearTabPageHeaderSkin}

            For i = 0 To tabSkins.Length - 1
                Dim state = CType(tabSkins(i).GetState(NSkinState.MouseOver), NColorSkinState)
                state.BackgroundFill = New NColorFill(backgroundColor)
            Next

            ' Call base to skin the tab widget
            MyBase.CreateTabStyles()
        End Sub

        ''' <summary>
        ''' Schema associated with NCustomTheme.
        ''' </summary>
        Public Shared ReadOnly NCustomThemeSchema As NSchema
    End Class

#End Region

    Public Class NDocumentBoxAndThemesExample
        Inherits NExampleBase
#Region "Constructors"

        Public Sub New()
        End Sub

        Shared Sub New()
            NDocumentBoxAndThemesExampleSchema = NSchema.Create(GetType(NDocumentBoxAndThemesExample), NExampleBase.NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            Dim table As NTableFlowPanel = New NTableFlowPanel()
            table.HorizontalSpacing = 10
            table.VerticalSpacing = 10
            table.MaxOrdinal = 3
            table.Add(CreateGroupBox("Buttons", CreateButtons()))
            table.Add(CreateGroupBox("List Box", CreateListBox()))
            table.Add(CreateGroupBox("Tree View", CreateTreeView()))
            table.Add(CreateGroupBox("Drop Down Edits", CreateDropDownEdits()))
            table.Add(CreateGroupBox("Tab", CreateTab()))
            table.Add(CreateGroupBox("Range Based", CreateRangeBased()))
            table.Add(CreateGroupBox("Ribbon", CreateRibbon()))
            table.Add(CreateGroupBox("Command Bars", CreateCommandBars()))
            table.Add(CreateGroupBox("Windows", CreateWindows()))

            ' Create the document box
            m_DocumentBox = New NDocumentBox()
            m_DocumentBox.HorizontalPlacement = ENHorizontalPlacement.Left
            m_DocumentBox.Border = NBorder.CreateFilledBorder(NColor.Red)
            m_DocumentBox.BorderThickness = New NMargins(1)
            m_DocumentBox.Surface = New NDocumentBoxSurface(table)
            Return m_DocumentBox
        End Function

        Protected Overrides Function CreateExampleControls() As NWidget
            Dim stack As NStackPanel = New NStackPanel()
            Dim enabledCheckBox As NCheckBox = New NCheckBox("Enabled", True)
            AddHandler enabledCheckBox.CheckedChanged, AddressOf OnEnabledCheckBoxCheckedChanged
            stack.Add(enabledCheckBox)


            ' Create the theme tree view
            Dim theme As NTheme
            Dim rootItem, themeItem As NTreeViewItem
            Dim themeTreeView As NTreeView = New NTreeView()
            stack.Add(themeTreeView)

            '
            ' Add the "Inherit Styles" root tree view item
            '
            rootItem = New NTreeViewItem("Inherit Styles")
            rootItem.Tag = "inherit"
            themeTreeView.Items.Add(rootItem)
            themeTreeView.SelectedItem = rootItem

            '
            ' Add the part based UI themes to the tree view
            '
            rootItem = New NTreeViewItem("Part Based")
            rootItem.Expanded = True
            themeTreeView.Items.Add(rootItem)
            themeItem = New NTreeViewItem("Windows XP Blue")
            themeItem.Tag = New NWindowsXPBlueTheme()
            rootItem.Items.Add(themeItem)
            themeItem = New NTreeViewItem("Windows 7 Aero")
            themeItem.Tag = New NWindowsAeroTheme()
            rootItem.Items.Add(themeItem)
            themeItem = New NTreeViewItem("Windows 8")
            themeItem.Tag = New NWindows8Theme()
            rootItem.Items.Add(themeItem)
            themeItem = New NTreeViewItem("Windows 10")
            themeItem.Tag = New NWindows10Theme()
            rootItem.Items.Add(themeItem)
            themeItem = New NTreeViewItem("Mac OS X 10.7 Lion")
            themeItem.Tag = New NMacLionTheme()
            rootItem.Items.Add(themeItem)
            themeItem = New NTreeViewItem("Mac OS X 10.11 El Capitan")
            themeItem.Tag = New NMacElCapitanTheme()
            rootItem.Items.Add(themeItem)
            themeItem = New NTreeViewItem("Nevron Dark")
            themeItem.Tag = New NNevronDarkTheme()
            rootItem.Items.Add(themeItem)
            themeItem = New NTreeViewItem("Nevron Light")
            themeItem.Tag = New NNevronLightTheme()
            rootItem.Items.Add(themeItem)

            '
            ' Add the windows classic UI themes to the tree view
            '
            rootItem = New NTreeViewItem("Windows Classic")
            rootItem.Expanded = True
            themeTreeView.Items.Add(rootItem)
            Dim windowsClassicSchemes As ENUIThemeScheme() = NEnum.GetValues(Of ENUIThemeScheme)()
            Dim i = 0, count = windowsClassicSchemes.Length

            While i < count
                Dim scheme = windowsClassicSchemes(i)
                theme = New NWindowsClassicTheme(scheme)
                themeItem = New NTreeViewItem(NStringHelpers.InsertSpacesBeforeUppersAndDigits(scheme.ToString()))
                themeItem.Tag = theme
                rootItem.Items.Add(themeItem)
                i += 1
            End While

            '
            ' Add the custom themes to the tree view
            '
            rootItem = New NTreeViewItem("Custom")
            rootItem.Expanded = True
            themeTreeView.Items.Add(rootItem)
            themeItem = New NTreeViewItem("Custom Theme")
            themeItem.Tag = New NCustomTheme()
            rootItem.Items.Add(themeItem)

            ' Subscribe to the selected path changed event
            AddHandler themeTreeView.SelectedPathChanged, New [Function](Of NValueChangeEventArgs)(AddressOf OnThemeTreeViewSelectedPathChanged)
            Return stack
        End Function

        Protected Overrides Function GetExampleDescription() As String
            Return "
<p>
	This example demonstrates how to use document boxes. The document box is a widget that has a document.
	If you set the <b>InheritStyleSheetsProperty</b> of the document box's document to false, then the widgets hosted
	in it will not inherit the styling of the document the document box is placed in.
</p>
<p>
	This example also demonstrates the UI themes incuded in Nevron Open Vision. Select a theme from the tree view on
	the right to apply it to the document box and see how the widgets look when that theme is applied.
</p>
<p>
	The last item in the tree view is a custom theme that changes the mouse over state of buttons, flat buttons (i.e.
	buttons in ribbon and toolbars) and tab page headers. The custom theme is defined in the beginning of the example's
	source code.
</p>
"
        End Function

#End Region

#Region "Implementation"

        Private Function CreateButtons() As NStackPanel
            ' Create buttons
            Dim stack As NStackPanel = New NStackPanel()
            stack.VerticalSpacing = 10
            Dim checkBox As NCheckBox = New NCheckBox("Check Box")
            stack.Add(checkBox)
            Dim radioButton As NRadioButton = New NRadioButton("Radio Button")
            stack.Add(radioButton)
            Dim button As NButton = New NButton("Button")
            stack.Add(button)
            Return stack
        End Function

        Private Function CreateListBox() As NListBox
            Dim listBox As NListBox = New NListBox()

            For i = 1 To 20
                listBox.Items.Add(New NListBoxItem("Item " & i))
            Next

            Return listBox
        End Function

        Private Function CreateTreeView() As NTreeView
            Dim treeView As NTreeView = New NTreeView()

            For i = 1 To 7
                Dim itemName = "Item " & i
                Dim item As NTreeViewItem = New NTreeViewItem(itemName)
                treeView.Items.Add(item)
                itemName += "."

                For j = 1 To 3
                    Dim childItem As NTreeViewItem = New NTreeViewItem(itemName & j)
                    item.Items.Add(childItem)
                Next
            Next

            Return treeView
        End Function

        Private Function CreateDropDownEdits() As NStackPanel
            Dim stack As NStackPanel = New NStackPanel()
            stack.VerticalSpacing = 10
            stack.Add(CreateComboBox())
            Dim colorBox As NColorBox = New NColorBox()
            stack.Add(colorBox)
            Dim dateTimeBox As NDateTimeBox = New NDateTimeBox()
            stack.Add(dateTimeBox)
            Dim splitButton As NFillSplitButton = New NFillSplitButton()
            stack.Add(splitButton)
            Return stack
        End Function

        Private Function CreateComboBox() As NComboBox
            Dim comboBox As NComboBox = New NComboBox()
            comboBox.Items.Add(New NComboBoxItem("Item 1"))
            comboBox.Items.Add(New NComboBoxItem("Item 2"))
            comboBox.Items.Add(New NComboBoxItem("Item 3"))
            comboBox.Items.Add(New NComboBoxItem("Item 4"))
            comboBox.SelectedIndex = 0
            Return comboBox
        End Function

        Private Function CreateTab() As NTab
            Dim tab As NTab = New NTab()
            tab.TabPages.Add(New NTabPage("Page 1", "This is tab page 1"))
            tab.TabPages.Add(New NTabPage("Page 2", "This is tab page 2"))
            tab.TabPages.Add(New NTabPage("Page 3", "This is tab page 3"))
            Return tab
        End Function

        Private Function CreateRangeBased() As NStackPanel
            Dim stack As NStackPanel = New NStackPanel()
            stack.VerticalSpacing = 10
            Dim numericUpDown As NNumericUpDown = New NNumericUpDown()
            stack.Add(numericUpDown)
            Dim slider As NSlider = New NSlider()
            stack.Add(slider)
            Dim progressBar As NProgressBar = New NProgressBar()
            progressBar.PreferredHeight = 20
            progressBar.Value = 40
            stack.Add(progressBar)
            Return stack
        End Function

        Private Function CreateRibbon() As NRibbon
            Dim ribbon As NRibbon = New NRibbon()
            ribbon.VerticalPlacement = ENVerticalPlacement.Top

            '
            ' Create the "Home" ribbon tab page
            '
            Dim pageHome As NRibbonTabPage = New NRibbonTabPage("Home")
            ribbon.Tab.TabPages.Add(pageHome)

            ' Create the "Clipboard" group of the "Home" tab page
            Dim group As NRibbonGroup = New NRibbonGroup("Clipboard")
            group.Icon = NResources.Image_Ribbon_16x16_clipboard_copy_png
            pageHome.Groups.Add(group)
            Dim pasteSplitButton = NRibbonSplitButton.CreateLarge("Paste", NResources.Image_Ribbon_32x32_clipboard_paste_png)
            pasteSplitButton.CollapseToMedium = ENCollapseCondition.Never
            pasteSplitButton.CollapseToSmall = ENCollapseCondition.Never
            Dim pasteMenu As NMenu = New NMenu()
            pasteMenu.Items.Add(New NMenuItem("Paste"))
            pasteMenu.Items.Add(New NMenuItem("Paste Special..."))
            pasteMenu.Items.Add(New NMenuItem("Paste as Link"))
            pasteSplitButton.Popup.Content = pasteMenu
            group.Items.Add(pasteSplitButton)
            Dim collapsiblePanel As NRibbonCollapsiblePanel = New NRibbonCollapsiblePanel()
            collapsiblePanel.InitialState = ENRibbonWidgetState.Medium
            group.Items.Add(collapsiblePanel)
            collapsiblePanel.Add(New NRibbonButton("Cut", Nothing, NResources.Image_Ribbon_16x16_clipboard_cut_png))
            collapsiblePanel.Add(New NRibbonButton("Copy", Nothing, NResources.Image_Ribbon_16x16_clipboard_copy_png))
            collapsiblePanel.Add(New NRibbonButton("Format Painter", Nothing, NResources.Image_Ribbon_16x16_copy_format_png))

            ' Create the "Format" group of the "Home" tab page
            group = New NRibbonGroup("Format")
            pageHome.Groups.Add(group)
            collapsiblePanel = New NRibbonCollapsiblePanel()
            collapsiblePanel.InitialState = ENRibbonWidgetState.Medium
            group.Items.Add(collapsiblePanel)
            Dim fillSplitButton As NFillSplitButton = New NFillSplitButton()
            collapsiblePanel.Add(fillSplitButton)
            Dim strokeSplitButton As NStrokeSplitButton = New NStrokeSplitButton()
            collapsiblePanel.Add(strokeSplitButton)

            '
            ' Add an "Insert" ribbon tab page
            '
            ribbon.Tab.TabPages.Add(New NRibbonTabPage("Insert"))
            Return ribbon
        End Function

        Private Function CreateCommandBars() As NCommandBarManager
            Dim manager As NCommandBarManager = New NCommandBarManager()

            ' Create a menu bar in the first lane
            Dim lane1 As NCommandBarLane = New NCommandBarLane()
            manager.TopDock.Add(lane1)
            Dim menuBar As NMenuBar = New NMenuBar()
            menuBar.Pendant.Visibility = ENVisibility.Collapsed
            lane1.Add(menuBar)
            Dim fileMenu As NMenuDropDown = New NMenuDropDown("File")
            menuBar.Items.Add(fileMenu)
            Dim newMenuItem As NMenuItem = New NMenuItem(Presentation.NResources.Image_File_New_png, "New")
            fileMenu.Items.Add(newMenuItem)
            newMenuItem.Items.Add(New NMenuItem("Project"))
            newMenuItem.Items.Add(New NMenuItem("Web Site"))
            newMenuItem.Items.Add(New NMenuItem("File"))
            fileMenu.Items.Add(New NMenuItem(Presentation.NResources.Image_File_Open_png, "Open"))
            fileMenu.Items.Add(New NMenuItem(Presentation.NResources.Image_File_Save_png, "Save"))
            fileMenu.Items.Add(New NMenuSeparator())
            fileMenu.Items.Add(New NMenuItem(Presentation.NResources.Image_File_Print_png, "Print"))
            Dim editMenu As NMenuDropDown = New NMenuDropDown("Edit")
            menuBar.Items.Add(editMenu)
            editMenu.Items.Add(New NMenuItem(Presentation.NResources.Image_Edit_Undo_png, "Undo"))
            editMenu.Items.Add(New NMenuItem(Presentation.NResources.Image_Edit_Redo_png, "Redo"))

            ' Add a toolbar in the second lane
            Dim lane2 As NCommandBarLane = New NCommandBarLane()
            manager.TopDock.Add(lane2)
            Dim toolbar As NToolBar = New NToolBar()
            toolbar.Pendant.Visibility = ENVisibility.Collapsed
            lane2.Add(toolbar)
            toolbar.Items.Add(NButton.CreateImageAndText(Presentation.NResources.Image_File_New_png, "New"))
            toolbar.Items.Add(NButton.CreateImageAndText(Presentation.NResources.Image_File_Open_png, "Open"))
            toolbar.Items.Add(NButton.CreateImageAndText(Presentation.NResources.Image_File_Save_png, "Save"))
            toolbar.Items.Add(New NCommandBarSeparator())
            toolbar.Items.Add(NButton.CreateImageAndText(Presentation.NResources.Image_File_Print_png, "Print"))

            ' Add a toolbar in the third lane
            Dim lane3 As NCommandBarLane = New NCommandBarLane()
            manager.TopDock.Add(lane3)
            toolbar = New NToolBar()
            toolbar.Pendant.Visibility = ENVisibility.Collapsed
            lane3.Add(toolbar)
            toolbar.Items.Add(CreateComboBox())
            toolbar.Items.Add(New NCommandBarSeparator())
            toolbar.Items.Add(NToggleButton.CreateImageAndText(Presentation.NResources.Image_FontStyle_Bold_png, "Bold"))
            toolbar.Items.Add(New NCheckBox("Plain Text"))
            Return manager
        End Function

        Private Function CreateWindows() As NStackPanel
            Dim stack As NStackPanel = New NStackPanel()
            stack.VerticalSpacing = 10

            ' create a button which shows a top-level window, added to the NDocumentBoxSurface.Windows collection.
            ' such top-level windows will use the style sheets applied to the NDocumentBox.
            Dim windowButton As NButton = New NButton("Show Window...")
            AddHandler windowButton.Click, Sub(ByVal arg)
                                               Dim window = NApplication.CreateTopLevelWindow(m_DocumentBox.Surface)
                                               window.Title = "Top-Level Window"
                                               Dim windowStack As NStackPanel = New NStackPanel()
                                               Dim label As NLabel = New NLabel("Top-level windows that are added to the NDocumentBoxSurface Windows collection," & vbCrLf & " will use the NDocumentBox styling.")
                                               windowStack.Add(label)
                                               Dim buttonStrip As NButtonStrip = New NButtonStrip()
                                               buttonStrip.AddCloseButton()
                                               windowStack.Add(buttonStrip)
                                               window.Content = windowStack
                                               window.Open()
                                           End Sub

            stack.Add(windowButton)

            ' message box
            Dim showMessageBoxButton As NButton = New NButton("Show MessageBox...")
            AddHandler showMessageBoxButton.Click, Sub(ByVal arg)
                                                       Dim msgBoxSettings As NMessageBoxSettings = New NMessageBoxSettings("Message boxes that are added to the NDocumentBoxSurface Windows collection," & vbCrLf & " will use the NDocumentBox styling.", "Message box title")
                                                       msgBoxSettings.WindowsContainer = m_DocumentBox.Surface
                                                       NMessageBox.Show(msgBoxSettings)
                                                   End Sub

            stack.Add(showMessageBoxButton)
            Return stack
        End Function

        Private Function CreateGroupBox(ByVal header As Object, ByVal content As Object) As NGroupBox
            Dim groupBox As NGroupBox = New NGroupBox(header, content)

            ' Check whether the application is in touch mode and set the size of the group box accordingly
            groupBox.PreferredSize = If(NApplication.Desktop.TouchMode, New NSize(360, 250), New NSize(260, 180)) ' touch mode size
            ' regular mode size
            Return groupBox
        End Function

#End Region

#Region "Event Handlers"

        Private Sub OnEnabledCheckBoxCheckedChanged(ByVal arg As NValueChangeEventArgs)
            m_DocumentBox.Surface.Content.Enabled = CBool(arg.NewValue)
        End Sub

        Private Sub OnThemeTreeViewSelectedPathChanged(ByVal arg1 As NValueChangeEventArgs)
            Dim treeView = CType(arg1.CurrentTargetNode, NTreeView)
            Dim selectedItem = treeView.SelectedItem
            If selectedItem Is Nothing Then Return

            If TypeOf selectedItem.Tag Is NTheme Then
                ' Apply the selected theme to the document box's document
                Dim theme = CType(selectedItem.Tag, NTheme)
                m_DocumentBox.Document.InheritStyleSheets = False
                m_DocumentBox.Document.StyleSheets.ApplyTheme(theme)
            ElseIf Object.Equals(selectedItem.Tag, "inherit") Then
                ' Make the document inherit its style sheets and clear all current ones
                m_DocumentBox.Document.InheritStyleSheets = True
                m_DocumentBox.Document.StyleSheets.Clear()
            End If
        End Sub

#End Region

#Region "Fields"

        Private m_DocumentBox As NDocumentBox

#End Region

#Region "Schema"

        Public Shared ReadOnly NDocumentBoxAndThemesExampleSchema As NSchema

#End Region
    End Class
End Namespace

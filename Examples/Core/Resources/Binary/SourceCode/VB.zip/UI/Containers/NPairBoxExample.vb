Imports Nevron.Nov.Dom
Imports Nevron.Nov.Editors
Imports Nevron.Nov.Graphics
Imports Nevron.Nov.Layout
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.UI
    Public Class NPairBoxExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' Default constructor.
        ''' </summary>
        Public Sub New()
        End Sub
        ''' <summary>
        ''' Static constructor.
        ''' </summary>
        Shared Sub New()
            NPairBoxExampleSchema = NSchema.Create(GetType(NPairBoxExample), NExampleBase.NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            m_PairBox = New NPairBox(CreateBoxContent("Box 1", NColor.Blue), CreateBoxContent("Box 2", NColor.Red))
            m_PairBox.HorizontalPlacement = ENHorizontalPlacement.Left
            m_PairBox.VerticalPlacement = ENVerticalPlacement.Top

            ' The Spacing property is automatically set from the UI theme to NDesign.HorizontalSpacing,
            ' so you don't need to set it. It is set here only for the purposes of the example.
            m_PairBox.Spacing = NDesign.HorizontalSpacing

            Return m_PairBox
        End Function
        Protected Overrides Function CreateExampleControls() As NWidget
            Dim stack As NStackPanel = New NStackPanel()

            Dim editors = NDesigner.GetDesigner(m_PairBox).CreatePropertyEditors(m_PairBox, NInputElement.EnabledProperty, NWidget.HorizontalPlacementProperty, NWidget.VerticalPlacementProperty, NPairBox.BoxesRelationProperty, NPairBox.FitModeProperty, NPairBox.FillModeProperty, NPairBox.SpacingProperty)

            Dim i = 0, count = editors.Count

            While i < count
                stack.Add(editors(i))
                i += 1
            End While

            Return New NUniSizeBoxGroup(stack)
        End Function
        Protected Overrides Function GetExampleDescription() As String
            Return "
<p>
	This example demonstrates how to create a pair box. The pair box is a widget, which consists of 2 other widgets - <b>Box1</b> and <b>Box2</b>.
	You can change the relative alignment, the spacing and the size mode of this widgets using the controls to the right.
</p>
" End Function

#End Region

#Region "Implementation"

        Private Function CreateBoxContent(ByVal text As String, ByVal borderColor As NColor) As NWidget
            Dim label As NLabel = New NLabel(text)
            label.HorizontalPlacement = ENHorizontalPlacement.Center
            label.VerticalPlacement = ENVerticalPlacement.Center

            Dim contentElement As NContentHolder = New NContentHolder(label)
            contentElement.Border = NBorder.CreateFilledBorder(borderColor)
            contentElement.BorderThickness = New NMargins(1)
            contentElement.Padding = New NMargins(2)

            Return contentElement
        End Function

#End Region

#Region "Fields"

        Private m_PairBox As NPairBox

#End Region

#Region "Schema"

        ''' <summary>
        ''' Schema associated with NPairBoxExample.
        ''' </summary>
        Public Shared ReadOnly NPairBoxExampleSchema As NSchema

#End Region
    End Class
End Namespace

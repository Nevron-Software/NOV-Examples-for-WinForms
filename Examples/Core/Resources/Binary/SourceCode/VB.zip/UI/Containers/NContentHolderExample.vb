Imports Nevron.Nov.Dom
Imports Nevron.Nov.Editors
Imports Nevron.Nov.Graphics
Imports Nevron.Nov.Layout
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.UI
    Public Class NContentHolderExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' Default constructor.
        ''' </summary>
        Public Sub New()
        End Sub

        ''' <summary>
        ''' Static constructor.
        ''' </summary>
        Shared Sub New()
            NContentHolderExampleSchema = NSchema.Create(GetType(NContentHolderExample), NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            Dim label As NLabel = New NLabel("Content Holder")
            label.HorizontalPlacement = ENHorizontalPlacement.Center
            label.VerticalPlacement = ENVerticalPlacement.Center

            m_ContentHolder = New NContentHolder()
            m_ContentHolder.Content = label
            m_ContentHolder.SetBorder(1, NColor.Red)

            Return m_ContentHolder
        End Function
        Protected Overrides Function CreateExampleControls() As NWidget
            Dim stack As NStackPanel = New NStackPanel()

            Dim propertyEditors = NDesigner.GetDesigner(m_ContentHolder).CreatePropertyEditors(m_ContentHolder, NWidget.HorizontalPlacementProperty, NWidget.VerticalPlacementProperty)

            For i = 0 To propertyEditors.Count - 1
                stack.Add(propertyEditors(i))
            Next

            Dim toggleLoaderButton As NButton = New NButton("Show Loader")
            toggleLoaderButton.Click += AddressOf ToggleLoaderButton_Click
            stack.Add(toggleLoaderButton)

            Return New NUniSizeBoxGroup(stack)
        End Function
        Protected Overrides Function GetExampleDescription() As String
            Return "<p>The content holder is a widget that can host another widget and provides support for showing a loader.</p>"
        End Function

#End Region

#Region "Implementation"

        Private Sub ToggleLoaderButton_Click(ByVal arg As NEventArgs)
            Dim button = CType(arg.CurrentTargetNode, NButton)
            Dim label = CType(button.Content, NLabel)

            If m_ContentHolder.Enabled Then
                m_ContentHolder.ShowLoader()
                label.Text = "Hide Loader"
            Else
                m_ContentHolder.HideLoader()
                label.Text = "Show Loader"
            End If
        End Sub

#End Region

#Region "Fields"

        Private m_ContentHolder As NContentHolder

#End Region

#Region "Schema"

        ''' <summary>
        ''' Schema associated with NContentHolderExample.
        ''' </summary>
        Public Shared ReadOnly NContentHolderExampleSchema As NSchema

#End Region
    End Class
End Namespace

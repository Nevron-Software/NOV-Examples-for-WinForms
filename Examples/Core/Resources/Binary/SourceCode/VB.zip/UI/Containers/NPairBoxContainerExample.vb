Imports Nevron.Nov.Editors
Imports Nevron.Nov.Dom
Imports Nevron.Nov.Graphics
Imports Nevron.Nov.Layout
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.UI
    Public Class NUniSizeBoxExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' Default constructor.
        ''' </summary>
        Public Sub New()
        End Sub
        ''' <summary>
        ''' Static constructor.
        ''' </summary>
        Shared Sub New()
            NUniSizeBoxExampleSchema = NSchema.Create(GetType(NUniSizeBoxExample), NExampleBase.NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            Dim stack As NStackPanel = New NStackPanel()
            stack.HorizontalPlacement = ENHorizontalPlacement.Left
            stack.VerticalPlacement = ENVerticalPlacement.Top
            m_PairBoxes = New NPairBox(Texts.Length / 2 - 1) {}

            For i = 0 To m_PairBoxes.Length - 1
                Dim pairBox As NPairBox = New NPairBox(New NLabel(Texts(i * 2)), New NLabel(Texts(i * 2 + 1)), True)
                pairBox.Box1.Border = NBorder.CreateFilledBorder(NColor.Blue)
                pairBox.Box1.BorderThickness = New NMargins(1)
                pairBox.Box2.Border = NBorder.CreateFilledBorder(NColor.Red)
                pairBox.Box2.BorderThickness = New NMargins(1)
                m_PairBoxes(i) = pairBox
                stack.Add(pairBox)
            Next

            Return New NUniSizeBoxGroup(stack)
        End Function

        Protected Overrides Function CreateExampleControls() As NWidget
            Dim stack As NStackPanel = New NStackPanel()
            Dim i = 0, count = m_PairBoxes.Length

            While i < count
                ' Create the pair box property editors
                Dim pairBox = m_PairBoxes(i)
                Dim editors = NDesigner.GetDesigner(pairBox).CreatePropertyEditors(pairBox, NPairBox.FillModeProperty, NPairBox.FitModeProperty)
                Dim box1 = CType(pairBox.Box1, NUniSizeBox)
                editors.Add(NDesigner.GetDesigner(box1).CreatePropertyEditor(box1, NUniSizeBox.UniSizeModeProperty))
                Dim box2 = CType(pairBox.Box2, NUniSizeBox)
                editors.Add(NDesigner.GetDesigner(box2).CreatePropertyEditor(box2, NUniSizeBox.UniSizeModeProperty))

                ' Create the properties stack panel
                Dim propertyStack As NStackPanel = New NStackPanel()
                Dim j = 0, editorCount = editors.Count

                While j < editorCount
                    propertyStack.Add(editors(j))
                    j += 1
                End While

                ' Add the box 1 preferred height editor
                Dim editor = NDesigner.GetDesigner(box1.Content).CreatePropertyEditor(box1.Content, NBoxElement.PreferredHeightProperty)
                Dim label As NLabel = editor.GetFirstDescendant(Of NLabel)()
                label.Text = "Box 1 Preferred Height:"
                propertyStack.Add(editor)

                ' Add the box 2 preferred height editor
                editor = NDesigner.GetDesigner(box2.Content).CreatePropertyEditor(box2.Content, NBoxElement.PreferredHeightProperty)
                label = editor.GetFirstDescendant(Of NLabel)()
                label.Text = "Box 2 Preferred Height:"
                propertyStack.Add(editor)

                ' Create a group box for the properties
                Dim groupBox As NGroupBox = New NGroupBox("Pair Box " & (i + 1).ToString())
                groupBox.Content = propertyStack
                stack.Add(groupBox)
                i += 1
            End While

            Return New NUniSizeBoxGroup(stack)
        End Function

        Protected Overrides Function GetExampleDescription() As String
            Return "
<p>
	This example demonstrates how to create several pair boxes and place them in an alignable element container.
	Alignable element containers let the user specify how to size the alignable elements in the container.
</p>
"
        End Function

#End Region

#Region "Fields"

        Private m_PairBoxes As NPairBox()

#End Region

#Region "Schema"

        ''' <summary>
        ''' Schema associated with NUniSizeBoxExample.
        ''' </summary>
        Public Shared ReadOnly NUniSizeBoxExampleSchema As NSchema

#End Region

#Region "Constants"

        Private Shared ReadOnly Texts As String() = New String() {"This is box 1.1", "I'm box 1.2 and I'm wider", "Box 2.1", "Box 2.2", "I am box 3.1 and I am the widest one", "The last box - 3.2"}

#End Region
    End Class
End Namespace

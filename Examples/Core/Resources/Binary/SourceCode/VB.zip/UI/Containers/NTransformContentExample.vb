Imports Nevron.Nov.Dom
Imports Nevron.Nov.Editors
Imports Nevron.Nov.Graphics
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.UI
    Public Class NTransformContentExample
        Inherits NExampleBase
#Region "Constructors"

        Public Sub New()
        End Sub

        Shared Sub New()
            NTransformContentExampleSchema = NSchema.Create(GetType(NTransformContentExample), NExampleBase.NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            ' create a dummy button
            Dim button As NButton = New NButton("I can be transformed")
            m_TransformContent = New NTransformContent(button)
            m_TransformContent.BorderThickness = New NMargins(1)
            m_TransformContent.Border = NBorder.CreateFilledBorder(NColor.Red)
            Return m_TransformContent
        End Function

        Protected Overrides Function CreateExampleControls() As NWidget
            Dim stack As NStackPanel = New NStackPanel()

            ' Transform Properties
            If True Then
                Dim editors = NDesigner.GetDesigner(m_TransformContent).CreatePropertyEditors(m_TransformContent, NTransformContent.ScaleXProperty, NTransformContent.ScaleYProperty, NTransformContent.AngleProperty, NTransformContent.StretchAtRightAnglesProperty, NWidget.HorizontalPlacementProperty, NWidget.VerticalPlacementProperty)
                Dim propertiesStack As NStackPanel = New NStackPanel()

                For i = 0 To editors.Count - 1
                    propertiesStack.Add(editors(i))
                Next

                stack.Add(New NGroupBox("Transform Content Properties", propertiesStack))
            End If

            Return stack
        End Function

        Protected Overrides Function GetExampleDescription() As String
            Return "
<p>
	This example demonstrates how to create and use the NTransformContent widget. 
    This widget allows you to aggregate another widget and apply arbitrary rotation and scaling on the content.
</p>
"
        End Function

#End Region

#Region "Fields"

        Private m_TransformContent As NTransformContent

#End Region

#Region "Schema"

        Public Shared ReadOnly NTransformContentExampleSchema As NSchema

#End Region

#Region "Nested Types - NDynamicContentTooltip"

        ''' <summary>
        ''' A tooltip that shows as content the current date and time
        ''' </summary>
        Public Class NDynamicContentTooltip
            Inherits NTooltip
#Region "Constructors"

            Public Sub New()
            End Sub

            Shared Sub New()
                NDynamicContentTooltipSchema = NSchema.Create(GetType(NDynamicContentTooltip), NTooltipSchema)
            End Sub

#End Region

#Region "Overrides - GetContent()"

            Public Overrides Function GetContent() As NWidget
                Dim now = Date.Now
                Return New NLabel("I was shown at: " & now.ToString("T"))
            End Function

#End Region

#Region "Schema"

            Public Shared ReadOnly NDynamicContentTooltipSchema As NSchema

#End Region
        End Class

#End Region
    End Class
End Namespace

Imports System.IO
Imports System.Text

Imports Nevron.Nov.Dom
Imports Nevron.Nov.Graphics
Imports Nevron.Nov.IO
Imports Nevron.Nov.Layout
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.UI
    Public Class NFileDialogsExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' Default constructor.
        ''' </summary>
        Public Sub New()
        End Sub
        ''' <summary>
        ''' Static constructor.
        ''' </summary>
        Shared Sub New()
            NFileDialogsExampleSchema = NSchema.Create(GetType(NFileDialogsExample), NExampleBase.NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            m_TextBox = New NTextBox()
            m_TextBox.Multiline = True
            m_TextBox.AcceptsEnter = True
            m_TextBox.AcceptsTab = True
            m_TextBox.VScrollMode = ENScrollMode.WhenNeeded
            m_TextBox.Text = "This is a sample text." & vbLf & vbLf & "You can edit and save it." & vbLf & vbLf & "You can also load text from a text file."
            Return m_TextBox
        End Function
        Protected Overrides Function CreateExampleControls() As NWidget
            Dim stack As NStackPanel = New NStackPanel()
            stack.FillMode = ENStackFillMode.Last
            stack.FitMode = ENStackFitMode.Last

            ' create the buttons group
            Dim buttonsGroup As NGroupBox = New NGroupBox("Open Dialogs from Buttons")
            stack.Add(buttonsGroup)

            Dim buttonsStack As NStackPanel = New NStackPanel()
            buttonsStack.Direction = ENHVDirection.LeftToRight
            buttonsGroup.Content = buttonsStack

            Dim openButton As NButton = New NButton("Open File...")
            openButton.Content.HorizontalPlacement = ENHorizontalPlacement.Center
            openButton.Click += New [Function](Of NEventArgs)(AddressOf OnOpenButtonClick)
            buttonsStack.Add(openButton)

            Dim openMultiselectButton As NButton = New NButton("Choose Multiple Files...")
            openMultiselectButton.Content.HorizontalPlacement = ENHorizontalPlacement.Center
            openMultiselectButton.Click += New [Function](Of NEventArgs)(AddressOf OnMultiselectOpenButtonClick)
            buttonsStack.Add(openMultiselectButton)

            Dim saveButton As NButton = New NButton("Save to File...")
            saveButton.Content.HorizontalPlacement = ENHorizontalPlacement.Center
            saveButton.Click += New [Function](Of NEventArgs)(AddressOf OnSaveButtonClick)
            buttonsStack.Add(saveButton)

            ' create the menu group
            Dim menuGroup As NGroupBox = New NGroupBox("Open Dialogs from Menu Items")
            stack.Add(menuGroup)

            Dim menuBar As NMenuBar = New NMenuBar()
            menuGroup.Content = menuBar

            Dim fileMenu As NMenuDropDown = New NMenuDropDown("File")
            menuBar.Items.Add(fileMenu)

            Dim openFileMenuItem As NMenuItem = New NMenuItem("Open File...")
            openFileMenuItem.Click += New [Function](Of NEventArgs)(AddressOf OnOpenFileMenuItemClick)
            fileMenu.Items.Add(openFileMenuItem)

            Dim saveFileMenuItem As NMenuItem = New NMenuItem("Save File...")
            saveFileMenuItem.Click += New [Function](Of NEventArgs)(AddressOf OnSaveFileMenuItemClick)
            fileMenu.Items.Add(saveFileMenuItem)

            ' create the dialog group
            Dim dialogGroup As NGroupBox = New NGroupBox("Open Dialogs from Dialog")
            stack.Add(dialogGroup)

            Dim showDialogButton As NButton = New NButton("Show Dialog...")
            showDialogButton.Click += New [Function](Of NEventArgs)(AddressOf OnShowDialogButtonClick)
            dialogGroup.Content = showDialogButton

            ' add the events log
            m_EventsLog = New NExampleEventsLog()
            stack.Add(m_EventsLog)

            Return stack
        End Function
        Protected Overrides Function GetExampleDescription() As String
            Return "
<p>
	This example demonstrates how to create and use the open and save file dialogs provided by NOV.
</p>
" End Function

#End Region

#Region "Event Handlers"

        Private Sub OnOpenButtonClick(ByVal args As NEventArgs)
            ShowOpenFileDialog()
        End Sub
        Private Sub OnMultiselectOpenButtonClick(ByVal args As NEventArgs)
            ShowMultiselectOpenFileDialog()
        End Sub
        Private Sub OnSaveButtonClick(ByVal args As NEventArgs)
            ShowSaveFileDialog()
        End Sub

        Private Sub OnOpenFileMenuItemClick(ByVal arg1 As NEventArgs)
            ShowOpenFileDialog()
        End Sub
        Private Sub OnSaveFileMenuItemClick(ByVal arg1 As NEventArgs)
            ShowSaveFileDialog()
        End Sub

        Private Sub OnShowDialogButtonClick(ByVal arg1 As NEventArgs)
            Dim stack As NStackPanel = New NStackPanel()
            stack.Margins = New NMargins(10)
            stack.VerticalSpacing = 10

            Dim openButton As NButton = New NButton("Open File...")
            openButton.Content.HorizontalPlacement = ENHorizontalPlacement.Center
            openButton.Click += New [Function](Of NEventArgs)(AddressOf OnOpenButtonClick)
            stack.Add(openButton)

            Dim saveButton As NButton = New NButton("Save to File...")
            saveButton.Content.HorizontalPlacement = ENHorizontalPlacement.Center
            saveButton.Click += New [Function](Of NEventArgs)(AddressOf OnSaveButtonClick)
            stack.Add(saveButton)

            Dim closeButtonStrip As NButtonStrip = New NButtonStrip()
            closeButtonStrip.AddCloseButton()
            stack.Add(closeButtonStrip)

            ' create a dialog that is owned by this widget window
            Dim dialog As NTopLevelWindow = NApplication.CreateTopLevelWindow()
            dialog.SetupDialogWindow("Show File Dialogs", False)
            dialog.Content = stack
            dialog.Open()
        End Sub

#End Region

#Region "Implementation - Show Open And Save Dialog"

        Private Sub ShowOpenFileDialog()
            Dim openFileDialog As NOpenFileDialog = New NOpenFileDialog()
            openFileDialog.FileTypes = New NFileDialogFileType() {New NFileDialogFileType("Text Files", "txt"), New NFileDialogFileType("XML Files", "xml"), New NFileDialogFileType("All Files", "*")}
            openFileDialog.SelectedFilterIndex = 0
            openFileDialog.MultiSelect = False
            openFileDialog.InitialDirectory = ""
            openFileDialog.Title = "Open Text File"

            openFileDialog.Closed += New [Function](Of NOpenFileDialogResult)(AddressOf OnOpenFileDialogClosed)
            openFileDialog.RequestShow()
        End Sub
        Private Sub OnOpenFileDialogClosed(ByVal result As NOpenFileDialogResult)
            Select Case result.Result
                Case ENCommonDialogResult.OK
                    Dim file = result.Files(0)
                    file.OpenReadAsync().[Then](Sub(ByVal stream As Stream)
                                                    Using stream
                                                        m_TextBox.Text = NStreamHelpers.ReadToEndAsString(stream)
                                                    End Using

                                                    m_EventsLog.LogEvent("File opened: " & file.Name)
                                                End Sub)

                Case ENCommonDialogResult.Cancel
                    m_EventsLog.LogEvent("File not selected")

                Case ENCommonDialogResult.Error
                    m_EventsLog.LogEvent("Error message: " & result.ErrorException.Message)
            End Select
        End Sub

        Private Sub ShowMultiselectOpenFileDialog()
            Dim openFileDialog As NOpenFileDialog = New NOpenFileDialog()
            openFileDialog.MultiSelect = True
            openFileDialog.Title = "Select Multiple Files"

            openFileDialog.Closed += New [Function](Of NOpenFileDialogResult)(AddressOf OnMultiselectOpenFileDialogClosed)
            openFileDialog.RequestShow()
        End Sub
        Private Sub OnMultiselectOpenFileDialogClosed(ByVal result As NOpenFileDialogResult)
            Select Case result.Result
                Case ENCommonDialogResult.OK
                    Dim sb As StringBuilder = New StringBuilder()

                    For i = 0 To result.Files.Length - 1
                        sb.AppendLine(result.Files(i).Name)
                    Next

                    m_TextBox.Text = sb.ToString()

                    m_EventsLog.LogEvent("Multiple files selected")

                Case ENCommonDialogResult.Cancel
                    m_EventsLog.LogEvent("File not selected")

                Case ENCommonDialogResult.Error
                    m_EventsLog.LogEvent("Error message: " & result.ErrorException.Message)
            End Select
        End Sub

        Private Sub ShowSaveFileDialog()
            Dim saveFileDialog As NSaveFileDialog = New NSaveFileDialog()
            saveFileDialog.FileTypes = New NFileDialogFileType() {New NFileDialogFileType("Text Files", "txt"), New NFileDialogFileType("All Files", "*")}
            saveFileDialog.InitialDirectory = String.Empty
            saveFileDialog.SelectedFilterIndex = 0
            saveFileDialog.DefaultFileName = "NevronTest"
            saveFileDialog.DefaultExtension = "txt"
            saveFileDialog.Title = "Save File As"

            saveFileDialog.Closed += New [Function](Of NSaveFileDialogResult)(AddressOf OnSaveFileDialogClosed)
            saveFileDialog.RequestShow()
        End Sub
        Private Sub OnSaveFileDialogClosed(ByVal result As NSaveFileDialogResult)
            Select Case result.Result
                Case ENCommonDialogResult.OK
                    result.File.CreateAsync().[Then](Sub(ByVal stream As Stream)
                                                         Using writer As StreamWriter = New StreamWriter(stream)
                                                             writer.Write(m_TextBox.Text)
                                                         End Using

                                                         m_EventsLog.LogEvent("File saved: " & result.SafeFileName)
                                                     End Sub)

                Case ENCommonDialogResult.Cancel
                    m_EventsLog.LogEvent("File not selected")

                Case ENCommonDialogResult.Error
                    m_EventsLog.LogEvent("Error Message: " & result.ErrorException.Message)
            End Select
        End Sub

#End Region

#Region "Fields"

        Private m_TextBox As NTextBox
        Private m_EventsLog As NExampleEventsLog

#End Region

#Region "Schema"

        ''' <summary>
        ''' Schema associated with NFileDialogsExample.
        ''' </summary>
        Public Shared ReadOnly NFileDialogsExampleSchema As NSchema

#End Region
    End Class
End Namespace

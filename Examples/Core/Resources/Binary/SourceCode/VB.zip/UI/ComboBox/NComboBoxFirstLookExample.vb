Imports Nevron.Nov.Dom
Imports Nevron.Nov.Editors
Imports Nevron.Nov.Layout
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.UI
    Public Class NComboBoxFirstLookExample
        Inherits NExampleBase
#Region "Constructors"

        Public Sub New()
        End Sub

        Shared Sub New()
            NComboBoxFirstLookExampleSchema = NSchema.Create(GetType(NComboBoxFirstLookExample), NExampleBase.NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            ' create the combo box
            m_ComboBox = New NComboBox()
            m_ComboBox.HorizontalPlacement = ENHorizontalPlacement.Left
            m_ComboBox.VerticalPlacement = ENVerticalPlacement.Top
            m_ComboBox.DropDownStyle = ENComboBoxStyle.DropDownList

            ' add a few items
            For i = 0 To 10 - 1
                m_ComboBox.Items.Add(New NComboBoxItem("Item " & i.ToString()))
            Next

            ' select the first item
            m_ComboBox.SelectedIndex = 0

            ' hook combo box selection events
            AddHandler m_ComboBox.SelectedIndexChanged, New [Function](Of NValueChangeEventArgs)(AddressOf OnComboBoxSelectedIndexChanged)
            Return m_ComboBox
        End Function

        Protected Overrides Function CreateExampleControls() As NWidget
            Dim stack As NStackPanel = New NStackPanel()
            stack.FillMode = ENStackFillMode.Last
            stack.FitMode = ENStackFitMode.Last
            Dim propertiesStack As NStackPanel = New NStackPanel()
            Dim editors = NDesigner.GetDesigner(m_ComboBox).CreatePropertyEditors(m_ComboBox, NInputElement.EnabledProperty, NWidget.HorizontalPlacementProperty, NWidget.VerticalPlacementProperty, NDropDownEdit.DropDownButtonPositionProperty, NComboBox.SelectedIndexProperty, NComboBox.DropDownStyleProperty, NComboBox.WheelNavigationModeProperty)

            For i = 0 To editors.Count - 1
                propertiesStack.Add(editors(i))
            Next

            stack.Add(New NGroupBox("Properties", New NUniSizeBoxGroup(propertiesStack)))

            ' create the events list box
            m_EventsLog = New NExampleEventsLog()
            stack.Add(m_EventsLog)
            Return stack
        End Function

        Protected Overrides Function GetExampleDescription() As String
            Return "
<p>
	This example demonstrates how to create a simple combo box with text only items. You can use the controls
	on the right to modify various properties of the combo box.
</p>
"
        End Function

#End Region

#Region "Event Handlers"

        Private Sub OnComboBoxSelectedIndexChanged(ByVal args As NValueChangeEventArgs)
            Dim comboBox = CType(args.TargetNode, NComboBox)
            m_EventsLog.LogEvent("Selected Index: " & comboBox.SelectedIndex.ToString())
        End Sub

        Private Sub OnShowDesignerButtonClicked(ByVal args As NEventArgs)
            Dim editor As NEditor = NDesigner.GetDesigner(m_ComboBox).CreateInstanceEditor(m_ComboBox)
            Dim window As NEditorWindow = NApplication.CreateTopLevelWindow(Of NEditorWindow)()
            window.Editor = editor
            window.Open()
        End Sub

#End Region

#Region "Fields"

        Private m_EventsLog As NExampleEventsLog
        Private m_ComboBox As NComboBox

#End Region

#Region "Schema"

        Public Shared ReadOnly NComboBoxFirstLookExampleSchema As NSchema

#End Region
    End Class
End Namespace

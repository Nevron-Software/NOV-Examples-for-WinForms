Imports Nevron.Nov.Dom
Imports Nevron.Nov.Editors
Imports Nevron.Nov.Layout
Imports Nevron.Nov.Text
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.UI
    Public Class NMaskedEnumDropDownExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' Default constructor.
        ''' </summary>
        Public Sub New()
        End Sub

        ''' <summary>
        ''' Static constructor.
        ''' </summary>
        Shared Sub New()
            NMaskedEnumDropDownExampleSchema = NSchema.Create(GetType(NMaskedEnumDropDownExample), NExampleBaseSchema)
        End Sub

#End Region

#Region "Protected Overrides"

        Protected Overrides Function CreateExampleContent() As NWidget
            Dim dropDown As NMaskedEnumDropDown = New NMaskedEnumDropDown()
            dropDown.VerticalPlacement = ENVerticalPlacement.Top
            dropDown.HorizontalPlacement = ENHorizontalPlacement.Left
            dropDown.ColumnCount = 2
            dropDown.EnumType = NDomType.FromType(GetType(ENTableStyleOptions))
            dropDown.Initialize()
            dropDown.EnumValue = ENTableStyleOptions.FirstRow
            Return dropDown
        End Function

        Protected Overrides Function CreateExampleControls() As NWidget
            Return Nothing
        End Function

        Protected Overrides Function GetExampleDescription() As String
            Return "
<p>
	This example demonstrates how to used the masked (flag) enum drop down widget to select enum flags.
</p>
"
        End Function

#End Region

#Region "Schema"

        ''' <summary>
        ''' Schema associated with NMaskedEnumDropDownExample.
        ''' </summary>
        Public Shared ReadOnly NMaskedEnumDropDownExampleSchema As NSchema

#End Region
    End Class
End Namespace

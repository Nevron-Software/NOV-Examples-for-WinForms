Imports Nevron.Nov.Dom
Imports Nevron.Nov.Layout
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.UI
    Public Class NComboBoxItemsManipulationExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' Default constructor.
        ''' </summary>
        Public Sub New()
        End Sub
        ''' <summary>
        ''' Static constructor.
        ''' </summary>
        Shared Sub New()
            NComboBoxItemsManipulationExampleSchema = NSchema.Create(GetType(NComboBoxItemsManipulationExample), NExampleBase.NExampleBaseSchema)
        End Sub

#End Region

#Region "Overrides - Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            ' create the combo box
            m_ComboBox = New NComboBox()
            m_ComboBox.HorizontalPlacement = ENHorizontalPlacement.Left
            m_ComboBox.VerticalPlacement = ENVerticalPlacement.Top
            m_ComboBox.DropDownStyle = ENComboBoxStyle.DropDownList

            ' add a few items
            For i = 0 To 9
                m_ComboBox.Items.Add(New NComboBoxItem("Item " & i.ToString()))
            Next

            ' select the first item
            m_ComboBox.SelectedIndex = 0

            ' hook combo box selection events
            m_ComboBox.SelectedIndexChanged += New [Function](Of NValueChangeEventArgs)(AddressOf OnComboBoxSelectedIndexChanged)

            Return m_ComboBox
        End Function
        Protected Overrides Function CreateExampleControls() As NWidget
            Dim stack As NStackPanel = New NStackPanel()
            stack.FillMode = ENStackFillMode.Last
            stack.FitMode = ENStackFitMode.Last

            ' Create the commands
            stack.Add(CreateCommandsGroupBox())

            ' Create the events log
            m_EventsLog = New NExampleEventsLog()
            stack.Add(m_EventsLog)

            Return stack
        End Function
        Protected Overrides Function GetExampleDescription() As String
            Return "
<p>
	This example demonstrates how to create a simple combo box with text only items and how to add/remove items.
	You can use the buttons on the right to add/remove items from the combo box's <b>Items</b> collection.
</p>
" End Function

#End Region

#Region "Implementation"

        Private Function CreateCommandsGroupBox() As NGroupBox
            Dim commandsStack As NStackPanel = New NStackPanel()

            Dim addButton As NButton = New NButton("Add Item")
            addButton.Click += New [Function](Of NEventArgs)(AddressOf OnAddButtonClick)
            commandsStack.Add(addButton)

            Dim removeSelectedButton As NButton = New NButton("Remove Selected")
            removeSelectedButton.Click += New [Function](Of NEventArgs)(AddressOf OnRemoveSelectedButtonClick)
            commandsStack.Add(removeSelectedButton)

            Dim removeAllButton As NButton = New NButton("Remove All")
            removeAllButton.Click += New [Function](Of NEventArgs)(AddressOf OnRemoveAllButtonClick)
            commandsStack.Add(removeAllButton)

            Return New NGroupBox("Commands", commandsStack)
        End Function

#End Region

#Region "Event Handlers"

        Private Sub OnComboBoxSelectedIndexChanged(ByVal args As NValueChangeEventArgs)
            Dim comboBox = CType(args.TargetNode, NComboBox)
            m_EventsLog.LogEvent("Selected Index: " & comboBox.SelectedIndex.ToString())
        End Sub
        Private Sub OnAddButtonClick(ByVal args As NEventArgs)
            m_ComboBox.Items.Add(New NComboBoxItem("Item " & m_ComboBox.Items.Count))
        End Sub
        Private Sub OnRemoveSelectedButtonClick(ByVal args As NEventArgs)
            If m_ComboBox.SelectedIndex <> -1 Then
                m_ComboBox.Items.RemoveAt(m_ComboBox.SelectedIndex)
                m_ComboBox.SelectedIndex = -1
            End If
        End Sub
        Private Sub OnRemoveAllButtonClick(ByVal args As NEventArgs)
            m_ComboBox.Items.Clear()
        End Sub

#End Region

#Region "Fields"

        Private m_ComboBox As NComboBox
        Private m_EventsLog As NExampleEventsLog

#End Region

#Region "Schema"

        ''' <summary>
        ''' Schema associated with NComboBoxItemsManipulationExample.
        ''' </summary>
        Public Shared ReadOnly NComboBoxItemsManipulationExampleSchema As NSchema

#End Region
    End Class
End Namespace

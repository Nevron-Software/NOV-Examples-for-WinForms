Imports Nevron.Nov.Editors
Imports Nevron.Nov.Dom
Imports Nevron.Nov.Layout
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.UI
    Public Class NTreeViewFirstLookExample
        Inherits NExampleBase
#Region "Constructors"

        Public Sub New()
        End Sub

        Shared Sub New()
            NTreeViewFirstLookExampleSchema = NSchema.Create(GetType(NTreeViewFirstLookExample), NExampleBase.NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            ' Create the tree view
            m_TreeView = New NTreeView()
            m_TreeView.HorizontalPlacement = ENHorizontalPlacement.Left
            ' Check whether the application is in touch mode and set the width of the tree view.
            Dim touchMode = NApplication.Desktop.TouchMode
            m_TreeView.PreferredWidth = If(touchMode, 300, 200)

            ' Add some items
            For i = 0 To 32 - 1
                Dim l1Item = CreateTreeViewItem(String.Format("Item {0}", i))
                m_TreeView.Items.Add(l1Item)

                For j = 0 To 8 - 1
                    Dim l2Item = CreateTreeViewItem(String.Format("Item {0}.{1}", i, j))
                    l1Item.Items.Add(l2Item)

                    For k = 0 To 2 - 1
                        Dim l3Item = CreateTreeViewItem(String.Format("Item {0}.{1}.{2}", i, j, k))
                        l2Item.Items.Add(l3Item)
                    Next
                Next
            Next

            ' Hook to tree view events
            AddHandler m_TreeView.SelectedPathChanged, New [Function](Of NValueChangeEventArgs)(AddressOf OnTreeViewSelectedPathChanged)
            Return m_TreeView
        End Function

        Protected Overrides Function CreateExampleControls() As NWidget
            Dim stack As NStackPanel = New NStackPanel()
            stack.FillMode = ENStackFillMode.Last
            stack.FitMode = ENStackFitMode.Last

            ' Create the properties group box
            stack.Add(CreatePropertiesGroupBox())

            ' Create the events log
            m_EventsLog = New NExampleEventsLog()
            stack.Add(m_EventsLog)
            Return stack
        End Function

        Protected Overrides Function GetExampleDescription() As String
            Return "
<p>
	This example demonstrates how to create a tree view with text only items. You can use the controls
	on the right to modify various properties of the tree box.
</p>
"
        End Function

#End Region

#Region "Implementation"

        Private Function CreatePropertiesGroupBox() As NGroupBox
            Dim propertiesStack As NStackPanel = New NStackPanel()
            Dim editors = NDesigner.GetDesigner(m_TreeView).CreatePropertyEditors(m_TreeView, NInputElement.EnabledProperty, NWidget.HorizontalPlacementProperty, NWidget.VerticalPlacementProperty, NScrollContentBase.NoScrollHAlignProperty, NScrollContentBase.NoScrollVAlignProperty, NScrollContentBase.HScrollModeProperty, NScrollContentBase.VScrollModeProperty, NTreeView.IntegralVScrollProperty)
            Dim i = 0, count = editors.Count

            While i < count
                propertiesStack.Add(editors(i))
                i += 1
            End While

            Dim propertiesGroupBox As NGroupBox = New NGroupBox("Properties", New NUniSizeBoxGroup(propertiesStack))
            Return propertiesGroupBox
        End Function

        Private Function CreateTreeViewItem(ByVal text As String) As NTreeViewItem
            Dim item As NTreeViewItem = New NTreeViewItem(text)
            item.Tag = text
            AddHandler item.ExpandedChanged, New [Function](Of NValueChangeEventArgs)(AddressOf OnTreeViewItemExpandedChanged)
            Return item
        End Function

#End Region

#Region "Event Handlers"

        Private Sub OnTreeViewSelectedPathChanged(ByVal args As NValueChangeEventArgs)
            m_EventsLog.LogEvent("Selected: " & m_TreeView.SelectedItem.Tag.ToString())
        End Sub

        Private Sub OnTreeViewItemExpandedChanged(ByVal args As NValueChangeEventArgs)
            Dim item = CType(args.TargetNode, NTreeViewItem)

            If item.Expanded Then
                m_EventsLog.LogEvent("Expanded: " & item.Tag.ToString())
            Else
                m_EventsLog.LogEvent("Collapsed: " & item.Tag.ToString())
            End If
        End Sub

#End Region

#Region "Fields"

        Private m_TreeView As NTreeView
        Private m_EventsLog As NExampleEventsLog

#End Region

#Region "Schema"

        ''' <summary>
        ''' Schema associated with NTreeViewFirstLookExample.
        ''' </summary>
        Public Shared ReadOnly NTreeViewFirstLookExampleSchema As NSchema

#End Region
    End Class
End Namespace

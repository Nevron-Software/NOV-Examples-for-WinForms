Imports Nevron.Nov.Dom
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.UI
    Public Class NCommandingExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' Default constructor.
        ''' </summary>
        Public Sub New()
        End Sub
        ''' <summary>
        ''' Static constructor.
        ''' </summary>
        Shared Sub New()
            NCommandingExampleSchema = NSchema.Create(GetType(NCommandingExample), NExampleBase.NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleControls() As NWidget
            Return Nothing
        End Function

        Protected Overrides Function CreateExampleContent() As NWidget
            Return Nothing
        End Function

        Protected Overrides Function GetExampleDescription() As String
            Return "
<p>
This example demonstrates how to create auto sizable and auto centered windows with expressions.
</p>
"
        End Function

#End Region

#Region "Schema"

        ''' <summary>
        ''' Schema associated with NCommandingExample.
        ''' </summary>
        Public Shared ReadOnly NCommandingExampleSchema As NSchema

#End Region

        Public Class MyCommandableWidget
            Inherits NWidget

            Public Sub New()
                ' TODO: initialize commander here
            End Sub

            Shared Sub New()
                MyCommandableWidgetSchema = NSchema.Create(GetType(MyCommandableWidget), NWidgetSchema)
                ' create a command that is associated with the Ctrl+T shortcut
                MyActionCommand = NCommand.Create(GetType(MyCommandableWidget), "MyActionCommand", "Sets a contstant text", New NShortcut(New NKey(ENKeyCode.T), ENModifierKeys.Control))
                MyToggleCommand = NCommand.Create(GetType(MyCommandableWidget), "MyToggleCommand", "Toggles the text fill", New NShortcut(New NKey(ENKeyCode.R), ENModifierKeys.Control))
            End Sub

            Public Shared ReadOnly MyCommandableWidgetSchema As NSchema
            Public Shared ReadOnly MyActionCommand As NCommand
            Public Shared ReadOnly MyToggleCommand As NCommand
        End Class

        Public Class MyToggleCommandAction
            Inherits NToggleCommandAction

            Public Overrides Function IsChecked(ByVal target As NNode) As Boolean
                Dim w As MyCommandableWidget = TryCast(OwnerInputElement, MyCommandableWidget)
                Return False
            End Function

            Public Overrides Sub Execute(ByVal target As NNode, ByVal parameter As Object)
                Throw New NotImplementedException()
            End Sub

            Public Overrides Function GetCommand() As NCommand
                Return MyCommandableWidget.MyActionCommand
            End Function

            Public Overrides Function IsEnabled(ByVal target As NNode) As Boolean
                Throw New NotImplementedException()
            End Function
        End Class
    End Class
End Namespace

Imports Nevron.Nov.Dom
Imports Nevron.Nov.Layout
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.UI
    Public Class NRadioButtonExample
        Inherits NExampleBase
#Region "Constructors"

        Public Sub New()
        End Sub

        Shared Sub New()
            NRadioButtonExampleSchema = NSchema.Create(GetType(NRadioButtonExample), NExampleBase.NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            Dim tab As NTab = New NTab()

            ' create a tab page with vertically arranged radio buttons
            Dim verticalTabPage As NTabPage = New NTabPage("Vertical Radio Group")
            tab.TabPages.Add(verticalTabPage)
            Dim verticalRadioGroup As NRadioButtonGroup = New NRadioButtonGroup()
            verticalRadioGroup.HorizontalPlacement = ENHorizontalPlacement.Left
            verticalRadioGroup.VerticalPlacement = ENVerticalPlacement.Top
            verticalTabPage.Content = verticalRadioGroup
            Dim verticalStack As NStackPanel = New NStackPanel()
            verticalRadioGroup.Content = verticalStack

            For i = 0 To 5 - 1
                Dim radioButton As NRadioButton = New NRadioButton("Item " & i.ToString())
                verticalStack.Add(radioButton)
            Next

            Dim disabledRadioButton1 As NRadioButton = New NRadioButton("Disabled")
            disabledRadioButton1.Enabled = False
            verticalStack.Add(disabledRadioButton1)
            AddHandler verticalRadioGroup.SelectedIndexChanged, AddressOf OnVerticalRadioGroupSelectedIndexChanged

            ' create a tab page with horizontally arranged radio buttons
            Dim horizontalTabPage As NTabPage = New NTabPage("Horizontal Radio Group")
            tab.TabPages.Add(horizontalTabPage)
            Dim horizontalRadioGroup As NRadioButtonGroup = New NRadioButtonGroup()
            horizontalRadioGroup.VerticalPlacement = ENVerticalPlacement.Top
            horizontalRadioGroup.HorizontalPlacement = ENHorizontalPlacement.Left
            horizontalTabPage.Content = horizontalRadioGroup
            Dim horizontalStack As NStackPanel = New NStackPanel()
            horizontalStack.Direction = ENHVDirection.LeftToRight
            horizontalRadioGroup.Content = horizontalStack

            For i = 0 To 5 - 1
                Dim radioButton As NRadioButton = New NRadioButton("Item " & i.ToString())
                horizontalStack.Add(radioButton)
            Next

            Dim disabledRadioButton2 As NRadioButton = New NRadioButton("Disabled")
            disabledRadioButton2.Enabled = False
            horizontalStack.Add(disabledRadioButton2)
            AddHandler horizontalRadioGroup.SelectedIndexChanged, AddressOf OnHorizontalRadioGroupSelectedIndexChanged
            Return tab
        End Function

        Protected Overrides Function CreateExampleControls() As NWidget
            Dim stack As NStackPanel = New NStackPanel()
            stack.FillMode = ENStackFillMode.Last
            stack.FitMode = ENStackFitMode.Last

            ' create the events list box
            m_EventsLog = New NExampleEventsLog()
            stack.Add(m_EventsLog)
            Return stack
        End Function

        Protected Overrides Function GetExampleDescription() As String
            Return "
<p>
	This example demonstrates how to create and use radio buttons and radio button groups. 
</p>
<p>
    A radio button (NRadioButton) is a kind of a toggle button, which is intended to be placed inside the sub-hierarchy of a radio button group (NRadioButtonGroup).
    When there are multiple radio buttons inside the radio button group sub-hierarchy, only one can be checked at a time. 
    Checking a different radio button will automatically uncheck the previously checked one.
</p>
<p>
    The radio button group (NRadioButtonGroup) is a content container, thus it is up to the developer to choose the style in which the radio buttons are arranged.
    In this example we have created two radio groups, each of which holding a stack panel (horizontal or vertical) that contain radio buttons. 
    It is however possible to arrange the radio buttons in any way that you see fit.
</p>
"
        End Function

#End Region

#Region "Event Handlers"

        Private Sub OnHorizontalRadioGroupSelectedIndexChanged(ByVal args As NValueChangeEventArgs)
            m_EventsLog.LogEvent("Horizontal Radio Selected: " & CInt(args.NewValue))
        End Sub

        Private Sub OnVerticalRadioGroupSelectedIndexChanged(ByVal args As NValueChangeEventArgs)
            m_EventsLog.LogEvent("Vertical Radio Selected: " & CInt(args.NewValue))
        End Sub

#End Region

#Region "Fields"

        Private m_EventsLog As NExampleEventsLog

#End Region

#Region "Schema"

        Public Shared ReadOnly NRadioButtonExampleSchema As NSchema

#End Region
    End Class
End Namespace

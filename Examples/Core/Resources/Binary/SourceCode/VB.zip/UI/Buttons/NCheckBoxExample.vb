Imports Nevron.Nov.Editors
Imports Nevron.Nov.Dom
Imports Nevron.Nov.Layout
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.UI
    Public Class NCheckBoxExample
        Inherits NExampleBase
#Region "Constructors"

        Public Sub New()
        End Sub
        Shared Sub New()
            NCheckBoxExampleSchema = NSchema.Create(GetType(NCheckBoxExample), NExampleBase.NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            m_CheckBox = New NCheckBox("Check Box")
            m_CheckBox.HorizontalPlacement = ENHorizontalPlacement.Left
            m_CheckBox.VerticalPlacement = ENVerticalPlacement.Top
            m_CheckBox.CheckedChanged += New [Function](Of NValueChangeEventArgs)(AddressOf OnCheckedChanged)
            Return m_CheckBox
        End Function
        Protected Overrides Function CreateExampleControls() As NWidget
            Dim stack As NStackPanel = New NStackPanel()
            stack.FillMode = ENStackFillMode.Last
            stack.FitMode = ENStackFitMode.Last

            ' properties
            Dim editors = NDesigner.GetDesigner(m_CheckBox).CreatePropertyEditors(m_CheckBox, NInputElement.EnabledProperty, NToggleButtonBase.CheckedProperty, NCheckBox.IndeterminateProperty, NSymbolToggleButton.SymbolContentRelationProperty)

            Dim propertiesStack As NStackPanel = New NStackPanel()
            For i = 0 To editors.Count - 1
                propertiesStack.Add(editors(i))
            Next

            stack.Add(New NGroupBox("Properties", New NUniSizeBoxGroup(propertiesStack)))

            ' events log
            m_EventsLog = New NExampleEventsLog()
            stack.Add(m_EventsLog)

            Return stack
        End Function
        Protected Overrides Function GetExampleDescription() As String
            Return "
<p>
	This example demonstrates NOV check boxes. Use the controls to the right to enable/disable the check box and to change its state and direction.
</p>
" End Function

#End Region

#Region "Event Handlers"

        Private Sub OnCheckedChanged(ByVal args As NValueChangeEventArgs)
            Dim checkBox = CType(args.TargetNode, NCheckBox)
            m_EventsLog.LogEvent("Check box " & If(checkBox.Checked, " checked", " unchecked"))
        End Sub

#End Region

#Region "Fields"

        Private m_CheckBox As NCheckBox
        Private m_EventsLog As NExampleEventsLog

#End Region

#Region "Schema"

        Public Shared ReadOnly NCheckBoxExampleSchema As NSchema

#End Region
    End Class
End Namespace

Imports Nevron.Nov.Dom
Imports Nevron.Nov.Graphics
Imports Nevron.Nov.Layout
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.UI
    Public Class NButtonsExample
        Inherits NExampleBase
#Region "Constructors"

        Public Sub New()
        End Sub
        Shared Sub New()
            NButtonsExampleSchema = NSchema.Create(GetType(NButtonsExample), NExampleBase.NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            ' create the host
            Dim stack As NStackPanel = New NStackPanel()
            stack.HorizontalPlacement = ENHorizontalPlacement.Left
            stack.VerticalPlacement = ENVerticalPlacement.Top
            stack.VerticalSpacing = 5

            ' text only push button
            Dim textOnlyButton As NButton = New NButton("Text only button")
            textOnlyButton.Click += AddressOf OnButtonClicked
            stack.Add(textOnlyButton)

            ' image only push button
            Dim imageOnlyButton As NButton = New NButton(NResources.Image__16x16_Contacts_png)
            imageOnlyButton.Click += AddressOf OnButtonClicked
            stack.Add(imageOnlyButton)

            ' image and text button
            Dim image2 As NImage = NResources.Image__16x16_Mail_png
            Dim imageAndTextButton As NButton = New NButton(New NPairBox("Image before text", image2, ENPairBoxRelation.Box2BeforeBox1, False))
            imageAndTextButton.Click += AddressOf OnButtonClicked
            stack.Add(imageAndTextButton)

            ' repeat button
            Dim repeatButton As NRepeatButton = New NRepeatButton("Repeat button")
            repeatButton.StartClicking += AddressOf OnRepeatButtonStartClicking
            repeatButton.Click += AddressOf OnButtonClicked
            repeatButton.EndClicking += AddressOf OnRepeatButtonEndClicking
            stack.Add(repeatButton)

            ' toggle button
            Dim toggleButton As NToggleButton = New NToggleButton("Toggle button")
            toggleButton.Click += AddressOf OnButtonClicked
            stack.Add(toggleButton)

            ' disabled button
            Dim disabledButton As NButton = New NButton("Disabled Button")
            disabledButton.Enabled = False
            stack.Add(disabledButton)

            Return stack
        End Function
        Protected Overrides Function CreateExampleControls() As NWidget
            Dim stack As NStackPanel = New NStackPanel()
            stack.FillMode = ENStackFillMode.Last
            stack.FitMode = ENStackFitMode.Last

            ' create the events list box
            m_EventsLog = New NExampleEventsLog()
            stack.Add(m_EventsLog)

            Return stack
        End Function
        Protected Overrides Function GetExampleDescription() As String
            Return "
<p>
	This example demonstrates the different types of buttons supported by NOV.
</p>
" End Function

#End Region

#Region "Event Handlers"

        Private Sub OnButtonClicked(ByVal arg1 As NEventArgs)
            m_EventsLog.LogEvent("Button clicked")
        End Sub
        Private Sub OnRepeatButtonStartClicking(ByVal arg1 As NEventArgs)
            m_EventsLog.LogEvent("Repeat Button Start Clicking")
        End Sub
        Private Sub OnRepeatButtonEndClicking(ByVal arg1 As NEventArgs)
            m_EventsLog.LogEvent("Repeat Button End Clicking")
        End Sub

#End Region

#Region "Fields"

        Private m_EventsLog As NExampleEventsLog

#End Region

#Region "Schema"

        Public Shared ReadOnly NButtonsExampleSchema As NSchema

#End Region
    End Class
End Namespace

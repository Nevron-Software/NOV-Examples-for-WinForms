Imports System.Globalization
Imports Nevron.Nov.Dom
Imports Nevron.Nov.Graphics
Imports Nevron.Nov.Layout
Imports Nevron.Nov.Text
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.UI
    Public Class NRibbonTabGroupsExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' Default constructor.
        ''' </summary>
        Public Sub New()
        End Sub

        ''' <summary>
        ''' Static constructor.
        ''' </summary>
        Shared Sub New()
            NRibbonTabGroupsExampleSchema = NSchema.Create(GetType(NRibbonTabGroupsExample), NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            Dim ribbon As NRibbon = New NRibbon()
            ribbon.VerticalPlacement = ENVerticalPlacement.Top

            ' The application menu
            ribbon.Tab.ApplicationMenu = CreateMenu()

            ' The "Home" page
            ribbon.Tab.TabPages.Add(CreateHomePage())

            ' The "Insert" page
            ribbon.Tab.TabPages.Add(CreateInsertPage())

            ' The "View" page
            Dim viewPage As NRibbonTabPage = New NRibbonTabPage("View")
            ribbon.Tab.TabPages.Add(viewPage)

            ' Ribbon tab page groups
            ribbon.Tab.TabPageGroups = New NRibbonTabPageGroupCollection()
            ribbon.Tab.TabPageGroups.Add(CreateTableTabPageGroup())
            ribbon.Tab.TabPageGroups.Add(CreateImageTabPageGroup())

            ' The help button
            ribbon.Tab.AdditionalContent = New NRibbonHelpButton()

            ' The ribbon search box
            ribbon.Tab.SearchBox = New NRibbonSearchBox()
            ribbon.Tab.SearchBox.InitFromOwnerRibbon()

            ' Subscribe to ribbon button Click events
            ribbon.AddEventHandler(NButtonBase.ClickEvent, New NEventHandler(Of NEventArgs)(AddressOf OnRibbonButtonClicked))
            Return ribbon
        End Function

        Protected Overrides Function CreateExampleControls() As NWidget
            Dim stack As NStackPanel = New NStackPanel()
            stack.FillMode = ENStackFillMode.Last
            stack.FitMode = ENStackFitMode.Last
            Dim tableCheckBox As NCheckBox = New NCheckBox()
            tableCheckBox.HorizontalPlacement = ENHorizontalPlacement.Left
            tableCheckBox.Checked = True
            AddHandler tableCheckBox.CheckedChanged, AddressOf OnTableCheckBoxCheckedChanged
            stack.Add(NPairBox.Create("Table group visible:", tableCheckBox))
            Dim tableColorBox As NColorBox = New NColorBox()
            tableColorBox.HorizontalPlacement = ENHorizontalPlacement.Left
            tableColorBox.SelectedColor = m_TableTabPageGroup.StripeFill.GetPrimaryColor()
            AddHandler tableColorBox.SelectedColorChanged, AddressOf OnTableColorBoxSelectedColorChanged
            stack.Add(NPairBox.Create("Table group color:", tableColorBox))
            Dim imageCheckBox As NCheckBox = New NCheckBox()
            imageCheckBox.HorizontalPlacement = ENHorizontalPlacement.Left
            imageCheckBox.Checked = True
            AddHandler imageCheckBox.CheckedChanged, AddressOf OnImageCheckBoxCheckedChanged
            stack.Add(NPairBox.Create("Image group visible:", imageCheckBox))
            Dim imageColorBox As NColorBox = New NColorBox()
            imageColorBox.HorizontalPlacement = ENHorizontalPlacement.Left
            imageColorBox.SelectedColor = m_ImageTabPageGroup.StripeFill.GetPrimaryColor()
            AddHandler imageColorBox.SelectedColorChanged, AddressOf OnImageColorBoxSelectedColorChanged
            stack.Add(NPairBox.Create("Image group color:", imageColorBox))
            m_EventsLog = New NExampleEventsLog()
            stack.Add(m_EventsLog)
            Return New NUniSizeBoxGroup(stack)
        End Function

        Protected Overrides Function GetExampleDescription() As String
            Return "
<p>
	This example demonstrates how to create and configure ribbon tab groups. Ribbon tab groups are collections of ribbon tab pages
	grouped because they contain logically connected commands. Each ribbon tab group can have a specific stripe fill which is painted
	at the top of each tab page header in the group. This makes it easy to distinguish tabs from different groups. Tab groups are
	typically used to provide contextual ribbon tab functionallity.
</p>
<p>
	Use the controls on the right to show and hide ribbon tab groups and configure their appearance.
</p>
"
        End Function

#End Region

#Region "Implementation"

#Region "Tab Pages"

        Private Function CreateMenu() As NApplicationMenu
            Dim appMenu As NApplicationMenu = New NApplicationMenu("File")
            Dim menu = appMenu.MenuPane

            ' Create the "Open" and "Save" menu items
            menu.Items.Add(New NMenuItem(NResources.Image_Ribbon_32x32_folder_action_open_png, "Open"))
            menu.Items.Add(New NMenuItem(NResources.Image_Ribbon_32x32_save_png, "Save"))

            ' Create the "Save As" menu item and its sub items
            Dim saveAsMenuItem As NMenuItem = New NMenuItem(NResources.Image_Ribbon_32x32_save_as_png, "Save As")
            saveAsMenuItem.Items.Add(New NMenuItem("PNG Image"))
            saveAsMenuItem.Items.Add(New NMenuItem("JPEG Image"))
            saveAsMenuItem.Items.Add(New NMenuItem("BMP Image"))
            saveAsMenuItem.Items.Add(New NMenuItem("GIF Image"))
            menu.Items.Add(saveAsMenuItem)

            ' Create the rest of the menu items
            menu.Items.Add(New NMenuSeparator())
            menu.Items.Add(New NMenuItem(NResources.Image_Ribbon_32x32_print_png, "Print"))
            menu.Items.Add(New NMenuItem(NResources.Image_Ribbon_32x32_settings_png, "Options"))
            menu.Items.Add(New NMenuSeparator())
            menu.Items.Add(New NMenuItem(NResources.Image_Ribbon_32x32_exit_png, "Exit"))

            ' Create a label for the content pane
            appMenu.ContentPane = New NLabel("This is the content pane")

            ' Create 2 buttons for the footer pane
            appMenu.FooterPane = New NApplicationMenuFooterPanel()
            appMenu.FooterPane.Add(New NButton("Options..."))
            appMenu.FooterPane.Add(New NButton("Exit"))
            Return appMenu
        End Function

        Private Function CreateHomePage() As NRibbonTabPage
            Dim page As NRibbonTabPage = New NRibbonTabPage("Home")

#Region "Clipboard Group"

            Dim group As NRibbonGroup = New NRibbonGroup("Clipboard")
            group.Icon = NResources.Image_Ribbon_16x16_clipboard_copy_png
            page.Groups.Add(group)
            Dim pasteSplitButton = NRibbonSplitButton.CreateLarge("Paste", NResources.Image_Ribbon_32x32_clipboard_paste_png)
            pasteSplitButton.CollapseToMedium = ENCollapseCondition.Never
            pasteSplitButton.CollapseToSmall = ENCollapseCondition.Never
            Dim pasteMenu As NMenu = New NMenu()
            pasteMenu.Items.Add(New NMenuItem("Paste"))
            pasteMenu.Items.Add(New NMenuItem("Paste Special..."))
            pasteMenu.Items.Add(New NMenuItem("Paste as Link"))
            pasteSplitButton.Popup.Content = pasteMenu
            group.Items.Add(pasteSplitButton)
            Dim collapsiblePanel As NRibbonCollapsiblePanel = New NRibbonCollapsiblePanel()
            collapsiblePanel.InitialState = ENRibbonWidgetState.Medium
            group.Items.Add(collapsiblePanel)
            collapsiblePanel.Add(New NRibbonButton("Cut", Nothing, NResources.Image_Ribbon_16x16_clipboard_cut_png))
            collapsiblePanel.Add(New NRibbonButton("Copy", Nothing, NResources.Image_Ribbon_16x16_clipboard_copy_png))
            collapsiblePanel.Add(New NRibbonButton("Format Painter", Nothing, NResources.Image_Ribbon_16x16_copy_format_png))

#End Region

#Region "Font Group"

            group = New NRibbonGroup("Font")
            group.Icon = NResources.Image_Ribbon_16x16_character_change_case_png
            page.Groups.Add(group)
            Dim wrapPanel As NRibbonWrapFlowPanel = New NRibbonWrapFlowPanel()
            wrapPanel.HorizontalSpacing = NDesign.HorizontalSpacing
            group.Items.Add(wrapPanel)
            Dim stackPanel As NRibbonStackPanel = CreateStackPanel()
            wrapPanel.Add(stackPanel)
            Dim fontNameComboBox As NFontNameComboBox = New NFontNameComboBox()
            fontNameComboBox.SelectedIndex = 5
            stackPanel.Add(fontNameComboBox)
            Dim fontSizeComboBox As NComboBox = New NComboBox()
            FillFontSizeCombo(fontSizeComboBox)
            fontSizeComboBox.SelectedIndex = 2
            stackPanel.Add(fontSizeComboBox)
            stackPanel = CreateStackPanel()
            stackPanel.Add(NRibbonButton.CreateSmall("Grow Font", NResources.Image_Ribbon_16x16_font_grow_png))
            stackPanel.Add(NRibbonButton.CreateSmall("Shrink Font", NResources.Image_Ribbon_16x16_font_shrink_png))
            stackPanel.Add(New NRibbonSeparator())
            wrapPanel.Add(stackPanel)
            Dim changeCaseMenu = NRibbonMenuDropDown.CreateSmall("Change Case", NResources.Image_Ribbon_16x16_character_change_case_png)
            changeCaseMenu.Menu.Items.Add(New NMenuItem("lowercase"))
            changeCaseMenu.Menu.Items.Add(New NMenuItem("UPPERCASE"))
            changeCaseMenu.Menu.Items.Add(New NMenuItem("Capitalize Each Word"))
            wrapPanel.Add(changeCaseMenu)
            stackPanel = CreateStackPanel()
            stackPanel.Add(NRibbonToggleButton.CreateSmall("Bold", NResources.Image_Ribbon_16x16_character_bold_small_png))
            stackPanel.Add(NRibbonToggleButton.CreateSmall("Italic", NResources.Image_Ribbon_16x16_character_italic_small_png))
            stackPanel.Add(NRibbonToggleButton.CreateSmall("Underline", NResources.Image_Ribbon_16x16_character_underline_small_png))
            stackPanel.Add(NRibbonToggleButton.CreateSmall("Strikethrough", NResources.Image_Ribbon_16x16_character_strikethrough_small_png))
            Dim panel2 As NRibbonStackPanel = CreateStackPanel()
            panel2.Add(NRibbonToggleButton.CreateSmall("Subscript", NResources.Image_Ribbon_16x16_character_subscript_small_png))
            panel2.Add(NRibbonToggleButton.CreateSmall("Superscript", NResources.Image_Ribbon_16x16_character_superscript_small_png))
            stackPanel.Add(New NToggleButtonGroup(panel2))
            stackPanel.Add(New NRibbonSeparator())
            wrapPanel.Add(stackPanel)
            Dim fillSplitButton As NFillSplitButton = New NFillSplitButton()
            fillSplitButton.Image = NResources.Image_Ribbon_16x16_text_fill_png
            wrapPanel.Add(fillSplitButton)

#End Region

#Region "Paragraph Group"

            group = New NRibbonGroup("Paragraph")
            group.Icon = NResources.Image_Ribbon_16x16_paragraph_align_center_png
            page.Groups.Add(group)
            wrapPanel = New NRibbonWrapFlowPanel()
            wrapPanel.HorizontalSpacing = NDesign.HorizontalSpacing
            group.Items.Add(wrapPanel)
            stackPanel = CreateStackPanel()
            stackPanel.Add(NRibbonSplitButton.CreateSmall("Bullets", NResources.Image_Ribbon_16x16_list_bullets_png))
            stackPanel.Add(NRibbonSplitButton.CreateSmall("Numbering", NResources.Image_Ribbon_16x16_list_numbers_png))
            Dim multilevelListMenu = NRibbonMenuDropDown.CreateSmall("Multilevel List", NResources.Image_Ribbon_16x16_list_multilevel_png)
            multilevelListMenu.Menu.Items.Add(New NMenuItem("Alpha and Numeric"))
            multilevelListMenu.Menu.Items.Add(New NMenuItem("Alpha and Roman"))
            multilevelListMenu.Menu.Items.Add(New NMenuItem("Numeric and Roman"))
            stackPanel.Add(multilevelListMenu)
            stackPanel.Add(New NRibbonSeparator())
            wrapPanel.Add(stackPanel)
            stackPanel = CreateStackPanel()
            stackPanel.Add(NRibbonButton.CreateSmall("Decrease Indent", NResources.Image_Ribbon_16x16_paragraph_indent_left_png))
            stackPanel.Add(NRibbonButton.CreateSmall("Increase Indent", NResources.Image_Ribbon_16x16_paragraph_indent_right_png))
            stackPanel.Add(New NRibbonSeparator())
            wrapPanel.Add(stackPanel)
            stackPanel = CreateStackPanel()
            stackPanel.Add(NRibbonButton.CreateSmall("Sort", NResources.Image_Ribbon_16x16_sort_az_png))
            stackPanel.Add(New NRibbonSeparator())
            stackPanel.Add(NRibbonButton.CreateSmall("Marks", NResources.Image_Ribbon_16x16_paragraph_marker_small_png))
            wrapPanel.Add(stackPanel)
            stackPanel = CreateStackPanel()
            stackPanel.Add(NRibbonToggleButton.CreateSmall("Align Left", NResources.Image_Ribbon_16x16_paragraph_align_left_png))
            stackPanel.Add(NRibbonToggleButton.CreateSmall("Align Center", NResources.Image_Ribbon_16x16_paragraph_align_center_png))
            stackPanel.Add(NRibbonToggleButton.CreateSmall("Align Right", NResources.Image_Ribbon_16x16_paragraph_align_right_png))
            stackPanel.Add(NRibbonToggleButton.CreateSmall("Justify", NResources.Image_Ribbon_16x16_paragraph_align_justified_png))
            stackPanel.Add(New NRibbonSeparator())
            wrapPanel.Add(New NToggleButtonGroup(stackPanel))
            stackPanel = CreateStackPanel()
            Dim lineSpacingMenu = NRibbonMenuDropDown.CreateSmall("Line Spacing", NResources.Image_Ribbon_16x16_paragraph_spacing_before_png)
            lineSpacingMenu.Menu.Items.Add(New NMenuItem("1.0"))
            lineSpacingMenu.Menu.Items.Add(New NMenuItem("1.15"))
            lineSpacingMenu.Menu.Items.Add(New NMenuItem("1.5"))
            lineSpacingMenu.Menu.Items.Add(New NMenuItem("2.0"))
            lineSpacingMenu.Menu.Items.Add(New NMenuItem("3.0"))
            lineSpacingMenu.Menu.Items.Add(New NMenuSeparator())
            lineSpacingMenu.Menu.Items.Add(New NMenuItem("Line Spacing Options..."))
            stackPanel.Add(lineSpacingMenu)
            stackPanel.Add(New NRibbonSeparator())
            wrapPanel.Add(stackPanel)
            fillSplitButton = New NFillSplitButton()
            wrapPanel.Add(fillSplitButton)

#End Region

#Region "Text Styles Group"

            group = New NRibbonGroup("Text Styles")
            group.Icon = NResources.Image_Ribbon_16x16_text_fill_png
            page.Groups.Add(group)
            Dim gallery As NRibbonGallery = New NRibbonGallery("Text Style", NResources.Image_Ribbon_32x32_cover_page_png, New NTextStylePicker())
            group.Items.Add(gallery)

#End Region

            Return page
        End Function

        Private Function CreateInsertPage() As NRibbonTabPage
            Dim page As NRibbonTabPage = New NRibbonTabPage("Insert")

            ' The "Page" group
            Dim group As NRibbonGroup = New NRibbonGroup("Page")
            group.Icon = NResources.Image_Ribbon_16x16_cover_page_png
            Dim panel As NRibbonCollapsiblePanel = New NRibbonCollapsiblePanel()
            group.Items.Add(panel)
            Dim button As NRibbonButton = New NRibbonButton("Cover Page")
            button.LargeImage = NResources.Image_Ribbon_32x32_cover_page_png
            button.SmallImage = NResources.Image_Ribbon_16x16_cover_page_png
            panel.Add(button)
            Dim imageBox As NImageBox = New NImageBox(NResources.Image_Ribbon_16x16_character_bold_small_png)
            button = New NRibbonButton("Blank Page")
            button.LargeImage = NResources.Image_Ribbon_32x32_page_png
            button.SmallImage = NResources.Image_Ribbon_16x16_page_png
            panel.Add(button)
            button = New NRibbonButton("Page Break")
            button.LargeImage = NResources.Image_Ribbon_32x32_page_break_png
            button.SmallImage = NResources.Image_Ribbon_16x16_page_break_png
            panel.Add(button)
            page.Groups.Add(group)
            Return page
        End Function

#End Region

#Region "Table Tab Page Group"

        Private Function CreateTableTabPageGroup() As NRibbonTabPageGroup
            m_TableTabPageGroup = New NRibbonTabPageGroup("Table", ENRibbonStripeColor.Yellow)
            m_TableTabPageGroup.TabPages.Add(CreateTableDesignPage())
            m_TableTabPageGroup.TabPages.Add(CreateTableLayoutPage())
            Return m_TableTabPageGroup
        End Function

        Private Function CreateTableDesignPage() As NRibbonTabPage
            Dim page As NRibbonTabPage = New NRibbonTabPage("Design")
            Dim group As NRibbonGroup = New NRibbonGroup("Table Styles")
            group.Icon = NResources.Image_Ribbon_16x16_table_design_png
            page.Groups.Add(group)
            Dim stylePicker As NTableStylePicker = New NTableStylePicker()
            Dim gallery As NRibbonGallery = New NRibbonGallery("Table Style", NResources.Image_Ribbon_32x32_table_design_png, stylePicker)
            gallery.ColumnCountStep = stylePicker.MaxNumberOfColumns
            gallery.MinimumPopupColumnCount = stylePicker.MaxNumberOfColumns
            gallery.PopupMenu = New NMenu()
            gallery.PopupMenu.Items.Add(New NMenuSeparator())
            gallery.PopupMenu.Items.Add(New NMenuItem("Modify Table Style..."))
            gallery.PopupMenu.Items.Add(New NMenuItem("New Table Style..."))
            group.Items.Add(gallery)
            Return page
        End Function

        Private Function CreateTableLayoutPage() As NRibbonTabPage
            Dim page As NRibbonTabPage = New NRibbonTabPage("Layout")
            Dim group As NRibbonGroup = New NRibbonGroup("Table")
            group.Icon = NResources.Image_Ribbon_16x16_page_break_png
            page.Groups.Add(group)
            group.Items.Add(NRibbonButton.CreateLarge("Properties", NResources.Image_Ribbon_32x32_table_design_png))
            Return page
        End Function

#End Region

#Region "Image Tab Page Group"

        Private Function CreateImageTabPageGroup() As NRibbonTabPageGroup
            m_ImageTabPageGroup = New NRibbonTabPageGroup("Image", ENRibbonStripeColor.Purple)
            m_ImageTabPageGroup.TabPages.Add(CreateImageEditPage())
            m_ImageTabPageGroup.TabPages.Add(CreateImageEffectsPage())
            Return m_ImageTabPageGroup
        End Function

        Private Function CreateImageEditPage() As NRibbonTabPage
            Dim page As NRibbonTabPage = New NRibbonTabPage("Edit")
            Return page
        End Function

        Private Function CreateImageEffectsPage() As NRibbonTabPage
            Dim page As NRibbonTabPage = New NRibbonTabPage("Effects")
            Return page
        End Function

#End Region

#End Region

#Region "Event Handlers"

        Private Sub OnRibbonButtonClicked(ByVal arg As NEventArgs)
            Dim button As INRibbonButton = TryCast(arg.TargetNode, INRibbonButton)

            If button IsNot Nothing Then
                m_EventsLog.LogEvent(button.Text & " clicked")
            End If
        End Sub

        Private Sub OnTableCheckBoxCheckedChanged(ByVal arg As NValueChangeEventArgs)
            Dim visible As Boolean = arg.NewValue
            m_TableTabPageGroup.Visibility = If(visible, ENVisibility.Visible, ENVisibility.Collapsed)
        End Sub

        Private Sub OnTableColorBoxSelectedColorChanged(ByVal arg As NValueChangeEventArgs)
            Dim color As NColor = arg.NewValue

            ' Set the stripe fill of the tab page headers in the tab group
            m_TableTabPageGroup.StripeFill = New NColorFill(color)

            ' Set a lighter color fill of the inactive tab page headers in the tab group
            m_TableTabPageGroup.InactiveHeaderFill = New NColorFill(color.Lighten(0.9F))
        End Sub

        Private Sub OnImageCheckBoxCheckedChanged(ByVal arg As NValueChangeEventArgs)
            Dim visible As Boolean = arg.NewValue
            m_ImageTabPageGroup.Visibility = If(visible, ENVisibility.Visible, ENVisibility.Collapsed)
        End Sub

        Private Sub OnImageColorBoxSelectedColorChanged(ByVal arg As NValueChangeEventArgs)
            Dim color As NColor = arg.NewValue

            ' Set the stripe fill of the tab page headers in the tab group
            m_ImageTabPageGroup.StripeFill = New NColorFill(color)

            ' Set a lighter color fill of the inactive tab page headers in the tab group
            m_ImageTabPageGroup.InactiveHeaderFill = New NColorFill(color.Lighten(0.9F))
        End Sub

#End Region

#Region "Fields"

        Private m_TableTabPageGroup As NRibbonTabPageGroup
        Private m_ImageTabPageGroup As NRibbonTabPageGroup
        Private m_EventsLog As NExampleEventsLog

#End Region

#Region "Schema"

        ''' <summary>
        ''' Schema associated with NRibbonTabGroupsExample.
        ''' </summary>
        Public Shared ReadOnly NRibbonTabGroupsExampleSchema As NSchema

#End Region

#Region "Static Methods"

        Private Shared Function CreateStackPanel() As NRibbonStackPanel
            Dim stackPanel As NRibbonStackPanel = New NRibbonStackPanel()
            stackPanel.HorizontalSpacing = NDesign.HorizontalSpacing
            Return stackPanel
        End Function
        ''' <summary>
        ''' Fills the given combo box with the commonly used font sizes.
        ''' </summary>
        ''' <returns></returns>
        Private Shared Sub FillFontSizeCombo(ByVal comboBox As NComboBox)
            Dim items = comboBox.Items
            items.Clear()
            Dim i = 8

            While i < 12
                items.Add(CreateFontSizeComboBoxItem(i))
                i += 1
            End While

            While i <= 28
                items.Add(CreateFontSizeComboBoxItem(i))
                i += 2
            End While

            items.Add(CreateFontSizeComboBoxItem(36))
            items.Add(CreateFontSizeComboBoxItem(48))
            items.Add(CreateFontSizeComboBoxItem(72))
        End Sub

        Private Shared Function CreateFontSizeComboBoxItem(ByVal fontSize As Integer) As NComboBoxItem
            Dim item As NComboBoxItem = New NComboBoxItem(fontSize.ToString(CultureInfo.InvariantCulture))
            Return item
        End Function

#End Region
    End Class
End Namespace

Imports Nevron.Nov.Dom
Imports Nevron.Nov.Graphics
Imports Nevron.Nov.Layout
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.UI
    Public Class NInteractiveContextPopupExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' Default constructor.
        ''' </summary>
        Public Sub New()
        End Sub
        ''' <summary>
        ''' Static constructor.
        ''' </summary>
        Shared Sub New()
            NInteractiveContextPopupExampleSchema = NSchema.Create(GetType(NInteractiveContextPopupExample), NExampleBase.NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            m_Label = New NLabel("Click me with the right mouse button")
            m_Label.HorizontalPlacement = ENHorizontalPlacement.Center
            m_Label.VerticalPlacement = ENVerticalPlacement.Center
            m_Label.Font = New NFont(NFontDescriptor.DefaultSansFamilyName, 10, ENFontStyle.Regular)
            m_Label.TextFill = New NColorFill(NColor.Black)
            Dim widget As NContentHolder = New NContentHolder(m_Label)
            widget.HorizontalPlacement = ENHorizontalPlacement.Left
            widget.VerticalPlacement = ENVerticalPlacement.Top
            widget.BackgroundFill = New NColorFill(NColor.PapayaWhip)
            widget.Border = NBorder.CreateFilledBorder(NColor.Black)
            widget.BorderThickness = New NMargins(1)
            widget.PreferredSize = New NSize(300, 100)
            AddHandler widget.MouseDown, New [Function](Of NMouseButtonEventArgs)(AddressOf OnTargetWidgetMouseDown)
            Return widget
        End Function

        Protected Overrides Function CreateExampleControls() As NWidget
            Return Nothing
        End Function

        Protected Overrides Function GetExampleDescription() As String
            Return "
<p>
	This example demonstrates how to create an interactive context popup. All you have to do is to create
	a popup window and show it using the <b>NPopupWindow.OpenInContext(...)</b> method when the user right
	clicks the widget the context is designed for.
</p>
"
        End Function

#End Region

#Region "Implementation"

        Private Function CreateToggleButton(ByVal text As String, ByVal isChecked As Boolean) As NToggleButton
            Dim label As NLabel = New NLabel(text)
            label.HorizontalPlacement = ENHorizontalPlacement.Center
            label.VerticalPlacement = ENVerticalPlacement.Center
            Dim button As NToggleButton = New NToggleButton(label)
            button.Checked = isChecked
            button.PreferredWidth = 20
            AddHandler button.CheckedChanged, New [Function](Of NValueChangeEventArgs)(AddressOf OnToggleButtonCheckedChanged)
            Return button
        End Function

        Private Function CreatePopupContent() As NWidget
            ' Create the first tool bar
            Dim toolBar1 As NToolBar = New NToolBar()
            toolBar1.Gripper.Visibility = ENVisibility.Collapsed
            toolBar1.Pendant.Visibility = ENVisibility.Collapsed
            toolBar1.Items.HorizontalSpacing = 3
            Dim fontComboBox As NComboBox = New NComboBox()
            Dim i = 0, fontCount = Fonts.Length

            While i < fontCount
                Dim fontName = Fonts(i)
                Dim label As NLabel = New NLabel(fontName)
                label.Font = New NFont(fontName, 8, ENFontStyle.Regular)
                fontComboBox.Items.Add(New NComboBoxItem(label))

                If Equals(fontName, m_Label.Font.Name) Then
                    ' Update the selected index
                    fontComboBox.SelectedIndex = i
                End If

                i += 1
            End While

            AddHandler fontComboBox.SelectedIndexChanged, New [Function](Of NValueChangeEventArgs)(AddressOf OnFontComboBoxSelectedIndexChanged)
            toolBar1.Items.Add(fontComboBox)
            Dim fontSizeNumericUpDown As NNumericUpDown = New NNumericUpDown()
            fontSizeNumericUpDown.Minimum = 6
            fontSizeNumericUpDown.Maximum = 32
            fontSizeNumericUpDown.Value = m_Label.Font.Size
            AddHandler fontSizeNumericUpDown.ValueChanged, New [Function](Of NValueChangeEventArgs)(AddressOf OnFontSizeNumericUpDownValueChanged)
            toolBar1.Items.Add(fontSizeNumericUpDown)

            ' Create the second tool bar
            Dim toolBar2 As NToolBar = New NToolBar()
            toolBar2.Gripper.Visibility = ENVisibility.Collapsed
            toolBar2.Pendant.Visibility = ENVisibility.Collapsed
            Dim boldButton = CreateToggleButton("B", (m_Label.Font.Style And ENFontStyle.Bold) = ENFontStyle.Bold)
            toolBar2.Items.Add(boldButton)
            Dim italicButton = CreateToggleButton("I", (m_Label.Font.Style And ENFontStyle.Italic) = ENFontStyle.Italic)
            toolBar2.Items.Add(italicButton)
            Dim underlineButton = CreateToggleButton("U", (m_Label.Font.Style And ENFontStyle.Underline) = ENFontStyle.Underline)
            toolBar2.Items.Add(underlineButton)
            Dim fillButton As NFillSplitButton = New NFillSplitButton()
            fillButton.SelectedValue = New NAutomaticValue(Of NFill)(False, CType(m_Label.TextFill.DeepClone(), NFill))
            AddHandler fillButton.SelectedValueChanged, New [Function](Of NValueChangeEventArgs)(AddressOf OnFillButtonSelectedValueChanged)
            toolBar2.Items.Add(fillButton)

            ' Add the tool bars in a stack
            Dim stack As NStackPanel = New NStackPanel()
            stack.Add(toolBar1)
            stack.Add(toolBar2)
            Return stack
        End Function

#End Region

#Region "Event Handlers"

        Private Sub OnTargetWidgetMouseDown(ByVal args As NMouseButtonEventArgs)
            If args.Button <> ENMouseButtons.Right Then Return

            ' Mark the event as handled
            args.Cancel = True

            ' Create and show the popup
            Dim popupContent As NWidget = CreatePopupContent()
            Dim popupWindow As NPopupWindow = New NPopupWindow(popupContent)
            NPopupWindow.OpenInContext(popupWindow, args.CurrentTargetNode, args.ScreenPosition)
        End Sub

        Private Sub OnFontComboBoxSelectedIndexChanged(ByVal args As NValueChangeEventArgs)
            Dim index As Integer = args.NewValue
            m_Label.Font.Name = Fonts(index)
        End Sub

        Private Sub OnToggleButtonCheckedChanged(ByVal args As NValueChangeEventArgs)
            Dim toggleButton = CType(args.CurrentTargetNode, NToggleButton)
            Dim label = CType(toggleButton.Content, NLabel)

            Select Case label.Text
                Case "B"
                    m_Label.Font.Style = m_Label.Font.Style Xor ENFontStyle.Bold
                Case "I"
                    m_Label.Font.Style = m_Label.Font.Style Xor ENFontStyle.Italic
                Case "U"
                    m_Label.Font.Style = m_Label.Font.Style Xor ENFontStyle.Underline
            End Select
        End Sub

        Private Sub OnFontSizeNumericUpDownValueChanged(ByVal args As NValueChangeEventArgs)
            m_Label.Font.Size = CDbl(args.NewValue)
        End Sub

        Private Sub OnFillButtonSelectedValueChanged(ByVal args As NValueChangeEventArgs)
            Dim newValue As NAutomaticValue(Of NFill) = args.NewValue
            Dim fill = newValue.Value
            m_Label.TextFill = CType(fill.DeepClone(), NFill)
        End Sub

#End Region

#Region "Fields"

        Private m_Label As NLabel

#End Region

#Region "Schema"

        ''' <summary>
        ''' Schema associated with NInteractiveContextPopupExample.
        ''' </summary>
        Public Shared ReadOnly NInteractiveContextPopupExampleSchema As NSchema

#End Region

#Region "Constants"

        Private Shared ReadOnly Fonts As String() = New String() {NFontDescriptor.DefaultSansFamilyName, NFontDescriptor.DefaultSerifFamilyName, NFontDescriptor.DefaultMonoFamilyName}

#End Region
    End Class
End Namespace

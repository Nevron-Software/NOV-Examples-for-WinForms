Imports System
Imports Nevron.Nov.Dom
Imports Nevron.Nov.Editors
Imports Nevron.Nov.Graphics
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.UI
    Public Class NLabelExample
        Inherits NExampleBase
#Region "Constructors"

        Public Sub New()
        End Sub
        Shared Sub New()
            NLabelExampleSchema = NSchema.Create(GetType(NLabelExample), NExampleBase.NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            m_Label = New NLabel()
            m_Label.SetBorder(1, NColor.Red)

            Return m_Label
        End Function
        Protected Overrides Function CreateExampleControls() As NWidget
            Dim stack As NStackPanel = New NStackPanel()

            m_SampleTextComboBox = New NComboBox()

            For i = 0 To 1
                m_SampleTextComboBox.Items.Add(New NComboBoxItem("Sample " & i.ToString()))
            Next

            m_SampleTextComboBox.SelectedIndexChanged += New [Function](Of NValueChangeEventArgs)(AddressOf OnSampleTextChanged)
            m_SampleTextComboBox.SelectedIndex = 0

            stack.Add(New NLabel("Sample Text:"))
            stack.Add(m_SampleTextComboBox)

            ' font families
            stack.Add(New NLabel("Font Family:"))
            m_FontFamiliesComboBox = New NComboBox()

            Dim fontFamilies = NApplication.FontService.InstalledFontsMap.FontFamilies
            Dim selectedIndex = 0

            For i = 0 To fontFamilies.Length - 1
                m_FontFamiliesComboBox.Items.Add(New NComboBoxItem(fontFamilies(i)))

                If Equals(fontFamilies(i), NFontDescriptor.DefaultSansFamilyName) Then
                    selectedIndex = i
                End If
            Next

            m_FontFamiliesComboBox.SelectedIndex = selectedIndex
            m_FontFamiliesComboBox.SelectedIndexChanged += New [Function](Of NValueChangeEventArgs)(AddressOf OnFontStyleChanged)
            stack.Add(m_FontFamiliesComboBox)

            ' font sizes
            stack.Add(New NLabel("Font Size:"))
            m_FontSizeComboBox = New NComboBox()
            For i = 5 To 71
                m_FontSizeComboBox.Items.Add(New NComboBoxItem(i.ToString()))
            Next

            m_FontSizeComboBox.SelectedIndex = 4
            m_FontSizeComboBox.SelectedIndexChanged += New [Function](Of NValueChangeEventArgs)(AddressOf OnFontStyleChanged)
            stack.Add(m_FontSizeComboBox)

            ' add style controls
            m_BoldCheckBox = New NCheckBox()
            m_BoldCheckBox.Content = New NLabel("Bold")
            m_BoldCheckBox.CheckedChanged += New [Function](Of NValueChangeEventArgs)(AddressOf OnFontStyleChanged)
            stack.Add(m_BoldCheckBox)

            m_ItalicCheckBox = New NCheckBox()
            m_ItalicCheckBox.Content = New NLabel("Italic")
            m_ItalicCheckBox.CheckedChanged += New [Function](Of NValueChangeEventArgs)(AddressOf OnFontStyleChanged)
            stack.Add(m_ItalicCheckBox)

            m_UnderlineCheckBox = New NCheckBox()
            m_UnderlineCheckBox.Content = New NLabel("Underline")
            m_UnderlineCheckBox.CheckedChanged += New [Function](Of NValueChangeEventArgs)(AddressOf OnFontStyleChanged)
            stack.Add(m_UnderlineCheckBox)

            m_StrikeThroughCheckBox = New NCheckBox()
            m_StrikeThroughCheckBox.Content = New NLabel("Strikethrough")
            m_StrikeThroughCheckBox.CheckedChanged += New [Function](Of NValueChangeEventArgs)(AddressOf OnFontStyleChanged)
            stack.Add(m_StrikeThroughCheckBox)

            ' properties
            Dim editors = NDesigner.GetDesigner(m_Label).CreatePropertyEditors(m_Label, NInputElement.EnabledProperty, NWidget.HorizontalPlacementProperty, NWidget.VerticalPlacementProperty, NLabel.TextAlignmentProperty, NLabel.TextWrapModeProperty)

            Dim propertiesStack As NStackPanel = New NStackPanel()
            For i = 0 To editors.Count - 1
                propertiesStack.Add(editors(i))
            Next

            ' make sure font style is updated
            OnFontStyleChanged(Nothing)

            stack.Add(New NGroupBox("Properties", New NUniSizeBoxGroup(propertiesStack)))
            Return stack
        End Function
        Protected Overrides Function GetExampleDescription() As String
            Return "
<p>
	This example demonstrates how to create and use labels. The controls on the right let you
	change the label's font, alignment, placement, etc.
</p>
" End Function

#End Region

#Region "Event Handlers"

        Private Sub OnSampleTextChanged(ByVal args As NValueChangeEventArgs)
            Select Case m_SampleTextComboBox.SelectedIndex
                Case 0
                    m_Label.Text = "The quick brown fox jumps over the lazy dog."
                Case 1
                    m_Label.Text = "This is the first line of a multi line label." & vbLf & "This is the second line."
            End Select
        End Sub
        Private Sub OnFontStyleChanged(ByVal args As NValueChangeEventArgs)
            Dim fontFamily As String = TryCast(m_FontFamiliesComboBox.SelectedItem.Content, NLabel).Text
            Dim fontSize As Integer = Integer.Parse(TryCast(m_FontSizeComboBox.SelectedItem.Content, NLabel).Text)

            Dim fontStyle = ENFontStyle.Regular

            If m_BoldCheckBox.Checked Then
                fontStyle = fontStyle Or ENFontStyle.Bold
            End If

            If m_ItalicCheckBox.Checked Then
                fontStyle = fontStyle Or ENFontStyle.Italic
            End If

            If m_UnderlineCheckBox.Checked Then
                fontStyle = fontStyle Or ENFontStyle.Underline
            End If

            If m_StrikeThroughCheckBox.Checked Then
                fontStyle = fontStyle Or ENFontStyle.Strikethrough
            End If

            m_Label.Font = New NFont(fontFamily, fontSize, fontStyle, ENFontRasterizationMode.Antialiased)
        End Sub

#End Region

#Region "Fields"

        Private m_Label As NLabel

        Private m_SampleTextComboBox As NComboBox
        Private m_FontFamiliesComboBox As NComboBox
        Private m_FontSizeComboBox As NComboBox
        Private m_BoldCheckBox As NCheckBox
        Private m_ItalicCheckBox As NCheckBox
        Private m_UnderlineCheckBox As NCheckBox
        Private m_StrikeThroughCheckBox As NCheckBox

#End Region

#Region "Schema"

        ''' <summary>
        ''' Schema associated with NLabelExample.
        ''' </summary>
        Public Shared ReadOnly NLabelExampleSchema As NSchema

#End Region
    End Class
End Namespace

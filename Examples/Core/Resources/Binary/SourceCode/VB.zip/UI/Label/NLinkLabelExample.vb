Imports Nevron.Nov.Dom
Imports Nevron.Nov.Graphics
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.UI
    Public Class NLinkLabelExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' Default constructor.
        ''' </summary>
        Public Sub New()
        End Sub

        ''' <summary>
        ''' Static constructor.
        ''' </summary>
        Shared Sub New()
            NLinkLabelExampleSchema = NSchema.Create(GetType(NLinkLabelExample), NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            Dim stack As NStackPanel = New NStackPanel()
            stack.Padding = New NMargins(NDesign.HorizontalSpacing, NDesign.VerticalSpacing)
            Dim webLinkLabel As NLinkLabel = New NLinkLabel("Nevron Website", "https://www.nevron.com/")
            stack.Add(webLinkLabel)
            Dim emailLinkLabel As NLinkLabel = New NLinkLabel("Nevron Support Email", "mailto:support@nevron.com")
            stack.Add(emailLinkLabel)
            Return stack
        End Function

        Protected Overrides Function CreateExampleControls() As NWidget
            Return Nothing
        End Function

        Protected Overrides Function GetExampleDescription() As String
            Return "
<p>
	This example demonstrates how to create and use link labels. The first label leads to Nevron's website and the second one
	should open your default email client when clicked. When a link label is clicked, it is automatically marked as visited by
	setting its <b>IsVisited</b> property to true.
</p>
"
        End Function

#End Region

#Region "Schema"

        ''' <summary>
        ''' Schema associated with NLinkLabelExample.
        ''' </summary>
        Public Shared ReadOnly NLinkLabelExampleSchema As NSchema

#End Region
    End Class
End Namespace

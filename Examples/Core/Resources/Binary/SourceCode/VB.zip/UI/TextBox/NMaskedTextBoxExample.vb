Imports Nevron.Nov.Dom
Imports Nevron.Nov.Layout
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.UI
    Public Class NMaskedTextBoxExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' Default constructor.
        ''' </summary>
        Public Sub New()
        End Sub

        ''' <summary>
        ''' Static constructor.
        ''' </summary>
        Shared Sub New()
            NMaskedTextBoxExampleSchema = NSchema.Create(GetType(NMaskedTextBoxExample), NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            Dim stack As NStackPanel = New NStackPanel()
            stack.HorizontalPlacement = ENHorizontalPlacement.Left
            m_PhoneNumberTextBox = New NMaskedTextBox()
            m_PhoneNumberTextBox.Mask = "(999) 000-0000"
            AddHandler m_PhoneNumberTextBox.MaskInputRejected, AddressOf OnMaskInputRejected
            stack.Add(NPairBox.Create("Phone Number:", m_PhoneNumberTextBox))
            m_CreditCardNumberTextBox = New NMaskedTextBox()
            m_CreditCardNumberTextBox.Mask = "0000 0000 0000 0000"
            AddHandler m_CreditCardNumberTextBox.MaskInputRejected, AddressOf OnMaskInputRejected
            stack.Add(NPairBox.Create("Credit Card Number:", m_CreditCardNumberTextBox))
            m_SocialSecurityNumberTextBox = New NMaskedTextBox()
            m_SocialSecurityNumberTextBox.Mask = "000-00-0000"
            AddHandler m_SocialSecurityNumberTextBox.MaskInputRejected, AddressOf OnMaskInputRejected
            stack.Add(NPairBox.Create("Social Security Number:", m_SocialSecurityNumberTextBox))
            Return New NUniSizeBoxGroup(stack)
        End Function

        Protected Overrides Function CreateExampleControls() As NWidget
            Dim stack As NStackPanel = New NStackPanel()
            stack.FillMode = ENStackFillMode.Last
            stack.FitMode = ENStackFitMode.Last
            Dim promptCharTextBox As NTextBox = New NTextBox("_")
            promptCharTextBox.MaxLength = 1
            promptCharTextBox.SelectAllOnFocus = True
            promptCharTextBox.HorizontalPlacement = ENHorizontalPlacement.Left
            AddHandler promptCharTextBox.TextChanged, AddressOf OnPromptCharTextBoxTextChanged
            stack.Add(NPairBox.Create("Prompt char: ", promptCharTextBox))
            m_EventsLog = New NExampleEventsLog()
            stack.Add(m_EventsLog)
            Return stack
        End Function

        Protected Overrides Function GetExampleDescription() As String
            Return "
<p>
    This example demonstrates how to create, configure and use masked text boxes. The text box on the right lets you configure
    the prompt character (i.e. the <b>PromptChar</b> property) of the sample masked text boxes.
</p>
"
        End Function

#End Region

#Region "Event Handlers"

        Private Sub OnMaskInputRejected(ByVal arg As NMaskInputRejectedEventArgs)
            m_EventsLog.LogEvent("Rejected Character: '" & arg.Character & "', reason: '" & NStringHelpers.InsertSpacesBeforeUppersAndDigits(arg.Reason.ToString()) & "'")
        End Sub

        Private Sub OnPromptCharTextBoxTextChanged(ByVal arg As NValueChangeEventArgs)
            Dim text = CStr(arg.NewValue)

            If Not Equals(text, Nothing) AndAlso text.Length = 1 Then
                Dim promptChar = text(0)
                m_PhoneNumberTextBox.PromptChar = promptChar
                m_CreditCardNumberTextBox.PromptChar = promptChar
                m_SocialSecurityNumberTextBox.PromptChar = promptChar
            End If
        End Sub

#End Region

#Region "Fields"

        Private m_PhoneNumberTextBox As NMaskedTextBox
        Private m_CreditCardNumberTextBox As NMaskedTextBox
        Private m_SocialSecurityNumberTextBox As NMaskedTextBox
        Private m_EventsLog As NExampleEventsLog

#End Region

#Region "Schema"

        ''' <summary>
        ''' Schema associated with NMaskedTextBoxExample.
        ''' </summary>
        Public Shared ReadOnly NMaskedTextBoxExampleSchema As NSchema

#End Region
    End Class
End Namespace

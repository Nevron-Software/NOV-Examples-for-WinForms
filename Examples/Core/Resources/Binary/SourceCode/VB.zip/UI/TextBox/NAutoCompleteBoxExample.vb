Imports System
Imports System.IO

Imports Nevron.Nov.DataStructures
Imports Nevron.Nov.Dom
Imports Nevron.Nov.Graphics
Imports Nevron.Nov.Layout
Imports Nevron.Nov.UI
Imports Nevron.Nov.Xml

Namespace Nevron.Nov.Examples.UI
    Public Class NAutoCompleteBoxExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' Default constructor.
        ''' </summary>
        Public Sub New()
        End Sub
        ''' <summary>
        ''' Static constructor.
        ''' </summary>
        Shared Sub New()
            NAutoCompleteBoxExampleSchema = NSchema.Create(GetType(NAutoCompleteBoxExample), NExampleBase.NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            Dim stack As NStackPanel = New NStackPanel()
            stack.HorizontalPlacement = ENHorizontalPlacement.Left
            stack.VerticalPlacement = ENVerticalPlacement.Top
            stack.VerticalSpacing = 10

            ' Load the contry data
            m_Countries = LoadCountryData()

            ' Create the simple auto complete text box
            m_TextBox = New NAutoCompleteBox()
            m_TextBox.PreferredWidth = 300
            m_TextBox.InitAutoComplete(m_Countries)
            Me.m_TextBox.TextChanged += AddressOf OnTextBoxTextChanged
            Dim pairBox = CreatePairBox("Enter country name:", m_TextBox)
            stack.Add(New NGroupBox("Auto complete items -> Labels", pairBox))

            ' Create the advanced auto complete text box
            m_AdvancedTextBox = New NAutoCompleteBox()
            m_AdvancedTextBox.PreferredWidth = 300
            m_AdvancedTextBox.Image = NResources.Image_ExamplesUI_Icons_Search_png
            m_AdvancedTextBox.InitAutoComplete(m_Countries, New NCountryFactory())
            Me.m_AdvancedTextBox.TextChanged += AddressOf OnTextBoxTextChanged
            pairBox = CreatePairBox("Enter country name:", m_AdvancedTextBox)
            stack.Add(New NGroupBox("Auto complete items -> Custom widgets", pairBox))

            Return stack
        End Function
        Protected Overrides Function CreateExampleControls() As NWidget
            Dim stack As NStackPanel = New NStackPanel()
            stack.FillMode = ENStackFillMode.Last
            stack.FitMode = ENStackFitMode.Last

            ' Create the property editors
            Dim enabledCheckBox As NCheckBox = New NCheckBox("Enabled", True)
            enabledCheckBox.CheckedChanged += New [Function](Of NValueChangeEventArgs)(AddressOf OnEnabledCheckBoxCheckedChanged)
            stack.Add(enabledCheckBox)

            m_CaseSensitiveCheckBox = New NCheckBox("Case Sensitive", False)
            m_CaseSensitiveCheckBox.CheckedChanged += New [Function](Of NValueChangeEventArgs)(AddressOf OnCaseSensitiveCheckBoxCheckedChanged)
            stack.Add(m_CaseSensitiveCheckBox)

            Dim stringMacthModeComboBox As NComboBox = New NComboBox()
            stringMacthModeComboBox.FillFromEnum(Of ENStringMatchMode)()
            stringMacthModeComboBox.SelectedIndexChanged += AddressOf OnStringMacthModeComboBoxSelectedIndexChanged
            stack.Add(NPairBox.Create("String Match Mode:", stringMacthModeComboBox))

            ' Add the events log
            m_EventsLog = New NExampleEventsLog()
            stack.Add(m_EventsLog)

            Return stack
        End Function
        Protected Overrides Function GetExampleDescription() As String
            Return "
<p>
	This example demonstrates how to create and use auto complete text boxes. The auto complete text box
	is an UI element that hosts a text box and also provides an auto complete functionality. Using the 
	controls on the right you can specify whether the auto complete should be case sensitive (default)
	or not and the string match mode.
</p>
" End Function

#End Region

#Region "Implementation"

        Private Function CreatePairBox(ByVal labelText As String, ByVal textBox As NAutoCompleteBox) As NPairBox
            Dim label As NLabel = New NLabel(labelText)
            label.VerticalPlacement = ENVerticalPlacement.Center

            Dim pairBox As NPairBox = New NPairBox(label, textBox, ENPairBoxRelation.Box1AboveBox2, False)
            pairBox.Spacing = 3
            Return pairBox
        End Function
        Private Function LoadCountryData() As NList(Of NCountry)
            ' Get the country list XML stream
            Dim stream As Stream = NResources.Instance.GetResourceStream("RSTR_CountryList_xml")

            ' Load an xml document from the stream
            Dim xmlDocument = NXmlDocument.LoadFromStream(stream)

            ' Process it
            Dim rows = xmlDocument.GetChildAt(0).GetChildAt(1)
            Dim countries As NList(Of NCountry) = New NList(Of NCountry)()

            Dim i = 0, countryCount = rows.ChildrenCount

            While i < countryCount
                Dim row = rows.GetChildAt(i)

                ' Get the country name
                Dim country As NCountry = New NCountry(GetValue(row.GetChildAt(1)))
                If String.IsNullOrEmpty(country.Name) Then Continue While

                ' Get the country's capital
                country.Capital = GetValue(row.GetChildAt(6))
                If String.IsNullOrEmpty(country.Capital) Then Continue While

                ' Get the country's currency
                country.CurrencyCode = GetValue(row.GetChildAt(7))
                country.CurrencyName = GetValue(row.GetChildAt(8))
                If String.IsNullOrEmpty(country.CurrencyCode) OrElse String.IsNullOrEmpty(country.CurrencyName) Then Continue While

                ' Get the country code (ISO 3166-1 2 Letter Code)
                country.Code = GetValue(row.GetChildAt(10))
                If String.IsNullOrEmpty(country.Code) Then Continue While

                ' Get the country flag
                Dim flagResourceName As String = "RIMG_CountryFlags_" & country.Code.ToLower() & "_png"
                Dim flagResource = Presentation.NResources.Instance.GetResource(flagResourceName)
                If flagResource Is Nothing Then Continue While

                country.Flag = New NImage(New NEmbeddedResourceRef(flagResource))

                ' Add the country to the list
                countries.Add(country)
                i += 1
            End While

            ' Sort the countries by name and return them
            countries.Sort()
            Return countries
        End Function
        Private Function GetCountryByName(ByVal str As String, ByVal caseSensitive As Boolean) As NCountry
            Dim comparison = If(caseSensitive, StringComparison.Ordinal, StringComparison.OrdinalIgnoreCase)
            Dim i = 0, count = m_Countries.Count

            While i < count
                Dim country = m_Countries(i)
                If String.Equals(str, country.Name, comparison) Then Return country
                i += 1
            End While

            Return Nothing
        End Function

#End Region

#Region "Event Handlers"

        Private Sub OnEnabledCheckBoxCheckedChanged(ByVal arg As NValueChangeEventArgs)
            Dim enabled As Boolean = arg.NewValue
            m_TextBox.Enabled = enabled
            m_AdvancedTextBox.Enabled = enabled
        End Sub
        Private Sub OnCaseSensitiveCheckBoxCheckedChanged(ByVal arg As NValueChangeEventArgs)
            Dim autocompleteCaseSensitive As Boolean = arg.NewValue
            m_TextBox.CaseSensitive = autocompleteCaseSensitive
            m_AdvancedTextBox.CaseSensitive = autocompleteCaseSensitive
        End Sub
        Private Sub OnStringMacthModeComboBoxSelectedIndexChanged(ByVal arg As NValueChangeEventArgs)
            Dim comboBox = CType(arg.CurrentTargetNode, NComboBox)
            Dim stringMatchMode As ENStringMatchMode = comboBox.SelectedItem.Tag
            m_TextBox.StringMatchMode = stringMatchMode
            m_AdvancedTextBox.StringMatchMode = stringMatchMode
        End Sub
        Private Sub OnTextBoxTextChanged(ByVal arg As NValueChangeEventArgs)
            Dim text = CStr(arg.NewValue)
            Dim country = GetCountryByName(text, m_CaseSensitiveCheckBox.Checked)
            If country IsNot Nothing Then
                m_EventsLog.LogEvent("Selected country: " & country.Name)
            End If
        End Sub

#End Region

#Region "Fields"

        Private m_TextBox As NAutoCompleteBox
        Private m_AdvancedTextBox As NAutoCompleteBox

        Private m_CaseSensitiveCheckBox As NCheckBox
        Private m_EventsLog As NExampleEventsLog
        Private m_Countries As NList(Of NCountry)

#End Region

#Region "Schema"

        ''' <summary>
        ''' Schema associated with NAutoCompleteBoxExample.
        ''' </summary>
        Public Shared ReadOnly NAutoCompleteBoxExampleSchema As NSchema

#End Region

#Region "Static Methods"

        Private Shared Function GetValue(ByVal node As NXmlNode) As String
            If node.ChildrenCount <> 1 Then Return Nothing

            Dim textNode As NXmlTextNode = TryCast(node.GetChildAt(0), NXmlTextNode)
            Return If(textNode IsNot Nothing, textNode.Text, Nothing)
        End Function

#End Region

#Region "Nested Types"

        Private Class NCountry
            Implements IComparable(Of NCountry), INDeeplyCloneable
            Public Sub New(ByVal name As String)
                Me.Name = name
                Code = Nothing
                CurrencyCode = Nothing
                CurrencyName = Nothing
                Capital = Nothing
                Flag = Nothing
            End Sub

            Public Overrides Function ToString() As String
                Return Name
            End Function
            Public Function CompareTo(ByVal other As NCountry) As Integer Implements IComparable(Of NCountry).CompareTo
                Return Name.CompareTo(other.Name)
            End Function
            ''' <summary>
            ''' Creates an identical copy of this object.
            ''' </summary>
            ''' <returns>A copy of this instance.</returns>
            Public Function DeepClone() As Object Implements INDeeplyCloneable.DeepClone
                Dim country As NCountry = New NCountry(Name)
                Return country
            End Function

            Public Name As String
            Public Code As String
            Public CurrencyCode As String
            Public CurrencyName As String
            Public Capital As String
            Public Flag As NImage
        End Class

        Private Class NCountryFactory
            Inherits NWidgetFactory(Of NCountry)
            Public Overrides Function CreateWidget(ByVal country As NCountry) As NWidget
                ' Create a dock panel
                Dim stack As NStackPanel = New NStackPanel()
                stack.Padding = New NMargins(3)
                stack.Tag = country

                ' Create the flag image box and the country name label
                Dim countryLabel As NLabel = New NLabel(country.Name)
                countryLabel.VerticalPlacement = ENVerticalPlacement.Center
                countryLabel.Font = New NFont(NFontDescriptor.DefaultSansFamilyName, 10, ENFontStyle.Bold)

                Dim imageBox As NImageBox = New NImageBox(NSystem.SafeDeepClone(country.Flag))
                imageBox.VerticalPlacement = ENVerticalPlacement.Center
                imageBox.HorizontalPlacement = ENHorizontalPlacement.Left

                Dim pairBox As NPairBox = New NPairBox(imageBox, countryLabel)
                pairBox.Spacing = 3
                stack.Add(pairBox)

                ' Create the capital label
                Dim capitalLabel As NLabel = New NLabel("Capital: " & country.Capital)
                stack.Add(capitalLabel)

                ' Create the currency label
                Dim currencyLabel As NLabel = New NLabel("Currency: " & country.CurrencyName & ", " & country.CurrencyCode)
                stack.Add(currencyLabel)

                Return stack
            End Function
        End Class

#End Region
    End Class
End Namespace

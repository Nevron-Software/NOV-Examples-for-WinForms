Imports System
Imports Nevron.Nov.Dom
Imports Nevron.Nov.Editors
Imports Nevron.Nov.Graphics
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.UI
    ''' <summary>
    ''' The example shows how to work with the NTextBox widget
    ''' </summary>
    Public Class NTextBoxExample
        Inherits NExampleBase
#Region "Constructors"

        Public Sub New()
        End Sub

        Shared Sub New()
            NTextBoxExampleSchema = NSchema.Create(GetType(NTextBoxExample), NExampleBase.NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            m_TextBox = New NTextBox()
            m_TextBox.Hint = "Enter some text here."
            Return m_TextBox
        End Function

        Protected Overrides Function CreateExampleControls() As NWidget
            Dim stack As NStackPanel = New NStackPanel()

            ' font families
            m_FontFamiliesComboBox = New NComboBox()
            Dim fontFamilies = NApplication.FontService.InstalledFontsMap.FontFamilies
            Dim selectedIndex = 0

            For i = 0 To fontFamilies.Length - 1
                m_FontFamiliesComboBox.Items.Add(New NComboBoxItem(fontFamilies(i)))

                If Equals(fontFamilies(i), NFontDescriptor.DefaultSansFamilyName) Then
                    selectedIndex = i
                End If
            Next

            m_FontFamiliesComboBox.SelectedIndex = selectedIndex
            AddHandler m_FontFamiliesComboBox.SelectedIndexChanged, New [Function](Of NValueChangeEventArgs)(AddressOf OnFontStyleChanged)
            stack.Add(m_FontFamiliesComboBox)

            ' font sizes
            stack.Add(New NLabel("Font Size:"))
            m_FontSizeComboBox = New NComboBox()

            For i = 5 To 72 - 1
                m_FontSizeComboBox.Items.Add(New NComboBoxItem(i.ToString()))
            Next

            m_FontSizeComboBox.SelectedIndex = 4
            AddHandler m_FontSizeComboBox.SelectedIndexChanged, New [Function](Of NValueChangeEventArgs)(AddressOf OnFontStyleChanged)
            stack.Add(m_FontSizeComboBox)

            ' add style controls
            m_BoldCheckBox = New NCheckBox()
            m_BoldCheckBox.Content = New NLabel("Bold")
            AddHandler m_BoldCheckBox.CheckedChanged, New [Function](Of NValueChangeEventArgs)(AddressOf OnFontStyleChanged)
            stack.Add(m_BoldCheckBox)
            m_ItalicCheckBox = New NCheckBox()
            m_ItalicCheckBox.Content = New NLabel("Italic")
            AddHandler m_ItalicCheckBox.CheckedChanged, New [Function](Of NValueChangeEventArgs)(AddressOf OnFontStyleChanged)
            stack.Add(m_ItalicCheckBox)
            m_UnderlineCheckBox = New NCheckBox()
            m_UnderlineCheckBox.Content = New NLabel("Underline")
            AddHandler m_UnderlineCheckBox.CheckedChanged, New [Function](Of NValueChangeEventArgs)(AddressOf OnFontStyleChanged)
            stack.Add(m_UnderlineCheckBox)
            m_StrikeTroughCheckBox = New NCheckBox()
            m_StrikeTroughCheckBox.Content = New NLabel("Strikethrough")
            AddHandler m_StrikeTroughCheckBox.CheckedChanged, New [Function](Of NValueChangeEventArgs)(AddressOf OnFontStyleChanged)
            stack.Add(m_StrikeTroughCheckBox)

            ' properties
            Dim editors = NDesigner.GetDesigner(m_TextBox).CreatePropertyEditors(m_TextBox, NInputElement.EnabledProperty, NTextBox.ReadOnlyProperty, NTextBox.MultilineProperty, NTextBox.WordWrapProperty, NTextBox.AlwaysShowSelectionProperty, NTextBox.AlwaysShowCaretProperty, NTextBox.AcceptsTabProperty, NTextBox.AcceptsEnterProperty, NTextBox.ShowCaretProperty, NWidget.HorizontalPlacementProperty, NWidget.VerticalPlacementProperty, NTextBox.TextAlignProperty, NTextBox.DirectionProperty, NScrollContentBase.HScrollModeProperty, NScrollContentBase.VScrollModeProperty, NTextBox.CharacterCasingProperty, NTextBox.PasswordCharProperty, NTextBox.HintProperty, NTextBox.HintFillProperty)
            Dim propertiesStack As NStackPanel = New NStackPanel()

            For i = 0 To editors.Count - 1
                propertiesStack.Add(editors(i))
            Next

            stack.Add(New NGroupBox("Properties", New NUniSizeBoxGroup(propertiesStack)))

            ' make sure font style is updated
            OnFontStyleChanged(Nothing)
            Return stack
        End Function

        Protected Overrides Function GetExampleDescription() As String
            Return "
<p>
	This example demonstrates how to create and use text boxes. The controls on the right let you
	change the text box's font, alignment, placement, etc.
</p>
"
        End Function

#End Region

#Region "Event Handlers"

        Private Sub OnFontStyleChanged(ByVal args As NValueChangeEventArgs)
            Dim fontFamily As String = TryCast(m_FontFamiliesComboBox.SelectedItem.Content, NLabel).Text
            Dim fontSize As Integer = Integer.Parse(TryCast(m_FontSizeComboBox.SelectedItem.Content, NLabel).Text)
            Dim fontStyle = ENFontStyle.Regular

            If m_BoldCheckBox.Checked Then
                fontStyle = fontStyle Or ENFontStyle.Bold
            End If

            If m_ItalicCheckBox.Checked Then
                fontStyle = fontStyle Or ENFontStyle.Italic
            End If

            If m_UnderlineCheckBox.Checked Then
                fontStyle = fontStyle Or ENFontStyle.Underline
            End If

            If m_StrikeTroughCheckBox.Checked Then
                fontStyle = fontStyle Or ENFontStyle.Strikethrough
            End If

            m_TextBox.Font = New NFont(fontFamily, fontSize, fontStyle)
        End Sub

#End Region

#Region "Fields"

        Private m_TextBox As NTextBox
        Private m_FontFamiliesComboBox As NComboBox
        Private m_FontSizeComboBox As NComboBox
        Private m_BoldCheckBox As NCheckBox
        Private m_ItalicCheckBox As NCheckBox
        Private m_UnderlineCheckBox As NCheckBox
        Private m_StrikeTroughCheckBox As NCheckBox

#End Region

#Region "Schema"

        Public Shared ReadOnly NTextBoxExampleSchema As NSchema

#End Region
    End Class
End Namespace

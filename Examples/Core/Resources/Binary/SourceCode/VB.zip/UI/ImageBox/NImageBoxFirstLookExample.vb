Imports Nevron.Nov.Dom
Imports Nevron.Nov.Editors
Imports Nevron.Nov.Graphics
Imports Nevron.Nov.Layout
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.UI
    Public Class NImageBoxFirstLookExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' Default constructor
        ''' </summary>
        Public Sub New()
        End Sub
        ''' <summary>
        ''' Static constructor
        ''' </summary>
        Shared Sub New()
            NImageBoxFirstLookExampleSchema = NSchema.Create(GetType(NImageBoxFirstLookExample), NExampleBase.NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            ' Create an image box
            m_ImageBox = New NImageBox(NResources.Image_SampleImage_png)
            m_ImageBox.Border = NBorder.CreateFilledBorder(NColor.Red)
            m_ImageBox.BorderThickness = New NMargins(1)
            m_ImageBox.HorizontalPlacement = ENHorizontalPlacement.Left
            m_ImageBox.VerticalPlacement = ENVerticalPlacement.Top
            Return m_ImageBox
        End Function

        Protected Overrides Function CreateExampleControls() As NWidget
            Dim stack As NStackPanel = New NStackPanel()
            Dim editors = NDesigner.GetDesigner(m_ImageBox).CreatePropertyEditors(m_ImageBox, NWidget.HorizontalPlacementProperty, NWidget.VerticalPlacementProperty, NBoxElement.BackgroundFillProperty, NImageBoxBase.ImageMappingProperty, NImageBox.ImageRenderModeProperty, NImageBox.ImageProperty)
            Dim i = 0, count = editors.Count

            While i < count
                stack.Add(editors(i))
                i += 1
            End While

            Return New NUniSizeBoxGroup(stack)
        End Function

        Protected Overrides Function GetExampleDescription() As String
            Return "
<p>
	This example demonstrates the features of the Nevron image box widget. Use the controls to the right to load an image
	and change the image box settings.
</p>
"
        End Function

#End Region

#Region "Fields"

        Private m_ImageBox As NImageBox

#End Region

#Region "Schema"

        ''' <summary>
        ''' Schema associated with NImageBoxFirstLookExample
        ''' </summary>
        Public Shared ReadOnly NImageBoxFirstLookExampleSchema As NSchema

#End Region
    End Class
End Namespace

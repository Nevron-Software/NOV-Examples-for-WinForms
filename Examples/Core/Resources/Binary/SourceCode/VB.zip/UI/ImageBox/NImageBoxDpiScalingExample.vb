Imports System.Globalization

Imports Nevron.Nov.Dom
Imports Nevron.Nov.Graphics
Imports Nevron.Nov.Layout
Imports Nevron.Nov.UI

Namespace Nevron.Nov.Examples.UI
    Public Class NImageBoxDpiScalingExample
        Inherits NExampleBase
#Region "Constructors"

        ''' <summary>
        ''' Default constructor.
        ''' </summary>
        Public Sub New()
        End Sub

        ''' <summary>
        ''' Static constructor.
        ''' </summary>
        Shared Sub New()
            NImageBoxDpiScalingExampleSchema = NSchema.Create(GetType(NImageBoxDpiScalingExample), NExampleBaseSchema)
        End Sub

#End Region

#Region "Example"

        Protected Overrides Function CreateExampleContent() As NWidget
            Dim stack As NStackPanel = New NStackPanel()
            stack.Direction = ENHVDirection.LeftToRight
            stack.HorizontalPlacement = ENHorizontalPlacement.Center
            stack.VerticalPlacement = ENVerticalPlacement.Center

            Dim printIcon As NImage = NResources.Image_Print_ico
            Dim iconImageSource As NDpiAwareImageSource = New NDpiAwareImageSource(printIcon.ImageSource, New NSizeI(32, 32)) ' Windows icon (ICO file)
            ' Default size - i.e. desired image size at 96 DPI (100% screen scaling)
            stack.Add(CreatePairBox("DPI Aware Image", New NImageBox(iconImageSource)))

            ' Create a raster from the image at index 3 in the print icon, which has a size of 32x32 pixels
            Dim raster = printIcon.ImageSource.CreateFrameRaster(3)
            stack.Add(CreatePairBox("DPI Unaware Image", New NImageBox(NImage.FromRaster(raster))))

            Return New NUniSizeBoxGroup(stack)
        End Function
        Protected Overrides Function CreateExampleControls() As NWidget
            m_EventsLog = New NExampleEventsLog()
            Return m_EventsLog
        End Function
        Protected Overrides Function GetExampleDescription() As String
            Return "
<p>
	This example demonstrates the features of the Nevron icon box widget. This is a widget that can show a different image based
	on the current DPI scaling. Change the screen scaling in your OS to see how the image box dynamically loads an image of different
	size. Compare that image to the 16x16 pixel image in the image box and you will see that the image in the icon box is not blurred
	like the one in the image box.
</p>
" End Function

#End Region

#Region "Event Handlers"

        Protected Overrides Sub OnRegistered()
            MyBase.OnRegistered()

            m_EventsLog.LogEvent("Current DPI: " & GetResolution().ToString("N0", CultureInfo.InvariantCulture))
        End Sub

        Protected Overrides Sub OnResolutionChanged()
            MyBase.OnResolutionChanged()

            m_EventsLog.LogEvent("DPI Changed to " & GetResolution().ToString("N0", CultureInfo.InvariantCulture))
        End Sub

#End Region

#Region "Fields"

        Private m_EventsLog As NExampleEventsLog = New NExampleEventsLog()

#End Region

#Region "Schema"

        ''' <summary>
        ''' Schema associated with NImageBoxDpiScalingExample.
        ''' </summary>
        Public Shared ReadOnly NImageBoxDpiScalingExampleSchema As NSchema

#End Region

#Region "Static Methods"

        Private Shared Function CreatePairBox(ByVal text As String, ByVal widget As NWidget) As NPairBox
            Dim pairBox As NPairBox = New NPairBox(text, widget, ENPairBoxRelation.Box1AboveBox2, True)
            pairBox.Border = NBorder.CreateFilledBorder(NColor.DarkGray)
            pairBox.BorderThickness = New NMargins(1)
            pairBox.Padding = New NMargins(NDesign.HorizontalSpacing / 2, NDesign.VerticalSpacing / 2)

            Return pairBox
        End Function

#End Region
    End Class
End Namespace
